/* first record of xRoutines.c *****/
#include "suballcc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   int Xsubcc()
 *   int Xsub2cc()
 */
/**************************************************************/
/*eject*/
/*************************************************************** 
----------------------------------------------------------
*  Xsubcc(int round): execute subcc
***************************************************************/
int Xsubcc() {

  char cmnd[MAXLEN];

  sprintf(cmnd,
          "%sSubcc/Code/subcc %slsqccparams.target.dat",
          gParams.leibnizpath,
          gParams.suballccdetaildir);

  return(system(cmnd));

}
/*eject*/
/*************************************************************** 
----------------------------------------------------------
*  Xsub2cc(int round): execute sub2cc
***************************************************************/
int Xsub2cc(int round) {

  char cmnd[MAXLEN];

  sprintf(cmnd,
          "%sSub2cc/Code/sub2cc %slsqccparams.input.dat",
          gParams.leibnizpath,
          gParams.suballccdetaildir);

  return(system(cmnd));

}

/* last record of xRoutines.c *******/















