/* first record of doRounds.c *****/
#include "suballcc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   void doRounds()
 *   void defineTgtFile(int tgt)
 *   void defineMstFile(int tgt)
 *   int sub2suball(int tgt, int round)
 *    
 */
/**************************************************************/
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  doRounds(): do reduction rounds
* --------------------------------------------------------
***************************************************************/
void doRounds() {

  int tgt, round;

  char name[MAXLEN];

  showRoundSteps(
    "\nProcess targets\n");

  for (tgt=1; tgt<=numTargets; tgt++) {

    sprintf(name,
    "\n********************* Target %d ******************\n\n",tgt);
    showRoundSteps(name);

    /* define target file for target tgt */
    showRoundSteps("Define target file\n\n");
    defineTgtFile(tgt);

    numDeleteAttributes = 0;

    for (round=1; round<=MAX_ATTRIBUTE; round++) {

      sprintf(name,
      "\n***********Target %d -- Round %d ******************\n\n",
      tgt,round);
      showRoundSteps(name);

      /* define mst file */
      showRoundSteps("Define master file\n\n");
      defineMstFile();

      showRoundSteps("Execute sub2cc\n\n");
      /* execute sub2cc */
      if (Xsub2cc() != 0) {
        sprintf(name,
           "Execution of sub2cc failed for target %d in round %d",
           tgt,round);
        suballerror(name,"doRounds","401");
      }

      /* store/evaluate sub2cc output */
      /* select attribute to be deleted in next round */
      showRoundSteps("Evaluate Sub2cc output\n\n");
      if (sub2suball(tgt,round) != 0) {
        /* no subgroups found, stop for this target */
        break;
      } else {
        sprintf(name,"Attribute deleted in next round = %s\n\n",
            deleteAttribute[numDeleteAttributes]);
      }

    } /* end for round */

  } /* end for tgt */

  fprintf(suballfil,"\nENDATA\n");

  return;

}
/*eject*/
/**************************************************************
*  defineTgtFile(): define target file with one target
***************************************************************/
void defineTgtFile(int tgt) {

  char name[MAXLEN];

  FILE *tgtfil;

  sprintf(name,"input%s",gFileExt.tgt);
  tgtfil = openFileSuballccdetail(name,"w");

  fprintf(tgtfil,"TARGETS\n");
  fprintf(tgtfil,"%s\n",target[tgt]);
  fprintf(tgtfil,"ENDATA\n");

  closeFile(tgtfil);

  return;

}
/*eject*/
/**************************************************************
*  defineMstFile(): define input.mst file in Suballdetail directory
***************************************************************/
void defineMstFile(int tgt) {

  int i, flag, ndelatt;

  char token[MAX_ID];
  char fileRec[MAXLEN];

  char control[MAX_ID];
  char name[MAXLEN];

  FILE *inputmstfil;
  FILE *outputmstfil;

  ndelatt = 0;

  inputmstfil = openFilePrefix(gFileExt.mst, "r");

  sprintf(name,"input%s",gFileExt.mst);
  outputmstfil = openFileSuballccdetail(name,"w");

  strcpy(control,"ATTRIBUTES");

  while(fgets(fileRec, MAXLEN, inputmstfil) != NULL) {

  sscanf(fileRec,"%s",token);

  if (strcmp(control,"ATTRIBUTES") == 0) {
    if (strcmp(token,"ATTRIBUTES") == 0) {
      fprintf(outputmstfil,"%s",fileRec);
      strcpy(control,"DATA");
    }
    continue;
  } /* end if strcmp(control,"ATTRIBUTES") == 0 */

  if (strcmp(control,"DATA") == 0) {
    if (strcmp(token,"DATA") == 0) {
      fprintf(outputmstfil,"%s",fileRec);
      strcpy(control,"ENDATA");
      continue;
    }
    /* check if attribute name is in delete list */
    flag = FALSE;
    for (i=1; i<=numDeleteAttributes; i++) {
      if (strcmp(token,deleteAttribute[i]) == 0) {
        /* attribute name is in delete list */
        flag = TRUE;
        break;
      }
    }
    if (flag == FALSE) {
      /* accept attribute as given in fileRec */
      fprintf(outputmstfil,"%s",fileRec);
      continue;
    } else {
      /* delete this attribute */
      ndelatt++;
      fprintf(outputmstfil,"%s DELETE\n",token);
    }
  } /* end if strcmp(control,"DATA") == 0 */

  if (strcmp(control,"ENDATA") == 0) {
    /* copy fileRec into output file */
    fprintf(outputmstfil,"%s",fileRec);
    if (strcmp(token,"ENDATA") == 0) {
      break;
    }
    continue;
  } /* end if strcmp(control,"ENDATA") == 0 */

  } /* end while */

  if (strcmp(control,"ENDATA") != 0) {
    suballerror("Master file out of order\n",
                "defineMstFile", "101");
  }

  if (ndelatt != numDeleteAttributes) {
    suballerror("Inconsistent deletion counts of attributes",
                "defineMstFile", "102");
  }

  closeFile(inputmstfil);
  closeFile(outputmstfil);

  return;

}
/*eject*/
/**************************************************************
*  sub2suball(): save sub2 output file in suball file
***************************************************************/
int sub2suball(int tgt, int round) {

  int flag, haveattributeflag, i;

  char token[MAX_ID];
  char fileRec[MAXLEN];

  char control[MAX_ID];
  char name[MAXLEN], name2[MAXLEN];

  FILE *sub2fil;

  haveattributeflag = FALSE;

  sprintf(name,"input%s2",gFileExt.sub);
  sub2fil = openFileSuballccdetail(name,"r");

  strcpy(control,"PREAMBLE");

  while(fgets(fileRec, MAXLEN, sub2fil) != NULL) {

    sscanf(fileRec,"%s",token);

    if (strcmp(control,"PREAMBLE") == 0) {
      if ((tgt == 1) && (round == 1)) {
        /* preamble is printed only one time in suball output */
        /* do not print 'ENDATA' of preamble if it occurs */
        /* do not print 'SUBGROUP' */
        if (strcmp(token,"ENDATA") != 0) {
          if (strcmp(token,"SUBGROUP") != 0) {
            fprintf(suballfil,"%s",fileRec);
          }
        } else {
          fprintf(suballfil,"/*eject*/\n");
        }
      }
      if (strcmp(token,"ENDATA") == 0) {
        /* sub2 file has only preamble and no subgroups */        
        strcpy(control,"NOSUBGROUPS");
        break;
      } else if (strcmp(token,"SUBGROUP") == 0) {
        strcpy(control,"SUBGROUP");
        fprintf(suballfil,
          "*****************************************\n\n");
        fprintf(suballfil,
          "SUBALL TARGET %d ROUND %d\n\n", tgt,round);
        fprintf(suballfil,
          "TARGETCASE: %s\n\n",target[tgt]);
        fprintf(suballfil,
          "  Number of DELETE Attributes = %d\n",
          numDeleteAttributes);
        for (i=1; i<=numDeleteAttributes; i++) {
          fprintf(suballfil,"    %s\n",deleteAttribute[i]);
        }       
        fprintf(suballfil,
          "\n*****************************************\n");
        fprintf(suballfil,
          "/*eject*/\n");
      } else {
        continue;
      }
    }  /* end if  strcpy(control,"PREAMBLE") == 0 */

    if (strcmp(control,"SUBGROUP") == 0) {
      if (strcmp(token,"ENDATA") == 0) {
        fprintf(suballfil,"/*eject*/\n");
        strcpy(control,"ENDATA");
        break;
      }
      fprintf(suballfil,"%s",fileRec);

      /* get delete attribute from factor of first subgroup */
      if ((haveattributeflag == FALSE) &&
          (strcmp(token,"(") == 0)) {
        numDeleteAttributes++;
        sscanf(fileRec," ( %s %s",name, name2);
        /* case 1: name = attribute, name2 = inequality sign */
        /* case 2: name = coefficient, name2 = attribute */
        /* look for decimal point in name to decide case */
        flag = 1;
        for (i=0; i<=strlen(name)-1; i++) {
          if (name[i] == '.') {
            flag = 2;
            break;
          }  
        }
        if (flag == 1) {
          strcpy(deleteAttribute[numDeleteAttributes],name);
        } else {
          strcpy(deleteAttribute[numDeleteAttributes],name2);
        }
        haveattributeflag = TRUE;     
      }
      continue;
    } /* end if strcpy(control,"SUBGROUP") == 0 */

  } /* end while */

  closeFile(sub2fil);

  if (strcmp(control,"NOSUBGROUPS") == 0) {
    return 1;    
  }

  if (strcmp(control,"ENDATA") != 0) {
    suballerror("sub2 output file out of order\n",
                "sub2suball", "101");
  }

  if (haveattributeflag == FALSE) {
    suballerror("sub2 output file out of order\n",
                "sub2suball", "102");
  }

  return 0;

}
/* last record of doRounds.c *****/
