/* first record of suballcc.h *****/
#include "suballparams.h"
/******************* Custom Data Types **********************/
/* parameters */
struct {
  char  prefix[MAX_ID];
  char  directory[MAX_DIRECTORY];
  char  leibnizpath[MAX_DIRECTORY];
  char  subccdetaildir[MAX_DIRECTORY+MAX_ID];
  char  suballccdetaildir[MAX_DIRECTORY+MAX_ID];
  char  master2masterABprogram[MAX_DIRECTORY+MAX_ID];
  float attributeImportanceThreshold;
  int   maxAttributesUsed;
  int   significanceMeasure;
  float subgroupThreshold;
  int   maxExpansion;
  int   defSizeSubgroup;
  int   sortSplitRatio;
} typedef SuballccParams;

/* file extensions */
struct {
  char mst[32];
  char mstAB[32];
  char opt[32];
  char rtr[32];
  char rts[32];
  char rtsA[32];
  char rtsB[32];
  char rtsEqrtr[32];
  char ats[32];
  char rul[32];
  char cut[32];
  char sep[32];
  char sub[32];
  char tgt[32];
  char vot[32];
  char votA[32];
  char votB[32];
} typedef FileExtensions;
/*eject*/
/******************* Global Variables ***********************/
char lsqccparamsname[MAX_ID];

/* display and control */
int gNumOpenFiles;
int gShowSteps;
int gShowRoundSteps;
int gOutputVariations;
int gSelectTargetFile;
int gSelectTestFile;
int gKeepSubccdetail;
int gKeepSuballccdetail;

/* control/path parameters */
SuballccParams gParams;
 
/* file extensions */
FileExtensions gFileExt;

/* arrays */
char deleteAttribute[MAX_ATTRIBUTE+1][MAX_ID];
int numDeleteAttributes;

char target[MAX_TARGET+1][MAX_ID];
int numTargets;

/* output file */
FILE *suballfil;

/* error file */
FILE* errfil;

/* error flag for entire process */
/*  = 0: no errors */
int errorflag;
/*eject*/

/******************** Subroutines **************************/

int  suballcc();

/********** doRounds.c **********/
void doRounds();
void defineTgtFile(int tgt);
void defineMstFile();
int  sub2suball(int tgt, int round);

/********** initialize.c **********/
void initialize();
void createLsqccParamsFile();
void createLsqccParamsTargetFile();
void transferAtsFile();
/************** readFiles.c *************/
void loadTargetFile();
void lowerCase(char *ch);
int  parse_param(char *lhs, char *rhs, char *record, 
                 FILE *params);
void readParamsFile();
void shiftLeft(char fileRec[]);

/***************** util.c ******************/
void bubbleSort(double *a, int *idx, int n);

void  closeFile(FILE* file);
FILE* openFile(char* name, char* mode);
FILE* openFilePrefix(char* extension, char* mode);
FILE* openFileSuballccdetail(char* name, char* mode);

void  constructSuballccdetail();
void  removeSuballccdetail();
void  showRoundSteps(char *message);
int   stringCompare(const char *a, const char *b, int n);
void  suballerror(char *m1,char *m2,char *m3);

/************** xRoutines.c ***************/
int Xsubcc();
int Xsub2cc();

/* last record of suballcc.h *****/


