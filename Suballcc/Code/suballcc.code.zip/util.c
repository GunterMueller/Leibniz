/* first record of util.c *****/
#include "suballcc.h"
#include "features.h" /* system version selection */
/**************************************************************/
/*
 * subroutines in this file:
 *   void  constructSuballccdetail()
 *   void  closeFile(FILE* file);
 *   FILE* openFile(char* name, char* mode)
 *   FILE* openFilePrefix(char* extension, char* mode)
 *   FILE* openFileSuballccdetail(char* name, char* mode)
 *   void  removeSuballccdetail()
 *   void  showRoundSteps(char *message)
 *   void  suballerror(char *m1,char *m2, char *m3)
 */
/***************************************************************/
/*eject*/
/************************************************************
 *   constructSuballccdetail(): construct Suballcc detail directory
 ************************************************************/

void  constructSuballccdetail() {

  char cmnd[MAXLEN];
  char suballccdetail[MAX_DIRECTORY+MAX_ID];

  FILE *out;

/*  
 *  gParams.suballccdetaildir contains a terminating '/'
 *  to be consistent with Leibniz System convention
 */

  strcpy(suballccdetail,gParams.suballccdetaildir);

#ifdef UNIX

  sprintf(cmnd,"test -d %s",suballccdetail);
    
    if( system(cmnd)  == 0 ) {    
/*
 * directory exists already, clean it
 * after introduction of fake file TMPlsq76xi2uy3
 * so that rm command does not cause error message
 * for empty directory
 */
      out = openFileSuballccdetail("TMPlsq76xi2uy3TMPlsq76xi2uy3","w");
      closeFile(out); 
      sprintf(cmnd,"rm  %s*",suballccdetail);
      system(cmnd);
    } else {
/*
 * directory does not exist, create it
 */
      sprintf(cmnd,"mkdir  %s",suballccdetail);
      system(cmnd);
    }

#endif /*UNIX specification */

#ifdef WINDOWS

/* remove '\\' of directory specification */
  suballccdetail[strlen[suballccdetail]-1] = '\0';
  sprintf(cmnd, "IF EXIST %s. (del /f /q %s\\*) ELSE mkdir %s.",
		  suballccdetail, suballccdetail, suballccdetail);
  system(cmnd);

  #endif /* WINDOWS specification */

  return;
}
/*eject*/
/***************************************************************/
void closeFile(FILE* file) 
{
  fclose(file);
  gNumOpenFiles--;
  return; 
}
/***************************************************************/
FILE* openFile(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,"Error opening %s \n for %s. Stop.\n",
                  name, mode);
          suballerror(message,"openFile","101");
	}

        gNumOpenFiles++;	
	return out;
}
/****************************************************************/
FILE* openFilePrefix(char* extension, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,gParams.directory);
	strcat(file,gParams.prefix);
	strcat(file,extension);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,
            "Error opening %s \n for %s. Stop.\n", file, mode);
	  suballerror(message,"openFilePrefix","101");
	}
	
        gNumOpenFiles++;	
	return out;
}
/****************************************************************/
FILE* openFileSuballccdetail(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,gParams.suballccdetaildir);
	strcat(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,
              "Error opening %s \n for %s. Stop.\n", file, mode);
          suballerror(message,"openFileSuballccdetail","101");
	}
	
        gNumOpenFiles++;	
	return out;
}	
/*eject*/
/****************************************************
 * removeSuballccdetail(): remove Suballcc detail directory 
 ****************************************************/
void removeSuballccdetail() {

  char cmnd[MAXLEN];
  char suballccdetail[MAX_DIRECTORY+MAX_ID];

/*  
 *  gParams.suballccdetaildir contains a terminating '/'
 *  to be consistent with Leibniz System convention
 */

  strcpy(suballccdetail,gParams.suballccdetaildir);

#ifdef UNIX  

  sprintf(cmnd,"rm %s*",suballccdetail);
  system(cmnd);
  
  sprintf(cmnd,"rmdir %s",suballccdetail);
  system(cmnd);

#endif /* UNIX specification */

#ifdef WINDOWS

/*
 * rd /s /q suballccdetail
 */
  sprintf(cmnd, "rd /s /q %s", suballccdetail);
  system(cmnd);

#endif /* WINDOWS specification */

  return;
}
/*eject*/
/****************************************************
 * showRoundSteps(): show reduction processing steps 
 ****************************************************/
void showRoundSteps(char *message) {

  if (gShowRoundSteps == TRUE) {
    printf("%s",message);
  }
  fprintf(errfil,"%s",message);

  return;
}
/*eject*/
/***************************************************************
*  suballerror(): suballcc system error termination 
****************************************************************/
void suballerror(char *m1,char *m2, char *m3) {
/*
 */
  printf("%s\nStop\n",m1);
  fprintf(errfil,"%s\nStop\n",m1);

  printf("\n*******SUBALLCC SYSTEM ERROR*******\n");
  printf("ERROR IN %s  code %s\n",m2,m3);
  printf("**********************************\n");
  printf("For details, see error file suballcc.err\n");
/*
 */
  fprintf(errfil,"\n*******SUBALLCC SYSTEM ERROR*******\n");
  fprintf(errfil,"ERROR IN %s  code %s\n",m2,m3);
  fprintf(errfil,"**********************************\n");
  exit(1);

}
/* last record of util.c *******/

















