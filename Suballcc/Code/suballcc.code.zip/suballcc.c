/* first record of suballcc.c *****/
/*
 *   Leibniz System: Suballcc System
 *   Copyright 2011 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * ===================================================
 * Suballcc System - Callable Subgroup Version Suballcc
 * ===================================================
 *
 *  caution: 
 *   - parameters must have been obtained 
 *     (see readParamsFile() for required information)
 *   - errfil must have been opened (see suballccmain() program)
 *   - errfil must be closed after execution of suballcc
 *  caution: these conditions are not checked by the program 
 * -----------------------------------------------------------
 *  Leibniz programs used:
 *  Subcc: sub2cc
 *
 *  subroutines in this file:
 *  int suballcc()
 *  void doRounds()
 *  void initialize()
 *  void constructSuballccdetail()    
 *  void removeSuballccdetail()   
 * -----------------------------------------------------------
 */
#include "suballcc.h"
/***********************************************************/	
int suballcc() {

  char name[MAXLEN];

  /* initialize errorflag */
  errorflag = 0;

  /* initialize gNumOpenFiles */
  gNumOpenFiles = 0;

  /* target option 'tgt only' */
  if (gSelectTargetFile == TGTONLY) {
    /* execute subcc */
    showRoundSteps("Execute subcc with 'tgt only' option\n");
    if (Xsubcc() != 0) {
      suballerror("Error, execution of subcc with 'tgt only' option",
                  "suballcc","101");
    }    
    if (gNumOpenFiles != 0) {
      suballerror("mismatch of opened/closed files","suballcc","801");
    }  
    return errorflag;   
  }

  /* construct Suballccdetail directory */
  showRoundSteps("Construct Suballccdetail directory\n\n");
  constructSuballccdetail();

  /* initialize arrays, files, parameters */
  initialize();

  /* open output file */
  sprintf(name,"%sall",gFileExt.sub);
  suballfil = openFilePrefix(name, "w");

  /* do subgroup discovery rounds */
  doRounds();

  sprintf(name,"Output in file ./%s%sall\n\n",
               gParams.prefix,gFileExt.sub);
  showRoundSteps(name);
   
  /* close output file */
  closeFile(suballfil);

  /* if 'keep suballcc details directory' is not 
   * specified in lsqccparams.dat, then remove
   * suballcc detail directory
   */
  if (gKeepSuballccdetail == FALSE) {
    showRoundSteps("Remove Suballccdetail directory\n\n");
    removeSuballccdetail();
  }

  if (gNumOpenFiles != 0) {
    suballerror("mismatch of opened/closed files","suballcc","901");
  }
 
  return errorflag;
	
}

/* last record of suballcc.c *******/
    
