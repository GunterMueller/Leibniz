/* first record of util.c *****/
#include "suballcc.h"
#include "features.h" /* system version selection */
/**************************************************************/
/*
 * subroutines in this file:
 *   void initialize()
 *   void createLsqccParamsFile()
 *   void createLsqccParamsTargetFile()
 *   void transferAtsFile()  
 */
/***************************************************************/
/*eject*/
/************************************************************
 *   initialize(): initialize arrays, files
 ************************************************************/

void initialize() {

  /* define and store targets */

  if (gSelectTargetFile == NEWTGT) {
    /* create parameter file for target generation only */
    createLsqccParamsTargetFile();
    /* execute: subcc Suballdetaildir/lsqccparams.target.dat */   
    if (Xsubcc() != 0) {
      suballerror("Execution of subcc failed","initialize", "101");
    }
  }

  /* load target file into target[][]*/
  loadTargetFile();
  if (numTargets == 0) {
    suballerror("No targets specified","initialize","102");
  }

  /* create lsqccparams.dat in Suballccdetail directory */
  /* for iterative sub2cc execution */
  createLsqccParamsFile();

  /* if ALTERNATE test option is specified and no split option, */
  /* copy .ats file into Suballccdetail directory */
  if ((gSelectTestFile  == ALTERNATE) &&
      (gParams.sortSplitRatio == 0)) { 
    transferAtsFile();
  }

  return;

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  createLsqccParamsFile(): 
*    create lsqccparams.dat file for sub2cc
* --------------------------------------------------------
***************************************************************/
void createLsqccParamsFile() {

  char fileRec[MAXLEN]; 
  char name[MAXLEN];

  FILE *suballccParams;
  FILE *sub2ccParams;

  suballccParams = openFile(lsqccparamsname,"r");
  sub2ccParams = openFileSuballccdetail("lsqccparams.input.dat","w");

  while (fgets(fileRec,MAXLEN,suballccParams) != 0) { 
                                            /* begin while */
    if (strncmp(fileRec,"ENDATA",6) == 0) { 
      /* have copied all lines of lsqccparams file except
       * for ENDATA statement
       * complete file by adding statements
       */  

      /*************begin allcc section*************/
      sprintf(name,"begin allcc");
      fprintf(sub2ccParams,"%s\n",name);

      /* file name without extension */
      sprintf(name,
	      "file name without extension = input");
      fprintf(sub2ccParams,"%s\n",name);

      /* training/testing directory */
      sprintf(name,
	      "training/testing directory = %s",
              gParams.suballccdetaildir);
      fprintf(sub2ccParams,"%s\n",name);

      sprintf(name,"begin subcc");
      fprintf(sub2ccParams,"%s\n",name);

      /* specify option 'old tgt' */
      sprintf(name,
      "compute subgroups (new tgt, old tgt, tgt only) = old tgt");
      fprintf(sub2ccParams,"%s\n",name);

      /* ENDATA */
      sprintf(name,"ENDATA");
      fprintf(sub2ccParams,"%s\n",name);

      /* done with output file */
      closeFile(suballccParams);
      closeFile(sub2ccParams);
      return;
    } /* end if strncmp(fileRec,"ENDATA" */

    /* write fileRec into output file */
    fprintf(sub2ccParams,"%s",fileRec);

  } /* end while */  

  suballerror("Missing ENDATA record in lsqccparams.dat",
           "createLsqccParamsFile", "101");

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  createLsqccParamsTargetFile(): 
*    create lsqccparams.dat file for target definition by subcc
* --------------------------------------------------------
***************************************************************/
void createLsqccParamsTargetFile() {

  char fileRec[MAXLEN]; 
  char name[MAXLEN];

  FILE *suballccParams;
  FILE *subccParams;

  suballccParams = openFile(lsqccparamsname,"r");
  subccParams = 
     openFileSuballccdetail("lsqccparams.target.dat","w");

  while (fgets(fileRec,MAXLEN,suballccParams) != 0) { 
                                            /* begin while */
    if (strncmp(fileRec,"ENDATA",6) == 0) { 
      /* have copied all lines of lsqccparams file except
       * for ENDATA statement
       * complete file by adding statements
       */  

      /*************begin subcc section*************/
      sprintf(name,"begin subcc");
      fprintf(subccParams,"%s\n",name);

      /* specify option 'tgt only' */
      sprintf(name,
      "compute subgroups (new tgt, old tgt, tgt only) = tgt only");
      fprintf(subccParams,"%s\n",name);

      /* ENDATA */
      sprintf(name,"ENDATA");
      fprintf(subccParams,"%s\n",name);

      /* done with output file */
      closeFile(suballccParams);
      closeFile(subccParams);
      return;
    } /* end if strncmp(fileRec,"ENDATA" */

    /* write fileRec into output file */
    fprintf(subccParams,"%s",fileRec);

  } /* end while */  

  suballerror("Missing ENDATA record in lsqccparams.target.dat",
              "createLsqccParamsTargetFile", "101");

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  transferAtsFile(): 
*    transfer .ats file from current directory into
*    Suballdetail directory as input.ats
* --------------------------------------------------------
***************************************************************/
void transferAtsFile() {

  int endataCheckFlag = FALSE;

  char fileRec[MAXLEN]; 

  FILE *atsfil;
  FILE *inputatsfil;

  atsfil = openFilePrefix(gFileExt.ats, "r");
  inputatsfil = 
     openFileSuballccdetail("input.ats","w");

  /* get .ats file records */
  while (fgets(fileRec, MAXLEN, atsfil) != NULL) {

    fprintf(inputatsfil,"%s",fileRec);
		
    if (strncmp(fileRec, "ENDATA", 6) == 0 ||
                strncmp(fileRec, "ENDDATA", 7) == 0) {
      endataCheckFlag = TRUE;
      break;
    }
  }

  if (endataCheckFlag == FALSE) {
    suballerror("Missing ENDATA record in tgt file",
                "transferAtsFile","102");
		
  }
		
  closeFile(atsfil);
  closeFile(inputatsfil);

  return;

}

/* last record of initialize.c *********/
