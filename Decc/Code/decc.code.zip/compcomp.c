/*  first record of compcomp.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h" 
/*
 * **************************************************************
 *  module component composition 
 * 
 *  purpose:  composes components qblock and qblock+1 
 *            into one block.
 * 
 *    input:  problem in layer 1, with correct indices and counts
 *            ('*' means conditions tested in compos)
 *
 *            arrays assumed defined:
 *              - matrix data amatcl, amatrw
 *              - nrows, ncols, nblks
 *              - colnam, rownam, prbnam
 *              - matrix indices as follows:
 *        *         all columns j active (ciact(j) = 1)
 *        *         all rows i active  (riact(i) = 1)
 *                  remaining indices must be consistent 
 *                  with these assignments.
 *              - counts cnxxx, rnxxx 
 *        *     - all cost(j) must be .ge. 0 if optimz = 1
 *              - scale, idxcol, idxrow 
 *              - dlclop, dlrwop
 *              - lcllim, ucllim, lrwlim, urwlim
 *              - bdfxbl 
 *              - logrge 
 *              - optimz 
 *              - qblock 
 *
 *     additional input requirements as well as the output 
 *     are given with each subroutine of this module.
 *
 *     calling sequence:
 *
 *       compos    composes components qblock and qblock+1
 *
 * **************************************************************
 * 
 * 
 * **************************************************************
 *  subroutine compos 
 * 
 *  purpose:  composes components qblock and qblock+1 
 *            into one block.
 *
 *    input:  as specified in module summary
 *
 *   output:  problem with new component qblock replacing 
 *            old qblock and qblock + 1.  
 *            all columns of new block qblock are
 *            free, and solution algorithm for that new block 
 *            is as yet undecided.  
 *            twosat(new qblock) = -1 and bdfxbl(new block) = 0. 
 * ****************************************************************
 * 
 */
void compos() {
/*
 */
void mcfxfr();
/*
 */
  static long qp1,j,i,q;
/*
 *  check that qblock is in appropriate range
 */
  if ((qblock<=0)||
      (qblock>=nblks)) {
    error(" compos ","   82   ");
  }
  qp1=qblock+1;
/*
 *  shift block indices
 */
  for(j=lcllim_(qp1); j<=ncols; j++)  {
    ciblk_(j)=ciblk_(j)-1;
  }
  for(i=lrwlim_(qp1); i<=nrows; i++)  {
    riblk_(i)=riblk_(i)-1;
  }
/*
 *  revise block limits for qblock
 */
  ucllim_(qblock)=ucllim_(qp1);
  urwlim_(qblock)=urwlim_(qp1);
/*
 *  move fixed columns of new qblock to free
 */
  for(j=lcllim_(qblock); j<=ucllim_(qblock); j++)  {
    if (cifix_(j)!=0) {
      mcfxfr(j);
    }
  }
/*
 *  indicate that no solution algorithm has as yet been 
 *  selected for new qblock; save logrge(qp1) in logrge(qblock)
 */
  twosat_(qblock)=-1;
  bdfxbl_(qblock)=0;
  logrge_(qblock)=logrge_(qp1);
/*
 *  if blocks exist beyond new qblock, shift information
 */
  if (qp1<nblks) {
    for(q=qp1; q<=nblks-1; q++)  {
/*
 *  shift block limits
 */
      lcllim_(q)=lcllim_(q+1);
      ucllim_(q)=ucllim_(q+1);
      lrwlim_(q)=lrwlim_(q+1);
      urwlim_(q)=urwlim_(q+1);
/*
 *  shift fixed column count
 */
      bdfxbl_(q)=bdfxbl_(q+1);
/*
 *  shift indicator for solution algorithm
 */
      twosat_(q)=twosat_(q+1);
/*
 *  shift logrge data
 */
      logrge_(q)=logrge_(q+1);
    }
  }
/*
 *  change number of blocks
 */
  nblks=nblks-1;
  return;
}
/*  last record of compcomp.c****** */
