/*  first record of xpci.c***** */
/*
 * this is a linear programming system in C based on the xmp
 * linear programming system developed originally by r. marsten.
 * A number of changes have been made to accommodate the
 * C programming language and to obtain stable performance.
 * 
 *    This file contains the following routines:
 *
 *  getcom,   putlen,
 *  la05ad,   la05bd,   la05cd,   la05ed,   mc20ad,   mc20bd,   xaddaj,
 *  xaddub,   xgetaj,   xgetub,   xdata1,   xdata2,   xdata3,   xdata4,
 *  fcand,     fdchq,    xdchr,    xdph2,    xdual,   xbcomp,   xbredu,
 *  xbtran,   xcheck,   xchuzr,     xdot,    xfact,    xfeas,   xftran,
 *  xla05x,     xlog,   xphas2,   xpivot,   xpriml,   xprint,   xprior,
 *  xslack,   xstart,    xstop,   xupdat,    xupdx,   xzcomp,    xmaps.
 *
 * Warning: To compile, keep them all in the same file !! 
 *
 */

/*
 *  Include files
 */
#include <stdio.h>
#include <stdlib.h>

/*
 *  Macro definitions
 */
#define TRUE  (1)
#define FALSE (0)

#define abs(x)   ((x) >= 0 ? (x) : -(x))
#define dabs(x)  (double)abs(x)
#define max(a,b) ((a) >= (b) ? (a) : (b))

/*
 *  Common Blocks (visible ONLY to the routines of this file)
 */
/*>>> la05dd <<<*/
static double smallr;
static FILE *lp;
static long lenl, lenu, ncp, lrow, lcol;

/*>>> xmplen <<<*/
static long leni, lenmi, lenmr, lenr;

/*>>> xmpcom <<<*/
static double big, small, zl, zlc, eps1, eps2, eps3, eps4;

/*>>> xmpfil <<<*/
/* activate file iobsf and output statements */
/* if output desired */
/* static FILE *iobsf; */ 

/*
 *  Table of constant values
 */
static long zero = 0;
static long one = 1;

/* ============================================================ getcom === 
 *  gets values of variables of xmp common block xmpcom 
 *
 *  parameters: gbig = big of xmp 
 *              gsmall = small of xmp 
 *              gzl = zl of xmp 
 *              gzlc = zlc of xmp 
 *              geps1 = eps1 of xmp 
 *              geps2 = eps2 of xmp 
 *              geps3 = eps3 of xmp 
 *              geps4 = eps4 of xmp 
 */
void getcom(gbig, gsmall, gzl, gzlc, geps1, geps2, geps3, geps4)
double *gbig, *gsmall, *gzl, *gzlc;
double *geps1, *geps2, *geps3, *geps4;
{
/*
 *  get values of variables of xmp common block xmpcom 
 */
    *gbig = big;
    *gsmall = small;
    *gzl = zl;
    *gzlc = zlc;
    *geps1 = eps1;
    *geps2 = eps2;
    *geps3 = eps3;
    *geps4 = eps4;

    return;
}                                /* getcom */

/* ============================================================ putlen === 
 *  put values into variables of xmp common block xmplen
 *
 *  parameters: pleni = leni of xmp
 *              plenmi = lenmi of xmp
 *              plenmr = lenmr of xmp
 *              plenr = lenr of xmp
 */
void putlen(pleni, plenmi, plenmr, plenr)
long *pleni, *plenmi, *plenmr, *plenr;
{
/*
 *  put values into variables of xmp common block xmplen
 */
    leni  = *pleni;
    lenmi = *plenmi;
    lenmr = *plenmr;
    lenr  = *plenr;

    return;
}                                /* putlen */

/* ============================================================ la05ad === 
 * standard first version of the la05 routines: 
 * double precision and full-word integer. 
 *
 * warning:  don't try to use half-words for the ip array. 
 *           you won't be able to have more than 32,000 non-zeros 
 *           in the basis factors! 
 * could use half-words: 
 * ip(i,1),ip(i,2) point to the start of row/col i. 
 * iw(i,1),iw(i,2) hold the number of non-zeros in row/col i. 
 * during the main body of this subroutine the vectors iw(.,3),iw(.,5), 
 *     iw(.,7) are used to hold doubly linked lists of rows that have 
 *     not been pivotal and have equal numbers of non-zeros. 
 * iw(.,4),iw(.,6),iw(.,8) hold similar lists for the columns. 
 * iw(i,3),iw(i,4) hold first row/column to have i non-zeros 
 *     or zero if there are none. 
 * iw(i,5), iw(i,6) hold row/col number of row/col prior to row/col i 
 *     in its list, or zero if none. 
 * iw(i,7), iw(i,8) hold row/col number of row/col after row/col i 
 *     in its list, or zero if none. 
 * for rows/cols that have been pivotal iw(i,5),iw(i,6) hold negation of
 *     position of row/col i in the pivotal ordering. 
 */
void la05ad(a, ind, nz, ia, n, ip, iw, w, g, u)
double *a;
long   *ind, *nz, *ia, *n, *ip, *iw;
double *w, *g, *u;
{
/* 
 *  Initialized data 
 */
  static char rc[1 * 2 * 3 + 1] = "rcoowl";
  static float eps = (float) 2.3e-16;

/* 
 *  f2c generated locals 
 */
  long   ip_dim1, ip_offset, ind_dim1, ind_offset, iw_dim1, iw_offset;
  long   i__1, i__2, i__3, i__4, i__5;
  double d__1, d__2, d__3;

/* 
 *  Local variables 
*/
  double amax;
  long   i, j, k, l;
  long   jcost, kcost, k1, k2;
  double am;
  long   kc, nc, ii;
  double au;
  long   kl, in, kk, ir, kp, kr, kj, jp, il, kq, ks, kn, idummy, klc;
  long   kpc, mcp, kpl, ipp, krl, nzc, knp, ipv;

  static char *erm = "error return from la05cd because";

  void mc20ad(), la05ed();

/* 
 *  Parameter adjustments (Fortran -> C) 
 */
  --w;
  iw_dim1 = *n;
  iw_offset = iw_dim1 + 1;
  iw -= iw_offset;
  ip_dim1 = *n;
  ip_offset = ip_dim1 + 1;
  ip -= ip_offset;
  ind_dim1 = *ia;
  ind_offset = ind_dim1 + 1;
  ind -= ind_offset;
  --a;

/* ------------------- Function body ------------------- */

/*
 * statements below eliminate compiler warning messages
 * about unitialized values
 */
  kr = 0;
  kj = 0;
  jp = 0;
  ipp = 0;
/* end of statements to eliminate warning messages */

/* 
 *  eps is the relative accuracy of floating-point computation 
 */
  if (*u > 1.) *u = (float) 1.;
  if (*u < eps) *u = eps;
  if (*n < 1) goto L520;
  *g = (float) 0.;
  for (i = 1; i <= *n; ++i) {
    w[i] = (float) 0.;
    for (j = 1; j <= 5; ++j) iw[i + j * iw_dim1] = 0;
  }

/* 
 *  flush out small entries, count elements in rows and columns 
 */
  l = 1;
  lenu = *nz;
  i__1 = *nz;
  for (idummy = 1; idummy <= i__1; ++idummy) {
    if (l > lenu) goto L25;
    i__2 = lenu;
    for (k = l; k <= i__2; ++k) {
      if ((d__1 = a[k], abs(d__1)) <= smallr) goto L15;
      i = ind[k + ind_dim1];
      j = ind[k + (ind_dim1 << 1)];
/* 
 *  Computing MAX 
 */
      d__2 = (d__1 = a[k], abs(d__1));
      *g = max(d__2, *g);
      if (i < 1 || i > *n) goto L540;
      if (j < 1 || j > *n) goto L540;
      ++iw[i + iw_dim1];
      ++iw[j + (iw_dim1 << 1)];
    }
    goto L25;

L15:
    l = k;
    a[l] = a[lenu];
    ind[l + ind_dim1] = ind[lenu + ind_dim1];
    ind[l + (ind_dim1 << 1)] = ind[lenu + (ind_dim1 << 1)];
    --lenu;
  }

L25:
  lenl = 0;
  lrow = lenu;
  lcol = lrow;
/* 
 *  mcp is the maximum number of compresses permitted before an
 *  error return results. 
 */
/* 
 *  Computing MAX 
 */
  i__1 = *n / 10;
  mcp = max(i__1, 20);
  ncp = 0;
/* 
 *  check for null row or column and initialize ip(i,2) to point
 *  just beyond where the last component of column i of a will
 *  be stored. 
 */
  k = 1;
  for (ir = 1; ir <= *n; ++ir) {
    k += iw[ir + (iw_dim1 << 1)];
    ip[ir + (ip_dim1 << 1)] = k;
    for (l = 1; l <= 2; ++l)
      if (iw[ir + l * iw_dim1] <= 0) goto L580;
  }
/* 
 *  reorder by rows 
 */
  mc20ad(n, &lenu, &a[1], &ind[(ind_dim1 << 1) + 1], &ip[ip_offset], 
         &ind[ind_dim1 + 1], &zero);
/* 
 *  check for double entries while using the newly constructed
 *  row file to construct the column file. note that by putting
 *  the entries in backwards and decreasing ip(j,2) each time it
 *  is used we automatically leave it pointing to the first element. 
 */
  kl = lenu;
  for (ii = 1; ii <= *n; ++ii) {
    ir = *n + 1 - ii;
    kp = ip[ir + ip_dim1];
    i__2 = kl;
    for (k = kp; k <= i__2; ++k) {
      j = ind[k + (ind_dim1 << 1)];
      if (iw[j + iw_dim1 * 5] == ir) goto L500;
      iw[j + iw_dim1 * 5] = ir;
      kr = ip[j + (ip_dim1 << 1)] - 1;
      ip[j + (ip_dim1 << 1)] = kr;
      ind[kr + ind_dim1] = ir;
    }
    kl = kp - 1;
  }
/* 
 *  set up linked lists of rows and cols with equal numbers of non-zeros.
 */
  for (l = 1; l <= 2; ++l) {
    for (i = 1; i <= *n; ++i) {
      *nz = iw[i + l * iw_dim1];
      in = iw[*nz + (l + 2) * iw_dim1];
      iw[*nz + (l + 2) * iw_dim1] = i;
      iw[i + (l + 6) * iw_dim1] = in;
      iw[i + (l + 4) * iw_dim1] = 0;
      if (in != 0) iw[in + (l + 4) * iw_dim1] = i;
    }
  }
/*
 *  start of main elimination loop. 
 */
  for (ipv = 1; ipv <= *n; ++ipv) {
/* 
 *  find pivot. jcost is markowitz cost of cheapest pivot found so far,
 *  which is in row ipp and column jp. 
 */
    jcost = *n * *n;
/* 
 *  loop on length of column to be searched 
 */
    for (*nz = 1; *nz <= *n; ++(*nz)) {
/* 
 *  Computing 2nd power 
 */
      i__3 = *nz - 1;
      if (jcost <= i__3 * i__3) goto L183;
      j = iw[*nz + (iw_dim1 << 2)];
/* 
 *  search columns with nz non-zeros. 
 */
      i__3 = *n;
      for (idummy = 1; idummy <= i__3; ++idummy) {
	if (j <= 0) goto L133;
	kp = ip[j + (ip_dim1 << 1)];
	kl = kp + iw[j + (iw_dim1 << 1)] - 1;
	i__4 = kl;
	for (k = kp; k <= i__4; ++k) {
	  i = ind[k + ind_dim1];
	  kcost = (*nz - 1) * (iw[i + iw_dim1] - 1);
	  if (kcost >= jcost) continue;
	  if (*nz == 1) goto L125;
/* 
 * find largest element in row of potential pivot. 
 */
	  amax = (float) 0.;
	  k1 = ip[i + ip_dim1];
	  k2 = iw[i + iw_dim1] + k1 - 1;
	  i__5 = k2;
	  for (kk = k1; kk <= i__5; ++kk) {
/* 
 *  Computing MAX 
 */
	    d__2 = amax, d__3 = (d__1 = a[kk], abs(d__1));
	    amax = max(d__2, d__3);
	    if (ind[kk + (ind_dim1 << 1)] == j) kj = kk;
	  }
/*
 *  perform stability test. 
 */
	  if ((d__1 = a[kj], abs(d__1)) < amax * *u) continue;

L125:
	  jcost = kcost;
	  ipp = i;
	  jp = j;
/*
 *  Computing 2nd power 
 */
	  i__5 = *nz - 1;
	  if (jcost <= i__5 * i__5) goto L183;
	}
	j = iw[j + (iw_dim1 << 3)];
      }

L133:
/*
 *  search rows with nz non-zeros. 
 */
      i = iw[*nz + iw_dim1 * 3];
      i__3 = *n;
      for (idummy = 1; idummy <= i__3; ++idummy) {
	if (i <= 0) break;
	amax = (float) 0.;
	kp = ip[i + ip_dim1];
	kl = kp + iw[i + iw_dim1] - 1;
/*
 *  find largest element in the row 
 */
	i__4 = kl;
	for (k = kp; k <= i__4; ++k) {
/*
 *  Computing MAX 
 */
	  d__2 = (d__1 = a[k], abs(d__1));
	  amax = max(d__2, amax);
	}
	au = amax * *u;
	i__4 = kl;
	for (k = kp; k <= i__4; ++k) {
/*
 *  perform stability test. 
 */
	  if ((d__1 = a[k], abs(d__1)) < au) continue;
	  j = ind[k + (ind_dim1 << 1)];
	  kcost = (*nz - 1) * (iw[j + (iw_dim1 << 1)] - 1);
	  if (kcost >= jcost) continue;
	  jcost = kcost;
	  ipp = i;
	  jp = j;
/*
 *  Computing 2nd power 
 */
	  i__5 = *nz - 1;
	  if (jcost <= i__5 * i__5) goto L183;
	}
	i = iw[i + iw_dim1 * 7];
      }
    }

L183:
/*
 *  pivot found.
 *  remove rows and columns involved in elimination from ordering vectors. 
 */
    kp = ip[jp + (ip_dim1 << 1)];
    kl = iw[jp + (iw_dim1 << 1)] + kp - 1;
    for (l = 1; l <= 2; ++l) {
      i__2 = kl;
      for (k = kp; k <= i__2; ++k) {
	i = ind[k + l * ind_dim1];
	il = iw[i + (l + 4) * iw_dim1];
	in = iw[i + (l + 6) * iw_dim1];
	if (il == 0) goto L185;
	iw[il + (l + 6) * iw_dim1] = in;
	goto L190;

L185:
	*nz = iw[i + l * iw_dim1];
	iw[*nz + (l + 2) * iw_dim1] = in;

L190:
	if (in > 0) iw[in + (l + 4) * iw_dim1] = il;
      }
      kp = ip[ipp + ip_dim1];
      kl = kp + iw[ipp + iw_dim1] - 1;
    }
/*
 *  store pivot 
 */
    iw[ipp + iw_dim1 * 5] = -ipv;
    iw[jp + iw_dim1 * 6] = -ipv;
/*
 *  eliminate pivotal row from column file and find pivot in row file.
 */
    i__2 = kl;
    for (k = kp; k <= i__2; ++k) {
      j = ind[k + (ind_dim1 << 1)];
      kpc = ip[j + (ip_dim1 << 1)];
      --iw[j + (iw_dim1 << 1)];
      klc = kpc + iw[j + (iw_dim1 << 1)];
      i__3 = klc;
      for (kc = kpc; kc <= i__3; ++kc)
	if (ipp == ind[kc + ind_dim1]) goto L216;

L216:
      ind[kc + ind_dim1] = ind[klc + ind_dim1];
      ind[klc + ind_dim1] = 0;
      if (j == jp) kr = k;
    }
/*
 *  bring pivot to front of pivotal row. 
 */
    au = a[kr];
    a[kr] = a[kp];
    a[kp] = au;
    ind[kr + (ind_dim1 << 1)] = ind[kp + (ind_dim1 << 1)];
    ind[kp + (ind_dim1 << 1)] = jp;
/*
 *  perform elimination itself, looping on non-zeros in pivot column.
 */
    nzc = iw[jp + (iw_dim1 << 1)];
    if (nzc == 0) goto L468;
    i__2 = nzc;
    for (nc = 1; nc <= i__2; ++nc) {
      kc = ip[jp + (ip_dim1 << 1)] + nc - 1;
      ir = ind[kc + ind_dim1];
/*
 *  search non-pivot row for element to be eliminated. 
 */
      kr = ip[ir + ip_dim1];
      krl = kr + iw[ir + iw_dim1] - 1;
      i__3 = krl;
      for (knp = kr; knp <= i__3; ++knp)
	if (jp == ind[knp + (ind_dim1 << 1)]) goto L300;

L300:
/*
 *  bring element to be eliminated to front of its row. 
 */
      am = a[knp];
      a[knp] = a[kr];
      a[kr] = am;
      ind[knp + (ind_dim1 << 1)] = ind[kr + (ind_dim1 << 1)];
      ind[kr + (ind_dim1 << 1)] = jp;
      am = -a[kr] / a[kp];
/*
 *  compress row file unless it is certain that there is room for new row. 
 */
      if (lrow + iw[ir + iw_dim1] + iw[ipp + iw_dim1] + lenl <= *ia) goto L340;
      if (ncp >= mcp ||
	  lenu + iw[ir + iw_dim1] + iw[ipp + iw_dim1] + lenl > *ia)
	goto L600;
      la05ed(&a[1], &ind[(ind_dim1 << 1) + 1], &ip[ip_offset], n, 
             &iw[iw_offset], ia, &one);
      kp = ip[ipp + ip_dim1];
      kr = ip[ir + ip_dim1];

L340:
      krl = kr + iw[ir + iw_dim1] - 1;
      kq = kp + 1;
      kpl = kp + iw[ipp + iw_dim1] - 1;
/*
 *  place pivot row (excluding pivot itself) in w. 
 */
      if (kq > kpl) goto L350;
      i__3 = kpl;
      for (k = kq; k <= i__3; ++k) {
	j = ind[k + (ind_dim1 << 1)];
	w[j] = a[k];
      }

L350:
      ip[ir + ip_dim1] = lrow + 1;
/*
 *  transfer modified elements. 
 */
      ind[kr + (ind_dim1 << 1)] = 0;
      ++kr;
      if (kr > krl) goto L380;
      i__3 = krl;
      for (ks = kr; ks <= i__3; ++ks) {
	j = ind[ks + (ind_dim1 << 1)];
	au = a[ks] + am * w[j];
	ind[ks + (ind_dim1 << 1)] = 0;
/*
 *  if element is very small remove it from u. 
 */
	if (abs(au) <= smallr) goto L365;
/*
 *  Computing MAX 
 */
	d__1 = *g, d__2 = abs(au);
	*g = max(d__1, d__2);
	++lrow;
	a[lrow] = au;
	ind[lrow + (ind_dim1 << 1)] = j;
	goto L370;

L365:
	--lenu;
/*
 *  remove element from col file. 
 */
	k = ip[j + (ip_dim1 << 1)];
	kl = k + iw[j + (iw_dim1 << 1)] - 1;
	iw[j + (iw_dim1 << 1)] = kl - k;
	i__4 = kl;
	for (kk = k; kk <= i__4; ++kk)
	  if (ind[kk + ind_dim1] == ir) goto L367;

L367:
	ind[kk + ind_dim1] = ind[kl + ind_dim1];
	ind[kl + ind_dim1] = 0;

L370:
	w[j] = (float) 0.;
      }

L380:
/*
 *  scan pivot row for fills. 
 */
      if (kq > kpl) goto L435;
      i__3 = kpl;
      for (ks = kq; ks <= i__3; ++ks) {
	j = ind[ks + (ind_dim1 << 1)];
	au = am * w[j];
	if (abs(au) <= smallr) goto L430;
	++lrow;
	a[lrow] = au;
	ind[lrow + (ind_dim1 << 1)] = j;
	++lenu;
/* 
 *  create fill in column file. 
 */
	*nz = iw[j + (iw_dim1 << 1)];
	k = ip[j + (ip_dim1 << 1)];
	kl = k + *nz - 1;
/*
 *  if possible place new element at end of present entry. 
 */
	if (kl != lcol) goto L390;
	if (lcol + lenl >= *ia) goto L400;
	++lcol;
	goto L395;

L390:
	if (ind[kl + 1 + ind_dim1] != 0) goto L400;

L395:
	ind[kl + 1 + ind_dim1] = ir;
	goto L425;

L400:  /* new entry has to be created. */
	if (lcol + lenl + *nz + 1 < *ia) goto L410;
/*
 *  compress column file if there is not room for new entry. 
 */
	if (ncp >= mcp || lenu + lenl + *nz + 1 >= *ia) goto L600;
	la05ed(&a[1], &ind[ind_offset], &ip[(ip_dim1 << 1) + 1], n, &
	       iw[(iw_dim1 << 1) + 1], ia, &zero);
	k = ip[j + (ip_dim1 << 1)];
	kl = k + *nz - 1;

L410:
/*
 *  transfer old entry into new. 
 */
	ip[j + (ip_dim1 << 1)] = lcol + 1;
	i__4 = kl;
	for (kk = k; kk <= i__4; ++kk) {
	  ++lcol;
	  ind[lcol + ind_dim1] = ind[kk + ind_dim1];
	  ind[kk + ind_dim1] = 0;
	}
/*
 *  add new element. 
 */
	++lcol;
	ind[lcol + ind_dim1] = ir;

L425:
/*
 *  Computing MAX 
 */
	d__1 = *g, d__2 = abs(au);
	*g = max(d__1, d__2);
	iw[j + (iw_dim1 << 1)] = *nz + 1;

L430:
	w[j] = (float) 0.;
      }

L435:
      iw[ir + iw_dim1] = lrow + 1 - ip[ir + ip_dim1];
/*
 *  store multiplier 
 */
      if (lenl + lcol + 1 <= *ia) goto L450;
/*
 *  compress col file if necessary. 
 */
      if (ncp >= mcp) goto L600;
      la05ed(&a[1], &ind[ind_offset], &ip[(ip_dim1 << 1) + 1], n, 
             &iw[(iw_dim1 << 1) + 1], ia, &zero);

L450:
      k = *ia - lenl;
      ++lenl;
      a[k] = am;
      ind[k + ind_dim1] = ipp;
      ind[k + (ind_dim1 << 1)] = ir;
      --lenu;
    }

L468:
/*
 *  insert rows and columns involved in elimination in linked lists
 *   of equal numbers of non-zeros. 
 */
    k1 = ip[jp + (ip_dim1 << 1)];
    k2 = iw[jp + (iw_dim1 << 1)] + k1 - 1;
    iw[jp + (iw_dim1 << 1)] = 0;
    for (l = 1; l <= 2; ++l) {
      if (k2 < k1) goto L475;
      i__2 = k2;
      for (k = k1; k <= i__2; ++k) {
	ir = ind[k + l * ind_dim1];
	if (l == 1) ind[k + l * ind_dim1] = 0;
	*nz = iw[ir + l * iw_dim1];
	if (*nz <= 0) goto L630;
	in = iw[*nz + (l + 2) * iw_dim1];
	iw[ir + (l + 6) * iw_dim1] = in;
	iw[ir + (l + 4) * iw_dim1] = 0;
	iw[*nz + (l + 2) * iw_dim1] = ir;
	if (in != 0) iw[in + (l + 4) * iw_dim1] = ir;
      }

L475:
      k1 = ip[ipp + ip_dim1] + 1;
      k2 = iw[ipp + iw_dim1] + k1 - 2;
    }
  }
/*
 *  reset column file to refer to u and store row/col numbers in 
 *  pivotal order in iw(.,3),iw(.,4) 
 */
  for (i = 1; i <= *n; ++i) {
    j = -iw[i + iw_dim1 * 5];
    iw[j + iw_dim1 * 3] = i;
    j = -iw[i + iw_dim1 * 6];
    iw[j + (iw_dim1 << 2)] = i;
    iw[i + (iw_dim1 << 1)] = 0;
  }
  for (i = 1; i <= *n; ++i) {
    kp = ip[i + ip_dim1];
    kl = iw[i + iw_dim1] + kp - 1;
    i__2 = kl;
    for (k = kp; k <= i__2; ++k) {
      j = ind[k + (ind_dim1 << 1)];
      ++iw[j + (iw_dim1 << 1)];
    }
  }
  k = 1;
  for (i = 1; i <= *n; ++i) {
    k += iw[i + (iw_dim1 << 1)];
    ip[i + (ip_dim1 << 1)] = k;
  }
  lcol = k - 1;
  for (ii = 1; ii <= *n; ++ii) {
    i = iw[ii + iw_dim1 * 3];
    kp = ip[i + ip_dim1];
    kl = iw[i + iw_dim1] + kp - 1;
    i__1 = kl;
    for (k = kp; k <= i__1; ++k) {
      j = ind[k + (ind_dim1 << 1)];
      kn = ip[j + (ip_dim1 << 1)] - 1;
      ip[j + (ip_dim1 << 1)] = kn;
      ind[kn + ind_dim1] = i;
    }
  }
  return;

L500:
/*
 *  the following instructions implement the failure exits. 
 */
  if (lp != 0)
    fprintf(lp,
       "\n\n%s there is more than one entry in row %ld and column %ld\n",
	    erm, ir, j);
  *g = (float) -4.;
  return;

L520:
  if (lp != 0) fprintf(lp, "\n\n%s n is not positive\n", erm);
  *g = (float) -1.;
  return;

L540:
  if (lp != 0) fprintf(lp, "\n\n%s element %ld is in row %ld and column %ld\n",
	              erm, k, i, j);
  *g = (float) -3.;
  return;

L580:
  if (lp != 0) fprintf(lp, "\n\n%s %c%c%c %ld  has no elements\n", 
                      erm, rc[l - 1], rc[l + 1], rc[l + 3], ir);
  *g = (float) -2.;
  return;

L600:
  if (lp != 0) fprintf(lp, "\n\n%s ia is too small\n", erm);
  *g = (float) -7.;
  return;

L630:
  ++ipv;
  iw[ipv + iw_dim1] = ir;
  for (i = 1; i <= *n; ++i) {
    ii = -iw[i + (l + 4) * iw_dim1];
    if (ii > 0) iw[ii + iw_dim1] = i;
  }
  if (lp != 0) {
    fprintf(lp, "error return from la05ad because the following ");
    fprintf(lp, "%c%c%cs are dependent\n", rc[l - 1], rc[l + 1], rc[l + 3]);
    for (i = 1, i__1 = 1; i <= ipv; ++i, ++i__1) {
      fprintf(lp, "%5ld", iw[i + iw_dim1]);
      if (!(i__1 % 20))	fprintf(lp, "\n");
    }
    if ((i__1 - 1) % 20) fprintf(lp, "\n");
  }
  *g = (float) -5.;
  return;
}				/* la05ad */

/* ============================================================ la05bd === 
 * could use half-words: 
 * warning:  don't try to use half-words for the ip array. 
 *           you won't be able to have more than 32,000 non-zeros 
 *           in the basis factors! 
 * ip(i,1),ip(i,2) point to start of row/column i of u. 
 * iw(i,1),iw(i,2) are lengths of row/col i of u. 
 * iw(.,3),iw(.,4) hold row/col numbers in pivotal order. 
 */
void la05bd(a, ind, ia, n, ip, iw, w, g, b, trans)
double *a;
long *ind, *ia, *n, *ip, *iw;
double *w, *g, *b;
long *trans;
{
/*
 *  f2c generated locals
 */
  long ind_dim1, ind_offset, iw_dim1, iw_offset, ip_dim1, ip_offset,
   i__1, i__2, i__3;
  double d__1;

/*
 *  Local variables
 */
  long i, j, k, l1, k2, n1;
  double am;
  long ii, kk, kl, kp, nz, kpc, kll;

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --b;
  --w;
  iw_dim1 = *n;
  iw_offset = iw_dim1 + 1;
  iw -= iw_offset;
  ip_dim1 = *n;
  ip_offset = ip_dim1 + 1;
  ip -= ip_offset;
  ind_dim1 = *ia;
  ind_offset = ind_dim1 + 1;
  ind -= ind_offset;
  --a;

/* ------------------- Function body ------------------- */
  if (*g < 0.) goto L400;
  kll = *ia - lenl + 1;
  if (*trans) goto L300;
/*
 *  multiply vector by inverse of l 
 */
  if (lenl <= 0) goto L112;
  l1 = *ia + 1;
  i__1 = lenl;
  for (kk = 1; kk <= i__1; ++kk) {
    k = l1 - kk;
    i = ind[k + ind_dim1];
    if ((d__1 = b[i], abs(d__1)) < smallr) continue;
    j = ind[k + (ind_dim1 << 1)];
    b[j] += a[k] * b[i];
  }

L112:
  for (i = 1; i <= *n; ++i) {
    w[i] = b[i];
    b[i] = (float) 0.;
  }
/*
 *  multiply vector by inverse of u 
 */
  n1 = *n + 1;
  for (ii = 1; ii <= *n; ++ii) {
    i = n1 - ii;
    i = iw[i + iw_dim1 * 3];
    am = w[i];
    kp = ip[i + ip_dim1];
    if (kp > 0) goto L130;
    kp = -kp;
    ip[i + ip_dim1] = kp;
    nz = iw[i + iw_dim1];
    kl = kp - 1 + nz;
    k2 = kp + 1;
    i__2 = kl;
    for (k = k2; k <= i__2; ++k) {
      j = ind[k + (ind_dim1 << 1)];
      am -= a[k] * b[j];
    }

L130:
    if (abs(am) < smallr) continue;
    j = ind[kp + (ind_dim1 << 1)];
    b[j] = am / a[kp];
    kpc = ip[j + (ip_dim1 << 1)];
    kl = iw[j + (iw_dim1 << 1)] + kpc - 1;
    if (kl == kpc) continue;
    k2 = kpc + 1;
    i__2 = kl;
    for (k = k2; k <= i__2; ++k) {
      i = ind[k + ind_dim1];
      ip[i + ip_dim1] = -(i__3 = ip[i + ip_dim1], abs(i__3));
    }
  }
  goto L500;

L300:       /* multiply vector by inverse of transpose of u */
  for (i = 1; i <= *n; ++i) {
    w[i] = b[i];
    b[i] = (float) 0.;
  }
  for (ii = 1; ii <= *n; ++ii) {
    i = iw[ii + (iw_dim1 << 2)];
    am = w[i];
    if (abs(am) < smallr) continue;
    j = iw[ii + iw_dim1 * 3];
    kp = ip[j + ip_dim1];
    am /= a[kp];
    b[j] = am;
    kl = iw[j + iw_dim1] + kp - 1;
    if (kp == kl) continue;
    k2 = kp + 1;
    i__3 = kl;
    for (k = k2; k <= i__3; ++k) {
      i = ind[k + (ind_dim1 << 1)];
      w[i] -= am * a[k];
    }
  }
/*
 *  multiply vector by inverse of transpose of l 
 */
  if (kll > *ia) goto L500;
  i__1 = *ia;
  for (k = kll; k <= i__1; ++k) {
    j = ind[k + (ind_dim1 << 1)];
    if ((d__1 = b[j], abs(d__1)) < smallr) continue;
    i = ind[k + ind_dim1];
    b[i] += a[k] * b[j];
  }
  goto L500;

L400:
  if (lp != 0) {
    fprintf(lp, "\n\n error return from la05bd because earlier entry ");
    fprintf(lp, "gave error return");
  }

L500:
  for (ii = 1; ii <= *n; ++ii)
    if ((d__1 = b[ii], abs(d__1)) < smallr) b[ii] = (float) 0.;
  return;
}				/* la05bd */

/* ============================================================ la05cd === 
 * could use half-words: 
 * warning:  don't try to use half-words for the ip array. 
 *           you won't be able to have more than 32,000 non-zeros 
 *           in the basis factors! 
 */
void la05cd(a, ind, ia, n, ip, iw, w, g, u, mm)
double *a;
long *ind, *ia, *n, *ip, *iw;
double *w, *g, *u;
long *mm;
{
/*
 *  f2c generated locals
 */
  long ind_dim1, ind_offset, iw_dim1, iw_offset, ip_dim1, ip_offset,
   i__1, i__2, i__3;
  double d__1, d__2;

/*
 *  Local variables
 */
  long last, last1, last2, i;
  long k, j, m, l, index, m1;
  double am;
  long ii, ij, kj;
  double au;
  long jm, im, kp, kl, kr, km, is, in, ir, jp, kq, ks, kk, nz, mcp,
   kpl, krl, ins, jns, knp, ipp;

  static char *erm = "error return from la05cd because";

  void la05ed();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --w;
  iw_dim1 = *n;
  iw_offset = iw_dim1 + 1;
  iw -= iw_offset;
  ip_dim1 = *n;
  ip_offset = ip_dim1 + 1;
  ip -= ip_offset;
  ind_dim1 = *ia;
  ind_offset = ind_dim1 + 1;
  ind -= ind_offset;
  --a;

/* ------------------- Function body ------------------- */

/*
 * statements below eliminate compiler warning messages
 * about unitialized values
 */
  last = 0;
  m = 0;
  knp = 0;
/* end of statements to eliminate warning messages */

  if (*g < 0.) goto L640;
  jm = *mm;
/*
 *  mcp limits the value of ncp permitted before an error return results.
 */
  mcp = ncp + 20;
/*
 *  remove old column 
 */
  lenu -= iw[jm + (iw_dim1 << 1)];
  kp = ip[jm + (ip_dim1 << 1)];
  im = ind[kp + ind_dim1];
  kl = kp + iw[jm + (iw_dim1 << 1)] - 1;
  iw[jm + (iw_dim1 << 1)] = 0;
  i__1 = kl;
  for (k = kp; k <= i__1; ++k) {
    i = ind[k + ind_dim1];
    ind[k + ind_dim1] = 0;
    kr = ip[i + ip_dim1];
    nz = iw[i + iw_dim1] - 1;
    iw[i + iw_dim1] = nz;
    krl = kr + nz;
    i__2 = krl;
    for (km = kr; km <= i__2; ++km)
      if (ind[km + (ind_dim1 << 1)] == jm) goto L20;

L20:
    a[km] = a[krl];
    ind[km + (ind_dim1 << 1)] = ind[krl + (ind_dim1 << 1)];
    ind[krl + (ind_dim1 << 1)] = 0;
  }
/*
 *  insert new column 
 */
  for (ii = 1; ii <= *n; ++ii) {
    i = iw[ii + iw_dim1 * 3];
    if (i == im) m = ii;
    if ((d__1 = w[i], abs(d__1)) <= smallr) goto L110;
    ++lenu;
    last = ii;
    if (lcol + lenl < *ia) goto L50;
/*
 *  compress column file if necessary. 
 */
    if (ncp >= mcp || lenl + lenu >= *ia) goto L600;
    la05ed(&a[1], &ind[ind_offset], &ip[(ip_dim1 << 1) + 1], n, 
           &iw[(iw_dim1 << 1) + 1], ia, &zero);

L50:
    ++lcol;
    nz = iw[jm + (iw_dim1 << 1)];
    if (nz == 0) ip[jm + (ip_dim1 << 1)] = lcol;
    iw[jm + (iw_dim1 << 1)] = nz + 1;
    ind[lcol + ind_dim1] = i;
    nz = iw[i + iw_dim1];
    kpl = ip[i + ip_dim1] + nz;
    if (kpl > lrow) goto L55;
    if (ind[kpl + (ind_dim1 << 1)] == 0) goto L90;

L55:
/*
 *  new entry has to be created. 
 */
    if (lenl + lrow + nz < *ia) goto L60;
    if (ncp >= mcp || lenl + lenu + nz >= *ia) goto L600;
/*
 *  compress row file if necessary. 
 */
    la05ed(&a[1], &ind[(ind_dim1 << 1) + 1], &ip[ip_offset], n, 
           &iw[iw_offset], ia, &one);

L60:
    kp = ip[i + ip_dim1];
    ip[i + ip_dim1] = lrow + 1;
    if (nz == 0) goto L80;
    kpl = kp + nz - 1;
    i__2 = kpl;
    for (k = kp; k <= i__2; ++k) {
      ++lrow;
      a[lrow] = a[k];
      ind[lrow + (ind_dim1 << 1)] = ind[k + (ind_dim1 << 1)];
      ind[k + (ind_dim1 << 1)] = 0;
    }

L80:
    ++lrow;
    kpl = lrow;

L90:
/*
 *  place new element at end of row.
 */
    iw[i + iw_dim1] = nz + 1;
    a[kpl] = w[i];
    ind[kpl + (ind_dim1 << 1)] = jm;

L110:
    w[i] = (float) 0.;
  }
  if (iw[im + iw_dim1] == 0 || iw[jm + (iw_dim1 << 1)] == 0 || m > last)
    goto L580;
/* 
 *  find column singletons, other than the spike. non-singletons are 
 *  marked with w(j)=1. only iw(.,3) is revised and iw(.,4) is used
 *  for workspace.  
 */
  ins = m;
  m1 = m;
  w[jm] = (float) 1.;
  i__1 = last;
  for (ii = m; ii <= i__1; ++ii) {
    i = iw[ii + iw_dim1 * 3];
    j = iw[ii + (iw_dim1 << 2)];
    if ((d__1 = w[j], abs(d__1)) < smallr) goto L140;
    kp = ip[i + ip_dim1];
    kl = kp + iw[i + iw_dim1] - 1;
    i__2 = kl;
    for (k = kp; k <= i__2; ++k) {
      j = ind[k + (ind_dim1 << 1)];
      w[j] = (float) 1.;
    }
    iw[ins + (iw_dim1 << 2)] = i;
    ++ins;
    continue;

L140:    /* place singletons in new position. */
    iw[m1 + iw_dim1 * 3] = i;
    ++m1;
  }
/*
 *  place non-singletons in new position. 
 */
  ij = m + 1;
  index = last - 1;
  if (index < m1) goto L161;
  i__1 = index;
  for (ii = m1; ii <= i__1; ++ii) {
    iw[ii + iw_dim1 * 3] = iw[ij + (iw_dim1 << 2)];
    ++ij;
  }

L161:
/* 
 *  place spike at end. 
 */
  iw[last + iw_dim1 * 3] = im;
/*
 *  find row singletons, apart from spike row. non-singletons are marked with 
 *  w(i)=2. again only iw(.,3) is revised and iw(.,4) is used for workspace. 
 */
  last1 = last;
  jns = last;
  w[im] = (float) 2.;
  j = jm;
  i__1 = last;
  for (ij = m1; ij <= i__1; ++ij) {
    ii = last + m1 - ij;
    i = iw[ii + iw_dim1 * 3];
    if (w[i] != 2.) goto L180;
    k = ip[i + ip_dim1];
    if (ii != last) j = ind[k + (ind_dim1 << 1)];
    kp = ip[j + (ip_dim1 << 1)];
    kl = kp + iw[j + (iw_dim1 << 1)] - 1;
    iw[jns + (iw_dim1 << 2)] = i;
    --jns;
    i__2 = kl;
    for (k = kp; k <= i__2; ++k) {
      i = ind[k + ind_dim1];
      w[i] = (float) 2.;
    }
    continue;

L180:
    iw[last1 + iw_dim1 * 3] = i;
    --last1;
  }
  i__1 = last1;
  for (ii = m1; ii <= i__1; ++ii) {
    ++jns;
    i = iw[jns + (iw_dim1 << 2)];
    w[i] = (float) 3.;
    iw[ii + iw_dim1 * 3] = i;
  }
/*
 *  deal with singleton spike column. note that bump rows are marked by 
 *  w(i)=3. 
 */
  i__1 = last1;
  for (ii = m1; ii <= i__1; ++ii) {
    kp = ip[jm + (ip_dim1 << 1)];
    kl = kp + iw[jm + (iw_dim1 << 1)] - 1;
    is = 0;
    i__2 = kl;
    for (k = kp; k <= i__2; ++k) {
      l = ind[k + ind_dim1];
      if (w[l] != 3.) continue;
      if (is != 0) goto L230;
      i = l;
      knp = k;
      is = 1;
    }
    if (is == 0) goto L580;
/*
 *  make a(i,jm) a pivot. 
 */
    ind[knp + ind_dim1] = ind[kp + ind_dim1];
    ind[kp + ind_dim1] = i;
    kp = ip[i + ip_dim1];
    i__2 = *ia;
    for (k = kp; k <= i__2; ++k)
      if (ind[k + (ind_dim1 << 1)] == jm) goto L216;

L216:
    am = a[kp];
    a[kp] = a[k];
    a[k] = am;
    ind[k + (ind_dim1 << 1)] = ind[kp + (ind_dim1 << 1)];
    ind[kp + (ind_dim1 << 1)] = jm;
    jm = ind[k + (ind_dim1 << 1)];
    iw[ii + (iw_dim1 << 2)] = i;
    w[i] = (float) 2.;
  }
  ii = last1;
  goto L250;

L230:
  in = m1;
  i__1 = last1;
  for (ij = ii; ij <= i__1; ++ij) {
    iw[ij + (iw_dim1 << 2)] = iw[in + iw_dim1 * 3];
    ++in;
  }

L250:
  last2 = last1 - 1;
  if (m1 == last1) goto L485;
  i__1 = last2;
  for (i = m1; i <= i__1; ++i) iw[i + iw_dim1 * 3] = iw[i + (iw_dim1 << 2)];
  m1 = ii;
  if (m1 == last1) goto L485;
/* 
 *  clear w 
 */
  for (i = 1; i <= *n; ++i) w[i] = (float) 0.;

/*
 *  perform elimination 
 */
  ir = iw[last1 + iw_dim1 * 3];
  i__1 = last1;
  for (ii = m1; ii <= i__1; ++ii) {
    ipp = iw[ii + iw_dim1 * 3];
    kp = ip[ipp + ip_dim1];
    kr = ip[ir + ip_dim1];
    jp = ind[kp + (ind_dim1 << 1)];
    if (ii == last1) jp = jm;
/*
 *  search non-pivot row for element to be eliminated. and bring it to front 
 *  of its row 
 */
    krl = kr + iw[ir + iw_dim1] - 1;
    i__2 = krl;
    for (knp = kr; knp <= i__2; ++knp)
      if (jp == ind[knp + (ind_dim1 << 1)]) goto L300;
    if (ii - last1 != 0) continue;
    else goto L580;

L300:   /* bring element to be eliminated to front of its row. */
    am = a[knp];
    a[knp] = a[kr];
    a[kr] = am;
    ind[knp + (ind_dim1 << 1)] = ind[kr + (ind_dim1 << 1)];
    ind[kr + (ind_dim1 << 1)] = jp;
    if (ii == last1) goto L310;
    if ((d__1 = a[kp], abs(d__1)) < *u * abs(am)) goto L310;
    if (abs(am) < *u * (d__1 = a[kp], abs(d__1))) goto L330;
    if (iw[ipp + iw_dim1] <= iw[ir + iw_dim1]) goto L330;

L310:   /* perform interchange */
    iw[last1 + iw_dim1 * 3] = ipp;
    iw[ii + iw_dim1 * 3] = ir;
    ir = ipp;
    ipp = iw[ii + iw_dim1 * 3];
    k = kr;
    kr = kp;
    kp = k;
    kj = ip[jp + (ip_dim1 << 1)];
    i__2 = *ia;
    for (k = kj; k <= i__2; ++k)
      if (ind[k + ind_dim1] == ipp) goto L325;

L325:
    ind[k + ind_dim1] = ind[kj + ind_dim1];
    ind[kj + ind_dim1] = ipp;

L330:
    if ((d__1 = a[kp], abs(d__1)) < smallr) goto L580;
    if (ii == last1) continue;
    am = -a[kr] / a[kp];
/*
 *  compress row file unless it is certain that there is room for new row. 
 */
    if (lrow + iw[ir + iw_dim1] + iw[ipp + iw_dim1] + lenl <= *ia) goto L340;
    if (ncp >= mcp ||
	lenu + iw[ir + iw_dim1] + iw[ipp + iw_dim1] + lenl > *ia) goto L600;
    la05ed(&a[1], &ind[(ind_dim1 << 1) + 1], &ip[ip_offset], n, 
           &iw[iw_offset], ia, &one);
    kp = ip[ipp + ip_dim1];
    kr = ip[ir + ip_dim1];

L340:
    krl = kr + iw[ir + iw_dim1] - 1;
    kq = kp + 1;
    kpl = kp + iw[ipp + iw_dim1] - 1;
/*
 *  place pivot row (excluding pivot itself) in w. 
 */
    if (kq > kpl) goto L350;
    i__2 = kpl;
    for (k = kq; k <= i__2; ++k) {
      j = ind[k + (ind_dim1 << 1)];
      w[j] = a[k];
    }

L350:
    ip[ir + ip_dim1] = lrow + 1;
/*
 *  transfer modified elements. 
 */
    ind[kr + (ind_dim1 << 1)] = 0;
    ++kr;
    if (kr > krl) goto L380;
    i__2 = krl;
    for (ks = kr; ks <= i__2; ++ks) {
      j = ind[ks + (ind_dim1 << 1)];
      au = a[ks] + am * w[j];
      ind[ks + (ind_dim1 << 1)] = 0;
/*
 *  if element is very small remove it from u. 
 */
      if (abs(au) <= smallr) goto L365;
/*
 *  Computing MAX 
 */
      d__1 = *g, d__2 = abs(au);
      *g = max(d__1, d__2);
      ++lrow;
      a[lrow] = au;
      ind[lrow + (ind_dim1 << 1)] = j;
      goto L370;

L365:
      --lenu;
/*
 *  remove element from col file. 
 */
      k = ip[j + (ip_dim1 << 1)];
      kl = k + iw[j + (iw_dim1 << 1)] - 1;
      iw[j + (iw_dim1 << 1)] = kl - k;
      i__3 = kl;
      for (kk = k; kk <= i__3; ++kk)
	if (ind[kk + ind_dim1] == ir) goto L367;

L367:
      ind[kk + ind_dim1] = ind[kl + ind_dim1];
      ind[kl + ind_dim1] = 0;

L370:
      w[j] = (float) 0.;
    }

L380:       /* scan pivot row for fills. */
    if (kq > kpl) goto L435;
    i__2 = kpl;
    for (ks = kq; ks <= i__2; ++ks) {
      j = ind[ks + (ind_dim1 << 1)];
      au = am * w[j];
      if (abs(au) <= smallr) goto L430;
      ++lrow;
      a[lrow] = au;
      ind[lrow + (ind_dim1 << 1)] = j;
      ++lenu;
/*
 *  create fill in column file. 
 */
      nz = iw[j + (iw_dim1 << 1)];
      k = ip[j + (ip_dim1 << 1)];
      kl = k + nz - 1;
/*
 *  if possible place new element at end of present entry. 
 */
      if (kl != lcol) goto L390;
      if (lcol + lenl >= *ia) goto L400;
      ++lcol;
      goto L395;

L390:
      if (ind[kl + 1 + ind_dim1] != 0) goto L400;

L395:
      ind[kl + 1 + ind_dim1] = ir;
      goto L425;

L400:                                     /* new entry has to be created. */
      if (lcol + lenl + nz + 1 < *ia) goto L410;
/*
 *  compress column file if there is not room for new entry. 
 */
      if (ncp >= mcp || lenu + lenl + nz + 1 >= *ia) goto L600;
      la05ed(&a[1], &ind[ind_offset], &ip[(ip_dim1 << 1) + 1], n, 
             &iw[(iw_dim1 << 1) + 1], ia, &zero);
      k = ip[j + (ip_dim1 << 1)];
      kl = k + nz - 1;

L410:        /* transfer old entry into new. */
      ip[j + (ip_dim1 << 1)] = lcol + 1;
      i__3 = kl;
      for (kk = k; kk <= i__3; ++kk) {
	++lcol;
	ind[lcol + ind_dim1] = ind[kk + ind_dim1];
	ind[kk + ind_dim1] = 0;
      }
/*
 *  add new element. 
 */
      ++lcol;
      ind[lcol + ind_dim1] = ir;

L425:
/*
 *  Computing MAX 
 */
      d__1 = *g, d__2 = abs(au);
      *g = max(d__1, d__2);
      iw[j + (iw_dim1 << 1)] = nz + 1;

L430:
      w[j] = (float) 0.;
    }

L435:
    iw[ir + iw_dim1] = lrow + 1 - ip[ir + ip_dim1];
/*
 *  store multiplier 
 */
    if (lenl + lcol + 1 <= *ia) goto L450;
/*
 *  compress col file if necessary. 
 */
    if (ncp >= mcp) goto L600;
    la05ed(&a[1], &ind[ind_offset], &ip[(ip_dim1 << 1) + 1], n, 
           &iw[(iw_dim1 << 1) + 1], ia, &zero);

L450:
    k = *ia - lenl;
    ++lenl;
    a[k] = am;
    ind[k + ind_dim1] = ipp;
    ind[k + (ind_dim1 << 1)] = ir;
/*
 *  create blank in pivotal column. 
 */
    kp = ip[jp + (ip_dim1 << 1)];
    nz = iw[jp + (iw_dim1 << 1)] - 1;
    kl = kp + nz;
    i__2 = kl;
    for (k = kp; k <= i__2; ++k)
      if (ind[k + ind_dim1] == ir) goto L465;

L465:
    ind[k + ind_dim1] = ind[kl + ind_dim1];
    iw[jp + (iw_dim1 << 1)] = nz;
    ind[kl + ind_dim1] = 0;
    --lenu;
  }

L485:   /* construct column permutation and store it in iw(.,4) */
  i__1 = last;
  for (ii = m; ii <= i__1; ++ii) {
    i = iw[ii + iw_dim1 * 3];
    k = ip[i + ip_dim1];
    j = ind[k + (ind_dim1 << 1)];
    iw[ii + (iw_dim1 << 2)] = j;
  }
  return;

L580:           /* the following instructions implement the failure exits. */
  if (lp != 0) {
    fprintf(lp, "\n\n%s singular matrix created by replacement of ", erm);
    fprintf(lp, "col %ld\n", *mm);
  }
  *g = (float) -6.;
  return;

L600:
  if (lp != 0) fprintf(lp, "\n\n%s ia is too small\n", erm);
  *g = (float) -7.;
  return;

L640:
  if (lp != 0) fprintf(lp, "\n\n%s earlier entry gave error return\n", erm);
  return;
}				/* la05cd */

/* ============================================================ la05ed === 
 * warning:  do not try to use half-words for the ip array.
 *           you won't be able to have more than 32,000 non-zeros
 *           in the basis factors!
 */
void la05ed(a, irn, ip, n, iw, ia, reals)
double *a;
long *irn, *ip, *n, *iw, *ia;
long *reals;
{
/*
 *  f2c generated locals
 */
  long i__1;

/*
 *  Local variables
 */
  long j, k, kl, kn, nz, ipi;

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --iw;
  --ip;
  --irn;
  --a;

/* ------------------- Function body ------------------- */
  ++ncp;
/*
 *  compress file of positive integers. entry j starts at irn(ip(j)) 
 *  and contains iw(j) integers,j=1,n. other components of irn are zero.
 *  length of compressed file placed in lrow if reals is .true. or lcol 
 *  otherwise. 
 *  if reals is .true. array a contains a real file associated with irn 
 *  and this is compressed too. 
 *  a,irn,ip,iw,ia are input/output variables. 
 *  n,reals are input/unchanged variables. 
 */
  for (j = 1; j <= *n; ++j) {
/*
 *  store the last element of entry j in iw(j) then overwrite it by -j.
 */
    nz = iw[j];
    if (nz <= 0) continue;
    k = ip[j] + nz - 1;
    iw[j] = irn[k];
    irn[k] = -j;
  }
/*
 *  kn is the position of next entry in compressed file. 
 */
  kn = 0;
  ipi = 0;
  kl = lcol;
  if (*reals) kl = lrow;
/*
 *  loop through the old file skipping zero (dummy) elements and moving 
 *  genuine elements forward. the entry number becomes known only when 
 *  its end is detected by the presence of a negative integer. 
 */
  i__1 = kl;
  for (k = 1; k <= i__1; ++k) {
    if (irn[k] == 0) continue;
    ++kn;
    if (*reals) a[kn] = a[k];
    if (irn[k] >= 0) goto L20;
/*
 *  end of entry. restore irn(k), set pointer to start of entry and
 *  store current kn in ipi ready for use when next last entry is detected. 
 */
    j = -irn[k];
    irn[k] = iw[j];
    ip[j] = ipi + 1;
    iw[j] = kn - ipi;
    ipi = kn;

L20:
    irn[kn] = irn[k];
  }
  if (*reals) lrow = kn;
  if (!(*reals)) lcol = kn;
  return;
}				/* la05ed */

/* ============================================================ mc20ad === 
 *
 *       mc20ad                 25/11/75
 *  name mc20ad(r)                 check 
 */
void mc20ad(nc, maxa, a, inum, jptr, jnum, jdisp)
long *nc, *maxa;
double *a;
long *inum, *jptr, *jnum, *jdisp;
{
/*
 *  f2c generated locals
 */
  long i__1, i__2;

/*
 *  Local variables
 */
  double acep;
  long icep, jcep, null, i, j, k, ja, jb, kr;
  double ace;
  long ice, jce, loc;

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --jnum;
  --jptr;
  --inum;
  --a;

/* ------------------- Function body ------------------- */
  null = -(*jdisp);
/*
 *  clear jptr  
 */
  i__1 = *nc;
  for (j = 1; j <= i__1; ++j) {
    jptr[j] = 0;
  }
/*
 *  count the number of elements in each column. 
 */
  i__1 = *maxa;
  for (k = 1; k <= i__1; ++k) {
    j = jnum[k] + *jdisp;
    ++jptr[j];
  }
/*  
 * set the jptr array 
 */
  k = 1;
  i__1 = *nc;
  for (j = 1; j <= i__1; ++j) {
    kr = k + jptr[j];
    jptr[j] = k;
    k = kr;
  }
/*
 *  reorder the elements into column order.  the algorithm is an in-place 
 *  sort and is of order maxa. 
 */
  i__1 = *maxa;
  for (i = 1; i <= i__1; ++i) {
/*
 *  establish the current entry. 
 */
    jce = jnum[i] + *jdisp;
    if (jce == 0) continue;
    ace = a[i];
    ice = inum[i];
/*
 *  clear the location vacated. 
 */
    jnum[i] = null;
/*
 *  chain from current entry to store items. 
 */
    i__2 = *maxa;
    for (j = 1; j <= i__2; ++j) {
/*
 *  current entry not in correct position.  determine correct position to 
 *  store entry. 
 */
      loc = jptr[jce];
      ++jptr[jce];
/*
 *  save contents of that location. 
 */
      acep = a[loc];
      icep = inum[loc];
      jcep = jnum[loc];
/*
 *  store current entry. 
 */
      a[loc] = ace;
      inum[loc] = ice;
      jnum[loc] = null;
/*
 *  check if next current entry needs to be processed. 
 */
      if (jcep == null) break;
/*
 *  it does.  copy into current entry. 
 */
      ace = acep;
      ice = icep;
      jce = jcep + *jdisp;
    }
  }
/*
 *  reset jptr vector. 
 */
  ja = 1;
  i__1 = *nc;
  for (j = 1; j <= i__1; ++j) {
    jb = jptr[j];
    jptr[j] = ja;
    ja = jb;
  }
  return;
}				/* mc20ad */

/* ============================================================ mc20bd === 
 */
void mc20bd(nc, maxa, a, inum, jptr)
long *nc, *maxa;
double *a;
long *inum, *jptr;
{
/*
 *  f2c generated locals
 */
  long i__1, i__2, i__3;

/*
 *  Local variables
 */
  long kmax, j, k, jj, ik, kdummy;
  double ace;
  long ice, klo, kor;

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --jptr;
  --inum;
  --a;

/* ------------------- Function body ------------------- */
  kmax = *maxa;
  i__1 = *nc;
  for (jj = 1; jj <= i__1; ++jj) {
    j = *nc + 1 - jj;
    klo = jptr[j] + 1;
    if (klo > kmax) goto L30;
    kor = kmax;
    i__2 = kmax;
    for (kdummy = klo; kdummy <= i__2; ++kdummy) {
/*
 *  items kor, kor+1, .... ,kmax are in order 
 */
      ace = a[kor - 1];
      ice = inum[kor - 1];
      i__3 = kmax;
      for (k = kor; k <= i__3; ++k) {
	ik = inum[k];
	if (abs(ice) <= abs(ik)) goto L20;
	inum[k - 1] = ik;
	a[k - 1] = a[k];
      }
      k = kmax + 1;

L20:
      inum[k - 1] = ice;
      a[k - 1] = ace;
      --kor;
    }

L30:  /* next column */
    kmax = klo - 2;
  }
  return;
}				/* mc20bd */

/* ============================================================ xaddaj === 
 *     *****purpose: 
 *     this routine is used to add a single new column to the 
 *     current linear program. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     cj          contains one objective function coefficient. 
 *     cola        contains the non-zero coefficients 
 *                 of a matrix column. 
 *     coli        contains the row numbers corresponding 
 *                 to the non-zeros of a matrix column. 
 *     collen      contains the number of non-zeros in a 
 *                 matrix column. 
 *     colmax      is the maximum number of non-zeros in any 
 *                 matrix column. 
 *     n           is the number of columns in the current 
 *                 linear program before adding this new one. 
 *     on output: 
 *     j           is the index assigned to the new column. 
 *     n           is the number of columns after adding this new one: 
 *                 (output n) = (input n) + 1 
 *     *****application and usage restrictions: 
 *     this routine uses the map of the data structure for 
 *     the  problem data.  the 'body of program' must be re-written 
 *     if that map is changed. 
 *     *****algorithm notes: 
 *     data structure for the problem data. 
 *
 *     mapi(1)      points to the colpnt array. 
 *     mapi(2)      points to the rownos array. 
 *     mapi(3)      points to the maxa constant. 
 *     mapi(4)      points to the maxm constant. 
 *     mapi(5)      points to the maxn constant. 
 *
 *     mapr(1)      points to the lowerb array. 
 *     mapr(2)      points to the upperb array. 
 *     mapr(3)      points to the profit array. 
 *     mapr(4)      points to the abycol array. 
 *
 */
void xaddaj(cj, cola, coli, collen, colmax, ioerr, j, 
            mapi, mapr, memi, memr, n)
double *cj, *cola;
FILE *ioerr;
long *coli, *collen, *colmax, *j, *mapi, *mapr, *memi;
double *memr;
long *n;
{
  long mi1, mi2, mi3, mi4, mi5, mr3, mr4;

/*
 *  Subroutines called
 */  
  void xdata1();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;

/* ------------------- Function body ------------------- */
  ++(*n);
  *j = *n;
  mi1 = mapi[1];
  mi2 = mapi[2];
  mi3 = mapi[3];
  mi4 = mapi[4];
  mi5 = mapi[5];
  mr3 = mapr[3];
  mr4 = mapr[4];
  xdata1(cj, &cola[1], &coli[1], collen, colmax, ioerr, j, &memr[mr3], &
	 memr[mr4], &memi[mi1], &memi[mi2], &memi[mi3], &memi[mi4], &memi[
								   mi5]);
  return;
}				/* xaddaj */

/* ============================================================ xaddub === 
 *     *****purpose: 
 *     this routine is used to set lower and upper bounds for a 
 *     single variable. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     bndtyp      1 means lower bound=0, upper bound=+infinity 
 *                   for every variable; 
 *                 2 means lower bound=0, upper bound=bound 
 *                   for every variable 1,...,ntype2 and 
 *                   lower bound=0, upper bound=+infinity for every 
 *                   variable past ntype2; 
 *                 3 means lower bound=0 for every variable; 
 *                 4 means both bounds are general. 
 *                 note:  the bound type does not apply to free 
 *                        variables or artificial variables. 
 *     j           is the index of the variable whose bounds 
 *                 are being added. 
 *     lj          is the lower bound being added (if bndtyp=4). 
 *     uj          is the upper bound being added. 
 *     on output: 
 *     lj and uj have been placed in the problem data structure 
 *     and associated with variable j. 
 *     *****application and usage restrictions: 
 *     this routine uses the map of the data structure for the 
 *     problem data.  the 'body of program' must be re-written if 
 *     that map is changed. 
 *     *****algorithm notes: 
 *     data structure for the problem data: 
 *
 *     mapi(1)      points to the colpnt array. 
 *     mapi(2)      points to the rownos array. 
 *     mapi(3)      points to the maxa constant. 
 *     mapi(4)      points to the maxm constant. 
 *     mapi(5)      points to the maxn constant. 
 *
 *     mapr(1)      points to the lowerb array. 
 *     mapr(2)      points to the upperb array. 
 *     mapr(3)      points to the profit array. 
 *     mapr(4)      points to the abycol array. 
 *
 */
void xaddub(bndtyp, ioerr, j, lj, mapi, mapr, memi, memr, uj)
FILE *ioerr;
long *bndtyp, *j;
double *lj;
long *mapi, *mapr, *memi;
double *memr, *uj;
{
  long mi5, mr1, mr2;

/*
 *  Subroutines called
 */  
  void xdata3();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --memr;
  --memi;
  --mapr;
  --mapi;

/* ------------------- Function body ------------------- */
  mi5 = mapi[5];
  mr1 = mapr[1];
  mr2 = mapr[2];
  xdata3(bndtyp, ioerr, j, lj, uj, &memr[mr1], &memr[mr2], &memi[mi5]);
  return;
}				/* xaddub */

/* ============================================================ xgetaj === 
 *     *****purpose: 
 *     this subroutine extracts one column and the corresponding 
 *     objective function coefficient from the data structure 
 *     for the original problem data. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     colmax      is the maximum number of non-zeros in any 
 *                 matrix column. 
 *     j           is the index of the column to be extracted. 
 *     on output: 
 *     cj          contains one objective function coefficient. 
 *     cola        contains the non-zero coefficients 
 *                 of a matrix column. 
 *     coli        contains the row numbers corresponding 
 *                 to the non-zeros of a matrix column. 
 *     collen      contains the number of non-zeros in a 
 *                 matrix column. 
 *     *****application and usage restrictions: 
 *     this routine uses the map of the data structure 
 *     for the  problem data.  the 'body of program' must be re-written 
 *     if that map is changed. 
 *     *****algorithm notes: 
 *     data structure for the problem data: 
 *
 *     mapi(1)      points to the colpnt array. 
 *     mapi(2)      points to the rownos array. 
 *     mapi(3)      points to the maxa constant. 
 *     mapi(4)      points to the maxm constant. 
 *     mapi(5)      points to the maxn constant. 
 *
 *     mapr(1)      points to the lowerb array. 
 *     mapr(2)      points to the upperb array. 
 *     mapr(3)      points to the profit array. 
 *     mapr(4)      points to the abycol array. 
 *
 */
void xgetaj(cj, cola, coli, collen, colmax, ioerr, j, mapi, mapr, memi, memr)
double *cj, *cola;
FILE *ioerr;
long *coli, *collen, *colmax, *j, *mapi, *mapr, *memi;
double *memr;
{
  long mi1, mi2, mi3, mi5, mr3, mr4;

/*
 *  Subroutines called
 */  
  void xdata2();


/*
 *  Parameter adjustments (Fortran -> C)
 */
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;

/* ------------------- Function body ------------------- */
  mi1 = mapi[1];
  mi2 = mapi[2];
  mi3 = mapi[3];
  mi5 = mapi[5];
  mr3 = mapr[3];
  mr4 = mapr[4];
  xdata2(cj, &cola[1], &coli[1], collen, colmax, ioerr, j, &memr[mr3], &
	 memr[mr4], &memi[mi1], &memi[mi2], &memi[mi3], &memi[mi5]);
  return;
}				/* xgetaj */

/* ============================================================ xgetub === 
 *     *****purpose: 
 *     this routine is used to fetch the lower and upper 
 *     bounds of a single variable from the problem 
 *     data structure. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     bndtyp      1 means lower bound=0, upper bound=+infinity 
 *                   for every variable; 
 *                 2 means lower bound=0, upper bound=bound 
 *                   for every variable 1,...,ntype2 and 
 *                   lower bound=0, upper bound=+infinity for every 
 *                   variable past ntype2; 
 *                 3 means lower bound=0 for every variable; 
 *                 4 means both bounds are general. 
 *                 note:  the bound type does not apply to free 
 *                        variables or artificial variables. 
 *     j           is the index of the variable whose bounds 
 *                 are to be fetched. 
 *     on output: 
 *     lj          is the lower bound for variable j. 
 *     uj          is the upper bound for variable j. 
 *     *****application and usage restrictions: 
 *     this routine uses the map of the data structure for the 
 *      problem data.  the 'body of program' must be re-written if that 
 *     map is changed. 
 *     *****algorithm notes: 
 *     data structure for the problem data: 
 *
 *     mapi(1)      points to the colpnt array. 
 *     mapi(2)      points to the rownos array. 
 *     mapi(3)      points to the maxa constant. 
 *     mapi(4)      points to the maxm constant. 
 *     mapi(5)      points to the maxn constant. 
 *
 *     mapr(1)      points to the lowerb array. 
 *     mapr(2)      points to the upperb array. 
 *     mapr(3)      points to the profit array. 
 *     mapr(4)      points to the abycol array. 
 *
 */
void xgetub(bndtyp, ioerr, j, lj, mapi, mapr, memi, memr, uj)
FILE *ioerr;
long *bndtyp, *j;
double *lj;
long *mapi, *mapr, *memi;
double *memr, *uj;
{
  long mi5, mr1, mr2;

/*
 *  Subroutines called
 */  
  void xdata4();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --memr;
  --memi;
  --mapr;
  --mapi;

/* ------------------- Function body ------------------- */
  mi5 = mapi[5];
  mr1 = mapr[1];
  mr2 = mapr[2];
  xdata4(bndtyp, ioerr, j, lj, uj, &memr[mr1], &memr[mr2], &memi[mi5]);
  return;
}				/* xgetub */

/* ============================================================ xdata1 === 
 *     *****purpose: 
 *     this routine adds a single new column to the 
 *     problem data structure. 
 *     *****parameter description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     cj          contains one objective function coefficient. 
 *     cola        contains the non-zero coefficients 
 *                 of a matrix column. 
 *     coli        contains the row numbers corresponding 
 *                 to the non-zeros of a matrix column. 
 *     collen      contains the number of non-zeros in a 
 *                 matrix column. 
 *     colmax      is the maximum number of non-zeros in any 
 *                 matrix column. 
 *     j           is the index of the new column being added. 
 *     profit      is part of the problem data structure. 
 *                 it contains the objective function. 
 *     abycol      is part of the problem data structure. 
 *                 it contains the non-zero coefficients, 
 *                 in column major order. 
 *     colpnt      is part of the problem data structure. 
 *                 it contains a pointer to the beginning of 
 *                 the section for each column in the abycol 
 *                 and rownos arrays. 
 *     rownos      is part of the problem data structure. 
 *                 it contains the row numbers corresponding 
 *                 to the non-zeros in the abycol array. 
 *     on output: 
 *     the new column has been placed in the profit, abycol, 
 *     colpnt, and rownos arrays. 
 *     *****application and usage restrictions: 
 *     this routine is dependent on the problem 
 *     data structure.  it must be replaced if a different 
 *     data structure is used. 
 *     *****algorithm notes: 
 *     this routine is not, strictly speaking, part of xmp. 
 *     it is part of the implementation of a specific data 
 *     structure for the problem data. 
 *
 */
void xdata1(cj, cola, coli, collen, colmax, ioerr, j, profit,
	    abycol, colpnt, rownos, maxa, maxm, maxn)
double *cj, *cola;
FILE *ioerr;
long *coli, *collen, *colmax, *j;
double *profit, *abycol;
long *colpnt, *rownos, *maxa, *maxm, *maxn;
{
/*
 *  f2c generated locals
 */
  long i__1;

/*
 *  Local variables
 */
  long error;
  long ik, ip, ikx;

/*
 *  Subroutines called
 */  
  void xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --rownos;
  --colpnt;
  --abycol;
  --profit;
  --coli;
  --cola;

/* ------------------- Function body ------------------- */
  if (*j > *maxn) {
    fprintf(ioerr, "xdata1...error: too many variables.\n");
    fprintf(ioerr, "space was requested for only %ld variables.\n", *maxn);
    error = 0;
    xstop(&error, ioerr);
  }
/*
 *  colpnt(1) has to be set to zero to begin.
 *  initialize whole profit array to zero in case it
 *
 *  gets extracted later by xgetro.  
 */
  if (*j == 1) {
    colpnt[*j] = 0;
    i__1 = *maxn;
    for (ik = 1; ik <= i__1; ++ik) profit[ik] = (float) 0.;
  }
  ip = colpnt[*j];
  colpnt[*j + 1] = ip + *collen;
  if (ip + *collen > *maxa) {
    fprintf(ioerr, "xdata1...error: too many non-zeros.\n");
    fprintf(ioerr, "space was requested for only %ld non-zeros.\n", *maxa);
    error = 0;
    xstop(&error, ioerr);
  }
  profit[*j] = *cj;
  if (*collen < 0 || *collen > *colmax) goto L140;
  if (*collen > 0) {
    i__1 = *collen;
    for (ik = 1; ik <= i__1; ++ik) {
      ikx = ik;
      if (coli[ik] < 1 || coli[ik] > *maxm) goto L130;
      abycol[ip + ik] = cola[ik];
      rownos[ip + ik] = coli[ik];
    }
  }
  return;

L130:
  fprintf(ioerr, "xdata1...error: column %ld has an entry in row %ld\n",
	  *j, coli[ikx]);
  error = 0;
  xstop(&error, ioerr);

L140:
  fprintf(ioerr, "xdata1...error: column %ld has length %ld\n", *j, *collen);
  error = 0;
  xstop(&error, ioerr);
  return;
}				/* xdata1 */

/* ============================================================ xdata2 === 
 *     *****purpose: 
 *     this routine retrieves one column from the problem 
 *     data structure. 
 *     *****parameter description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     colmax      is the maximum number of non-zeros in any 
 *                 matrix column. 
 *     j           is the index of the column to be retrieved. 
 *     profit      is part of the problem data structure. 
 *                 it contains the objective function. 
 *     abycol      is part of the problem data structure. 
 *                 it contains the non-zero coefficients, 
 *                 in column major order. 
 *     colpnt      is part of the problem data structure. 
 *                 it contains a pointer to the beginning of 
 *                 the section for each column in the abycol 
 *                 and rownos arrays. 
 *     rownos      is part of the problem data structure. 
 *                 it contains the row numbers corresponding 
 *                 to the non-zeros in the abycol array. 
 *     on output: 
 *     cj          contains one objective function coefficient. 
 *     cola        contains the non-zero coefficients 
 *                 of a matrix column. 
 *     coli        contains the row numbers corresponding 
 *                 to the non-zeros of a matrix column. 
 *     collen      contains the number of non-zeros in a 
 *                 matrix column. 
 *     *****application and usage restrictions: 
 *     this routine is dependent on the problem 
 *     data structure.  it must be replaced if a 
 *     different data structure is used. 
 *     *****algorithm notes: 
 *     this routine is not, strictly speaking, part of xmp. 
 *     it is part of the implementation of a specific data 
 *     structure for the problem data. 
 *
 *     this routine has been modified (june, 1983) to be 
 *     compatible with the xaddrj routine as well as the 
 *     xaddaj routine.  xaddrj is used by the xcut routine 
 *     which adds new constraints to an existing linear program. 
 *
 */
void xdata2(cj, cola, coli, collen, colmax, ioerr, j, profit,
	    abycol, colpnt, rownos, maxa, maxn)
double *cj, *cola;
FILE *ioerr;
long *coli, *collen, *colmax, *j;
double *profit, *abycol;
long *colpnt, *rownos, *maxa, *maxn;
{
/*
 *  f2c generated locals
 */
  long i__1;

/*
 *  Local variables
 */
  long error;
  long ik, ip;

/*
 *  Subroutines called
 */  
  void xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --rownos;
  --colpnt;
  --abycol;
  --profit;
  --coli;
  --cola;

/* ------------------- Function body ------------------- */
  if (*j < 1 || *j > *maxn) {
    fprintf(ioerr, "xdata2...error: variable %ld does not exist.\n", *j);
    error = 0;
    xstop(&error, ioerr);
  }
  *cj = profit[*j];
  ip = colpnt[*j];
  *collen = colpnt[*j + 1] - ip;
  if (*collen < 0 || *collen > *colmax) goto L120;
/*
 *  next line is for compatibility with xaddrj. 
 */
  if (*collen == *colmax) goto L115;
  if (*collen > 0) {
    i__1 = *collen;
    for (ik = 1; ik <= i__1; ++ik) {
      cola[ik] = abycol[ip + ik];
      coli[ik] = rownos[ip + ik];
    }
  }
  return;

L115:
/*
 *  this section is for compatibility with xaddrj. 
 *  we must remove the padded zeros. 
 */
  *collen = 0;
  i__1 = *colmax;
  for (ik = 1; ik <= i__1; ++ik) {
    if (rownos[ip + ik] == 0) goto L118;
    ++(*collen);
    cola[ik] = abycol[ip + ik];
    coli[ik] = rownos[ip + ik];
  }

L118:
  if (*collen == 0) goto L120;
  return;

L120:
  fprintf(ioerr, "xdata2...error: column %ld has length %ld\n", *j, *collen);
  error = 0;
  xstop(&error, ioerr);
  return;
}				/* xdata2 */

/* ============================================================ xdata3 === 
 *     *****purpose: 
 *     this routine adds lower and upper bounds for a single 
 *     variable.  it is only used when bndtyp= 3 or 4. 
 *     *****parameter description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     bndtyp      1 means lower bound=0, upper bound=+infinity 
 *                   for every non-free variable; 
 *                 2 means lower bound=0, upper bound=bound 
 *                   for every non-free structural variable; 
 *                 3 means lower bound=0 for every non-free variable; 
 *                 4 means both bounds are general. 
 *     j           is the index of the variable whose 
 *                 bounds are being added. 
 *     lj          is the lower bound. 
 *     uj          is the upper bound. 
 *     lowerb      is part of the problem data structure. 
 *                 it contains the lower bounds on the variables 
 *                 when bndtyp=4. 
 *     upperb      is part of the problem data structure. 
 *                 it contains the upper bounds on the variables 
 *                 when bndtyp= 3 or 4. 
 *     on output: 
 *     lj and uj have been added to the lowerb and upperb 
 *     arrays.  only uj is actually saved if bndtyp= 3. 
 *     *****application and usage restrictions: 
 *     this routine is dependent on the problem 
 *     data structure.  it must be replaced if a different 
 *     data structure is used. 
 *     *****algorithm notes: 
 *     this routine is not, strictly speaking, part of xmp. 
 *     it is part of the implementation of a specific data 
 *     structure for the problem data. 
 *
 */
void xdata3(bndtyp, ioerr, j, lj, uj, lowerb, upperb, maxn)
FILE *ioerr;
long *bndtyp, *j;
double *lj, *uj, *lowerb, *upperb;
long *maxn;
{
  long error;

/*
 *  Subroutines called
 */  
  void xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --upperb;
  --lowerb;

/* ------------------- Function body ------------------- */
  if (*j < 1 || *j > *maxn) {
    fprintf(ioerr, "xdata3...error: invalid variable index %ld\n", *j);
    error = 0;
    xstop(&error, ioerr);
  }
  if (*lj > *uj) {
    fprintf(ioerr, "xdata3.....for j = %ld   lj = %16.8f", *j, *lj);
    fprintf(ioerr, "  exceeds uj = %16.8f\n", *uj);
    error = 0;
    xstop(&error, ioerr);
  }
  if (*bndtyp == 4) {
    upperb[*j] = *uj;
    lowerb[*j] = *lj;
  } else if (*bndtyp == 3) {
    upperb[*j] = *uj;
  } else {
    fprintf(ioerr, "xdata3     %ld\n", *bndtyp);
    error = 3;
    xstop(&error, ioerr);
  }
  return;
}				/* xdata3 */

/* ============================================================ xdata4 === 
 *     *****purpose: 
 *     this routine retrieves the lower and upper bounds 
 *     for a single variable.  it is only used if 
 *     bndtyp= 3 or 4. 
 *     *****parameter description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     bndtyp      1 means lower bound=0, upper bound=+infinity 
 *                   for every non-free variable; 
 *                 2 means lower bound=0, upper bound=bound 
 *                   for every non-free structural variable; 
 *                 3 means lower bound=0 for every non-free variable; 
 *                 4 means both bounds are general. 
 *     j           is the index of the variable whose bounds 
 *                 are to be retrieved. 
 *     lowerb      is part of the problem data structure. 
 *                 it contains the lower bounds on the variables 
 *                 when bndtyp=4. 
 *     upperb      is part of the problem data structure. 
 *                 it contains the upper bounds on the variables 
 *                 when bndtyp= 3 or 4. 
 *     on output: 
 *     lj          is the lower bound on variable j. 
 *     uj          is the upper bound on variable j. 
 *     *****application and usage restrictions: 
 *     this routine is dependent on the problem 
 *     data structure.  it must be replaced if a different 
 *     data structure is used. 
 *     *****algorithm notes: 
 *     this routine is not, strictly speaking, part of xmp. 
 *     it is part of the implementation of a specific data 
 *     structure for the problem data. 
 *
 */
void xdata4(bndtyp, ioerr, j, lj, uj, lowerb, upperb, maxn)
FILE *ioerr;
long *bndtyp, *j;
double *lj, *uj, *lowerb, *upperb;
long *maxn;
{
  long error;

/*
 *  Subroutines called
 */  
  void xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --upperb;
  --lowerb;

/* ------------------- Function body ------------------- */
  if (*j < 1 || *j > *maxn) {
    fprintf(ioerr, "xdata4...error: invalid variable index %ld\n", *j);
    error = 0;
    xstop(&error, ioerr);
  }
  *lj = (float) 0.;
  if (*bndtyp == 4) {
    *uj = upperb[*j];
    *lj = lowerb[*j];
  } else if (*bndtyp == 3) {
    *uj = upperb[*j];
  } else {
    fprintf(ioerr, "xdata4     %ld\n", *bndtyp);
    error = 3;
    xstop(&error, ioerr);
  }

  return;
}				/* xdata4 */

/* ============================================================ fcand  === 
 *     *****purpose: 
 *     the purpose of this subroutine is to select a candidate list 
 *     of attractive non-basic variables which will be eligible 
 *     to enter the basis during the subsequent series of minor 
 *     iterations. 
 *
 *     this is the fast version of xcand. 
 *
 *     *****parameter description: 
 *     see xmp dictionary for parameters not described here. 
 *     on input: 
 *     abycol      is part of the problem data structure. 
 *                 it contains the non-zero coefficients, 
 *                 in column major order. 
 *     colpnt      is part of the problem data structure. 
 *                 it contains a pointer to the beginning of 
 *                 the section for each column in the abycol 
 *                 and rownos arrays. 
 *     look        is the number of columns to be considered during 
 *                 construction of the candidate list. 
 *                 controls partial pricing. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     pick        is the size of the candidate list used for 
 *                 multiple pricing. 
 *     phase       is the phase, 1 or 2. 
 *     profit      is part of the problem data structure. 
 *                 it contains the objective function. 
 *     rownos      is part of the problem data structure. 
 *                 it contains the row numbers corresponding 
 *                 to the non-zeros in the abycol array. 
 *     start1      is the starting column for the partial pricing 
 *                 procedure. 
 *     on output: 
 *     cand        is the candidate list; it contains the non-basic 
 *                 variables that are eligible to enter the basis 
 *                 during a series of minor iterations. 
 *     pprime      is the number of attractive non-basic 
 *                 variables actually placed in the candidate list; 
 *                 pprime less than or equal to pick. 
 *     start2      is the last column considered by the partial 
 *                 pricing procedure. 
 *     *****application and usage restrictions: 
 *
 *     this is the fast version of xcand.  it is fast 
 *     because it handles the problem data structure 
 *     directly, without going through xgetaj, and also 
 *     because it does its own inner products without 
 *     calling xdot.  this routine will have to be changed 
 *     if the problem data structure is changed. 
 *
 *     *****algorithm notes: 
 *     to call fcand, use the following form: 
 *
 *     call fcand(cand,...,uzero, 
 *    x memr(mapr(3)),memr(mapr(4)),memi(mapi(1)), 
 *    x memi(mapi(2)),memi(mapi(3))) 
 *
 *     partial pricing: 
 *     'look' is the number of columns scanned during one call 
 *     to fcand.  the columns scanned are start1,start1+1,..., 
 *     start1+look-1 unless there is wraparound (scanning 
 *     the end of the matrix and then the beginning of the 
 *     matrix).  wraparound is handled in the obvious way. 
 *     no column is scanned more than once.  if 'look' is 
 *     greater than the number of columns, then every column 
 *     will be scanned. 
 *
 *     multiple pricing: 
 *     if there are at least 'pick' attractive columns among those 
 *     scanned, then the 'pick' most attractive are selected for 
 *     the candidate list. (most attractive in terms of the 
 *     magnitude of their relative profit.)  if there are fewer 
 *     than 'pick' attractive columns among those scanned, 
 *     then all of them are placed in the candidate list. 
 *     'pprime' is set to the actual number of candidates selected. 
 *
 */
void fcand(cand, cola, coli, colmax, ioerr, look, mapi, mapr,
	   maxm, maxn, memi, memr, n, pick, phase, pprime, start1, start2,
	   status, uzero, profit, abycol, colpnt, rownos, maxa)
long *cand;
double *cola;
FILE *ioerr;
long *coli, *colmax, *look, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *pick, *phase, *pprime, *start1, *start2, *status;
double *uzero, *profit, *abycol;
long *colpnt, *rownos, *maxa;
{
/*
 *  f2c generated locals
 */
  long i__1, i__2;

/*
 *  Local variables
 */
  double temp, zabs;
  long loop;
  double zdot;
  long j, k2, k3, ia, ib;
  double dj, candcj[10];
  long ik, ip, collen, ikx;

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --rownos;
  --colpnt;
  --abycol;
  --profit;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --cand;

/* ------------------- Function body ------------------- */
  if (*pick > 10) *pick = 10;
  loop = 1;
  *pprime = 0;
  ia = *start1;
  ib = *start1 + *look - 1;
  if (ib > *n) ib = *n;

L200:
  *start2 = ib;

  i__1 = ib;
  for (j = ia; j <= i__1; ++j) { /* beginning of main loop. */
    if ((i__2 = status[j]) < 0) {
      goto L210;
    } else if (i__2 == 0) {
      goto L230;
    } else {
      continue;
    }

L210:
    if (status[j] < -2) continue;

L230:
/*
 *  non-basic free variables (status -2) are eligible to enter
 *  the basis.
 *  artificial variables (status -3) and locked variables
 *  (status -4 or -5) are not eligible to enter the basis.
 *
 *  here if variable j is non-basic, not artificial, and not locked.
 *  compute the relative profit for variable j. 
 */
/*
 *  --- data structure access. ---
 */
    ip = colpnt[j];
    collen = colpnt[j + 1] - ip;
    zdot = (float) 0.;
    zabs = (float) 0.;
    if (collen > 0) {
      i__2 = collen;
      for (ik = 1; ik <= i__2; ++ik) {
	ikx = rownos[ip + ik];
	if (ikx == 0) goto L236;
	temp = uzero[ikx] * abycol[ip + ik];
	zdot += temp;
	zabs += abs(temp);
      }
    }

L236:
    if (abs(zdot) < zl || abs(zdot) < zl * zabs) zdot = (float) 0.;
    if (*phase == 1) {
      dj = (float) 0.;
    } else {
      dj = profit[j];
    }
    dj -= zdot;
    if (abs(dj) < zlc) dj = (float) 0.;
/*
 *  --- end of data structure access. ---
 */
    if (dj < 0.) {
      goto L270;
    } else if (dj == 0) {
      continue;
    } else {
      goto L280;
    }

L270:
    if (status[j] == -1 || status[j] == -2) goto L290;
    continue;

L280:
    if (status[j] == 0 || status[j] == -2) goto L290;
    continue;

L290:
    dj = abs(dj);
    if (*pprime == 0) goto L310;
/*
 *  put variable j in the candidate list, in order according to the 
 *  magnitude of its relative profit. 
 */
    k2 = 1;

L300:
    if (dj > candcj[k2 - 1]) goto L320;
    ++k2;
    if (k2 <= *pprime) goto L300;
    if (*pprime == *pick) continue;

L310:
    ++(*pprime);

L315:
    cand[*pprime] = j;
    candcj[*pprime - 1] = dj;
    continue;

L320:
    if (*pick == 1) goto L315;
    k3 = *pick - 1;
    if (*pprime < *pick) k3 = *pprime;

L330:
    cand[k3 + 1] = cand[k3];
    candcj[k3] = candcj[k3 - 1];
    --k3;
    if (k3 >= k2) goto L330;
    cand[k2] = j;
    candcj[k2 - 1] = dj;
    ++(*pprime);
    if (*pprime > *pick) *pprime = *pick;
  }      /* end of main loop. */
/*
 *  check for wraparound...scanning end of matrix and beginning of matrix. 
 */
  if (loop == 2) return;
  loop = 2;
  if (*start1 + *look - 1 <= *n) return;
  ia = 1;
  ib = *start1 + *look - 1 - *n;
  if (ib > *start1 - 1) ib = *start1 - 1;
  if (ib >= ia) goto L200;

  return;
}				/* fcand */

/* ============================================================ xdchq  === 
 *     *****purpose: 
 *     the purpose of this routine is to determine the variable 
 *     to enter the basis for a dual simplex pivot. 
 *
 *     this is the fast version of xdchq. 
 *
 *     *****parameter description: 
 *     see xmp dictionary for parameters not described here. 
 *     on input: 
 *     abycol      is part of the problem data structure. 
 *                 it contains the non-zero coefficients, 
 *                 in column major order. 
 *     betar       is used to hold row r of the basis inverse, 
 *                 where r is the position of the variable basis(r) 
 *                 that is leaving the basis. 
 *     colpnt      is part of the problem data structure. 
 *                 it contains a pointer to the beginning 
 *                 of the section for each column in the abycol 
 *                 and rownos arrays. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     outtyp      +1 means the leaving variable is going to its 
 *                    lower bound; 
 *                 -1 means the leaving variable is going to its 
 *                    upper bound; 
 *                  0 means the entering and leaving variables are 
 *                    the same. 
 *     profit      is part of the problem data structure. 
 *                 it contains the objective function. 
 *     rownos      is part of the problem data structure. 
 *                 it contains the row numbers corresponding 
 *                 to the non-zeros in the abycol array. 
 *     on output: 
 *     dfeas       .false. if a dual infeasible column has been 
 *                 encountered (in this event q is the index of 
 *                 the dual infeasible column); 
 *                 .true. otherwise. 
 *     intyp       +1 means the entering variable is increasing 
 *                    from its lower bound. 
 *                 -1 means the entering variable is decreasing 
 *                    from its upper bound. 
 *     lambda      is the winning ratio from the dual ratio 
 *                 test; also the distance to be moved 
 *                 in dual space when we make the pivot. 
 *     pivot       is the pivot element. 
 *     q           the index of the entering variable. 
 *     dunbdd      .true. if the dual problem is unbounded; 
 *                 .false. otherwise. 
 *     *****application and usage restrictions: 
 *
 *     this is the fast version of xdchq.  it is fast because 
 *     it handles the problem data structure directly, without 
 *     going through xgetaj, and also because it does its own 
 *     inner products, without calling xdot. 
 *     this routine will have to be changed if the problem 
 *     data structure is changed. 
 *
 *     *****algorithm notes: 
 *     to call fdchq, use the following form: 
 *
 *     call fdchq(betar,...,uzero, 
 *    x memr(mapr(3)),memr(mapr(4)),memi(mapi(1)), 
 *    x memi(mapi(2)),memi(mapi(3))) 
 *
 */
void fdchq(betar, cola, coli, colmax, dfeas, intyp, ioerr,
	   lambda, mapi, mapr, maxm, maxn, memi, memr, n, outtyp, pivot, q,
	   status, dunbdd, uzero, profit, abycol, colpnt, rownos, maxa)
double *betar, *cola;
long *coli, *colmax;
long *dfeas;
FILE *ioerr;
long *intyp;
double *lambda;
long *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *outtyp;
double *pivot;
long *q, *status;
long *dunbdd;
double *uzero, *profit, *abycol;
long *colpnt, *rownos, *maxa;
{
/*
 *  f2c generated locals
 */
  long i__2;

/*
 *  Local variables
 */
  double babs, braj, zabs, temp, uzaj;
  long j;
  double pivhi, pivlo;
  long error;
  double cj, dj;
  long ik, ip;
  double lambhi;
  long jx;
  double lamblo;
  long collen, qhi, qlo, ikx;

/*
 *  Subroutines called
 */  
  void xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --rownos;
  --colpnt;
  --abycol;
  --profit;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --betar;

/* ------------------- Function body ------------------- */
/*
 * statements below eliminate compiler warning messages
 * about unitialized values
 */
  dj = 0.;
/* end of statements to eliminate warning messages */

  if (*n < 1 || *n > *maxn) {
    error = 2;
    fprintf(ioerr, "fdchq     %ld\n", *n);
    xstop(&error, ioerr);
  }
/*
 *  lamblo is the winning ratio for the non-basic variables 
 *  that are at their lower bounds. 
 *  lambhi is the winning ratio for the non-basic variables 
 *  that are at their upper bounds. 
 *  lambda is then the minimum of lamblo and lambhi if 
 *  outtyp=+1 ; or the maximum of lamblo and lambhi if 
 *  outtyp=-1. 
 *
 *  note:  outtyp=+1 means lambda is to be positive, 
 *         outtyp=-1 means lambda is to be negative. 
 *
 *  qlo is the index of the non-basic variable associated 
 *  with lamblo. 
 *  qhi is the index of the non-basic variable associated 
 *  with lambhi. 
 *  q is the index of the non-basic variable associated 
 *  with lambda. 
 */
  *dfeas = TRUE;
  *dunbdd = FALSE;
  *intyp = 0;
  qlo = 0;
  qhi = 0;
  *q = 0;
  pivlo = (float) 0.;
  pivhi = (float) 0.;
  *pivot = (float) 0.;
  if (*outtyp == -1) goto L100;
  lamblo = big;
  lambhi = big;
  *lambda = big;
  goto L105;

L100:
  lamblo = -big;
  lambhi = -big;
  *lambda = -big;

L105:
  for (j = 1; j <= *n; ++j) {   /* beginning of main loop. */
    jx = j;
    if ((i__2 = status[j]) < 0) {
      goto L110;
    } else if (i__2 == 0) {
      goto L120;
    } else {
      continue;
    }

L110:
    if (status[j] == -1) goto L150;
    if (status[j] == -2) goto L240;
    continue;

L120:
/*
 *  here for non-basic variables that are at their lower bounds. 
 */
/*
 *  --- data structure access. ---
 */
    cj = profit[j];
    ip = colpnt[j];
    collen = colpnt[j + 1] - ip;
    braj = (float) 0.;
    babs = (float) 0.;
    if (collen > 0) {
      i__2 = collen;
      for (ik = 1; ik <= i__2; ++ik) {
	ikx = rownos[ip + ik];
	if (ikx == 0) goto L123;
	temp = betar[ikx] * abycol[ip + ik];
	braj += temp;
	babs += abs(temp);
      }
    }

L123:
    if (abs(braj) < zl || abs(braj) < zl * babs) braj = (float) 0.;
    if (*outtyp == 1 && braj >= 0.) continue;
    if (*outtyp == -1 && braj <= 0.) continue;
    uzaj = (float) 0.;
    zabs = (float) 0.;
    if (collen > 0) {
      i__2 = collen;
      for (ik = 1; ik <= i__2; ++ik) {
	ikx = rownos[ip + ik];
	if (ikx == 0) goto L125;
	temp = uzero[ikx] * abycol[ip + ik];
	uzaj += temp;
	zabs += abs(temp);
      }
    }

L125:
    if (abs(uzaj) < zl || abs(uzaj) < zl * zabs) uzaj = (float) 0.;
/*
 *  --- end of data structure access. ---
 */
    dj = cj - uzaj;
    if (abs(dj) < zlc) dj = (float) 0.;
    if (dj > 0.) goto L240;
    temp = dj / braj;
    if (abs(temp) < zl) temp = (float) 0.;
    if (*outtyp == -1) goto L140;
    if (temp > lamblo) continue;

L130:
    if (temp == lamblo && abs(braj) < abs(pivlo)) continue;
    lamblo = temp;
    qlo = j;
    pivlo = braj;
    continue;

L140:
    if (temp < lamblo) continue;
    goto L130;

L150:
/*
 *  here for non-basic variables that are at their upper bounds. 
 */
/*
 *  --- data structure access. ---
 */
    cj = profit[j];
    ip = colpnt[j];
    collen = colpnt[j + 1] - ip;
    braj = (float) 0.;
    babs = (float) 0.;
    if (collen > 0) {
      i__2 = collen;
      for (ik = 1; ik <= i__2; ++ik) {
	ikx = rownos[ip + ik];
	if (ikx == 0) goto L153;
	temp = betar[ikx] * abycol[ip + ik];
	braj += temp;
	babs += abs(temp);
      }
    }

L153:
    if (abs(braj) < zl || abs(braj) < zl * babs) braj = (float) 0.;
    if (*outtyp == 1 && braj <= 0.) continue;
    if (*outtyp == -1 && braj >= 0.) continue;
    uzaj = (float) 0.;
    zabs = (float) 0.;
    if (collen > 0) {
      i__2 = collen;
      for (ik = 1; ik <= i__2; ++ik) {
	ikx = rownos[ip + ik];
	if (ikx == 0) goto L155;
	temp = uzero[ikx] * abycol[ip + ik];
	uzaj += temp;
	zabs += abs(temp);
      }
    }

L155:
    if (abs(uzaj) < zl || abs(uzaj) < zl * zabs) uzaj = (float) 0.;
/*
 * --- end of data structure access. ---
 */
    dj = cj - uzaj;
    if (abs(dj) < zlc) dj = (float) 0.;
    if (dj < 0.) goto L240;
    temp = dj / braj;
    if (abs(temp) < zl) temp = (float) 0.;
    if (*outtyp == -1) goto L170;
    if (temp > lambhi) continue;

L160:
    if (temp == lambhi && abs(braj) < abs(pivhi)) continue;
    lambhi = temp;
    qhi = j;
    pivhi = braj;
    continue;

L170:
    if (temp < lambhi) continue;
    goto L160;
  }             /* end of main loop */
  if (*outtyp == -1) goto L210;
/*
 *  here if the leaving variable is going to be increased to its lower bound. 
 */
  if (lamblo >= *lambda) goto L190;
  *lambda = lamblo;
  *q = qlo;
  *pivot = pivlo;
  *intyp = 1;

L190:
  if (lambhi >= *lambda) goto L200;
  *lambda = lambhi;
  *q = qhi;
  *pivot = pivhi;
  *intyp = -1;

L200:
  goto L230;

L210:
/*  
 *  here if the leaving variable is going to be decreased to its upper bound. 
 */
  if (lamblo <= *lambda) goto L220;
  *lambda = lamblo;
  *q = qlo;
  *pivot = pivlo;
  *intyp = 1;

L220:
  if (lambhi <= *lambda) goto L230;
  *lambda = lambhi;
  *q = qhi;
  *pivot = pivhi;
  *intyp = -1;

L230:
  if (*q == 0 && *intyp == 0) *dunbdd = TRUE;
  return;

L240:     /* here if the current basis is found to be not dual feasible. */
  *dfeas = FALSE;
  *q = jx;
  fprintf(ioerr, "fdchq...j= %ld status=%ld dj=%16.8f\n", *q, status[*q], dj);
  return;
}				/* fdchq */

/* ============================================================ xdchr  === 
 *     *****purpose: 
 *     this routine determines the variable to leave the 
 *     basis for a dual simplex pivot. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     m           is the number of constraints. 
 *     nrej        the number of entries in the reject list. 
 *     reject      a list of rows that may not be chosen as the 
 *                 pivot row. 
 *     on output: 
 *     gr          is the rate at which the dual objective function 
 *                 will decrease as variable basis(r) leaves 
 *                 the basis.  it is also the maximum primal 
 *                 violation. 
 *     outtyp      +1 means the leaving variable is going to its 
 *                    lower bound; 
 *                 -1 means the leaving variable is going to its 
 *                    upper bound; 
 *     r           the position of the leaving variable, 
 *                 i.e., the index of the variable leaving the basis 
 *                 is basis(r). 
 *
 *     note: if the current basis is primal feasible, 
 *     the output will be gr=0.0, outtyp=0, and r=0 
 *     *****application and usage restrictions: 
 *     *****algorithm notes: 
 *     the rows listed in reject are not to be chosen. 
 *     this is part of the pivot rejection mechanism 
 *     for the dual simplex method.  these rows have already 
 *     been tried but the implied pivot elements were too 
 *     small. 
 *
 */
void xdchr(baslb, basub, gr, ioerr, m, maxm, nrej, outtyp, r,
           reject, xbzero)
double *baslb, *basub, *gr;
FILE *ioerr;
long *m, *maxm, *nrej, *outtyp, *r, *reject;
double *xbzero;
{
/*
 *  f2c generated locals
 */
  long i__2;

/*
 *  Local variables
 */
  double glow;
  long rlow, i, k;
  double ghigh;
  long rhigh, error;

/*
 *  Subroutines called
 */  
  void xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --xbzero;
  --reject;
  --basub;
  --baslb;

/* ------------------- Function body ------------------- */
  if (*m > 0 && *m <= *maxm) goto L90;
  error = 1;
  fprintf(ioerr, "xdchr      %ld\n", *m);
  xstop(&error, ioerr);

L90:
/*
 *  glow is the maximum absolute violation among basic 
 *  variables that are below their lower bounds. 
 *  ghigh is the maximum absolute violation among basic 
 *  variables that are above their upper bounds. 
 *  gr is the maximum of glow and ghigh. 
 *  rlow is the row index associated with glow. 
 *  rhigh is the row index associated with ghigh. 
 *  r is the row index associated with gr. 
 */
  glow = (float) 0.;
  ghigh = (float) 0.;
  *gr = (float) 0.;
  rlow = 0;
  rhigh = 0;
  *r = 0;
  *outtyp = 0;

  for (i = 1; i <= *m; ++i) {  /* main loop begins here. */
    if (xbzero[i] >= baslb[i]) goto L110;
/*
 *  here for basic variables that are below their lower bounds.  
 */
    if (baslb[i] - xbzero[i] <= glow) goto L120;
    if (*nrej == 0) goto L106;
    i__2 = *nrej;
    for (k = 1; k <= i__2; ++k)
      if (reject[k] == i) goto L120;

L106:
    glow = baslb[i] - xbzero[i];
    rlow = i;
    goto L120;

L110:
    if (xbzero[i] <= basub[i]) goto L120;
/*
 *  here for basic variables that are above their upper bounds.  
 */
    if (xbzero[i] - basub[i] <= ghigh) goto L120;
    if (*nrej == 0) goto L116;
    i__2 = *nrej;
    for (k = 1; k <= i__2; ++k)
      if (reject[k] == i) goto L120;

L116:
    ghigh = xbzero[i] - basub[i];
    rhigh = i;

L120:
    ;
  }    /* end of main loop. */

/*
 *  now compare glow and ghigh.  unless the current
 *  basis is primal feasible, the variable to leave the 
 *  basis will be either basis(rlow) or basis(rhigh).
 */
  if (glow < zl) goto L130;
  *gr = glow;
  *r = rlow;
  *outtyp = 1;

L130:
  if (ghigh < zl) goto L140;
  if (ghigh < *gr) goto L140;
  *gr = ghigh;
  *r = rhigh;
  *outtyp = -1;

L140:
  return;
}				/* xdchr */

/* ============================================================ xdph2  === 
 *     *****purpose:
 *     this routine performs dual simplex pivots until a
 *     termination condition is reached.  the starting
 *     solution is assumed to be dual feasible.
 *     this routine therefore implements a 'phase 2'
 *     for the dual simplex method.
 *     *****argument description:
 *     see xmp dictionary for arguments not described here.
 *     on input:
 *     betar       is used to hold row r of the basis inverse,
 *                 where r is the position of the variable basis(r)
 *                 that is leaving the basis.
 *     factit      is the number of iterations performed since
 *                 the last factorization.
 *     factor      is the re-factorization frequency.
 *     m           is the number of constraints.
 *     n           is the number of variables (total, including
 *                 slacks and artificials).
 *     print       specifies the level of printing desired:
 *                 0 means error messages only;
 *                 1 means termination condition messages;
 *                 2 means print the objective function value
 *                   after each basis re-factorization;
 *                 3 means log information at every iteration.
 *     z           is the value of the objective function.
 *     on output:
 *     dfeasq      if a dual infeasible column is detected,
 *                 during the dual simplex method,
 *                 then dfeasq is the index of the corresponding
 *                 primal variable.
 *     dterm       is the termination code for the dual
 *                 simplex method:
 *                 1 means optimal solution found;
 *                 2 means the dual is unbounded;
 *                 3 means dual feasibility lost;
 *                 4 means the presumed optimal solution
 *                   does not satisfy the accuracy check;
 *                 5 means problem abandoned.
 *     dunbr       if the dual problem is unbounded,
 *                 then dunbr is the row in which the
 *                 unbounded condition was detected.
 *     factit      is the number of iterations performed since
 *                 the last factorization.
 *     iter        is the number of iterations performed.
 * 
 * 
 *     the last solution obtained is contained in the arrays:
 *     bascb, basis, baslb, basub, status, uzero,
 *     xbzero, and z
 * 
 * 
 *     *****application and usage restrictions:
 * 
 *     this routine has been modified to use
 *     fdchq, which is the fast version of xdchq
 * 
 *     *****algorithm notes:
 *     the following are scratch arrays with respect to
 *     this routine.   that is, they must be provided by the
 *     calling program, but they do not have to be set.
 *          betar,cola,coli,yq
 * 
 * 
 *     for dual simplex pivots, the sign of the
 *     pivot element is given by the following table:
 * 
 *                  outtyp
 *            +1                -1
 *     -----------------------------------
 *     i              i                  i
 *     i      -       i        +         i   +1
 *     i              i                  i
 *     -----------------------------------         intyp
 *     i              i                  i
 *     i      +       i        -         i   -1
 *     i              i                  i
 *     -----------------------------------
 * 
 * 
 *     theta   is the amount of change in the primal variable
 *             entering the basis.
 *     gr      is the rate of change of the dual objective
 *             function (it is also the maximum primal
 *             violation...see xdchr).
 *     pivot   is the pivot element.
 * 
 * 
 *     if intyp=+1 and outtyp=+1, then
 *     theta = -gr/pivot   which is positive.
 * 
 *     if intyp=+1 and outtyp=-1, then
 *     theta = gr/pivot   which is positive.
 * 
 *     if intyp=-1 and outtyp=+1, then
 *     theta = gr/pivot   which is positive.
 * 
 *     if intyp=-1 and outtyp=-1, then
 *     theta = -gr/pivot   which is positive.
 * 
 *     thus in all cases theta is positive, and we
 *     may take  theta = dabs ( gr/pivot ).
 * 
 * 
 */
void xdph2(b, bascb, basis, baslb, basub, betar, bndtyp, bound, cola, coli, 
           colmax, dfeasq, dterm, dunbr, factit, factor, ioerr, iolog, iter, 
           m, mapi, mapr, maxm, maxn, memi, memr, n, ntype2, print, status, 
           uzero, xbzero, yq, z)
double *b, *bascb;
long *basis;
double *baslb, *basub, *betar;
long *bndtyp;
double *bound, *cola;
FILE *iolog;
FILE *ioerr;
long *coli, *colmax, *dfeasq, *dterm, *dunbr, *factit, *factor, *iter;
long *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *ntype2, *print, *status;
double *uzero, *xbzero, *yq, *z;
{
/*
 *  f2c generated locals
 */
  long i__1;
  double d__1;

/*
 *  Local variables
 */
  long nrej;
  long i, fcode, q, r;
  long dfeas;
  long leave, ucode;
  double theta;
  double pivot;
  long intyp;
  double cj, lambda;
  long ik;
  double dq, gr, lq;
  long dunbdd;
  double uq;
  long collen, reject[10];
  long mi1, mi2, mi3, mr3, mr4, outtyp, ikx;

/*
 *  Subroutines called
 */  
  void xlog(), fdchq(), xfact(), xdchr(), xupdx();
  void xgetaj(), xbcomp(), xbtran(), xgetub(), xftran(), xupdat();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --betar;
  --basub;
  --baslb;
  --basis;
  --bascb;
  --b;

/* ------------------- Function body ------------------- */
  *iter = 0;
  nrej = 0;
  mi1 = mapi[1];
  mi2 = mapi[2];
  mi3 = mapi[3];
  mr3 = mapr[3];
  mr4 = mapr[4];

L100:
/*
 *  determine the variable to leave the basis. 
 */
  xdchr(&baslb[1], &basub[1], &gr, ioerr, m, maxm, &nrej, &outtyp, &r,
	reject, &xbzero[1]);
  if (r == 0) goto L300;
  leave = basis[r];
/*
 *  variable basis(r) will leave the basis. 
 *
 *  compute row r of the basis inverse.  this is the direction of the 
 *  move in dual space. 
 */
  for (i = 1; i <= *m; ++i) {
    betar[i] = (float) 0.;
  }
  betar[r] = (float) 1.;
  xbtran(ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1], &betar[1]);
/*
 *  determine the variable to enter the basis.  
 */
  fdchq(&betar[1], &cola[1], &coli[1], colmax, &dfeas, &intyp, ioerr, &
	lambda, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &
	outtyp, &pivot, &q, &status[1], &dunbdd, &uzero[1], &memr[mr3], &
	memr[mr4], &memi[mi1], &memi[mi2], &memi[mi3]);

  if (!dfeas) goto L500;
  if (dunbdd) goto L400;
/*
 *  pivot rejection mechanism 
 */
  if (abs(pivot) > eps3) goto L115;
  ++nrej;
  if (nrej <= 10) goto L112;
  fprintf(ioerr, "xdph2...problem abandoned...too many rejected pivots\n");
  *dterm = 5;
  return;

L112:
  fprintf(ioerr, "xdph2...iteration %ld     pivot rejected, ", *iter);
  fprintf(ioerr, "row=%ld     pivot=%16.8f\n", r, pivot);
  reject[nrej - 1] = r;
  goto L100;

L115:
  nrej = 0;
/*
 *  variable q will enter the basis.
 *  load the incoming column into yq to be ftran'ed. 
 */
  xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &q, &mapi[1], 
         &mapr[1], &memi[1], &memr[1]);
  for (i = 1; i <= *m; ++i) yq[i] = (float) 0.;
  if (collen > 0) {
    i__1 = collen;
    for (ik = 1; ik <= i__1; ++ik) {
      ikx = coli[ik];
      yq[ikx] = cola[ik];
    }
  }
  xftran(&yq[1], ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1]);
/*
 *  update the basis...exchange the entering and leaving columns. 
 */
  xupdat(ioerr, m, &mapi[1], &mapr[1], &memi[1], &memr[1], &r, &ucode);
/*
 *  update the array of objective coefficients of the basic variables. 
 */
  bascb[r] = cj;
/*
 *  get the lower and upper bounds for the entering variable, q. 
 */
  switch ((int) *bndtyp) {
  case 1:  goto L140;
  case 2:  goto L150;
  case 3:  goto L170;
  case 4:  goto L170;
  }

L140:   /* here for the standard case, zero and +infinity. */
  lq = (float) 0.;
  uq = big;
  goto L180;

L150:   /* here if all of the structurals have a common bound. */
  lq = (float) 0.;
  uq = *bound;
  if (q > *ntype2) uq = big;
  goto L180;

L170:  /* here for general bounds. */
  xgetub(bndtyp, ioerr, &q, &lq, &mapi[1], &mapr[1], &memi[1], &memr[1], &uq);

L180:
/*
 *  compute theta -- the amount of change in the incoming variable.  
 *  (theta is always non-negative) 
 */
  theta = (d__1 = gr / pivot, abs(d__1));
  if (theta < zl) theta = (float) 0.;
/*
 *  compute dq -- the relative profit of the incoming variable. 
 */
  dq = lambda * pivot;
  if (abs(dq) < zlc) dq = (float) 0.;
/*
 *  update the values of the basic variables and the value of the 
 *  objective function. 
 */
  xupdx(&basis[1], &baslb[1], &basub[1], &dq, &intyp, &lq, m, maxm, maxn,
	n, &outtyp, &q, &r, &status[1], &theta, &uq, &xbzero[1], &yq[1], z);
/*
 *  update the dual variables.  
 */
  for (i = 1; i <= *m; ++i) {
    uzero[i] += lambda * betar[i];
    if ((d__1 = uzero[i], abs(d__1)) < zlc) uzero[i] = (float) 0.;
  }

  ++(*iter);
  if (*print == 3)
    xlog(&dq, &intyp, iolog, iter, &leave, &outtyp, &pivot, &q, &r, &theta, z);
/*
 *  re-factor the basis if necessary. 
 */
  ++(*factit);
  if (*factit <= *factor) goto L100;
  xfact(&bascb[1], &basis[1], &baslb[1], &basub[1], &cola[1], &coli[1], colmax,
        &fcode, ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1]);
  if (fcode != 1) exit(1);
/*
 *  write out the current basis and status lists in case a re-start
 *  is necessary.
 */
/*
  if (iobsf != 0) {long j;
    for (i = 1, i__1 = 1; i <= *m; ++i, ++i__1) {
      fprintf(iobsf, "%6ld", basis[i]);
      if (!(i__1 % 10)) fprintf(iobsf, "\n");
    }
    if ((i__1 - 1) % 10) fprintf(iobsf, "\n");
    for (j = 1, i__1 = 1; j <= *n; ++j, ++i__1) {
      fprintf(iobsf, "%6ld", status[j]);
      if (!(i__1 % 10)) fprintf(iobsf, "\n");
    }
    if ((i__1 - 1) % 10) fprintf(iobsf, "\n");
    rewind(iobsf);
  }
*/
  *factit = 0;
/*
 *  re-compute the basic variables using the re-factored basis. 
 */
  xbcomp(&b[1], &bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax,
       ioerr, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, 
       &status[1], &xbzero[1], z);
/*
 *  re-compute the dual variables using the re-factored basis. 
 */
  for (i = 1; i <= *m; ++i) uzero[i] = bascb[i];
  xbtran(ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1], &uzero[1]);

  if (*print == 2) fprintf(iolog, "iteration=%6ld     dual objective=%16.8f\n",
                           *iter, *z);
  goto L100;

L300: /* no further improvement in the dual objective can be made. */
  *dterm = 1;
  if (*print == 0) return;
  fprintf(iolog, "xdph2 ...optimal solution found\n");
  return;

L400:        /* come here if an unbounded condition is detected. */
  *dterm = 2;
  *dunbr = r;
  if (*print == 0) return;
  fprintf(iolog, "xdph2 ...the dual problem is unbounded     row %ld\n", r);
  return;

L500:        /* come here if an infeasibility is detected. */
  *dterm = 3;
  *dfeasq = q;
  if (*print == 0) return;
  fprintf(iolog, "xdph2 ...dual feasibility lost     column %ld\n", q);
  return;
}				/* xdph2 */

/* ============================================================ xdual  === 
 *     *****purpose: 
 *     this routine is the top level routine for the 
 *     dual simplex method. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     factor      is the re-factorization frequency. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     print       specifies the level of printing desired: 
 *                  0 means error messages only; 
 *                  1 means termination condition messages; 
 *                  2 means log information at every iteration. 
 *     z           is the value of the objective function. 
 *     on output: 
 *     dfeasq      if a dual infeasible column is detected, 
 *                 during the dual simplex method, 
 *                 then dfeasq is the index of the corresponding 
 *                 primal variable. 
 *                 (dterm = 3 or 5) 
 *     dterm       is the termination code for the dual 
 *                 simplex method: 
 *                 1 means optimal solution found; 
 *                 2 means the dual is unbounded; 
 *                 3 means dual feasibility lost; 
 *                 4 means the presumed optimal solution 
 *                   does not satisfy the accuracy check; 
 *                 5 means problem abandoned; 
 *                 6 means that it was not possible to make 
 *                   a dual feasible start. 
 *     dunbr       if the dual problem is unbounded, 
 *                 then dunbr is the row in which the 
 *                 unbounded condition was detected. 
 *                 (dterm = 2) 
 *     iterd       is the number of dual simplex iterations 
 *                 performed. 
 *
 *     the following arrays contain the last solution obtained: 
 *     bascb,basis,baslb,basub,status,uzero,xbzero,z 
 *     *****application and usage restrictions: 
 *     *****algorithm notes: 
 *     the following are scratch arrays with respect to 
 *     this routine.  that is, they must be provided by the 
 *     calling program, but they do not have to be set. 
 *        betar,cola,coli,yq 
 *
 *     the initial basis should be dual feasible. 
 *     we make a dual feasible start as follows: 
 *     compute the relative profit for each non-basic 
 *     variable.     if the relative profit is: 
 *       1) positive, then the variable is set at its upper 
 *          bound (which must be finite); 
 *       2) negative, then the variable is set at its lower 
 *          bound (which must be finite); 
 *       3) zero, then the variable is, by convention, 
 *          set at its lower bound (which must be finite). 
 *
 *     any attempt to set a variable at a non-finite 
 *     bound means that the initial basis is not dual 
 *     feasible and we return with dterm=6. 
 *     dfeasq is set to the index of the offending variable. 
 *     note: all free variables must be in the basis 
 *     before xdual is called, since they cannot be set at either 
 *     bound. 
 *
 *     important note:  you can always make a dual feasible start 
 *                      by declaring sufficiently large, but finite, 
 *                      upper bounds on all of the variables. 
 *                      (the lower bounds, if not zero, must also 
 *                      be finite of course.) 
 *
 */
void xdual(b, bascb, basis, baslb, basub, betar, bndtyp, bound, cola, coli, 
           colmax, dfeasq, dterm, dunbr, factor, ioerr, iolog, iterd, m, 
           mapi, mapr, maxm, maxn, memi, memr, n, ntype2, print, status, 
           uzero, xbzero, yq, z)
double *b, *bascb;
long *basis;
double *baslb, *basub, *betar;
long *bndtyp;
double *bound, *cola;
FILE *iolog;
FILE *ioerr;
long *coli, *colmax, *dfeasq, *dterm, *dunbr, *factor, *iterd, *m, *mapi;
long *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *ntype2, *print, *status;
double *uzero, *xbzero, *yq, *z;
{
/*
 *  f2c generated locals
 */
  long i__2;

/*
 *  Local variables
 */
  double uzaj;
  long posn;
  long i, j, fcode;
  long error;
  double cj, dj, lj;
  long dblchk;
  double uj;
  long dindex, collen, factit;
  long pindex;
  double dtoler, derror;
  double ptoler, perror;
  long dok, pok;

/*
 *  Subroutines called
 */  
  void xdot(), xdph2(), xfact(), xstop(), xcheck(), xgetaj(), xbcomp();
  void xgetub(), xbtran();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --betar;
  --basub;
  --baslb;
  --basis;
  --bascb;
  --b;

/* ------------------- Function body ------------------- */
  if (*m > 0 && *m <= *maxm) goto L100;
  error = 1;
  fprintf(ioerr, "xdual      %ld\n", *m);
  xstop(&error, ioerr);

L100:
  if (*n > 0 && *n <= *maxn) goto L110;
  error = 2;
  fprintf(ioerr, "xdual      %ld\n", *n);
  xstop(&error, ioerr);

L110:
  *iterd = 0;
  factit = 0;
  dblchk = TRUE;
/*
 *  beginning of loop for setting each non-basic variable at the correct 
 *  bound for a dual feasible start. 
 */
  for (j = 1; j <= *n; ++j) {
    if ((i__2 = status[j]) < 0) {
      goto L130;
    } else if (i__2 == 0) {
      goto L140;
    } else {
      continue;
    }

L130:
    if (status[j] == -1) goto L140;
/*
 *  skip artificial variables and fixed variables. 
 */
    if (status[j] <= -3) continue;
/*
 *  here for free variables, status=-2 
 *  all free variables must be made basic before calling xdual. 
 */
    *dfeasq = j;
    *dterm = 6;
    goto L300;

L140:
/*
 *  compute the relative profit for variable j 
 */
    xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1]);

    xdot(&cola[1], &coli[1], &collen, colmax, maxm, &uzero[1], &uzaj);

    dj = cj - uzaj;
    if (abs(dj) < zlc) dj = (float) 0.;
/*
 *  get the bounds for variable j 
 */
    switch ((int) *bndtyp) {
    case 1:  goto L150;
    case 2:  goto L160;
    case 3:  goto L180;
    case 4:  goto L180;
    }

L150:          /* here for the standard case, zero and +infinity */
    lj = (float) 0.;
    uj = big;
    goto L190;

L160:          /* here if all non-free structurals have a common bound. */
    lj = (float) 0.;
    uj = *bound;
    if (j > *ntype2) uj = big;
    goto L190;

L180:          /* here for general bounds. */
    xgetub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], &memr[1],&uj);

L190:
/* 
 *  now set variable j to the correct bound, checking to make sure that the 
 *  bound is finite.  
 */
    if (dj <= 0.) goto L200;
    else goto L210;

L200:    /* here for variables which are to be set at their lower bound. */
    if (lj <= -big) goto L220;
    status[j] = 0;
    continue;

L210:    /* here for variables which are to be set at their upper bound. */
    if (uj >= big) goto L220;
    status[j] = -1;
    continue;

L220:          /* here if a variable is to be set to a non-finite bound. */
    *dfeasq = j;
    *dterm = 6;
    goto L300;
  }   /* end of loop for setting the non-basic variables. */
/*
 *  re-compute the values of the basic variables and the value of the 
 *  objective function, since some non-basic variables may have changed bound.
 */
  xbcomp(&b[1], &bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax,
         ioerr, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, 
         &status[1], &xbzero[1], z);
/*
 *  for each basic artificial variable, change the upper and lower bounds 
 *  to zero.   this will cause it to be forced out of the basis. 
 */
  for (i = 1; i <= *m; ++i) {
    posn = basis[i];
    if (status[posn] != -3) continue;
    basub[i] = (float) 0.;
    baslb[i] = (float) 0.;
  }
/*
 *  now do dual simplex iterations until a termination condition is reached. 
 */
  xdph2(&b[1], &bascb[1], &basis[1], &baslb[1], &basub[1], &betar[1],
	bndtyp, bound, &cola[1], &coli[1], colmax, dfeasq, dterm, dunbr, &
	factit, factor, ioerr, iolog, iterd, m, &mapi[1], &mapr[1], maxm,
	maxn, &memi[1], &memr[1], n, ntype2, print, &status[1], &uzero[1],
	&xbzero[1], &yq[1], z);

  if (*dterm != 1) return;
/*
 *  factor the optimal basis. 
 */
  xfact(&bascb[1], &basis[1], &baslb[1], &basub[1], &cola[1], &coli[1],
	colmax, &fcode, ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &
	memr[1]);
  if (fcode != 1) exit(1);
/*
 *  re-compute the values of the basic variables and of the objective 
 *  function using the re-factored basis. 
 */
  xbcomp(&b[1], &bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax,
       ioerr, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &
	 status[1], &xbzero[1], z);
/*
 *  re-compute the values of the dual variables using the re-factored basis. 
 */
  for (i = 1; i <= *m; ++i) uzero[i] = bascb[i];
  xbtran(ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1], &uzero[1]);
/*
 *  check the optimal solution. 
 */
  dtoler = eps1;
  ptoler = eps2;
  xcheck(&b[1], &basis[1], bndtyp, bound, &cola[1], &coli[1], colmax, &
	 dblchk, &derror, &dindex, &dok, &dtoler, ioerr, m, &mapi[1], &
	 mapr[1], maxm, maxn, &memi[1], &memr[1], n, &perror, &pindex, &
	 pok, &ptoler, &status[1], &uzero[1], &yq[1], &xbzero[1]);

  if (!pok || !dok) *dterm = 4;
  return;

L300:
  fprintf(iolog, "xdual...can not make dual feasible start\n");
  fprintf(iolog, "because of variable %ld\n", *dfeasq);
  fprintf(iolog, "put bounds on variables or use primal method\n");
  return;
}				/* xdual */

/* ============================================================ xbcomp === 
 *     *****purpose: 
 *     this routine computes the current values of the basic 
 *     variables and the current value of the phase 2 objective 
 *     function. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     b           is the right hand side array. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     on output: 
 *     xbzero      the array containing the values of the basic 
 *                 variables. 
 *     z           is the value of (phase 2) objective function. 
 *     *****application and usage restrictions: 
 *     *****algorithm notes: 
 *     the right-hand-side is reduced to account for the non- 
 *     basic variables which are at non-zero lower and upper 
 *     bounds.  the reduced right-hand-side is then ftran'ed 
 *     against the current basis inverse. 
 *
 */
void xbcomp(b, bascb, bndtyp, bound, cola, coli, colmax, ioerr, m, mapi, 
            mapr, maxm, maxn, memi, memr, n, status, xbzero, z)
double *b, *bascb;
long *bndtyp;
double *bound, *cola;
FILE *ioerr;
long *coli, *colmax, *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *status;
double *xbzero, *z;
{
/*
 *  f2c generated locals
 */
  double d__1;

/*
 *  Local variables
 */
  long i, error;
  double znb;

/*
 *  Subroutines called
 */  
  void xstop(), xbredu(), xftran();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --xbzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --bascb;
  --b;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xbcomp     %ld\n", *m);
    xstop(&error, ioerr);
  }
  if (*n < 1 || *n > *maxn) {
    error = 2;
    fprintf(ioerr, "xbcomp     %ld\n", *n);
    xstop(&error, ioerr);
  }
  *z = (float) 0.;
  znb = (float) 0.;
/*
 *  reduce the right-hand-side values to account for the non-basic variables 
 *  which are at non-zero lower and upper bounds. 
 */
  xbredu(&b[1], bndtyp, bound, &cola[1], &coli[1], colmax, ioerr, m, 
         &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &status[1], 
         &xbzero[1], &xbzero[1], &znb);

  *z += znb;
  xftran(&xbzero[1], ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1]);
/*
 *  get the objective function contribution of the basic variables,
 *  and zero out small values of the basic variables. 
 */
  for (i = 1; i <= *m; ++i) {
    if ((d__1 = xbzero[i], abs(d__1)) < zl) xbzero[i] = (float) 0.;
    *z += bascb[i] * xbzero[i];
  }
  if (abs(*z) < zlc) *z = (float) 0.;
  return;
}				/* xbcomp */

/* ============================================================ xbredu === 
 *     *****purpose: 
 *     this routine reduces the right-hand-side, b, to 
 *     take into account the non-basic variables that 
 *     are at non-zero bounds, 
 *     and to account for super-basic variables, if any. 
 *     it also computes the objective function contribution 
 *     of the non-basic variables, 
 *     and super-basic variables. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     b           is the right hand side array. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     work        is any double precision array of length 
 *                 maxm that can be used temporarily. 
 *     xbzero      the first m locations of xbzero are 
 *                 ignored.  locations past 
 *                 m must contain the values of the super- 
 *                 basic variables, if any. 
 *                 note: most routines that call xbredu will 
 *                 send work=xbzero (e.g. xbcomp) 
 *     on output: 
 *     work        contains the reduced right-hand-side, 
 *                 i. e., b minus the sum of every non-basic 
 *                 column, each multiplied by the current 
 *                 value of the corresponding variable. 
 *                 (super-basic variables also accounted for) 
 *     znb         is the phase 2 objective contribution of 
 *                 the non-basic variables. 
 *                 (super-basic variables also accounted for) 
 *
 *     *****application and usage restrictions: 
 *     this routine has been modified to allow for 
 *     super-basic variables. 
 *     a consequence of allowing for super-basic variables 
 *     is the fact that this routine must be executed even 
 *     when bndtyp=1. 
 *
 *     *****algorithm notes: 
 *     the right-hand-side is reduced to account for the non- 
 *     basic variables which are at non-zero lower and upper 
 *     bounds.  this must be done before computing the 
 *     values of the basic variables or checking the primal 
 *     solution. 
 *     (super-basic variables are also taken into account) 
 * 
 */
void xbredu(b, bndtyp, bound, cola, coli, colmax, ioerr, m, mapi, mapr, maxm, 
            maxn, memi, memr, n, status, work, xbzero, znb)
double *b;
long *bndtyp;
double *bound, *cola;
FILE *ioerr;
long *coli, *colmax, *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *status;
double *work, *xbzero, *znb;
{
/*
 *  f2c generated locals
 */
  long i__2;

/*
 *  Local variables
 */
  long i, j, jstat, error;
  double cj;
  long ik;
  double lj, uj;
  long collen;
  double tbound;
  long ikx;

/*
 *  Subroutines called
 */  
  void xstop(), xgetaj(), xgetub();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --xbzero;
  --work;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --b;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xbredu     %ld\n", *m);
    xstop(&error, ioerr);
  }
  if (*n < 1 || *n > *maxn) {
    error = 2;
    fprintf(ioerr, "xbredu     %ld\n", *n);
    xstop(&error, ioerr);
  }
  *znb = (float) 0.;
/*
 *  load the right-hand-side into the work array. 
 */
  for (i = 1; i <= *m; ++i) work[i] = b[i];
  if (*n == 0) return;
/*
 *  reduce the right-hand-side values to account for
 *  the non-basic variables which are at non-zero 
 *  lower and upper bounds. 
 *  (and to account for super-basic variables, if any) 
 */
  for (j = 1; j <= *n; ++j) {      /* start main loop. */
    if ((i__2 = status[j]) < 0) {
      goto L130;
    } else if (i__2 == 0) {
      goto L160;
    } else {
      goto L190;
    }

L130:
    if (status[j] == -2 || status[j] == -3) continue;
    if (status[j] == -4) goto L160;

L140:      /* here for variables which are at their upper bound. */
    if (*bndtyp == 1) {
      tbound = big;
    } else if (*bndtyp == 2) {
      tbound = *bound;
    } else {
      xgetub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], 
             &memr[1], &uj);
      if (uj == 0.) continue;
      tbound = uj;
    }
    if (tbound >= big) {
      fprintf(ioerr, "xbredu...variable %ld is at +infinity.\n", j);
      error = 0;
      xstop(&error, ioerr);
    }
    goto L170;

L160:          /* here for variables which are at their lower bounds. */
    if (*bndtyp != 4) continue;
    xgetub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], 
           &memr[1], &uj);
    if (lj == 0.) continue;
    if (lj <= -big) {
      fprintf(ioerr, "xbredu...variable %ld is at -infinity\n", j);
      fprintf(ioerr, "it will be flipped to its upper bound.\n");
      status[j] = -1;
      goto L140;
    }
    tbound = lj;

L170:
    xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1]);
    *znb += cj * tbound;
    if (collen > 0) {
      i__2 = collen;
      for (ik = 1; ik <= i__2; ++ik) {
	ikx = coli[ik];
	work[ikx] -= cola[ik] * tbound;
      }
    }
    continue;

L190:                  /* here for super-basic variables, if any. */
    if (status[j] <= *m) continue;
    jstat = status[j];
    tbound = xbzero[jstat];
    goto L170;
  }    /* end of main loop. */
  return;
}				/* xbredu */

/* ============================================================ xbtran === 
 *     *****purpose: 
 *     this subroutine implements the btran or backward transformation 
 *     row*(basis inverse) 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     m           is the number of constraints. 
 *     mapi        is a map of array memi. 
 *     mapr        is a map of array memr. 
 *     memi        array containing hidden integer data. 
 *     memr        array containing hidden real data. 
 *     row         is the row to be btran'ed. 
 *     on output: 
 *     row contains (input row)*(basis inverse) 
 *     *****application and usage restrictions: 
 *     this subroutine is compatible with john reid's la05 routines 
 *     for handling an lu factorization of the basis matrix.  the 
 *     'body of program' must be re-written if some other inverse 
 *     representation is used. 
 *     *****algorithm notes: 
 *     data structure for the basis inverse representation: 
 *
 *     mapi(6)    points to reid's ia constant. 
 *     mapi(7)    points to reid's ip array. 
 *     mapi(8)    points to reid's iw array. 
 *     mapi(9)    points to reid's ind array. 
 *
 *     mapr(5)    points to reid's g constant. 
 *     mapr(6)    points to reid's u constant. 
 *     mapr(7)    points to reid's w array. 
 *     mapr(8)    points to reid's a array. 
 *
 */
void xbtran(ioerr, m, mapi, mapr, maxm, memi, memr, row)
FILE *ioerr;
long *m, *mapi, *mapr, *maxm, *memi;
double *memr, *row;
{
  double g;
  long trans;
  long error;
  long mi6, mi7, mi8, mi9, mr5, mr7, mr8;

/*
 *  Subroutines called
 */  
  void la05bd(), xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --row;
  --memr;
  --memi;
  --mapr;
  --mapi;

/* ------------------- Function body ------------------- */
  trans = TRUE;
  mi6 = mapi[6];
  mi7 = mapi[7];
  mi8 = mapi[8];
  mi9 = mapi[9];
  mr5 = mapr[5];
  mr7 = mapr[7];
  mr8 = mapr[8];
  memr[mr5] = (float) 0.;
  la05bd(&memr[mr8], &memi[mi9], &memi[mi6], m, &memi[mi7], &memi[mi8], &
	 memr[mr7], &memr[mr5], &row[1], &trans);
  g = memr[mr5];
  if (g >= 0.) return;
  fprintf(ioerr, "xbtran...error return from la05b...g=%10.2f\n", g);
  error = 0;
  xstop(&error, ioerr);
  return;
}				/* xbtran */

/* ============================================================ xcheck === 
 *     *****purpose: 
 *     the purpose of this routine is to check the accuracy 
 *     of the current primal and dual solutions.  this serves 
 *     as an indirect check on the accuracy of the current 
 *     basis inverse representation.  the primal check is: 
 *     basis*(basic variables)=(reduced right-hand-side) 
 *     the right-hand-side has to be reduced to account 
 *     for the non-basic variables at non-zero bounds. 
 *     the dual check is:  (dual variables)*basis=(objective 
 *     coefficients of basic variables). 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     dblchk      .true. means check primal and dual residuals, 
 *                 .false. means check primal residuals only. 
 *     dtoler      is the tolerance to be used for the 
 *                 dual accuracy check. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     ptoler      is the tolerance to be used for the 
 *                 primal accuracy check. 
 *     work        is any double precision array of length maxm that can
 *
 *                 be used temporarily. 
 *     on output: 
 *     derror      is the absolute value of the maximum dual 
 *                 residual. 
 *     dindex      is the index of the column where the 
 *                 maximum dual residual occurs.  the error in 
 *                 column basis(dindex) is derror. 
 *     dok         .true. if derror is smaller than dtoler; 
 *                 .false. otherwise. 
 *     perror      is the absolute value of the maximum 
 *                 primal residual. 
 *     pindex      is the index of the row where the maximum 
 *                 primal residual occurs. 
 *     pok         .true. if perror is smaller than ptoler; 
 *                 .false. otherwise. 
 *     work        contains the absolute values of the primal 
 *                 residuals. 
 */
void xcheck(b, basis, bndtyp, bound, cola, coli, colmax, dblchk, derror, 
            dindex, dok, dtoler, ioerr, m, mapi, mapr, maxm, maxn, memi, 
            memr, n, perror, pindex, pok, ptoler, status, uzero, work,
	    xbzero)
double *b;
long *basis, *bndtyp;
double *bound, *cola;
long *coli, *colmax;
long *dblchk;
double *derror;
long *dindex;
long *dok;
double *dtoler;
FILE *ioerr;
long *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n;
double *perror;
long *pindex;
long *pok;
double *ptoler;
long *status;
double *uzero, *work, *xbzero;
{
/*
 *  f2c generated locals
 */
  long i__2;
  double d__1;

/*
 *  Local variables
 */
  long i, j, error;
  double cj, dj;
  long ik;
  double dlevel;
  long collen;
  double plevel;
  double znb;
  long ikx;

/*
 *  Subroutines called
 */  
  void xstop(), xgetaj(), xbredu();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --xbzero;
  --work;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --basis;
  --b;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xcheck     %ld\n", *m);
    xstop(&error, ioerr);
  }
  *pok = TRUE;
  *dok = TRUE;
  *perror = (float) 0.;
  *derror = (float) 0.;
  *pindex = 0;
  *dindex = 0;
  plevel = (float) 0.;
  dlevel = (float) 0.;
/*
 *  reduce the right-hand-side to account for the non-basic variables at 
 *  non-zero bounds. 
 */
  xbredu(&b[1], bndtyp, bound, &cola[1], &coli[1], colmax, ioerr, m, 
         &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &status[1], 
         &work[1], &xbzero[1], &znb);

  for (i = 1; i <= *m; ++i) {  /* beginning of main loop. */
    j = basis[i];
    xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1]);
    dj = cj;
    if (collen > 0) {
      i__2 = collen;
      for (ik = 1; ik <= i__2; ++ik) {
	ikx = coli[ik];
	work[ikx] -= cola[ik] * xbzero[i];
	dj -= uzero[ikx] * cola[ik];
      }
    }
    if (!(*dblchk)) continue;
/*
 *  check the dual residual, relative profit of basic variable should be zero.
 */
    dj = abs(dj);
    if (dj <= *derror) continue;
    *derror = dj;
    *dindex = basis[i];
    dlevel = abs(cj);
  }      /* end of main loop. */
/*
 *  check the primal residuals. 
 */
  for (i = 1; i <= *m; ++i) {
    work[i] = (d__1 = work[i], abs(d__1));
    if (work[i] <= *perror) continue;
    *perror = work[i];
    *pindex = i;
    plevel = (d__1 = b[i], abs(d__1));
  }
  if (*perror > *ptoler * (plevel + (float) 1.)) *pok = FALSE;
  if (!(*pok))
    fprintf(ioerr, "xcheck...maximum primal residual: %ld     %17.10f\n",
	    *pindex, *perror);
  if (!(*dblchk)) return;
  if (*derror > *dtoler * (dlevel + (float) 1.)) *dok = FALSE;
  if (!(*dok)) 
    fprintf(ioerr, "xcheck...maximum dual residual: %ld     %17.10f\n",
	    *dindex, *derror);
  return;
}				/* xcheck */

/* ============================================================ xchuzr === 
 *     *****purpose: 
 *     this subroutine determines the variable to leave the 
 *     basis for a primal simplex pivot. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     intyp       +1 means the entering variable is increasing 
 *                    from its lower bound. 
 *                 -1 means the entering variable is decreasing 
 *                    from its upper bound. 
 *     lq          is the lower bound on the entering variable. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     q           the index of the entering variable. 
 *                 (used only when checking the status of the 
 *                 entering variable to see if it is a free variable) 
 *     uq          is the upper bound for the entering variable. 
 *     yq          contains the unpacked and updated column for 
 *                 the entering variable. 
 *     on output: 
 *     outtyp      +1 means the leaving variable is going to its 
 *                    lower bound; 
 *                 -1 means the leaving variable is going to its 
 *                    upper bound; 
 *                  0 means the entering and leaving variables are 
 *                    the same. 
 *     pivot       is the pivot element. 
 *     r           the position of the leaving variable, 
 *                 i.e., the index of the variable leaving the basis 
 *                 is basis(r). 
 *                 if outtyp=0, then r=0. 
 *                 if an infeasibility is detected (i.e. a basic 
 *                 variable out of bounds), then r=-1. 
 *     theta       is the amount of change in the variable 
 *                 entering the basis, i.e. the value of the 
 *                 winning ratio from the primal ratio test. 
 *     unbdd       .true. if no variable hits a finite 
 *                 bound as a result of the current move; 
 *                 .false. otherwise.  
 */
void xchuzr(basis, baslb, basub, intyp, ioerr, lq, m, maxm, maxn, n, outtyp, 
            phase, pivot, q, r, status, theta, unbdd, uq, xbzero, yq)
long *basis;
double *baslb, *basub;
FILE *ioerr;
long *intyp;
double *lq;
long *m, *maxm, *maxn, *n, *outtyp, *phase;
double *pivot;
long *q, *r, *status;
double *theta;
long *unbdd;
double *uq, *xbzero, *yq;
{
/*
 *  f2c generated locals
 */
  double d__1;

/*
 *  Local variables
 */
  double temp;
  long i, error, r1, r2;
  double theta1, theta2, theta3;
  double pivot1, pivot2;

/*
 *  Subroutines called
 */  
  void xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --status;
  --basub;
  --baslb;
  --basis;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xchuzr %ld\n", *m);
    xstop(&error, ioerr);
  }
/*
 *  initialize. 
 *  theta1 is the minimum ratio for the basic variables that 
 *  are heading toward their lower bound. 
 *  theta2 is the minimum ratio for the basic variables that 
 *  are heading toward their upper bound. 
 *  theta3 is the distance to the opposite bound for the 
 *  entering variable. 
 *  r1 is the row index associated with theta1. 
 *  r2 is the row index associated with theta2. 
 *  pivot1 is the pivot element associated with theta1. 
 *  pivot2 is the pivot element associated with theta2. 
 */
  theta1 = big;
  theta2 = big;
  theta3 = big;
  if (status[*q] != -2) theta3 = *uq - *lq;
  if (theta3 < 0.) goto L270;
  *outtyp = 0;
  *r = 0;
  r1 = 0;
  r2 = 0;
  *pivot = (float) 1.;
  pivot1 = (float) 0.;
  pivot2 = (float) 0.;
  *unbdd = FALSE;
  *theta = theta3;
  if (*theta < zl) return;
/*
 *  flip the signs of the entering column if the entering 
 *  variable is coming down from its upper bound. 
 */
  if (*intyp == -1) for (i = 1; i <= *m; ++i) yq[i] = -yq[i];
  for (i = 1; i <= *m; ++i) {  /* main loop begins here. */
    if ((d__1 = yq[i], abs(d__1)) < zl) yq[i] = (float) 0.;
    if ((d__1 = yq[i]) < 0.) {
      goto L150;
    } else if (d__1 == 0) {
      continue;
    } else {
      goto L130;
    }

L130:
/*
 *  come here for basic variables which will decrease. 
 *
 *  update theta1. 
 */
    if (baslb[i] <= -big) {
      if (xbzero[i] <= basub[i]) continue;
      temp = xbzero[i] - basub[i];
    } else {
      temp = xbzero[i] - baslb[i];
    }
    if (abs(temp) < eps2) temp = (float) 0.;
/*
 *  if this basic variable is starting below its lower bound, 
 *  then we are in trouble if it is phase 2. 
 */
    if (temp < 0.) {
      if (*phase == 2) {
	*r = -1;
	goto L190;
      } else {
	continue;
      }
    }
    temp /= yq[i];
    if (temp < zl) temp = (float) 0.;
    if (temp > theta1 + zl) continue;
    if (temp < theta1 - zl) goto L140;
/*
 *  resolve ties in favor of larger pivot element. 
 */
    if (yq[i] <= pivot1) continue;

L140:
    theta1 = temp;
    r1 = i;
    pivot1 = yq[i];
    continue;

/*
 *  come here for basic variables which will increase.
 *
 *  update theta2. 
 */
L150:
    if (basub[i] >= big) {
      if (xbzero[i] >= baslb[i]) continue;
      temp = baslb[i] - xbzero[i];
    } else {
      temp = basub[i] - xbzero[i];
    }
    if (abs(temp) < eps2) temp = (float) 0.;
/*
 *  if this basic variable is starting above its upper bound, then we are 
 *  in trouble if it is phase2. 
 */
    if (temp < 0.) {
      if (*phase == 2) {
	*r = -1;
	goto L190;
      } else {
	continue;
      }
    }
    temp /= -yq[i];
    if (temp < zl) temp = (float) 0.;
    if (temp > theta2 + zl) continue;
    if (temp < theta2 - zl) goto L160;
/*
 *  resolve ties in favor of larger pivot element note:  yq(i) and pivot2 
 *  are both negative. 
 */
    if (yq[i] >= pivot2) continue;

L160:
    theta2 = temp;
    r2 = i;
    pivot2 = yq[i];
  }     /* end of main loop. */
/*
 *  now compare theta1, theta2, and theta3. 
 *  determine which variable leaves the basis.
 *  it must be basis(r1), basis(r2),
 *  or the entering variable q itself. 
 */
  if (theta1 >= *theta) goto L180;
  if (r1 == 0) goto L180;
  *theta = theta1;
  *r = r1;
  *pivot = pivot1;
  *outtyp = 1;
  if (baslb[*r] <= -big) *outtyp = -1;

L180:
  if (theta2 >= *theta) goto L190;
  if (r2 == 0) goto L190;
  *theta = theta2;
  *r = r2;
  *pivot = pivot2;
  *outtyp = -1;
  if (basub[*r] >= big) *outtyp = 1;

L190:
/*
 *  restore signs of entering column and change sign of pivot 
 *  element if appropriate. 
 */
  if (*intyp == -1) {
    for (i = 1; i <= *m; ++i) yq[i] = -yq[i];
    *pivot = -(*pivot);
  }
  if (*outtyp == 0 && abs(*theta) >= big) *unbdd = TRUE;
  return;

L270:
  fprintf(ioerr, "xchuzr...variable=%ld\n", *q);
  fprintf(ioerr, "lower=%16.8f  upper=%16.8f\n", *lq, *uq);
  error = 0;
  xstop(&error, ioerr);

  return;
}				/* xchuzr */

/* ============================================================ xdot   === 
 *     *****purpose: 
 *     the purpose of this routine is to perform 
 *     an inner product between a row vector and a 
 *     packed matrix column. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     row         is the row vector. 
 *     on output: 
 *     zdot        contains the inner product between 
 *                 row and the packed matrix column 
 *                 contained in cola and coli.  
 */
void xdot(cola, coli, collen, colmax, maxm, row, zdot)
double *cola;
long *coli, *collen, *colmax, *maxm;
double *row, *zdot;
{
/*
 *  f2c generated locals
 */
  long i__1;

/*
 *  Local variables
 */
  double zabs, temp;
  long ik, ikx;

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --row;
  --coli;
  --cola;

/* ------------------- Function body ------------------- */
  *zdot = (float) 0.;
  zabs = (float) 0.;
  if (*collen > 0) {
    i__1 = *collen;
    for (ik = 1; ik <= i__1; ++ik) {
      ikx = coli[ik];
      temp = row[ikx] * cola[ik];
      *zdot += temp;
      zabs += abs(temp);
    }
  }
  if (abs(*zdot) < zl || abs(*zdot) < zl * zabs) *zdot = (float) 0.;
  return;
}				/* xdot */

/* ============================================================ xfact  === 
 *     *****purpose: 
 *     this subroutine re-factors (or re-inverts) the 
 *     current basis matrix. 
 *
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     m           is the number of constraints. 
 *     mapi        is a map of array memi. 
 *     mapr        is a map of array memr. 
 *     memi        array containing hidden integer data. 
 *     memr        array containing hidden real data. 
 *     on output: 
 *     fcode       is a return code for xfact: 
 *                 1 means everything ok; 
 *                 2 means that the basis is singular; 
 *                 3 means storage overflow. 
 *
 *     reid's a and ind arrays have been set up and the current basis has
 *     been factored by la05a. 
 *
 *     *****application and usage restrictions: 
 *     this subroutine is compatible with j. k. reid's la05 
 *     routines for handling an lu factorization of the basis 
 *     matrix.  the 'body of program' must be re-written if some other 
 *     inverse representation is used. 
 *
 *     *****algorithm notes: 
 *     this routine has some extra, currently unused arguments. 
 *     this is to facilitate implementation of some forseeable 
 *     enhancements, e.g. inserting artificial variables when 
 *     factorization or inversion fails. 
 *
 *     data structure for the basis inverse representation: 
 *
 *     mapi(6)    points to reid's ia constant. 
 *     mapi(7)    points to reid's ip array. 
 *     mapi(8)    points to reid's iw array. 
 *     mapi(9)    points to reid's ind array. 
 *
 *     mapr(5)    points to reid's g constant. 
 *     mapr(6)    points to reid's u constant. 
 *     mapr(7)    points to reid's w array. 
 *     mapr(8)    points to reid's a array. 
 * 
 */
void xfact(bascb, basis, baslb, basub, cola, coli, colmax, fcode, ioerr, m, 
           mapi, mapr, maxm, memi, memr)
double *bascb;
long *basis;
double *baslb, *basub, *cola;
FILE *ioerr;
long *coli, *colmax, *fcode, *m, *mapi, *mapr, *maxm, *memi;
double *memr;
{
/*
 *  Local variables
 */
  double g;
  long i, j;
  long error;
  double cj;
  long nz, collen;
  long mi6, mi7, mi8, mi9, mr5, mr6, mr7, mr8;

/*
 *  Subroutines called
 */  
  void la05ad(), xla05x(), xstop(), xgetaj();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --basub;
  --baslb;
  --basis;
  --bascb;

/* ------------------- Function body ------------------- */
  *fcode = 1;
  mi6 = mapi[6];
  mi7 = mapi[7];
  mi8 = mapi[8];
  mi9 = mapi[9];
  mr5 = mapr[5];
  mr6 = mapr[6];
  mr7 = mapr[7];
  mr8 = mapr[8];
  memr[mr5] = (float) 0.;
  nz = 0;
  for (i = 1; i <= *m; ++i) {
    j = basis[i];
    xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1]);
    xla05x(&memr[mr8], &cola[1], &coli[1], &collen, colmax, &i, &memi[
					   mi6], &memi[mi9], ioerr, &nz);
  }
  la05ad(&memr[mr8], &memi[mi9], &nz, &memi[mi6], m, &memi[mi7], &memi[mi8]
	 ,&memr[mr7], &memr[mr5], &memr[mr6]);
  g = memr[mr5];
  if (g >= 0.) goto L130;
  fprintf(ioerr, "xfact ...error return from la05a...g=%10.2f\n", g);
  if (g == -2. || g == -5.) {
    *fcode = 2;
    goto L130;
  }
  if (g == -7.) {
    fprintf(ioerr, "please increase space for memr and memi arrays\n");
    *fcode = 3;
    error = 0;
    xstop(&error, ioerr);
  }

L130:
/*
 *  check to see if the factorization routine has
 *  inserted any artificial variables into the basis.
 *  the convention is that if the i-th basic variable
 *  has been replaced by an artificial variable for
 *  constraint k, then it will set basis(i)=-k.
 *  note:  reid's factorization routine does not insert
 *  artificial variables. 
 */
  return;
}				/* xfact */

/* ============================================================ xfeas  === 
 *    *****purpose:
 *    this routine starts from any given basis and finds
 *    a primal feasible basis, if one exists.
 *    the approach used is to force every basic variable
 *    to satisfy its upper and lower bounds.
 *    *****argument description:
 *    see xmp dictionary for arguments not described here.
 *    on input:
 *    factit      is the number of iterations performed since
 *                the last factorization.
 *    factor      is the re-factorization frequency.
 *    look        is the number of columns to be considered
 *                during construction of the candidate list.
 *                controls partial pricing.
 *    m           is the number of constraints.
 *    n           is the number of variables (total, including
 *                slacks and artificials).
 *    pick        is the size of the candidate list used for multiple
 *                pricing.
 *    print       specifies the level of printing desired:
 *                0 means error messages only;
 *                1 means termination condition messages;
 *                2 means print objective function value after
 *                  each basis re-factorization;
 *                3 means log information at every iteration.
 *    uzero       will be used to hold the phase 1 dual
 *                variables.
 *    on output:
 *    factit      is the number of iterations performed since
 *                the last factorization.
 *    feas        1  if a feasible solution has been found;
 *                2  if the problem is infeasible;
 *                3  if the problem has been abandoned.
 *    iter        is the number of iterations performed.
 *
 *    z           is minus the sum of infeasibilities.
 *
 *
 *    the last solution obtained is contained in the arrays:
 *    bascb,basis,baslb,basub,status,xbzero
 *
 *    *****application and usage restrictions:
 *
 *    this routine has been modified to use fcand,
 *    which is the fast version of xcand.
 *
 *    *****algorithm notes:
 *    at each iteration a pricing form is constructed.
 *    this pricing form contains a +1.0 for each basic
 *    variable that is below its lower bound;
 *    a -1.0 for each basic variable that is above its
 *    upper bound; and a 0.0 for each basic variable that
 *    is within its bounds.  (we are done if every basic
 *    variable is within its bounds.)  this pricing form
 *    is then btran'ed to produce a vector of dual
 *    variables.  note that a (possibly) different pricing
 *    form, and hence a different objective function,
 *    is constructed at every iteration.
 *
 *
 *    the dual variables, uzero, do not have to be set
 *    before calling xfeas.  bascb, the array of objective
 *    coefficients of the basic variables, is updated during
 *    xfeas but is not used as the pricing form.
 *    upon completion of xfeas, bascb can be btran'ed to
 *    compute the correct phase 2 dual variables.
 *    this is done, for example, in xpriml.
 *
 *    the following arrays must be set before calling xfeas:
 *    b,bascb,basis,baslb,basub,status,xbzero
 *
 *    the following are scratch arrays with respect to
 *    this routine.  that is, they must be provided by the
 *    calling program, but they do not have to be set.
 *       cola,coli,uzero,yq
 */
void xfeas(b, bascb, basis, baslb, basub, bndtyp, bound, cola, coli, 
           colmax, factit, factor, feas, ioerr, iolog, iter, look, m,
           mapi, mapr, maxm, maxn, memi, memr, n, ntype2, pick, print, 
           status, uzero, xbzero, yq, z)
double *b, *bascb;
long *basis;
double *baslb, *basub;
long *bndtyp;
double *bound, *cola;
FILE *iolog;
FILE *ioerr;
long *coli, *colmax, *factit, *factor, *feas, *iter, *look, *m, *mapi;
long *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *ntype2, *pick, *print, *status;
double *uzero, *xbzero, *yq, *z;
{
/*
 *  f2c generated locals
 */
  long i__1;
  double d__1;

/*
 *  Local variables
 */
  long cand[10], iflag, idle, ichk, nrej, save;
  double zold, uzaj;
  long nout, i;
  long k, check, fcode, q, r, pcode;
  long unbdd;
  long leave, phase;
  double theta;
  long error;
  double ztemp, pivot;
  long intyp;
  long saves1;
  double cj;
  long start1, start2, jj;
  double dq;
  long dblchk;
  long ir;
  double lq;
  long ix, jx;
  double uq, cjsave;
  long collen, dindex, reject[20];
  long savelk, pindex;
  double dtoler;
  long pprime;
  double derror;
  double ptoler;
  long stsave[20], mi1, mi2;
  double perror;
  long mi3, mr3, mr4;
  long outtyp;
  long dok, pok;

/*
 *  Subroutines called
 */  
  void xlog(), xdot(), fcand(), xfact(), xstop(), xcheck();
  void xgetaj(), xbcomp(), xgetub(), xbtran(), xpivot();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --basub;
  --baslb;
  --basis;
  --bascb;
  --b;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xfeas      %ld\n", *m);
    xstop(&error, ioerr);
  }
  if (*n < 1 || *n > *maxn) {
    error = 2;
    fprintf(ioerr, "xfeas      %ld\n", *n);
    xstop(&error, ioerr);
  }
  if (*pick > 10) *pick = 10;

  phase = 1;
  *iter = 0;
  nrej = 0;
  idle = 0;
  zold = -big;
  ptoler = eps2;
  pok = TRUE;
  dblchk = FALSE;
/*
 *  do accuracy check halfway between refactorizations.  
 */
  check = *factor / 2;
/*
 *  need map values for fast version of xcand. 
 */
  mi1 = mapi[1];
  mi2 = mapi[2];
  mi3 = mapi[3];
  mr3 = mapr[3];
  mr4 = mapr[4];
/*
 *  save the value of look, the block size for partial pricing. 
 */
  savelk = *look;
  start1 = 1;
/*
 *  set up the pricing form and compute the phase 1 dual variables. 
 */
  iflag = 1;
  goto L800;

L150:
/*
 *  return here to begin a major iteration:  get a set of candidates 
 *  for basis entry. 
 */

L210:
  save = start1;
  *look = savelk;

L220:  /* go price out a block and construct a candidate list. */
  fcand(cand, &cola[1], &coli[1], colmax, ioerr, look, &mapi[1], &mapr[1],
	maxm, maxn, &memi[1], &memr[1], n, pick, &phase, &pprime, &start1,
	&start2, &status[1], &uzero[1], &memr[mr3], &memr[mr4], 
        &memi[mi1], &memi[mi2], &memi[mi3]);
/*
 *  logic for determining when no further improvement
 *  is possible -- i.e. a complete scan of the matrix
 *  has been made without finding any candidates for basis
 *  entry.  remember that we are using partial pricing 
 *  with wraparound.  this gets tricky. 
 */
  saves1 = start1;
  start1 = start2 + 1;
  if (start1 > *n) start1 = 1;
/*
 *  pprime positive means that we have found some candidates 
 *  in this block of columns and must do some minor iterations. 
 */
  if (pprime > 0) goto L230;
/*
 *  here are two conditions under which we can be sure that we 
 *  have scanned the whole matrix without finding any candidates. 
 */
  if (start1 == save) goto L410;
  if (start2 < saves1 && start2 >= save) goto L410;
/*
 *  otherwise, we have to go back and price out another block. 
 */
  if (start1 >= save || start1 + *look - 1 < save) {
    goto L220;
  } else {
    *look = save - start1;
    goto L220;
  }
/*
 * come here to do a series of minor iterations using the candidate list. 
 */
L230:

L240:   /* return here after each minor iteration. */
  k = 1;

L250:
  if (cand[k - 1] != 0) goto L270;

L260:
  ++k;
  if (k <= pprime) goto L250;
  goto L210;

L270:               /* come here to price out one of the candidates. */
  jx = cand[k - 1];
  xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &jx, &mapi[1], &
	 mapr[1], &memi[1], &memr[1]);
  cjsave = cj;
  xdot(&cola[1], &coli[1], &collen, colmax, maxm, &uzero[1], &uzaj);
/*
 *  we assume a zero coefficient in the phase i objective function for 
 *  every non-basic variable. 
*/
  dq = -uzaj;
  if (abs(dq) < zlc) dq = (float) 0.;
  if (dq < 0.) {
    goto L285;
  } else if (dq == 0) {
    goto L260;
  } else {
    goto L286;
  }

L285:
  if (status[jx] == -1 || status[jx] == -2) goto L290;
  goto L260;

L286:
  if (status[jx] == 0 || status[jx] == -2) goto L290;
  goto L260;

L290:
  q = cand[k - 1];
/*
 *  variable q has been selected to enter the basis.
 *  load yq with column q in its unpacked form (it will be ftran'ed later). 
 */
  for (i = 1; i <= *m; ++i) {
    yq[i] = (float) 0.;
  }
  if (collen > 0) {
    i__1 = collen;
    for (i = 1; i <= i__1; ++i) {
      ix = coli[i];
      yq[ix] = cola[i];
    }
  }
/*
 *  get the lower and upper bounds for the entering variable q. 
 */
  if (status[q] == -2) { /* free variables */
    lq = -big;
    uq = big;
  } else if (*bndtyp == 1) {/* here for standard case, zero and +infinity */
    lq = (float) 0.;
    uq = big;
  } else if (*bndtyp == 2) { /* all non-free structurals have a common bound */
    lq = (float) 0.;
    uq = *bound;
    if (q > *ntype2) uq = big;
  } else {  /* here for general bounds. */
    xgetub(bndtyp, ioerr, &q, &lq, &mapi[1], &mapr[1], &memi[1], &memr[1],&uq);
  }
  intyp = 1;
  if (dq < 0.) intyp = -1;
/*
 *   now pivot variable q into the basis. 
 */
  xpivot(&basis[1], &baslb[1], &basub[1], &dq, &intyp, ioerr, &leave, &lq,
         m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &outtyp,
	 &pcode, &phase, &pivot, &q, &r, &status[1], &theta, &unbdd, &uq,
	 &xbzero[1], &yq[1], z);
  if (unbdd) goto L600;
/*
 *  pivot rejection mechanism. 
 */
  if (pcode == 1) {
    if (nrej > 0) {
      i__1 = nrej;
      for (ir = 1; ir <= i__1; ++ir) {
	jj = reject[ir - 1];
	status[jj] = stsave[ir - 1];
      }
      nrej = 0;
    }
  } else {
    ++nrej;
    reject[nrej - 1] = q;
    stsave[nrej - 1] = status[q];
    status[q] = -3;
    if (nrej > 20) {
      fprintf(ioerr,
	      "xfeas ...problem abandoned:  too many rejected pivots\n");
      *feas = 3;
      goto L700;
    } else {
      fprintf(ioerr, "xfeas ...iteration %ld     pivot rejected:\n",
	      *iter);
      fprintf(ioerr, "variable= %ld     pivot=%16.8f\n", q, pivot);
      cand[k - 1] = 0;
      goto L240;
    }
  }
/*
 *  give up if the objective is not changing. 
 */
  if ((d__1 = *z - zold, abs(d__1)) > zlc) {
    idle = 0;
    zold = *z;
  } else {
    ++idle;
    if (idle > *m << 1 && idle > 500) {
      fprintf(ioerr,
       "xfeas...problem abandoned:  objective function not improving\n");
      *feas = 3;
      goto L700;
    }
  }
/*
 *  setting cand(k)=0 indicates that candidate k has already been pivoted 
 *  into the basis. 
 */
  cand[k - 1] = 0;
  ++(*iter);

  if (*print == 3)
    xlog(&dq, &intyp, iolog, iter, &leave, &outtyp, &pivot, &q, &r, &theta, z);
  if (outtyp == 0) goto L380;
/*
 *  update the array of objective coefficients of the basic variables. 
 */
  bascb[r] = cjsave;
/*
 *  accuracy check. 
 */
  ichk = 0;
  if (*factit != check) goto L3749;

L3748:
  xcheck(&b[1], &basis[1], bndtyp, bound, &cola[1], &coli[1], colmax, &
	 dblchk, &derror, &dindex, &dok, &dtoler, ioerr, m, &mapi[1], &
	 mapr[1], maxm, maxn, &memi[1], &memr[1], n, &perror, &pindex, &
	 pok, &ptoler, &status[1], &uzero[1], &yq[1], &xbzero[1]);
  ++ichk;
  if (pok) goto L3749;
  *factit = *factor;
  if (ichk == 1) goto L3749;
  fprintf(ioerr, "xfeas...problem abandoned:  fatal accuracy problem\n");
  *feas = 3;
  goto L700;

L3749:               /* re-factor the basis if necessary. */
  ++(*factit);
  if (*factit <= *factor) goto L380;
  xfact(&bascb[1], &basis[1], &baslb[1], &basub[1], &cola[1], &coli[1],
	colmax, &fcode, ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], 
        &memr[1]);
  if (fcode != 1) exit(1);
/*
 *  write out the current basis and status lists in case a re-start
 *  is necessary.
 */
/*
  if (iobsf != 0) {long j;
    for (i = 1, i__1 = 1; i <= *m; ++i, ++i__1) {
      fprintf(iobsf, "%6ld", basis[i]);
      if (!(i__1 % 10)) fprintf(iobsf, "\n");
    }
    if ((i__1 - 1) % 10) fprintf(iobsf, "\n");
    for (j = 1, i__1 = 1; j <= *n; ++j, ++i__1) {
      fprintf(iobsf, "%6ld", status[j]);
      if (!(i__1 % 10)) fprintf(iobsf, "\n");
    }
    if ((i__1 - 1) % 10) fprintf(iobsf, "\n");
    rewind(iobsf);
  }
*/
  *factit = 0;
/*
 *  re-compute the basic variables using the re-factored basis. 
 */
  xbcomp(&b[1], &bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax,
         ioerr, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, 
         &status[1], &xbzero[1], &ztemp);

  if (*print == 2) {
    d__1 = -(*z);
    fprintf(iolog, "iteration=%6ld     infeasibility=%16.8f\n",
	    *iter, d__1);
  }
  if (!pok) goto L3748;

L380:
/*
 *  set up the pricing form and compute the phase 1 dual variables. 
 */
  iflag = 2;
  goto L800;

L410:       /* come here if there is no feasible solution. */
  *feas = 2;
  if (*print == 0) goto L700;
  fprintf(iolog, "xfeas...problem is infeasible.\n");
  if (*print == 1) goto L700;
  for (i = 1; i <= *m; ++i)
    if ((xbzero[i] < baslb[i]) || (xbzero[i] > basub[i]))
      fprintf(iolog, "var%5ld lower=%13.6f value=%13.6f upper=%13.6f\n",
	      basis[i], baslb[i], xbzero[i], basub[i]);
  goto L700;

L500:       /* come here if a primal feasible solution has been found. */
  *feas = 1;
  if (*print == 0) goto L700;
  fprintf(iolog, "xfeas...feasible solution found.\n");
  goto L700;

L600:           /* come here for error */
  fprintf(ioerr,
	"xfeas...error: unbounded condition detected during phase 1.\n");
  error = 0;
  xstop(&error, ioerr);

L700:
/*
 *  restore the value of look, and flush out the rejected pivot list. 
 */
  *look = savelk;
  if (nrej > 0) {
    i__1 = nrej;
    for (ir = 1; ir <= i__1; ++ir) {
      jj = reject[ir - 1];
      status[jj] = stsave[ir - 1];
    }
    nrej = 0;
  }
  return;

/*
 *  this section sets up the pricing form and computes the phase 1 
 *  dual variables. 
 */
L800:
/*
 *  any basic variable below its lower bound must be increased;  any basic 
 *  variable above its upper bound must be decreased. 
 *
 *  nout is the number of variables that are out of bounds. 
 *  z is the negative of the total violation. 
 */
  nout = 0;
  *z = (float) 0.;

  for (i = 1; i <= *m; ++i) {
    uzero[i] = (float) 0.;
    if (xbzero[i] - baslb[i] < -eps2) {
      uzero[i] = (float) 1.;
      *z = *z + xbzero[i] - baslb[i];
      ++nout;
    } else {
      if (xbzero[i] - basub[i] > eps2) {
        uzero[i] = (float) -1.;
        *z = *z + basub[i] - xbzero[i];
        ++nout;
      }
    }
  }
  if (nout == 0) goto L500;
/*
 *  compute the dual variables. 
 */
  xbtran(ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1], &uzero[1]);

  switch ((int) iflag) {
  case 1:  goto L150;
  case 2:  goto L240;
  }
  return;
}				/* xfeas */

/* ============================================================ xftran === 
 *     *****purpose: 
 *     this subroutine implements the ftran or forward transformation 
 *     (basis inverse)*column. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     column      is the column to be ftran'ed. 
 *     m           is the number of constraints. 
 *     mapi        is a map of array memi. 
 *     mapr        is a map of array memr. 
 *     memi        array containing hidden integer data. 
 *     memr        array containing hidden real data. 
 *     on output: 
 *     column contains (basis inverse)*(input column) 
 *     *****application and usage restrictions: 
 *     this subroutine is compatible with john reid's la05 routines 
 *     for handling an lu factorization of the basis matrix.  the 
 *     'body of program' must be re-written if some other inverse 
 *     representation is used. 
 *     *****algorithm notes: 
 *     data structure for the basis inverse representation: 
 *
 *     mapi(6)    points to reid's ia constant. 
 *     mapi(7)    points to reid's ip array. 
 *     mapi(8)    points to reid's iw array. 
 *     mapi(9)    points to reid's ind array. 
 *
 *     mapr(5)    points to reid's g constant. 
 *     mapr(6)    points to reid's u constant. 
 *     mapr(7)    points to reid's w array. 
 *     mapr(8)    points to reid's a array. 
 *
 */
void xftran(column, ioerr, m, mapi, mapr, maxm, memi, memr)
double *column;
FILE *ioerr;
long *m, *mapi, *mapr, *maxm, *memi;
double *memr;
{
  double g;
  long trans;
  long error;
  long mi6, mi7, mi8, mi9, mr5, mr7, mr8;

/*
 *  Subroutines called
 */  
  void la05bd(), xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --memr;
  --memi;
  --mapr;
  --mapi;
  --column;

/* ------------------- Function body ------------------- */
  mi6 = mapi[6];
  mi7 = mapi[7];
  mi8 = mapi[8];
  mi9 = mapi[9];
  mr5 = mapr[5];
  mr7 = mapr[7];
  mr8 = mapr[8];

  trans = FALSE;
  memr[mr5] = (float) 0.;
  la05bd(&memr[mr8], &memi[mi9], &memi[mi6], m, &memi[mi7], &memi[mi8], &
	 memr[mr7], &memr[mr5], &column[1], &trans);
  g = memr[mr5];
  if (g >= 0.) return;
  fprintf(ioerr, "xftran...error return from la05b...g=%10.2f\n", g);
  error = 0;
  xstop(&error, ioerr);
  return;
}				/* xftran */

/* ============================================================ xla05x === 
 *     *****purpose: 
 *     this routine places one basic column into 
 *     reid's a and ind arrays in preparation for a 
 *     call to la05a.  this routine is on the same level 
 *     as the other la05 routines.  it is needed because 
 *     reid's arrays cannot be handled directly from 
 *     the xmp routines. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     a           is reid's a array. 
 *     i           is the position of this column in the basis. 
 *     ia          is the length of reid's a and ind arrays. 
 *     ind         is reid's ind array. 
 *     nz          is the number of non-zeros already in the 
 *                 basis, before this column is added. 
 *     on output: 
 *     nz          is the number of non-zeros now in the basis; 
 *                 (output nz)=(input nz)+collen 
 *     the new column has been placed in a and ind. 
 *     *****application and usage restrictions: 
 *     this subroutine is compatible with john reid's la05 routines 
 *     for handling an lu factorization of the basis matrix. 
 *     in fact, this routine should be regarded as part of 
 *     the la05 package rather than as part of xmp.   
 */
void xla05x(a, cola, coli, collen, colmax, i, ia, ind, ioerr, nz)
double *a, *cola;
FILE *ioerr;
long *coli, *collen, *colmax, *i, *ia, *ind, *nz;
{
/*
 *  f2c generated locals
 */
  long ind_dim1, ind_offset;

/*
 *  Local variables
 */
  long error;
  long ik;

/*
 *  Subroutines called
 */  
  void xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  ind_dim1 = *ia;
  ind_offset = ind_dim1 + 1;
  ind -= ind_offset;
  --coli;
  --cola;
  --a;

/* ------------------- Function body ------------------- */
  if (*collen < 1 || *collen > *colmax) {
    fprintf(ioerr,
      "xla05x...error: the basic column in position %ld has length %ld\n",
      *i, *collen);
    error = 0;
    xstop(&error, ioerr);
  }
  for (ik = 1; ik <= *collen; ++ik) {
    ++(*nz);
    if (*nz > *ia) {
      fprintf(ioerr, "xla05x...overflow: not enough room for basis matrix\n");
      error = 0;
      xstop(&error, ioerr);
    }
    a[*nz] = cola[ik];
    ind[*nz + ind_dim1] = coli[ik];
    ind[*nz + (ind_dim1 << 1)] = *i;
  }
  return;
}				/* xla05x */

/* ============================================================ xlog   === 
 *     *****purpose: 
 *     this routine prints log information about the current 
 *     pivot, if requested. 
 *     *****argument description: 
 *     on input: 
 *     dq          is the "relative profit" or "reduced profit" 
 *                 of the entering variable. 
 *     intyp       +1 means the entering variable is increasing 
 *                    from its lower bound. 
 *                 -1 means the entering variable is decreasing 
 *                    from its upper bound. 
 *     iolog       is the i/o unit where log information is to 
 *                 be written, if requested. 
 *     iter        is the current iteration count. 
 *     leave       is the variable that just left the basis. 
 *     outtyp      +1 means the leaving variable is going to its 
 *                    lower bound; 
 *                 -1 means the leaving variable is going to its 
 *                    upper bound; 
 *                  0 means the entering and leaving variables are 
 *                    the same. 
 *     pivot       is the pivot element, pivot= yq(r). 
 *     q           the index of the entering variable. 
 *     r           the position of the leaving variable, 
 *                 i.e., the index of the variable leaving the basis 
 *                 is basis(r). 
 *     theta       is the value at which the incoming variable 
 *                 will enter the basis, i.e. the value of the 
 *                 winning ratio from the primal ratio test. 
 *     z           is the value of the objective function. 
 *     on output:  
 */
void xlog(dq, intyp, iolog, iter, leave, outtyp, pivot, q, r, theta, z)
double *dq;
FILE *iolog;
long *intyp, *iter, *leave, *outtyp;
double *pivot;
long *q, *r;
double *theta, *z;
{
  if (*iter == 1) {
    fprintf(iolog, " iter enter leave          pivot           rate");
    fprintf(iolog, "       distance      objective\n");
  }
  fprintf(iolog, "%5ld%6ld%6ld%15.6f%15.6f%15.6f%15.6f\n",
	  *iter, *q, *leave, *pivot, *dq, *theta, *z);
  return;
}				/* xlog */

/* ============================================================ xphas2 === 
 *     *****body of program  (xphas2) 
 *     *****purpose: 
 *     this routine executes phase 2 of the primal simplex method. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     factit      is the number of iterations performed since 
 *                 the last factorization. 
 *     factor      is the re-factorization frequency. 
 *     look        is the number of columns to be considered during 
 *                 construction of the candidate list. 
 *                 controls partial pricing. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     pick        is the size of the candidate list used for 
 *                 multiple pricing. 
 *     print       specifies the level of printing desired: 
 *                 0 means error messages only; 
 *                 1 means termination condition messages; 
 *                 2 means print objective function value after 
 *                   after each basis re-factorization; 
 *                 3 means log information at every iteration. 
 *     z           is the value of the phase 2 objective function. 
 *     on output: 
 *     factit      is the number of iterations performed since 
 *                 the last factorization. 
 *     iter        is the number of iterations performed. 
 *     termin      is the termination code for phase 2: 
 *                 1 means optimal solution found; 
 *                 2 means problem is unbounded; 
 *                 3 means that primal feasibility has been lost; 
 *                 5 means the problem has been abandoned. 
 *     unbddq      if the problem is unbounded, then unbddq is 
 *                 the index of the variable that was about to 
 *                 enter the basis when the unbounded condition 
 *                 was detected. 
 *     yq          if the problem is unbounded, then yq contains 
 *                 the ftran'ed version of the column that was 
 *                 about to enter the basis when the unbounded 
 *                 condition was detected. 
 *
 *     the last solution obtained is contained in the arrays: 
 *     bascb,basis,baslb,basub,status,uzero,xbzero, and z 
 *
 *     *****application and usage restrictions: 
 *     this routine has been modified to use fcand, 
 *     which is the fast version of xcand. 
 *
 *     *****algorithm notes: 
 *     the following arrays have to be set before calling xphas2: 
 *     b,bascb,basis,baslb,basub,status,uzero,xbzero,z 
 *
 *     the following are scratch arrays with respect to 
 *     this routine.  that is, they must be provided by the 
 *     calling program, but they do not have to be set. 
 *        cola,coli,yq  
 */
void xphas2(b, bascb, basis, baslb, basub, bndtyp, bound, cola, coli, colmax, 
            factit, factor, ioerr, iolog, iter, look, m, mapi, mapr, maxm, 
            maxn, memi, memr, n, ntype2, pick, print, status, termin, unbddq, 
            uzero, xbzero, yq, z)
double *b, *bascb;
long *basis;
double *baslb, *basub;
long *bndtyp;
double *bound, *cola;
FILE *iolog;
FILE *ioerr;
long *coli, *colmax, *factit, *factor, *iter, *look, *m, *mapi, *mapr;
long *maxm, *maxn, *memi;
double *memr;
long *n, *ntype2, *pick, *print, *status, *termin, *unbddq;
double *uzero, *xbzero, *yq, *z;
{
/*
 *  f2c generated locals
 */
  long i__1;

/*
 *  Local variables
 */
  long cand[10], idle, ichk, nrej, save;
  double zold, uzaj;
  long i;
  long k, check, fcode, q, r, pcode;
  long unbdd;
  long leave, phase;
  double theta;
  long error;
  double pivot;
  long intyp;
  long saves1;
  double cj;
  long start1, start2, jj;
  double dq;
  long dblchk;
  long ir;
  double lq;
  long ix, jx;
  double uq, cjsave;
  long collen, dindex, reject[20];
  long savelk, pindex;
  double dtoler;
  long pprime;
  double derror;
  double ptoler;
  long stsave[20], mi1, mi2;
  double perror;
  long mi3, mr3, mr4;
  long outtyp;
  long dok, pok;

/*
 *  Subroutines called
 */  
  void xlog(), xdot(), fcand(), xfact(), xstop(), xcheck(), xgetaj();
  void xbcomp(), xgetub(), xbtran(), xpivot();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --basub;
  --baslb;
  --basis;
  --bascb;
  --b;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xphas2     %ld\n", *m);
    xstop(&error, ioerr);
  }
  if (*n < 1 || *n > *maxn) {
    error = 2;
    fprintf(ioerr, "xphas2     %ld\n", *n);
    xstop(&error, ioerr);
  }
  if (*pick > 10) *pick = 10;

  phase = 2;
  *iter = 0;
  nrej = 0;
  idle = 0;
  zold = -big;
  ptoler = eps2;
  pok = TRUE;
  dblchk = FALSE;
/*
 *  do accuracy check halfway between refactorizations. 
 */
  check = *factor / 2;
/*
 *  need map values for fast version of xcand. 
 */
  mi1 = mapi[1];
  mi2 = mapi[2];
  mi3 = mapi[3];
  mr3 = mapr[3];
  mr4 = mapr[4];
/*
 *  save the value of look, the block size for partial pricing. 
 */
  savelk = *look;
  start1 = 1;

L210:
/*
 *  return here to begin a major iteration:  get a set of candidates 
 *  for basis entry. 
 */
  save = start1;
  *look = savelk;

L220:      /* go price out a block and construct a candidate list. */
  fcand(cand, &cola[1], &coli[1], colmax, ioerr, look, &mapi[1], &mapr[1],
	maxm, maxn, &memi[1], &memr[1], n, pick, &phase, &pprime, &start1,
	&start2, &status[1], &uzero[1], &memr[mr3], &memr[mr4], 
        &memi[mi1], &memi[mi2], &memi[mi3]);
/*
 *  logic for determining when no further improvement 
 *  is possible -- i.e. a complete scan of the matrix
 *  has been made without finding any candidates for basis
 *  entry.  remember that we are using partial pricing
 *  with wraparound.  this gets tricky. 
 */
  saves1 = start1;
  start1 = start2 + 1;
  if (start1 > *n) start1 = 1;
/*
 *  pprime positive means that we have found some candidates
 *  in this block of columns and must do some minor iterations. 
 */
  if (pprime > 0) goto L230;
/*
 *  here are two conditions under which we can be sure that we
 *  have scanned the whole matrix without finding any candidates. 
 */
  if (start1 == save) goto L410;
  if (start2 < saves1 && start2 >= save) goto L410;
/*
 *  otherwise, we have to go back and price out another block. 
 */
  if (start1 >= save || start1 + *look - 1 < save) {
    goto L220;
  } else {
    *look = save - start1;
    goto L220;
  }

L230: /* come here to do a series of minor iterations using candidate list. */

L240:  /* return here after each minor iteration. */
  k = 1;

L250:
  if (cand[k - 1] != 0) goto L270;

L260:
  ++k;
  if (k <= pprime) goto L250;
  goto L210;

L270:              /* come here to price out one of the candidates. */
  jx = cand[k - 1];
  xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &jx, &mapi[1], 
         &mapr[1], &memi[1], &memr[1]);
  cjsave = cj;
  xdot(&cola[1], &coli[1], &collen, colmax, maxm, &uzero[1], &uzaj);
  dq = cj - uzaj;
  if (abs(dq) < zlc) dq = (float) 0.;
  if (dq < 0.) {
    goto L285;
  } else if (dq == 0) {
    goto L260;
  } else {
    goto L286;
  }

L285:
  if (status[jx] == -1 || status[jx] == -2) goto L290;
  goto L260;

L286:
  if (status[jx] == 0 || status[jx] == -2) goto L290;
  goto L260;

L290:
  q = cand[k - 1];
/*
 *  variable q has been selected to enter the basis. 
 *  load yq with column q in its unpacked form (it will be 
 *  ftran'ed later).
 */
  for (i = 1; i <= *m; ++i) {
    yq[i] = (float) 0.;
  }
  if (collen > 0) {
    i__1 = collen;
    for (i = 1; i <= i__1; ++i) {
      ix = coli[i];
      yq[ix] = cola[i];
    }
  }
/*
 *  get the lower and upper bounds for the entering variable q. 
 */
  if (status[q] == -2) {/* free variables */
    lq = -big;
    uq = big;
  } else if (*bndtyp == 1) {/* here for standard case, zero and +infinity */
    lq = (float) 0.;
    uq = big;
  } else if (*bndtyp == 2) {/* all non-free structurals have a common bound. */
    lq = (float) 0.;
    uq = *bound;
    if (q > *ntype2) uq = big;
  } else {    /* here for general bounds. */
    xgetub(bndtyp, ioerr, &q, &lq, &mapi[1], &mapr[1], &memi[1], &memr[1],&uq);
  }
  intyp = 1;
  if (dq < 0.) intyp = -1;
/*
 *  now pivot variable q into the basis. 
 */
  xpivot(&basis[1], &baslb[1], &basub[1], &dq, &intyp, ioerr, &leave, &lq,
       m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &outtyp,
	 &pcode, &phase, &pivot, &q, &r, &status[1], &theta, &unbdd, &uq,
	 &xbzero[1], &yq[1], z);
/*
 *  check for loss of feasibility. 
 */
  if (r < 0) {
    *termin = 3;
    goto L376;
  }
  if (unbdd) goto L600;
/*
 *  pivot rejection mechanism. 
 */
  if (pcode == 1) {
    if (nrej > 0) {
      i__1 = nrej;
      for (ir = 1; ir <= i__1; ++ir) {
	jj = reject[ir - 1];
	status[jj] = stsave[ir - 1];
      }
      nrej = 0;
    }
  } else {
    ++nrej;
    reject[nrej - 1] = q;
    stsave[nrej - 1] = status[q];
    status[q] = -3;
    if (nrej > 20) {
      fprintf(ioerr,
	      "xphas2...problem abandoned:  too many rejected pivots\n");
      *termin = 5;
      goto L700;
    } else {
      fprintf(ioerr, "xphas2...iteration %ld     pivot rejected:\n", *iter);
      fprintf(ioerr, "variable=%ld     pivot=%16.8f\n", q, pivot);
      cand[k - 1] = 0;
      goto L240;
    }
  }
/*
 *  give up if the objective function is not improving.
 *  this could be due to degeneracy or to round-off
 *  errors in computing the relative profits after an
 *  optimal solution has been found. 
 */
  if (*z - zold > zlc) {
    idle = 0;
    zold = *z;
  } else {
    ++idle;
    if (idle > *m << 1 && idle > 500) {
      fprintf(ioerr,
      "xphas2...problem abandoned:  objective function not improving\n");
      *termin = 5;
      goto L700;
    }
  }
/*
 *  setting cand(k)=0 indicates that candidate k has already been pivoted 
 *  into the basis. 
 */
  cand[k - 1] = 0;
  ++(*iter);
  if (*print == 3)
    xlog(&dq, &intyp, iolog, iter, &leave, &outtyp, &pivot, &q, &r, &theta, z);
  if (outtyp == 0) goto L240;
/*
 *  update the array of objective coefficients of the basic variables. 
 */
  bascb[r] = cjsave;
/*
 *  accuracy check. 
 */
  ichk = 0;
  if (*factit != check) goto L3749;

L3748:
  xcheck(&b[1], &basis[1], bndtyp, bound, &cola[1], &coli[1], colmax, 
         &dblchk, &derror, &dindex, &dok, &dtoler, ioerr, m, &mapi[1], 
         &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &perror, &pindex, 
         &pok, &ptoler, &status[1], &uzero[1], &yq[1], &xbzero[1]);
  ++ichk;
  if (pok) goto L3749;
  *factit = *factor;
  if (ichk == 1) goto L3749;
  fprintf(ioerr, "xphas2...problem abandoned:  fatal accuracy problem\n");
  *termin = 5;
  goto L700;

L3749:         /* re-factor the basis if necessary. */
  ++(*factit);
  if (*factit <= *factor) goto L380;
  xfact(&bascb[1], &basis[1], &baslb[1], &basub[1], &cola[1], &coli[1],
	colmax, &fcode, ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], 
        &memr[1]);
  if (fcode != 1) exit(1);
/*
 *  write out the current basis and status lists in case a re-start
 *  is necessary.
 */
/*
  if (iobsf != 0) {long j;
    for (i = 1, i__1 = 1; i <= *m; ++i, ++i__1) {
      fprintf(iobsf, "%6ld", basis[i]);
      if (!(i__1 % 10))	fprintf(iobsf, "\n");
    }
    if ((i__1 - 1) % 10) fprintf(iobsf, "\n");
    for (j = 1, i__1 = 1; j <= *n; ++j, ++i__1) {
      fprintf(iobsf, "%6ld", status[j]);
      if (!(i__1 % 10))	fprintf(iobsf, "\n");
    }
    if ((i__1 - 1) % 10) fprintf(iobsf, "\n");
    rewind(iobsf);
  }
*/
  *factit = 0;
/*
 *  re-compute the basic variables using the re-factored basis. 
 */
  xbcomp(&b[1], &bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax,
       ioerr, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &
	 status[1], &xbzero[1], z);

  if (*print == 2)
    fprintf(iolog, "iteration=%6ld     phase 2 objective=%16.8f\n", *iter, *z);
  if (!pok) goto L3748;
/*
 *  check to make sure that primal feasibility has not been lost. 
 */
  *termin = 0;
  for (i = 1; i <= *m; ++i)
    if (xbzero[i] - baslb[i] < -eps2 || xbzero[i] - basub[i] > eps2) {
      fprintf(ioerr, "xphas2...variable %ld is out of bounds:\n", basis[i]);
      fprintf(ioerr, "%16.8f%16.8f%16.8f\n", baslb[i], xbzero[i], basub[i]);
      *termin = 3;
    }

L376:
  if (*termin == 3) {
    fprintf(ioerr, "xphas2...primal feasibility lost...return to phase 1\n");
    goto L700;
  }

L380:           /* update the dual variables. */
  for (i = 1; i <= *m; ++i) {
    uzero[i] = bascb[i];
  }
  xbtran(ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1], &uzero[1]);
  goto L240;

L410: /* come here when no further improvement in the objective can be made. */
  *termin = 1;
  if (*print == 0) goto L700;
  fprintf(iolog, "xphas2... optimal solution found.\n");
  goto L700;

L600:               /* come here if an unbounded condition is detected. */
  *termin = 2;
  *unbddq = q;
  if (*print == 0) goto L700;
  fprintf(iolog, "xphas2...problem is unbounded.   ( variable %ld )\n", q);

L700:  /* restore the value of look, and flush out the rejected pivot list. */
  *look = savelk;
  if (nrej > 0) {
    i__1 = nrej;
    for (ir = 1; ir <= i__1; ++ir) {
      jj = reject[ir - 1];
      status[jj] = stsave[ir - 1];
    }
    nrej = 0;
  }
  return;
}				/* xphas2 */

/* ============================================================ xpivot === 
 *     *****purpose: 
 *     the purpose of this routine is to pivot the chosen 
 *     variable, q, into the basis.  this involves: 
 *        1) ftran'ing the pivot column; 
 *        2) determining the variable that leaves the basis; 
 *        3) updating the basis inverse representation; and 
 *        4) updating the arrays pertaining to the primal solution. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     dq          is the 'relative profit' or 'reduced profit' 
 *                 of the entering variable. 
 *     intyp       +1 means the entering variable is increasing 
 *                    from its lower bound. 
 *                 -1 means the entering variable is decreasing 
 *                    from its upper bound. 
 *     lq          is the lower bound on the entering variable. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     q           the index of the entering variable. 
 *     uq          is the upper bound for the entering variable. 
 *     yq          contains the unpacked column that is about 
 *                 to enter the basis. 
 *     z           is the value of the objective function. 
 *     on output: 
 *     leave       is the index of the variable that leaves the 
 *                 basis when variable q enters. 
 *     outtyp      +1 means the leaving variable is going to its 
 *                    lower bound; 
 *                 -1 means the leaving variable is going to its 
 *                    upper bound; 
 *                  0 means the entering and leaving variables are 
 *                    the same. 
 *     pcode       a return code.  pcode = -1 if the pivot 
 *                 column has been rejected because the pivot 
 *                 element is too small; otherwise pcode is 
 *                 set equal to the value of ucode returned 
 *                 by xupdat. 
 *     pivot       is the pivot element. 
 *     r           the position of the leaving variable, 
 *                 i.e., the index of the variable leaving the basis 
 *                 is basis(r). 
 *                 if outtyp=0, then r=0. 
 *                 if feasibility has been lost during phase 2, 
 *                 then r=-1. 
 *     theta       is the amount of change in the variable 
 *                 entering the basis, i.e. the value of the 
 *                 winning ratio from the primal ratio test. 
 *     unbdd       .true. if unbounded condition has been detected; 
 *                 .false. otherwise. 
 *     yq          contains the ftran'ed version of the entering 
 *                 column, i.e. (basis inverse)*(column) 
 *     in addition, the following arrays have been updated: 
 *     basis,baslb,basub,status,xbzero. 
 *     the basis inverse representation has also been 
 *     updated by xupdat. 
 *     *****algorithm notes: 
 *     after the ratio test, performed by xchuzr, the 
 *     proposed pivot column is rejected if the pivot 
 *     element is too small.  (less than eps3 in absolute value) 
 *     this is to guard against numerical instability. 
 * 
 */
void xpivot(basis, baslb, basub, dq, intyp, ioerr, leave, lq, m, mapi, mapr, 
            maxm, maxn, memi, memr, n, outtyp, pcode, phase, pivot, q, r, 
            status, theta, unbdd, uq, xbzero, yq, z)
long *basis;
double *baslb, *basub, *dq;
FILE *ioerr;
long *intyp, *leave;
double *lq;
long *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *outtyp, *pcode, *phase;
double *pivot;
long *q, *r, *status;
double *theta;
long *unbdd;
double *uq, *xbzero, *yq, *z;
{
  long ucode;

/*
 *  Subroutines called
 */  
  void xupdx(), xftran(), xupdat(), xchuzr();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --basub;
  --baslb;
  --basis;

/* ------------------- Function body ------------------- */
  *pcode = 1;

  xftran(&yq[1], ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1]);

  xchuzr(&basis[1], &baslb[1], &basub[1], intyp, ioerr, lq, m, maxm, maxn,
	 n, outtyp, phase, pivot, q, r, &status[1], theta, unbdd, uq, &
	 xbzero[1], &yq[1]);
/*
 *  return immediately if we have lost feasibility during phase 2. 
 */
  if (*r < 0) return;
  *leave = *q;
  if (*outtyp != 0) *leave = basis[*r];
/*
 *  check to see if the objective is unbounded in direction q. 
 */
  if (*unbdd) return;
  if (abs(*pivot) <= eps3) {
    *pcode = -1;
    return;
  }
  if (*outtyp != 0) {
    xupdat(ioerr, m, &mapi[1], &mapr[1], &memi[1], &memr[1], r, &ucode);
    *pcode = ucode;
    if (*pcode != 1) return;
  }
  xupdx(&basis[1], &baslb[1], &basub[1], dq, intyp, lq, m, maxm, maxn, n,
	outtyp, q, r, &status[1], theta, uq, &xbzero[1], &yq[1], z);

  return;
}				/* xpivot */

/* ============================================================ xpriml === 
 *     *****purpose: 
 *     this routine is the top level routine for the 
 *     primal simplex method. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     factor      is the re-factorization frequency. 
 *     look        is the number of columns to be considered 
 *                 during construction of the candidate list. 
 *                 controls partial pricing. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     pick        is the size of the candidate list used for 
 *                 multiple pricing. 
 *     print       specifies the level of printing desired: 
 *                  0 means error messages only; 
 *                  1 means termination condition messages; 
 *                  2 means log information at every iteration. 
 *     z           is the value of the objective function. 
 *     on output: 
 *     iter1       contains the number of phase 1 iterations 
 *                 performed. 
 *     iter2       contains the number of phase 2 iterations 
 *                 performed. 
 *     termin      is the termination code for the primal simplex method:
 *
 *                 1 means optimal solution found; 
 *                 2 means the problem is unbounded; 
 *                 3 means the problem is infeasible; 
 *                 4 means the presumed optimal solution does 
 *                   not satisfy the accuracy check; 
 *                 5 means the problem has been abandoned. 
 *     unbddq      if the problem is unbounded, then unbddq is 
 *                 the index of the variable that was about to 
 *                 enter the basis when the unbounded condition 
 *                 was detected. 
 *     yq          if the problem is unbounded, then yq contains 
 *                 the ftran'ed version of the column that was 
 *                 about to enter the basis when the unbounded 
 *                 condition was detected. 
 *
 *     the following arrays contain the last solution obtained: 
 *     bascb,basis,baslb,basub,status,uzero,xbzero,z 
 *
 *     *****algorithm notes: 
 *     the following arrays must be set before calling xpriml: 
 *     b,bascb,basis,baslb,basub,status,xbzero 
 *
 *     the following are scratch arrays with respect to 
 *     this routine.  that is, they must be provided by the 
 *     calling program, but they do not have to be set. 
 *        cola,coli,yq  
 */
void xpriml(b, bascb, basis, baslb, basub, bndtyp, bound, cola, coli, colmax, 
            factor, ioerr, iolog, iter1, iter2, look, m, mapi, mapr, maxm, 
            maxn, memi, memr, n, ntype2, pick, print, status, termin, unbddq, 
            uzero, xbzero, yq, z)
double *b, *bascb;
long *basis;
double *baslb, *basub;
long *bndtyp;
double *bound, *cola;
FILE *iolog;
FILE *ioerr;
long *coli, *colmax, *factor, *iter1, *iter2, *look, *m, *mapi, *mapr;
long *maxm, *maxn, *memi;
double *memr;
long *n, *ntype2, *pick, *print, *status, *termin, *unbddq;
double *uzero, *xbzero, *yq, *z;
{
/*
 *  Initialized data 
 */
  static long factit = 0;

/*
 *  Local variables
 */
  long feas, ichk, i, fcode;
  long error;
  long dblchk;
  long dindex, pindex;
  double dtoler, derror;
  double ptoler, perror;
  long dok, pok;

/*
 *  Subroutines called
 */  
  void xfact(), xfeas(), xstop(), xphas2(), xcheck(), xbcomp();
  void xbtran(), xzcomp();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --basub;
  --baslb;
  --basis;
  --bascb;
  --b;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xpriml     %ld\n", *m);
    xstop(&error, ioerr);
  }
  if (*n < 1 || *n > *maxn) {
    error = 2;
    fprintf(ioerr, "xpriml     %ld\n", *n);
    xstop(&error, ioerr);
  }
  if (*iter1 > 0 || *iter2 > 0) goto L120;
  factit = 0;

L120:
  *iter1 = 0;
  *iter2 = 0;
  dtoler = eps1;
  ptoler = eps2;
  dblchk = TRUE;

L140:
  xfeas(&b[1], &bascb[1], &basis[1], &baslb[1], &basub[1], bndtyp, bound, 
        &cola[1], &coli[1], colmax, &factit, factor, &feas, ioerr, iolog,
	iter1, look, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1],
        n, ntype2, pick, print, &status[1], &uzero[1], &xbzero[1], 
        &yq[1], z);

  if (feas == 2) {        /* infeasible */
    *termin = 3;
    dblchk = FALSE;
    goto L165;
  } else if (feas == 3) { /* abandoned */
    *termin = 5;
    return;
  }
/*
 *  get ready for phase 2. 
 */
/*
 *  compute the current value of the phase 2 objective. 
 */
  xzcomp(&bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax, ioerr, m, 
         &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &status[1],
	 &xbzero[1], z);
/*
 *  compute the dual variables based on the phase 2 objective. 
 */
  for (i = 1; i <= *m; ++i) uzero[i] = bascb[i];
  xbtran(ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1], &uzero[1]);
  xphas2(&b[1], &bascb[1], &basis[1], &baslb[1], &basub[1], bndtyp, bound,
	 &cola[1], &coli[1], colmax, &factit, factor, ioerr, iolog, iter2,
	 look, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n,
	 ntype2, pick, print, &status[1], termin, unbddq, &uzero[1], 
         &xbzero[1], &yq[1], z);
  if (*termin == 5) return;
  if (*termin == 3) goto L140;

L165:                 /* check the final solution for accuracy. */
  ichk = 0;

L170:
  xcheck(&b[1], &basis[1], bndtyp, bound, &cola[1], &coli[1], colmax, 
         &dblchk, &derror, &dindex, &dok, &dtoler, ioerr, m, &mapi[1], 
         &mapr[1], maxm, maxn, &memi[1], &memr[1], n, &perror, &pindex, 
         &pok, &ptoler, &status[1], &uzero[1], &yq[1], &xbzero[1]);
  ++ichk;
  if (dok && pok) return;
  if (ichk == 1) goto L180;
  *termin = 4;
  return;

L180:  /* factor the final basis to improve accuracy, if necessary. */
  xfact(&bascb[1], &basis[1], &baslb[1], &basub[1], &cola[1], &coli[1],
	colmax, &fcode, ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], 
        &memr[1]);
  if (fcode != 1)  exit(1);
/*
 *  re-compute the values of the basic variables and of the objective 
 *  function using the re-factored basis. 
 */
  xbcomp(&b[1], &bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax,
         ioerr, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, 
         &status[1], &xbzero[1], z);
/*
 *  re-compute the values of the dual variables using the re-factored basis. 
 */
  for (i = 1; i <= *m; ++i) uzero[i] = bascb[i];
  xbtran(ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1], &uzero[1]);
  goto L170;
}				/* xpriml */

/* ============================================================ xprint === 
 *     *****purpose: 
 *     this routine prints out the current basic solution 
 *     and the objective function value. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     ioerr       is the i/o unit where error messages are to 
 *                 be written. 
 *     iolog       is the i/o unit where log information is to 
 *                 be written, if requested. 
 *     on output: 
 *     the current basic solution and the objective function 
 *     value have been written out on i/o unit iolog. 
 *     *****application and usage restrictions: 
 *     this routine has been modified to accept super-basic 
 *     variables.  
 */
void xprint(basis, bndtyp, bound, ioerr, iolog, m, mapi, mapr, maxm, maxn, 
            memi, memr, n, ntype2, status, xbzero, z)
long *basis, *bndtyp;
double *bound;
FILE *iolog;
FILE *ioerr;
long *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *ntype2, *status;
double *xbzero, *z;
{
/*
 *  f2c generated locals
 */
  long i__2;

/*
 *  Local variables
 */
  long i, j;
  double value;
  double lj, uj;
  long ix;

/*
 *  Subroutines called
 */  
  void xgetub();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --xbzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --basis;

/* ------------------- Function body ------------------- */
  fprintf(iolog, "xprint...current solution\n");
  fprintf(iolog, "    %6ld equations     %ld variables\n", *m, *n);
  fprintf(iolog, "  variable         status                value\n");
/*
 *  print out the values of all of the basic variables and all of the 
 *  non-basic variables that are at non-zero bounds. 
 */
  for (j = 1; j <= *n; ++j) {
    if ((i__2 = status[j]) < 0) {
      goto L200;
    } else if (i__2 == 0) {
      goto L250;
    } else {
      goto L260;
    }

L200:
    if (status[j] == -3) goto L230;
    if (status[j] == -2) continue;
    if (status[j] == -4) goto L250;
/*
 *  here for non-basic variables at their upper bounds. 
 */
    if (*bndtyp >= 3) {
      xgetub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], 
             &memr[1], &uj);
      value = uj;
    } else if (*bndtyp == 2) {
      if (j > *ntype2) goto L220;
      value = *bound;
    } else {
      goto L220;
    }
    goto L270;

L220:
    fprintf(iolog,
     "****error: variable %ld is at its upper bound of +infinity.\n", j);
    continue;

L230:              /* here for artificial variables. */
    for (i = 1; i <= *m; ++i)
      if (basis[i] == j) {
	value = xbzero[i];
	goto L270;
      }
    continue;

L250:              /* here for non-basic variables at their lower bounds. */
    if (*bndtyp != 4) continue;
    xgetub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], &memr[1],&uj);
    if (lj == 0.) continue;
    value = lj;
    goto L270;

L260:              /* here for the basic variables (except artificials) */
    ix = status[j];
    value = xbzero[ix];
    if (ix <= *m) goto L270;
/*
 *  here for super-basic variables. 
 */
    fprintf(iolog, "%10ld %14ld      sb  %16.8f\n", j, status[j], value);
    continue;

L270:
    fprintf(iolog, "%10ld %14ld     %16.8f\n", j, status[j], value);
  }
/*
 *  print the objective value. 
 */
  fprintf(iolog, "value of linear objective function=%16.8f\n", *z);
  return;
}				/* xprint */

/* ============================================================ xprior === 
 *     *****purpose: 
 *     this routine attempts to pivot a given priority list of variables
 *     into the basis. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     prlist            >0 means the corresponding variable should be 
 *                          pivoted into the basis; 
 *                       =0 is just a filler. 
 *     on output: 
 *     prlist            >0 means the corresponding variable was 
 *                          pivoted into the basis; 
 *                       =0 is just a filler; 
 *                       <0 means the corresponding variable could not 
 *                          be pivoted into the basis. 
 *
 *     *****application and usage restrictions: 
 *     note that prlist(1),...,prlist(m) has to be initialized to zero. 
 *     then any non-zero indicates a variable that should be pivoted 
 *     into the basis. 
 *
 *     this routine will not update the objective function value. 
 *     this is okay if you are going to call xpriml afterwards. 
 *     otherwise you should follow xprior with a call to xzcomp. 
 *
 *     the variables that leave the basis are determined by a call to 
 *     xchuzr.  thus priority variables that are pivoted into the basis 
 *     may subsequently be pivoted out again during xprior! 
 *
 */
void xprior(bascb, basis, baslb, basub, bndtyp, bound, cola, coli, colmax, 
            ioerr, iolog, m, mapi, mapr, maxm, maxn, memi, memr, n, ntype2, 
            prlist, status, xbzero, yq)
double *bascb;
long *basis;
double *baslb, *basub;
long *bndtyp;
double *bound, *cola;
FILE *iolog;
FILE *ioerr;
long *coli, *colmax, *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *ntype2, *prlist, *status;
double *xbzero, *yq;
{
/*
 *  f2c generated locals
 */
  long i__2;

/*
 *  Local variables
 */
  long i, k, q, r, pcode, leave;
  long unbdd;
  long phase;
  double theta;
  long count, error;
  double ztemp, pivot;
  long intyp;
  double cj;
  long ik;
  double dq, lq, uq;
  long collen;
  long county;
  long outtyp, ikx;

/*
 *  Subroutines called
 */  
  void xstop(), xgetaj(), xgetub(), xpivot();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --status;
  --prlist;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --basub;
  --baslb;
  --basis;
  --bascb;

/* ------------------- Function body ------------------- */
  count = 0;
  county = 0;
  ztemp = (float) 0.;
  for (i = 1; i <= *m; ++i) {        /* begin main loop. */
    if (prlist[i] == 0) continue;
    q = prlist[i];
    ++count;
    if (status[q] > 0) {
      fprintf(ioerr, "xprior...variable %ld is already basic\n", q);
      continue;
    } else if (status[q] <= -4) {
      fprintf(ioerr, "xprior...variable %ld is locked\n", q);
      prlist[i] = -q;
      continue;
    }
    xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &q, &mapi[1],
	   &mapr[1], &memi[1], &memr[1]);
    for (k = 1; k <= *m; ++k) yq[k] = (float) 0.;
    if (collen > 0) {
      i__2 = collen;
      for (ik = 1; ik <= i__2; ++ik) {
	ikx = coli[ik];
	yq[ikx] = cola[ik];
      }
    }
    if (status[q] == -2) {
      lq = -big;
      uq = big;
    } else if (*bndtyp == 1) {
      lq = (float) 0.;
      uq = big;
    } else if (*bndtyp == 2) {
      lq = (float) 0.;
      uq = *bound;
      if (q > *ntype2) uq = big;
    } else {
      xgetub(bndtyp, ioerr, &q, &lq, &mapi[1], &mapr[1], &memi[1], 
             &memr[1], &uq);
    }
    if (status[q] == 0 || status[q] == -2) {
      intyp = 1;
      dq = (float) 1.;
    } else if (status[q] == -1) {
      intyp = -1;
      dq = (float) -1.;
    } else {
      fprintf(ioerr,
	      "xprior...variable %ld has status %ld\n", q, status[q]);
      error = 0;
      xstop(&error, ioerr);
    }
    phase = 1;
    xpivot(&basis[1], &baslb[1], &basub[1], &dq, &intyp, ioerr, &leave, 
           &lq, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n,
	   &outtyp, &pcode, &phase, &pivot, &q, &r, &status[1], &theta, 
           &unbdd, &uq, &xbzero[1], &yq[1], &ztemp);
    if (!unbdd && pcode == 1) {
      ++county;
      bascb[r] = cj;
    } else {
      prlist[i] = -q;
    }
  }  /* end of main loop. */
  fprintf(iolog, "xprior: %ld priority variables\n", count);
  fprintf(iolog, "        %ld brought into basis\n", county);
  return;
}				/* xprior */

/* ============================================================ xslack === 
 *    *****purpose:
 *    this routine is called after an initial set of structural
 *    variables has been entered.  it sets up an initial basis
 *    so that the primal or dual simplex method can be applied.
 *    xslack takes as input the number of constraints,
 *    the right-hand-side, the list of row types, and the status
 *    of the structural variables.  (the structural variables,
 *    which are all made non-basic, may be at their lower or upper
 *    bounds, as indicated by their status.)  this routine
 *    adds a slack variable for each less-than-or-equal
 *    constraint, a surplus variable for each greater-than-
 *    or-equal constraint, an artificial variable (with
 *    upper and lower bounds of zero) for each equation,
 *    and a free variable for each free row.
 *    it constructs an initial basis from these variables, factors that
 *    basis, and sets the primal and dual solutions and the
 *    objective function value accordingly.
 *
 *
 *    for two-sided constraints:
 *
 *            blow(i) .le. sum(over j) a(i,j)*x(j) .le. b(i)
 *
 *    a slack variable is added with lower bound zero and
 *    upper bound b(i)-blow(i).
 *    an error stop will occur unless b(i) exceeds or
 *    equals blow(i).
 *    note:  you must use bndtyp at least 3 in order to use
 *           two-sided constraints, since the slack must have
 *           a finite upper bound.
 *
 *
 *    (xslack may be called, if desired, before any of the
 *    structural variables have been entered.)
 *
 *    *****argument description:
 *    see xmp dictionary for arguments not described here.
 *    on input:
 *    b           is the right hand side array.
 *                (it contains the upper limit for each
 *                 two-sided constraint)
 *    blow        contains the lower limit for each
 *                two-sided constraint.
 *    m           is the number of constraints, i.e. the
 *                number of rows in the original a-matrix.
 *    n           is the number of structural variables,
 *                i.e. the number of columns in the original
 *                a-matrix.
 *    rowtyp      is the array of row types:
 *                +2 means a two-sided constraint;
 *                +1 means less than or equal to;
 *                 0 means equation;
 *                -1 means greater than or equal to;
 *                -2 means a free row (functional).
 *    status      has already been set for the structural variables.
 *    on output:
 *    bascb       is an array containing the objective function
 *                coefficients of the basic variables.
 *    basis       is the list of basic variables.
 *    baslb       is an array containing the lower bounds
 *                on the basic variables.
 *    basub       is an array containing the upper bounds
 *                on the basic variables.
 *    n           is the number of variables (total, including
 *                slacks and artificials).
 *    status      has been set for the slack and artificial
 *                variables.
 *    uzero       the array containing the values of the dual
 *                variables.
 *    xbzero      the array containing the values of the basic
 *                variables.
 *    z           is the value of the objective function.
 *                in fact, z is the
 *                objective contribution of the non-basic
 *                variables, since all of the slack, surplus,
 *                artificial, and free
 *                variables have objective coefficients of zero.
 *    *****application and usage restrictions:
 *    *****algorithm notes:
 *
 *
 *
 * row type   rowtyp        action
 * --------   ------        -----------------------------------
 * 2-sided     +2            +slack  (with finite upper bound)
 * le          +1            +slack
 * eq           0            +artificial  (both bounds zero)
 * ge          -1            -surplus
 * free        -2            +free
 *
 *
 *
 */
void xslack(b, bascb, basis, baslb, basub, blow, bndtyp, bound, cola, coli, 
            colmax, ioerr, m, mapi, mapr, maxm, maxn, memi, memr, n, rowtyp, 
            status, uzero, xbzero, z)
double *b, *bascb;
long *basis;
double *baslb, *basub, *blow;
long *bndtyp;
double *bound, *cola;
FILE *ioerr;
long *coli, *colmax, *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *rowtyp, *status;
double *uzero, *xbzero, *z;
{
/*
 *  f2c generated locals
 */
  long i__2;

/*
 *  Local variables
 */
  long i, k, j, fcode;
  long error;
  double cj, lj;
  double uj;
  long collen;

/*
 *  Subroutines called
 */  
  void xfact(), xstop(), xaddaj(), xaddub(), xbcomp();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --xbzero;
  --uzero;
  --status;
  --rowtyp;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --blow;
  --basub;
  --baslb;
  --basis;
  --bascb;
  --b;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xslack     %ld\n", *m);
    xstop(&error, ioerr);
  }
  if (*n < 0 || *n > *maxn) {
    error = 2;
    fprintf(ioerr, "xslack     %ld\n", *n);
    xstop(&error, ioerr);
  }
/*
 *  if there are tw0-sided constraints, make sure that there is space 
 *  reserved for upper bounds. 
 */
  k = 0;
  for (i = 1; i <= *m; ++i) if (rowtyp[i] == 2) k = 1;
  if ((k > 0) && (*bndtyp < 3)) {
    fprintf(ioerr,
      "xslack...bndtyp must be at least 3 when using two-sided constraints\n");
    error = 0;
    xstop(&error, ioerr);
  }
  cj = (float) 0.;
  collen = 1;
  for (i = 1; i <= *m; ++i) {    /*  beginning of main loop. */
    lj = (float) 0.;
    uj = big;
    baslb[i] = (float) 0.;
    basub[i] = big;
    bascb[i] = (float) 0.;
    uzero[i] = (float) 0.;
    if ((i__2 = rowtyp[i]) < 0) {
      goto L120;
    } else if (i__2 == 0) {
      goto L150;
    } else {
      goto L190;
    }

L120:
    if (rowtyp[i] <= -2) goto L220;
/*
 *  here for a greater than or equal to constraint. 
 *  subtract a surplus variable and put it in the basis. 
 */
    cola[1] = (float) -1.;
    coli[1] = i;
    xaddaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1], n);
    if (*bndtyp >= 3)
      xaddub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], 
             &memr[1], &uj);
    basis[i] = j;
    status[j] = i;
    continue;

L150:
/*
 *  here for an equation. add an artificial variable and put it in the basis.
 *  make the lower and upper bounds both zero so that it will be forced out. 
 */
    cola[1] = (float) 1.;
    coli[1] = i;
    basub[i] = (float) 0.;
    xaddaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1], n);
    uj = (float) 0.;
    if (*bndtyp >= 3)
      xaddub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1],
             &memr[1], &uj);
    basis[i] = j;
    status[j] = -3;
    continue;

L190:
/*
 *  here for a less than or equal to constraint. 
 *  add a slack variable and put it in the basis. 
 */
    cola[1] = (float) 1.;
    coli[1] = i;
    xaddaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1], n);
/*
 *  check for two-sided constraint. 
 */
    if (rowtyp[i] == 2) {
      uj = b[i] - blow[i];
      basub[i] = uj;
      if (uj < 0.) {
	fprintf(ioerr, "xslack...two-sided constraint %ld\n", i);
	fprintf(ioerr,
		"lower limit exceeds upper limit:  %16.8f%16.8f\n",
		blow[i], b[i]);
	error = 0;
	xstop(&error, ioerr);
      }
    }
    if (*bndtyp >= 3)
      xaddub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], 
             &memr[1], &uj);
    basis[i] = j;
    status[j] = i;
    continue;

L220:
/*
 *  here for a free constraint. add a free variable and put it in the basis. 
 */
    cola[1] = (float) 1.;
    coli[1] = i;
    baslb[i] = -big;
    xaddaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1], n);
    lj = -big;
    if (*bndtyp == 4)
      xaddub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], 
             &memr[1], &uj);
    basis[i] = j;
    status[j] = i;
  }             /* end of main loop. */
/*
 *  factor the starting basis. 
 */
  xfact(&bascb[1], &basis[1], &baslb[1], &basub[1], &cola[1], &coli[1],
	colmax, &fcode, ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], 
        &memr[1]);
  if (fcode != 1) exit(1);
/*
 *  compute the values of the basic variables, and the value 
 *  of the phase 2 objective function. 
 */
  xbcomp(&b[1], &bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax,
         ioerr, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, 
         &status[1], &xbzero[1], z);
  return;
}				/* xslack */

/* ============================================================ xstart === 
 *     *****purpose: 
 *     use this routine to start the primal or dual 
 *     simplex method from any given basis. 
 *     the given basis is specified by the basis and 
 *     status arrays. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     basis       is the list of basic variables. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     status      an indicator for each variable: 
 *                  0 means the variable is out at its lower bound; 
 *                  k means that this is the k-th basic variable; 
 *                 -1 means that this variable is out at its upper bound;
 *                 -2 means that this is a free variable...once in the 
 *                    basis it never leaves; 
 *                 -3 means that this is an artificial variable...once 
 *                    it leaves the basis it never re-enters. 
 *                 -4 means the variable is locked out of the 
 *                    basis at its lower bound; 
 *                 -5 means the variable is locked out of the 
 *                    basis at its upper bound. 
 *                 note: artificial variables always have 
 *                 status -3, they do not get a positive 
 *                 status when they are in the basis. 
 *     on output: 
 *     bascb       is an array containing the objective function 
 *                 coefficients of the basic variables. 
 *     baslb       is an array containing the lower bounds 
 *                 on the basic variables. 
 *     basub       is an array containing the upper bounds 
 *                 on the basic variables. 
 *     scode       is a return code for xstart: 
 *                 1 means everything ok; 
 *                 2 means the given basis was singular. 
 *     uzero       the array containing the values of the dual 
 *                 variables. 
 *     xbzero      the array containing the values of the basic 
 *                 variables. 
 *     z           is the value of the objective function. 
 *     *****application and usage restrictions: 
 *     after calling xstart you may call any of the 
 *     following iterating routines: 
 *     xpriml, xfeas, xphas2 (if given basis 
 *     is primal feasible), xdual, xdph2 (if given 
 *     basis is dual feasible). 
 */
void xstart(b, bascb, basis, baslb, basub, bndtyp, bound, cola, coli, colmax, 
            ioerr, m, mapi, mapr, maxm, maxn, memi, memr, n, ntype2, scode, 
            status, uzero, xbzero, z)
double *b, *bascb;
long *basis;
double *baslb, *basub;
long *bndtyp;
double *bound, *cola;
FILE *ioerr;
long *coli, *colmax, *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *ntype2, *scode, *status;
double *uzero, *xbzero, *z;
{
/*
 *  Local variables
 */
  long i, j, fcode;
  long error;
  double cj, lj, uj;
  long collen;

/*
 *  Subroutines called
 */  
  void xfact(), xstop(), xgetaj(), xbcomp(), xgetub(), xbtran();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --xbzero;
  --uzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --basub;
  --baslb;
  --basis;
  --bascb;
  --b;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xstart     %ld\n", *m);
    xstop(&error, ioerr);
  }
  *scode = 1;
/*
 *  set the lower and upper bounds on the basic variables,
 *  and set the objective function coefficients for the basic variables. 
 */
  for (i = 1; i <= *m; ++i) {
    j = basis[i];
    xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1]);
    bascb[i] = cj;
    if (status[j] == -2) goto L104;
    if (status[j] == -3) goto L105;
    switch ((int) *bndtyp) {
    case 1:  goto L101;
    case 2:  goto L102;
    case 3:  goto L103;
    case 4:  goto L103;
    }

L101:                     /* here for the standard case: zero and +infinity */
    baslb[i] = (float) 0.;
    basub[i] = big;
    continue;

L102:          /* here if all the non-free structurals have a common bound. */
    baslb[i] = (float) 0.;
    basub[i] = *bound;
    if (j > *ntype2) basub[i] = big;
    continue;

L103:                     /* here for general bounds. */
    xgetub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], &memr[1],&uj);
    baslb[i] = lj;
    basub[i] = uj;
    continue;

L104:                     /*  here for free variables */
    fprintf(ioerr, "xstart...basic free variable with -2 status\n");
    error = 0;
    xstop(&error, ioerr);

L105:                     /*  here for artificial variables */
    baslb[i] = (float) 0.;
    basub[i] = (float) 0.;
  }

/*
 *  factor the given basis. 
 */
  xfact(&bascb[1], &basis[1], &baslb[1], &basub[1], &cola[1], &coli[1],
	colmax, &fcode, ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], 
        &memr[1]);
  if (fcode != 1) {
    *scode = 2;
    fprintf(ioerr, "xstart.....basis provided is singular\n");
    return;
  }
/*
 *  compute the values of the basic variables and the objective function. 
 */
  xbcomp(&b[1], &bascb[1], bndtyp, bound, &cola[1], &coli[1], colmax,
         ioerr, m, &mapi[1], &mapr[1], maxm, maxn, &memi[1], &memr[1], n, 
         &status[1], &xbzero[1], z);
/*
 *  compute the values of the dual variables. 
 */
  for (i = 1; i <= *m; ++i) uzero[i] = bascb[i];
  xbtran(ioerr, m, &mapi[1], &mapr[1], maxm, &memi[1], &memr[1], &uzero[1]);
  return;
}				/* xstart */

/* ============================================================ xstop  === 
 *     *****purpose: 
 *     the purpose of this routine is to facilitate 
 *     common handling of all fatal errors. 
 *     only the most frequently occuring error messages are 
 *     printed here.  more specialized messages are printed 
 *     in the subroutine where they arise. 
 *
 *     *****argument description: 
 *     on input: 
 *     error       is an error code: 
 *                 1 means invalid number of constraints; 
 *                 2 means invalid number of variables; 
 *                 3 means invalid bound type; 
 *                 4 means invalid column length. 
 *     ioerr       is the i/o unit where error messages are to 
 *                 be written. 
 *     on output: 
 */
void xstop(error, ioerr)
FILE *ioerr;
long *error;
{
  fprintf(ioerr, "\n**********LEIBNIZ SYSTEM ERROR**********");
  fprintf(ioerr, "\n           ERROR IN xstop()");
  fprintf(ioerr, "\n****************************************");
  switch (*error) {
  case 0: exit(1);
  case 1: fprintf(ioerr, "invalid number of constraints.\n");
          exit(1);
  case 2: fprintf(ioerr, "invalid number of variables.\n");
          exit(1);
  case 3: fprintf(ioerr, "invalid bound type.\n");
          exit(1);
  case 4: fprintf(ioerr, "invalid column length.\n");
          exit(1);
  default: exit(1);
  }
}				/* xstop */

/* ============================================================ xupdat === 
 *     *****purpose: 
 *     this subroutine updates the basis inverse representation 
 *     after the entering and leaving variables have been 
 *     selected. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     m           is the number of constraints. 
 *     mapi        is a map of array memi. 
 *     mapr        is a map of array memr. 
 *     memi        array containing hidden integer data 
 *     memr        array containing hidden real data. 
 *     r           the position of the leaving variable, 
 *                 i.e., the index of the variable leaving the basis 
 *                 is basis(r). 
 *     on output: 
 *     the inverse representation has been updated. 
 *     ucode       is a return code for xupdat: 
 *                 1 means everything is ok; 
 *                 2 means refactorization suggested because 
 *                   the number of non-zeros has doubled; 
 *                 3 means the current basis is singular; 
 *                 4 means storage overflow. 
 *                 refactorization is imperative if ucode 
 *                 is 3 or 4. 
 *     *****application and usage restrictions: 
 *     this subroutine is compatible with j. k. reid's la05 
 *     routines for handling an lu factorization of the basis 
 *     matrix.  the 'body of program' must be re-written if some other 
 *     inverse representation is used. 
 *     *****algorithm notes: 
 *     data structure for the basis inverse representation: 
 *
 *     mapi(6)    points to reid's ia constant. 
 *     mapi(7)    points to reid's ip array. 
 *     mapi(8)    points to reid's iw array. 
 *     mapi(9)    points to reid's ind array. 
 *
 *     mapr(5)    points to reid's g constant. 
 *     mapr(6)    points to reid's u constant. 
 *     mapr(7)    points to reid's w array. 
 *     mapr(8)    points to reid's a array. 
 *  
 */
void xupdat(ioerr, m, mapi, mapr, memi, memr, r, ucode)
FILE *ioerr;
long *m, *mapi, *mapr, *memi;
double *memr;
long *r, *ucode;
{
  double g;
  long error;
  long mi6, mi7, mi8, mi9, mr5, mr6, mr7, mr8;

/*
 *  Subroutines called
 */  
  void la05cd(), xstop();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --memr;
  --memi;
  --mapr;
  --mapi;

/* ------------------- Function body ------------------- */
  mi6 = mapi[6];
  mi7 = mapi[7];
  mi8 = mapi[8];
  mi9 = mapi[9];
  mr5 = mapr[5];
  mr6 = mapr[6];
  mr7 = mapr[7];
  mr8 = mapr[8];
  memr[mr5] = (float) 0.;
  la05cd(&memr[mr8], &memi[mi9], &memi[mi6], m, &memi[mi7], &memi[mi8], 
         &memr[mr7], &memr[mr5], &memr[mr6], r);
  g = memr[mr5];
  *ucode = 1;
  if (g >= 0.) return;
  fprintf(ioerr, "xupdat...error return from la05c...g=%10.2f\n", g);
  if (g == -7.)
    fprintf(ioerr, "please increase space for memr and memi arrays\n");
  error = 0;
  xstop(&error, ioerr);
  return;
}				/* xupdat */

/* ============================================================ xupdx  === 
 *     *****purpose: 
 *     this subroutine updates the list of basic variables, 
 *     the values of the basic variables, 
 *     the lists of the lower and upper bounds on 
 *     the basic variables, 
 *     the status array, 
 *     and the value of the objective function. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     dq          is the 'relative profit' or 'reduced profit' 
 *                 of the entering variable. 
 *     intyp       +1 means the entering variable is increasing 
 *                    from its lower bound. 
 *                 -1 means the entering variable is decreasing 
 *                    from its upper bound. 
 *     lq          is the lower bound on the entering variable. 
 *     m           is the number of constraints. 
 *     n           is the number of variables (total, including 
 *                 slacks and artificials). 
 *     outtyp      +1 means the leaving variable is going to its 
 *                    lower bound; 
 *                 -1 means the leaving variable is going to its 
 *                    upper bound; 
 *                  0 means the entering and leaving variables are 
 *                    the same. 
 *     q           the index of the entering variable. 
 *     r           the position of the leaving variable, 
 *                 i.e., the index of the variable leaving the basis 
 *                 is basis(r). 
 *     theta       is the amount of change in the variable 
 *                 entering the basis, i.e. the value of the 
 *                 winning ratio from the primal ratio test. 
 *     uq          is the upper bound for the entering variable. 
 *     z           is the value of the objective function. 
 *     on output: 
 *     basis       contains the updated list of basic variables. 
 *     baslb       contains the updated lower bounds on 
 *                 the basic variables. 
 *     basub       contains the updated upper bounds on 
 *                 the basic variables. 
 *     status      contains the updated status indicators. 
 *     xbzero      contains the updated values of the basic variables. 
 *     z           contains the updated value of the objective function.
 *
 *     *****algorithm notes: 
 *     a free variable that is entering the basis is assumed 
 *     to be starting from zero. i.e. non-basic free variables 
 *     are assumed to have value zero. 
 * 
 */
void xupdx(basis, baslb, basub, dq, intyp, lq, m, maxm, maxn, n, outtyp, q, 
           r, status, theta, uq, xbzero, yq, z)
long *basis;
double *baslb, *basub, *dq;
long *intyp;
double *lq;
long *m, *maxm, *maxn, *n, *outtyp, *q, *r, *status;
double *theta, *uq, *xbzero, *yq, *z;
{
/*
 *  f2c generated locals
 */
  double d__1;

/*
 *  Local variables
 */
  long i, leave;

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --yq;
  --xbzero;
  --status;
  --basub;
  --baslb;
  --basis;

/* ------------------- Function body ------------------- */
  if (*intyp == 1) {        /*  here for a variable entering from its l.b. */
    if (abs(*theta) > zl) {
      *z += *dq * *theta;
      for (i = 1; i <= *m; ++i) {
	xbzero[i] -= yq[i] * *theta;
	if ((d__1 = xbzero[i], abs(d__1)) < zl) xbzero[i] = (float) 0.;
      }
    }
    if (*outtyp != 0) {
      xbzero[*r] = *lq + *theta;
      if (status[*q] == -2) xbzero[*r] = *theta;
    }
  } else if (*intyp == -1) { /* here for a variable entering from its u.b. */
    if (abs(*theta) > zl) {
      *z -= *dq * *theta;
      for (i = 1; i <= *m; ++i) {
	xbzero[i] += yq[i] * *theta;
	if ((d__1 = xbzero[i], abs(d__1)) < zl) xbzero[i] = (float) 0.;
      }
    }
    if (*outtyp != 0) {
      xbzero[*r] = *uq - *theta;
      if (status[*q] == -2) xbzero[*r] = -(*theta);
    }
  }
/*
 *  here to update the basis and status arrays; and the lower and 
 *  upper bound arrays for the basic variables. 
 */
  if (*outtyp != 0) {
    leave = basis[*r];
    basis[*r] = *q;
    status[*q] = *r;
    if (status[leave] != -3) {
      if (*outtyp == 1) {
	status[leave] = 0;
      } else {
	status[leave] = -1;
      }
    }
    baslb[*r] = *lq;
    basub[*r] = *uq;
  } else {
    if (*intyp == 1) {
      status[*q] = -1;
    } else {
      status[*q] = 0;
    }
  }
  return;
}				/* xupdx */

/* ============================================================ xzcomp === 
 *     *****purpose: 
 *     this routine computes the value of the phase 2 
 *     objective function for any basic solution. 
 *     *****argument description: 
 *     see xmp dictionary for arguments not described here. 
 *     on input: 
 *     on output: 
 *     z           is the value of the objective function. 
 *
 *     *****application and usage restrictions: 
 *     this routine has been modified to allow for super-basic 
 *     variables. 
 *
 */
void xzcomp(bascb, bndtyp, bound, cola, coli, colmax, ioerr, m, mapi, mapr, 
            maxm, maxn, memi, memr, n, status, xbzero, z)
double *bascb;
long *bndtyp;
double *bound, *cola;
FILE *ioerr;
long *coli, *colmax, *m, *mapi, *mapr, *maxm, *maxn, *memi;
double *memr;
long *n, *status;
double *xbzero, *z;
{
/*
 *  f2c generated locals
 */
  long i__2;

/*
 *  Local variables
 */
  long i, j, jstat, error;
  double cj, lj, uj;
  long collen;
  double tbound;

/*
 *  Subroutines called
 */  
  void xstop(), xgetaj(), xgetub();

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --xbzero;
  --status;
  --memr;
  --memi;
  --mapr;
  --mapi;
  --coli;
  --cola;
  --bascb;

/* ------------------- Function body ------------------- */
  if (*m < 1 || *m > *maxm) {
    error = 1;
    fprintf(ioerr, "xzcomp     %ld\n", *m);
    xstop(&error, ioerr);
  }
  if (*n < 1 || *n > *maxn) {
    error = 2;
    fprintf(ioerr, "xzcomp     %ld\n", *n);
    xstop(&error, ioerr);
  }
  *z = (float) 0.;
/*
 *  get the basic variables. 
 */
  for (i = 1; i <= *m; ++i) *z += bascb[i] * xbzero[i];
/*
 *   get the non-basic variables. 
 */
  for (j = 1; j <= *n; ++j) {
    if ((i__2 = status[j]) < 0) {
      goto L130;
    } else if (i__2 == 0) {
      goto L160;
    } else {
      goto L175;
    }

L130:
    if (status[j] == -2 || status[j] == -3) continue;
    if (status[j] == -4) goto L160;
/*
 *  here for non-basic variables at their upper bounds. 
 */
    if (*bndtyp == 2) goto L140;
    if (*bndtyp == 3 || *bndtyp == 4) goto L150;
    error = 3;
    fprintf(ioerr, "xzcomp     %ld\n", *bndtyp);
    xstop(&error, ioerr);

L140:
    tbound = *bound;
    goto L170;

L150:
    xgetub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], &memr[1],&uj);
    if (uj == 0.) continue;
    tbound = uj;
    goto L170;

L160:       /*  here for non-basic variables at their lower bounds. */
    if (*bndtyp != 4) continue;
    xgetub(bndtyp, ioerr, &j, &lj, &mapi[1], &mapr[1], &memi[1], &memr[1],&uj);
    if (lj == 0.) continue;
    tbound = lj;

L170:
    xgetaj(&cj, &cola[1], &coli[1], &collen, colmax, ioerr, &j, &mapi[1],
	   &mapr[1], &memi[1], &memr[1]);
    *z += cj * tbound;
    continue;

L175:             /* here for super-basic variables, if any. */
    if (status[j] <= *m) continue;
    jstat = status[j];
    tbound = xbzero[jstat];
    goto L170;
  }
  if (abs(*z) < zlc) *z = (float) 0.;
  return;
}				/* xzcomp */

/* ============================================================ xmaps  === 
 *     this is the standard version of the xmaps routine. 
 *     it assumes that all arrays are either double precision 
 *     (real*8) or full-word integer (integer*4). 
 *     all hidden double precision arrays are placed in the 
 *     double precision array memr.  all hidden integer arrays 
 *     are placed in the integer array memi.  thus there are 
 *     no difficulties with execution-time argument checking. 
 *
 *     the following practices are possible but not recommended: 
 *
 *     1) to use half-words for the three large integer arrays 
 *        (rownos, iw, and ind), set nwordh=2.  then find each 
 *        occurrence of "could use half-words:" in the xdata.for 
 *        file and the la05.for file, and change the "integer" 
 *        declaration on the immediately next line to "integer*2". 
 *        (also in the xla05x routine, which is in the xlp2.for 
 *        file.) 
 *
 *        warning:  the xmp array colpnt and the la05 array ip 
 *                  must be full word integer if you want to allow 
 *                  more than 32,000 non-zeros in the matrix 
 *                  (colpnt) and the basis factors (ip)! 
 *
 *     2) to store the original problem data in single precision, 
 *        set nwords=2.  then find each occurrence of 
 *        "could use single precision:" in the xdata.for file, 
 *        and change the "double precision" declaration on the 
 *        immediately next line to "real". 
 *
 *     to run with either 1) or 2) above, you will have to suppress 
 *     execution-time argument checking (if your system does it). 
 *
 *     *****purpose:
 *     this routine sets up the two maps of the hidden data structure.
 *     this data structure contains both the original problem data
 *     and the current basis inverse representation.  the data
 *     structure is separated into two parts:
 *     the array memi contains all of the integer data and
 *     the array memr contains all of the real data.
 *     mapi is the map of memi (integer data) and
 *     mapr is the map of memr (real data).
 * 
 * 
 * 
 *     this routine also initializes constants in the xmp common
 *     area /xmpcom/ and in reid's common area /la05dd/.
 * 
 *     *****argument description:
 *     on input:
 *     bndtyp      1 means lower bound=0, upper bound=+infinity
 *                   for every variable;
 *                 2 means lower bound=0, upper bound=bound
 *                   for every variable 1,...,ntype2 and
 *                   lower bound=0, upper bound=+infinity for every
 *                   variable past ntype2;
 *                 3 means lower bound=0 for every variable;
 *                 4 means both bounds are general.
 *                 note:  the bound type does not apply to free
 *                        variables or artificial variables.
 *     ioerr       is the i/o unit where error messages are to
 *                 be written.
 *     iolog       is the i/o unit where advisory messages
 *                 are written
 *     print       output option indicator
 *                 = 0 means that error messages only
 *                 = 1 means termination condition messages
 *                 = 2 means print objective function value after
 *                     each basis factorization
 *                 = 3 means log information at every iteration
 *                 change 3/21/94 (k.t.): 
 *                 added iolog and print as parameter to xmaps, 
 *                 and changed writing from ioerr to iolog 
 *                 for advisory messages based on print value
 *     maxa        is the maximum number of non-zeros that will be
 *                 encountered during the current run.
 *                 it is used to set array sizes.
 *     maxm        is the maximum number of constraints that
 *                 will be encountered during the current run;
 *                 it is used to set array sizes.
 *     maxn        is the maximum number of variables that will be
 *                 encountered during the current run;
 *                 it is used to set array sizes.
 *     memi        is the working storage array for hidden integer data.
 *     memr        is the working storage array for hidden real data.
 *     on output:
 *     mapi        is a map of memi (the array for hidden integer data).
 *     mapr        is a map of memr (the array for hidden real data).
 *     *****application and usage restrictions:
 *     this routine depends on the actual data structures for the
 *     problem data and for the basis inverse representation.
 *     the 'body of program' must be modified if either or both
 *     of these data structures are changed.
 * 
 * 
 *     *****algorithm notes:
 * 
 *     map of the hidden integer data:
 * 
 *     mapi(1)    points to the colpnt array.
 *     mapi(2)    points to the rownos array.
 *     mapi(3)    points to the maxa constant.
 *     mapi(4)    points to the maxm constant.
 *     mapi(5)    points to the maxn constant.
 *     mapi(6)    points to the la05 ia constant.
 *     mapi(7)    points to the la05 ip array.
 *     mapi(8)    points to the la05 iw array.
 *     mapi(9)    points to the la05 ind array.
 * 
 * 
 * 
 *     map of the hidden real data.
 * 
 *     mapr(1)    points to the lowerb array.
 *     mapr(2)    points to the upperb array.
 *     mapr(3)    points to the profit array.
 *     mapr(4)    points to the acoeff array.
 *     mapr(5)    points to the la05 g constant.
 *     mapr(6)    points to the la05 u constant.
 *     mapr(7)    points to the la05 w array.
 *     mapr(8)    points to the la05 a array.
 * 
 * 
 * 
 *     array sizes:
 * 
 *     array              no. of entries
 *     ------             --------------
 *     colpnt             maxn+1               contains a pointer to the
 *                                             beginning of each column
 *                                             in the rownos and acoeff
 *                                             arrays.
 * 
 *     rownos             maxa                 contains the row numbers
 *                                             corresponding to the non-
 *                                             zero coefficients in
 *                                             the acoeff array.
 * 
 *     ip                 2*maxm               used by la05.
 *     iw                 8*maxm               used by la05.
 *     ind                variable  (2*ia)     used by la05.
 * 
 *     lowerb             maxn or 0            contains lower bounds
 *                                             on the variables.
 * 
 *     upperb             maxn or 0            contains upper bounds
 *                                             on the variables.
 * 
 *     profit             maxn                 contains the objective
 *                                             function coefficients.
 * 
 *     acoeff             maxa                 contains the non-zero
 *                                             matrix coefficients,
 *                                             in column-major order.
 * 
 *     w                  maxm                 used by la05.
 *     a                  variable   (ia)      used by la05.
 * 
 * 
 *     formulas for determining how much space is available
 *     for the la05 variable length arrays for the basis factors.
 *     note:  lenr is the user specified length for the memr array,
 *     and leni is the user specified length for the memi array.
 * 
 *     lenr = maxn+maxm+maxa+2+ia      if bndtyp=1 or 2
 *          = 2*maxn+maxm+maxa+2+ia    if bndtyp=3
 *          = 3*maxn+maxm+maxa+2+ia    if bndtyp=4
 * 
 *     leni = maxn+10*maxm+maxa+5+2*ia
 * 
 *     so we get for the real data:
 *     ia(real) = lenr-maxn-maxm-maxa-2     if bndtyp=1 or 2
 *              = lenr-2*maxn-maxm-maxa-2   if bndtyp=3
 *              = lenr-3*maxn-maxm-maxa-2   if bndtyp=4
 * 
 *     and for the integer data:
 *     ia(integer) = (leni-maxn-10*maxm-maxa-5)/2
 * 
 *     then we set ia = min(ia(real),ia(integer)) and tell
 *     the user that he may reduce either lenr or leni so that
 *     there is no wasted space.
 */
void xmaps(bndtyp, ioerr, iolog, print, mapi, mapr, maxa, maxm, maxn, memi, 
           memr)
FILE *iolog;
FILE *ioerr;
long *bndtyp, *print, *mapi, *mapr, *maxa, *maxm, *maxn, *memi;
double *memr;
{
/*
 *  f2c generated locals
 */
  float r__1;

/*
 *  Local variables
 */
  double u;
  long itemp;
  float t1, t2;
  long ia;
  long nwordh, mi3, mi4, mi5, mi6, nwords, mr6, iai, iar;

/*
 *  Parameter adjustments (Fortran -> C)
 */
  --memr;
  --memi;
  --mapr;
  --mapi;

/* ------------------- Function body ------------------- */
  nwords = 1;
  nwordh = 1;
/*
 *  begin special section to replace the la05 block data 
 *  program for initializing /la05dd/, 
 *  and to initialize /xmpcom/. 
 *  this is being done because the xmp routines will 
 *  frequently be called from a program library and 
 *  since block data programs are never 'called' they 
 *  don't get loaded. 
 *  for /la05dd/ : 
 */
  smallr = 1e-10;
  lp = ioerr;
/*
 *  for /xmpcom/ : 
 */
  big = 1e30;
  small = 1e-10;
  zl = 1e-10;
  zlc = 1e-10;
  eps1 = 1e-6;
  eps2 = 1e-6;
  eps3 = 1e-6;
  eps4 = .001;
/*
 *  end of special section to replace the block data programs. 
 */
  if (*print > 0) {
    fprintf(iolog, "xmaps...words of memory available\n");
    fprintf(iolog, "integer: %ld          real: %ld\n", leni, lenr);
  }
/*
 *  set up mapi, the map of the hidden integer data. 
 */
  mapi[1] = 1;
  mapi[2] = mapi[1] + 1 + *maxn + 1;
  mapi[3] = mapi[2] + 1 + *maxa / nwordh;
  mapi[4] = mapi[3] + 1;
  mapi[5] = mapi[4] + 1;
  mapi[6] = mapi[5] + 1;
  mapi[7] = mapi[6] + 1;
  mapi[8] = mapi[7] + 1 + (*maxm << 1);
  mapi[9] = mapi[8] + 1 + (*maxm << 3) / nwordh;
/*
 *  set up mapr, the map of the hidden real data. 
 */
  mapr[1] = 1;
  mapr[2] = mapr[1];
  if (*bndtyp == 4) mapr[2] = mapr[1] + 1 + *maxn / nwords;
  mapr[3] = mapr[2];
  if (*bndtyp >= 3) mapr[3] = mapr[2] + 1 + *maxn / nwords;
  mapr[4] = mapr[3] + 1 + *maxn / nwords;
  mapr[5] = mapr[4] + 1 + *maxa / nwords;
  mapr[6] = mapr[5] + 1;
  mapr[7] = mapr[6] + 1;
  mapr[8] = mapr[7] + 1 + *maxm;
/*
 *  figure out how much space is left for the la05 variable length arrays  
 *  (a and ind). 
 */
  iai = (leni - mapi[9] + 1) / 2;
  iai *= nwordh;
  iar = lenr - mapr[8] + 1;
  if (iai > 0 && iar > 0) goto L100;
  fprintf(ioerr, "\n**********LEIBNIZ SYSTEM ERROR**********");
  fprintf(ioerr, "\n           ERROR IN xmaps()");
  fprintf(ioerr, "\n****************************************");
  fprintf(ioerr, "xmaps...no room left for basis factors\n");
  exit(1);

L100:
  if (iai < iar) goto L110;
  ia = iar;                   /* here if lenr is tighter. */
  itemp = leni - (iai - iar);
  goto L120;

L110:
  ia = iai;                    /* here if leni is tighter. */
  itemp = lenr - (iar - iai);

L120:
  if (*print > 0)
    fprintf(iolog,
      "xmaps...you have room for %ld non-zeros in the basis factors\n", ia);
  t1 = (float) (*maxa);
  t2 = (float) (*maxn);
  t2 = t1 / t2 * *maxm;
/*
 *  t2 is the estimated number of non-zeros in the average basis matrix. 
 */
  t1 = (float) ia;
  if (*print > 0) {
    r__1 = t1 / t2;
    fprintf(iolog, "xmaps...this permits a growth factor of %10.2f\n", r__1);
    fprintf(iolog,
    "a growth factor of at least 3.0 is required for successful execution.\n");
  }
  if (iai > iar)
    if (*print > 0)
      fprintf(iolog, "you could reduce integer memory from %ld to %ld\n",
	      leni, itemp);
  if (iar > iai)
    if (*print > 0)
      fprintf(iolog, "you could reduce real memory from %ld to %ld\n",
	      lenr, itemp);
/*
 *  now set necessary constants in the two data structures. 
 */
  u = (float) .1;
  mi3 = mapi[3];
  mi4 = mapi[4];
  mi5 = mapi[5];
  mi6 = mapi[6];
  mr6 = mapr[6];
  memi[mi3] = *maxa;
  memi[mi4] = *maxm;
  memi[mi5] = *maxn;
  memi[mi6] = ia;
  memr[mr6] = u;

  return;
}				/* xmaps */
/*  last record of xpci.c****** */
