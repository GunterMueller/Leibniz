/*  first record of prsfct.c***** */
#include<string.h>
#include<stdio.h>
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/*
 * ********************************************************
 *  subroutine prsfct
 * 
 *  purpose:  parse fact statements.
 * 
 *  calling sequence:
 *     prsfct :- parses the quantification portion of the
 *              statement.
 *       cnvfct :- parses the body of the fact statement.
 * 
 *  caution:  the clause from the .log file is in tmpstr.
 * 
 * *********************************************************
 * 
 */
void prsfct() {
/*
 */
  static long indx,ix;
  static char type[1+1];
  static char nam[58+1];
  static long faflg,teflg,l,r,err;
  static long j,i,x,sidx;
  static long n;
  static char msgstr[128+1];
  static long onewhr;
/*
 */
  void chknam();
  void ckeoln();
  void cnvfct();
  void extcmp();
  void fndnam();
  void inperr();
  int  readlogfil();
  void scrwrt();
  void sonewhr();
/*
 * initialize local variables and strings
 */
  msgstr_(128+1) = '\0';
  nam_(58+1) = '\0';
  type_(1+1) = '\0';
/*
 */
  qnttyp=0;
  faflg=0;
  teflg=0;
  nqnt=0;
  nwhr=0;
  for(i=1; i<=whrmax; i++)  {
    for(ix=1; ix<=qntmax+1; ix++)  {
      whrstm_(ix,i)=0;
    }
  }
  zz50:;
/*
 *   read one record of scrfil into tmpstr
 */
  if (readlogfil()==0) {
    return;
  }
/*
 */
  l=0;
  r=0;
/*
 *  get next component of tmpstr
 */
  zz60:;
  extcmp(tmpstr,&l,&r);
/*
 *  statement continued on next line
 */
  if (lstrncmp(&tmpstr_(l),"$",r-l+1)==0) {
    goto zz50;
  }
/*
 *  check for endata or declaration section keywords
 */
  if (lstrncmp(&tmpstr_(l),"ENDATA",r-l+1)==0) {
    if (strcmp(state ,"Q4010")==0) {
      strcpy(state ,"QEND");
      return;
    } else {
/*
 *  unexpected endata
 */
      inperr(&fatal);
      strcpy(msgstr," LBCC2040: Unexpected ENDATA encountered");
      scrwrt("+W",msgstr);
      return;
    }
  } else if (lstrncmp(&tmpstr_(l),"SETS",r-l+1)==0) {
    inperr(&fatal);
    strcpy(msgstr,
        " LBCC2180: SETS section must come before FACTS");
    scrwrt("+W",msgstr);
    return;
  } else if (lstrncmp(&tmpstr_(l),"VARIABLES",r-l+1)==0) {
    inperr(&fatal);
    strcpy(msgstr,
        " LBCC2180: VARIABLES section must come before FACTS");
    scrwrt("+W",msgstr);
    return;
  } else if (lstrncmp(&tmpstr_(l),"PREDICATES",r-l+1)==0) {
    inperr(&fatal);
    strcpy(msgstr,
        " LBCC2180: PREDICATES section must come before FACTS");
    scrwrt("+W",msgstr);
    return;
  }
/*eject*/
/*
 * ---------------------------------------------
 *  state definitions
 * ---------------------------------------------
 *  at first call to prsfct state = q4000.  we want to
 *  detect an empty facts section, which is condition:
 *    if have endata and state = q4000.
 *  now set state to q4010 which is the beginning state
 *  for remainder of facts section.
 */
  if (strcmp(state ,"Q4000")==0) {
    strcpy(state ,"Q4010");
  }
/*
 * ----------------------------------------------------
 *  state 4160
 *  if the state is q4160, then do an empty transition to
 *  state q4010.  4160 is out of order because its
 *  purpose is to reject an 'ENDATA' following a
 *  quantification statement that has no body,
 *  and since the 'ENDATA' test was passed above,
 *  we do an automatic move to start state.
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4160")==0) {
    strcpy(state ,"Q4010");
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4010 is quantification, where, or body of fact
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4010")==0) {
/*
 *  processing for "FOR ALL"
 */
    if (lstrncmp(&tmpstr_(l),"FOR",r-l+1)==0) {
      if (teflg==1) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1240: Cannot mix quantifiers");
        scrwrt("+W",msgstr);
      }
      faflg=1;
/*
 *  set quantification type to universal
 */
      qnttyp=univ;
      strcpy(state ,"Q4100");
      goto zz60;
    }
/*
 *  processing for "THERE"
 */
    if (lstrncmp(&tmpstr_(l),"THERE",r-l+1)==0) {
      if (faflg==1) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1240: Cannot mix quantifiers");
        scrwrt("+W",msgstr);
      }
      teflg=1;
/*
 *  set quantification type to existential
 */
      qnttyp=exis;
      strcpy(state ,"Q4110");
      goto zz60;
    }
/*
 *  processing for "WHERE"
 */
    if (lstrncmp(&tmpstr_(l),"WHERE",r-l+1)==0) {
      strcpy(state ,"Q4200");
      goto zz60;
    }
/*
 *  if none of the above keywords,
 *  then body of fact statement
 */
    strcpy(state ,"Q4400");
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4100 is "FOR ALL" processing
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4100")==0) {
    strcpy(state ,"Q4120");
/*
 *  expect "all" keyword
 */
    if (lstrncmp(&tmpstr_(l),"ALL",r-l+1)==0) {
      goto zz60;
    } else {
/*
 *  error if "all" not next word
 */
      inperr(&nftl);
      strcpy(msgstr," LBCC1250: Keyword ALL expected");
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4150");
      goto zz60;
    }
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4110 is "THERE EXISTS" processing
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4110")==0) {
    strcpy(state ,"Q4120");
/*
 *  expect "exists" keyword
 */
    if (lstrncmp(&tmpstr_(l),"EXISTS",r-l+1)==0) {
      goto zz60;
    } else {
      inperr(&nftl);
      strcpy(msgstr," LBCC1250: Keyword EXISTS expected");
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4150");
      goto zz60;
    }
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4120 is quantified variable part of
 *  fact statement.
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4120")==0) {
    strcpy(state ,"Q4130");
/*
 *  check if legal name
 */
    n = min(r-l+1,58);
    strncpy(nam,&tmpstr_(l),n);
    nam_(n+1) = '\0';
    chknam(nam,&err,"Q");
    if (err!=0) {
      goto zz60;
    }
/*
 *  check if name already referenced.
 */
    fndnam(nam,&indx,type);
    if (indx>0) {
      inperr(&nftl);
      sprintf(msgstr,
          " LBCC1260: Quantifier already used: %s",
          &qntnam_(1,indx));
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4150");
      goto zz60;
    }
/*
 *  store quantified variable for matching with
 *  predicate definition
 */
    if (nqnt==qntmax) {
      inperr(&nftl);
      n = qntmax;
      sprintf(msgstr,
          " LBCC1270: Too many quantified variables;"
          " at most: %ld",n);
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4150");
      goto zz60;
    }
    nqnt=nqnt+1;
    n = min(r-l+1,58);
    strncpy(&qntnam_(1,nqnt),&tmpstr_(l),n);
    qntnam_(n+1,nqnt) = '\0';
    goto zz60;
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4130 is keyword "IN" processing
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4130")==0) {
    strcpy(state ,"Q4140");
    if (lstrncmp(&tmpstr_(l),"IN",r-l+1)!=0) {
      inperr(&nftl);
      strcpy(msgstr," LBCC1280: Keyword IN expected");
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4150");
    }
    goto zz60;
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4140 is setname
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4140")==0) {
/*
 *  check if setname defined
 */
    n = min(r-l+1,58);
    strncpy(nam,&tmpstr_(l),n);
    nam_(n+1) = '\0';
    fndnam(nam,&indx,type);
    if ((indx>0)&&
        (strcmp(type  ,"S")==0)) {
/*
 *  record that set has been used
 */
      sused_(indx)=1;
/*
 *  put index of set associated with
 *  quantified variable in qsetix.
 *  initialize qperm(i) to 1.
 */
      qsetix_(nqnt)=indx;
      qperm_(nqnt)=1;
      strcpy(state ,"Q4160");
      goto zz60;
    }
/*
 *  setname not found; error
 */
    inperr(&nftl);
    strncpy(auxmsg,&tmpstr_(l),r-l+1);
    auxmsg_(r-l+2) = '\0';
    sprintf(msgstr,
        " LBCC1050: Unrecognized set name: %s",auxmsg);
    scrwrt("+W",msgstr);
    strcpy(state ,"Q4150");
    goto zz60;
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4150: dummy state to handle certain errors.
 *  read from file without processing statements until
 *  get ".", then return.
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4150")==0) {
/*
 *  search for period
 */
    for(j=1; j<=(busmax-1); j++)  {
      if (tmpstr_(j)=='.') {
        strcpy(state ,"Q4010");
        return;
      }
    }
/*
 *  read next record
 */
    goto zz50;
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4200:  left side condition variable of binary
 *                relation of 'WHERE' statement
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4200")==0) {
    if (nqnt==1) {
      inperr(&nftl);
      strcpy(msgstr," LBCC1500: Too many WHERE statements");
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4150");
      goto zz60;
    }
    if (nqnt==2) {
      if (nwhr==1) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1500: Too many WHERE statements");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4150");
        goto zz60;
      }
    }
    if (nqnt==3) {
      if (nwhr==3) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1500: Too many WHERE statements");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4150");
        goto zz60;
      }
    }
    nwhr=nwhr+1;
/*
 *  check that condition variable is one of the current
 *  quantified variables
 */
    for(i=1; i<=nqnt; i++)  {
      if (lstrncmp(&tmpstr_(l),&qntnam_(1,i),r-l+1)==0) {
/*
 *  condition variable is quantified
 *  variable; indicate this
 */
        whrstm_(i,nwhr)=1;
        strcpy(state ,"Q4210");
        goto zz60;
      }
    }
/*
 *  error: condition variable is not recognized
 */
    inperr(&nftl);
    strncpy(auxmsg,&tmpstr_(l),r-l+1);
    auxmsg_(r-l+2) = '\0';
    sprintf(msgstr,
        " LBCC1480: WHERE condition variable"
        " not recognized: %s",auxmsg);
    scrwrt("+W",msgstr);
    strcpy(state ,"Q4150");
    goto zz60;
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4210:  relation of 'WHERE' statement
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4210")==0) {
/*
 *  store relation type
 */
    if (lstrncmp(&tmpstr_(l),"!=",r-l+1)==0) {
      whrstm_(qntmax+1,nwhr)=1;
    } else if (lstrncmp(&tmpstr_(l),"==",r-l+1)==0) {
      whrstm_(qntmax+1,nwhr)=2;
    } else if (lstrncmp(&tmpstr_(l),"<",r-l+1)==0) {
      whrstm_(qntmax+1,nwhr)=3;
    } else if (lstrncmp(&tmpstr_(l),"<=",r-l+1)==0) {
      whrstm_(qntmax+1,nwhr)=4;
    } else if (lstrncmp(&tmpstr_(l),">",r-l+1)==0) {
      whrstm_(qntmax+1,nwhr)=5;
    } else if (lstrncmp(&tmpstr_(l),">=",r-l+1)==0) {
      whrstm_(qntmax+1,nwhr)=6;
    } else {
      inperr(&nftl);
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr,
          " LBCC1490: Unrecognized WHERE relation: %s",
          auxmsg);
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4150");
      goto zz60;
    }
    strcpy(state ,"Q4220");
    goto zz60;
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4220:  right side condition variable of
 *                binary relation of 'WHERE' statement
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4220")==0) {
/*
 *  check that condition variable is one of the
 *  current quantified variables
 */
    for(i=1; i<=nqnt; i++)  {
      if (lstrncmp(&tmpstr_(l),&qntnam_(1,i),r-l+1)==0) {
/*
 *  condition variable is recognized as a quantified
 *  variable; store
 */
        if (whrstm_(i,nwhr)!=0) {
          inperr(&nftl);
          strcpy(msgstr,
              " LBCC1520: Duplicate condition variable"
              " in WHERE statement");
          scrwrt("+W",msgstr);
          strcpy(state ,"Q4160");
          goto zz60;
        }
        whrstm_(i,nwhr)=1;
/*
 *  check that only one 'WHERE' statement is specified
 *  for a given pair for the 3 quantifier case
 */
        if (nqnt==3) {
          if (nwhr>1) {
            sonewhr(&onewhr);
            x=onewhr;
            if (x==1) {
              inperr(&nftl);
              strcpy(msgstr,
                  " LBCC1510: Too many WHERE statements"
                  " for given quantifier pair");
              scrwrt("+W",msgstr);
              strcpy(state ,"Q4150");
              goto zz60;
            }
          }
        }
        strcpy(state ,"Q4160");
        ckeoln(tmpstr,&r);
        goto zz60;
      }
    }
/*
 *  error: condition variable is not recognized
 */
    inperr(&nftl);
    strncpy(auxmsg,&tmpstr_(l),r-l+1);
    auxmsg_(r-l+2) = '\0';
    sprintf(msgstr,
        " LBCC1480: WHERE condition variable"
        " not recognized: %s",auxmsg);
    scrwrt("+W",msgstr);
    strcpy(state ,"Q4150");
    goto zz60;
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state q4400 is body of fact statement
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4400")==0) {
/*
 *  send compacted fact statement to cnvfct,
 *  which will convert the body of fact statement
 *  into internal representation.  if the statement
 *  is syntactically correct, then we convert it to cnf.
 *  cnvfct will detect if a statement spans more than
 *  one line and read them in as well.
 *  determine start index; 0=first component,
 *  l-2 previous component. this for case where body
 *  of fact comes after quant. on same line.
 */
    if (l==1) {
      sidx=0;
    } else {
      sidx=l-2;
    }
    cnvfct(&sidx);
    return;
  }
/*
 * ---------------------------------------------
 *  error section
 * ---------------------------------------------
 *  error if state not found
 */
  fprintf(errfil,"STATE = %s", state);
  printf("STATE = %s", state);
  error(" prsfct ","  4902  ");
}
/*eject*/
/*
 * *****************************************************
 *  subroutine cnvfct
 * 
 *  purpose:  converts a fact statement into internal
 *            format in preparation for makcnf, which
 *            converts to disjunctive
 *            form.  parses statement for
 *            syntactical/semantical correctness.
 *            internal form is:  'AND', 'OR'
 *            converted to &, |.  'IF THEN' converted to
 *            logical equivalent.  separators between all
 *            syntactic components, except for [ ];
 *            separator can come only immediately prior
 *            to [ and -[, and immediately after ].  this
 *            allows entire component within [ ] to be
 *            extracted at once during application of logic
 *            conversion algorithm, and also allows removal
 *            of brackets without removal of separators.
 *
 * 
 *    input:  r      - the index where conversion
 *                     should begin.
 * 
 *   output:  the fact statement in internal form is
 *            written to temporary file (unit = 12; tmp1).
 *            statement is either cnf clause or dnf formula.
 *            with all negations only attached to variables.
 * 
 *   flags:
 *     brkcnt :- <= 0 means not a wff.
 *     ifflg  :- if encountered.
 *     thnflg :- then encountered.
 * 
 *   caution:  tmpstr contains the clause from
 *             the .log file.  the internal (standardized)
 *             clause is built in tmp, then  written out
 *             to file tmp1 to be processed by makcnf.
 *
 *             user may specify -[ AND .. AND ] and [ AND .. AND ]
 *             as bracketed terms. Bracket count brkcnt keeps
 *             track of these terms by brkcnt = no. of opening 
 *             brackets minus no. of closing brackets.
 *             user may not specify brackets in IF THEN 
 *             statements. 
 *             Of course, & may be used instead of AND.
 *
 *             However, IF THEN itself may produce
 *             -[ & .. & ], -[ | .. | ], [ & .. & ],
 *             as well as [ | .. | ]. 
 *             the brackets of these terms derived from IF THEN 
 *             are not recorded in bracket count brkcnt.
 *
 *             at end of cnvfct(), only brackets of type
 *             [ & .. & ] are left, and all other brackets
 *             have been eliminated.
 *             
 *              
 * *******************************************************
 * 
 */
void cnvfct(long *rt) {
/*
 */
  static long r,l,jx,indx;
  static long brkcnt,ifflg,likeflg,thnflg,notflg;
  static long prdidx,scnt,j,i;
  static long n;
  static char type[1+1];
  static char str[20+1];
  static char nam[58+1];
  static long getfrm,err;
  static char msgstr[128+1];
  static char numstr[8+1];
/*
 */
  void chklev();
  void chknam();
  void ckeoln();
  void cmpres();
  void extcmp();
  void fndnam();
  void inperr();
  void negate();
  int readlogfil();
  void rewnds();
  void scrwrt();
  void sgetfrm();
  void smtchbr();
  void wtfil2();
/*
 * initialize local variables and strings
 */
  r = *rt;
  nam_(58+1) = '\0';
  numstr_(8+1) = '\0';
  msgstr_(128+1) = '\0';
  type_(1+1) = '\0';
  str_(20+1) = '\0';
/*
 * -----------------------------------------------------
 *  scan tmpstr left to right, extracting components.
 *  internal format is stored in tmp.
 * -----------------------------------------------------
 */
  strcpy(state ,"Q4400");
  brkcnt=0;
  ifflg=0;
  likeflg=0;
  thnflg=0;
  notflg=0;
/*
 *  default for likelihood is 000
 */
  for (i=1;i<=58;i++) {
    clsnam_(i) = ' ';
  }
  clsnam_(58+1) = '\0';
  strncpy(&clsnam_(54),"000",3);
  jx=0;
  if (r!=0) {
/*
 *  next component to extract is not the first
 */
    goto zz60;
  }
  zz50:;
  l=0;
  r=0;
  zz60:;
  extcmp(tmpstr,&l,&r);
/*
 * -----------------------------------------
 *  should never have an endata before '.'
 * -----------------------------------------
 */
  if (lstrncmp(&tmpstr_(l),"ENDATA",r-l+1)==0) {
    goto zz342;
  }
/*
 * -----------------------------------------
 *  statement continued on next line
 *  skip condition of error state (q4450);
 *  must handle in state q4450
 * -----------------------------------------
 */
  if ((lstrncmp(&tmpstr_(l),"$",r-l+1)==0) &&
      (strcmp(state ,"Q4450")!=0)) {
/*
 *  fact statement is continued on next line
 *
 *  read one record of scrfil into tmpstr
 */
    if (readlogfil()==0) {
      *rt = r;
      return;
    }
/*
 *  begin parsing on new portion of clause.
 */
    goto zz50;
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state definitions
 * ----------------------------------------------------
 *  state 'Q4400' handles IF.
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4400")==0) {
    strcpy(state ,"Q4405");
    if (lstrncmp(&tmpstr_(l),"IF",r-l+1)==0) {
      ifflg=1;
/*
 *  replace if by -[
 *  is not followed by separator $ to allow possible removal
 *  of [ in negate()
 */
      jx=jx+2;
      strncpy(&tmp_(jx-1),"-[",2);
      goto zz60;
    }
/*
 *  else drop through to 4405
 */
  }
/*eject*/
/*
 * ----------------------------------------------------
 *  state 'Q4405' handles [, 'NOT', -, NAME
 * ----------------------------------------------------
 */
  if (strcmp(state ,"Q4405")==0) {
/*
 *  [ bracket
 */
    if (lstrncmp(&tmpstr_(l),"[",r-l+1)==0) {
/*  
 *  brackets cannot occur in IF THEN fact
 */
      if (ifflg>0) {
        inperr(&nftl);
        sprintf(msgstr,
            "  LBCC1630: Brackets [ and ] are not allowed in"
            " IF THEN statement");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
/*
 *  [ is not followed by separator $ to allow for possible
 *  removal of [ in negate()
 */
      if (notflg==0) {
        jx=jx+1;
        tmp_(jx) = '[';
      } else {
        jx = jx+2;
        strncpy(&tmp_(jx-1),"-[",2);
        notflg=0;
      }
      brkcnt=brkcnt+1;
      goto zz60;
    }
/*
 *  NOT
 */
    if ((lstrncmp(&tmpstr_(l),"NOT",r-l+1)==0) ||
        (lstrncmp(&tmpstr_(l),"-",r-l+1)==0)) {
      if (notflg==1) {
        notflg=0;
      } else {
        notflg=1;
      }
      goto zz60;
    } else {
/*
 *  name encountered
 */
      jx=jx+1;
      if (notflg==1) {
        tmp_(jx) = '-';
        notflg=0;
      } else {
        tmp_(jx) = ' ';
      }
/*
 *  check if variable or predicate name.
 */
      n = min(r-l+1,58);
      strncpy(nam,&tmpstr_(l),n);
      nam_(n+1) = '\0';
      fndnam(nam,&indx,type);
      if ((indx>0)&&
          (strcmp(type  ,"P")==0)) {
/*
 *  it is a predicate.
 */
        prdidx=indx;
/*
 *  set pused to indicate the predicate was used
 */
        pused_(prdidx)=1;
        jx=jx+1;
        strncpy(&tmp_(jx),&tmpstr_(l),r-l+1);
        jx=jx+r-l;
        strcpy(state ,"Q4410");
        goto zz60;
      } else if ((indx>0)&&
          (strcmp(type  ,"V")==0)) {
/*
 *  its a variable.
 *  set vused to indicate the variable was used
 */
        vused_(indx)=1;
/*
 *  store in tmp
 */
        jx=jx+1;
        strncpy(&tmp_(jx),&tmpstr_(l),r-l+1);
        jx=jx+r-l+1;
/*
 *  insert separator
 */
        tmp_(jx) = '$';
        strcpy(state ,"Q4440");
        goto zz60;
      } else {
/*
 *  syntax error
 */
        inperr(&nftl);
        strncpy(auxmsg,&tmpstr_(l),r-l+1);
        auxmsg_(r-l+2) = '\0';
        sprintf(msgstr,
            " LBCC1290: Unrecognized predicate"
            " or variable: %s",auxmsg);
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
    }
  }
/*eject*/
/*
 * ------------------------------------
 *  state q4410 is "("
 * ------------------------------------
 */
  if (strcmp(state ,"Q4410")==0) {
    if (lstrncmp(&tmpstr_(l),"(",r-l+1)==0) {
      jx=jx+1;
      tmp_(jx) = '(';
/*
 *  initialize running set count
 */
      scnt=0;
      strcpy(state ,"Q4420");
      goto zz60;
    } else {
      inperr(&nftl);
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr,
          "  LBCC1090: '(' expected; got: %s",auxmsg);
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4450");
      goto zz60;
    }
  }
/*eject*/
/*
 * --------------------------------------------------
 *  state q4420 is quantified variable or element name
 * --------------------------------------------------
 */
  if (strcmp(state ,"Q4420")==0) {
    scnt=scnt+1;
    strcpy(state ,"Q4430");
/*
 *  check whether we are dealing with quantified variable 
 *  or element
 */
    n = min(r-l+1,58);
    strncpy(nam,&tmpstr_(l),n);
    nam_(n+1) = '\0';
    fndnam(nam,&indx,type);
    if ((indx>0)&&
        (strcmp(type  ,"E")==0)) {
/*
 *  it is an element name
 *  see if defined on associated set
 */
      if (setdat_(eltmax+1,prdset_(scnt,prdidx))>0) {
        for(j=1; j<=setdat_(eltmax+1,prdset_(scnt,prdidx)); j++)  {
          if (indx==setdat_(j,prdset_(scnt,prdidx))) {
            jx=jx+1;
            strncpy(&tmp_(jx),&tmpstr_(l),r-l+1);
            jx=jx+r-l;
            goto zz60;
          }
        }
        inperr(&nftl);
        strncpy(auxmsg,&tmpstr_(l),r-l+1);
        auxmsg_(r-l+2) = '\0';
        sprintf(msgstr,
            " LBCC1300: Element %s is not in set %s,"
            " predicate: %s",auxmsg,
            &setnam_(1,prdset_(scnt,prdidx)),
            &prdnam_(1,prdidx));
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
    } else if ((indx>0)&&
        (strcmp(type  ,"Q")==0)) {
/*
 *  check that set definition of quantifier is same as
 *  the set of the predicate for current argument,
 *  or if set definition of quantifier is a subset of
 *  the argument of the predicate
 */
      if (prdset_(scnt,prdidx)!=qsetix_(indx)) {
/*
 *  check if set of quantifier is a subset of
 *  the argument set of the predicate
 */
        for(i=1; i<=setdat_(eltmax+1,qsetix_(indx)); i++)  {
          for(j=1; j<=setdat_(eltmax+1,prdset_(scnt,prdidx)); j++)  {
            if (setdat_(i,qsetix_(indx))==
                setdat_(j,prdset_(scnt,prdidx))) {
/*
 *  set element of quantifier is a member of the
 *  argument set of the predicate
 */
              goto zz160;
            }
          }
/*
 *  set of element of quantifier is not a member, so have error
 */
          goto zz180;
        zz160:;}
/*
 *  set of quantifier is a subset
 */
        goto zz190;
/*
 *  set definitions for quantifier and predicate argument
 *  do not match
 */
        zz180:;
        inperr(&nftl);
        sprintf(msgstr,
            " LBCC1310: Quantifier set and predicate argument"
            " set mismatch: %s",&prdnam_(1,prdidx));
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
/*
 *  predicate is defined on quantified set.
 *  mark that this quantifier was used.
 */
      zz190:;
      qused_(indx)=1;
      jx=jx+1;
      strncpy(&tmp_(jx),&tmpstr_(l),r-l+1);
      jx=jx+r-l;
      goto zz60;
    } else {
/*
 *  element/quantified variable not found,
 *  syntax error
 */
      inperr(&nftl);
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr,
          " LBCC1320: Element or quantifier expected with: %s"
          "  got: %s",&prdnam_(1,prdidx),auxmsg);
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4450");
      goto zz60;
    }
  }
/*eject*/
/*
 * ------------------------------------
 *  state q4430 is ")" or ','
 * ------------------------------------
 */
  if (strcmp(state ,"Q4430")==0) {
    if (lstrncmp(&tmpstr_(l),",",r-l+1)==0) {
      if (scnt==prdset_(3,prdidx)) {
        inperr(&nftl);
        sprintf(msgstr,
            "  LBCC1330: Incorrect number of arguments"
            " with predicate: %s",&prdnam_(1,prdidx));
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
      jx=jx+1;
      tmp_(jx) = ',';
      strcpy(state ,"Q4420");
      goto zz60;
    }
    if (lstrncmp(&tmpstr_(l),")",r-l+1)==0) {
      if (scnt!=prdset_(3,prdidx)) {
        inperr(&nftl);
        sprintf(msgstr,
            "  LBCC1330: Incorrect number of arguments"
            " with predicate: %s",&prdnam_(1,prdidx));
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
      jx=jx+1;
      strncpy(&tmp_(jx),")$",2);
      jx=jx+1;
      strcpy(state ,"Q4440");
    } else {
      inperr(&nftl);
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr,
          " LBCC1130: ')' expected; got: %s",
          auxmsg);
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4450");
      goto zz60;
    }
    goto zz60;
  }
/*eject*/
/*
 * -------------------------------------------------------
 *  state q4440 handles: ], operator, 'THEN', likelihoods, '.'
 * -------------------------------------------------------
 */
  if (strcmp(state ,"Q4440")==0) {
    strcpy(state ,"Q4405");
    if ((lstrncmp(&tmpstr_(l),"AND",r-l+1)==0) ||
        (lstrncmp(&tmpstr_(l),"&",r-l+1)==0)) {
/*
 *  AND may only appear within [ ] and after IF or THEN
 */
      if ((brkcnt==0)&&
          (ifflg==0)) {
        inperr(&nftl);
        sprintf(msgstr,
            " LBCC1340: Incorrect use of AND operator");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
      jx=jx+2;
      strncpy(&tmp_(jx-1),"&$",2);
      strcpy(state ,"Q4405");
      goto zz60;
    } else if ((lstrncmp(&tmpstr_(l),"OR",r-l+1)==0) ||
        (lstrncmp(&tmpstr_(l),"|",r-l+1)==0)) {
/*
 *  OR may not appear within [ ]
 */
      if (brkcnt>0) {
        inperr(&nftl);
        sprintf(msgstr,
            " LBCC1350: OR operator not allowed within [ ]");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
      jx=jx+2;
      strncpy(&tmp_(jx-1),"|$",2);
      strcpy(state ,"Q4405");
      goto zz60;
    } else if (lstrncmp(&tmpstr_(l),"]",r-l+1)==0) {
/*  
 *  brackets cannot occur in IF THEN fact
 */
      if (ifflg>0) {
        inperr(&nftl);
        sprintf(msgstr,
            "  LBCC1630: Brackets [ and ] are not allowed in"
            " IF THEN statement");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
      brkcnt=brkcnt-1;
      if (brkcnt<0) {
        inperr(&nftl);
        sprintf(msgstr,
            " LBCC1360: Too many ']' encountered");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
/*
 *  ] may not be preceded by separator $ to allow possible
 *  removal of ] in negate()
 */
      if (tmp_(jx)!='$') {
        jx=jx+1;
      }
      strncpy(&tmp_(jx),"]$",2);
      jx=jx+1;
      strcpy(state ,"Q4440");
      goto zz60;
    } else if (lstrncmp(&tmpstr_(l),"THEN",r-l+1)==0) {
      if (ifflg==0) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1370: Keyword IF missing");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      } else if (thnflg>0) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1380: THEN already occurred");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      } else {
/*
 *  indicate THEN can appear only once
 */
        thnflg=1;
/*
 *  replace 'THEN' with ']$|$['.
 *  the ] may not be preceded by separator $, and the [
 *  may not be followed by separator $, to allow possible
 *  removal of ] or [ in negate() 
 */
        if (tmp_(jx)!='$') {
          jx=jx+1;
        }
        strncpy(&tmp_(jx),"]$|$[",5);
        jx=jx+4;
        strcpy(state ,"Q4405");
        goto zz60;
      }
    }
/*eject*/
/*
 *  likelihoods
 */
    if (lstrncmp(&tmpstr_(l),"ALWAYS",r-l+1)==0) {
      strncpy(&clsnam_(54),"100",3);
      clsnam_(58) = 'D';
      likeflg = 1;
    } else if (lstrncmp(&tmpstr_(l),"VERY",r-l+1)==0) {
      extcmp(tmpstr,&l,&r);
      if (lstrncmp(&tmpstr_(l),"FREQUENTLY",r-l+1)==0) {
        strncpy(&clsnam_(54),"085",3);
        clsnam_(58) = 'D';
        likeflg = 1;
      } else {
        inperr(&nftl);
        strcpy(msgstr," LBCC1450: Unrecognized likelihood: VERY");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
    } else if (lstrncmp(&tmpstr_(l),"FREQUENTLY",r-l+1)==0) {
      strncpy(&clsnam_(54),"065",3);
      clsnam_(58) = 'D';
      likeflg = 1;
    } else if (lstrncmp(&tmpstr_(l),"HALF",r-l+1)==0) {
      extcmp(tmpstr,&l,&r);
      if (lstrncmp(&tmpstr_(l),"THE",r-l+1)!=0) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1450: Unrecognized likelihood: HALF");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      } else {
        extcmp(tmpstr,&l,&r);
        if (lstrncmp(&tmpstr_(l),"TIME",r-l+1)!=0) {
          inperr(&nftl);
          strcpy(msgstr,
             " LBCC1450: Unrecognized likelihood: HALF THE");
          scrwrt("+W",msgstr);
          strcpy(state ,"Q4450");
          goto zz60;
        } else {
          strncpy(&clsnam_(54),"050",3);
          clsnam_(58) = 'D';
          likeflg = 1; 
        }
      }
    } else if (lstrncmp(&tmpstr_(l),"SOMETIMES",r-l+1)==0) {
      strncpy(&clsnam_(54),"025",3);
      clsnam_(58) = 'D';
      likeflg = 1;
    } else if (lstrncmp(&tmpstr_(l),"RARELY",r-l+1)==0) {
      strncpy(&clsnam_(54),"010",3);
      clsnam_(58) = 'D';
      likeflg = 1;
    } else if (lstrncmp(&tmpstr_(l),"AT",r-l+1)==0) {
      extcmp(tmpstr,&l,&r);
      if (lstrncmp(&tmpstr_(l),"LEVEL",r-l+1)==0) {
        extcmp(tmpstr,&l,&r);
        n = min(r-l+1,8);
        strncpy(numstr,&tmpstr_(l),n);
        numstr_(n+1) = '\0';
        chklev(numstr,&err);
        if (err==1) {
          inperr(&nftl);
          strcpy(msgstr," LBCC1610: Improper level or % term");
          scrwrt("+W",msgstr);
          strcpy(state ,"Q4450");
          goto zz60;
        } else {
          strncpy(&clsnam_(54),"000",3);
          strncpy(&clsnam_(57-(r-l+1)),&tmpstr_(l),r-l+1);
          clsnam_(58) = 'D';
          likeflg = 1;
        }
      } else {
        inperr(&nftl);
        strcpy(msgstr," LBCC1610: Improper level or % term");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }   
    } else if (tmpstr_(r)=='%') {
      n = min(r-l+1,8);
      strncpy(numstr,&tmpstr_(l),n);
      numstr_(n) = '\0';
      chklev(numstr,&err);
      if (err==1) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1610: Improper level or % term");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      } else {
        strncpy(&clsnam_(54),"000",3);
        strncpy(&clsnam_(57-(r-l)),&tmpstr_(l),r-l);
        clsnam_(58) = 'D';
        likeflg = 1;
      }
    }
    if (likeflg==1) {
/*
 *  likelihood has been processed. check if likelihood
 *  terms are followed by '.'
 */
      extcmp(tmpstr,&l,&r);
      if (lstrncmp(&tmpstr_(l),".",r-l+1)!=0) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1620: Likelihood must be followed"
                      " by period terminating fact");
        scrwrt("+W",msgstr);
        strcpy(state ,"Q4450");
        goto zz60;
      }
/*
 *  process '.' next, so no additional state needed
 */
    }
/*eject*/
/*
 */ 
    if (lstrncmp(&tmpstr_(l),".",r-l+1)==0) {
      strcpy(state ,"Q4010");
/*
 *  if quantification, check if all quantifiers were used
 */
      if (nqnt>0) {
        for(i=1; i<=nqnt; i++)  {
          if (qused_(i)==0) {
            inperr(&nftl);
            sprintf(msgstr,
             "  LBCC1390: Quantifier not used: %s",&qntnam_(1,i));
            scrwrt("+W",msgstr);
          }
        }
      }
/*
 *  error if 'IF' but no 'THEN' part
 */
      if ((ifflg>0)&&
          (thnflg==0)) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1400: THEN is missing");
        scrwrt("+W",msgstr);
        goto zz332;
      }
/*
 *  error if brackets do not match up
 */
      if (brkcnt!=0) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1410: Syntax error:"
                      " unmatched brackets");
        scrwrt("+W",msgstr);
        goto zz332;
      }
/*
 *  add closing bracket ] if we have IF THEN statement.
 *  ] may not be preceded by separator $ to allow possible
 *  removal of ] in negate()

 */
      if (thnflg>0) {
        if (tmp_(jx)!='$') { 
          jx=jx+1;
        }
        strncpy(&tmp_(jx),"]$",2);
        jx=jx+1;
      }
/*eject*/
/*
 *  initialize first 8 characters of clause name
 */
      strncpy(&clsnam_(1),"^^^^^^^^",8);
/*
 *  check for delete option.  note: do not want delete option and
 *  clause name in main syntax diagram, as they are optional and
 *  would cause the next fact statement to be read prematurely.
 */
      extcmp(tmpstr,&l,&r);
      if (lstrncmp(&tmpstr_(l),"$",r-l+1)!=0) {
/*
 *  have an additional string following the '.'
 *  this must be either the keyword word 'NAME' followed by
 *  the clause name, or just the clause name.
 *  in both cases, the clause becomes deletable. hence,
 *  store delete option in clsnam
 */
        clsnam_(58) = 'D';
/*
 *  check whether keyword 'NAME' follows the '.'
 */
        if (lstrncmp(&tmpstr_(l),"NAME",r-l+1)==0) {
/*
 *  must have clause name next
 */
          extcmp(tmpstr,&l,&r);
          if (lstrncmp(&tmpstr_(l),"$",r-l+1)==0) {
            inperr(&nftl);
            strcpy(msgstr,
                 " LBCC1420: Clause name required after NAME");
            scrwrt("+W",msgstr);
          }
        }
/*
 * check clause name for legality
 */
        n = min(r-l+1,58);
        strncpy(nam,&tmpstr_(l),n);
        nam_(n+1) = '\0';
        chknam(nam,&err,"C");
        if (err!=0) {
          goto zz332;
        }
/*
 *  check clause name for earlier occurrence
 *  as set, element, predicate, variable, quantification variable
 */
        strncpy(&clsnam_(1),&tmpstr_(l),r-l+1);
        clsnam_(r-l+2) = '\0';
        fndnam(clsnam,&indx,type);
        if (indx>0) {
          inperr(&nftl);
          if (strcmp(type  ,"E")==0) {
            strcpy(str   ,"element");
          } else if (strcmp(type  ,"S")==0) {
            strcpy(str   ,"set");
          } else if (strcmp(type  ,"P")==0) {
            strcpy(str   ,"predicate");
          } else if (strcmp(type  ,"Q")==0) {
            strcpy(str   ,"quantifier");
          } else if (strcmp(type  ,"V")==0) {
            strcpy(str   ,"variable");
          } else {
            error("cnvfct","302");
          }
          strncpy(auxmsg,&tmpstr_(l),r-l+1);
          auxmsg_(r-l+2) = '\0';
          sprintf(msgstr,
              " LBCC1010: %s has already been defined"
              " as a(n) %s",auxmsg,str);
          scrwrt("+W",msgstr);
          strcpy(state ,"Q4450");
          goto zz60;
        }
        ckeoln(tmpstr,&r);        
      }
/*
 *  handle negation and remove unnecessary brackets
 */
      goto zz300;
    } else {
/*
 *  operator expected but not encountered
 */
      inperr(&nftl);
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr,
          "  LBCC1440: Operator expected; got: %s",
          auxmsg);
      scrwrt("+W",msgstr);
      strcpy(state ,"Q4450");
      goto zz60;
    }
  }
/*eject*/
/*
 * -------------------------------------------------------
 *  state q4450:  dummy state to handle errors in fact statments.
 *  read from file without processing statements until hit '.', 
 *  then return
 * -------------------------------------------------------
 */
  if (strcmp(state ,"Q4450")==0) {
/*
 *  search for period
 */
    zz240:;
    for(j=1; j<=(busmax-1); j++)  {
      if (tmpstr_(j)=='.') {
        strcpy(state ,"Q4010");
        *rt = r;
        return;
      }
    }
/*
 *   read one record of logfil into tmpstr
 */
    if (readlogfil()==0) {
      *rt = r;
      return;
    }
/*
 */
    if (lstrncmp(&tmpstr_(1),"ENDATA",6)==0) {
      goto zz342;
    }
/*
 *  test for period
 */
    goto zz240;
  }
/*eject*/
/*
 * ------------------------------------
 *  state not found; error
 * ------------------------------------
 */
  fprintf(errfil,"STATE = %s", state);
  printf("STATE = %s", state);
  error("cnvfct","204");
/*eject*/
/*
 * ------------------------------------
 *  here to handle negation.
 * ------------------------------------
 */
  zz300:;
/*
 *  add terminating separator $
 */
  jx=jx+1;
  tmp_(jx) = '$';
/*
 *  handle negation and remove unnecessary brackets.
 *  negation may occur in front of [  ] terms. 
 *  one such case is produced by IF THEN
 */
  negate(tmp,&jx);
/*
 *  compress tmp by squeezing out all blanks
 */
  cmpres(tmp,&jx);
/*eject*/
/*
 * ------------------------------------
 *  check if statement is legal form
 * ------------------------------------
 *  determine form of statement
 */
  sgetfrm(&getfrm,tmp);
  form=getfrm;
  if (form==-1) {
    inperr(&nftl);
    strcpy(msgstr," LBCC1460: Statement must be a legal form");
    scrwrt("+W",msgstr);
    goto zz332;
  }
/*
 *  if quantification, allow only all OR clause
 */
  if (nqnt>0) {
    if (form!=1) {
      inperr(&nftl);
      strcpy(msgstr,
         " LBCC1470: Illegal statement for quantification");
      scrwrt("+W",msgstr);
      goto zz332;
    }
  }
/*eject*/
/*
 * ------------------------------------
 *  store internal format statement
 * ------------------------------------
 */
  wfile=tmp1;
/*
 *      rewind tmp1
 */
  rewnds(&tmp1);
/*
 *      write jx and tmp(1 to jx)
 */
  wtfil2(&wfile,&jx,"TMP");
/*
 */
  zz332:;
  if (jx>busmax) {
/*
 *  error: array dimension exceeded
 */
    error("cnvfct","332");
  }
  *rt = r;
  return;
/*
 * ------------------------------------
 *  error section
 * ------------------------------------
 */
  zz342:;
  inperr(&fatal);
  strcpy(msgstr," LBCC2040: Unexpected ENDATA encountered");
  scrwrt("+W",msgstr);
  *rt = r;
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine negate
 * 
 *  purpose:  scans tmparg from left to right.
 *            if -[ encountered, negates the statement
 *            inside.
 *            eliminates unnecessary brackets of terms
 *            [   OR   OR  ] or [variable].
 * 
 *  caution:  this routine does not process nested levels
 *            of bracketed expressions.
 * 
 * ******************************************************
 * 
 */
void negate(char *tmparg,long *jxt) {
/*
 */
  static long jx,l,bidx,i;
  static long mtchbr;
/*
 */
  void smtchbr();
/*
 * initialize local variables and strings
 */
  jx = *jxt;
/*
 */
  l=1;
  zz100:;
  if (lstrncmp(&tmparg_(l),"-[",2)==0) {
    tmparg_(l) = ' ';
    l=l+1;
/*
 *  scan for matching ] and negate what is inside
 */
    smtchbr(&mtchbr,tmparg,&l,&jx);
    bidx=mtchbr;
    i=l+1;
    zz200:;
    if (tmparg_(i)==' ') {
      tmparg_(i) = '-';
    } else if (tmparg_(i)=='-') {
      tmparg_(i) = ' ';
      if (tmparg_(i+1)=='[') {
/*
 *  error, have nested brackets
 */
        error("negate","102");
      }
    } else if (tmparg_(i)=='|') {
      tmparg_(i) = '&';
    } else if (tmparg_(i)=='&') {
      tmparg_(i) = '|';
    }
    if (i<bidx-1) {
      i=i+1;
      goto zz200;
    }
/*
 *  advance l pointer depending on whether -[  ] was processed
 */
     l=bidx+1;
  } else {
     l=l+1;
  }
/*
 *  check if done with entire statement
 */
  if (l<jx) {
    goto zz100;
  }
/*
 *  remove unnecessary brackets of [  OR  OR  ] or [variable]
 */
  l=1;
  zz500:;
  if (tmparg_(l)=='[') {
/*
 *  scan for matching bracket
 */
    smtchbr(&mtchbr,tmparg,&l,&jx);
    bidx=mtchbr;
    for (i=l+1;i<=bidx-1;i++) {
      if (tmparg_(i)=='&') {
/*
 *  brackets are required since there is '&' connector
 */
        goto zz515;
      }
    }
/*
 *  brackets are not needed
 *  remove them
 */
    tmparg_(l)=' ';
    tmparg_(bidx)=' ';
    zz515:;
    l=bidx+1;
  } else {
    l=l+1;
  }
/*
 *  check if more checking is needed
 */
  if (l<jx) {
    goto zz500;
  }
/*
 *  done
 */
  *jxt = jx;
  return;
}
/*eject*/
/*
 * ******************************************************
 *  subroutine smtchbr
 * 
 *  purpose:  finds matching ']' of '[' in position l.
 *            returns index of ']' in bidx.
 * 
 * ******************************************************
 * 
 */
void smtchbr(long *mtchbrt,char *tmparg,long *lt,long *jxt)  {
/*
 */
  static long l,jx;
  static long bcnt,ix;
  static long mtchbr;
/*
 * initialize local variables and strings
 */
  mtchbr = *mtchbrt;
  l = *lt;
  jx = *jxt;
/*
 */
  bcnt=0;
  for(ix=l; ix<=jx; ix++)  {
    if (tmparg_(ix)=='[') {
      bcnt=bcnt+1;
    } else if (tmparg_(ix)==']') {
      bcnt=bcnt-1;
    }
    if (bcnt==0) {
      mtchbr=ix;
      *mtchbrt = mtchbr;
      *lt = l;
      *jxt = jx;
      return;
    }
  }
/*
 *  matching right not found; programming error
 *  since we know it is a wff
 */
  error(" smtchbr","  202   ");
  *mtchbrt = mtchbr;
  *lt = l;
  *jxt = jx;
  return;
}
/*eject*/
/*
 * ***************************************************
 *  subroutine sgetfrm
 * 
 *  purpose:  determines statement form.
 *            we know the statement to be
 *            syntactically correct from cnvfct.
 * 
 *  returns:  -1  if statement is not a legal form.
 *             1  if statement is an all or clause.
 *             2  if statement is
 *                [& & &] | [& & &] | | | ...
 * 
 * *****************************************************
 * 
 */
void sgetfrm(long *getfrmt,char *tmparg) {
/*
 */
  static long j,l,r,st,i;
  static long getfrm;
/*
 */
  void extcmp();
/*
 * initialize local variables and strings
 */
  getfrm = *getfrmt;
/*
 */
  getfrm=-1;
/*
 *  check if statement is of form = 1
 */
  for(j=1; j<=busmax; j++)  {
    if (lstrncmp(&tmparg_(j),"$$",2)==0) {
      getfrm=1;
      *getfrmt = getfrm;
      return;
    } else if (tmparg_(j)=='&') {
      goto zz190;
    } else if (tmparg_(j)=='[') {
      goto zz190;
    }
  }
/*
 *  check if statement is of form = 2.
 *  use syntax diagram for this.
 */
  zz190:;
  l=0;
  r=0;
/*
 *  state is initially 1 (we use a local
 *  state transition variable)
 *  final state is state 1.
 */
  st=1;
  zz200:;
  extcmp(tmparg,&l,&r);
  zz210:;
  if (lstrncmp(&tmparg_(l),"$",r-l+1)==0) {
    getfrm=2;
    *getfrmt = getfrm;
    return;
  }
/*
 * ----------------------------------
 *  st = 1 branches on '|' or '['
 * ----------------------------------
 */
  if (st==1) {
    if (tmparg_(l)=='[') {
      st=2;
      goto zz210;
    } else if (lstrncmp(&tmparg_(l),"|",r-l+1)==0) {
      goto zz200;
    } else if  (lstrncmp(&tmparg_(l),"&",r-l+1)==0) {
      *getfrmt = getfrm;
      return;
    } else {
/*
 *  predicate or variable name
 */
      goto zz200;
    }
/*
 * ----------------------------------
 *  st = 2 must see nothing but '&'
 * ----------------------------------
 */
  } else if (st==2) {
    for(i=l+1; i<=r-1; i++)  {
      if (tmparg_(i)=='|') {
        *getfrmt = getfrm;
        return;
      } else if (tmparg_(i)=='[') {
        *getfrmt = getfrm;
        return;
      }
    }
    st=3;
    goto zz200;
/*
 * ----------------------------------
 *  st = 3 must see '|'
 * ----------------------------------
 */
  } else if (st==3) {
    if (lstrncmp(&tmparg_(l),"&",r-l+1)==0) {
      *getfrmt = getfrm;
      return;
    } else if (lstrncmp(&tmparg_(l),"|",r-l+1)==0) {
      st=1;
      goto zz200;
    } else {
/*
 *  predicate or variable
 */
      goto zz200;
    }
  } else {
/*
 *  state not found
 */
    error("sgetfrm","292");
  }
}
/*eject*/
/*
 * ******************************************************
 *  subroutine sonewhr
 * 
 *  purpose:  only one 'WHERE' statement is allowed for a
 *            given pair of quantifiers.
 *            return 1 if this condition is violated,
 *                   0 otherwise.
 * 
 *     note:  this function is called only for the 3
 *            quantifier case, since the 2 quantifier
 *            case allows only one 'WHERE' in total
 *            (this is checked during 'WHERE' processing
 *            in prsfct).
 * 
 * *******************************************************
 * 
 */
void sonewhr(long *onewhrt) {
/*
 */
  static long i,ix,j,onewhr;
/*
 * initialize local variables and strings
 */
  onewhr = *onewhrt;
/*
 */
  onewhr=0;
/*
 *  loop through 'WHERE' statements
 */
  for(i=1; i<=nwhr-1; i++)  {
    for(j=i+1; j<=whrmax; j++)  {
      for(ix=1; ix<=qntmax; ix++)  {
        if (whrstm_(ix,i)!=whrstm_(ix,j)) {
/*
 *  no match, go to next statement
 */
          goto zz110;
        }
      }
/*
 *  statement matches, error
 */
      onewhr=1;
      *onewhrt = onewhr;
      return;
    zz110:;}
  }
  *onewhrt = onewhr;
  return;
}
/*  last record of prsfct.c****** */
