/*  first record of fctcls.c***** */
#include<string.h>
#include<stdio.h>
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/*
 * ***************************************************
 *  module convert fact to clauses
 * 
 *  contains the following routines:
 * 
 *     fctcls   : converts a fact to equivalent clauses.
 *                topmost routine governing repeated
 *                applications of the rewrite algorithm
 *                to all clauses, until equivalent clauses
 *                near cnf form are obtained.
 *                (full conversion to cnf is accomplished
 *                by module clscnf).
 * 
 *  calling sequence:
 *     fctcls   - converts fact to equivalent clauses.
 *       rewrit - converts dnf to cnf.
 * 
 * ****************************************************
 * 
 * 
 * 
 * ****************************************************
 *  subroutine fctcls
 * 
 *  purpose:  converts fact to equivalent clauses.
 * 
 *              1) takes dnf fact and converts it to cnf
 *                 via repeated passes of the rewrite
 *                 algorithm, puts resultant clauses
 *                 into the appropriate temporary file
 *                 for subsequent processing by cnfout or
 *                 applyq.
 * 
 *              2) takes an all 'OR' fact and puts it
 *                 into appropriate temporary file for
 *                 subsequent processing by cnfout or
 *                 applyq.
 * 
 *   output:  the equivalent clause(s) (with ascii names),
 *            one per line, in temporary file wfile.
 * 
 *  caution:  reads clauses into tmp from temporary files.
 * 
 * *****************************************************
 * 
 */
void fctcls() {
/*
 */
  static long done,i;
/*
 */
  void rewnds();
  void rdfil2();
  void rewrit();
/*
 * initialize local variables and strings
 * 
 *  we start with the fact statement in file wfile
 */
  wfile=tmp1;
/*
 *  rewind tmp1 and tmp2
 */
  rewnds(&tmp1);
  rewnds(&tmp2);
/*
 *  nstmt is the number of statements in current
 *  processing file
 */
  nstmt=1;
/*
 *  nstmt2 is the number of statements in the file
 *  containing converted stmts.
 */
  nstmt2=0;
/*
 *  initially, we are done. parsing algorithm
 *  determines otherwise.
 */
  done=1;
/*
 *  make one pass of rewrite algorithm over each
 *  clause in file wfile
 */
  zz510:;
  for(i=1; i<=nstmt; i++)  {
/*
 *  read jx and tmp(1 to jx)
 */
    rdfil2(&wfile,"TMP");
    if (rbuend==1) {
/*
 *  error trying to read record from wfile
 */
      error("  fctcls  ","   402  ");
    }
/*
 */
    rewrit(&done);
  }
/*
 *  toggle wfile so that output file of rewrite is now
 *  input file
 */
  if (wfile==tmp1) {
    wfile=tmp2;
  } else {
    wfile=tmp1;
  }
/*
 *  the number of statments in the output file
 *  become # stmts in input file
 */
  nstmt=nstmt2;
  nstmt2=0;
/*
 *  rewind tmp1 and tmp2
 */
  rewnds(&tmp1);
  rewnds(&tmp2);
/*
 *  check whether or not we are done
 */
  if (done==0) {
    done=1;
    goto zz510;
  }
  return;
}
/*
 * *******************************************************
 *  subroutine rewrit
 * 
 *  purpose:  generates equivalent disjunctive clauses from
 *            given dnf fact.
 *            output is to temporary file.
 *            uses the rewrite algorithm
 *            (introduce new variables).
 * 
 *            if there are only 'OR'd literals,
 *            the fact is placed in the temporary file.
 * 
 *  caution:  tmp contains the entire clause.
 *            grpstr and litstr are also used in the
 *            processing of tmp.
 * 
 * ********************************************************
 * 
 */
void rewrit(long *donet) {
/*
 */
  static long done;
  static char tstr[5+1];
  static long nand;
  static long ftmp,l,r,ll,gl,lx,rx,nx,i;
/*
 */
  void extcmp();
  void gnewv();
  void wtfil2();
  void cmpres();
/*
 * initialize local variables and strings
 */
  done = *donet;
/*
 * --------------------------------------------------
 *  partition logic statement as follows:
 *    1. put literals in litstr; known
 *       to be separated by 'OR'
 *    2. put bracketed groups of 'AND' literals
 *       in grpstr
 * --------------------------------------------------
 */
  if (wfile==tmp1) {
    ftmp=tmp2;
  } else {
    ftmp=tmp1;
  }
  l=0;
  r=0;
  ll=1;
  gl=1;
  nand=0;
  zz520:;
  extcmp(tmp,&l,&r);
  if (lstrncmp(&tmp_(l),"$",r-l+1)==0) {
    litstr_(ll) = '$';
    grpstr_(gl) = '$';
/*
 *  all components have been processed;
 *  proceed with conversion
 */
    goto zz600;
  }
/*
 *  ignore '|'; remove them.
 *  resultant 'clauses' will have literals
 *  separated by '$'.  cnfout or applyq will add '|'.
 */
  if (tmp_(l)=='|') {
    goto zz520;
  }
  if (tmp_(l)!='[') {
/*
 *  component is a literal; store in litstr
 */
    strncpy(&litstr_(ll),&tmp_(l),r-l+1);
    ll=ll+r-l+1;
    litstr_(ll) = '$';
    ll=ll+1;
    goto zz520;
  } else {
/*
 *  store 'AND' group in grpstr
 */
    strncpy(&grpstr_(gl),&tmp_(l),r-l+1);
    gl=gl+r-l+1;
    grpstr_(gl) = '$';
    gl=gl+1;
/*
 *  increment number of 'AND' group components
 */
    nand=nand+1;
    goto zz520;
  }
/*
 * ----------------------------------------------------
 *  now create equivalent disjunctive statements
 *  from grpstr, litstr
 *  add two new clauses:
 *        old variables | new variable | first 'AND' group
 *                                       from grpstr
 *        -new variable | remainder of 'AND' groups
 *                        from grpstr
 *  repeat until for all clauses in wfile there
 *  are no 'AND' groups.
 * ----------------------------------------------------
 */
  zz600:;
  if (nand==0) {
/*
 *  there are no 'AND' components to be
 *  processed for this clause
 */
    goto zz800;
  } else if (nand==1) {
/*
 *  distribute 'AND' over 'OR'
 */
    goto zz700;
  }
/*
 *  otherwise, another pass over clauses
 *  will be required
 */
  done=0;
/*
 * --------------------------
 *  build new clauses
 *  note:  tmp was split into grpstr and litstr,
 *         and is free from this point on; it is reused
 *         now to store constructed clauses.
 * --------------------------
 *  first build: old variables | new variable | first 'AND'
 *                                              group
 *  setup tmp with literals
 */
  strncpy(tmp,litstr,ll);
/*
 *  extract first component from grpstr and
 *  concatentate to tmp
 */
  lx=0;
  rx=0;
  nx=ll;
  extcmp(grpstr,&lx,&rx);
  strncpy(&tmp_(nx),&grpstr_(lx),rx-lx+1);
  nx=nx+rx-lx+1;
  tmp_(nx) = '$';
  nx=nx+1;
/*
 *  add new variable
 */
  gnewv(tstr);
  tmp_(nx) = ' ';
  strncpy(&tmp_(nx+1),tstr,5);
  strncpy(&tmp_(nx+6),"$$",2);
  nx=nx+7;
/*
 *  write clause to ftmp
 *      nx and tmp(1 to nx)
 */
  wtfil2(&ftmp,&nx,"TMP");
/*
 */
  nstmt2=nstmt2+1;
/*
 *  now build:  -new variable | remaining 'AND' groups
 */
  nx=1;
/*
 *  add negation of new variable added above
 */
  tmp_(nx) = '-';
  strncpy(&tmp_(nx+1),tstr,5);
  nx=nx+6;
  tmp_(nx) = '$';
  nx=nx+1;
/*
 *  extract s2 from grpstr and concatenate to tmp
 */
  for(i=2; i<=nand; i++)  {
    extcmp(grpstr,&lx,&rx);
    strncpy(&tmp_(nx),&grpstr_(lx),rx-lx+1);
    nx=nx+rx-lx+1;
    tmp_(nx) = '$';
    nx=nx+1;
  }
  tmp_(nx) = '$';
  nx=nx+1;
/*
 *  write clause to ftmp
 *      nx and tmp(1 to nx)
 */
  wtfil2(&ftmp,&nx,"TMP");
/*
 */
  nstmt2=nstmt2+1;
  *donet = done;
  return;
/*
 * ---------------------------------------------
 *  here, there is one group of 'AND's to process
 *  for each literal in the 'AND' group, make a
 *  new clause with the 'OR' literals.
 * ---------------------------------------------
 */
  zz700:;
  l=0;
  r=0;
/*
 *  remove [ ] from around 'AND' group.
 */
  grpstr_(1) = ' ';
  grpstr_(gl-2) = ' ';
  cmpres(grpstr,&gl);
/*
 *  extract next 'AND' literal from single component
 *  in grpstr
 *  create a new clause for each 'AND' literal
 */
  zz720:;
/*
 *  setup tmp with literals
 */
  strncpy(tmp,litstr,ll);
  nx=ll;
  extcmp(grpstr,&l,&r);
  if (lstrncmp(&grpstr_(l),"$",r-l+1)==0) {
    *donet = done;
    return;
  }
  if (lstrncmp(&grpstr_(l),"&",r-l+1)==0) {
    goto zz720;
  }
/*
 *  concatenate literal to tmp
 */
  strncpy(&tmp_(nx),&grpstr_(l),r-l+1);
  nx=nx+r-l+1;
  strncpy(&tmp_(nx),"$$",2);
  nx=nx+1;
/*
 *      write nx and tmp(1 to nx)
 */
  wtfil2(&ftmp,&nx,"TMP");
/*
 */
  nstmt2=nstmt2+1;
  goto zz720;
  zz800:;
/*
 *      write ll and litstr(1 to ll)
 */
  wtfil2(&ftmp,&ll,"LIT");
/*
 */
  nstmt2=nstmt2+1;
  *donet = done;
  return;
}
/*  last record of fctcls.c****** */
