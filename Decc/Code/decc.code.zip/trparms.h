/*  first record of trparms.h***** */
/*
 * *******************************************************
 *  defines parameters for translat module
 * *******************************************************
 */
#define setmax 2
/*
 *                   max number of sets
 */
#define prdmax 2
/*
 *                   max number of predicates
 */
#define eltmax 2  /* max number of elements for set,      */
                    /* function, predicate                  */
/*
 */
#define qntmax 3    /* max number of quantified variables   */
/*
 */
#define whrmax 3    /* max number of where statements       */
/*
 */
#define mwemax 40   /* max number of warnings/errors after  */
                    /* which writing of such messages to    */
                    /* screen is stopped                    */
/*
 */
#define bufmax 2    /* number of bulk arrays                */
                    /* ( = number of devices replaced by    */
                    /*  bulk arrays)                        */
/*
 */
#define vnamln 58  /* propositional variable length */
/*
 */
#define enamln 58  /* element name length           */
/*
 */
#define rnamln 58  /* user defined row name length  */
/*
 */
#define ridtln 58  /* row identifier length         */
/*
 */
#define numlen  8  /* length of an ascii number     */
                   /*  (true/false cost)            */
/*  last record of trparms.h****** */
