/*
 *  replacement code installed Aug 2, 2007. forces use
 *  of all 'parallel' copies when a source row is selected
 *  below, 'accept' means: add to source or sink rows
 *
 *  Rules:
 *    nodlim     rownam       action
 *  --------------------------------------------------------
 *     > 0    not 'parallel'  accept, decrement nodlim
 *                            (this adds first row of set
 *                            of identical rows)
 *    >= 0    'parallel'      accept, nodlim not changed
 *                            (this adds 'parallel' rows)
 *       0    not 'parallel'  do not accept, set nodlim = -1
 *                            (this terminates additions)
 *                            if flgsrc == 0, return
 *                            (this terminates routine)
 *      -1     anything       do not accept
 *  --------------------------------------------------------
 */
          if (riblk_(i)==q) { /* if riblk_(i)== q */
            if (nodlim == -1) {
              continue;
            }

            /* decide pflg value */
            if ((mincutflg == ONLYCOLS) && 
                (strncmp(&rownam_(1,invidxrow_(i)),
                 "parallel.",9)==0)) {
              pflg = 1; /* 'parallel' case */
            } else {
              pflg = 0; /* regular case */
            }

            if ((nodlim == 0) && (pflg == 0)) {
              if (flgsrc == 1) {
                nodlim = -1;
                continue;
              } else {
                return;
              }
            }

            /* accept row i as source or sink node */
            if ((nodlim > 0) && (pflg == 0)) {
              nodlim--;
            }
            if (flgsrc == 1) {
              rsourc_(rowmax+1)=rsourc_(rowmax+1)+1;
              rsourc_(rsourc_(rowmax+1))=i;
            } else {
              rsink_(rowmax+1)=rsink_(rowmax+1)+1;
              rsink_(rsink_(rowmax+1))=i;
            }

          } /* end if riblk_(i)== q */
