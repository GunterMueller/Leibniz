/*  first record of exdefs.h***** */
/* ******************************************************
 *  defines global variables for execution module
 * ****************************************************** 
 *  CAUTION: if any change is made in this file, then
 *           the corresponding change must be made in
 *           file exexts.h
 */
/*
 *  files
 */
FILE *chkfil;     /* check file            */
FILE *prmfil;     /* parameter file        */
FILE *errfil;     /* error messages file   */
FILE *logfil[logfilmax];
                  /* log input files       */
FILE *trsprobfil; /* trs prob file         */
FILE *trsdefsfil; /* trs defs file         */
FILE *trsextsfil; /* trs exts file         */
FILE *trscodefil; /* trs code file         */
FILE *lrnthmfil;  /* lrn theorems file     */
FILE *lrnrowfil;  /* lrn rows file         */
FILE *prgfil;     /* prg program file      */
FILE *condiptfil; /*condensed input file */
/*
 *  file names, extensions, directories, line counts 
 */
char deccparamsname[256];  /* deccparams file name         */
char trsprobfil_name[256]; /* trs prob file name           */
char trsprobfil_nopa[256]; /* trs prob file name, no path  */
char trsdefsfil_name[256]; /* trs defs file name           */
char trsdefsfil_nopa[256]; /* trs defs file name, no path  */
char trsextsfil_name[256]; /* trs exts file name           */
char trsextsfil_nopa[256]; /* trs exts file name, no path  */
char trscodefil_name[256]; /* trs code file name           */
char trscodefil_nopa[256]; /* trs code file name, no path  */
char prgfil_name[256];     /* prg file name                */
char condiptfil_name[256]; /* condensed input file name    */
char logfil_name[256*(logfilmax+1)];     
                           /* log file name                */
char errfil_name[256];     /* err file name                */
char lrnthmfil_name[256];  /* lrn theorems file name       */
char lrnrowfil_name[256];  /* lrn rows file name           */
char filnam[256];          /* file name                    */
char auxnam[256];          /* auxiliary file               */
char namext[(namemax+1)*5];/* name extension               */ 
char prbdir[256];          /* problem directory            */
char parstr[256];          /* parameter string             */
long logcline[logfilmax];  /* list of current line numbers */
                           /* of log input files           */
long nlogfil;              /* number of log input files    */
/*
 *  typedefs needed for some macros
 */
typedef struct {
  char  name[58+1];
  short status;
} CLAUSE_ARRAY;
typedef char PRGNAME_ARRAY[256+1];
/*
 *  flags for memory allocation
 *  = 0 not allocated
 *  = 1 allocated
 */
long lpxalcflg = 0; /* flag for lpx alloc                  */
long exalcflg  = 0; /* flag for generation/execution alloc */
long tralcflg  = 0; /* flag for translation alloc          */
/*
 *  flags connected with transfer code generation
 */
long nonusewarnflg = 1; /* = 1 warn about variable defined    */
                        /*     but not used in clauses        */
                        /* = 0 do not warn about unused       */
                        /*     variables                      */
long trsprocessflg = 0; /* = 1 define/use transfer process    */
                        /* = 0 do not define/use transfer     */
                        /*     process                        */
long keepallvarflg = 0; /* = 1 keep all variables of log      */
                        /*     formulation, whether or not    */
                        /*     they are used in facts         */
                        /* = 0 do not keep all variables,     */
                        /*     but only ones used in facts    */
long mktrsprocfilflg = 0; /* = 1 make files for transfer      */
                        /*     process                        */
                        /* = 0 do not make files for transfer */
                        /*     process                        */
long mincutflg;         /* = ONLYCOLS   only cols in cut      */
                        /* = PREFERCOLS prefer cols in cut    */
                        /* = PREFERROWS prefer rows in cut    */
long outputprgflg = 0;  /* = 1 output compiled program to     */
                        /*     .prg file                      */  
                        /* = 0 do not output compiled program */
long condiptflg = 0;    /* =-1 no action                      */
                        /* = 0 output of condensed input is   */
                        /*     requested, but begin keyword   */
                        /*     has not yet been reached       */
                        /* = 1 output condensed input         */
                        /* = 2 output of condensed input is   */
                        /*     is stopped since end keyword   */
                        /*     has been reached or passed     */
char begcondiptword[128+1];/* begin keyword of condensed input*/
char endcondiptword[128+1];/* end keyword of condensed input  */

long decompositionflg;  /* = LINEAR linear decomposition      */
                        /* = TREE   tree decomposition        */
long blockminsize;      /* minimum size of any block          */
/*eject*/
/*
 */
long colmax;
long rowmax;
long anzmax;
long blkmax;
long cutmax;
long prbmax;
long stomax;
long laymax;
/*
 *  define variables for control
 */
long apmbnd;
char lbzver[7+1];
long apmflg;
long selvr[4];
long automt;
long satchk;
long bstver;
long lrnflg;
long lrnoutflg;
long ilrncyc;
long nlrncyc;
long ilrnzero;
long nlrnzero;
long lrnsucc;
/*
 */
long nselvr;
long iselvr;
/*
 *  define variables for io and control
 * 
 */
long scrflg = 1;
long accflg;
long selpgv;
/*
 */
long flgprb;
long flgopt;
long flgtrm;
long flgatf;
long flggol;
/*
 */
long c1 = 1;
long c2 = 2;
long c3 = 3;
long c4 = 4;
long c5 = 5;
long c6 = 6;
long c7 = 7;
long c8 = 8;
long c9 = 9;
/*
 *  define variables for put/get routines
 */
long pgnum;
long npgrec;
char *pgrec;
char *pgalp;
/*
 *  lpexec communication arrays
 */
long *xpoint;
double *xvalue;
char *xcomnd;
/*eject*/
/*
 *  define column and row names
 *  caution: indices j,i for colnam_(j), rownam_(i)
 *           refer to input. can be linked to index
 *           j1, i1 of problem being processed
 *           using j1 = idxcol_(j), i1 = idxrow_(i)
 *           the inverse relationships are given by
 *           j = invidxcol_(j1) and i = invidxrow_(i1)
 */
char *colnam;
char *rownam;
char *clnam;
char *rwnam;
/*
 *  define external index arrays.
 *  idxclx_(j) refers to the jth non-asterisk name
 *  in colnam.
 *  caution:  must always translate to the 'name'
 *            level (colnam) and then translate from
 *            colnam to jscan (internal level).
 * 
 */
long *idxclx;
long ncolsx;
/*
 *  define additional control variables
 *  (suffix r indicates retained information)
 *  flags
 */
long asgflg;
long solflg = -2;
long satble;
long xerror = 0;
long zeroerr = 0;
long warn = 1;
long nftl = 2;
long fatl = 3;
long errval;
long execerr[3];
long execerrmax[3];
long optimr;
unsigned long randseed;
/*
 *  retained costs
 *  (remaining retained arrays are part of cl_(,)
 *  and rw_(,) arrays)
 */
long *trucsr;
long *falcsr;
/*
 *  variables for approximate minimization
 *  for definitions, see routine apmsol
 * 
 */
double *rndzv;
double *deltaz;
long *xcl2lp;
long *xlp2cl;
long *xrw2lp;
long *xlp2rw;
long *lpstat;
long *rndcl;
long *rndcas;
long *rndfsb;
/*
 */
long *nlurr;
long *ciacpr;
/*
 */
double *lrrval;
double *urrval;
/*eject*/
/*
 *  variables for internal problem storage
 *  for definitions, see module get and put problems
 * 
 */
long irec;
long currec;
long antrec;
long fstrec;
long lstrec;
long nfrrec;
long usdrec;
long nrecs;
/*
 */
long *nxtrec;
long *prbbeg;
long *prbend;
long *prbsiz;
long lprb;
long nprbs;
long stoflg;
char *storec;
char *prbnam;
/*
 *  max indices actually used,
 *  and the succss variable
 *  to indicate success of operation (1) or failure (0).
 * 
 */
long nblks;
long *nbks;
long *nders;
long *ndrge;
long *nerge;
long *ndrgep;
long *nergep;
long *npairs;
long nrg;
long nrgx;
long nnzrg;
long nnzrgx;
/*
 */
long *lcllim;
long *ucllim;
long *lrwlim;
long *urwlim;
long lcllmt;
long ucllmt;
long lrwlmt;
long urwlmt;
/*
 */
long nanzs;
long *nnzs;
long ncols;
long *ncls;
long nrows;
long *nrws;
long succss;
long *twosat;
long *twost;
long flgrge;
long devdif;
long totmem;
long *fxcase;
long aggidx;
long aggdif;
long evalsubflg;
/*
 */
long ngols;
long jxgoal;
/*eject*/
/*
 *  variables for optimization information
 * 
 */
long ttcost;
long prcost;
long lbcost;
long q1cost;
long cost1;
/*
 *  input costs
 * caution: index je for trucst_(je), falcst_(je)
 *          trcst_(je,k),flcst_(je,k),
 *          refers to input, and thus agrees with
 *          name in colnam_(je), clnam_(je,k)
 *          related index j of problem
 *          being processed is j = idxcol_(je)
 * 
 */
long *trucst;  /* is trcst of layer 1 */
long *falcst;  /* is flcst of layer 1 */
long *trcst;   
long *flcst;
long optimz;
/*
 *  variables for permutation information
 * 
 */
long pmvalue;
long bstval;
long *prmdat;
long *prmlim;
long *nprms;
long psize;
/*eject*/
/*
 *  variables for component decomposition
 * 
 */
long *csourc;
long *rsourc;
long *csink;
long *rsink;
long *cnew;
long *rnew;
long *ccut;
long *rcut;
/*
 */
long jscan;
long jcol;
long juser;
long jval;
long iscan;
long jnam;
long inam;
long istar;
/*
 */
long qblock;
long maxcut;
long bstcut;
long bstcolcut;
long bstrowcut;
long onpath;
long srcsiz;
long nodlim;
long flgsrc;
long *cdis;
long *rdis;
long cfar;
long distce;
long *histdc;
/*
 *  variables for range information
 * 
 */
long *drange;
long *ptdr;
long *nzdr;
long *pter;
long *nzer;
long dr;
long dr1;
long er;
long er1;
long *rg;
long *ptrg;
long *nzrg;
long *rgx;
long *ptrgx;
long *nzrgx;
long zrgx;
/*
 */
long *lcost;
long *rgxlst;
long *rgxusd;
long *auxv1;
long *auxv2;
long *auxv3;
long *aux;
long *va;
long *vb;
long *vc;
long *ldr;
long *ler;
long *ldr1;
long *ler1;
long rgxcur;
/*eject*/
/*
 *  variables for retained solution
 */
long *retsol;
/*
 *  variables for bounds on effort for
 *  satisfiability tests
 * 
 */
double realk;
double realtl;
double realts;
double realtp;
double realto;
long bdfxvr;
long *bdfxbl;
long *logrge;
long *ablkct;
long inselt;
long mspeed;
long *attblk;
/*
 *  variables for column information
 * 
 */
long *cl;
long *centry;
long *clalli;
long *clacti;
long *clinai;

/*  Decomposition
 *  column cut node list
 *  for jx = 1, 2, ..., colcut_(cutmax+1,qblock):
 *  colcut_(jx,qblock) = jnam: col jnam is in cut of block qblock
 *  caution: jnam is external index 
 */
long *colcut;

/*
 *  column index lists
 * 
 */
long *cxlfix;
long *cxlbnd;
long *cxlsol;
long *cxlinp;
long *cxlbegthm;
long *cxlthm;
long *cxlpath;
/*
 *   variables for row information
 * 
 */
long *rw;
long *rentry;
long *rwallj;
long *rwactj;
long *rwfixj;
long *rwfrej;
long *rwinaj;

/*  Decomposition
 *  row cut node list
 *  for ix = 1, 2, ..., rowcut_(cutmax+1,qblock):
 *  rowcut_(ix,qblock) = inam: row inam is in cut of block qblock
 *  caution: inam is external index
 */
long *rowcut;

/*
 *  row index lists for permutation
 *  module
 * 
 */
long *rnred;
long *rxlact;
long *rxleqz;
long *rxleq1;
long *rxlcu1;
long *rxleq2;
long *rposj;
long *rxlrhs;
long *ronej;
long *aonej;
long *rxlntz;
long *rxlinp;
/*eject*/
/*
 *  variables for matrix information
 * 
 */
long *amc;
long *ptamc;
long *nzamc;
long *amr;
long *ptamr;
long *nzamr;
/*
 *  ablk arrays (A - block)
 */
long *ablkcl;
long *ptablc;
long *nzablc;
long *ablkrw;
long *ptablr;
long *nzablr;
/*
 *  amsl arrays (A - matrix solution)
 */
long *amslcl;
long *ptamsc;
long *nzamsc;
long *amslrw;
long *ptamsr;
long *nzamsr;
long *rnared;
/*
 *  bmsl arrays (B - matrix solution)
 */
long *bmslcl;
long *ptbmsc;
long *nzbmsc;
long *bmslrw;
long *ptbmsr;
long *nzbmsr;
long *rnbred;
long *ribred;
long *rxlbw1;
long *rxlbwz;
/*eject*/
/*
 *  enumeration arrays
 *  for interpretation, see enufix
 */
long *bdvalu;
long *bdcase;
long *bdcons;
long *bdsave;
long *bdtemp;
/*
 *  variable for transfer process
 */
long *trsvar;
/*
 *  learning arrays
 *  for intepretation, see lrnrows
 */
long thmlen;
long thmlenmax;
long nthms;
long *thmmat;   /* allocation in lrnrows */
long *ptthmmat; /* allocation in lrnrows */
long *pathcase;
/*
 */
long nconcl;
long nconfx;
long nsavec;
long nsavex;
long nunitres;
/*
 */
long *selcol;
long *covtot;
long *covmat;
long *selcas;
long nsatrow;
long *nstrow;
/*
 */
long nslcol;
long nslcas;
long curcas;
long lowbnd;
/*eject*/
/*
 *  equivalence for range data
 * 
 */
long *erange;
/*
 */
long *gpod;
/*
 */
long *gpoe;
/*
 */
long *gpodp;
/*
 */
long *gpoep;
/*
 *  set up equivalences for column counts, indicator
 *  vectors, and index lists
 * 
 *  equivalences for counts in cl_(1,1,1) - cl_(1,9,1)
 *  below are active only during program generation,
 *  and are invalidated by subroutine retain
 *  at end of program generation
 */
long *cnallp;
long *cnalln;
long *cnall;
long *cnactp;
long *cnactn;
long *cnact;
long *cninap;
long *cninan;
long *cnina;
/*
 *  equivalences for cl_(1,1,1) - cl_(1,8,1)
 *  below are initialized by subroutine retain
 *  at end of program generation, and are active
 *  during execution. can extend this up to
 *  and including cl_(1,9,1)
 * 
 */
long *ciactr;
long *ciinar;
long *cifrer;
long *cifixr;
long *ciacgl;
long *idxgol;
long *idxgnm;
long *gcoeff;
long *primal;
/*
 *  permanent equivalences
 * 
 */
long *ciact;
long *ciina;
long *cifre;
long *cifix;
long *solut1;
long *solut2;
long *solut3;
long *solut4;
long *solut5;
long *scale;
long *idxcol;
long *ciblk;
long *dlclop;
long *cost;
long *cvatf;
long ncvatf1;
long *inlsol;
long *invidxcol;
/*eject*/
/*
 *  set up equivalences for row counts,
 *  indicator vectors, and index lists
 * 
 *  equivalences for counts in rw_(1,1,1) - rw_(1,15,1)
 *  below are active only during program generation,
 *  and are invalidated by subroutine retain
 *  at end of program generation
 */
long *rnallp;
long *rnalln;
long *rnall;
long *rnactp;
long *rnactn;
long *rnact;
long *rninap;
long *rninan;
long *rnina;
long *rnfrep;
long *rnfren;
long *rnfre;
long *rnfixp;
long *rnfixn;
long *rnfix;
/*
 *  equivalences for rw_(1,1,1) - rw_(1,11,1)
 *  below are initialized by subroutine retain
 *  at end of program generation, and are active
 *  during execution. can extend this up to
 *  and including rw_(1,15,1)
 * 
 */
long *riactr;
long *riinar;
long *levelr;
long *dual;
long *goalxq;
long *glocst;
long *ghicst;
long *goalus;
long *goalrq;
long *glflg;
/*
 *  permanent equivalences
 * 
 */
long *riact;
long *riina;
long *rhs1;
long *rhs2;
long *rhs3;
long *rhs4;
long *rhs5;
long *idxrow;
long *riblk;
long *dlrwop;
long *level;
long *invidxrow;
/*
 *  set up equivalences for the layer 1 problem matrix
 * 
 */
long *amatcl;
long *ptamac;
long *nzamac;
long *amatrw;
long *ptamar;
long *nzamar;
/*
 *  equivalence relations for max flow module.
 *  relates solut1-solut5 and rhs1-rhs5 to
 *  clpath, claugm, clstat, clcutn, cllabn, and
 *  rwpath, rwaugm, rwstat, rwcutn, rwlabn.
 * 
 */
long *clpath;
long *claugm;
long *clstat;
long *clcutn;
long *cllabn;
long *rwpath;
long *rwaugm;
long *rwstat;
long *rwcutn;
long *rwlabn;
/*
 *  equivalence relations for permutation module.
 *  relates solut1 - solut5 to
 *  height, curprm, fnlprm, tmpprm, bstprm
 * 
 */
long *height;
long *curprm;
long *fnlprm;
long *tmpprm;
long *bstprm;
/*  last record of exdefs.h****** */

/* temporary variables */
long ncount;
