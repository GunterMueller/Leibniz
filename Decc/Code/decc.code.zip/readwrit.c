/*  first record of readwrit.c***** */
#include<string.h>
#include<stdio.h>
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/*
 * ****************************************************
 *  readwrit.f contains all subroutines handling
 *  open, read, write, rewind of bulk arrays.
 *  uses file numbers for reference 12 and 13
 *  variables for bulk storage:
 *            nburec() = record counters
 *            xbuzzz() = indices of array usage
 *            buzzz(,) = bulk storage arrays
 *            crdflg() = current read flag
 *            cwtflg() = current write flag
 *            prdflg() = previous read flag
 *            pwtflg() = previous write flag
 *            rbuend   = end-of-file flag
 * *****************************************************
 * 
 * 
 * *****************************************************
 *  subroutine opens
 * 
 *  purpose: initializes bulk files
 * *****************************************************
 * 
 */
void opens(long *filet) {
/*
 */
  static long dx,file;
/*
 * initialize local variables and strings
 */
  file = *filet;
/*
 *  open bulk arrays
 */
  dx=file-11;
  crdflg_(dx)=0;
  cwtflg_(dx)=0;
  tburec_(dx)=0;
  xbuint_(dx)=0;
  xbuchr_(dx)=0;
  *filet = file;
  return;
}
/*
 * *****************************************************
 *  subroutine rewnds
 * 
 *  purpose: rewinds bulk file
 * *****************************************************
 * 
 */
void rewnds(long *filet) {
/*
 */
  static long dx,file;
/*
 * initialize local variables and strings
 */
  file = *filet;
/*
 */
  dx=file-11;
/*
 *  rewind bulk arrays
 */
  crdflg_(dx)=0;
  cwtflg_(dx)=0;
  xbuint_(dx)=0;
  xbuchr_(dx)=0;
  *filet = file;
  return;
}
/*
 * *****************************************************
 *  subroutine rdfil2
 * 
 *  purpose:  reads from file = 12 or 13
 *            into tmp or litstr
 * *****************************************************
 * 
 */
void rdfil2(long *filet,char *ft) {
/*
 */
  static long dx,file,jx;
/*
 * initialize local variables and strings
 */
  file = *filet;
/*
 */
  if ((strcmp(ft    ,"TMP")!=0)&&
      (strcmp(ft    ,"LIT")!=0)) {
/*
 *  error, ft must be equal to 'TMP' or 'LIT'
 */
    error(" rdfil2 "," 51     ");
  }
  rbuend=0;
  dx=file-11;
  if (cwtflg_(dx)==1) {
/*
 *  error, have been writing, so reading not allowed
 *  at this time
 */
    error(" rdfil2 "," 52     ");
  }
  if (crdflg_(dx)==0) {
/*
 *  reading of first record group
 */
    if (tburec_(dx)<=0) {
/*
 *  error, reading requested, but file has no records
 */
      error(" rdfil2 "," 53     ");
    }
    crdflg_(dx)=1;
    nburec_(dx)=tburec_(dx);
  }
  if (nburec_(dx)==0) {
/*
 *  end of file has been reached
 *  set end-of-file flag and return
 */
    rbuend=1;
    *filet = file;
    return;
  }
  nburec_(dx)=nburec_(dx)-1;
/*
 *  first read statement
 */
  xbuint_(dx)=xbuint_(dx)+1;
  jx=buint_(xbuint_(dx),dx);
/*
 *  second read statement
 */
  if (strcmp(ft    ,"TMP")==0) {
    strncpy(tmp,&buchr_(xbuchr_(dx)+1,dx),jx);
  } else {
    strncpy(litstr,&buchr_(xbuchr_(dx)+1,dx),jx);
  }
  xbuchr_(dx)=xbuchr_(dx)+jx;
  *filet = file;
  return;
}
/*
 * *****************************************************
 *  subroutine rdfil3
 * 
 *  purpose:  reads from file = 12 or 13 into
 *            clsxl1 or clsxl2, and into clsnam
 * *****************************************************
 * 
 */
void rdfil3(long *filet,long *ltt) {
/*
 */
  static long dx,file,i,lt,m,n;
/*
 * initialize local variables and strings
 */
  file = *filet;
  lt = *ltt;
/*
 */
  if ((lt!=1)&&
      (lt!=2)) {
/*
 *  error, lt must be equal to 1 or 2
 */
    error(" rdfil3 "," 51     ");
  }
  rbuend=0;
  dx=file-11;
  if (cwtflg_(dx)==1) {
/*
 *  error, have been writing, so reading not allowed
 *  at this time
 */
    error(" rdfil3 "," 52     ");
  }
  if (crdflg_(dx)==0) {
/*
 *  reading of first record group
 */
    if (tburec_(dx)<=0) {
/*
 *  error, reading requested, but file has no records
 */
      error(" rdfil3 "," 53     ");
    }
    crdflg_(dx)=1;
    nburec_(dx)=tburec_(dx);
  }
  if (nburec_(dx)==0) {
/*
 *  end of file has been reached
 *  set end-of-file flag and return
 */
    rbuend=1;
    *filet = file;
    *ltt = lt;
    return;
  }
  nburec_(dx)=nburec_(dx)-1;
/*
 *  first read statement
 */
  xbuint_(dx)=xbuint_(dx)+1;
  n=buint_(xbuint_(dx),dx);
  if (lt==1) {
    clsxl1_(cvmax+1)=n;
  } else {
    clsxl2_(cvmax+1)=n;
  }
/*
 *  second read statement
 */
  for(i=1; i<=n; i++)  {
    xbuint_(dx)=xbuint_(dx)+1;
    m=buint_(xbuint_(dx),dx);
    if (lt==1) {
      clsxl1_(i)=m;
    } else {
      clsxl2_(i)=m;
    }
  }
/*
 *  third read statement
 */
  strcpy(clsnam,&buchr_(xbuchr_(dx)+1,dx));
  xbuchr_(dx) += strlen(clsnam)+1;
  *filet = file;
  *ltt = lt;
  return;
}
/*
 * *****************************************************
 *  subroutine wtfil2
 * 
 *  purpose:  writes into file =12 or 13
 *            from tmp or litstr
 * *****************************************************
 * 
 */
void wtfil2(long *filet,long *jxt,char *ft) {
/*
 */
  static long dx,file,jx;
/*
 * initialize local variables and strings
 */
  file = *filet;
  jx = *jxt;
/*
 */
  if ((strcmp(ft    ,"TMP")!=0)&&
      (strcmp(ft    ,"LIT")!=0)) {
/*
 *  error, ft must be equal to 'TMP' or 'LIT'
 */
    error(" wtfil2 "," 51     ");
  }
  dx=file-11;
  if (crdflg_(dx)==1) {
/*
 *  error, have been reading, so writing not allowed
 *  at this time
 */
    error(" wtfil2 "," 52     ");
  }
  if (cwtflg_(dx)==0) {
/*
 *  writing of first record group
 */
    cwtflg_(dx)=1;
    tburec_(dx)=0;
  }
  tburec_(dx)=tburec_(dx)+1;
/*
 *  first write statement
 */
  xbuint_(dx)=xbuint_(dx)+1;
  if (xbuint_(dx)>busmax) {
/*
 *  file full, not enough space
 */
    error(" wtfil2 ","  103   ");
  }
  buint_(xbuint_(dx),dx)=jx;
/*
 *  second write statement
 */
  if ((xbuchr_(dx)+jx)>bchmax) {
/*
 *  file full, not enough space
 */
    error(" wtfil2 ","  104   ");
  }
  if (strcmp(ft    ,"TMP")==0) {
    strncpy(&buchr_(xbuchr_(dx)+1,dx),tmp,jx);
  } else {
    strncpy(&buchr_(xbuchr_(dx)+1,dx),litstr,jx);
  }
  xbuchr_(dx)=xbuchr_(dx)+jx;
/*
 *  end of write statements
 */
  *filet = file;
  *jxt = jx;
  return;
}
/*
 * *****************************************************
 *  subroutine wtfil3
 * 
 *  purpose:  writes into file = 12 or 13 from
 *            clsxl1 or clsxl2, and from clsnam
 * *****************************************************
 * 
 */
void wtfil3(long *filet,long *ltt) {
/*
 */
  static long dx,file,i,lt,m,n;
/*
 * initialize local variables and strings
 */
  file = *filet;
  lt = *ltt;
/*
 */
  if ((lt!=1)&&
      (lt!=2)) {
/*
 *  error, lt must be equal to 1 or 2
 */
    error(" wtfil3 "," 51     ");
  }
  dx=file-11;
  if (crdflg_(dx)==1) {
/*
 *  error, have been reading, so writing not allowed
 *  at this time
 */
    error(" wtfil3 "," 52     ");
  }
  if (cwtflg_(dx)==0) {
/*
 *  writing of first record group
 */
    cwtflg_(dx)=1;
    tburec_(dx)=0;
  }
  tburec_(dx)=tburec_(dx)+1;
/*
 *  first write statement
 */
  xbuint_(dx)=xbuint_(dx)+1;
  if (xbuint_(dx)>busmax) {
/*
 *  file full, not enough space
 */
    error(" wtfil3 ","  102   ");
  }
  if (lt==1) {
    n=clsxl1_(cvmax+1);
  } else {
    n=clsxl2_(cvmax+1);
  }
  buint_(xbuint_(dx),dx)=n;
/*
 *  second write statement
 */
  for(i=1; i<=n; i++)  {
    xbuint_(dx)=xbuint_(dx)+1;
    if (xbuint_(dx)>busmax) {
/*
 *  file full, not enough space
 */
      error(" wtfil3 ","  103   ");
    }
    if (lt==1) {
      m=clsxl1_(i);
    } else {
      m=clsxl2_(i);
    }
    buint_(xbuint_(dx),dx)=m;
  }
/*
 *  third write statement
 */
  if ((xbuchr_(dx)+ridtln)>bchmax) {
/*
 *  file full, not enough space
 */
    error(" wtfil3 ","  201  ");
  }
  strcpy(&buchr_(xbuchr_(dx)+1,dx),clsnam);
  xbuchr_(dx) += strlen(clsnam)+1;
  *filet = file;
  *ltt = lt;
  return;
}
/*  last record of readwrit.c****** */
