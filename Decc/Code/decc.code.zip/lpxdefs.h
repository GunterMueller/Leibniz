/*  first record of lpxdefs.h***** */
long maxeq;
long maxstr;
long maxnz;
long maxvar;
long maxcol;
long lenr8;
long leni4;
long iafac;
/*
 *  error variables for dynamic allocation
 */
long xerror;
long fatl;
/*
 *     explanation of the parameter statements:
 * 
 *     maxeq   = maximum number of constraints;
 *     maxstr  = maximum number of structural variables;
 *     maxvar  = maximum number of variables, including
 *               slacks;
 *     maxnz   = maximum number of non-zeros in the matrix,
 *               including slack columns but not including
 *               right-hand-side or objective function;
 *     maxcol  = maximum number of non-zeros in any single
 *               column; (we use maxcol = maxeq since that
 *               suffices)
 *     lenr8   = length of double precision working storage
 *               array;
 *     leni4   = length of integer working storage array.
 *     iafac   = storage factor computed by xmp for ia
 *               (conditions: 3 <= iafac <= 10)
 * 
 * 
 *     see the xmp dictionary for the definitions of the
 *     xmp arrays that are declared below. all other xmp
 *     variables are defined in lpci.f.
 * 
 */
double *memr;
/*
 */
long *memi;
/*
 */
double *b;
double *bascb;
double *baslb;
/*
 */
double *basub;
double *betar;
double *blow;
/*
 */
double *cola;
/*
 */
double *uzero;
double *xbzero;
double *yq;
/*
 */
long *basis;
long *coli;
/*
 */
long *rowtyp;
long *status;
/*
 * error files within lp domain
 * fioerr = internal file name in lpexec()
 * fiolog = internal file name in lpexec()
 * for details about fioerr, fiolog, see routine lpexec()
 */
FILE *fioerr;
FILE *fiolog;
/*
 * error file defined outside lp domain
 * errfil =  must be defined and opened in the
 *           routine calling lpexec()
 */
extern FILE *errfil;
/*  last record of lpxdefs.h****** */
