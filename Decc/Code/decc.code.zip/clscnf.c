/*  first record of clscnf.c***** */
#include<string.h>
#include<stdio.h>
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"

int abs();
/*
 * -------------------------------------------------------
 *  module clscnf
 * 
 *  purpose:  generates cnf clauses in a standardized form,
 *            outputs the clauses in
 *              trprbnam 
 *              trncols,trnrows, trnanzs
 *              trcolnam, trcolusx, trcvatf, trtrucst, trfalcst
 *              trrownam, trptamar, trnzamar, tramatrw
 * 
 *  this module contains:
 * 
 *    cnfout  : outputs cnf without quantification.
 *    applyq  : applies quantification and outputs cnf.
 *    cnewqp  : calculate new quantification permutation.
 *    argtyp  : returns type of a given predicate argument.
 *    maknam  : constructs a full literal name.
 *    makidt  : constructs clause identifier.
 *    makcls  : checks for duplicate clauses,
 *              constructs cnf
 *              clause from clause index list.
 *    sckdupv : checks if given variable is a duplicate or
 *              complement in the clause.
 *    saddlit : adds given literal to the clause.
 *    sgetlix : gets the index of the variable in the
 *              list cnfvar.
 *    schkcnd : determines if a given literal violates a
 *              'WHERE' condition.
 *
 * 
 * --------------------------------------------------------
 * 
 * 
 * ********************************************************
 *  subroutine cnfout
 * 
 *  purpose:  constructs final cnf clauses from
 *            clause index lists.
 * 
 *  caution:  clauses are first stored in tmp, and finally
 *            stored in tramatrw.
 *            tramatrw indices are based on full list of
 *            variables. For use in generator, must convert
 *            indices to reduced list via trcolusx_(j).
 *            that conversion is done in getcnf().
 * 
 * ********************************************************
 * 
 */
void cnfout(long *clsnumt) {
/*
 */
  static long clsnum;
  static char litnam[58+1];
  static char nam[58+1];
  static char arg1[58+1],arg2[58+1];
  static long arg1ix,arg2ix,minus,j,indx;
  static long empty,i,l,r,x;
  static char targ1[1+1],targ2[1+1],type[1+1];
  static long addlit;
  static char msgstr[128+1];
/*
 */
  void argtyp();
  void extcmp();
  void extnam();
  void fndnam();
  void inperr();
  void makcls();
  void makidt();
  void maknam();
  void rdfil2();
  void saddlit();
  void scrwrt();
  void wtfil3();
/*
 * initialize local variables and strings
 */
  clsnum = *clsnumt;
  litnam_(58+1)  = '\0';
  nam_(58+1)     = '\0';
  arg1_(58+1)     = '\0';
  arg2_(58+1)     = '\0';
  targ1_(1+1)    = '\0';
  targ2_(1+1)    = '\0';
  type_(1+1)     = '\0';
  msgstr_(128+1) = '\0';
/*
 * -------------------------------------------------------
 *  read one statement at a time from file wfile
 *  (up to nstmt).
 *  check for duplicate variables, variable and
 *  its negation, and store clause in tramatrw
 * -------------------------------------------------------
 *  initialize empty to true (1); there are no clauses.  if write
 *  a clause, set to false (0).  if all done and empty = 1, then
 *  warn user that all clauses were deleted.
 */
  empty=1;
  if (nstmt<=0) {
/*
 *  nstmt cannot be less than or equal to zero.
 */
    error(" cnfout ","   22   ");
  }
/*
 *  clause index lists will be written to unused tmp file
 */
  if (wfile==tmp1) {
    ixfile=tmp2;
  } else {
    ixfile=tmp1;
  }
  for(i=1; i<=nstmt; i++)  {
/*
 *        read jx and tmp(1 to jx)
 */
    rdfil2(&wfile,"TMP");
    if (rbuend==1) {
/*
 *  error trying to read record
 */
      error(" cnfout ","  904   ");
    }
/*
 */
    clsxl1_(cvmax+1)=0;
    l=0;
    r=0;
/*
 *  scan tmp component by component.
 */
    zz120:;
    extcmp(tmp,&l,&r);
    if (lstrncmp(&tmp_(l),"$",r-l+1)==0) {
/*
 * ----------------------------------------------
 *  have extracted all components
 *  write out the clause index list
 * --------------------------------------
 *  store clause identifier in clsnam
 */
      makidt(&clsnum,&i);
/*
 *  write the number of indices
 *      in current clause: clsxl1_(cvmax+1)
 *  write the indices of the clause:
 *     (clsxl1_(j), j=1, clsxl1_(cvmax+1))
 *  write the clause identifier: clsnam
 */
      j=1;
      wtfil3(&ixfile,&j);
/*
 */
      empty=0;
      goto zz100;
    }
/*
 * ------------------------------------------
 *  extract name and arguments (if exist)
 * ------------------------------------------
 */
    extnam(tmp,&l,&r,nam,arg1,arg2,&minus);
    fndnam(nam,&indx,type);
    if ((indx>0)&&
        (strcmp(type  ,"P")==0)) {
/*
 *  get type and index of arg1
 *  arg1 is name of arg.  targ1 is type of arg. arg1ix is index of arg.
 */
      argtyp(arg1,targ1,&arg1ix);
/*
 *  get type and index of arg2
 */
      argtyp(arg2,targ2,&arg2ix);
/*
 * --------------------------------------------------------
 *  handle single argument case.
 * --------------------------------------------------------
 */
      if (strcmp(targ2 ,"?")==0) {
        if (strcmp(targ1 ,"E")==0) {
          maknam(nam,arg1,arg2,litnam,&minus);
          goto zz420;
        }
/*
 * --------------------------------------------------------
 *  handle double argument case.
 * --------------------------------------------------------
 */
      } else if ((strcmp(targ1 ,"E")==0)&&
          (strcmp(targ2 ,"E")==0)) {
        maknam(nam,arg1,arg2,litnam,&minus);
        goto zz420;
      } else {
/*
 *  must be one of above cases
 */
        error(" cnfout ","  202   ");
      }
/*
 * --------------------------------------------------------
 *  handle variable name
 * --------------------------------------------------------
 */
    } else if ((indx>0)&&
        ((strcmp(type  ,"V")==0)||
        (strcmp(type  ,"N")==0))) {
      maknam(nam,"        ","        ",litnam,&minus);
      goto zz420;
    } else {
/*
 *  error: predicate or variable not found
 */
      error("cnfout","102");
    }
/*
 * ----------------------------------------------
 *  add literal to clause if not already there.
 * ----------------------------------------------
 */
    zz420:;
    saddlit(&addlit,litnam);
    x=addlit;
    if (x==2) {
/*
 *  throw out entire clause
 */
      goto zz100;
    } else {
      goto zz120;
    }
  zz100:;}
/*
 *  all clauses have been processed.
 */
  if (empty==1) {
    inperr(&warn);
    strcpy(msgstr,
        " LBCC0070: Fact statement is always satisfiable");
    scrwrt("+W",msgstr);
    clsnum--;
  } else {
    makcls();
  }
  *clsnumt = clsnum;
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine applyq
 * 
 *  purpose:  applies quantification to a clause and
 *            constructs final cnf
 * 
 *  definition:  empty: given an original clause,
 *               there is no resulting clause after
 *               quantification
 *               (the original clause is always satisfiable)
 * 
 * output:       empty = 0: at least one clause was
 *                          produced
 *                     = 1: no clause was produced,
 *                          either because 'WHERE'
 *                          conditions do not permit any
 *                          instance, or because all
 *                          clauses are trivially
 *                          satisfiable.
 * 
 *  caution:     clauses are stored in tmp.
 * 
 * ********************************************************
 * 
 */
void applyq(long *clsnumt) {
/*
 */
  static long clsnum;
  static char litnam[58+1];
  static char nam[58+1];
  static char arg1[58+1],arg2[58+1];
  static long arg1ix,arg2ix,minus,sc;
  static long done,indx,empty,l,r,i;
  static char targ1[1+1],targ2[1+1],type[1+1];
  static char msgstr[128+1];
  static long addlit;
/*
 */
  void argtyp();
  void cnewqp();
  void extcmp();
  void extnam();
  void fndnam();
  void inperr();
  void makcls();
  void makidt();
  void maknam();
  void rdfil2();
  void saddlit();
  void scrwrt();
  void wtfil3();
/*
 * initialize local variables and strings
 */
  clsnum = *clsnumt;
  litnam_(58+1)  = '\0';
  nam_(58+1)     = '\0';
  arg1_(58+1)     = '\0';
  arg2_(58+1)     = '\0';
  targ1_(1+1)    = '\0';
  targ2_(1+1)    = '\0';
  type_(1+1)     = '\0';
  msgstr_(128+1) = '\0';
/*
 *  initialize empty to true (1); there are no clauses.  if write
 *  a clause, set to false (0).  if all done and empty = 1, then
 *  warn user that all clauses were deleted.
 */
  empty=1;
/*
 *  nstmt must be equal to 1 (a single 'OR' clause)
 */
  if (nstmt!=1) {
    error(" applyq ","   22   ");
  }
/*
 *  clause index lists will be written to unused tmp file
 */
  if (wfile==tmp1) {
    ixfile=tmp2;
  } else {
    ixfile=tmp1;
  }
/*
 *  read the clause
 *      read jx and tmp_(1 to jx)
 */
  rdfil2(&wfile,"TMP");
  if (rbuend==1) {
    error(" applyq ","  904   ");
  }
/*
 *  initialize subclause counter
 */
  sc=0;
/*
 *  initialize clause length to 0
 */
  clsxl1_(cvmax+1)=0;
/*
 *  initialize done flag
 *  done = -1: permutation must be initialized
 *  done =  0: have valid permutation satisfying
 *             all 'WHERE' conditions
 *  done =  1: have processed all permutations
 *             satisfying 'WHERE' conditions
 */
  done=-1;
/*
 *  initialize permutation
 */
  cnewqp(&done);
/*
 *  done has been set by cnewqp
 *        to 0 ( => have valid permutation)
 *     or to 1 ( => there is no valid permutation
 *                  due to 'WHERE' conditions)
 * 
 */
  if (done==1) {
/*
 * there is no valid permutation
 */
    if (qnttyp==exis) {
      inperr(&nftl);
      strcpy(msgstr,
          " LBCC1560: THERE EXISTS and WHERE conditions are contradictory");
      scrwrt("+W",msgstr);
    } else {
      inperr(&nftl);
      strcpy(msgstr,
          " LBCC1550: FOR ALL and WHERE conditions are contradictory");
      scrwrt("+W",msgstr);
    }
    *clsnumt = clsnum;
    return;
  }
/*
 *  processing loop starts here
 *  reset for new clause
 */
  zz105:;
  clsxl1_(cvmax+1)=0;
  zz110:;
  l=0;
  r=0;
/*
 *  scan tmp component by component.
 */
  zz120:;
  extcmp(tmp,&l,&r);
  if (lstrncmp(&tmp_(l),"$",r-l+1)==0) {
/*
 * --------------------------------------------------------
 *  have extracted all components of current permutation.
 *  if universal case, write clause index list, get next
 *  permutation.
 *  if existential case, simply get next permutation.
 * --------------------------------------------------------
 */
    if (qnttyp==exis) {
      cnewqp(&done);
      if (done==1) {
        if (clsxl1_(cvmax+1)==0) {
/*
 *  system error: we had at least one valid permutation, but no
 *  clause entries resulted. but then must have had -x | x case
 *  case, which is handled by statement 620
 */
          error(" applyq ","  122   ");
        } else {
/*
 *  write out the clause index list
 */
          goto zz300;
        }
      } else {
/*
 *  continue with next permutation
 */
        goto zz110;
      }
    }
    if (qnttyp==univ) {
      if (clsxl1_(cvmax+1)==0) {
/*
 *  system error: clause can be empty only if there is -x | x case,
 *  which is handled by statement 620
 */
        error(" applyq ","  132   ");
      } else {
/*
 *  write out the clause index list; set up for next subclause
 */
        goto zz300;
      }
    }
/*
 *  programming error: quantification not known
 */
    error(" applyq ","  302   ");
/*
 * --------------------------------------
 *  write out the clause index list
 * --------------------------------------
 */
    zz300:;
/*
 *  store clause identifier in clsnam
 */
    sc=sc+1;
    makidt(&clsnum,&sc);
/*
 *  write the number of indices
 *      in current clause: clsxl1_(cvmax+1)
 *  write the indices of the clause:
 *      (clsxl1_(i), i=1, clsxl1_(cvmax+1))
 *  write the clause identifier: clsnam
 */
    i=1;
    wtfil3(&ixfile,&i);
/*
 */
    empty=0;
/*
 * --------------------------------------------------------------
 *  determine next action based on type of quantification
 * --------------------------------------------------------------
 */
    if (qnttyp==exis) {
/*
 *  now have the single clause created 
 *  by existential quantification in ixfile.  
 *  all permutations have been done.  
 *  check for duplicate rows, make cnf clause
 */
      makcls();
      *clsnumt = clsnum;
      return;
    } else {
/*
 *  get next permutation for 'FOR ALL' case
 */
      cnewqp(&done);
      if (done==1) {
        if (empty==1) {
/*
 *  formulation error; all clauses are trivially satisfiable
 */
          inperr(&nftl);
          strcpy(msgstr,
              " LBCC0070: Fact statement is always satisfiable");
          scrwrt("+W",msgstr);
          *clsnumt = clsnum;
          return;
        }
/*
 *  now have all clauses (by indices) in ixfile. 
 *  check for duplicate rows and make cnf clauses
 */
        makcls();
        *clsnumt = clsnum;
        return;
      } else {
/*
 *  new clause
 */
        goto zz105;
      }
    }
  }
/*
 * ------------------------------------------
 *  extract name and arguments (if exist)
 * ------------------------------------------
 */
  extnam(tmp,&l,&r,nam,arg1,arg2,&minus);
  fndnam(nam,&indx,type);
  if ((indx>0)&&
      (strcmp(type  ,"P")==0)) {
/*
 *  it is a predicate
 *  check if arg1 is quantified variable or element name
 *  arg1 is name of arg.  targ1 is type of arg. arg1ix is index of arg.
 */
    argtyp(arg1,targ1,&arg1ix);
/*
 *  check if arg2 is quantified variable or element name
 */
    argtyp(arg2,targ2,&arg2ix);
/*
 * -----------------------------------------------------------------
 *  execute quantification.
 *  universal case:
 *    one clause for each argument combination.  forms many clauses.
 *  existential case:
 *    one clause for all argument combinations.
 *  there are 5 cases:
 *  1) there is only one argument
 *  2) both arguments are element names
 *  3) 1st argument is element name, 2nd argument is quantifed var
 *  4) 1st argument is quantifed var, 2nd argument is element name
 *  5) 1st argument is quantified var, 2nd argument is quantified var
 * -----------------------------------------------------------------
 * -----------------------------------------------------------------
 *  single argument case; element or quantifier
 * -----------------------------------------------------------------
 */
    if (strcmp(targ2 ,"?")==0) {
      if (strcmp(targ1 ,"E")==0) {
        maknam(nam,arg1,arg2,litnam,&minus);
      } else if (strcmp(targ1 ,"Q")==0) {
        strcpy(arg1,&eltnam_(1,setdat_(qperm_(arg1ix),qsetix_(arg1ix))));
        maknam(nam,arg1,arg2,litnam,&minus);
        goto zz620;
      } else {
        error(" applyq ","  602   ");
      }
      goto zz620;
/*
 * -----------------------------------------------------------------
 *  double argument case; both elements
 * -----------------------------------------------------------------
 */
    } else if ((strcmp(targ1 ,"E")==0)&&
        (strcmp(targ2 ,"E")==0)) {
      maknam(nam,arg1,arg2,litnam,&minus);
      goto zz620;
/*
 * -----------------------------------------------------------------
 *  double argument case; arg1=element arg2=quantifier
 * -----------------------------------------------------------------
 */
    } else if ((strcmp(targ1 ,"E")==0)&&
        (strcmp(targ2 ,"Q")==0)) {
      strcpy(arg2,&eltnam_(1,setdat_(qperm_(arg2ix),qsetix_(arg2ix))));
      maknam(nam,arg1,arg2,litnam,&minus);
      goto zz620;
/*
 * -----------------------------------------------------------------
 *  double argument case; arg1=quantifier arg2=element
 * -----------------------------------------------------------------
 */
    } else if ((strcmp(targ1 ,"Q")==0)&&
        (strcmp(targ2 ,"E")==0)) {
      strcpy(arg1,&eltnam_(1,setdat_(qperm_(arg1ix),qsetix_(arg1ix))));
      maknam(nam,arg1,arg2,litnam,&minus);
      goto zz620;
/*
 * -----------------------------------------------------------------
 *  double argument case; both quantifiers
 * -----------------------------------------------------------------
 */
    } else if ((strcmp(targ1 ,"Q")==0)&&
        (strcmp(targ2 ,"Q")==0)) {
      strcpy(arg1,&eltnam_(1,setdat_(qperm_(arg1ix),qsetix_(arg1ix))));
      strcpy(arg2,&eltnam_(1,setdat_(qperm_(arg2ix),qsetix_(arg2ix))));
      maknam(nam,arg1,arg2,litnam,&minus);
      goto zz620;
    } else {
/*
 *  must be one of above cases
 */
      error(" applyq ","  336   ");
    }
/*
 * ------------------------------------------------------------------
 *  handle variable name
 * ------------------------------------------------------------------
 */
  } else if ((indx>0)&&
      ((strcmp(type  ,"V")==0)||
      (strcmp(type  ,"N")==0))) {
    maknam(nam,"        ","        ",litnam,&minus);
    goto zz620;
  } else {
/*
 *  error: predicate or variable not found
 */
    error(" applyq ","  622   ");
  }
/*
 * ------------------------------------------------------------------
 *  add literal to clause.  handle trivially satisifiable case here.
 * ------------------------------------------------------------------
 */
  zz620:;
  saddlit(&addlit,litnam);
  if (addlit==2) {
/*
 *  have x | -x case, so current clause deleted. for
 *  'THERE EXISTS', entire fact is trivially satisfiable
 */
    if (qnttyp==exis) {
      goto zz650;
    }
/*
 *  must have 'FOR ALL' case; current clause is skipped
 *  calculate new quantification permutation.
 */
    cnewqp(&done);
    if (done==1) {
/*
 *  we are done for the 'FOR ALL' case
 */
      goto zz650;
    } else {
/*
 *  construct next clause
 */
      goto zz105;
    }
  } else {
/*
 *  extract next predicate/variable and process
 */
    goto zz120;
  }
/*
 *  label 650 is executed when the last subclause
 *  of the 'FOR ALL' case is trivially satisfied,
 *  and it is executed when the single clause of
 *  the 'THERE EXISTS' case is trivially satisfied.
 */
  zz650:;
  if (empty==1) {
    inperr(&warn);
    strcpy(msgstr," LBCC0070: Fact statement is always satisfiable");
    scrwrt("+W",msgstr);
  } else {
    makcls();
  }
  *clsnumt = clsnum;
  return;
}
/*eject*/
/*
 * **************************************************************
 *  subroutine cnewqp
 * 
 *  purpose:  calculate new quantification permutation.
 *            qperm contains current permutation of the quantified
 *            variables (initially 1 1 1). skip permutations
 *            that do not satisfy 'WHERE' conditions.
 * 
 *  input:    done = -1: find first valid permutation
 *                 =  0: find next valid permutation
 * 
 *  output:   done =  0: valid permutation found
 *                    1: there is no first or additional permutation
 * 
 * ****************************************************************
 * 
 */
void cnewqp(long *donet) {
/*
 */
  static long done;
  static long j,valid;
/*
 */
  void chkcnd();
/*
 * initialize local variables and strings
 */
  done = *donet;
/*
 *  done = -1: must find first valid permutation
 *          0: must find next valid permutation
 */
  if ((done!=-1)&&
      (done!=0)) {
    error(" cnewqp ","  132   ");
  }
/*
 */
  if (done==-1) {
/*
 *  find first valid permutation
 */
    done=0;
    for(j=1; j<=qntmax; j++)  {
      qperm_(j)=1;
    }
/*
 *  check validity
 */
    chkcnd(&valid);
    if (valid==1) {
/*
 *  have valid permutation
 */
      *donet = done;
      return;
    }
/*
 *  first permutation is not valid
 *  search for next valid one
 */
  }
/*
 * know done = 0
 */
  zz50:;
/*
 *  calculate new permutation for universally quantified variables.
 *  (works like a gas pump display).
 * 
 */
  j=nqnt;
  if (qperm_(j)==setdat_(eltmax+1,qsetix_(j))) {
    zz100:;
    qperm_(j)=1;
    if (j-1>=1) {
      j=j-1;
      if (qperm_(j)==setdat_(eltmax+1,qsetix_(j))) {
        goto zz100;
      } else {
        qperm_(j)=qperm_(j)+1;
      }
    } else {
      done=1;
      *donet = done;
      return;
    }
  } else {
    qperm_(j)=qperm_(j)+1;
  }
  chkcnd(&valid);
  if (valid==0) {
/*
 *  permutation does not satisfy all 'WHERE' conditions
 */
    goto zz50;
  }
/*
 * permutation is valid, so return
 */
  *donet = done;
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine argtyp
 * 
 *  purpose:  given arg (name of argument), return type of 
 *            argument in targ: 
 *            'E' means element, 'Q' means quantified variable;
 *            return index of name in eltnam or qntnam in argix.
 * 
 * ********************************************************
 * 
 */
void argtyp(char *arg,char *targ,long *argixt)  {
/*
 */
  static long argix;
  static long indx,j;
  static char type[1+1];
  static char nam[58+1];
/*
 */
  void fndnam();
/*
 * initialize local variables and strings
 */
  argix = *argixt;
  type_(1+1) = '\0';
  nam_(58+1) = '\0';
/*
 */
  if (arg_(1)=='?') {
    strcpy(targ  ,"?");
    strcpy(arg   ,"        ");
    argix=0;
    *argixt = argix;
    return;
  }
  strcpy(nam   ,arg);
  fndnam(nam,&indx,type);
  if ((indx>0)&&
      (strcmp(type  ,"Q")==0)) {
/*
 *  it is a quantified variable; look it up
 */
    if (nqnt<=0) {
      error(" argtyp ","  102   ");
    }
    for(j=1; j<=nqnt; j++)  {
      if (strcmp(arg,&qntnam_(1,j))==0) {
/*
 *  store type and index
 */
        strcpy(targ  ,"Q");
        argix=j;
        goto zz200;
      }
    }
/*
 *  error: quantified variable not found
 */
    error(" argtyp ","  104   ");
  } else if ((indx>0)&&
      (strcmp(type  ,"E")==0)) {
/*
 *  it is an element name; look it up
 */
    if (nelts<=0) {
      error(" argtyp ","  106   ");
    }
    for(j=1; j<=nelts; j++)  {
      if (strcmp(arg,&eltnam_(1,j))==0) {
/*
 *  store type and index
 */
        strcpy(targ  ,"E");
        argix=j;
        goto zz200;
      }
    }
/*
 *  error: element not found
 */
    error(" argtyp ","  108   ");
  } else {
/*
 *  must be element or quantified variable, but was not
 */
    error(" argtyp ","  112   ");
  }
  zz200:;
  *argixt = argix;
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine maknam
 * 
 *  purpose:  build character string (litnam)
 *            from nam1,2,3.
 *            error if length of litnam > 52.
 * 
 * ********************************************************
 * 
 */
void maknam(char *nam1,char *nam2,char *nam3,
            char *litnam,long *minust) {
/*
 */
  void inperr();
  void scrwrt();
/*
 *  length of nam is 3 times vnamln plus two parentheses,
 *  one comma, and end-of-string character
 */
  static long minus,ix;
  static char nam[3*vnamln+3+1];
  static char msgstr[128+1];
/*
 * initialize local variables and strings
 */
  minus = *minust;
/*
 *  store minus sign if it exists
 */
  if (minus==1) {
    strcpy(nam,"-");
  } else {
    strcpy(nam,"");
  }
/*
 *  store predicate or variable name
 */
  ix = strlen(nam) + 1;
  strcpy(&nam_(ix),nam1);
/*
 */
  if (strcmp(nam2  ,"        ")!=0) {
/*
 *  insert left parenthesis (for predicate case)
 */
    ix = strlen(nam) + 1;
    strcpy(&nam_(ix),"(");
    ix = strlen(nam) + 1;
    strcpy(&nam_(ix),nam2);
/*
 */ 
    if (strcmp(nam3  ,"        ")!=0) {
/*
 *  insert comma to separate arguments (for predicate case)
 *  and second argument name
 */
      ix = strlen(nam) + 1;
      strcpy(&nam_(ix),",");
      ix = strlen(nam) + 1;
      strcpy(&nam_(ix),nam3);
    }
/*
 *  insert right parenthesis (for predicate case)
 */
    ix = strlen(nam) + 1;
    strcpy(&nam_(ix),")");
  }
  if (strlen(nam) > 52) {
    inperr(&nftl);
    strcpy(msgstr," LBCC1190: %s is an illegal identifier:"
                  " too long");
    scrwrt("+W",msgstr);
/*
 *  reduce size so processing can continue
 *  may cause subsequent faulty error messages, but this
 *  cannot be helped
 */
    nam_(53) = '\0';
  }
  strcpy(litnam,nam);
  *minust = minus;
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine makidt
 * 
 *  purpose:  store clause identifier in clsnam.
 * 
 * ********************************************************
 * 
 */
void makidt(long *clsnumt,long *sct) {
/*
 */
  static long clsnum,sc;
  static char tnam[8+1];
/*
 */
  void itostr();
/*
 * initialize local variables and strings
 */
  clsnum = *clsnumt;
  sc = *sct;
  tnam_(8+1) = '\0';
/*
 * ----------------------------------
 *  add clause name
 * ----------------------------------
 */

/******* begin of code removed 12/30/04 *******
  if (lstrncmp(clsnam,"^^^^^^^^",8)==0) {
    itostr(&clsnum,tnam);
    tnam_(1) = '@';
    strncpy(&clsnam_(1),&tnam_(1),8);
  }
  itostr(&sc,tnam);
  strncpy(&clsnam_(9),&tnam_(5),4);
  clsnam_(12+1) = '\0';
 ******* end of code removed 12/30/04 *******/

/******* begin code added 12/30/04 *******/
/* this code creates clause name if needed and
 *  does not add subclause number
 */
  if (lstrncmp(clsnam,"^^^^^^^^",8)==0) {
/*
 *  build original clause number in position 1 to 8
 */
    itostr(&clsnum,tnam);
    tnam_(1) = '@';
    strncpy(&clsnam_(1),&tnam_(1),8);
    clsnam_(8+1) = '\0';  
  }
/******* end code added 12/30/04 *******/

  *clsnumt = clsnum;
  *sct = sc;
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine makcls
 * 
 *  purpose:  checks for duplicate rows amoung the rows in 
 *            input file.
 *            uses two files, an input file and an output file.
 *            initially the input file is ixfile (itmp).
 *            the first clause of the input file is unique; 
 *            store final cnf in trxxxxxx arrays.  
 *            check remaining rows in input file against
 *            this first clause.  
 *            ignore duplicates, write out non-duplicates 
 *            to output file (otmp).  swap input and output
 *            files when all clauses in input file have been 
 *            checked.
 *            repeat process until there are no clauses in 
 *            input file.
 * 
 *  caution:  clause is built in tmp.
 *            there must be a clause in itmp.
 * 
 * **********************************************************
 * 
 */
void makcls() {
/*
 */
  static char litnam[58+1];
  static long i,ix,done;
  static long jx,m;
  static long x,ixx;
  static long itmp,otmp,adflg;
/*
 */
  void rewnds();
  void rdfil3();
  void wtfil3();
/*
 * initialize local variables and strings
 */
  litnam_(58+1) = '\0';
/*
 */
  itmp=ixfile;
  otmp=wfile;
/*
 * ------------------------------------------------
 *  first record of input temporary file is by definition
 *  unique.  remaining rows will be checked
 *  against it, and left out if they are duplicate.
 * ------------------------------------------------
 */
  zz100:;
  done=1;
/*
 *      rewind itmp
 */
  rewnds(&itmp);
/*
 *      rewind otmp
 */
  rewnds(&otmp);
/*
 *  read first record from input temporary file
 *      clsxl1_(cvmax+1)
 *      (clsxl1_(i), i=1, clsxl1_(cvmax+1))
 *      clsnam
 */
  i=1;
  rdfil3(&itmp,&i);
  if (rbuend==1) {
/*
 *  error reading ixfile
 */
    error(" makcls ","  1010  ");
  }
/*
 *  make the final cnf clause and store it in tramatrw
 *
 *  increase row counter
 */
  trnrows++;
  /* check added March 8, 2008 */
  if (trnrows > crmax) {
    printf("\nToo many rows, increase rowmax = %ld\n",crmax); 
    fprintf(errfil,"Too many rows, increase rowmax = %ld\n",crmax);
    lbccexit(1);
  }
/*
 *  define pointer trptamar
 */
  if (trnrows > 1) {
    trptamar_(trnrows) = trptamar_(trnrows-1) +
                         trnzamar_(trnrows-1);
  } else {
    trptamar_(trnrows) = 0;
  }
/*
 *  store count trnzamar and update total count trnanzs
 */
  trnzamar_(trnrows) = clsxl1_(cvmax+1);
  trnanzs += clsxl1_(cvmax+1);
/*
 */
  for(jx=1; jx<=clsxl1_(cvmax+1); jx++)  {
/*
 *  store signed index in tramatrw
 */
    /* check added March 8, 2008 */
    if ((jx+trptamar_(trnrows)) > camax) {
      printf(
      "\nToo many matrix elements, increase anzmax = %ld\n",camax); 
      fprintf(errfil,
      "\nToo many matrix elements, increase anzmax = %ld\n",camax);
      lbccexit(1);
    }
    tramatrw_(jx+trptamar_(trnrows)) = clsxl1_(jx);
/*
 *  flag variable as used
 */
    m = abs(clsxl1_(jx));
    strcpy(&cnfvarflg_(m),"P");
  }
/*
 *  store clause name with level and delete option
 */
  strcpy(&trrownam_(1,trnrows),clsnam);
  strcpy(&trrownam_(54,trnrows),&clsnam_(54));  
/*
 * ------------------------------------------------------
 *  check remaining rows against the first one (known to
 *  be unique). if rows match, ignore them, else write
 *  them to second temporary file
 * ------------------------------------------------------
 *
 *  assume all remaining rows in itmp are duplicates
 * (all duplicate flag)
 */
  adflg=1;
  zz210:;
/*
 *  read next record from input temporary file and
 *  compare with candidate
 *     clsxl2_(cvmax+1)
 *     (clsxl2_(i), i=1, clsxl2_(cvmax+1))
 *     clsnam
 */
  i=2;
  rdfil3(&itmp,&i);
  if (rbuend==1) {
    goto zz1000;
  }
/*
 */
  done=0;
/*
 *  compare the two rows
 *  if clauses are the same, take no action.
 *  if different, put into output temporary file
 */
  if (clsxl1_(cvmax+1)!=clsxl2_(cvmax+1)) {
/*
 *  different number of entries, cannot be same row;
 *  put into output file
 */
    goto zz300;
  }
/*
 *  same number of entries, do comparison.
 *  put 0s in litlst where clsxl1 has entries
 */
  for(i=1; i<=clsxl1_(cvmax+1); i++)  {
    litlst_(abs(clsxl1_(i)))=0;
  }
/*
 *  put +/-1s in litlst where clsxl2 has +/-1 entries
 */
  for(i=1; i<=clsxl2_(cvmax+1); i++)  {
    if (clsxl2_(i)<0) {
      litlst_(abs(clsxl2_(i)))=-1;
    } else {
      litlst_(abs(clsxl2_(i)))=1;
    }
  }
/*
 *  list litlst now has +/-1s in indices corresponding
 *  to entries of clsxl2
 *  check that each entry of litlst has a +/-1
 *  corresponding to each index of clsxl1
 */
  ixx=0;
  for(ix=1; ix<=clsxl1_(cvmax+1); ix++)  {
    if (clsxl1_(ix)<0) {
      if (litlst_(abs(clsxl1_(ix)))==-1) {
        ixx=ixx+1;
      }
    } else if (clsxl1_(ix)>0) {
      if (litlst_(clsxl1_(ix))==1) {
        ixx=ixx+1;
      }
    }
  }
  if (ixx==clsxl2_(cvmax+1)) {
/*
 *  rows are the same; ignore, look at next row
 */
    goto zz210;
  }
  zz300:;
/*
 *  rows are not the same, store in output temporary file
 *      clsxl2(cvmax+1)
 *      (clsxl2_(i), i=1, clsxl2_(cvmax+1))
 *      clsnam
 */
  i=2;
  wtfil3(&otmp,&i);
/*
 *  indicate all rows in itmp are not all duplicates
 */
  adflg=0;
  goto zz210;
/*
 * -----------------------------------------------------
 *  swap input and output files.  begin process over
 *  again, unless done, or remaining rows in file were
 *  all duplicates (adflg = 1)
 * -----------------------------------------------------
 */
  zz1000:;
  if (done==1) {
    return;
  }
  if (adflg==1) {
    return;
  }
  x=itmp;
  itmp=otmp;
  otmp=x;
  goto zz100;
}
/*eject*/
/*
 * ******************************************************
 *  subroutine sckdupv
 * 
 *  purpose:  the current literal index is in lidx.
 *            scans clsxl1 for duplicate or complement.
 * 
 *   return:  0 if variable or complement does not occur.
 *            1 if duplicate.
 *            2 if complement occurs.
 * 
 * ******************************************************
 * 
 */
void sckdupv(long *ckdupvt,long *lidxt) {
/*
 */
  static long lidx;
  static long i;
  static long ckdupv;
/*
 * initialize local variables and strings
 */
  ckdupv = *ckdupvt;
  lidx = *lidxt;
/*
 */
  ckdupv=0;
/*
 *  look for duplicate index
 */
  if (clsxl1_(cvmax+1)>0) {
    for(i=1; i<=clsxl1_(cvmax+1); i++)  {
/*
 *  check if duplicate or complement
 */
      if (abs(clsxl1_(i))==abs(lidx)) {
        if (clsxl1_(i)==lidx) {
/*
 *  duplicate found
 */
          ckdupv=1;
        }
        if (clsxl1_(i)!=lidx) {
/*
 *  complement found
 */
          ckdupv=2;
        }
        *ckdupvt = ckdupv;
        *lidxt = lidx;
        return;
      }
    }
  }
  *ckdupvt = ckdupv;
  *lidxt = lidx;
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine saddlit
 * 
 *  purpose:  looks up index of litnam in cnfvar,
 *            checks if for the current clause
 *            it is a duplicate or complement,
 *            and if  neither, adds the literal
 *            to clsxl1.
 * 
 * *********************************************************
 * 
 */
void saddlit(long *addlitt,char *litnam) {
/*
 */
  static long x,lidx;
  static char msgstr[128+1];
  static long addlit;
  static long getlix,ckdupv;
  static long n;
/*
 */
  void inperr();
  void schdupv();
  void scrwrt();
  void sgetlix();
/*
 * initialize local variables and strings
 */
  addlit = *addlitt;
  msgstr_(128+1) = '\0';
/*
 *  get index of literal in cnfvar
 */
  sgetlix(&getlix,litnam);
  lidx=getlix;
  if (litnam_(1)=='-') {
    lidx=-lidx;
  }
/*
 *  check if duplicate or if complement is already present.
 */
  sckdupv(&ckdupv,&lidx);
  x=ckdupv;
  addlit=x;
  if (x==0) {
/*
 *  store index in clsxl1
 */
    clsxl1_(cvmax+1)=clsxl1_(cvmax+1)+1;
    if (clsxl1_(cvmax+1)>cvmax) {
      inperr(&fatal);
      n = cvmax;
      sprintf(msgstr,
          " LBCC2200: Too many variables in clause; "
          "at most %ld allowed",n);
      scrwrt("+W",msgstr);
      *addlitt = addlit;
      return;
    }
    clsxl1_(clsxl1_(cvmax+1))=lidx;
    *addlitt = addlit;
    return;
  } else if (x==1) {
/*
 *  duplicate
 */
    *addlitt = addlit;
    return;
  } else if (x==2) {
/*
 *  complement found; throw out row on return
 */
    *addlitt = addlit;
    return;
  } else {
/*
 *  code not recognized
 */
    error(" addlit ","  106   ");
  }
}
/*eject*/
/*
 * ******************************************************
 *  subroutine sgetlix
 * 
 *  purpose:  searches for litnam in cnfvar and
 *            returns its index.
 * 
 * *****************************************************
 * 
 */
void sgetlix(long *getlixt,char *litnam) {
/*
 */
  static char tmpvar[58+1];
  static long i;
  static long getlix;
/*
 * initialize local variables and strings
 */
  getlix = *getlixt;
  if (litnam_(1)=='-') {
    strcpy(tmpvar,&litnam_(2));
  } else {
    strcpy(tmpvar,&litnam_(1));
  }
/*
 *  search for tmpvar in cnfvar; must find it
 */
  if (ncnfv>0) {
    for(i=1; i<=ncnfv; i++)  {
      if (strcmp(tmpvar,&cnfvar_(1,i))==0) {
        getlix=i;
        *getlixt = getlix;
        return;
      }
    }
/*
 *  error: variable not found
 */
    error(" sgetlix","   102  ");
  } else {
/*
 *  ncnfv must be greater than zero
 */
    error(" sgetlix","   104  ");
  }
}
/*eject*/
/*
 * *****************************************************
 *  subroutine chkcnd
 * 
 *  purpose:  checks if the 'WHERE' conditions
 *            are satisfied by the current permutation
 *            in qperm
 * 
 *   output:  valid = 1  if the current quantification
 *                       permutation satisfies all 'WHERE'
 *                       conditions
 *                    0  otherwise
 * *****************************************************
 * 
 */
void chkcnd(long *validt) {
/*
 */
  static long valid;
  static long i,ix,ixx;
/*
 * initialize local variables and strings
 */
  valid = *validt;
/*
 *  assume conditions hold, look for violation.
 */
  valid=1;
/*
 *  current permutation is in qperm
 *  check each 'WHERE' condition for current quantification
 *  permutation
 */
  if (nwhr==0) {
/*
 * there are no 'WHERE' conditions
 */
    *validt = valid;
    return;
  }
  for(i=1; i<=nwhr; i++)  {
    for(ix=1; ix<=nqnt; ix++)  {
      if (whrstm_(ix,i)==1) {
        for(ixx=ix+1; ixx<=nqnt; ixx++)  {
          if (whrstm_(ixx,i)==1) {
/*
 *  have other quantifier index in ixx
 */
            if (whrstm_(qntmax+1,i)==1) {
/*
 *  not equal condition; compare element names
 */
              if (strcmp(&eltnam_(1,setdat_(qperm_(ix),qsetix_(ix))),
                  &eltnam_(1,setdat_(qperm_(ixx),qsetix_(ixx))))!=0) {
/*
 *  so far, no violation; look at next condition
 */
                goto zz210;
              } else {
/*
 *  violation
 */
                valid=0;
                *validt = valid;
                return;
              }
            } else if (whrstm_(qntmax+1,i)==2) {
/*
 *  equal condition; compare element names
 */
              if (strcmp(&eltnam_(1,setdat_(qperm_(ix),qsetix_(ix))),
                  &eltnam_(1,setdat_(qperm_(ixx),qsetix_(ixx))))==0) {
/*
 *  so far, no violation; look at next condition
 */
                goto zz210;
              } else {
/*
 *  violation
 */
                valid=0;
                *validt = valid;
                return;
              }
            } else if (whrstm_(qntmax+1,i)==3) {
/*
 *  less than condition; compare element names
 */
              if (strcmp(&eltnam_(1,setdat_(qperm_(ix),qsetix_(ix))),
                  &eltnam_(1,setdat_(qperm_(ixx),qsetix_(ixx))))<0) {
/*
 *  so far, no violation; look at next condition
 */
                goto zz210;
              } else {
/*
 *  violation
 */
                valid=0;
                *validt = valid;
                return;
              }
            } else if (whrstm_(qntmax+1,i)==4) {
/*
 *  less than equal condition; compare element names
 */
              if (strcmp(&eltnam_(1,setdat_(qperm_(ix),qsetix_(ix))),
                  &eltnam_(1,setdat_(qperm_(ixx),qsetix_(ixx))))<=0) {
/*
 *  so far, no violation; look at next condition
 */
                goto zz210;
              } else {
/*
 *  violation
 */
                valid=0;
                *validt = valid;
                return;
              }
            } else if (whrstm_(qntmax+1,i)==5) {
/*
 *  greater than condition; compare element names
 */
              if (strcmp(&eltnam_(1,setdat_(qperm_(ix),qsetix_(ix))),
                  &eltnam_(1,setdat_(qperm_(ixx),qsetix_(ixx))))>0) {
/*
 *  so far, no violation; look at next condition
 */
                goto zz210;
              } else {
/*
 *  violation
 */
                valid=0;
                *validt = valid;
                return;
              }
            } else if (whrstm_(qntmax+1,i)==6) {
/*
 *  greater than equal condition; compare element names
 */
              if (strcmp(&eltnam_(1,setdat_(qperm_(ix),qsetix_(ix))),
                  &eltnam_(1,setdat_(qperm_(ixx),qsetix_(ixx))))>=0) {
/*
 *  so far, no violation; look at next condition
 */
                goto zz210;
              } else {
/*
 *  violation
 */
                valid=0;
                *validt = valid;
                return;
              }
            } else {
/*
 *  programming error, condition not found
 */
              error(" chkcnd ","  202   ");
            }
          }
        }
/*
 *  programming error: did not find the other quantifier in the condition.
 */
        error(" chkcnd ","  204   ");
      }
    }
  zz210:;}
/*
 *  all 'WHERE' conditions are satisfied
 */
  *validt = valid;
  return;
}
/*  last record of clscnf.c****** */
