/*  first record of help.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*
 * ********************************************
 *  module help
 *  if command listed in lower case listed, then 
 *  already implemented in C. 
 * ********************************************
 *
 *         CHKSOL     :- Check solution
 *         COMPOS     :- Compose blocks
 *         CNF2LG     :- Convert .CNF to .LOG
 *         damatx     :- Display amatcl, amatrw
 *         dcuts      :- Display ccut and rcut information
 *         dlabels    :- Display labeled/unlabeled cols/rows
 *         DCLDAT     :- Display column data
 *         DDRNGE     :- Display DRANGE, GPOD, GPODP
 *         DERNGE     :- Display ERANGE, GPOE, GPOEP
 *         DNAMES     :- Display COLNAM, ROWNAM, PRBNAM
 *         DRWDAT     :- Display row data
 *         ENUDEC     :- Solve current problem
 *         XATF       :- Extract ATF part
 *         XNOATF     :- Extract non-ATF part
 *         FNDALG     :- Find solution alg for a block
 *         FNDDEC     :- Find decomposition for a block
 *         FNDPAD     :- Automatic decomposition
 *         GENPRB     :- Generate problem
 *         GETCNF     :- Get CNF problem
 *         GETPRG     :- Get problem with range data
 *         INJATF     :- Inject ATF part into layer 1
 *         PICTUR     :- Picture of matrix
 *         PREP       :- Preprocess problem
 *         PRMFIX     :- Permute fixed columns
 *         PUTPRG     :- Put problem with range data
 *         QUERY      :- Answer queries
 *         RANGES     :- Calculate range data
 *         REFORM     :- Reformulate problem
 *         SELPAD     :- Manual decomposition
 *         STATS      :- Statistics of problem
 *         TBLKPR     :- Transfer BLK part to layer 1
 *         TPRBLK     :- Transfer layer 1 to BLK part
 */


/*
 *  damatx     :- Display amatcl, amatrw
 */
void damatx(char message[]) {
/*
 */
  static long i,j,q;
/*
 */
  printf("\n\n *** %s ***\n",message);
  fprintf(errfil,"\n\n *** %s ***\n",message);
  printf(
    "\nMatrix Rows\n");
  fprintf(errfil,
    "\nMatrix Rows\n");
  for (q=1;q<=nblks;q++) {
    printf("Block = %ld\n",q);
    fprintf(errfil,"Block = %ld\n",q);
    for (i=1;i<=nrows;i++) {
      if (riblk_(i) == q) {
        printf("Row = %s: ",&rownam_(1,invidxrow_(i)));
        fprintf(errfil,"Row = %s: ",&rownam_(1,invidxrow_(i)));
        for (j=1;j<=nzamar_(i);j++) {
          if (amatrw_(j+ptamar_(i)) > 0) {
            printf(" %s",
               &colnam_(1,invidxcol_(amatrw_(j+ptamar_(i)))));
            fprintf(errfil," %s",
               &colnam_(1,invidxcol_(amatrw_(j+ptamar_(i)))));
          } else {
            printf(" -%s",
               &colnam_(1,invidxcol_(-amatrw_(j+ptamar_(i)))));
            fprintf(errfil," -%s",
               &colnam_(1,invidxcol_(-amatrw_(j+ptamar_(i)))));
          }

          /* begin old code, has indices only */
          /* printf(
             "%5ld",amatrw_(j+ptamar_(i)));
              fprintf(errfil,
	      "%5ld",amatrw_(j+ptamar_(i))); */
	  /* end old code */

        }
        printf("\n");
        fprintf(errfil,"\n");
      }
    }
  }
/*
 */
  printf(
    "\nMatrix Columns\n");
  fprintf(errfil,
    "\nMatrix Columns\n");
  for (q=1;q<=nblks;q++) {
    printf("Block = %ld\n",q);
    fprintf(errfil,"Block = %ld\n",q);
    for (j=1;j<=ncols;j++) {
      if (ciblk_(j) == q) {
        printf("Col = %s: ",&colnam_(1,invidxcol_(j)));
        fprintf(errfil,"Col = %s: ",&colnam_(1,invidxcol_(j)));
        for (i=1;i<=nzamac_(j);i++) {
          if (amatcl_(i+ptamac_(j)) > 0) {
            printf(" %s",
               &rownam_(1,invidxrow_(amatcl_(i+ptamac_(j)))));
            fprintf(errfil," %s",
               &rownam_(1,invidxrow_(amatcl_(i+ptamac_(j)))));  
          } else {
            printf(" -%s",
               &rownam_(1,invidxrow_(-amatcl_(i+ptamac_(j)))));
            fprintf(errfil," -%s",
               &rownam_(1,invidxrow_(-amatcl_(i+ptamac_(j))))); 
          }

          /* begin old code, has indices only */
            /* printf(
               "%5ld",amatcl_(i+ptamac_(j)));
               fprintf(errfil,
               "%5ld",amatcl_(i+ptamac_(j)));*/
	  /* end old code */

        }
        printf("\n");
        fprintf(errfil,"\n");
      }
    }
  }
/*
 */
  return;
}

/*
 *  dcuts      :- Display ccut, rcut (cut information)
 */
void dcuts(char message[]) {
/*
 */
  static long ix,jx;

  printf("\n *** %s ***",message);
  fprintf(errfil,"\n *** %s ***",message);
  printf("\nCut Information:\n");
  fprintf(errfil,"\nCut Information:\n");

  printf("\nCut Rows:\n");
  fprintf(errfil,"Cut Rows\n");
  for (ix=1; ix<=rcut_(rowmax+1); ix++) {
    printf(" %s\n",&rownam_(1,invidxrow_(rcut_(ix))));
    fprintf(errfil," %s\n",&rownam_(1,invidxrow_(rcut_(ix))));
  }  
  printf("\nCut Columns:\n");
  fprintf(errfil,"\nCut Columns\n");
  for (jx=1; jx<=ccut_(colmax+1); jx++) {
    printf(" %s\n",&colnam_(1,invidxcol_(ccut_(jx))));
    fprintf(errfil," %s\n",&colnam_(1,invidxcol_(ccut_(jx))));
  }
  return;
}

void doriginalcuts(char message[]) {
/*
 */
  static long i,j;

  printf("\n *** %s ***",message);
  fprintf(errfil,"\n *** %s ***",message);
  printf("\nOriginal Cut Information:\n");
  fprintf(errfil,"\nOriginal Cut Information:\n");

  printf("\nCut Rows:\n");
  fprintf(errfil,"Cut Rows\n");
  for (i=1; i<=nrows; i++) {
    if (rw_(i,21,2) == 1) {
      printf(" %s\n",&rownam_(1,invidxrow_(i)));
      fprintf(errfil," %s\n",&rownam_(1,invidxrow_(i)));
    }
  }  
  printf("\nCut Columns:\n");
  fprintf(errfil,"\nCut Columns\n");
  for (j=1; j<=ncols; j++) {
    if (cl_(j,17,2) == 1) {
      printf(" %s\n",&colnam_(1,invidxcol_(j)));
      fprintf(errfil," %s\n",&colnam_(1,invidxcol_(j)));
    }
  }
  return;
}

/*
 *  dlabels    :- Display labeled/unlabeled cols/rows
 */
void dlabels(char message[]) {
/*
 */
  static long i,j;

  printf("\n *** %s ***",message);
  fprintf(errfil,"\n *** %s ***",message);
  printf("\nLabeled/Unlabeled Cols/Rows:\n");
  fprintf(errfil,"\nLabeled/Unlabeled Cols/Rows:\n");

  printf("\nLabeled Rows:\n");
  fprintf(errfil,"\nLabeled Rows\n");
  for (i=1; i<=nrows; i++) {
    if (rw_(i,22,2) == 1) {
      printf(" %s\n",&rownam_(1,invidxrow_(i)));
      fprintf(errfil," %s\n",&rownam_(1,invidxrow_(i)));
    }
  } 
  printf("\nUnlabeled Rows:\n");
  fprintf(errfil,"\nUnlabeled Rows\n");
  for (i=1; i<=nrows; i++) {
    if (rw_(i,22,2) == 0) {
      printf(" %s\n",&rownam_(1,invidxrow_(i)));
      fprintf(errfil," %s\n",&rownam_(1,invidxrow_(i)));
    }
  }   
  printf("\nLabeled Columns:\n");
  fprintf(errfil,"\nLabeled Columns\n");
  for (j=1; j<=ncols; j++) {
    if (cl_(j,18,2) == 1) {
      printf(" %s\n",&colnam_(1,invidxcol_(j)));
      fprintf(errfil," %s\n",&colnam_(1,invidxcol_(j)));
    }
  }
  printf("\nUnlabeled Columns:\n");
  fprintf(errfil,"\nUnlabeled Columns\n");
  for (j=1; j<=ncols; j++) {
    if (cl_(j,18,2) == 0) {
      printf(" %s\n",&colnam_(1,invidxcol_(j)));
      fprintf(errfil," %s\n",&colnam_(1,invidxcol_(j)));
    }
  }
  return;
}

/*
 *  dgraph     :- Display graph
 */
void dgraph(char message[]) {
/*
 */
  static long i,j,q;
/*
 */
  fprintf(prgfil,"\n *** %s ***",message);
  if (scrflg == 1) {
    printf("\n%s\n","Graph Edges");
  }
  fprintf(prgfil,
    "\n%s\n","Graph Edges");
  for (q=1;q<=nblks;q++) {
    if (scrflg == 1) {
      printf("Block = %ld\n Edges\n",q);
    }
    fprintf(prgfil,"Block = %ld\n Edges\n",q);
    for (i=1;i<=nrows;i++) {
      if (riblk_(i) == q) {
	if (scrflg == 1) {
          printf("%s: ",&rownam_(1,invidxrow_(i)));
	}
        fprintf(prgfil,"%s: ",&rownam_(1,invidxrow_(i)));
        for (j=1;j<=nzamar_(i);j++) {
          if (amatrw_(j+ptamar_(i)) > 0) {
            if (scrflg == 1) {
              printf("   %s",
               &colnam_(1,invidxcol_(amatrw_(j+ptamar_(i)))));
            }
            fprintf(prgfil,"   %s",
               &colnam_(1,invidxcol_(amatrw_(j+ptamar_(i)))));
          } else {
            if (scrflg == 1) {
              printf("   -%s",
               &colnam_(1,invidxcol_(-amatrw_(j+ptamar_(i)))));
            }
            fprintf(prgfil,"   -%s",
               &colnam_(1,invidxcol_(-amatrw_(j+ptamar_(i)))));
          }
        }
        if (scrflg == 1) {
          printf("\n");
        }
        fprintf(prgfil,"\n");
      }
    }
  }
/*
 */
/*  if (scrflg == 1) {
    printf("%s\n","Graph Nodes");
  }
  fprintf(prgfil,
    "%s\n","Graph Nodes");
  for (q=1;q<=nblks;q++) {
    if (scrflg == 1) {
      printf("Block = %ld Nodes\n",q);
    }
    fprintf(prgfil,"Block = %ld Nodes\n",q);
    for (j=1;j<=ncols;j++) {
      if (ciblk_(j) == q) {
        if (scrflg == 1) { 
          printf("%s: ",&colnam_(1,invidxcol_(j)));
        }
        fprintf(prgfil,"%s: ",&colnam_(1,invidxcol_(j)));
        for (i=1;i<=nzamac_(j);i++) {
          if (amatcl_(i+ptamac_(j)) > 0) {
            if (scrflg == 1) {
              printf("   %s",
               &rownam_(1,invidxrow_(amatcl_(i+ptamac_(j)))));
            }
            fprintf(prgfil,"   %s",
               &rownam_(1,invidxrow_(amatcl_(i+ptamac_(j)))));  
          } else {
            if (scrflg == 1) {
              printf("   -%s",
               &rownam_(1,invidxrow_(-amatcl_(i+ptamac_(j)))));
            }
            fprintf(prgfil,"   -%s",
               &rownam_(1,invidxrow_(-amatcl_(i+ptamac_(j))))); 
          }
        }
        if (scrflg == 1) {
          printf("\n");
        }
        fprintf(prgfil,"\n");
      }
    }
    } */
/*
 */
  return;
}

/*
 *  begin of Fortran code that so far
 *  has not been translated to C
 */
/*
C-----------------------------------------------------------------------------
C  SUBROUTINE HELP
C
C  Display HELP SCREEN
C-----------------------------------------------------------------------------
C
      SUBROUTINE HELP
C
      INCLUDE 'common.f'
C
      WRITE(*,'(1X,A/)') 'LEIBNIZ PROGRAM GENERATOR COMMANDS:'
      IF (ACCESS .EQ. 1) THEN
        WRITE(*,'(1X,A)')
     $         'ANALYZ     :- Analyze program for decomposition',
     $         '              into independent problems'
        WRITE(*,'(1X,A)') 'CHKSOL     :- Check solution'
        WRITE(*,'(1X,A)') 'COMPOS     :- Compose blocks'
        WRITE(*,'(1X,A)') 'CNF2LG     :- Convert .CNF to .LOG'
        WRITE(*,'(1X,A)') 'DAMATX     :- Display AMATCL, AMATRW'
        WRITE(*,'(1X,A)') 'DBMDAT     :- Display block matrix data'
        WRITE(*,'(1X,A)') 'DCLDAT     :- Display column data'
        WRITE(*,'(1X,A)') 'DDRNGE     :- Display DRANGE, GPOD, GPODP'
        WRITE(*,'(1X,A)') 'DERNGE     :- Display ERANGE, GPOE, GPOEP'
        WRITE(*,'(1X,A)') 'DNAMES     :- Display COLNAM, ROWNAM, PRBNAM'
        WRITE(*,'(1X,A)') 'DRWDAT     :- Display row data'
        WRITE(*,'(1X,A)') 'ENUDEC     :- Solve current problem'
        WRITE(*,'(1X,A)') 'XATF       :- Extract ATF part'
        WRITE(*,'(1X,A)') 'XNOATF     :- Extract non-ATF part'
        WRITE(*,'(1X,A)') 'FNDALG     :- Find solution alg for a block'
        WRITE(*,'(1X,A)') 'FNDDEC     :- Find decomposition for a block'
        WRITE(*,'(1X,A)') 'FNDPAD     :- Automatic decomposition'
        WRITE(*,'(1X,A)') 'GENPRB     :- Generate problem'
        WRITE(*,'(1X,A)') 'GETCNF     :- Get CNF problem'
        WRITE(*,'(1X,A)') 'GETPRG     :- Get problem with range data'
        WRITE(*,'(1X,A)') 'INJATF     :- Inject ATF part into layer 1'
        WRITE(*,'(1X,A)') 'PICTUR     :- Picture of matrix'
        WRITE(*,'(1X,A)') 'PREP       :- Preprocess problem'
        WRITE(*,'(1X,A)') 'PRMFIX     :- Permute fixed columns'
        WRITE(*,'(1X,A)') 'PUTPRG     :- Put problem with range data'
        WRITE(*,'(1X,A)') 'QUERY      :- Answer queries'
        WRITE(*,'(1X,A)') 'RANGES     :- Calculate range data'
        WRITE(*,'(1X,A)') 'REFORM     :- Reformulate problem'
        WRITE(*,'(1X,A)') 'SELPAD     :- Manual decomposition'
        WRITE(*,'(1X,A)') 'STATS      :- Statistics of problem'
        WRITE(*,'(1X,A)') 'TBLKPR     :- Transfer BLK part to layer 1'
        WRITE(*,'(1X,A)') 'TPRBLK     :- Transfer layer 1 to BLK part'
      ENDIF
      WRITE(*,'(1X,A)') 'G          :- Generate program'
      WRITE(*,'(1X,A)') 'R          :- Retrieve program'
      WRITE(*,'(1X,A)') 'E          :- Execute program'
      WRITE(*,'(1X,A)') 'Q          :- Quit'
      RETURN
      END
C
C-----------------------------------------------------------------------------
C  SUBROUTINE DBMDAT
C
C  Display all matrix info for block information
C-----------------------------------------------------------------------------
C
       SUBROUTINE DBMDAT
C
      INCLUDE 'common.f'
C
      INTEGER * 4  I, J
C
      WRITE(DISK5,'(1X,A)') 'MATRIX BLOCK INFORMATION'
      WRITE(*,'(1X,A)') 'MATRIX BLOCK INFORMATION'
      WRITE(DISK5,'(1X,A)') 'ABLKRW:'
      WRITE(*,'(1X,A)') 'ABLKRW:'
      DO 110 I=1, NROWS
        WRITE(*,'(40I3)') (ABLKRW(J+PTABLR(I)),
     $                     J=1,NZABLR(I))
        WRITE(DISK5,'(40I3)') (ABLKRW(J+PTABLR(I)),
     $                         J=1,NZABLR(I))
 110  CONTINUE
      WRITE(DISK5,'(1X,A)') 'ABLKCL:'
      WRITE(*,'(1X,A)') 'ABLKCL:'
      DO 120 J=1, NCOLS
        WRITE(*,'(40I3)') (ABLKCL(I+PTABLC(J)),
     $                     I=1,NZABLC(J))
        WRITE(DISK5,'(40I3)') (ABLKCL(I+PTABLC(J)),
     $                         I=1,NZABLC(J))
 120  CONTINUE
      RETURN
      END
C
C
C-----------------------------------------------------------------------------
C  SUBROUTINE DCLDAT
C
C  Display all column arrays
C-----------------------------------------------------------------------------
C
      SUBROUTINE DCLDAT(LAYER)
C
      INCLUDE 'common.f'
C
      INTEGER * 4  L, I, J, LAYER
C
      WRITE(*,'(/,A,I2,A)') ' LAYER ',LAYER,' COLUMN INFORMATION CL'
      WRITE(DISK5,'(/,A,I2,A)') ' LAYER ',LAYER,' COLUMN INFORMATION CL'
C  write numbered 'L' identification line
      WRITE(*,'(25I3)') (L, L=1,LCLMAX)
      WRITE(*,'(25A3)') ('-', I=1,LCLMAX)
      WRITE(DISK5,'(25I3)') (L, L=1,LCLMAX)
      WRITE(DISK5,'(25A3)') ('-', I=1,LCLMAX)
      DO 110 J=1,NCOLS
        WRITE(*,'(25I3)') (CL(J,L,LAYER), L=1,LCLMAX)
 110    WRITE(DISK5,'(25I3)') (CL(J,L,LAYER), L=1,LCLMAX)
      RETURN
      END
C
C
C-----------------------------------------------------------------------------
C  SUBROUTINE DRWDAT
C
C  Display all row arrays and counts from specified layer
C-----------------------------------------------------------------------------
C
       SUBROUTINE DRWDAT(LAYER)
C
      INCLUDE 'common.f'
C
      INTEGER * 4  L, I, LAYER
C
      WRITE(*,'(/,A,I2,A,A)') ' LAYER ',LAYER,' ROW INFORMATION RW'
      WRITE(DISK5,'(/,A,I2,A,A)') ' LAYER ',LAYER,' ROW INFORMATION RW'
C  write numbered 'L' identification line
      WRITE(*,'(25I3)') (L, L=1,LRWMAX)
      WRITE(*,'(25A3)') ('--', I=1,LRWMAX)
      WRITE(DISK5,'(25I3)') (L, L=1,LRWMAX)
      WRITE(DISK5,'(25A3)') ('--', I=1,LRWMAX)
      DO 110 I=1, NROWS
        WRITE(*,'(25I3)') (RW(I,L,LAYER), L=1,LRWMAX)
 110    WRITE(DISK5,'(25I3)') (RW(I,L,LAYER), L=1,LRWMAX)
      RETURN
      END
C
C
C-----------------------------------------------------------------------------
C  SUBROUTINE DAMATX
C
C  Display AMATX contents
C-----------------------------------------------------------------------------
C
       SUBROUTINE DAMATX
C
      INCLUDE 'common.f'
C
      INTEGER * 4  I, J
C
      WRITE(DISK5,'(A,I2)') ' MATRIX CONTENTS FOR LAYER 1'
      WRITE(*,'(A,I2)') ' MATRIX CONTENTS FOR LAYER 1'
      WRITE(DISK5,'(1X,A)') 'AMATRW:'
      WRITE(*,'(1X,A)') 'AMATRW:'
      DO 110 I=1, NROWS
        WRITE(*,'(40I3)') (AMATRW(J+PTAMAR(I)),
     $                     J=1,NZAMAR(I))
        WRITE(DISK5,'(40I3)') (AMATRW(J+PTAMAR(I)),
     $                         J=1,NZAMAR(I))
 110  CONTINUE
      WRITE(DISK5,'(1X,A)') 'AMATCL:'
      WRITE(*,'(1X,A)') 'AMATCL:'
      DO 120 J=1, NCOLS
        WRITE(*,'(40I3)') (AMATCL(I+PTAMAC(J)),
     $                     I=1,NZAMAC(J))
        WRITE(DISK5,'(40I3)') (AMATCL(I+PTAMAC(J)),
     $                         I=1,NZAMAC(J))
 120  CONTINUE
      RETURN
      END
C
C
C-----------------------------------------------------------------------------
C  SUBROUTINE DNAMES
C
C  Display COLUMN, ROW, AND PROBLEM NAMES
C-----------------------------------------------------------------------------
C
       SUBROUTINE DNAMES
C
      INCLUDE 'common.f'
C
      INTEGER * 4  I, J
C
      WRITE(DISK5,'(A,A)') ' PROBLEM NAME: ',PRBNAM(1)
      WRITE(DISK5,'(A)') ' COLUMN NAMES:'
      WRITE(DISK5,'(1X,A28)') (COLNAM(J), J=1,NCOLS)
      WRITE(DISK5,'(A)') ' ROW NAMES:'
      WRITE(DISK5,'(1X,A28)') (ROWNAM(I), I=1,NROWS)
C
      WRITE(*,'(A,A)') ' PROBLEM NAME: ',PRBNAM(1)
      WRITE(*,'(A)') ' COLUMN NAMES:'
      WRITE(*,'(1X,A28)') (COLNAM(J), J=1,NCOLS)
      WRITE(*,'(A)') ' ROW NAMES:'
      WRITE(*,'(1X,A28)') (ROWNAM(I), I=1,NROWS)
      RETURN
      END
C-----------------------------------------------------------------------------
C  SUBROUTINE DDRNGE
C
C  Display DRANGE, GPOD, GPODP.
C-----------------------------------------------------------------------------
C
      SUBROUTINE DDRNGE
C
      INCLUDE 'common.f'
C
      INTEGER * 4   Q, K, J
C
      DO 10 Q=1, NBLKS-1
        CALL RANGES
C-------------------------------------------------------------------------
C  print out range vectors
C  strip graph information. negative numbers become positive, remove 2**14
C-------------------------------------------------------------------------
        DO 40 K=1, NDERS(Q)
          IF (DRANGE(K,Q) .GE. 2**14) THEN
              DRANGE(K,Q) = DRANGE(K,Q) - 2**14
          ENDIF
          IF (DRANGE(K,Q) .LE. -(2**14)) THEN
            DRANGE(K,Q) = IABS(DRANGE(K,Q) + 2**14)
          ENDIF
 40     CONTINUE
        WRITE(DISK5,'(A,I2,A)') 'DRANGE BLK ',Q,' RANGE VECTORS'
C  write out column by column, where one column is on one row
        DO 100 J=1, NDRGE(Q)
          WRITE(DISK5,'(1X,64I4)')
     $       (IABS(DRANGE(K+PTDR(J,Q),Q)),
     $        K=1,NZDR(J,Q))
 100    CONTINUE
        CALL RANGES
C-------------------------------------------------------------------------
C  print out GPOD information
C  write out '1' for negative numbers, else '0'
C-------------------------------------------------------------------------
        DO 60 K=1, NDRGE(Q)
          DO 70 J=1, NDRGE(Q)
            IF (GPOD(K,J+NERGE(Q),Q) .LT. 0) THEN
              GPOD(K,J+NERGE(Q),Q) = 1
            ELSE
              GPOD(K,J+NERGE(Q),Q) = 0
            ENDIF
 70       CONTINUE
 60     CONTINUE
        WRITE(DISK5,'(A,I2,A)') 'DRANGE BLK ',Q,' GPOD'
C  write out column by column, where one column is on one row
        DO 200 J=1, NDRGE(Q)
          WRITE(DISK5,'(1X,64I4)') 
     $       (GPOD(K,J+NERGE(Q),Q),K=1,NDRGE(Q))
 200    CONTINUE
        CALL RANGES
C-------------------------------------------------------------------------
C  print out GPODP information
C  if IABS greater than equal 2**14, write out '1', else '0'
C-------------------------------------------------------------------------
        IF (Q .GT. 1) THEN
        DO 80 K=1, NDRGE(Q-1)
          DO 90 J=1, NDRGE(Q)
            IF (IABS(GPODP(K,J+NERGE(Q),Q)) .GE. 2**14) THEN
              GPODP(K,J+NERGE(Q),Q) = 1
            ELSE
              GPODP(K,J+NERGE(Q),Q) = 0
            ENDIF
 90       CONTINUE
 80     CONTINUE
        WRITE(DISK5,'(A,I2,A)') 'DRANGE BLK ',Q,' GPODP'
C  write out column by column, where one column is on one row
        DO 300 J=1, NDRGE(Q)
          WRITE(DISK5,'(1X,64I4)')
     $          (GPODP(K,J+NERGE(Q),Q),K=1,NDRGE(Q-1))
 300    CONTINUE
        ENDIF
 10   CONTINUE
      CALL RANGES
      RETURN
      END
C
C
C-----------------------------------------------------------------------------
C  SUBROUTINE DERNGE
C
C  Display ERANGE, GPOE, GPOEP.
C-----------------------------------------------------------------------------
C
      SUBROUTINE DERNGE
C
      INCLUDE 'common.f'
C
      INTEGER * 4   Q, K, J
C
      DO 10 Q=1, NBLKS-1
        CALL RANGES
C-------------------------------------------------------------------------
C  print out range vectors
C  strip graph information. negative numbers become positive, remove 2**14
C-------------------------------------------------------------------------
        DO 40 K=1, NDERS(Q)
          IF (ERANGE(K,Q) .GE. 2**14) THEN
              ERANGE(K,Q) = ERANGE(K,Q) - 2**14
          ENDIF
          IF (ERANGE(K,Q) .LE. -(2**14)) THEN
            ERANGE(K,Q) = IABS(ERANGE(K,Q) + 2**14)
          ENDIF
 40     CONTINUE
        WRITE(DISK5,'(A,I2,A)') 'ERANGE BLK ',Q,' RANGE VECTORS'
C  write out column by column, where one column is on one row
        DO 100 J=1, NERGE(Q)
          WRITE(DISK5,'(1X,64I4)')
     $       (IABS(ERANGE(K+PTER(J,Q),Q)),
     $        K=1,NZER(J,Q))
 100    CONTINUE
        CALL RANGES
C-------------------------------------------------------------------------
C  print out GPOE information
C  write out '1' for negative numbers, else '0'
C-------------------------------------------------------------------------
        DO 60 K=1, NERGE(Q)
          DO 70 J=1, NERGE(Q)
            IF (GPOE(K,J,Q) .LT. 0) THEN
              GPOE(K,J,Q) = 1
            ELSE
              GPOE(K,J,Q) = 0
            ENDIF
 70       CONTINUE
 60     CONTINUE
        WRITE(DISK5,'(A,I2,A)') 'ERANGE BLK ',Q,' GPOE'
C  write out column by column, where one column is on one row
        DO 200 J=1, NERGE(Q)
          WRITE(DISK5,'(1X,64I4)') (GPOE(K,J,Q),K=1,NERGE(Q))
 200    CONTINUE
        CALL RANGES
C-------------------------------------------------------------------------
C  print out GPOEP information
C  if IABS greater than equal 2**14, write out '1', else '0'
C-------------------------------------------------------------------------
        IF (Q .GT. 1) THEN
        DO 80 K=1, NERGE(Q-1)
          DO 90 J=1, NERGE(Q)
            IF (IABS(GPOEP(K,J,Q)) .GE. 2**14) THEN
              GPOEP(K,J,Q) = 1
            ELSE
              GPOEP(K,J,Q) = 0
            ENDIF
 90       CONTINUE
 80     CONTINUE
        WRITE(DISK5,'(A,I2,A)') 'ERANGE BLK ',Q,' GPOEP'
C  write out column by column, where one column is on one row
        DO 300 J=1, NERGE(Q)
          WRITE(DISK5,'(1X,64I4)') (GPOEP(K,J,Q),K=1,NERGE(Q-1))
 300    CONTINUE
        ENDIF
 10   CONTINUE
      CALL RANGES
      RETURN
      END
*/
/*
 *  end of Fortran code
 */
/*  last record of help.c****** */ 
