/*  first record of lpxfdefs.h***** */
/* function defs begin */
#define memr_(i)       memr[(i-1)]
#define memi_(i)       memi[(i-1)]
#define b_(i)          b[(i-1)]
#define bascb_(i)      bascb[(i-1)]
#define baslb_(i)      baslb[(i-1)]
#define basub_(i)      basub[(i-1)]
#define betar_(i)      betar[(i-1)]
#define blow_(i)       blow[(i-1)]
#define cola_(i)       cola[(i-1)]
#define uzero_(i)      uzero[(i-1)]
#define xbzero_(i)     xbzero[(i-1)]
#define yq_(i)         yq[(i-1)]
#define basis_(i)      basis[(i-1)]
#define coli_(i)       coli[(i-1)]
#define rowtyp_(i)     rowtyp[(i-1)]
#define status_(i)     status[(i-1)]
/*  last record of lpxfdefs.h****** */
