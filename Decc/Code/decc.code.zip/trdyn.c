/*  first record of trdyn.c***** */
#include<stdio.h>
#include<stdlib.h>
#include"exparms.h"
#include"exexts.h"
#include"trparms.h"
#include"trdefs.h"
#include"trfdefs.h"
extern long tralcflg;
/* ************************************* */
void trdyn_alloc() {
/*
 *  memory allocation
 *  caution: make sure that the following parameters
 *           have been defined and and satisfy the
 *           conditions below
 *  setmax >= 2
 *  prdmax >= 2
 *  eltmax >= 2
 *  cvmax  >= 100 (to prevent small case effects)
 *  busmax >= 60*cvmax
 *  bchmax >= rditln*cvmax 
 *   
 *  qntmax  =  3
 *  whrmax  =  3
 *  bufmax  =  2
 *  vnamln  = 58
 *  enamln  = 58
 *  rnamln  = 58
 *  ridtln  = 58
 */
  long i, j, k;
/*
 */
  void error();
/*
 *  reset allocation flag and
 *  check that no allocation exists
 */
  if (tralcflg==0) {
    tralcflg = 1;
  } else {
    error("trdyn_alloc","102");
  }
/*
 *  assign 
 *     anzmax, rowmax, colmax 
 *  values to corresponding
 *     camax, crmax, cvmax
 *  also define busmax, bchmax
 */
  camax = anzmax;
  crmax = rowmax;
  cvmax = colmax;
  busmax = 60*cvmax; /* dimension of bulk arrays    */
                     /* replacing devices 12 and 13 */
  bchmax = ridtln*cvmax; /* max string length for buchr array */
/*
 */
  if (setmax < 2 ) {
    error("trdyn_alloc","202");
  }
  if (prdmax < 2 ) {
    error("trdyn_alloc","204");
  }
  if (eltmax < 2 ) {
    error("trdyn_alloc","206");
  }
  if (cvmax < 100 ) {
    error("trdyn_alloc","208");
  }
  if ( qntmax != 3 ) {
    error("trdyn_alloc","216");
  }
  if ( whrmax != 3 ) {
    error("trdyn_alloc","218");
  }
  if ( bufmax != 2 ) {
    error("trdyn_alloc","222");
  }
  if ( vnamln != 58 ) {
    error("trdyn_alloc","224");
  }
  if ( enamln != 58 ) {
    error("trdyn_alloc","226");
  }
  if ( rnamln != 58 ) {
    error("trdyn_alloc","228");
  }
  if ( ridtln != 58 ) {
    error("trdyn_alloc","232");
  }
/*
 */
  if((cnfvar = (char  *) malloc((vnamln+1) * (cvmax) * sizeof(char  )))==NULL) goto zz100;
  if((cnfvarflg = (char  *) malloc((1+1) * (cvmax) * sizeof(char  )))==NULL) goto zz100;
  if((cstval = (char  *) malloc((6+1) * (2) * (cvmax) * sizeof(char  )))==NULL) goto zz100;
  if((delopt = (long  *) malloc((cvmax) * sizeof(long  )))==NULL) goto zz100;
  if((varopt = (long  *) malloc((cvmax) * sizeof(long  )))==NULL) goto zz100;
  if((clsxl1 = (long  *) malloc((cvmax+1) * sizeof(long  )))==NULL) goto zz100;
  if((clsxl2 = (long  *) malloc((cvmax+1) * sizeof(long  )))==NULL) goto zz100;
  if((litlst = (long  *) malloc((cvmax) * sizeof(long  )))==NULL) goto zz100;
  if((truec  = (char  *) malloc((6+1) * sizeof(char  )))==NULL) goto zz100;
  if((falsc  = (char  *) malloc((6+1) * sizeof(char  )))==NULL) goto zz100;
  if((strng1 = (char  *) malloc((busmax+1) * sizeof(char  )))==NULL) goto zz100;
  if((strng2 = (char  *) malloc((busmax+1) * sizeof(char  )))==NULL) goto zz100;
  if((strng3 = (char  *) malloc((busmax+1) * sizeof(char  )))==NULL) goto zz100;
  if((nburec = (long  *) malloc((bufmax) * sizeof(long  )))==NULL) goto zz100;
  if((tburec = (long  *) malloc((bufmax) * sizeof(long  )))==NULL) goto zz100;
  if((xbuchr = (long  *) malloc((bufmax) * sizeof(long  )))==NULL) goto zz100;
  if((xbuint = (long  *) malloc((bufmax) * sizeof(long  )))==NULL) goto zz100;
  if((crdflg = (long  *) malloc((bufmax) * sizeof(long  )))==NULL) goto zz100;
  if((cwtflg = (long  *) malloc((bufmax) * sizeof(long  )))==NULL) goto zz100;
  if((buchr  = (char  *) malloc(((bchmax+1)*bufmax) * sizeof(char  )))==NULL) goto zz100;
  if((buint  = (long  *) malloc((busmax) * (bufmax) * sizeof(long  )))==NULL) goto zz100;
  if((state  = (char  *) malloc((5+1) * sizeof(char  )))==NULL) goto zz100;
  if((sused  = (long  *) malloc((setmax) * sizeof(long  )))==NULL) goto zz100;
  if((setdat = (long  *) malloc((eltmax+3) * (setmax) * sizeof(long  )))==NULL) goto zz100;
  if((setnam = (char  *) malloc((vnamln+1) * (setmax) * sizeof(char  )))==NULL) goto zz100;
  if((eltnam = (char  *) malloc((enamln+1) * (eltmax) * sizeof(char  )))==NULL) goto zz100;
  if((prdset = (long  *) malloc((3) * (prdmax) * sizeof(long  )))==NULL) goto zz100;
  if((pused  = (long  *) malloc((prdmax) * sizeof(long  )))==NULL) goto zz100;
  if((prdnam = (char  *) malloc((enamln+1) * (prdmax) * sizeof(char  )))==NULL) goto zz100;
  if((vused  = (long  *) malloc((cvmax) * sizeof(long  )))==NULL) goto zz100;
  if((varnam = (char  *) malloc((vnamln+1) * (cvmax) * sizeof(char  )))==NULL) goto zz100;
  if((nvnam  = (char  *) malloc((8+1) * (cvmax) * sizeof(char  )))==NULL) goto zz100;
  if((qperm  = (long  *) malloc((qntmax) * sizeof(long  )))==NULL) goto zz100;
  if((qsetix = (long  *) malloc((qntmax) * sizeof(long  )))==NULL) goto zz100;
  if((qntnam = (char  *) malloc((enamln+1) * (qntmax) * sizeof(char  )))==NULL) goto zz100;
  if((qused  = (long  *) malloc((qntmax) * sizeof(long  )))==NULL) goto zz100;
  if((clsnam = (char  *) malloc((ridtln+1) * sizeof(char  )))==NULL) goto zz100;
  if((whrstm = (long  *) malloc((qntmax+1) * (whrmax) * sizeof(long  )))==NULL) goto zz100;
  if((trprbnam = (char  *) malloc((enamln+1) * sizeof(char  )))==NULL) goto zz100;
  if((trcolnam = (char  *) malloc((vnamln+1) * (cvmax) * sizeof(char  )))==NULL) goto zz100;
  if((trrownam = (char  *) malloc((ridtln+1) * (crmax) * sizeof(char  )))==NULL) goto zz100;
  if((trcolusx = (long  *) malloc((cvmax) * sizeof(long  )))==NULL) goto zz100;
  if((trcvatf  = (long  *) malloc((cvmax) * sizeof(long  )))==NULL) goto zz100;
  if((trtrucst = (long  *) malloc((cvmax) * sizeof(long  )))==NULL) goto zz100;
  if((trfalcst = (long  *) malloc((cvmax) * sizeof(long  )))==NULL) goto zz100;
  if((tramatrw = (long  *) malloc((camax) * sizeof(long  )))==NULL) goto zz100;
  if((trptamar = (long  *) malloc((crmax) * sizeof(long  )))==NULL) goto zz100;
  if((trnzamar = (long  *) malloc((crmax) * sizeof(long  )))==NULL) goto zz100;
  if((auxmsg = (char  *) malloc((128+1) * sizeof(char  )))==NULL) goto zz100;
  if((inputrecord = (char  *) malloc((128+1) * sizeof(char  )))==NULL) goto zz100;
  tmpstr = strng1;
  tmp    = strng2;
  grpstr = strng1;
  litstr = strng3;
/*
 *  initialize end-of-string character for strings
 */
  truec_(6+1)       = '\0';
  falsc_(6+1)       = '\0';
  strng1_(busmax+1) = '\0';
  strng2_(busmax+1) = '\0';
  strng3_(busmax+1) = '\0';
  state_(5+1)       = '\0';
  clsnam_(ridtln+1) = '\0';
  auxmsg_(128+1)    = '\0';
  inputrecord_(128+1) = '\0';
  for (j=1;j<=cvmax;j++) {
    cnfvar_(vnamln+1,j) = '\0';
    cnfvarflg_(j) = '\0';
  }
  for (j=1;j<=bufmax;j++) {
    buchr_(bchmax+1,j) = '\0';
  }
  for (j=1;j<=setmax;j++) {
    setnam_(vnamln+1,j) = '\0';
  }
  for (j=1;j<=eltmax;j++) {
    eltnam_(enamln+1,j) = '\0';
  }
  for (j=1;j<=prdmax;j++) {
    prdnam_(enamln+1,j) = '\0';
  }
  for (j=1;j<=cvmax;j++) {
    varnam_(vnamln+1,j) = '\0';
  }
  for (j=1;j<=cvmax;j++) {
    nvnam_(8+1,j) = '\0';
  }
  for (j=1;j<=qntmax;j++) {
    qntnam_(enamln+1,j) = '\0';
  }
  for (j=1;j<=2;j++) {
    for (k=1;k<=cvmax;k++) {
      cstval_(6+1,j,k) = '\0';
    }
  }
  for (j=1;j<=cvmax;j++) {
    trcolnam_(53,j) = '\0';
    trcolnam_(vnamln+1,j) = '\0';
  }
  for (i=1;i<=crmax;i++) {
    trrownam_(53,i) = '\0';
    trrownam_(ridtln+1,i) = '\0';
  }
/*  initialize flag variables
 */
  warn  = 1;
  nftl  = 2;
  fatal = 3;
  exis  = 1;
  univ  = 2;  
/*
 */
  return;
  zz100:
/*
 * insufficient memory available for allocation
 */
  printf(
   "Insufficient memory available for lbcc trdyn allocation\n");
  printf(
   "Must reduce problem size or increase memory\n");
  printf(
   "Stop\n");
  fprintf(errfil,
   "Insufficient memory available for lbcc trdyn allocation\n");
  fprintf(errfil,
   "Must reduce problem size or increase memory\n");
  fprintf(errfil,
   "Stop\n"); 
  exit(1);
}
/* ************************************* */
void trdyn_free() {
/*
 *  memory de-allocation
 */
  void error();
/*
 *  reset allocation flag and
 *  check that allocation exists
 */
  if (tralcflg==1) {
    tralcflg = 0;
  } else {
    error("trdyn_free","102");
  }
/*
 */
  free(cnfvar );
  free(cnfvarflg );
  free(cstval );
  free(delopt );
  free(varopt );
  free(clsxl1 );
  free(clsxl2 );
  free(litlst );
  free(truec  );
  free(falsc  );
  free(strng1 );
  free(strng2 );
  free(strng3 );
  free(nburec );
  free(tburec );
  free(xbuchr );
  free(xbuint );
  free(crdflg );
  free(cwtflg );
  free(buchr  );
  free(buint  );
  free(state  );
  free(sused  );
  free(setdat );
  free(setnam );
  free(eltnam );
  free(prdset );
  free(pused  );
  free(prdnam );
  free(vused  );
  free(varnam );
  free(nvnam  );
  free(qperm  );
  free(qsetix );
  free(qntnam );
  free(qused  );
  free(clsnam );
  free(whrstm );
  free(trprbnam);
  free(trcolnam);
  free(trrownam);
  free(trcolusx);
  free(trcvatf);
  free(trtrucst);
  free(trfalcst);
  free(tramatrw);
  free(trptamar);
  free(trnzamar);
  free(auxmsg );
  free(inputrecord);
  return;
}
/*  last record of trdyn.c****** */
