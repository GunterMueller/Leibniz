/*  first record of query.c***** */
/*
 * ******************************************************
 *  module query interface (execution)
 * 
 *  purpose: handles user queries
 *
 *  procedures:
 * 
 *    asg_dev     assign devices (allocate memory and 
 *                open error output device).
 *                asg_dev or inz_prb must be first procedure.
 *    beg_prb     read program (.prg) into layer 1.
 *    del_prb     delete a problem from storage.
 *    exe_lbcc    execute lbcc compiler.
 *    fre_dev     free devices (deallocate memory and
 *                close error output device)
 *    get_cgn     return clause name or goal name plus
 *                related information for specified
 *                index.
 *    get_dim     get dimensions for colmax, rowmax, anzmax,
 *                blkmax, prbmax, and stomax  from specified prg 
 *                files by repeated calls
 *    get_dul     return dual value for clause or goal
 *                with specified index.
 *    get_gol     return goal information for specified
 *                goal.
 *    get_pml     return classification for specified
 *                variable during most recent execution
 *                of lp in apmsol.
 *    get_val     return variable value and cost
 *                information for specified name or index
 *                (not allowed with transfer process)
 *    inz_prb     open error file.
 *                read specified prg files, compute parameters
 *                colmax, rowmax, anzmax, blkmax, prgmax, and 
 *                stomax (get_dim).
 *                assign devices (asg_dev).
 *                load programs of specified prg files into 
 *                memory (beg_prb).
 *                asg_dev or inz_prb must be first procedure.
 *    lim_err     define limits on number of warning/error
 *                cases when execution is terminated
 *    mxcls_sat  find maximal set of specified clauses for 
 *                which problem is satisfiable
 *    mncls_unsat find minimal set of specified clauses for
 *                which problem is unsatisfiable
 *    mst_allvar  modify status of all user variables
 *                (requires transfer process)
 *    mst_cls     modify the state of all clauses matching
 *                the given criteria string.
 *    mst_gol     modify state of all goals matching the
 *                given criteria string.
 *    mst_prb     change problem type from minimization
 *                problem to satisfiability problem or
 *                conversely.
 *    mst_var     modify the state of all variables
 *                matching the given criteria string or
 *                index
 *    ret_prb     retrieve a problem from storage.
 *    rst_prb     restore all or part of original
 *                problem.
 *    sol_prb     solve the problem;
 *                return total cost if satisfiable
 *                and if it is an optimization problem.
 *    sol_xct     solve the problem exactly
 *                (i.e., not approx. min.)
 *    sts_cls     return status of clause: active or
 *                deleted.
 *    sts_elt     return status of element: element name given
 *                index, or index given element name. Also,
 *                total number of elements.
 *                procedure is defined in mktrsdefsexts()
 *                of file mktrsprocess.c and is available
 *                only when transfer process is used
 *    sts_prb     return no. of variables, no. clauses
 *                and goals, whether or not solved.
 *                if solved, return whether or not
 *                satisfiable.
 *    sts_sto     return summary for storage of problems,
 *                including the problem name of problem
 *                with specified index
 *    sts_var     return status of variable:
 *                cost, value, active or
 *                deleted, goal information.
 *    sto_prb     store a problem.
 *
 *  utilities:
 *    pdatatoudata  move pdata to udata at end of procedure
 *    udatatopdata  move udata to pdata at begin of procedure
 *
 *  in each procedure: load local variables 
 *  pcomnd, pname, pstate, ptype, pvalue, perror 
 *  with the values of the user variables. prior to 
 *  exit of the procedure, transfer the values of 
 *  pcomnd, pname, pstate, ptype, pvalue, perror
 *  to the user variables except for pname, which 
 *  is assigned to uname only if needed.
 *  caution: if dimension of string uname,
 *  ustate, or utype is changed, then must also
 *  adjust assignment of end-of-string
 *  character and upper-case conversion in
 *  udatatopdata.
 *  
 *  ucomnd,uname,ustate,uvalue,uvalue,uerror are the
 *  parameters sent from the calling program.
 *
 *  flags (are part of .prg file, and are stored
 *         when problem is stored):
 *    solflg      -2  = initially and after fre_dev
 *                -1  = after asg_dev, no problem loaded
 *                 0  = problem loaded, not solved
 *                 1  = problem solved (sol_prb executed)
 *
 *    asgflg       0  = set to zero after problem solved
 *                 1  = changes were made after problem
 *                      solved
 * 
 *  if solflg = 1:
 *      satble     0  = not satisfiable
 *                 1  = satisfiable
 * 
 * 
 *  the following procedures change solflg to 0:
 *  (the remaining procedures do not affect solflg) 
 *              beg_prb
 *              exe_lbcc
 *              rst_prb
 *              mst_cls
 *              mst_prb
 *              mst_var
 * 
 *  the following procedures change asgflg to 1:
 *  (the remaining procedures do not affect asgflg) 
 *              mst_var
 *              mst_cls
 *              rst_prb
 * 
 *  caution: if transfer process is used, flags solflg = 1 
 *           and asgflg = 1 cannot be interpreted as stated 
 *           above since user may have changed variable values 
 *           in user program and such changes are not known
 *           to procedures of this module.
 *
 *           all procedures except asg_dev and beg_prb assume
 *           current problem in level 1.
 * 
 *           if any procedure is changed or added so
 *           that cl, rw arrays of
 *           layer 1 are affected other than cixxx, rixxx,
 *           then must also adjust procedure rst_prb
 * 
 *           counts cnxxxx, rnxxxx in layer 1 are not
 *           maintained
 * 
 *  notes: 1. xerror is a global variable whose value
 *         is checked upon entrance to each procedure.
 *         if it xerror = fatl, an immediate
 *         return to the calling subroutine is enforced.
 *         decisions on errors are handled locally in each
 *         procedure.
 * 
 * *******************************************************
 * 
 */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*eject*/
/*
 * -----------------------------------
 *  asg_dev
 * 
 *  description:   assign devices (allocate memory and
 *                 open error output device)
 *                 initialize error limits
 *                   max 100 warnings
 *                        10 nonfatal errors
 *                         0 fatal errors 
 *                 record if error messages are
 *                 to be output on screen.
 *                 asg_dev or inz_prb must be first procedure
 * 
 *  input:         pname = "<name of error file>"
 *                         if empty string, use "execute.err"
 *                         error file name is not used if error
 *                         file has already been opened 
 *                 pvalue_(1) = 1 if output on screen
 *                            =-1 if no screen output
 *                 pvalue_(2) = colmax (must be >= 2)
 *                 pvalue_(3) = rowmax (must be >= 2)
 *                 pvalue_(4) = anzmax (must be >= 2)
 *                 pvalue_(5) = blkmax (must be >= 2)
 *                 pvalue_(6) = prbmax (must be >= 2)
 *                 pvalue_(7) = stomax (must be >= 2)
 * 
 *  output:        pname = "<name of error file>", whether
 *                         or not error file was opened in this
 *                         procedure
 *                 pvalue_(1) = 1 if output on screen
 *                            =-1 if no screen output
 *                 pvalue_(2) = colmax parameter
 *                 pvalue_(3) = rowmax parameter
 *                 pvalue_(4) = anzmax parameter
 *                 pvalue_(5) = blkmax parameter
 *                 pvalue_(6) = prbmax parameter
 *                 pvalue_(7) = stomax parameter
 *                 pvalue_(8) = amount of memory used for
 *                             arrays
 *                 ptype = "<Leibniz System Version>"
 *  
 *                 perror_(1) = 0 if operation successful, else
 *                              error indicated by error code.
 *
 *  entry conditions:
 *                 asg_dev or inz_prb must be first procedure
 *                 => solflg = -2
 * -----------------------------------
 */
void asg_dev(char *uname,char *ustate,char *utype,
               long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i;
/*
 */
  void calmem();
  void errmsg();
  void disprm();
  void exdyn_alloc();
  void pdatatoudata();
  void udatatopdata();
  void vrsion();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"assign_device");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  reset xerror, error counts, error limits, and access flag
 */
  xerror = 0;
  for (i=1;i<=fatl;i++) {
    execerr_(i) = 0;
  }
/*
 *  set limit on max number of warnings to 0
 *  set limit on max number of nonfatal errors to 0
 *  set limit on max number of fatal errors to 0
 */
  execerrmax_(1) = 0;
  execerrmax_(2) = 0;
  execerrmax_(3) = 0;
  accflg = 0;
/*
 *  scrflg is the flag for screen output
 */
  scrflg=pvalue_(1);
  if (scrflg!=1) {
    scrflg = 0;
  }
/*
 *  test solflg for correct value (= -2)
 */
  if (solflg==-2) {
/*  
 *  open error file unless it has already been opened
 */
    if (errfil==NULL) {
      if (pname_(1)=='\0') {
        strcpy(pname,"execute.err");
      }
      errfil = fopen(pname,"w");
      if (errfil == NULL) {
        printf("\n"
           "**********************************\n"
           "Cannot open error file %s\n"
           "**********************************\n",
           pname);
        xerror=fatl;
        goto zz1000;  
      }
      strcpy(errfil_name,pname);
    }
/*
 *  update uname
 */
    strcpy(uname,errfil_name); 
  } else {
/*
 *  asg_dev has already been executed
 */
    perror_(1) = nftl;
    errval = 1370;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  allocate memory as specified in pvalue
 */
  colmax = pvalue_(2);
  rowmax = pvalue_(3);
  anzmax = pvalue_(4);
  blkmax = pvalue_(5);
  prbmax = pvalue_(6);
  stomax = pvalue_(7);
/*
 *  laymax is = 7 for execute 
 *  must be same as for lbcc compiler
 */
  laymax = 7;
/*
 *  check parameters for min values
 */
  if (colmax<2) {
    perror_(1)=nftl;
    errval=1120;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (rowmax<2) {
    perror_(1)=nftl;
    errval=1130;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (anzmax<2) {
    perror_(1)=nftl;
    errval=1140;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (blkmax<2) {
    perror_(1)=nftl;
    errval=1150;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (prbmax<2) {
    perror_(1)=nftl;
    errval=1220;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (stomax<2) {
    perror_(1)=nftl;
    errval=1230;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }

  exdyn_alloc();
/*
 *  initialize storage index vector and pointers
 */
  for(irec=1; irec<=stomax-1; irec++)  {
    nxtrec_(irec)=irec+1;
  }
  nxtrec_(stomax)=0;
  fstrec=1;
  lstrec=stomax;
  nprbs=1;
  nfrrec=stomax;
/*
 *  reset solflg
 */
  solflg=-1;
/*
 *  store parameters
 */
  pvalue_(2)=colmax;
  pvalue_(3)=rowmax;
  pvalue_(4)=anzmax;
  pvalue_(5)=blkmax;
  pvalue_(6)=prbmax;
  pvalue_(7)=stomax;
/*
 *  compute total memory required (kbytes)
 */
  calmem();
  pvalue_(8)=totmem;
/*
 *  get leibniz system version
 */
  vrsion();
  strcpy(ptype ,lbzver);
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  beg_prb
 * 
 *  description:   load program for specified problem. 
 *                 this procedure must be executed prior 
 *                 to any other procedure except for asg_dev. 
 *                 the procedure may be used repeatedly to
 *                 load programs for various problems. 
 *                 whenever the program of a problem is loaded, 
 *                 the program of the prior problem is no 
 *                 longer available. However, one may use
 *                 sto_prb to save such prior programs.
 * 
 *  input:         pname = <full pathname of program file>
 * 
 *  output:        pname = "<problem name>"
 *                 pvalue_(1) = <number of variables>
 *                 pvalue_(2) = <number of logic clauses 
 *                               and goals>
 *                 ptype  = "SAT" if satisfiability problem
 *                        = "MIN" if minimization problem
 *                 if transfer process is used:
 *                   all user variables are initialized to -1
 *
 *                 perror_(1) = 0 if operation successful, else
 *                             error indicated by code.
 * 
 *  entry conditions:
 *                 asg_dev must have been executed => 
 *                 solflg >= -1.
 * -----------------------------------
 */
void beg_prb(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void errmsg();
  void disprm();
  void getprg();
  void pdatatoudata();
  void sts_prb();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"begin_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<-1) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  prgfil = fopen(pname,"r");
  if (prgfil == NULL) {
/*
 *  error: cannot open file
 */
    perror_(1)=nftl;
    errval=1020;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000; 
  }
/*
 *  load problem from disk
 */
  stoflg=-1;
  lprb=1;
  getprg();
  fclose(prgfil);
/*
 */
  if (succss==0) {
/*
 *  problem was not loaded
 */
    perror_(1)=warn;
    errval=0010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (succss<0) {
/*
 *  check for compatible leibniz versions
 */
    if (succss==-9999) {
      perror_(1)=fatl;
      errval=2020;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
/*
 *  colmax, rowmax, anzmax, or blkmax are too small 
 *  compared with ncols,  nrows,  nanzs,  or nblks
 */
    succss=-succss;
    if ((succss/2)*2!=succss) {
/*
 *  colmax too small
 */
      errval=1120;
      errmsg();
      perror_(1)=nftl;
    }
    succss=succss/2;
    if ((succss/2)*2!=succss) {
/*
 *  roxmax too small
 */
      errval=1130;
      errmsg();
      perror_(1)=nftl;
    }
      succss=succss/2;
    if ((succss/2)*2!=succss) {
/*
 *  anzmax too small
 */
      errval=1140;
      errmsg();
      perror_(1)=nftl;
    }
    succss=succss/2;
    if ((succss/2)*2!=succss) {
/*
 *  blkmax too small
 */
      errval=1150;
      errmsg();
      perror_(1)=nftl;
    }
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  note: asgflg = 0 and solflg = 0 are part of .prg file, so
 *        need not specify here
 *  get problem status information
 */
  sts_prb(pname,pstate,ptype,pvalue,perror);
  if (perror_(1)!=zeroerr) {
    error("beg_prb","102");
  }
/*
 *  update uname
 */
  strcpy(uname,pname);
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  del prb
 * 
 *  description:  delete a stored problem.
 * 
 *  input:        pname     = "<name of problem to be deleted>"
 * 
 *  output:       pvalue_(2) = total number of problems after the
 *                            deletion (current problem and all
 *                            stored problems)
 *                pvalue_(3) = total number of records used for
 *                            storage of problems
 *                pvalue_(4) = total number of records still
 *                            available for storage of problems
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 *                at least two problems must be present
 *                => nprbs >= 2
 * -----------------------------------
 */
void del_prb(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long j;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"delete_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check if there is a stored problem
 */
  if (nprbs<=1) {
    perror_(1)=nftl;
    errval=1270;
/*
 *  there is no stored problem
 */
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  search for stored problem with name matching pname string
 */
  for(j=2; j<=nprbs; j++)  {
    if (strcmp(pname,&prbnam_(1,j))==0) {
/*
 *  have match. update pointers, counts, indices, and names
 */
    lprb=j;
      if (fstrec==0) {
        fstrec=prbbeg_(lprb);
      } else {
        nxtrec_(lstrec)=prbbeg_(lprb);
      }
      lstrec=prbend_(lprb);
      nfrrec=nfrrec+prbsiz_(lprb);
      if (lprb!=nprbs) {
/*
 *  shift last stored problem into position of the
 *  just deleted one
 */
        strcpy(&prbnam_(1,lprb),&prbnam_(1,nprbs));
        prbbeg_(lprb)=prbbeg_(nprbs);
        prbend_(lprb)=prbend_(nprbs);
        prbsiz_(lprb)=prbsiz_(nprbs);
      }
        nprbs=nprbs-1;
/*
 *  get storage statistics
 */
      pvalue_(2)=nprbs;
      pvalue_(3)=stomax-nfrrec;
      pvalue_(4)=nfrrec;
       goto zz1000;
    }
  }
/*
 *  unknown problem name
 */
  perror_(1)=nftl;
  errval=1250;
  errmsg();
  disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  exe_lbcc
 * 
 *  description:   read parameter file deccparams.dat
 *                 and execute the lbcc compiler
 * 
 *  input:         pname = "<directory of deccparams.dat>"
 *                         if = empty string, current directory
 *                         is used; else, directory name must 
 *                         terminate with "/" (Unix) or "\\" 
 *                         (MS Windows)
 *                 if transfer process is used:
 *                   all user variables are initialized to -1
 * 
 *  output:        compiled program in layer 1
 *                 if specified in parameter file:
 *                   prg file of generated program
 * 
 *  entry conditions:
 *                 asg_dev must have been executed => 
 *                 solflg >= -1.
 * -----------------------------------
 */
void exe_lbcc(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void errmsg();
  void disprm();
  void getparm();
  void lbcc();
  void pdatatoudata();
  void sts_prb();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"execute_lbcc");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<-1) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  read parameter file deccparams.dat using
 *  directory specified in pname
 *  note that parameters 
 *        colmax
 *        rowmax
 *        anzmax
 *        blkmax
 *        prbmax
 *        stomax
 *        laymax
 *  of the file are ignored since memory allocation
 *  has already been done
 */
  getparm(pname);
/*
 *  compile problem
 */
  lbcc();
/*
 *  note: asgflg = 0 and solflg = 0 are part of .prg file, so
 *        need not specify here
 *  get problem status information
 */
  sts_prb(pname,pstate,ptype,pvalue,perror);
  if (perror_(1)!=zeroerr) {
    error("exe_lbcc","102");
  }
/*
 *  update uname
 */
  strcpy(uname ,pname);  
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  fre_dev
 * 
 *  description:  free devices (deallocate memory and
 *                close error output device)
 * 
 *  input:        none
 *  
 *  output:      perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *              - asg_dev must have been executed
 * -----------------------------------
 */
void fre_dev(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i;
/*
 */
  void errmsg();
  void disprm();
  void exdyn_free();
  void pdatatoudata();
  void trdyn_free();
  void udatatopdata();
/*
 *  set strings to null, value array to 0
 */
  uname_(1) = '\0';
  ustate_(1) = '\0';
  utype_(1) = '\0';
  for(i=1; i<=8; i++)  {
    uvalue_(i)=0;
  }
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"free_device");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  check solflg for correct value
 *  if solflg = -2, error: asg_dev or inz_prb has not yet
 *  been executed, and fre_dim must not be done
 */
  if (solflg==-2) {
/*
 *  asg_dev or inz_prb must be called prior to fre_dev
 */
    perror_(1)=nftl;
    errval=1380;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  reset flags
 */
  xerror = 0;
  scrflg = 1;
  solflg = -2;
/*
 *  close error file
 */
  fclose(errfil);
/*
 *  deallocate translation memory if it has been allocated
 */
  if (tralcflg==1) {
    trdyn_free();
  }
/*
 *  deallocate generation/execution memory
 */
  exdyn_free();
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  get_cgn
 * 
 *  description:  return clause name or goal name for specified
 *                index.  also return information related to
 *                clause or goal.
 * 
 *  input:        pvalue_(1) = <index>
 * 
 *  caution:      the index is an internal index and may not be
 *                utilized by the user in any other procedure
 *                except for get_dul.
 * 
 *  output:       ptype  = "<type of name>"
 *                       = "LOGC" if index correponds to a
 *                                   logic clause
 *                       = "GOAL" if index correponds to a
 *                                   goal
 *                       = "INTL" if index correponds to an
 *                                   internal clause 
 *                                   (not user accessible)
 * 
 *                if ptype = "LOGC":
 *                   pname  = "<name of logic clause>"
 *                   pstate = "A" if logic clause is active
 *                          = "D" if logic clause is deleted
 *                   pvalue_(2) = likelihood level of logic clause
 * 
 *                if ptype = "GOAL":
 *                   pname  = "<name of goal>"
 *                   pstate = "A" if goal is active
 *                          = "D" if goal is deleted
 * 
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *              - asg_dev and beg_prb must have been executed
 * -----------------------------------
 */
void get_cgn(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"get_clsname");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }

/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check index for correct range
 */
  if ((pvalue_(1)<0)||
    (pvalue_(1)>nrows)) {
    perror_(1)=nftl;
    errval=1210;
    errmsg();
/*
 *  index out of bounds
 */
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  save index and find internal index
 */
  i=pvalue_(1);
  iscan=idxrow_(i);
/*
 * make preliminary determination of clause type
 */
  if (glflg_(iscan)==1) {
    strcpy(ptype ,"GOAL");
  } else {
    strcpy(ptype ,"LOGC");
  }
/*
 *  determine name, and assign "INTL" as clause type if needed
 */
  pname_(1) = '\0';
  if ((rownam_(1,i) != '@') &&
    (rownam_(1,i) != '*')) {
    strcpy(pname,&rownam_(1,i));
  } else {
    strcpy(ptype,"INTL");
  }
/*
 *  update uname
 */
  strcpy(uname ,pname);
/*
 *  transfer status of clause into pstate
 */
  if (riina_(iscan)==2) {
    strcpy(pstate,"D");
  } else {
    strcpy(pstate,"A");
  }
/*
 *  transfer likelihood level into pvalue_(2)
 */
  pvalue_(2)=level_(iscan);
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
  }
/*eject*/
/*
 * -----------------------------------
 *  get_dim
 * 
 *  description:  get dimensions for 
 *                  colmax
 *                  rowmax
 *                  anzmax
 *                  blkmax
 *                  prbmax
 *                  stomax
 *                from specified prg files by repeated calls
 * 
 *  input:        name = "<prg file name>"
 *                pvalue_(1) = 0 so far, no prg file has been
 *                               processed
 *                           = k (k>0) k prg files have
 *                               been processed so far 
 *                           
 *  output:       pvalue_(1) incremented by 1
 *                pvalue_(2) = max of colmax values of the
 *                             prg files processed so far
 *                pvalue_(3) = max of rowmax values of the
 *                             prg files processed so far
 *                pvalue_(4) = max of anzmax values of the
 *                             prg files processed so far
 *                pvalue_(5) = max of blkmax values of the
 *                             prg files processed so far
 *                pvalue_(6) = prbmax for the prg files processed
 *                             so far (= pvalue_(1)+1)
 *                pvalue_(7) = stomax for the prg files processed
 *                             so far (= sum of individual stomax
 *                             values of the prg files) 
 * 
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 * -----------------------------------
 */
void get_dim(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i, num;
  static char buf[256], field[100];
  FILE *fp;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"get_dimension");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  open prg file
 */
  fp = fopen(pname, "r");
  if (fp == NULL) {
    perror_(1)=nftl;
    errval=1020;
    errmsg();
/*
 *  cannot open program file
 */
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  if this is first prg file, initialize pvalue_(2)..pvalue_(6)
 */
  if (pvalue_(1)==0) {
    for (i=2;i<=7;i++) {
      pvalue_(i) = 0;
    }
    pvalue_(6) = 1;
  }
/*
 *  read file and extract parameters
 */
  pvalue_(1)++;
  pvalue_(6)++;
  while(fgets(buf,80,fp) != NULL) {
    sscanf(buf, "%s%ld", field, &num);
    if (strcmp("COLMAX", field) == 0) { 
      if (num > pvalue_(2)) {
        pvalue_(2) = num;
      }
    } else if (strcmp("ROWMAX", field) == 0) { 
      if (num > pvalue_(3)) {
        pvalue_(3) = num;
      }
    } else if (strcmp("ANZMAX", field) == 0) { 
      if (num > pvalue_(4)) {
        pvalue_(4) = num;
      }
    } else if (strcmp("BLKMAX", field) == 0) { 
      if (num > pvalue_(5)) {
        pvalue_(5) = num;
      }
    } else if (strcmp("STOSIZ", field) == 0) {
      pvalue_(7) += num;
      fclose(fp);
      goto zz1000;
    }
  }
/*
 *  prg file without parameter records
 */
  fclose(fp);
  perror_(1)=nftl;
  errval=1430;
  errmsg();
  disprm(ucomnd,uname,ustate,utype,uvalue,perror);
  goto zz1000;
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
  }
/*eject*/
/*
 * -----------------------------------
 *  get_dul
 * 
 *  description:  return dual value for clause or goal 
 *                with specified index.  
 *                also return information related to 
 *                clause or goal.
 * 
 *  input:        pvalue_(1) = <index>
 * 
 *  caution:      the index is an internal index, and may not be
 *                utilized by the user in any other procedure
 *                except for get_cgn.
 * 
 *  output:       ptype  = "<type of name>"
 *                       = "LOGC" if index correponds to a
 *                                   logic clause
 *                       = "GOAL" if index correponds to a
 *                                   goal
 *                       = "INTL" if index correponds to an
 *                                   internal clause (not user
 *                                   accessible)
 * 
 *                if ptype = "LOGC":
 *                   pname  = "<name of logic clause>"
 *                   pstate = "A" if logic clause is active
 *                          = "D" if logic clause is deleted
 *                   pvalue_(2) = likelihood level of logic clause
 * 
 *                if ptype = "GOAL":
 *                   pname  = "<name of goal>"
 *                   pstate = "A" if goal is active
 *                          = "D" if goal is deleted
 * 
 *                in all cases:
 *                     pvalue_(3) = lp dual value 
 *                                  (rounded to integer)
 * 
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *              - asg_dev and beg_prb must have been executed, and
 *                the problem must have been solved => solflg > 0.
 *              - the problem must be satisfiable => satble > 0.
 *              - problem must have been solved by approx. min.
 * -----------------------------------
 */
void get_dul(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"get_dual");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<=0) {
/*
 *  problem not solved
 */
    perror_(1)=nftl;
    errval=1050;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (satble==0) {
    perror_(1)=warn;
    errval=0060;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 *  problem not satisfiable
 */
    goto zz1000;
  }
  if (apmflg==0) {
/*
 *  problem not solved by approximate minimization
 */
    perror_(1)=nftl;
    errval=1070;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check index for correct range
 */
  if ((pvalue_(1)<0)||
    (pvalue_(1)>nrows)) {
    perror_(1)=nftl;
    errval=1210;
    errmsg();
/*
 *  index out of bounds
 */
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  save index and find internal index
 */
  i=pvalue_(1);
  iscan=idxrow_(i);
/*
 * make preliminary determination of clause type
 */
  if (glflg_(iscan)==1) {
    strcpy(ptype ,"GOAL");
  } else {
    strcpy(ptype ,"LOGC");
  }
/*
 *  determine name, and assign "INTL" as clause type if needed
 */
  pname_(1) = '\0';
  if ((rownam_(1,i) != '@') &&
    (rownam_(1,i) != '*')) {
    strcpy(pname,&rownam_(1,i));
  } else {
    strcpy(ptype,"INTL");
  }
/*
 *  update uname
 */
  strcpy(uname ,pname);
/*
 *  transfer status of clause into pstate
 */
  if (riina_(iscan)==2) {
    strcpy(pstate,"D");
  } else {
    strcpy(pstate,"A");
  }
/*
 *  transfer likelihood level into pvalue_(2)
 */
  pvalue_(2)=level_(iscan);
/*
 *  transfer lp dual value
 */
  pvalue_(3)=dual_(iscan);
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  get_gol
 * 
 *  description:  return for specified goal name:
 *                goal quantity, cost of low usage, cost of high
 *                usage, indicator whether problem has been 
 *                solved, and, if solved, goal usage.
 * 
 *  input:        pname     = <goal name>
 * 
 *  output:       pstate = "A" if goal is active.
 *                       = "D" if goal is deleted.
 *                pvalue_(1) = goal quantity (external)
 *                pvalue_(2) = unit cost of low usage
 *                pvalue_(3) = unit cost of high usage
 *                pvalue_(4) = solution indicator (approx. min.)
 *                          = 1 if problem solved and satisfiable
 *                          = 0 else
 * 
 *                if pvalue_(4) = 1: (problem solved and 
 *                                    satisfiable)
 *                  pvalue_(5) = goal usage (external)
 * 
 *                perror_(1) = 0 if operation successful, else
 *                               error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 * -----------------------------------
 */
void get_gol(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"get_goal");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check if approximate minimization is used
 */
  if (apmflg==0) {
/*
 *  procedure requires approximate minimization
 */
    perror_(1)=nftl;
    errval=1330;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  process each row
 */
  for(i=1; i<=nrows; i++)  {
/*
 *  find internal index
 */
    iscan=idxrow_(i);
/*
 *  check if this is a goal and matches name
 */
    if ((glflg_(iscan)==1)&&
      (strcmp(pname,&rownam_(1,i))==0)) {
/*
 *  have a match
 *  get state of row
 */
      if (riina_(iscan)==2) {
        strcpy(pstate,"D");
      } else {
        strcpy(pstate,"A");
      }
/*
 *  get external goal quantity 
 *      low cost of usage
 *      high cost of usage
 */
      pvalue_(1)=goalxq_(iscan);
      pvalue_(2)=glocst_(iscan);
      pvalue_(3)=ghicst_(iscan);
/*
 *  get solution flag and usage
 */
      if ((solflg==1)&&
          (satble==1)) {
        pvalue_(4)=1;
        pvalue_(5)=goalus_(iscan);
      } else {
        pvalue_(4)=0;
        pvalue_(5)=0;
      }
/*
 *  done
 */
      goto zz1000;
    }
  }
/*
 *  no matching clause
 */
  perror_(1)=nftl;
  errval=1280;
  errmsg();
  disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  get_pml
 * 
 *  description:  return classification for specified variable
 *                during most recent execution of first lp
 *                (phase = 1) in apmsol, before reductions.
 *                problem must have been solved and must be
 *                satisfiable.
 *                information may be requested in one of two ways:
 *                (1) by specifying the variable name;
 *                (2) by specifying the index of the variable. the
 *                    index must lie between 1 and 
 *                    the total number of variables. 
 *                    this feature allows looping.
 * 
 *  input:        either:
 *                  pname = <name of variable>
 *                  pvalue_(1) = 0
 *                or:
 *                  pvalue_(1) = <index of variable>
 * 
 *  output:       pstate = "B" if variable value in lp is
 *                             in-between true and false
 *                         "T" if variable was fixed to true, or
 *                             was set to true in lp
 *                         "F" if variable was fixed to false, or
 *                             was set to false in lp
 *                         "D" if variable was deleted
 *                if pvalue_(1) > 0:
 *                  pname = <name of variable indexed by 
 *                           pvalue_(1)>
 *                  pvalue_(3) = true cost
 *                  pvalue_(4) = false cost
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *              - asg_dev and beg_prb must have been executed, and
 *                the problem must have been solved => solflg > 0.
 *              - the problem must be satisfiable => satble > 0.
 *              - problem must have been solved by approx. min.
 * -----------------------------------
 */
  void get_pml(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void errmsg();
  void disprm();
  void fcindx();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"get_primal");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<=0) {
    perror_(1)=warn;
    errval=0050;
    errmsg();
/*
 *  problem not solved
 */
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (satble==0) {
    perror_(1)=warn;
    errval=0060;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 *  problem not satisfiable
 */
    goto zz1000;
  }
  if (apmflg==0) {
    perror_(1)=warn;
    errval=0070;
    errmsg();
/*
 *  problem not solved by approximate minimization
 */
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  if index given, return variable name and related information
 */
  if ((pvalue_(1)<0)||(pvalue_(1)>ncolsx)) {
    perror_(1)=nftl;
    errval=1040;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 *  index for variable out of bounds
 */
    goto zz1000;
  }
  if (pvalue_(1)!=0) {
/*
 *  transfer variable name into pname and uname
 */
    jnam=idxclx_(pvalue_(1));
    jscan=idxcol_(jnam);
    strcpy(pname,&colnam_(1,jnam));
    strcpy(uname,&colnam_(1,jnam));
  } else {
/*
 *  find indices jnam (name level) and jscan (internal)
 *  of given variable name
 */
    fcindx(pname,perror);
    if (perror_(1)!=zeroerr) {
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
  if (primal_(jscan)==3) {
    strcpy(pstate,"B");
  } else if (primal_(jscan)==2) {
    strcpy(pstate,"D");
  } else if ((primal_(jscan)*scale_(jscan))==1) {
    strcpy(pstate,"T");
  } else {
    strcpy(pstate,"F");
  }
/*
 *  store cost information in pvalue
 */
  pvalue_(3)=trucst_(jnam);
  pvalue_(4)=falcst_(jnam);
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;  
}
/*eject*/
/*
 * -----------------------------------
 *  get_val
 * 
 *  description:  return solution value for specified variable,
 *                and true/false cost in optimization case.
 *                problem must have been solved and must be
 *                satisfiable.
 *                information may be requested in one of two ways:
 *                (1) by specifying the variable name;
 *                (2) by specifying the index of the variable. the
 *                    index must lie between 1 and the total 
 *                    number of variables. 
 *                    this feature allows looping.
 * 
 *  input:        either:
 *                  pname = <name of variable>
 *                  pvalue_(1) = 0
 *                or:
 *                  pvalue_(1) = <index of variable>
 * 
 *  output:       pstate = "T" if variable is true
 *                         "F" if variable is false
 *                         "D" if variable is deleted
 *                if pvalue_(1) > 0:
 *                  pname = <name of variable indexed 
 *                           by pvalue_(1)>
 *                if optimization:
 *                  pvalue_(3) = true cost
 *                  pvalue_(4) = false cost
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *              - asg_dev and beg_prb must have been executed, and
 *                the problem must have been solved => solflg > 0.
 *              - the problem must be satisfiable => satble > 0.
 *
 *  caution:      get_val cannot be used with transfer process
 * -----------------------------------
 */
void get_val(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void errmsg();
  void disprm();
  void fcindx();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"get_value");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 */
  if (trsprocessflg==1) {
/*
 *  get_val cannot be used with transfer process
 */
    perror_(1)=nftl;
    errval=1390;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  test for entry conditions
 */
  if (solflg<=0) {
    perror_(1)=warn;
    errval=0050;
    errmsg();
/*
 *  problem not solved
 */
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (satble==0) {
    perror_(1)=warn;
    errval=0060;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 *  problem not satisfiable
 */
    goto zz1000;
  }
/*
 *  if index given, return variable name and related information
 */
  if ((pvalue_(1)<0)||(pvalue_(1)>ncolsx)) {
    perror_(1)=nftl;
    errval=1040;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 *  index for variable out of bounds
 */
    goto zz1000;
  }
  if (pvalue_(1)!=0) {
/*
 *  transfer variable name into pname and uname
 */
    jnam=idxclx_(pvalue_(1));
    jscan=idxcol_(jnam);
    strcpy(pname,&colnam_(1,jnam));
    strcpy(uname,&colnam_(1,jnam));
  } else {
/*
 *  find indices jnam (name level) and jscan (internal)
 *  of given variable name
 */
    fcindx(pname,perror);
    if (perror_(1)!=zeroerr) {
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
  if (ciact_(jscan)!=0) {
    if (solut1_(jscan)*scale_(jscan)==1) {
      strcpy(pstate,"T");
    } else {
      strcpy(pstate,"F");
    }
  } else {
    if (ciina_(jscan)==2) {
      strcpy(pstate,"D");
    } else if (ciina_(jscan)*scale_(jscan)==1) {
      strcpy(pstate,"T");
    } else {
      strcpy(pstate,"F");
    }
  }
/*
 *  store cost information in pvalue
 */
  pvalue_(3)=trucst_(jnam);
  pvalue_(4)=falcst_(jnam);
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  inz_prb
 * 
 *  description:   open error file
 *                 read specified prg files, compute parameters
 *                   colmax
 *                   rowmax
 *                   anzmax
 *                   blkmax
 *                   prbmax
 *                   stomax
 *                 (get_dim) 
 *                 assign devices (asg_dev)
 *                 load programs of specified prg files into 
 *                 memory (beg_prb)
 *                 asg_dev or inz_prb must be first procedure
 * 
 *  input:         prgname[]:  each record = name of a prg file
 *                             last record is empty string
 *                 pname = "<name of error file>"
 *                         if empty string, use "execute.err"
 *                         error file name is not used if error
 *                         file has already been opened
 *                 pvalue_(1) = 1 if output on screen
 *                            =-1 if no screen output
 *
 *  output:        for last problem in list prgname, same output
 *                 as produced by sts_prb:
 *                 pname = "<problem name>"
 *                 pvalue_(1) = number of variables
 *                 pvalue_(2) = number of logic clauses and goals
 *                 if transfer process is used:
 *                   pstate = ""
 *                 if transfer process is not used:
 *                   pstate = "N"
 *                 ptype  = "SAT" if satisfiability problem
 *                        = "MIN" if minimization problem
 *                 pvalue_(5) = number of goals       
 * 
 *                 perror_(1) = 0 if operation successful, else
 *                              error indicated by error code.
 *
 *  entry conditions:
 *                 asg_dev or inz_prb must be first procedure
 *                 => solflg = -2
 * -----------------------------------
 */
void inz_prb(PRGNAME_ARRAY *prgname,
             char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i, num;
/*
 */
  void asg_dev();
  void beg_prb();
  void errmsg();
  void disprm();
  void pdatatoudata();
  void sts_prb();
  void sto_prb();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"initialize_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  reset xerror, error counts, error limits, and access flag
 */
  xerror = 0;
  for (i=1;i<=fatl;i++) {
    execerr_(i) = 0;
  }
/*
 *  set limit on max number of warnings to 0
 *  set limit on max number of nonfatal errors to 0
 *  set limit on max number of fatal errors to 0
 */
  execerrmax_(1) = 0;
  execerrmax_(2) = 0;
  execerrmax_(3) = 0;
  accflg = 0;
/*
 *  scrflg is the flag for screen output
 */
  scrflg=pvalue_(1);
  if (scrflg!=1) {
    scrflg = 0;
  }
/*
 *  test solflg for correct value (= -2)
 */
  if (solflg==-2) {
/*  
 *  open error file unless it has already been opened
 */
    if (errfil==NULL) {
      if (pname_(1)=='\0') {
        strcpy(pname,"execute.err");
      }
      errfil = fopen(pname,"w");
      if (errfil == NULL) {
        printf("\n"
           "**********************************\n"
           "Cannot open error file %s\n"
           "**********************************\n",
           pname);
        xerror=fatl;
        goto zz1000;  
      }
      strcpy(errfil_name,pname);
    }
/*
 *  update uname
 */
    strcpy(uname,errfil_name);
  } else {
/*
 *  asg_dev or inz_prb has already been executed
 */
    perror_(1) = nftl;
    errval = 1370;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  get parameter values from prg files 
 *  in prgname array with get_dim
 */
  i = 1;
  pvalue_(1) = 0;
  while (strcmp(prgname_(i), "") != 0) {
    strcpy(pname, prgname_(i));
    get_dim(pname, pstate, ptype, pvalue, perror);
    if (perror_(1)>=nftl) {
      goto zz1000;
    }
    i++;
  }
  num = i-1;
/*
 *  allocate devices with asg_dev
 *  that procedure ignores pname since error file
 *  has already been opened
 *  nevertheless, set pname = empty string as safety
 *  precaution
 *  asg_dev assigns solflg = -1
 */
  pname_(1) = '\0';
  pvalue_(1) = scrflg;
  asg_dev(pname, pstate, ptype, pvalue, perror);
  if (perror_(1)>=nftl) {
    goto zz1000;
  }
/*
 *  load and store programs with beg_prb and sto_prb
 */
  for (i = 1; i<=num; i++) {
    strcpy(pname, prgname_(i));
    beg_prb(pname, pstate, ptype, pvalue, perror);
    if (perror_(1)>=nftl) {
      goto zz1000;
    }
    strcpy(pname, "");
    sto_prb(pname, pstate, ptype, pvalue, perror);
    if (perror_(1)>=nftl) {
      goto zz1000;
    }
  }
/*
 *  get status of problem loaded last
 */
  sts_prb(pname, pstate, ptype, pvalue, perror);
  if (perror_(1)>=nftl) {
    goto zz1000;
  }
/*
 *  update uname
 */
  strcpy(uname,pname);
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
  }
/*eject*/
/*
 * -----------------------------------
 *  lim_err
 * 
 *  description:  defines limits for number of warnings,
 *                nonfatal errors, and fatal errors.
 *                when limit is exceedd, procedure 
 *                leibnizerroraction() is executed, where
 *                user has defined subsequent action.
 * 
 *  input:        limit value for
 *                value_(1)   warnings
 *                value_(2)   nonfatal errors
 *                value_(3)   fatal errors
 * 
 *  entry conditions: none
 *              
 * -----------------------------------
 */
void lim_err(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"limit_error");
/*
 */
  for (i=1;i<=fatl;i++) {
    if (pvalue_(i)<0) { 
/*
 *  limit on warnings/errors is negative
 */
      perror_(1)=nftl;
      errval=1400;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000; 
    }
  }
/*
 *  assign limits to execerrmax array
 */
  for (i=1;i<=fatl;i++) {
    execerrmax_(i) = pvalue_(i);
  }
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  mxcls_sat
 * 
 *  description:  find maximal set of specified clauses for 
 *                which problem is satisfiable
 * 
 *  input:        initial set of clauses that are candidates
 *                for deletion must be specified in array
 *                clauses[]. The last record in clauses[]
 *                must be the empty string.
 *
 *  output:       the status field in clauses[] corresponding
 *                to each clause is set as follows:
 *                 0   if clause has been deleted
 *                 1   if clause is retained in the maximum set
 *                -1   if there is no clause with 
 *                       name = clauses[].name
 *               state  = "U"  system is still unsatisfiable 
 *                             when all specified clauses are 
 *                             deleted
 *                      = "S"  system is satisfiable when all 
 *                             specified clauses are deleted
 *
 *                perror_(1) = 0 if operation successful, else
 *                               error indicated by error code
 *
 *  caution:      likelihood levels are ignored
 *
 *                the procedure changes the state of clauses 
 *                with name in array clauses[] from active to 
 *                deleted and conversely
 * 
 *                upon termination, the state of each such clause 
 *                is consistent with that specified by the status 
 *                field of clauses[] (see above)
 * 
 *                in some applications, one would like to reset 
 *                the state of all clauses after mxcls_sat
 *                to the state existing prior to mxcls_sat.
 *                one achieves that effect by storing the
 *                problem prior to the call of mxcls_sat 
 *                using sto_prb, and retrieving the problem
 *                after mxcls_sat using ret_prb
 *
 *                assumes that all desired problem modifications 
 *                (fixing or deletion of variables, deletion of 
 *                clauses, etc. have already been done    
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been executed =>
 *                solflg >= 0.
 *              
 * -----------------------------------
 */
void mxcls_sat(CLAUSE_ARRAY *clauses,
                 char *uname,char *ustate,char *utype,
                 long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i, flg;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void mst_cls();
  void mst_prb();
  void sol_prb();
  void sts_prb();  
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"maxcls_sat");
/*
 *  if minsat problem, change to sat
 */
  sts_prb(pname, pstate, ptype, pvalue, perror);
  if (perror_(1)>=nftl) {
    goto zz1000;
  }
  if (strcmp(ptype, "MIN") == 0) {
    flg = 1;
    strcpy(ptype, "SAT");
    mst_prb(pname, pstate, ptype, pvalue, perror);
    if (perror_(1)>=nftl) {
      goto zz1000;
    }
  } else {
    flg = 0;
  }
/* 
 *  delete all clauses
 */
  i = 0;
  while (strcmp(clauses[i].name,"")!=0) {
    strcpy(pname, clauses[i].name);
    pvalue_(1) = 0;
    pvalue_(2) = 100;
    strcpy(pstate, "D");
    mst_cls(pname, pstate, ptype, pvalue, perror);    
    if (perror_(1)==0) {
/*
 *  clause name occurs in problem
 */
      clauses[i].status = 0;
    } else {
      clauses[i].status = -1;
    }
    i++;
  }
/* 
 *  check satisfiability
 */
  sol_prb(pname, pstate, ptype, pvalue, perror);
  if (perror_(1)>=nftl) {
    goto zz1000;
  }
  if (strcmp(pstate,"U")==0) {
/*
 *  problem is unsatisfiable when all specified clauses
 *  are deleted 
 *  if needed, undo minsat to sat change
 *  return
 */
    if (flg == 1) {
      strcpy(ptype ,"MIN");
      mst_prb(pname, pstate, ptype, pvalue, perror);
      if (perror_(1)>=nftl) {
       goto zz1000;
      } 
    } 
    strcpy(pstate,"U");
    goto zz1000;;
  }
/*
 *  problem is satisfiable when all specified clauses
 *  are deleted
 *  find maximal set of clauses
 */
  i = 0;
  while (strcmp(clauses[i].name, "")) {
    if (clauses[i].status == 0) {
/*
 *  activate clause and check satisfiability
 */
      strcpy(pname, clauses[i].name);
      pvalue_(1) = 0;
      pvalue_(2) = 100;
      strcpy(pstate, "A");
      mst_cls(pname, pstate, ptype, pvalue, perror);
      if (perror_(1)>=nftl) {
        goto zz1000;
      }
      clauses[i].status = 1;
      sol_prb(pname, pstate, ptype, pvalue, perror);
      if (perror_(1)>=nftl) {
        goto zz1000;
      }
      if (strcmp(pstate,"U")==0) {
/*
 *  problem has become unsatisfiable
 *  delete clause again
 */
        strcpy(pname, clauses[i].name);
        pvalue_(1) = 0;
        pvalue_(2) = 100;
        strcpy(pstate, "D");
        mst_cls(pname, pstate, ptype, pvalue, perror);
        if (perror_(1)>=nftl) {
          goto zz1000;
        }
        clauses[i].status = 0;
      }
    }
    i++;
  };
/* 
 *  undo minsat to sat change if needed
 */
  if (flg == 1) {
    strcpy(ptype ,"MIN");
    mst_prb(pname, pstate, ptype, pvalue, perror); 
  }
  if (perror_(1)>=nftl) {
    goto zz1000;
  }  
  strcpy(pstate,"S");    
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  mncls_unsat
 * 
 *  description:  find minimal set of specified clauses for 
 *                which problem is unsatisfiable
 * 
 *  input:        initial set of clauses that are candidates
 *                for deletion must be specified in array
 *                clauses[]. The last record in clauses[]
 *                must be the empty string.
 *
 *  output:       the status field in clauses[] corresponding
 *                to each clause is set as follows:
 *                 0   if clause has been deleted
 *                 1   if clause is retained in the minimal set
 *                -1   if there is no clause with 
 *                       name = clauses[].name
 *               state  = "U"  system is unsatisfiable 
 *                             when all specified clauses are 
 *                             activated
 *                      = "S"  system is satisfiable when all 
 *                             specified clauses are activated
 *
 *                perror_(1) = 0 if operation successful, else
 *                               error indicated by error code
 *
 *  caution:      likelihood levels are ignored
 *
 *                the procedure changes the state of clauses 
 *                with name in array clauses[] from active to 
 *                deleted and conversely
 * 
 *                upon termination, the state of each such clause 
 *                is consistent with that specified by the status 
 *                field of clauses[] (see above)
 * 
 *                in some applications, one would like to reset 
 *                the state of all clauses after mncls_unsat
 *                to the state existing prior to mncls_unsat.
 *                one achieves that effect by storing the
 *                problem prior to the call of mncls_unsat 
 *                using sto_prb, and retrieving the problem
 *                after mncls_unsat using ret_prb
 *
 *                assumes that all desired problem modifications 
 *                (fixing or deletion of variables, deletion of 
 *                clauses, etc. have already been done  
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been executed =>
 *                solflg >= 0.
 *              
 * -----------------------------------
 */
void mncls_unsat(CLAUSE_ARRAY *clauses,
                 char *uname,char *ustate,char *utype,
                 long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i, flg;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void mst_cls();
  void mst_prb();
  void sol_prb();
  void sts_prb();  
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"mincls_unsat");
/*
 *  if minsat problem, change to sat
 */
  sts_prb(pname, pstate, ptype, pvalue, perror);
  if (perror_(1)>=nftl) {
    goto zz1000;
  }
  if (strcmp(ptype, "MIN") == 0) {
    flg = 1;
    strcpy(ptype, "SAT");
    mst_prb(pname, pstate, ptype, pvalue, perror);
    if (perror_(1)>=nftl) {
      goto zz1000;
    }
  } else {
    flg = 0;
  }
/* 
 *  activate all clauses
 */
  i = 0;
  while (strcmp(clauses[i].name,"")!=0) {
    strcpy(pname, clauses[i].name);
    pvalue_(1) = 0;
    pvalue_(2) = 100;
    strcpy(pstate, "A");
    mst_cls(pname, pstate, ptype, pvalue, perror);    
    if (perror_(1)==0) {
/*
 *  clause name occurs in problem
 */
      clauses[i].status = 1;
    } else {
      clauses[i].status = -1;
    }
    i++;
  }
/* 
 *  check unsatisfiability
 */
  sol_prb(pname, pstate, ptype, pvalue, perror);
  if (perror_(1)>=nftl) {
    goto zz1000;
  }
  if (strcmp(pstate,"S")==0) {
/*
 *  problem is satisfiable when all specified clauses
 *  are activated 
 *  if needed, undo minsat to sat change
 *  return
 */
    if (flg == 1) {
      strcpy(ptype ,"MIN");
      mst_prb(pname, pstate, ptype, pvalue, perror);
      if (perror_(1)>=nftl) {
       goto zz1000;
      } 
    } 
    strcpy(pstate,"S");
    goto zz1000;;
  }
/*
 *  problem is unsatisfiable when all specified clauses
 *  are activated
 *  find minimal set of clauses
 */
  i = 0;
  while (strcmp(clauses[i].name, "")) {
    if (clauses[i].status == 1) {
/*
 *  delete clause and check satisfiability
 */
      strcpy(pname, clauses[i].name);
      pvalue_(1) = 0;
      pvalue_(2) = 100;
      strcpy(pstate, "D");
      mst_cls(pname, pstate, ptype, pvalue, perror);
      if (perror_(1)>=nftl) {
        goto zz1000;
      }
      clauses[i].status = 0;
      sol_prb(pname, pstate, ptype, pvalue, perror);
      if (perror_(1)>=nftl) {
        goto zz1000;
      }
      if (strcmp(pstate,"S")==0) {
/*
 *  problem has become satisfiable
 *  activate clause again
 */
        strcpy(pname, clauses[i].name);
        pvalue_(1) = 0;
        pvalue_(2) = 100;
        strcpy(pstate, "A");
        mst_cls(pname, pstate, ptype, pvalue, perror);
        if (perror_(1)>=nftl) {
          goto zz1000;
        }
        clauses[i].status = 1;
      }
    }
    i++;
  };
/* 
 *  undo minsat to sat change if needed
 */
  if (flg == 1) {
    strcpy(ptype ,"MIN");
    mst_prb(pname, pstate, ptype, pvalue, perror); 
  }
  if (perror_(1)>=nftl) {
    goto zz1000;
  }  
  strcpy(pstate,"U");    
/*
 *  done
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  mst_allvar
 * 
 *  description:  modify the state of all user variables
 *  
 *  input:        pstate = "T" - fix all variables to true
 *                       = "F" - fix all variables to false
 *                       = "D" - delete all variables
 *                       = "A" - activate all variables
 *                       = "I" - keep current values of variables 
 *                               as initial solution for 
 *                               approx. min.
 *                       = "R" - remove any existing initial 
 *                               solution values for approx. min.
 *
 *  output:       perror_(1) = 0 if operation successful, else
 *                               error indicated by error code
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 *
 *  The case of pstate = "R", where any existing initial solution
 *  for approx. min. is removed, is equivalent to restoring the
 *  problem using restore_problem with pstate = "I".
 *
 *  caution:      requires transfer process
 *                
 * ------------------------------------------------------------
 */
void mst_allvar(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long j,k;
/*
 */
  void errmsg();
  void disprm();
  void leibniztransfer();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"modify_allvar");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  test state parameter
 */
  if ((strcmp(pstate,"T")!=0)&&
      (strcmp(pstate,"F")!=0)&&
      (strcmp(pstate,"D")!=0)&&
      (strcmp(pstate,"A")!=0)&&
      (strcmp(pstate,"I")!=0)&&
      (strcmp(pstate,"R")!=0)) {
/*
 *  unknown variable state
 */
    perror_(1)=nftl;
    errval=1030;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  test that transfer process is used
 */
  if (trsprocessflg==0) {
/*
 *  transfer process is required but is not used
 */
    perror_(1)=nftl;
    errval=1420;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 */
  if ((strcmp(pstate,"T")==0)||
      (strcmp(pstate,"F")==0)||
      (strcmp(pstate,"D")==0)||
      (strcmp(pstate,"A")==0)) {
/*
 *  compute value corresponding to string in pstate
 */
    if (strcmp(pstate,"T")==0) {
      k = 3;
    } else if (strcmp(pstate,"F")==0) {
      k = -3;
    } else if (strcmp(pstate,"D")==0) {
      k = 0;
    } else if (strcmp(pstate,"A")==0) {
      k = -1;
    } else {
      error("mst_allvar","202");
    }
/*
 *  assign k value to all variables
 *  colmax is used as upper bound on the index since
 *  all values are to be reset, regardless which
 *  problem resides currently in layer 1
 */
    for (j=1;j<=colmax;j++) {
      trsvar_(j) = k;
    }
    leibniztransfer("trsvartouser",prbnam, trsvar,&errval,
                      ucomnd,uname,pstate,ptype,pvalue,perror);
    goto zz1000;
  }
/*
 */
  if (strcmp(pstate,"I")==0) { 
/*
 *  use user values to define initial solution 
 *  for approx. min.
 *
 *  zero out initial solution array
 */
    for (jscan=1;jscan<=ncols;jscan++) {
      inlsol_(jscan) = 0;
    }
/*
 *  get user values
 */
    leibniztransfer("usertotrsvar",prbnam, trsvar,&errval,
                      ucomnd,uname,pstate,ptype,pvalue,perror);
/*
 *  assign user values in trsvar to initial solution array
 */
    for(jnam=1; jnam<=ncols; jnam++)  {
/*
 *  skip variable if its name begins with '*'
 *  since such variable is not user accessible
 */
      if (colnam_(1,jnam)!='*') {
        jscan = idxcol_(jnam);
/*
 *  jnam is name index
 *  jscan is inside index
 */
        if (trsvar_(jscan)!=0) {
          if (((trsvar_(jnam)>0)&&
               (scale_(jscan)==1))||
              ((trsvar_(jnam)<0)&&
               (scale_(jscan)==-1))) {
            inlsol_(jscan)=1;
          } else {
            inlsol_(jscan)=-1;
          }
        } else {
          inlsol_(jscan)=0;
        }
      }    
    }
    goto zz1000;
  }
/*
 */
  if (strcmp(pstate,"R")==0) {
/*
 * remove initial solution
 */
    for (jscan=1;jscan<=ncols;jscan++) {
      inlsol_(jscan) = 0;
    }
    goto zz1000;
  } 
/*
 *  error, must have one of the above cases
 */
  error("mst_allvar","402");
/*
 */
  zz1000:; 
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  mst_cls
 * 
 *  description:  change the state of all clauses matching
 *                the given name (possibly with the wildcard
 *                character '?') in pname and with likelihood
 *                level falling within a specified interval given
 *                by pvalue_(1) and pvalue_(2).
 *                do not consider goals, just examine logic 
 *                clauses.
 * 
 *  input:        pname = <clause name (wildcard ? allowed)>
 *                pstate = "D" - delete all matches
 *                       = "A" - activate all matches
 *                       = "L" - change likelihood level 
 *                               of all matches
 *                pvalue_(1) = <lowest likelihood level
 *                             to be considered>
 *                pvalue_(2) = <highest likelihood level
 *                0 <= pvalue_(1) <= pvalue_(2) <= 100
 *                if pstate = "L":
 *                  pvalue_(5) = <new likelihood level>
 *                  requires 1 <= pvalue_(1) and 
 *                           1 <= pvalue_(5) <= 100
 * 
 *  output:       pvalue_(3) = <no. of clause names 
 *                              matching criteria>
 *                pvalue_(4) = <no. of clauses modified>
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been executed =>
 *                solflg >= 0.
 * -----------------------------------
 */
void mst_cls(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i, j;
/*
 */
  void errmsg();
  void disprm();
  void iracin();
  void irinac();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"modify_clause");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check validity of likelihood level bounds
 */
  for(i=1; i<=2; i++)  {
    if ((pvalue_(i)<0)||
        (pvalue_(i)>100)) {
      perror_(1)=nftl;
      errval=1100;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
  if (pvalue_(1)>pvalue_(2)) {
    perror_(1)=nftl;
    errval=1110;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check validity of pstate
 */
  if ((strcmp(pstate,"A")!=0)&&
      (strcmp(pstate,"D")!=0)&&
      (strcmp(pstate,"L")!=0)) {
/*
 *  unknown clause code
 */
    perror_(1)=nftl;
    errval=1090;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  pstate = "L" requires pvalue_(1) >= 1 as well as
 *  1 <= pvalue_(5) <= 100
 */
  if ((strcmp(pstate,"L")==0)&&
      ((pvalue_(1)==0)||
      (pvalue_(5)<1)||
      (pvalue_(5)>100))) {
/*
 *  state ="L" and at least of the following:
 *   - likelihood level bound not compatible
 *   - new likelihood not in range 1 .. 100
 */
    perror_(1)=nftl;
    errval=1080;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  initialize total number of clauses matching the name
 *  and with likelihood level within the specified bounds
 */
  pvalue_(3)=0;
/*
 *  initialize total number of clauses actually updated.
 */
  pvalue_(4)=0;
/*
 *  process each row
 */
  for(i=1; i<=nrows; i++)  {
/*
 *  find internal index
 */
    iscan=idxrow_(i);
/*
 *  skip row if it is a goal
 */
    if (glflg_(iscan)==1) {
      goto zz305;
    }
    if (rownam_(58,i) != 'D') {
/*
 *  skip row since it is not deletable by user
 *  (it could be deletable due to preprocessing)
 */
      goto zz305;
    }
    if ((level_(iscan)>=pvalue_(1))&&
        (level_(iscan)<=pvalue_(2))) {
/*
 *  likelihood level is within specified range
 */
      if (strlen(pname)>0) {
/*
 *  check name
 */
        if (strlen(pname) != strlen(&rownam_(1,i))) {
          goto zz305;
        }
        for (j=1;j<=strlen(pname);j++) {
          if ((pname_(j) != '?')&&
              (pname_(j) != rownam_(j,i))) {
            goto zz305;
          }
        }
      }
/*
 *  have a match
 */
      pvalue_(3)=pvalue_(3)+1;
/*
 *  perform indicated action
 * 
 *  delete clause
 */
      if (strcmp(pstate,"D")==0) {
/*
 *  row may be deleted
 */
        if (riact_(iscan)==1) {
          iracin(iscan);
        }
/*
 *  determine if clause will be modified to update pvalue_(4)
 */
        if (riina_(iscan)!=2) {
          pvalue_(4)=pvalue_(4)+1;
        }
/*
 *  indicate clause is deleted
 */
        riina_(iscan)=2;
        goto zz305;
      }
/*
 *  activate clause
 */
      if (strcmp(pstate,"A")==0) {
/*
 *  row iscan is to be active
 */
        if (riina_(iscan)!=0) {
          irinac(iscan);
/*
 * update pvalue_(4) = total number of clauses modified.
 */
          pvalue_(4)=pvalue_(4)+1;
        }
        goto zz305;
      }
/*
 *  change likelihood level
 */
      if (strcmp(pstate,"L")==0) {
        level_(iscan)=pvalue_(5);
/*
 * update pvalue_(4) = total number of clauses modified.
 */
        pvalue_(4)=pvalue_(4)+1;
        goto zz305;
      }
    }
  zz305:;
  }
/*
 */
  if (pvalue_(3)==0) {
/*
 *  no matching name
 */
    perror_(1)=warn;
    errval=0020;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  } else {
    solflg=0;
    asgflg=1;
    goto zz1000;
  }
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  mst_gol
 * 
 *  description:  change the state of all goals matching
 *                the given name (possibly with the wildcard
 *                character '?') in pname.
 * 
 *  input:        pname = <goal name (wildcard ? allowed)>
 *                pstate = "D" - delete all matches
 *                       = "A" - activate all matches
 *                       = "Q" - change goal quantity of all
 *                               matches
 *                       = "L" - change cost of low usage of all
 *                               matches
 *                       = "H" - change cost of high usage of all
 *                               matches
 *                       = "P" - change goal quantity, cost of low
 *                               usage, cost of high usage of all
 *                               matches
 * 
 *                if pstate = "Q":
 *                  pvalue_(1) = new goal quantity
 *                if pstate = "L":
 *                  pvalue_(2) = new cost of low usage
 *                if pstate = "H":
 *                  pvalue_(3) = new cost of high usage
 *                if pstate = "P":
 *                  pvalue_(1) = new goal quantity
 *                  pvalue_(2) = new cost of low usage
 *                  pvalue_(3) = new cost of high usage
 * 
 *  output:       pvalue_(4) = <no. of goal names matching 
 *                              criteria>
 *                pvalue_(5) = <no. of goals modified>
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been executed =>
 *                solflg >= 0.
 * -----------------------------------
 */
  void mst_gol(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i,j;
/*
 */
  void errmsg();
  void disprm();
  void iracin();
  void irinac();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"modify_goal");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check if approximate minimization is used
 */
  if (apmflg==0) {
/*
 *  procedure requires approximate minimization
 */
    perror_(1)=nftl;
    errval=1330;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check validity of pstate
 */
  if ((strcmp(pstate,"A")!=0)&&
      (strcmp(pstate,"D")!=0)&&
      (strcmp(pstate,"Q")!=0)&&
      (strcmp(pstate,"L")!=0)&&
      (strcmp(pstate,"H")!=0)&&
      (strcmp(pstate,"P")!=0)) {
/*
 *  unknown goal code
 */
    perror_(1)=nftl;
    errval=1290;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check range of goal quantity, must be -16,383 .. 16,383
 */
  if ((strcmp(pstate,"Q")==0)||
      (strcmp(pstate,"P")==0)) {
    if ((pvalue_(1)<-16383)||
        (pvalue_(1)>16383)) {
      perror_(1)=nftl;
      errval=1350;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
/*
 *  check range of costs, must be 0 .. 16,383
 */
  if ((strcmp(pstate,"L")==0)||
      (strcmp(pstate,"H")==0)||
      (strcmp(pstate,"P")==0)) {
    if ((pvalue_(2)<0)||
        (pvalue_(3)<0)||
        (pvalue_(2)>16383)||
        (pvalue_(3)>16383)) {
      perror_(1)=nftl;
      errval=1360;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
/*
 *  initialize total number of clauses matching the name
 */
  pvalue_(4)=0;
/*
 *  initialize total number of clauses actually updated.
 */
  pvalue_(5)=0;
/*
 *  process each row
 */
  for(i=1; i<=nrows; i++)  {
/*
 *  find internal index
 */
    iscan=idxrow_(i);
/*
 *  skip row if it is not a goal
 */
    if (glflg_(iscan)!=1) {
      goto zz505;
    }
/*
 *  goal row must be deletable since all goal rows
 *  are named by definition. but possibly there is an unnamed clause
 *  with variable goal in .log file, so want to ignore such clauses
 */
    if (rownam_(58,i) != 'D') {
      goto zz505;
    }
/*
 */
    if (strlen(pname)>0) {
/*
 *  check name
 */
      if (strlen(pname) != strlen(&rownam_(1,i))) {
        goto zz505;
      }
      for (j=1;j<=strlen(pname);j++) {
        if ((pname_(j) != '?')&&
            (pname_(j) != rownam_(j,i))) {
          goto zz505;
        }
      }
    }
/*
 *  have a match
 */
    pvalue_(4)=pvalue_(4)+1;
/*
 *  perform indicated action
 * 
 *  delete goal
 */
    if (strcmp(pstate,"D")==0) {
/*
 *  row may be deleted
 */
      if (riact_(iscan)==1) {
        iracin(iscan);
      }
/*
 *  determine if goal will be modified to update pvalue_(5)
 */
      if (riina_(iscan)!=2) {
        pvalue_(5)=pvalue_(5)+1;
      }
/*
 *  indicate clause is deleted
 */
      riina_(iscan)=2;
      goto zz505;
    }
/*
 *  activate goal
 */
    if (strcmp(pstate,"A")==0) {
/*
 *  row iscan is to be active
 */
      if (riina_(iscan)!=0) {
        irinac(iscan);
/*
 * update pvalue_(5) = total number of clauses modified.
 */
        pvalue_(5)=pvalue_(5)+1;
      }
      goto zz505;
    }
/*
 *  change goal quantity
 */
    if (strcmp(pstate,"Q")==0) {
      if (goalxq_(iscan)!=pvalue_(1)) {
/*
 *  update goal quantity
 */
        goalxq_(iscan)=pvalue_(1);
/*
 * update pvalue_(5) = total number of clauses modified.
 */
        pvalue_(5)=pvalue_(5)+1;
      }
      goto zz505;
    }
/*
 *  change cost of low usage
 */
    if (strcmp(pstate,"L")==0) {
      if (glocst_(iscan)!=pvalue_(2)) {
/*
 *  update cost of low usage
 */
        glocst_(iscan)=pvalue_(2);
/*
 * update pvalue_(5) = total number of clauses modified.
 */
        pvalue_(5)=pvalue_(5)+1;
      }
      goto zz505;
    }
/*
 *  change cost of high usage
 */
    if (strcmp(pstate,"H")==0) {
      if (ghicst_(iscan)!=pvalue_(3)) {
/*
 *  update cost of high usage
 */
        ghicst_(iscan)=pvalue_(3);
/*
 * update pvalue_(5) = total number of clauses modified.
 */
        pvalue_(5)=pvalue_(5)+1;
      }
      goto zz505;
    }
/*
 *  change goal quantity, cost of low, high usage
 */
    if (strcmp(pstate,"P")==0) {
      if ((goalxq_(iscan)!=pvalue_(1))||
          (glocst_(iscan)!=pvalue_(2))||
          (ghicst_(iscan)!=pvalue_(3))) {
/*
 *  update goal quantity and low, high cost of usage
 */
        goalxq_(iscan)=pvalue_(1);
        glocst_(iscan)=pvalue_(2);
        ghicst_(iscan)=pvalue_(3);
        pvalue_(5)=pvalue_(5)+1;
      }
      goto zz505;
    }
/*
 */
  zz505:;
  }
/*
 */
  if (pvalue_(4)==0) {
/*
 *  no matching name
 */
    perror_(1)=warn;
    errval=0020;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  } else {
    solflg=0;
    asgflg=1;
    goto zz1000;
  }
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  mst_prb
 * 
 *  description:  modify status of current problem.
 * 
 *  input:        ptype  = "SAT" if change to satisfiability
 *                               problem
 *                       = "MIN" if change to minimization problem
 * 
 *  output:       pname = "<problem name>"
 *                pstate = "N" (indicates problem not solved)
 *                pvalue_(1) = <number of variables>
 *                pvalue_(2) = <number of clauses and goals>
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been executed
 *                => solflg >= 0.
 * -----------------------------------
 */
void mst_prb(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"modify_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }

/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  satisfiability problem may be reset to minimization problem
 *  only if original problem specified minimization
 *  (minimize in .log file)
 */
  if (strcmp(ptype3,"SAT")==0) {
/*
 *  switch min to sat requested
 */
    optimz=0;
  } else {
/*
 *  switch sat to min requested
 */
    if (optimr==0) {
/*
 *  switch to min not allowed
 */
      perror_(1)=nftl;
      errval=1170;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    } else {
      optimz=1;
    }
  }
  solflg=0;
  strcpy(pstate,"N");
  pvalue_(1)=ncolsx;
  pvalue_(2)=nrows;
/*
 *  update uname
 */
  strcpy(uname,&prbnam_(1,1));
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  mst_var
 * 
 *  description:  change the state of all variables matching
 *                the given name, possibly with wildcard '?',
 *                or given by index in pvalue_(1).
 *
 *  input:        either:
 *                  pvalue_(1) = 0
 *                  pname = <variable name, wildcard ? allowed>
 *                or:
 *                  pvalue_(1) = <index of variable>
 * 
 *                pstate = "T" - fix all matches to true
 *                       = "F" - fix all matches to false
 *                       = "D" - delete all matches
 *                       = "A" - activate all matches
 *                       = "M" - change costs of all matches
 *                       = "G" - change goal name and usage
 *                               coefficient of all matches
 *                       = "I" - change initial value for
 *                               approx. min.
 *                "T", "F", "D", "A", and "I" are not allowed if
 *                transfer process is used.
 * 
 *                 if pstate = "M":
 *                   pvalue_(5) = new cost of true
 *                   pvalue_(6) = new cost of false
 * 
 *                 if pstate = "G":
 *                   pname_(61..) = <goal name>
 *                   pvalue_(7) = new usage coefficient
 *                   use pvalue_(7) = 0 to effectively remove
 *                                     variable from goal 
 *                                     constraint; in that case,
 *                                     the goal name is ignored
 * 
 *                 if pstate = "I":
 *                   ptype = "IT" - initial value is true
 *                         = "IF" - initial value is false
 *                         = "IN" - no initial value assigned
 * 
 *  output:       pvalue_(3) = <no. of matching variables>
 *                pvalue_(4) = <no. of variables modified>
 *                perror_(1) = 0 if operation successful, else
 *                               error indicated by error code
 *                if pvalue_(1) > 0:
 *                  pname = <name of variable indexed by 
 *                           pvalue_(1)>
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 *
 *  caution:      if transfer process is used, then fixing,
 *                deleting, or activating of variables, or
 *                defining initial values for approx. min.,
 *                by mst_var is not allowed.
 *
 *                  
 * ------------------------------------------------------------
 */
void mst_var(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long hx,i,j,lx;
/*
 */
  void errmsg();
  void disprm();
  void icfrin();
  void icfxin();
  void icinfr();
  void icinfx();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"modify_variable");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  test state parameter
 */
  if ((strcmp(pstate,"T")!=0)&&
      (strcmp(pstate,"F")!=0)&&
      (strcmp(pstate,"D")!=0)&&
      (strcmp(pstate,"A")!=0)&&
      (strcmp(pstate,"M")!=0)&&
      (strcmp(pstate,"G")!=0)&&
      (strcmp(pstate,"I")!=0)) {
/*
 *  unknown variable state
 */
    perror_(1)=nftl;
    errval=1030;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  test for consistency with transfer process, if applicable
 */
  if ((trsprocessflg==1)&&
      ((strcmp(pstate,"T")==0)||
       (strcmp(pstate,"F")==0)||
       (strcmp(pstate,"D")==0)||
       (strcmp(pstate,"A")==0)||
       (strcmp(pstate,"I")==0))) {
/*
 *  transfer process does not allow fixing, deleting, or
 *  activating of variables, or defining initial
 *  value for approx. min. by mst_var
 */
    perror_(1)=nftl;
    errval=1410;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  } 
/*
 *  check conditions when costs are to be changed
 */
  if (strcmp(pstate,"M")==0) {
    if ((pvalue_(5)<-16383)||
        (pvalue_(6)<-16383)||
        (pvalue_(5)>16383)||
        (pvalue_(6)>16383)) {
/*
 *  pstate = "M" requires the costs in pvalue_(5) and pvalue_(6)
 *  to lie in the range -16,383 .. 16,383
 */
      perror_(1)=nftl;
      errval=1160;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
/*
 *  check conditions when goal data are to be changed
 */
  if (strcmp(pstate,"G")==0) {
/*
 *  check if approximate minimization is used
 */
    if (apmflg==0) {
/*
 *  procedure requires approximate minimization
 */
      perror_(1)=nftl;
      errval=1330;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
/*
 *  goal usage coefficient must be in range -128 .. 128
 */
    if ((pvalue_(7)<-128)||
        (pvalue_(7)>128)) {
      perror_(1)=nftl;
      errval=1340;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
/*
 */
    if (pvalue_(7)!=0) {
/*
 *  goal coefficient is nonzero
 *  copy goal name from uname_(61..) into pname_(61..)
 */
      strcpy(&pname_(61),&uname_(61));
/*
 *  goal name may not be empty
 */
      if (strlen(&pname_(61))==0) {
        perror_(1)=nftl;
        errval=1310;
        errmsg();
        disprm(ucomnd,uname,ustate,utype,uvalue,perror);
        goto zz1000;
      }
/*
 *  find row index for goal name, to be used for definition of
 *  idxgol(j) and idxgnm(j)
 */
      for(i=1; i<=nrows; i++)  {
        iscan=idxrow_(i);
        if ((glflg_(iscan)==1)&&
            (strcmp(&pname_(61),&rownam_(1,i))==0)) {
/*
 *  have match
 */
          inam=i;
          goto zz325;
        }
      }
/*
 *  name in pname_(61..) is not a goal name
 */
      perror_(1)=nftl;
      errval=1320;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
/*
 *  have external index for goal name in inam
 */
      zz325:;
    }
  }
/*
 *  check code in ptype when initial values are to be changed
 */
  if (strcmp(pstate,"I")==0) {
    if ((strcmp(ptype2,"IT")!=0)&&
        (strcmp(ptype2,"IF")!=0)&&
        (strcmp(ptype2,"IN")!=0)) {
/*
 *  pstate = "I" requires one of the codes IT, IF, IN in ptype
 */
      perror_(1)=nftl;
      errval=1030;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
/*
 *  initialize total number of variables matching variable name
 */
  pvalue_(3)=0;
/*
 *  initialize total number of variables actually updated.
 */
  pvalue_(4)=0;
/*
 *  test for proper range of pvalue_(1) index
 */
  if ((pvalue_(1)<0)||(pvalue_(1)>ncolsx)) {
/*
 *  index out of bounds
 */
    perror_(1)=nftl;
    errval=1040;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  set up do loop bounds
 */
  if (pvalue_(1)==0) {
/*
 *  variable name has been specified
 */
    lx=1;
    hx=ncolsx;
  } else {
/*
 *  variable index has been specified
 */
    lx=pvalue_(1);
    hx=pvalue_(1);
    jnam=idxclx_(pvalue_(1));
/*
 *  place variable name into pname and uname
 */
    strcpy(pname,&colnam_(1,jnam));
    strcpy(uname,&colnam_(1,jnam));
  }
/*
 *  loop through external variable indices using bounds lx and hx
 */
  for(j=lx; j<=hx; j++)  {
    jnam=idxclx_(j);
    if (pvalue_(1)==0) {
      if (strlen(pname) != strlen(&colnam_(1,jnam))) {
/*
 *  do not have a match
 */
        goto zz300;
      }
      for (i=1;i<=strlen(pname);i++) {
        if ((pname_(i) != '?')&&
            (pname_(i) != colnam_(i,jnam))) {
/*
 *  do not have a match
 */
          goto zz300;
        }
      }
    }
/*
 *  have a match
 */
    pvalue_(3)=pvalue_(3)+1;
    jscan=idxcol_(jnam);
/*
 *  perform indicated action
 * 
 *  fix variable to T or F
 */
    if ((strcmp(pstate,"T")==0)||(strcmp(pstate,"F")==0)) {
/*
 *  determine if variable will be modified
 *  to update total no. modified.
 */
      if (scale_(jscan)==1) {
        if (((strcmp(pstate,"T")==0)&&
            (ciina_(jscan)!=1))||
            ((strcmp(pstate,"F")==0)&&
            (ciina_(jscan)!=-1))) {
          pvalue_(4)=pvalue_(4)+1;
        }
      } else if (((strcmp(pstate,"F")==0)&&
                  (ciina_(jscan)!=1))||
                 ((strcmp(pstate,"T")==0)&&
                  (ciina_(jscan)!=-1))) {
        pvalue_(4)=pvalue_(4)+1;
      }
      if (cifre_(jscan)!=0) {
        icfrin(jscan);
      } else if (cifix_(jscan)!=0) {
        icfxin(jscan);
      }
/*
 *  set ciina to new value
 */
      if (((strcmp(pstate,"T")==0)&&
           (scale_(jscan)==1))||
          ((strcmp(pstate,"F")==0)&&
           (scale_(jscan)==-1))) {
        ciina_(jscan)=1;
      } else {
        ciina_(jscan)=-1;
      }
      goto zz300;
    }
/*
 * delete variable
 */
    if (strcmp(pstate,"D")==0) {
      if (dlclop_(jscan)==1) {
        if (cifre_(jscan)!=0) {
          icfrin(jscan);
        } else if (cifix_(jscan)!=0) {
          icfxin(jscan);
        }
/*
 *  update ciina(jscan) if necessary and record update count
 */
        if (ciina_(jscan)!=2) {
          pvalue_(4)=pvalue_(4)+1;
          ciina_(jscan)=2;
        }
        goto zz300;
      } else {
        perror_(1)=warn;
        errval=0030;
        errmsg();
        if (scrflg==1) {
          printf("for: ");
        }
        fprintf(errfil,"for: ");
        if (scrflg==1) {
          printf(&colnam_(1,jnam));
        }
        fprintf(errfil,&colnam_(1,jnam));
        disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 *  delete variable option not specified
 */
        goto zz300;
      }
    }
/*
 *  activate variable
 */
    if (strcmp(pstate,"A")==0) {
      if (ciina_(jscan)!=0) {
        if (cvatf_(jscan)!=0) {
/*
 *  variable jscan is atf type. 
 *  reset to default true/false value if
 *  not already at that value
 *  note: cvatf(jscan) may be 0, +/-1, +/-2, 
 *  the third case is due to
 *  monotone column assignment in monotn
 */
          if ((cvatf_(jscan)>0)&&
              (ciina_(jscan)!=1)) {
            ciina_(jscan)=1;
            pvalue_(4)=pvalue_(4)+1;
          } else if ((cvatf_(jscan)<0)&&
                     (ciina_(jscan)!=-1)) {
            ciina_(jscan)=-1;
          }
          goto zz300;
        } else {
/*
 *  variable jscan is non-atf type. move to active.  decide on
 *  free/fixed according to cifrer (which indicates whether
 *  column was originallly free)
 */
          if (cifrer_(jscan)!=0) {
            icinfr(jscan);
          } else {
            icinfx(jscan);
          }
/*
 *  update total number of variables modified
 */
          pvalue_(4)=pvalue_(4)+1;
        }
      }
      goto zz300;
    }
/*
 *  change costs
 */
    if (strcmp(pstate,"M")==0) {
/*
 *  check that cost change is allowed
 */
      if (((trucsr_(jnam)>falcsr_(jnam))&&
           (pvalue_(5)<pvalue_(6)))||
          ((trucsr_(jnam)==falcsr_(jnam))&&
           (pvalue_(5)!=pvalue_(6)))||
          ((trucsr_(jnam)<=falcsr_(jnam))&&
           (pvalue_(5)>pvalue_(6)))) {
        pvalue_(7)=j;
        perror_(1)=nftl;
        errval=1180;
        errmsg();
        disprm(ucomnd,uname,ustate,utype,uvalue,perror);
        goto zz1000;
      }
      trucst_(jnam)=pvalue_(5);
      falcst_(jnam)=pvalue_(6);
      cost_(jscan)=(pvalue_(5)-pvalue_(6))*scale_(jscan);
/*
 *  update total number of variables affected
 */
      pvalue_(4)=pvalue_(4)+1;
      goto zz300;
    }
/*
 *  change goal indices and coefficient
 *  zero goal coefficient implies remove indices
 */
    if (strcmp(pstate,"G")==0) {
      if (pvalue_(7)!=0) {
        idxgnm_(jscan)=inam;
        idxgol_(jscan)=idxrow_(inam);
        gcoeff_(jscan)=pvalue_(7)*scale_(jscan);
      } else {
        idxgnm_(jscan)=0;
        idxgol_(jscan)=0;
        gcoeff_(jscan)=0;
      }
/*
 *  update total number of variables affected
 */
      pvalue_(4)=pvalue_(4)+1;
      goto zz300;
    }
/*
 *  change initial value for approximate minimization
 */
    if (strcmp(pstate,"I")==0) {
/*
 *  determine if variable will be modified
 *  to update total no. modified
 *  case of 'no value assigned'
 */
      if (strcmp(ptype2,"IN")==0) {
        if (inlsol_(jscan)!=0) {
          pvalue_(4)=pvalue_(4)+1;
          inlsol_(jscan)=0;
        }
        goto zz300;
      }
/*
 *  case of true or false to be assigned
 */
      if (scale_(jscan)==1) {
        if (((strcmp(ptype2,"IT")==0)&&
             (inlsol_(jscan)!=1))||
            ((strcmp(ptype2,"IF")==0)&&
             (inlsol_(jscan)!=-1))) {
          pvalue_(4)=pvalue_(4)+1;
        }
      } else if (((strcmp(ptype2,"IF")==0)&&
                  (inlsol_(jscan)!=1))||
                 ((strcmp(ptype2,"IT")==0)&&
                  (inlsol_(jscan)!=-1))) {
        pvalue_(4)=pvalue_(4)+1;
      }
/*
 *  set inlsol to new value
 */
      if (((strcmp(ptype2,"IT")==0)&&
           (scale_(jscan)==1))||
          ((strcmp(ptype2,"IF")==0)&&
           (scale_(jscan)==-1))) {
        inlsol_(jscan)=1;
      } else {
        inlsol_(jscan)=-1;
      }
      goto zz300;
    }
/*
 */
  zz300:;
  }
/*
 */
  if (pvalue_(3)==0) {
/*
 *  no variables found that match criteria
 */
    perror_(1)=warn;
    errval=0020;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  } else {
    solflg=0;
    asgflg=1;
    goto zz1000;
  }
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  ret_prb
 * 
 *  description:  retrieve a stored problem and load as current
 *                problem. the problem also remains in storage
 * 
 *  input:        pname     = "<name of problem to be retrieved>"
 * 
 *  output:       pname = "<name of current problem>"
 *                        (= "<name of the retrieved problem>")
 *                pvalue_(1) = number of variables
 *                pvalue_(2) = number of logic clauses and goals
 *                if minimization, and if problem has been solved
 *                and is satisfiable:
 *                  pvalue_(3) = total cost of solution
 *                  pvalue_(4) = lower bound on minimum cost 
 *                               solution
 *                if transfer process is used:
 *                  pstate = "" (since user may have changed
 *                            variable values in user program,
 *                            cannot decide whether problem
 *                            has been solved)
 *                if transfer process is not used:
 *                  pstate = "S"   if problem solved and 
 *                                 satisfiable
 *                         = "U"   if problem solved and 
 *                                 unsatisfiable
 *                         = "N"   if problem is not solved
 *                ptype  = "SAT" if satisfiability problem
 *                       = "MIN" if minimization problem
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 *                at least two problems must be present
 *                => nprbs >= 2
 * -----------------------------------
 */
void ret_prb(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long j;
/*
 */
  void errmsg();
  void disprm();
  void getprg();
  void pdatatoudata();
  void sts_prb();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"retrieve_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check if there is a stored problem
 */
  if (nprbs<=1) {
    perror_(1)=nftl;
    errval=1270;
/*
 *  there is no stored problem
 */
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  search for stored problem with name matching pname string
 */
  for(j=2; j<=nprbs; j++)  {
    if (strcmp(pname,&prbnam_(1,j)) == 0) {
/*
 *  have match. retrieve problem and load it
 */
      lprb=j;
      stoflg=-1;
      currec=prbbeg_(lprb);
      getprg();
/*
 *  get status of retrieved problem
 */
      sts_prb(pname,pstate,ptype,pvalue,perror);
      if (perror_(1)>0) {
        error("sto_prb","132");
      }
/*
 *  update uname
 */
      strcpy(uname ,pname);
      goto zz1000;
    }
  }
/*
 *  unknown problem name
 */
  perror_(1)=nftl;
  errval=1250;
  errmsg();
  disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  rst_prb
 * 
 *  description:  restore the current problem to its original 
 *                form, i.e., to the form at hand immediately 
 *                after the loading of the program for that 
 *                problem by beg_prb.
 *                options: code letter in state
 *                pstate = "A":  restore all
 *                         "V":  restore variables
 *                              (active/default value)
 *                         "M":  restore costs of variables
 *                         "C":  restore clauses and goals 
 *                               to active
 *                         "L":  restore likelihood values 
 *                               of clauses
 *                         "T":  restore problem type (min/sat)
 *                         "I":  restore initial values for 
 *                               approx. min. to 
 *                               'no value assigned'
 * 
 *  input:        pstate = "<option code>" (see above)
 * 
 *  output:       perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 *
 *  If transfer process is used:
 *
 *      The case of pstate = "I", where any existing 
 *      initial solution for approx. min. is removed, 
 *      is equivalent to restoring the
 *      problem using mst_allvar with pstate = "R".
 *
 *      The values of variables in the user program are
 *      not affected by rst_prb.
 *
 *  
 * 
 *  caution:      for all goals: the goal quantity, cost of low
 *                usage, and cost of high usage, goal name and
 *                usage coefficient associated with given 
 *                variable, if any, are not changed by the 
 *                procedure rst_prb.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 * -----------------------------------
 */
void rst_prb(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long i,j;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"restore_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  solflg=0;
/*
 *  test state
 */
  if ((strcmp(pstate,"A")!=0)&&
      (strcmp(pstate,"V")!=0)&&
      (strcmp(pstate,"M")!=0)&&
      (strcmp(pstate,"C")!=0)&&
      (strcmp(pstate,"L")!=0)&&
      (strcmp(pstate,"T")!=0)&&
      (strcmp(pstate,"I")!=0)) {
/*
 *  unknown code for rst_prb procedure
 */
    perror_(1)=nftl;
    errval=1190;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if ((strcmp(pstate,"V")==0)&&
      (trsprocessflg==1)) {
/*
 *  rst_prb with state ="V" cannot be used 
 *  with transfer process
 */
    perror_(1)=nftl;
    errval=1440;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  } 
/*
 *  restore column indices if state = "A" or "V" and
 *  if transfer process is not used
 */
  if (((strcmp(pstate,"A")==0)||
       (strcmp(pstate,"V")==0))&&
      (trsprocessflg==0)) {
    for(j=1; j<=ncols; j++)  {
      if (ciina_(j)!=ciinar_(j)) {
        ciina_(j)=ciinar_(j);
        ciact_(j)=ciactr_(j);
        cifre_(j)=cifrer_(j);
        cifix_(j)=cifixr_(j);
      }
    }
    asgflg=1;
  }
/*
 *  restore costs
 */
  if ((strcmp(pstate,"A")==0)||
      (strcmp(pstate,"M")==0)) {
    for(j=1; j<=ncols; j++)  {
      trucst_(j)=trucsr_(j);
      falcst_(j)=falcsr_(j);
      jscan=idxcol_(j);
      cost_(jscan)=(trucsr_(j)-falcsr_(j))*scale_(jscan);
    }
  }
/*
 *  restore row indices
 */
  if ((strcmp(pstate,"A")==0)||
      (strcmp(pstate,"C")==0)) {
    for(i=1; i<=nrows; i++)  {
      if (riina_(i)!=riinar_(i)) {
        riina_(i)=riinar_(i);
        riact_(i)=riactr_(i);
      }
    }
    asgflg=1;
  }
/*
 *  restore likelihood levels
 */
  if ((strcmp(pstate,"A")==0)||
      (strcmp(pstate,"L")==0)) {
    for(j=1; j<=ncols; j++)  {
      level_(j)=levelr_(j);
    }
  }
/*
 *  restore problem type
 */
  if ((strcmp(pstate,"A")==0)||
      (strcmp(pstate,"T")==0)) {
    optimz=optimr;
  }
/*
 *  restore initial values for approx. min. to 'unspecified'
 */
  if ((strcmp(pstate,"A")==0)||
      (strcmp(pstate,"I")==0)) {
    for(j=1; j<=ncols; j++)  {
      inlsol_(j)=0;
    }
  }
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  sol_prb
 * 
 *  description:  solve current satisfiability or 
 *                minimization problem.
 * 
 *  input:        if approximate minimization:
 *                  pvalue_(5) = precision level of 
 *                               approx. min. procedure
 *                  uses values in inlsol to define
 *                  initial solution
 *                  type(1:1) = 'D' if details of  
 *                              computation are to be shown
 * 
 *  output:       pname = problem name
 *                pstate = "S" if problem satisfiable
 *                         "U" if problem unsatisfiable
 *                ptype = "SAT" if satisfiability problem
 *                        "MIN" if minimization problem
 *                if minimization, and if satisfiable:
 *                  pvalue_(3) = total cost of solution
 *                  pvalue_(4) = lower bound on minimum 
 *                               cost solution
 *                perror_(1) = 0 if operation successful, else
 *                               error indicated by error code.
 * 
 *  caution:      apmsol() may assign values to value(6-8).
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 * -----------------------------------
 */
void sol_prb(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void apmsol();
  void errmsg();
  void disprm();
  void leibniztransfer();
  void sol_xct();
  void pdatatoudata();
  void trsleibtovar();
  void trsvartoleib();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"solve_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  record problem name
 */
  strcpy(pname,&prbnam_(1,1));
/*
 *  update uname
 */
  strcpy(uname ,pname);
/*
 *  if transfer process is used, 
 *  transfer user values to leibniz
 */
  if (trsprocessflg==1) {
    leibniztransfer("usertotrsvar",prbnam,trsvar,&errval,
                    ucomnd,uname,pstate,ptype,pvalue,perror);

    if (perror_(1)!=zeroerr) {
      goto zz1000;
    }
    trsvartoleib(ucomnd,uname,pstate,ptype,pvalue,perror);
    if (perror_(1)!=zeroerr) {
      goto zz1000;
    }
    asgflg = 1;
  }
/*
 *  solve problem
 */
  if ((optimz==0)||(apmflg==0)) {
/*
 *  satisfiability or exact minimization case
 */
    sol_xct(pname,pstate,ptype,pvalue,perror);
  } else {
/*
 *  have approximate minimization case
 */
    apmsol(pname,pstate,ptype,pvalue,perror);
  }
/*
 *  if problem is satisfiable and transfer process is used, 
 *  transfer solution to user variables
 */
  if ((strcmp(pstate,"S")==0)&&
      (trsprocessflg==1)) {
    trsleibtovar();
    leibniztransfer("trsvartouser",prbnam,trsvar,&errval,
                    ucomnd,uname,pstate,ptype,pvalue,perror);

    if (perror_(1)!=zeroerr) {
      goto zz1000;
    }
  }
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  sol_xct
 * 
 *  description:  solve current problem exactly and 
 *                return outcome.
 * 
 *  input:        none
 * 
 *  output:       pstate = "S" if problem satisfiable
 *                         "U" if problem unsatisfiable
 *                ptype = "SAT" if satisfiability problem
 *                        "MIN" if minimization problem
 *                if minimization (exact):
 *                  pvalue_(3) = total cost of solution
 *                  pvalue_(4) = lower bound on total cost
 *                              (= total cost since min. is exact)
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 *
 *  caution:      if transfer process is used, then transfers
 *                must be done prior to and after call of this
 *                procedure. This procedure cannot check
 *                whether these transfers are done. 
 * -----------------------------------
 */
void sol_xct(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void ckfisl();
  void cstxpr();
  void enudec();
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
  void urinac();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"sol_xct");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
  if (asgflg==0) {
/*
 *  no changes have been made to original problem; simply solve
 */
    goto zz115;
  }
/*
 *  compute correct inactive rows
 */
  urinac();
/*
 *  solve satisfiability or minimization problem (exactly)
 */
  zz115:;
  enudec();
  ckfisl(perror);
  if (perror_(1)>0) {
/*
 *  satisfiable according to enudec,
 *  but solution incorrect (by ckfisl)
 */
    error("sol_xct","112");
  }
  pvalue_(3)=0;
  strcpy(pstate,"U");
  satble=0;
  prcost=0;
  lbcost=0;
  solflg=1;
  asgflg=0;
  if (succss==1) {
    strcpy(pstate,"S");
    satble=1;
    if (optimz==1) {
/*
 *  compute total cost, put into prcost
 */
      cstxpr();
/*
 *  store prcost in pvalue_(3) to be returned
 */
      pvalue_(3)=prcost;
/*
 *  store prcost in pvalue_(4) as lower bound
 */
      pvalue_(4)=prcost;
/*
 *  retain lower bound
 */
      lbcost=prcost;
    }
  }
/*
 * record problem type in ptype
 */
  if (optimz==1) {
    strcpy(ptype ,"MIN");
  } else {
    strcpy(ptype ,"SAT");
  }
  goto zz1000;
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  sts_cls
 * 
 *  description:  return status of all clauses with specified 
 *                name and with likelihood level in specified 
 *                interval.
 *                do not consider goals, just examine logic 
 *                clauses.
 * 
 *  input:        pname     = <clause name (wildcard ? allowed)>
 *                pvalue_(1) = <lowest likelihood level
 *                             to be considered>
 *                pvalue_(2) = <highest likelihood level
 *                             to be considered>
 * 
 *  output:       pstate = "D" if all matching clauses are deleted.
 *                       = "A" if all matching clauses are active.
 *                       = "B" if some matching clauses are deleted
 *                             and some matching clauses are active.
 *                pvalue_(3) = number of matching clauses
 *                pvalue_(4) = number of active matching clauses
 *                pvalue_(5) = number of deleted matching clauses
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 * -----------------------------------
 */
void sts_cls(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long fnd,i,j;
  static char versts[1+1];
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"status_clause");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check validity of likelihood level bounds
 */
  for(i=1; i<=2; i++)  {
    if ((pvalue_(i)<0)||
        (pvalue_(i)>100)) {
      perror_(1)=nftl;
      errval=1100;
      errmsg();
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
  if (pvalue_(1)>pvalue_(2)) {
    perror_(1)=nftl;
    errval=1110;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  initialize strings and counters
 */
  strcpy(versts," ");
  strcpy(pstate," ");
  fnd=0;
  pvalue_(3)=0;
  pvalue_(4)=0;
  pvalue_(5)=0;
/*
 *  process each row
 */
  for(i=1; i<=nrows; i++)  {
/*
 *  find internal index
 */
    iscan=idxrow_(i);
/*
 *  skip row if it is not a logic clause
 */
    if (glflg_(iscan)==1) {
      goto zz210;
    }
    if (rownam_(58,i) != 'D') {
/*
 *  skip row since it is not deletable by user
 *  (it could be deletable due to preprocessing)
 */
      goto zz210;
    }
    if ((level_(iscan)>=pvalue_(1))&&
        (level_(iscan)<=pvalue_(2))) {
/*
 *  likelihood level is within specified range
 */
      if (strlen(pname)>0) {
/*
 *  check name
 */
        if (strlen(pname) != strlen(&rownam_(1,i))) {
          goto zz210;
        }
        for(j=1; j<=strlen(pname); j++)  {
          if ((pname_(j) != '?') &&
              (pname_(j) != rownam_(j,i))) {
/*
 * do not have a match
 */
            goto zz210;
          }
        }
      }
/*
 *  have a match
 */
      fnd=fnd+1;
/*
 *  store value of clause in pstate
 */
      if (riina_(iscan)==2) {
        strcpy(versts,"D");
        pvalue_(5)=pvalue_(5)+1;
      } else {
        strcpy(versts,"A");
        pvalue_(4)=pvalue_(4)+1;
      }
      if (fnd==1) {
        strcpy(pstate,versts);
      } else {
        if (strcmp(pstate,versts)!=0) {
/*
 *  pstate != versts can happen when deletions using likelihood
 *  parameters removed some but not all clauses with a given name
 */
          strcpy(pstate,"B");
        }
      }
    }
  zz210:;
  }
/*
 *  store number of clauses with given name
 */
  pvalue_(3)=fnd;
  if (fnd==0) {
/*
 *  no matching clause
 */
    perror_(1)=nftl;
    errval=1070;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  sts_prb
 * 
 *  description:  return summary of current problem.
 * 
 *  input:        none
 * 
 *  output:       pname = "<problem name>"
 *                pvalue_(1) = number of variables
 *                pvalue_(2) = number of logic clauses and goals
 *                if minimization, and if problem has been solved
 *                and is satisfiable:
 *                  pvalue_(3) = total cost of solution
 *                  pvalue_(4) = lower bound on minimum cost 
 *                               solution
 *                if transfer process is used:
 *                  pstate = "" (since user may have changed
 *                            variable values in user program,
 *                            cannot decide whether problem
 *                            has been solved)
 *                if transfer process is not used:
 *                  pstate = "S"   if problem solved and 
 *                                 satisfiable
 *                         = "U"   if problem solved and 
 *                                 unsatisfiable
 *                         = "N"   if problem is not solved
 *                ptype  = "SAT" if satisfiability problem
 *                       = "MIN" if minimization problem
 *                pvalue_(5) = number of goals
 *                pvalue_(6) = number of literals
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 * -----------------------------------
 */
void sts_prb(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"status_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  store name of currently loaded problem in pname
 */
  strcpy(pname,&prbnam_(1,1));
/*
 *  update uname
 */
  strcpy(uname ,pname);
/*
 */
  pvalue_(1)=ncolsx;
  pvalue_(2)=nrows;
  pvalue_(3)=prcost;
  pvalue_(4)=lbcost;
  pvalue_(5)=ngols;
  pvalue_(6)=nanzs;
/*
 */
  if (trsprocessflg==1) {
    pstate_(1)='\0';
  } else {
    if (solflg==1) {
      if (satble==1) {
        strcpy(pstate,"S");
      } else {
        strcpy(pstate,"U");
      }
    } else {
      strcpy(pstate,"N");
    }
  }
/*
 */
  if (optimz==1) {
    strcpy(ptype ,"MIN");
  } else {
    strcpy(ptype ,"SAT");
  }
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return; 
}
/*eject*/
/*
 * -----------------------------------
 *  sts_sto
 * 
 *  description:  return summary for storage of problems,
 *                including the problem name of problem
 *                with specified index
 * 
 *  input:        pvalue_(1) = index of problem for which name 
 *                             and storage information is
 *                             to be returned
 * 
 *  output:       pvalue_(1) = index of problem for which name
 *                             and storage information has
 *                             been returned
 *                pvalue_(2) = total number of problems
 *                            (current problem and all
 *                            stored problems)
 *                pvalue_(3) = total number of records used for
 *                            storage of problems
 *                pvalue_(4) = total number of records still
 *                            available for storage of problems
 *                if pvalue_(1) = 1:
 *                  pname     = "<name of currently loaded 
 *                                problem>"
 *                  pvalue_(5) = 0
 *                if pvalue_(1) > 1:
 *                  pname      = "<name of stored problem 
 *                                 with index equal to pvalue(1)>"
 *                  pvalue_(5) = number of records used to store
 *                               problem with index equal to
 *                               pvalue_(1)
 *                perror_(1) = 0 if operation successful, else
 *                             error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 * -----------------------------------
 */
void sts_sto(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long j;
/*
 */
  void errmsg();
  void disprm();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"status_storage");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  transfer problem index into j
 */
  j=pvalue_(1);
  if ((j<=0)||(j>nprbs)) {
/*
 *  problem index out of range
 */
    perror_(1)=nftl;
    errval=1260;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  get basic storage statistics
 */
  pvalue_(2)=nprbs;
  pvalue_(3)=stomax-nfrrec;
  pvalue_(4)=nfrrec;
/*
 *  get problem name
 */
  strcpy(pname,&prbnam_(1,j));
/*
 *  update uname
 */
  strcpy(uname ,pname);
  if (j>=2) {
    pvalue_(5)=prbsiz_(j);
  } else {
    pvalue_(5)=0;
  }
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  sts_var
 * 
 *  description:  return status, and cost of true/false in
 *                optimization case, for specified variable.
 *                information may be requested in one of two ways:
 *                (1) by specifying the variable name;
 *                (2) by specifying the index of the variable. the
 *                    index must lie between 1 and the total 
 *                    number of variables. this feature allows 
 *                    looping.
 * 
 *  input:        either:
 *                  pvalue_(1) = 0
 *                  pname = <variable name>
 *                or:
 *                  pvalue_(1) = <index of variable>
 * 
 *  output:       pstate = variable value code
 *                if transfer process is not used:
 *                  pstate = "T" if variable is fixed to true
 *                           "F" if variable is fixed to false
 *                           "D" if variable is deleted
 *                           "A" if variable is active
 *                if transfer process is used:
 *                  pstate = ''
 *
 *                ptype  = "<part 1><part 2><part3>"
 *                  <part 1> =  D     if variable is deletable
 *                              blank if variable is not deletable
 *                  <part 2> =  T     if true is initial value
 *                                       for approx. min.
 *                              F     if false is initial value
 *                                       for approx. min.
 *                              N     if no initial value assigned
 *                                       for approx. min.
 *                  <part 3> =  AT    if variable has assigntrue
 *                                     option
 *                              AF    if variable has assignfalse
 *                                     option
 *                              MT    if program generator 
 *                                    declared variable to be 
 *                                    monotone with preferred 
 *                                    value T;
 *                                    effectively, variable has
 *                                    assigntrue option
 *                              MF    if program generator 
 *                                    declared variable to be 
 *                                    monotone with preferred 
 *                                    value F;
 *                                    effectively, variable has
 *                                    assignfalse option
 *                              blank if variable is not an
 *                                     AT, AF, MT, or MF case
 *                if pvalue_(1) > 0:
 *                  pname = <name of variable indexed by 
 *                           pvalue_(1)>
 *                if optimization:
 *                  pvalue_(3) = <cost of true>
 *                  pvalue_(4) = <cost of false>
 *                if variable is involved in a goal:
 *                  pname_(61..) = name of goal
 *                              (= blank: variable is not 
 *                                        involved in any goal)
 *                  pvalue_(5) = usage coefficient
 *                              (= 0: variable is not involved
 *                                    in any goal)
 *                pvalue_(6) = number of literals of variable
 * 
 *                perror_(1) = 0 if operation successful, else
 *                            error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 * -----------------------------------
 */
void sts_var(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  void errmsg();
  void disprm();
  void fcindx();
  void pdatatoudata();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"status_variable");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  if index given, return variable name and related information
 */
  if ((pvalue_(1)<0)||(pvalue_(1)>ncolsx)) {
    perror_(1)=nftl;
    errval=1040;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 *  index out of bounds
 */
    goto zz1000;
  }
/*
 *  transfer variable name into pname and uname
 */
  if (pvalue_(1)!=0) {
    jnam=idxclx_(pvalue_(1));
    jscan=idxcol_(jnam);
    strcpy(pname,&colnam_(1,jnam));
    strcpy(uname,&colnam_(1,jnam));
  } else {
/*
 *  find indices jnam (name level) and jscan (internal)
 *  of given variable name
 */
    fcindx(pname,perror);
    if (perror_(1)!=zeroerr) {
      disprm(ucomnd,uname,ustate,utype,uvalue,perror);
      goto zz1000;
    }
  }
/*
 *  store value of variable in pstate
 *  if transfer process is used, pstate = ""
 *  is used to indicate that no applicable 
 *  inside value exists
 */
  if (trsprocessflg==0) {
    if (ciina_(jscan)*scale_(jscan)==1) {
      strcpy(pstate,"T");
    } else if (ciina_(jscan)*scale_(jscan)==-1) {
      strcpy(pstate,"F");
    } else if (ciina_(jscan)==2) {
      strcpy(pstate,"D");
    } else {
      strcpy(pstate,"A");
    }
  } else {
    strcpy(pstate,"");
  }
/*
 *  store variable type in ptype
 */
  if (cvatf_(jscan)==0) {
    strcpy(ptype ,"    ");
  } else if ((scale_(jscan)*cvatf_(jscan))==1) {
    strcpy(ptype ,"  AT");
  } else if ((scale_(jscan)*cvatf_(jscan))==-1) {
    strcpy(ptype ,"  AF");
  } else if ((scale_(jscan)*cvatf_(jscan))==2) {
    strcpy(ptype ,"  MT");
  } else if ((scale_(jscan)*cvatf_(jscan))==-2) {
    strcpy(ptype ,"  MF");
  }
/*
 *  code for initial solution values
 */
  if (inlsol_(jscan)==0) {
    ptype_(2) = 'N';
  } else if ((scale_(jscan)*inlsol_(jscan))==1) {
    ptype_(2) = 'T';
  } else {
    ptype_(2) = 'F';
  }
/*
 *  code for delete option
 */
  if (dlclop_(jscan)==1) {
    ptype_(1) = 'D';
  }
/*
 *  store cost values in pvalue
 */
  pvalue_(3)=trucst_(jnam);
  pvalue_(4)=falcst_(jnam);
/*
 *  store goal name and usage coefficient
 */
  pvalue_(5)=gcoeff_(jscan)*scale_(jscan);
  if (gcoeff_(jscan)!=0) {
    inam=idxgnm_(jscan);
    if (idxgnm_(jscan)==0) {
/*
 *  error, index for goal name must be nonzero
 */
      error("sts_var","112");
    }
    strcpy(&pname_(61),&rownam_(1,inam));
  } else {
    pname_(61) = '\0';
  }
/*
 *  copy goal name from pname_(61..) into uname_(61..)
 */
  strcpy(&uname_(61),&pname_(61));
/*
 *  store number of literals occuring in column jscan
 */
  pvalue_(6)=nzamac_(jscan);
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/*
 * -----------------------------------
 *  sto_prb
 * 
 *  description:  store current problem. the problem remains
 *                loaded
 * 
 *  input:        if pname = "" (=empty string)
 *                   stored problem receives name of 
 *                   current problem
 *                 else:
 *                   pname = "<name for stored problem>"
 *  caution:      if a stored problem exists already with same
 *                name, then that stored problem is overwritten
 *                (actually, the stored problem is first deleted,
 *                and then the current problem is stored).
 * 
 *  output:       pname     = "<name of stored problem>"
 *                pvalue_(2) = total number of problems
 *                            (current problem and all
 *                            stored problems)
 *                pvalue_(3) = total number of records used for
 *                            storage of problems
 *                pvalue_(4) = total number of records still
 *                            available for storage of problems
 *                pvalue_(5) = number of records used to store
 *                            current problem
 *                pstate    = code for status of action taken
 *                          = "E": a stored problem with same 
 *                                 name existed and was 
 *                                 overwritten
 *                          = "N": there was no stored problem 
 *                                 with same name
 *                perror_(1) = 0 if operation successful, else
 *                             error indicated by error code.
 * 
 *  entry conditions:
 *                asg_dev and beg_prb must have been
 *                executed => solflg >= 0.
 * -----------------------------------
 */
void sto_prb(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
/*
 */
#include"query.h"
/*
 */
  static long j;
/*
 */
  void errmsg();
  void del_prb();
  void disprm();
  void pdatatoudata();
  void putprg();
  void sts_sto();
  void udatatopdata();
/*
 *  shift udata to pdata
 */
  udatatopdata(uname,ustate,utype,uvalue,uerror,
               pname,pstate,ptype,pvalue,perror,
               ptype1,ptype2,ptype3);
/*
 *  define command
 */
  strcpy(ucomnd,"store_problem");
/*
 *  return if xerror = fatl, since fatal error
 *  occurred in earlier call into leibniz
 */
  if (xerror==fatl) {
    return;
  }
/*
 *  test for entry conditions
 */
  if (solflg<0) {
    perror_(1)=nftl;
    errval=1010;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  check if name has been assigned
 *  if not, use name of currently loaded problem
 */
  if (pname_(1) == '\0') {
    strcpy(pname,&prbnam_(1,1));
  }
/*
 */
  strcpy(pstate,"N");
/*
 *  search for matching name among stored problems
 */
  if (nprbs>=2) {
    for(j=2; j<=nprbs; j++)  {
/*
 *  compare names
 */
      if (strcmp(pname,&prbnam_(1,j)) == 0) {
/*
 *  have a name match. delete problem with name given by pname
 */
        strcpy(pstate,"E");
        del_prb(pname,pstate,ptype,pvalue,perror);
        if (perror_(1)>0) {
          error("sto_prb","142");
        }
/*
 * update uname
 */
        strcpy(uname ,pname);
        goto zz205 ;
      }
    }
  }
/*
 */
  zz205 :;
/*
 *  store problem
 */
  if (nprbs==prbmax) {
/*
 *  cannot store problem since we have already stored max number
 *  of problems
 */
    perror_(1)=nftl;
    errval=1220;
    errmsg();
    errval=1240;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  update problem counter lprb
 */
  lprb=nprbs+1;
/*
 *  update problem name
 */
  strcpy(&prbnam_(1,lprb),pname);
  stoflg=1;
  currec=fstrec;
  usdrec=0;
  putprg();
  if (succss==0) {
/*
 *  could not store problem since available storage capacity
 *  too small
 */
    perror_(1)=nftl;
    errval=1230;
    errmsg();
    errval=1240;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    goto zz1000;
  }
/*
 *  problem has been stored
 *  update counts and indices
 */
  nprbs=lprb;
  nfrrec=nfrrec-usdrec;
  prbbeg_(lprb)=fstrec;
  prbend_(lprb)=antrec;
  prbsiz_(lprb)=usdrec;
  nxtrec_(antrec)=0;
  fstrec=currec;
/*
 *  assemble output information
 */
  pvalue_(1) = lprb;
  sts_sto(pname,pstate,ptype,pvalue,perror);
  if (perror_(1)>0) {
    error("sto_prb","402");
  }
/*
 *  update uname
 */
  strcpy(uname ,pname);
/*
 */
  zz1000:;
/*
 *  shift pdata to udata
 */
  pdatatoudata(ustate,utype,uvalue,uerror,
               pstate,ptype,pvalue,perror);
  return;
}
/*eject*/
/* ****************************************************
 * module shift udata to pdata and pdata to udata
 * ****************************************************
 */
void pdatatoudata(char *ustate,char *utype,
                  long *uvalue,short *uerror,
                  char *pstate,char *ptype,
                  long *pvalue,short *perror) {
/*  
 */
  long i;
/*
 *  transfer pdata to udata except for pname to uname,
 *  which is done separately in each procedure as needed 
 */
  strcpy(ustate,pstate);
  strcpy(utype ,ptype);
  for(i=1; i<=8; i++)  {
    uvalue_(i)=pvalue_(i);
  }
  for(i=1; i<=2; i++)  {
    uerror_(i)=perror_(i);
  }
/*
 *  save error code in xerror
 */
  xerror = perror_(1);
}
/*
 * **********************************************
 */
void udatatopdata(char *uname,char *ustate,char *utype,
                  long *uvalue,short *uerror,
                  char *pname,char *pstate,char *ptype,
                  long *pvalue,short *perror,
                  char *ptype1,char *ptype2,char *ptype3) {
/*
 */
  static long i;
  static char ptemp[4+1];
/*
 *  transfer udata to pdata
 */
/*
 *  insert end-of-string character for 
 *  uname, ustate, utype
 */
  uname_(128+1) = '\0';
  ustate_(1+1) = '\0';
  utype_(4+1) = '\0';
/*
 *  convert ustate value to upper case if necessary
 */
  if (((int)ustate_(1) >= 97) && 
      ((int)ustate_(1) <= 122)) {
    ustate_(1) = (char)((int)ustate_(1) - 32);
  }
/*
 *  convert utype to upper case
 */
  for (i=1; i<=strlen(utype); i++) {
    if (((int)utype_(i) >= 97) && 
        ((int)utype_(i) <= 122)) {
      utype_(i) = (char)((int)utype_(i) - 32);
    }
  }
/*
 *  transfer udata to pdata
 */
  strcpy(pname ,uname);
  strcpy(pstate,ustate);
  strcpy(ptype ,utype);
  for(i=1; i<=8; i++)  {
    pvalue_(i)=uvalue_(i);
  }
/*
 *  initialize perror
 */
  for(i=1; i<=2; i++)  {
    perror_(i)=0;
  }
/*
 *  extract substrings ptype1,2,3 from ptype
 */
  strcpy(ptemp ,ptype);
  ptemp[3] = '\0';
  strcpy(ptype3,ptemp);
  ptemp[2] = '\0';
  strcpy(ptype2,ptemp);
  ptemp[1] = '\0';
  strcpy(ptype1,ptemp);
}
/*
 * *************************************************
 */
/*  last record of query.c****** */
