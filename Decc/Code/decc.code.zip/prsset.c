/*  first record of prsset.c***** */
#include<string.h>
#include<stdio.h>
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/*
 * **********************************************************
 *  module parse
 * 
 *  this module contains:
 * 
 *    prsset :-   parse sets section
 *    prsprd :-   parse predicates section
 *    prsvar :-   parse variables section
 *    prsfct :-   parse facts section
 *    prsopt :-   parse variable options
 *                given with preds./vars.
 * 
 * ***********************************************************
 * 
 * 
 * ***********************************************************
 *  subroutine prsset
 * 
 *  purpose:  parses sets section and
 *            updates the following data structures:
 * 
 *            eltnam :- stores element names.
 *            setnam :- stores set names.
 *            setdat :- stores index of eltnam for each element
 *                      in each set.
 * 
 *  caution:  the input string is in tmpstr
 * 
 * ************************************************************
 * 
 */
void prsset() {
/*
 */
  static char type[1+1];
  static char str[20+1];
  static char nam[58+1];
  static long indx,l,r,nstelt,err,i;
  static long n;
  static char msgstr[128+1];
/*
 */
  void chknam();
  void ckeoln();
  void extcmp();
  void fndnam();
  void inperr();
  int readlogfil();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  type_(1+1) = '\0';
  str_(20+1) = '\0';
  nam_(58+1) = '\0';
  msgstr_(128+1) = '\0';
/*
 *  read next record from log file
 *  max line length is 125
 */
  zz50:;
  if (readlogfil()==0) {
    goto zz1014;
  }
/*
 */
  l=0;
  r=0;
/*
 *  get next component of tmpstr
 */
  zz60:;
  extcmp(tmpstr,&l,&r);
  if (lstrncmp(&tmpstr_(l),"ENDATA",r-l+1)==0) {
    inperr(&fatal);
    strcpy(msgstr," LBCC2040: Unexpected ENDATA encountered");
    scrwrt("+W",msgstr);
    return;
  }
/*
 * ---------------------------------------------
 *  state definitions
 * ---------------------------------------------
 * ---------------------------------------------
 *  state q1000 is keyword define
 * ---------------------------------------------
 */
  zz1000:;
  if (strcmp(state ,"Q1000")==0) {
    if (lstrncmp(&tmpstr_(l),"DEFINE",r-l+1)==0) {
/*
 *  check if too many sets are defined
 */
      if (nsets==setmax) {
        inperr(&fatal);
        n = setmax;
        sprintf(msgstr,
            " LBCC2050: Too many sets; at most %ld allowed",n);
        scrwrt("+W",msgstr);
        return;
      }
/*  
 *  initialize number of elements for this set
  */
      nstelt=0;
      strcpy(state ,"Q1020");
/*
 *  get next component of current record
 */
      goto zz60;
    } else {
      inperr(&fatal);
      strcpy(msgstr," LBCC2060: Keyword DEFINE expected");
      scrwrt("+W",msgstr);
      return;
    }
  }
/*
 * --------------------------------
 *  state q1020 is <setname>
 * --------------------------------
 */
  if (strcmp(state ,"Q1020")==0) {
/*
 *  check if legal identifier
 */
    n = min(r-l+1,58);
    strncpy(nam,&tmpstr_(l),n);
    nam_(n+1) = '\0';
    chknam(nam,&err,"S");
    if (err!=0) {
      strcpy(state ,"Q1040");
      ckeoln(tmpstr,&r);
      goto zz50;
    }
/*
 *  check if name already referenced
 */
    fndnam(nam,&indx,type);
    if (indx>0) {
      inperr(&nftl);
      if (strcmp(type  ,"E")==0) {
        strcpy(str   ,"element");
      } else if (strcmp(type  ,"S")==0) {
        strcpy(str   ,"set");
      } else if (strcmp(type  ,"Q")==0) {
        error(" prsset ","  202   ");
      } else if (strcmp(type  ,"V")==0) {
        error(" prsset ","  204   ");
      } else if (strcmp(type  ,"P")==0) {
        error(" prsset ","  206   ");
      } else {
        error(" prsset ","  208   ");
      }
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr,
          " LBCC1010: %s has already been defined "
          "as a(n) %s",auxmsg,str);
      scrwrt("+W",msgstr);
      strcpy(state ,"Q1040");
      ckeoln(tmpstr,&r);
      goto zz50;
    }
/*
 *  store set name
 */
    nsets=nsets+1;
    strncpy(&setnam_(1,nsets),&tmpstr_(l),r-l+1);
    setnam_(r-l+2,nsets) = '\0';
/*  
 *  initialize min/max indices of elements
 */
    setdat_(eltmax+2,nsets)=eltmax+1;
    setdat_(eltmax+3,nsets)=0;
/*
 */
    strcpy(state ,"Q1030");
/*
 *  there should be nothing else on this record
 *  after set name.  check.
 */
    ckeoln(tmpstr,&r);
    goto zz50;
  }
/*
 * -------------------------------------------------------
 *  state q1030 is appropriate branch or element parsing
 * -------------------------------------------------------
 */
  if (strcmp(state ,"Q1030")==0) {
    if (lstrncmp(&tmpstr_(l),"DEFINE",r-l+1)==0) {
      strcpy(state ,"Q1000");
/*
 *  check that we do not have an empty set
 */
      if (nstelt==0) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1020: Empty set not allowed");
        scrwrt("+W",msgstr);
      }
      goto zz1000;
    }
/*
 *  branch on appropriate keyword, if encountered.
 *  predicates must be next declaration section.
 *  note that same branch statements are
 *  in state q1040 as well
 */
    if (lstrncmp(&tmpstr_(l),"PREDICATES",r-l+1)==0) {
      ckeoln(tmpstr,&r);
      strcpy(state ,"Q2000");
      goto zz1900;
    } else if ((lstrncmp(&tmpstr_(l),"VARIABLES",r-l+1)==0)||
        (lstrncmp(&tmpstr_(l),"FACTS",r-l+1)==0)) {
      inperr(&fatal);
      strcpy(msgstr," LBCC2190: PREDICATES section expected");
      scrwrt("+W",msgstr);
      return;
    } else if (lstrncmp(&tmpstr_(l),"SETS",r-l+1)==0) {
      inperr(&fatal);
      sprintf(msgstr," LBCC2070: SETS section "
          "already encountered");
      scrwrt("+W",msgstr);
      return;
    }
/*
 *  otherwise assume it is an element name
 */
    n = min(r-l+1,58);
    strncpy(nam,&tmpstr_(l),n);
    nam_(n+1) = '\0';
    chknam(nam,&err,"E");
    if (err!=0) {
      ckeoln(tmpstr,&r);
      goto zz50;
    }
/*
 *  check if name already referenced
 */
    fndnam(nam,&indx,type);
    if ((indx>0)&&
        (strcmp(type  ,"E")!=0)) {
      inperr(&nftl);
      if (strcmp(type  ,"E")==0) {
        strcpy(str   ,"element");
      } else if (strcmp(type  ,"S")==0) {
        strcpy(str   ,"set");
      } else if (strcmp(type  ,"Q")==0) {
        error(" prsset ","  212   ");
      } else if (strcmp(type  ,"V")==0) {
        error(" prsset ","  214   ");
      } else if (strcmp(type  ,"P")==0) {
        error(" prsset ","  216   ");
      } else {
        error(" prsset ","  218   ");
      }
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr," LBCC1010: %s has already been "
          "defined as a(n) %s",auxmsg,str);
      scrwrt("+W",msgstr);
      ckeoln(tmpstr,&r);
      goto zz50;
    }
    if (nstelt==eltmax) {
      inperr(&nftl);
      n = eltmax;
      sprintf(msgstr," LBCC1030: Too many elements in set; "
          "at most %ld allowed",n);
      scrwrt("+W",msgstr);
      strcpy(state ,"Q1040");
      ckeoln(tmpstr,&r);
      goto zz50;
    }
/*
 *  check if element already a member of current set
 */
    if ((indx>0)&&(nstelt>0)) {
      for(i=1; i<=nstelt; i++)  {
        if (setdat_(i,nsets)==indx) {
          inperr(&nftl);
          sprintf(msgstr," LBCC1040: Element already a member "
              "of this set");
          scrwrt("+W",msgstr);
          ckeoln(tmpstr,&r);
          goto zz50;
        }
      }
    }
/*
 *  increment the number of elements for current set
 */
    nstelt=nstelt+1;
/*
 *  indx is index of element in eltnam
 */
    if (indx>0) {
      goto zz1030;
    }
/*
 *  new element name; store it
 */
    nelts=nelts+1;
    if (nelts>eltmax) {
      inperr(&fatal);
      n = eltmax;
      sprintf(msgstr,
          " LBCC2080: Cannot exceed %ld elements",n);
      scrwrt("+W",msgstr);
      return;
    }
    strncpy(&eltnam_(1,nelts),&tmpstr_(l),r-l+1);
    eltnam_(r-l+2,nelts) = '\0';
    indx=nelts;
/*
 *  store element index in setdat and
 *  update min/max index entries
 */
    zz1030:;
/*
 *  record index in setdat_(nstelt,nsets) 
 *  update count in setdat_(eltmax+1,nsets)
 */
    setdat_(nstelt,nsets)=indx;
    setdat_(eltmax+1,nsets)=nstelt;
/*
 *  update min index in setdat_(eltmax+2,nsets)
 */
    if (indx<setdat_(eltmax+2,nsets)) {
      setdat_(eltmax+2,nsets) = indx;
    }
/*
 *  update max index in setdat_(eltmax+3,nsets)
 */
    if (indx>setdat_(eltmax+3,nsets)) {
      setdat_(eltmax+3,nsets) = indx;
    }
    ckeoln(tmpstr,&r);
    goto zz50;
  }
/*
 * ------------------------------------------------
 *  state q1040 is dummy state for errors
 * ------------------------------------------------
 */
  if (strcmp(state ,"Q1040")==0) {
/*
 *  stay in this state until keyword encountered.  note that
 *  branch statements are same as for state q1030.
 */
    if (lstrncmp(&tmpstr_(l),"DEFINE",r-l+1)==0) {
      strcpy(state ,"Q1000");
      goto zz1000;
    }
/*
 *  branch on appropriate keyword, if encountered.
 */
    if (lstrncmp(&tmpstr_(l),"PREDICATES",r-l+1)==0) {
      strcpy(state ,"Q2000");
      return;
    } else if ((lstrncmp(&tmpstr_(l),"VARIABLES",r-l+1)==0)||
        (lstrncmp(&tmpstr_(l),"FACTS",r-l+1)==0)) {
      inperr(&fatal);
      strcpy(msgstr," LBCC2190: PREDICATES section expected");
      scrwrt("+W",msgstr);
      return;
    } else if (lstrncmp(&tmpstr_(l),"SETS",r-l+1)==0) {
      inperr(&fatal);
      sprintf(msgstr," LBCC2070: SETS section already "
          "encountered");
      scrwrt("+W",msgstr);
      return;
    } else {
/*
 *  must be element name; skip it
 */
      goto zz50;
    }
  }
/*
 * ------------------------------------------------
 *  error section
 * ------------------------------------------------
 *  error if state not found
 */
  error(" prsset ","  1012  ");
/*
 *  error if 'EOF' encountered
 */
  zz1014:;
  inperr(&fatal);
  strcpy(msgstr," LBCC2030: Unexpected end of source");
  scrwrt("+W",msgstr);
  return;
/*
 *  here if declaration keyword during set parsing.
 *  okay if not an empty set.
 */
  zz1900:;
  if (nstelt==0) {
    inperr(&nftl);
    strcpy(msgstr," LBCC1020: Empty set not allowed");
    scrwrt("+W",msgstr);
  }
  return;
}
/*  last record of prsset.c****** */
