/*  first record of getcnf.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"

int abs();
/*
 * *******************************************************
 *  subroutine getcnf
 * 
 *       get cnf formulation for generate step
 *       from variables and arrays trxxxxxx
 *       of translate step
 *       introduce k copies of rows for ONLYCOLS option
 *       where k = number of row entries
 *
 *   output:  if succss = 1: cnf formulation in layer 1
 *               succss = 0: problem could not be found
 * 
 *  caution:  matrix rows only are read and stored.
 * 
 * *******************************************************
 * 
 */
void getcnf() {
/*
 */
  static long i,j,js,jx,k,m;
/*
 */
  void wrtcnf();
/*
 *  minimization flag
 */
  optimz = cstflg;
/*
 *  problem name
 */
  strcpy(&prbnam_(1,1),trprbnam);
/*
 *  error if too many columns
 */
  if (trncols>=colmax) {
    printf("*************************************\n");
    printf("Too many columns in matrix formulation\n");
    printf("Stop decomposition process\n");
    printf("*************************************\n");
    fprintf(errfil,"*************************************\n");
    fprintf(errfil,"Too many columns in matrix formulation\n");
    fprintf(errfil,"Stop decomposition process\n");
    fprintf(errfil,"*************************************\n");
    succss = 0;
    return;
  }
/*
 *  initialize column count
 */
  ncols = trncols;
/*
 *  column information: colnam including delete option, 
 *  cvatf, trucst, falcst
 */
  for (j=1;j<=trncols;j++) {
    strcpy(&colnam_(1,j),&trcolnam_(1,j));
    strcpy(&colnam_(58,j),&trcolnam_(58,j));
    cvatf_(j) = trcvatf_(j);
    trucst_(j)=trtrucst_(j);
    falcst_(j)=trfalcst_(j);
  }
/*
 *  process rows
 *
 *  error if too many rows, assuming no parallel rows added
 */
  if (trnrows>=rowmax) {
    printf("*************************************\n");
    printf("Too many rows in matrix formulation\n");
    printf("Stop decomposition process\n");
    printf("*************************************\n");
    fprintf(errfil,"*************************************\n");
    fprintf(errfil,"Too many rows in matrix formulation\n");
    fprintf(errfil,"Stop decomposition process\n");
    fprintf(errfil,"*************************************\n");
    succss = 0;
    return;
  }
/*
 *  error if too many nonzeros
 */
  if (trnanzs>=anzmax) {
    printf("*************************************\n");
    printf("Too many nonzeros in matrix formulation\n");
    printf("Stop decomposition process\n");
    printf("*************************************\n");
    fprintf(errfil,"*************************************\n");
    fprintf(errfil,"Too many nonzeros in matrix formulation\n");
    fprintf(errfil,"Stop decomposition process\n");
    fprintf(errfil,"*************************************\n");
    succss = 0;
    return;
  }
/*
 *  get row data
 */
  nrows = 0;
  nanzs = 0;
  for (i=1;i<=trnrows;i++) { /* begin for i loop */ 
    if ((mincutflg == ONLYCOLS) &&
        (trnzamar_(i) >= 3)) {    /* changed '3' to '2' 10/29/2007 */
                                  /* changed back to '3' 1/12/2007 */
     /* use a total of k identical copies of row i to prevent
      * selection as cut row in any minimum cut set
      *
      * rows with one entry are not treated 
      * since a cut involving a row with 1 entry cannot occur
      */
      k = trnzamar_(i);
     /* k value suffices since:
      * if k identical rows are placed in the cut, then
      * there is alternate case of k-1 cut cols, which contradicts
      * cut set minimality
      */
      if (k > cutmax) {
        k = cutmax + 1; /* k suffices to prevent selection of
                         * all identical rows in cut set
                         */
      }
      if (k+nrows > rowmax) {
        printf("rowmax too small for option ONLYCOLS\n");
        printf("Stop\n");
        fprintf(errfil,"rowmax too small for option ONLYCOLS\n");
        fprintf(errfil,"Stop\n");
        succss = 0;
        return;
      }
      if (k*trnzamar_(i)+nanzs > anzmax) {
        printf("anzmax too small for option ONLYCOLS\n");
        printf("Stop\n");
        fprintf(errfil,"anzmax too small for option ONLYCOLS\n");
        fprintf(errfil,"Stop\n");
        succss = 0;
        return;
      }
    } else {
      k = 1;
    }
    /* create k rows equal to row i of tramatrw */
    for (m=1; m<=k; m++) {
      nrows++;

      /* row name */

      if (m == 1) {
        strcpy(&rownam_(1,nrows),&trrownam_(1,i));
      } else {
        sprintf(&rownam_(1,nrows),"parallel.%s",&trrownam_(1,i));
        if (strlen(&rownam_(1,nrows)) > 52) {
          printf("row name becomes too large\n");
          printf("due to 'parallel' prefix\n");
          printf("Stop\n");
          fprintf(errfil,"row name becomes too large\n");
          fprintf(errfil,"due to 'parallel' prefix\n");
          fprintf(errfil,"Stop\n");
          succss = 0;
          return;
        }
      }
      /* copy row options */
      strcpy(&rownam_(54,nrows),&trrownam_(54,i));

      /* row entries */

      ptamar_(nrows)=nanzs;
      nzamar_(nrows)=trnzamar_(i);
      for (jx=1;jx<=trnzamar_(i);jx++) {
        js = tramatrw_(jx+trptamar_(i));
        j = abs(js);
        if (js > 0) {
          amatrw_(jx+ptamar_(nrows)) =  trcolusx_(j);
        } else {
          amatrw_(jx+ptamar_(nrows)) = -trcolusx_(j);
        }
      }
      nanzs += trnzamar_(i);
    }    
  } /* end of for i loop */
/*
 *  initialize ncls, nrws, nnzs for layer 1
 */
  ncls_(1) = ncols;
  nrws_(1) = nrows;
  nnzs_(1) = nanzs;

  succss = 1;
/*
 *  for debugging purposes, uncomment wrtcnf() command
 *  and obtain matrix formulation on screen
 */
/*  wrtcnf(); */
/*
 */
  return;
}
/*  last record of getcnf.c ****** */
  

