/*  first record of lpxdyn.c***** */
#include<stdio.h>
#include<stdlib.h>
#include"lpxexts.h"
#include"lpxfdefs.h"
/*
 * flag for lpx allocation
 * must be initialized to 0
 */
extern long lpxalcflg;
/* **********************************************************
 */
void lpxdyn_alloc() {
/*
 *  memory allocation for lp execution
 *  all relevant lpx parameters must be defined
 *  for definition of these parameters from xpoint_() array, 
 *  see command ALC DIM in lpexec()
 */
  void error();
/*
 *  reset allocation flag and
 *  check that no allocation exists
 */
  if (lpxalcflg==0) {
    lpxalcflg = 1;
  } else {
    error("lpxdyn_alloc","102");
  }
/*
 */
  if((memr   = (double*) malloc((lenr8) * sizeof(double)))==NULL) goto zz100;
  if((memi   = (long  *) malloc((leni4) * sizeof(long  )))==NULL) goto zz100;
  if((b      = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((bascb  = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((baslb  = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((basub  = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((betar  = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((blow   = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((cola   = (double*) malloc((maxcol) * sizeof(double)))==NULL) goto zz100;
  if((uzero  = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((xbzero = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((yq     = (double*) malloc((maxeq) * sizeof(double)))==NULL) goto zz100;
  if((basis  = (long  *) malloc((maxeq) * sizeof(long  )))==NULL) goto zz100;
  if((coli   = (long  *) malloc((maxcol) * sizeof(long  )))==NULL) goto zz100;
  if((rowtyp = (long  *) malloc((maxeq) * sizeof(long  )))==NULL) goto zz100;
  if((status = (long  *) malloc((maxvar) * sizeof(long  )))==NULL) goto zz100;
  return;
  zz100:;
/*
 * insufficient memory available for allocation
 */
  printf(
   "Insufficient memory available for lpx allocation\n");
  printf(
   "Must reduce problem size or increase memory\n");
  printf(
   "Stop\n");
  fprintf(errfil,
   "Insufficient memory available for lpx allocation\n");
  fprintf(errfil,
   "Must reduce problem size or increase memory\n");
  fprintf(errfil,
   "Stop\n");
  exit(1); 
}
/* **********************************************************
 */
void lpxdyn_free() {
/*
 *  memory de-allocation
 */
  void error();
/*
 *  reset allocation flag and
 *  check that allocation exists
 */
  if (lpxalcflg==1) {
    lpxalcflg = 0;
  } else {
    error("lpxdyn_free","102");
  }
/*
 */
  free(memr   );
  free(memi   );
  free(b      );
  free(bascb  );
  free(baslb  );
  free(basub  );
  free(betar  );
  free(blow   );
  free(cola   );
  free(uzero  );
  free(xbzero );
  free(yq     );
  free(basis  );
  free(coli   );
  free(rowtyp );
  free(status );
  return;
}
/*  last record of lpxdyn.c****** */
