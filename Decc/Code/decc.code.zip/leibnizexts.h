/*  first record of leibnizexts.h***** */
/*
 *  element names and equivalent integers
 */
/*
 *  index limits of predicates
 */
/*
 *  predicate use with parentheses
 */
/*
 *  extern definitions of predicates
 */
/*
 *  propositional variables
 */
extern long sunshine;
extern long rain;
extern long umbrella;
extern long x;
extern long y;
extern long z;
extern long w;
extern long xsunshine;
extern long xrain;
extern long xumbrella;
extern long xx;
extern long xy;
extern long xz;
extern long xw;
extern long j;
extern long rain1;
/*  last record of leibnizexts.h***** */
