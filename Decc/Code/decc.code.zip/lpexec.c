/*  first record of lpexec.c***** */
/*
 * ******************************************************
 *  module lp execution
 * 
 *  purpose: executes the lp package xmp
 * 
 *  calling sequence:
 *      lpexec
 *        all xmp routines
 * 
 * 
 * *******************************************************
 * 
 * 
 * *******************************************************
 *  subroutine lpexec
 *  parameters: xcomnd = character string telling command
 *              xpoint = integer*4 vector with 8 entries
 *              xvalue  = real*8 vector with 8 entries
 *              interpretation of xpoint and xvalue depends
 *              on xcomnd
 * 
 *  note:       the lp formulation passed into this
 *              routine assumes maximization, in agreement
 *              with xmp maximization
 * 
 * *******************************************************
 * 
 */
#include<string.h>
#include<stdio.h>
#include"lpxdefs.h"
#include"lpxfdefs.h"
void error();
void xmaps();
void xaddaj();
void xaddub();
void xstart();
void xpriml();
void xdual();
void xgetub();
void putlen();
void getcom();
void lpexec(char *xcomnd,long *xpoint,double *xvalue) {
/*
 */
  #define xpoint_(i)  xpoint[(i-1)]
  #define xvalue_(i)  xvalue[(i-1)]
/*
 *     below are all xmp variables not listed in lpxcom
 * 
 */
  static double bound;
  static double cj,lj,uj,z;
  static long bndtyp,collen,colmax,dfeasq;
  static long dterm,dunbr;
  static long factor,iterd;
  static long iter1,iter2,look,m;
  static long maxa,maxm,maxn,n,ntype2;
  static long pick,print,termin,unbddq;
  static long mapi[10],mapr[10];
  static long scode,idno,ispec,jspec;
/*
 *     the variables below have the same interpretation
 *     as those of the xmp common blocks xmpcom and
 *     xmplen. the values are transferred between
 *     this routine and xmp using subroutines getcom
 *     and putlen of file xgetput.f.
 * 
 */
  static double big,small,zl,zlc,eps1,eps2,eps3,eps4;
/*
 */
  static long leni,lenmi,lenmr,lenr;
/*
 */
  void lpxdyn_alloc();
  void lpxdyn_free();
/*
 *  local variables
 */
  static long detflg;
  static long i,it,iz,j,nfrac,rndup,rup;
  static double deltaz,xdist,mxdist,zbnd,zcur,zr;
/*
 *  summary of lpexec commands
 *                     purpose             when called
 *  alc dim  allocate lpx memory        once at beg of lp exec
 *  get dim  compute total memory use   at any time
 *  put dev  put error/log device no.   at any time
 *  beg xmp_ begin  lpx for one lp      once for each lp
 *  beg col |                           for each column
 *  put obj |put column data            for each column
 *  put col |                           for each col entry
 *  end col_|                           for each column
 *  put bnd  put bound on column        for each column
 *  put rhs  put rhs                    for each rhs entry
 *  put bas  put basis                  for each basic variable
 *  put nbs  put nonbasis               for each nonbasic variable
 *  fac bas  factorize basis            for each initial basis use
 *  sol pml  solve by primal s. m.      for each primal problem
 *  sol dul  solve by dual s. m.        for each dual problem
 *  sol ip   solve ip                   for each ip
 *  get dul  get dual solution          for each row
 *  get sol  get solution               for each solution value
 *  get sts  get status of variable     for each variable
 *  rst sts  restore status and
 *           basis of variable          for each variable
 *  get zvl  get objective value        for each solved problem
 *  fre dim  release lpx memory         once at end of lp exec
 *
 *  carry out command
 * 
 * -----------------------------------------------------
 *  allocate memory and initialize parameters
 * -----------------------------------------------------
 */
  if (strcmp(xcomnd,"ALC DIM")==0) {
/*
 *  allocate memory for lpx computations
 *  
 *  requires:
 *     xpoint_(4) = max number of structural variables
 *     xpoint_(5) = max number of equations
 *     xpoint_(6) = max number of nonzeros in matrix
 *     xpoint_(7) = iafac (must be in range 3 - 10)
 *                  inversion control factor
 *  returns:
 *     xpoint_(8) = total memory requirements
 *     detflg = 0 (print error messages only)
 *
 *  initialize error variables
 */
    xerror=0;
    fatl=3;
/*
 *  store desired dimensions in maxstr,maxeq,
 *  maxvar,maxcol,lenr8,leni4
 */
    maxstr = xpoint_(4);
    maxeq  = xpoint_(5);
    maxnz  = xpoint_(6);
    iafac  = xpoint_(7);
    if (iafac < 3) {
      iafac = 3;
    };
    if (iafac > 10) {
      iafac = 10;
    };
/*
 *  compute remaining parameters maxvar,maxcol,leni4,lenr8
 */
    maxvar = maxstr + maxeq;
    maxcol = maxeq;
    leni4  = maxvar +
        6*maxeq +
        maxnz +
        10 +
        2*iafac*(maxeq*(maxnz/maxstr+1));/* is 2*ia qty */
        lenr8  = 3*maxvar +
        maxeq +
        maxnz +
        8 +
        iafac*(maxeq*(maxnz/maxstr+1)); /* is iar qty */
/*
 *  allocate memory
 */
    lpxdyn_alloc();
/*
 *  transfer dimensions to xmp variables
 */
    colmax=maxcol;
    maxa=maxnz;
    maxm=maxeq;
    maxn=maxvar;
    leni=leni4;
    lenr=lenr8;
    lenmi=10;
    lenmr=10;
/*
 *  transfer leni,lenmi,lenmr,lenr information to xmp
 */
    putlen(&leni,&lenmi,&lenmr,&lenr);
/*
 *  compute xpoint_(8) = total memory requirements 
 */
    xpoint_(8)=85*maxm+4*maxn+12*colmax+
        8*lenr+4*leni;
/*
 *  handling of error messages
 * 
 *  in this routine:
 *  error messages are handled using the files 
 *  fioerr, fiolog. 
 *  in xmp: 
 *  the files fioerr, fiolog here correspond to ioerr 
 *  and iolog in xmp
 *
 *  the files fioerr and fioerr are set here equal
 *  to the file errfil, which must be defined and opened
 *  in the routine calling lpexec()  
 */
    fioerr = errfil;
    fiolog = errfil;
/*
 *  print error messages only
 */
    detflg = 0;
    return;
  }
/*
 * -----------------------------------------------------
 *  get dimension of (overall) memory
 * -----------------------------------------------------
 */
  if (strcmp(xcomnd,"GET DIM")==0) {
/*
 *  compute xpoint_(8) = total memory requirements 
 */
    xpoint_(8)=85*maxm+4*maxn+12*colmax+
        8*lenr+4*leni;
/*
 */
    return;
  }
/*
 * -----------------------------------------------------
 *  put devices for error messages and log
 * -----------------------------------------------------
 */
  if (strcmp(xcomnd,"PUT DEV")==0) {
/*
 *  caution: xpoint_(1) and xpoint_(2) are not used
 * 
 *  store print value, which determines which 
 *  messages are to written.
 * 
 *  print = 0  print error messages only
 *        = 1  print termination condition messages
 *        = 2  print objective function value after
 *             each basis factorization
 *        = 3  print log information at every iteration
 */
    print=xpoint_(3);
    if (print==0) {
      detflg=0;
    } else {
      detflg=1;
    }
    return;
  }
/*
 * --------------------------------------------------------
 *  begin xmp
 * --------------------------------------------------------
 */
  if (strcmp(xcomnd,"BEG XMP")==0) {
/*
 *  initialize the number of rows m and the number of columns n
 */
    m=xpoint_(1);
    n=xpoint_(2);
/*
 */
    if (((m>maxm)||(n>maxn))||
        (xpoint_(3)>maxa)) {
/*
 *  lp is too big for current xmp dimensions. 
 *  set xpoint_(1) = 0,
 *  store array limits in xpoint_(6-8), and return
 */
      xpoint_(1)=0;
      xpoint_(6)=maxm;
      xpoint_(7)=maxn;
      xpoint_(8)=maxa;
      return;
    }
/*
 *  allow for lower and upper bounds on variables.
 */
    bndtyp=4;
/*
 *  factor is the re-factorization frequency.
 */
    factor=50;
/*
 *  look controls partial pricing.
 */
    look=n/5;
    if (look<200) {
      look=200;
    }
    if (look>1000) {
      look=1000;
    }
/*
 *  pick controls multiple pricing.
 */
    pick=5;
/*
 *  arrange hidden data structure
 */
    xmaps(&bndtyp,fioerr,fiolog,&print,
        mapi,mapr,&maxa,&maxm,&maxn,memi,memr);
/*
 *  get values defined in xmaps for the xmp variables of
 *  common block xmpcom
 */
    getcom(&big,&small,&zl,&zlc,&eps1,&eps2,&eps3,&eps4);
/*
 *  reset n to 0 for put col calls
 */
    n=0;
/*
 */
    return;
  }
/*
* -------------------------------------------------------
 *  input column
* -------------------------------------------------------
 */
  if (strcmp(xcomnd,"BEG COL")==0) {
/*
 *  begin column
 *  check column index
 */
    if (xpoint_(1)!=n+1) {
      printf("\nLPEXEC: BEG COL index error");
      fprintf(fioerr,"\nLPEXEC: BEG COL index error");
      printf("\nInput = %ld",xpoint_(1));
      fprintf(fioerr,"\nInput = %ld",xpoint_(1));
      printf("\nInternal index = %ld",n+1);
      fprintf(fioerr,"\nInternal index = %ld",n+1);
      goto zz995;
    }
    collen=0;
    return;
  }
/*
 * -----------------------------------
 */
  if (strcmp(xcomnd,"PUT OBJ")==0) {
/*
 *  put objective function coefficient
 *  check column index
 */
    if (xpoint_(1)!=n+1) {
      printf("\nLPEXEC: PUT OBJ index error");
      fprintf(fioerr,"\nLPEXEC: PUT OBJ index error");
      printf("\nInput = %ld",xpoint_(1));
      fprintf(fioerr,"\nInput = %ld",xpoint_(1));
      printf("\nInternal index = %ld",n+1);
      fprintf(fioerr,"\nInternal index = %ld",n+1);
      goto zz995;
    }
    cj=xvalue_(1);
    return;
  }
/*
 * -----------------------------------
 */
  if (strcmp(xcomnd,"PUT COL")==0) {
/*
 *  put column coefficient
 *  check column index
 */
    if (xpoint_(1)!=n+1) {
      printf("\nLPEXEC: PUT COL index error");
      fprintf(fioerr,"\nLPEXEC: PUT COL index error");
      printf("\nInput = %ld",xpoint_(1));
      fprintf(fioerr,"\nInput = %ld",xpoint_(1));
      printf("\nInternal index = %ld",n+1);
      fprintf(fioerr,"\nInternal index = %ld",n+1);
      goto zz995;
    }
    collen=collen+1;
    coli_(collen)=xpoint_(2);
    cola_(collen)=xvalue_(1);
    return;
  }
/*
 * -----------------------------------
 */
  if (strcmp(xcomnd,"END COL")==0) {
/*
 *  end column
 *  check column index
 */
    if (xpoint_(1)!=n+1) {
      printf("\nLPEXEC: END COL index error");
      fprintf(fioerr,"\nLPEXEC: END COL index error");
      printf("\nInput = %ld",xpoint_(1));
      fprintf(fioerr,"\nInput = %ld",xpoint_(1));
      printf("\nInternal index = %ld",n+1);
      fprintf(fioerr,"\nInternal index = %ld",n+1);
      goto zz995;
    }
    xaddaj(&cj,cola,coli,&collen,&colmax,fioerr,
        &idno,mapi,mapr,memi,memr,&n);
    return;
  }
/*
 * --------------------------------------------------------
 *  put bound on variable
 *  xvalue >=  1.0e10 means +infinity
 *         <= -1.0e10 means -infinity
 * --------------------------------------------------------
 */
  if (strcmp(xcomnd,"PUT BND")==0) {
/*
 *  put lower and upper bound on variable jspec
 */
    jspec=xpoint_(1);
    if (xvalue_(1)>(-1.0e10)) {
      lj=xvalue_(1);
    } else {
      lj=-big;
    }
    if (xvalue_(2)<(1.0e10)) {
      uj=xvalue_(2);
    } else {
      uj=big;
    }
    xaddub(&bndtyp,fioerr,&jspec,&lj,mapi,mapr,memi,memr,&uj);
    return;
  }
/*
 * --------------------------------------------------------
 *  put rhs
 * --------------------------------------------------------
 */
  if (strcmp(xcomnd,"PUT RHS")==0) {
/*
 *  put rhs for row ispec
 */
    ispec=xpoint_(1);
    b_(ispec)=xvalue_(1);
    return;
  }
/*
* -----------------------------------------------------
 *  put basis
* -----------------------------------------------------
 */
  if (strcmp(xcomnd,"PUT BAS")==0) {
/*
 *  put basis (variable jspec becomes basis variable number ispec)
 */
    jspec=xpoint_(1);
    ispec=xpoint_(2);
    basis_(ispec)=jspec;
    status_(jspec)=ispec;
    return;
  }
/*
* ------------------------------------------------------
 *  put nonbasis
* ------------------------------------------------------
 */
  if (strcmp(xcomnd,"PUT NBS")==0) {
/*
 *  put nonbasis bound for variable jspec
 */
    jspec=xpoint_(1);
    status_(jspec)=xpoint_(2);
    return;
  }
/*
* -------------------------------------------------------
 *  factorize basis
* -------------------------------------------------------
 */
  if (strcmp(xcomnd,"FAC BAS")==0) {
/*
 *  factorize basis
 */
    xstart(b,bascb,basis,baslb,basub,
        &bndtyp,&bound,
        cola,coli,&colmax,fioerr,
        &m,mapi,mapr,&maxm,&maxn,memi,memr,
        &n,&ntype2,&scode,status,
        uzero,xbzero,&z);
/*
 */
    if (scode!=1) {
      printf(
          "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
      fprintf(fioerr,
          "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
      goto zz995;
    }
    return;
  }
/*
* -------------------------------------------------------
 *  solve by primal simplex method
* -------------------------------------------------------
 */
  if (strcmp(xcomnd,"SOL PML")==0) {
/*
 *  solve by primal simplex method
 */
    zz105:;
    xpriml(b,bascb,basis,baslb,basub,&bndtyp,&bound,
        cola,coli,&colmax,
        &factor,fioerr,fiolog,&iter1,&iter2,
        &look,&m,mapi,mapr,&maxm,&maxn,memi,memr,
        &n,&ntype2,&pick,&print,status,&termin,&unbddq,
        uzero,xbzero,yq,&z);
/*
 *  record termination code
 */
    xpoint_(1)=termin;
    if (termin!=1) {
      printf(
         "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
      fprintf(fioerr,
         "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
      if (factor!=25) {
/*
 *  reset refactorization frequency to 25, and try again
 */
        factor=25;
        goto zz105;
      } else {
        goto zz995;
      }
    }
    return;
  }
/*
* -------------------------------------------------------
 *  solve by dual simplex method
 *  switch to primal simplex method if error is detected
* -------------------------------------------------------
 */
  if (strcmp(xcomnd,"SOL DUL")==0) {
/*
 *  reset refactorization frequency to 15
 */
    factor=15;
/*
 *  solve by dual simplex method
 */
    xdual(b,bascb,basis,baslb,basub,betar,&bndtyp,&bound,
        cola,coli,&colmax,&dfeasq,&dterm,&dunbr,&factor,
        fioerr,fiolog,&iterd,&m,mapi,mapr,&maxm,&maxn,
        memi,memr,&n,&ntype2,&print,status,uzero,xbzero,yq,&z);
    if (dterm!=1) {
/*
 *  have error in dual simplex method;
 *  since we will try primal method to continue, we only
 *  write error message if detflg = 1
 */
      if (detflg==1) {
        printf(
            "\nLPEXEC: Error in XDUAL. DTERM = %ld",dterm);
        printf("\nLPEXEC: Eliminate error using XPRIML");
        fprintf(fioerr,
          "\nLPEXEC: Error in XDUAL. DTERM = %ld",dterm);
        fprintf(fioerr,
          "\nLPEXEC: Eliminate error using XPRIML");
      }
/*
 *  factorize basis
 */
      xstart(b,bascb,basis,baslb,basub,
          &bndtyp,&bound,
          cola,coli,&colmax,fioerr,
          &m,mapi,mapr,&maxm,&maxn,memi,memr,
          &n,&ntype2,&scode,status,
          uzero,xbzero,&z);
/*
 */
      if (scode!=1) {
        printf(
           "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
        fprintf(fioerr,
           "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
        goto zz995;
      }
/*
 *  solve by primal simplex method
 */
      xpriml(b,bascb,basis,baslb,basub,&bndtyp,&bound,
          cola,coli,&colmax,
          &factor,fioerr,fiolog,&iter1,&iter2,
          &look,&m,mapi,mapr,&maxm,&maxn,memi,memr,
          &n,&ntype2,&pick,&print,status,&termin,&unbddq,
          uzero,xbzero,yq,&z);
/*
 *  record termination code
 */
      xpoint_(1)=termin;
      if (termin!=1) {
        printf(
         "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
        fprintf(fioerr,
         "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
        goto zz995;
      }
    }
    return;
  }
/*
* -----------------------------------------------------
 *  solve ip by rounding lp solutions
* -----------------------------------------------------
 */
  if (strcmp(xcomnd,"SOL IP ")==0) {
/*
 *  solve lp by primal simplex method, then repeatedly round solution
 *  values and use dual simplex method to re-solve. stop when an all-
 *  integer solution has been found. it is assumed that a basis has
 *  been specified and factorized. as input we require
 *  xvalue_(1) = postulated lower bound on objective function. if the
 *  ip objective function value reaches or falls below this bound,
 *  then we break off computations and declare failure 
 *  by setting xpoint_(1) = 0. 
 *  otherwise we declare success by xpoint_(1) = 1
 * 
 *  if dual simplex method fails: attempt to remedy using primal
 *  simplex method.
 *  if any other routine fails: set xpoint_(1) = 0 to indicate
 *  failure, and return.
 * 
 *  caution: this routine works only for ip problems of the form
 *           min cx s.t. Ax <= b and x 0/1; A 0/1, b>=0 integral
 * 
 */
    zbnd=xvalue_(1);
/*
 *  apply primal simplex method
 */
    xpriml(b,bascb,basis,baslb,basub,&bndtyp,&bound,
        cola,coli,&colmax,
        &factor,fioerr,fiolog,&iter1,&iter2,
        &look,&m,mapi,mapr,&maxm,&maxn,memi,memr,
        &n,&ntype2,&pick,&print,status,&termin,&unbddq,
        uzero,xbzero,yq,&z);
/*
 *  record termination code
 */
    xpoint_(1)=termin;
    if (termin!=1) {
      printf(
         "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
      fprintf(fioerr,
         "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
      xpoint_(1)=0;
      return;
    }
/*
 *  declare failure if integer part of z is .le. zbnd
 */
    iz=z;
    zr=iz;
    if (zr<=zbnd+zl) {
      xpoint_(1)=0;
      return;
    }
/*
 */
    it=0;
    zcur=z;
/*
 *  iterative rounding scheme
 * 
 *  count the number of fractional variables and look for one that is
 *  closest to an integer value. jspec is the index of that variable
 */
    zz50:;
    it=it+1;
    nfrac=0;
    for(i=1; i<=m; i++)  {
      j=basis_(i);
      if (j>n-m) {
        goto zz100;
      }
      if ((xbzero_(i)<=zl)||(xbzero_(i)>=1-zl)) {
        if (xbzero_(i)<=zl) {
          xbzero_(i)=0.0;
        } else {
          xbzero_(i)=1.0;
        }
      } else {
        nfrac=nfrac+1;
        if (xbzero_(i)<=0.5) {
          xdist=xbzero_(i);
          rup=0;
        } else {
          xdist=1.0-xbzero_(i);
          rup=1;
        }
        if ((nfrac==1)||(xdist<mxdist)) {
          jspec=j;
          mxdist=xdist;
          rndup=rup;
        }
      }
    zz100:;}
/*
 * log report
 * 
 */
    if (detflg==1) {
      printf("\nIter. # %ld  ZOPT = %.3f  Pivots: %ld",
          it,z, iterd);
      fprintf(fiolog,"\nIter. # %ld  ZOPT = %.3f  Pivots: %ld",
          it,z, iterd);
      printf("  Fract. var.: %ld  MXDIST = %.3f",
          nfrac, mxdist);
      fprintf(fiolog,"  Fract. var.: %ld  MXDIST = %.3f",
          nfrac, mxdist);
    }
/*
 * integrality test
 * 
 */
    if (nfrac==0) {
      goto zz1050;
    }
/*
 *  if mxdist is at most 0.4, then fix jspec to next integer and
 *  start next iteration
 * 
 */
    zz250:;
    if (mxdist<=(0.4+zl)) {
      if (rndup==0) {
        lj=0.0;
        uj=0.0;
      } else {
        lj=1.0;
        uj=1.0;
      }
      xaddub(&bndtyp,fioerr,&jspec,&lj,mapi,mapr,memi,memr,&uj);
/*
 *  factorize basis
 */
      xstart(b,bascb,basis,baslb,basub,
          &bndtyp,&bound,
          cola,coli,&colmax,fioerr,
          &m,mapi,mapr,&maxm,&maxn,memi,memr,
          &n,&ntype2,&scode,status,
          uzero,xbzero,&z);
/*
 */
      if (scode!=1) {
        printf(
           "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
        fprintf(fioerr,
           "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
        xpoint_(1)=0;
        return;
      }
/*
 *  apply dual simplex method
 */
      xdual(b,bascb,basis,baslb,basub,betar,&bndtyp,&bound,
          cola,coli,&colmax,&dfeasq,&dterm,&dunbr,&factor,
          fioerr,fiolog,&iterd,&m,mapi,mapr,&maxm,&maxn,
          memi,memr,&n,&ntype2,&print,status,uzero,xbzero,yq,&z);
      if (dterm!=1) {
/*
 *  have error in dual simplex method;
 *  since we will try primal method to continue, we only
 *  write error message if detflg = 1
 */
        if (detflg==1) {
          printf(
            "\nLPEXEC: Error in XDUAL. DTERM = %ld",dterm);
          printf("\nLPEXEC: Eliminate error using XPRIML");
          fprintf(fioerr,
            "\nLPEXEC: Error in XDUAL. DTERM = %ld",dterm);
          fprintf(fioerr,
            "\nLPEXEC: Eliminate error using XPRIML");
        }
/*
 *  factorize basis
 */
        xstart(b,bascb,basis,baslb,basub,
            &bndtyp,&bound,
            cola,coli,&colmax,fioerr,
            &m,mapi,mapr,&maxm,&maxn,memi,memr,
            &n,&ntype2,&scode,status,
            uzero,xbzero,&z);
/*
 */
        if (scode!=1) {
          printf(
           "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
          fprintf(fioerr,
           "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
          xpoint_(1)=0;
          return;
        }
/*
 *  solve by primal simplex method
 */
        xpriml(b,bascb,basis,baslb,basub,&bndtyp,&bound,
            cola,coli,&colmax,
            &factor,fioerr,fiolog,&iter1,&iter2,
            &look,&m,mapi,mapr,&maxm,&maxn,memi,memr,
            &n,&ntype2,&pick,&print,status,&termin,&unbddq,
            uzero,xbzero,yq,&z);
/*
 *  record termination code
 */
        xpoint_(1)=termin;
        if (termin!=1) {
          printf(
          "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
          fprintf(fioerr,
          "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
          xpoint_(1)=0;
          return;
        }
      }
/*
 *  declare failure if integer part of z is .le. zbnd
 */
      iz=z;
      zr=iz;
      if (zr<=zbnd+zl) {
        xpoint_(1)=0;
        return;
      }
/*
 *  update zcur
 */
      zcur=z;
/*
 *  start another rounding iteration
 */
      goto zz50;
    }
/*
 *  mxdist is strictly between 0.4 and 0.6. try rounding up/down
 *  fractional variable jspec, then select case that produces
 *  the least reduction of the objective function
 * 
 *  round value of variable jspec once up and once down
 */
    rup=1;
    zz550:;
    if (rup==0) {
      lj=0.0;
      uj=0.0;
    } else {
      lj=1.0;
      uj=1.0;
    }
    xaddub(&bndtyp,fioerr,&jspec,&lj,mapi,mapr,memi,memr,&uj);
/*
 *  factorize basis
 */
    xstart(b,bascb,basis,baslb,basub,
        &bndtyp,&bound,
        cola,coli,&colmax,fioerr,
        &m,mapi,mapr,&maxm,&maxn,memi,memr,
        &n,&ntype2,&scode,status,
        uzero,xbzero,&z);
/*
 */
    if (scode!=1) {
      printf(
          "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
      fprintf(fioerr,
          "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
      xpoint_(1)=0;
      return;
    }
/*
 *  apply dual simplex method
 */
    xdual(b,bascb,basis,baslb,basub,betar,&bndtyp,&bound,
        cola,coli,&colmax,&dfeasq,&dterm,&dunbr,&factor,
        fioerr,fiolog,&iterd,&m,mapi,mapr,&maxm,&maxn,
        memi,memr,&n,&ntype2,&print,status,uzero,xbzero,yq,&z);
    if (dterm!=1) {
/*
 *  have error in dual simplex method;
 *  since we will try primal method to continue, we only
 *  write error message if detflg = 1
 */
      if (detflg==1) {
        printf(
          "\nLPEXEC: Error in XDUAL. DTERM = %ld",dterm);
        printf("\nLPEXEC: Eliminate error using XPRIML");
        fprintf(fioerr,
          "\nLPEXEC: Error in XDUAL. DTERM = %ld",dterm);
        fprintf(fioerr,
          "\nLPEXEC: Eliminate error using XPRIML");
      }
/*
 *  factorize basis
 */
      xstart(b,bascb,basis,baslb,basub,
          &bndtyp,&bound,
          cola,coli,&colmax,fioerr,
          &m,mapi,mapr,&maxm,&maxn,memi,memr,
          &n,&ntype2,&scode,status,
          uzero,xbzero,&z);
/*
 */
      if (scode!=1) {
        printf(
         "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
        fprintf(fioerr,
         "\nLPEXEC: Error in XSTART. SCODE = %ld",scode);
        xpoint_(1)=0;
        return;
      }
/*
 *  solve by primal simplex method
 */
      xpriml(b,bascb,basis,baslb,basub,&bndtyp,&bound,
          cola,coli,&colmax,
          &factor,fioerr,fiolog,&iter1,&iter2,
          &look,&m,mapi,mapr,&maxm,&maxn,memi,memr,
          &n,&ntype2,&pick,&print,status,&termin,&unbddq,
          uzero,xbzero,yq,&z);
/*
 *  record termination code
 */
      xpoint_(1)=termin;
      if (termin!=1) {
        printf(
         "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
        fprintf(fioerr,
         "\nLPEXEC: Error in XPRIML. TERMIN = %ld",termin);
        xpoint_(1)=0;
        return;
      }
    }
    if (detflg==1) {
      printf("\n    Minor Iter. with Var. # %ld",
          jspec);
      fprintf(fiolog,"\n    Minor Iter. with Var. # %ld",
          jspec);
      printf("   ZOPT =  %.3f  Pivots: %ld",
          z,iterd);
      fprintf(fiolog,"    ZOPT =  %.3f  Pivots: %ld",
          z,iterd);
    }
/*
 *  evaluate result
 */
    if ((rup==1)||(deltaz>zcur-z)) {
/*
 *  have a better case
 */
      deltaz=zcur-z;
      rndup=rup;
    }
/*
 *  if deltaz = 0.0, accept rounding
 */
    if (deltaz<=zl) {
      zcur=z;
      goto zz50;
    }
    if (rup==1) {
/*
 *  initialize rounding up case
 */
      rup=0;
      goto zz550;
    }
/*
 *  declare failure if integer part of zcur-deltaz is .le. zbnd
 */
    iz=zcur-deltaz;
    zr=iz;
    if (zr<=zbnd+zl) {
      xpoint_(1)=0;
      return;
    }
/*
 *  implement the rounding of variable jspec
 *  if rndup = 1, then must recompute solution
 */
    if (rndup==1) {
      mxdist=0.0;
      goto zz250;
    } else {
/*
 *  have already the correct solution for rndup = 0,
 *  so can start next rounding iteration
 */
      zcur=z;
      goto zz50;
    }
/*
 *  have all integer solution
 */
    zz1050:;
    if (detflg==1) {
      printf("\nIntegral solution found");
      fprintf(fiolog,"\nIntegral solution found");
    }
/*
 *  declare success
 */
    xpoint_(1)=1;
    return;
  }
/*
* -----------------------------------------------------
 *  get dual solution
* -----------------------------------------------------
 */
  if (strcmp(xcomnd,"GET DUL")==0) {
    ispec=xpoint_(1);
    xvalue_(1)=uzero_(ispec);
    return;
  }
/*
* -----------------------------------------------------
 *  get solution
* -----------------------------------------------------
 */
  if (strcmp(xcomnd,"GET SOL")==0) {
    jspec=xpoint_(1);
    xpoint_(2)=status_(jspec);
    if (status_(jspec)>0) {
/*
 *  variable jspec is basic
 */
      xvalue_(1)=xbzero_(status_(jspec));
      return;
    } else {
/*
 *  variable jspec is nonbasic, and hence at upper or lower bound
 */
      xgetub(&bndtyp,fioerr,&jspec,&lj,
          mapi,mapr,memi,memr,&uj);
      if (status_(jspec)==0) {
        xvalue_(1)=lj;
      } else {
        xvalue_(1)=uj;
      }
      return;
    }
  }
/*
* -----------------------------------------------------
 *  get status of variable
* -----------------------------------------------------
 */
  if (strcmp(xcomnd,"GET STS")==0) {
    jspec=xpoint_(1);
    xpoint_(2)=status_(jspec);
    return;
  }
/*
* -----------------------------------------------------
 *  restore status and basis of variable
* -----------------------------------------------------
 */
  if (strcmp(xcomnd,"RST STS")==0) {
    jspec=xpoint_(1);
    status_(jspec)=xpoint_(2);
    if (status_(jspec)>0) {
      ispec=status_(jspec);
      basis_(ispec)=jspec;
    }
    return;
  }
/*
* -----------------------------------------------------
 *  get objective function value
* -----------------------------------------------------
 */
  if (strcmp(xcomnd,"GET ZVL")==0) {
    xvalue_(1)=z;
    return;
  }
/*
* -----------------------------------------------------
 *  release memory
* -----------------------------------------------------
 */
  if (strcmp(xcomnd,"FRE DIM")==0) {
    lpxdyn_free();
    return;
  }
/*
* -----------------------------------------------------
 *  end of commands
 * 
* -----------------------------------------------------
 *  unknown command
* -----------------------------------------------------
 *  command not recognized
 */
  printf("\nLPEXEC: Unknown command =  %s",xcomnd);
  fprintf(fioerr,
    "\nLPEXEC: Unknown command =  %s",xcomnd);
/*
 */
  zz995:;
  error("lpexec","997");
}
/*  last record of lpexec.c****** */
