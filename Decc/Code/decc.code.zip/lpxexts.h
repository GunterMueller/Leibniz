/*  first record of lpxexts.h***** */
extern long maxeq;
extern long maxstr;
extern long maxnz;
extern long maxvar;
extern long maxcol;
extern long lenr8;
extern long leni4;
extern long iafac;
/*
 *  error variables for dynamic allocation
 */
extern long xerror;
extern long fatl;
/*
 *     explanation of the parameter statements:
 * 
 *     maxeq   = maximum number of constraints;
 *     maxstr  = maximum number of structural variables;
 *     maxvar  = maximum number of variables, including
 *               slacks;
 *     maxnz   = maximum number of non-zeros in the matrix,
 *               including slack columns but not including
 *               right-hand-side or objective function;
 *     maxcol  = maximum number of non-zeros in any single
 *               column; (we use maxcol = maxeq since that
 *               suffices)
 *     lenr8   = length of double precision working storage
 *               array;
 *     leni4   = length of integer working storage array.
 *     iafac   = storage factor computed by xmp for ia
 *               (conditions: 3 <= iafac <= 10)
 * 
 * 
 *     see the xmp dictionary for the definitions of the
 *     xmp arrays that are declared below. all other xmp
 *     variables are defined in lpci.f.
 * 
 */
extern double *memr;
/*
 */
extern long *memi;
/*
 */
extern double *b;
extern double *bascb;
extern double *baslb;
/*
 */
extern double *basub;
extern double *betar;
extern double *blow;
/*
 */
extern double *cola;
/*
 */
extern double *uzero;
extern double *xbzero;
extern double *yq;
/*
 */
extern long *basis;
extern long *coli;
/*
 */
extern long *rowtyp;
extern long *status;
/*
 * error files within lp domain
 * fioerr = internal file name in lpexec()
 * fiolog = internal file name in lpexec()
 * for details about fioerr, fiolog, see routine lpexec()
 */
extern FILE *fioerr;
extern FILE *fiolog;
/*
 * error file defined outside lp domain
 * errfil =  must be defined and opened in the
 *           routine calling lpexec()
 */
extern FILE *errfil;
/*  last record of lpxexts.h****** */
