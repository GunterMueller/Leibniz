/*  first record of probalg.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*
 * *********************************************************
 *  module problem algorithms/decomposition
 * 
 *  purpose:  determines decomposition and solution
 *            algorithm sequence
 *            for problem in layer 1.
 * 
 *    input:  problem in layer 1, with correct indices and counts.
 *            may have any number of blocks.
 *            ('*' means condition is tested
 *            in fndalg and fnddec).
 *             arrays assumed defined:
 *              - matrix data amatcl, amatrw
 *              - nrows, ncols, nblks
 *              - colnam, rownam, prbnam
 *              - matrix indices as follows:
 *              all columns j active (cifre(j) = 1)
 *              all rows i active (riact(i) = 1)
 *                 remaining indices must be consistent with these
 *                  assignments.
 *              - counts cnxxx, rnxxx
 *          - all cost(j) must be .ge. 0 if optimz = 1
 *              - scale, idxcol, idxrow
 *              - dlclop, dlrwop
 *              - lcllim, ucllim, lrwlim, urwlim
 *              - logrge
 *              - optimz
 *              fndpad only:
 *              - selpgv = 0: decomposition only, no special 
 *                            structure analysis
 *                         1: preprocess w/o elim1,2;
 *                            no decomposition;
 *                            algorithms heuristically selected, 
 *                            no permutation of columns
 *                            remaining cases all with elim1,2 
 *                            preproc.
 *                         2: no decomp.,
 *                            algs. heuristically selected,
 *                            no permutation of fixed columns
 *                         3: no decomp., algs. optimally 
 *                            selected,
 *                            permute fixed columns
 *                         4: decomp., algs. heuristically 
 *                            selected,
 *                            no permutation of fixed columns
 *                         5: decomp., algs. optimally selected,
 *                            no permutation of fixed columns
 *                         6: decomp., algs. optimally selected,
 *                            permute fixed columns
 *                         7: like 4, but decomp. 
 *                            with max block last
 *                         8: like 5, but decomp. 
 *                            with max block last
 *                         9: like 6, but decomp. 
 *                            with max block last
 *   calling sequence:
 * 
 *         fndpad
 *           fndalg         selpgv = 0: not used 
 *                          selpgv > 0:finds component algorithm
 *           combng         LOGIC:  combines nearly negative blocks
 *                                  with block 1
 *                          MATRIX: if selpgv = 0, 10: not used
 *                                  else: combines 2sat blocks 
 *                                  with block 1
 *                                   
 *           fnddec         finds component decomposition
 *           compos         composes two blocks
 *           calrge         computes range data
 * 
 *   caution:  uses layer 2, 3, and 4 for intermediate storage.
 * 
 * ******************************************************
 * 
 * ******************************************************
 *  subroutine fndpad
 * 
 *  purpose:  finds decomposition and solution algorithms for problem
 *            in layer 1
 * 
 *    input:  as specified in module summary.
 * 
 *   output:  succss =  1: decomposition, range data, and solution
 *                         algorithm sequence for problem 
 *                         have been found.
 *            succss =  0: problem has been found 
 *                         to be infeasible.
 *            the succss value is also assigned to flgrge
 * 
 *     caution:  uses layers 2,3, and 4 for intermediate storage.
 * 
 * *******************************************************
 * 
 */
void fndpad() {
/*
 */
  void calrge();
  void combng();
  void compos();
  void fndalg();
  void fnddec();
  void prmfix();
  void scalcl();
/*
 */
  static long j,maxctg,mstar,m2,n,nstar;
  static long n1,n2,q;
  static char d[1+1];
/*
 *  check if problem has never been handled by fndpad
 *  before, or if it has at least two blocks
 */
#ifdef LOGIC
  if ((nblks==1)||
      (flgrge!=-1)||
      (twosat_(1)!=0)||
      (bdfxbl_(1)!=0)) {
    goto zz25;
  }
#endif
#ifdef MATRIX
  if ((nblks==1)||
      (flgrge!=-1)||
      (twosat_(1)!=1)||
      (bdfxbl_(1)!=0)) {
    goto zz25;
  }
#endif
  for(q=2; q<=nblks; q++)  {
    if (twosat_(q)!=-1) {
      goto zz25;
    } else {
      qblock=q;
      flgopt=0;
      fndalg(); 
    }
  }

/*
 *  problem has been preprocessed, but never handled by
 *  fndpad. problem has at least two blocks
 *  if selpgv > 0:
 *    LOGIC:  use combng to combine nearly negative blocks 
 *            with block 1
 *    MATRIX: use combng to combine 2sat blocks 
 *            with block 1
 *            skip if selpgv = 0 or 10
 */
  if (selpgv != 0 && selpgv != 10) {
    combng();
  }

/*
 *  retain maxcut value
 */
  zz25:;
  maxctg=maxcut;
  for(q=1; q<=nblks; q++)  {
    attblk_(q)=0;
  }
/*
 *  if selpgv = 0: prevent decomposition for block 1 
 */
  if (selpgv == 0) {
    attblk_(1) = 1;
  }
/*
 *  initialize pointers for histdc vector and effort bound nstar
 */
  m2=0;
  mstar=0;
  nstar=tt15m1;
  strcpy(d,"D");
/*
 *  find solution algorithm if unspecified
 *
 *  if selpgv = 0, this means setting for all q,
 *  bdfxbl_(q) = number of cols in block q
 */
  zz50:;
  for(q=1; q<=nblks; q++) {
    if (twosat_(q)<0) {
      qblock=q;
      flgopt=0;
      fndalg();
    }
/*
 *  if small number of block columns, skip decomposition attempt
 *    if selpgv = 0 or >= 10: have <= 4 columns
 *              > 0: have <= 2 columns 
 */
    if (((selpgv == 0)||(selpgv >= 10)) && (bdfxbl_(q)<=4)) {
      attblk_(q)=1;
    } else if ((selpgv > 0) && (bdfxbl_(q)<=2)) {
      attblk_(q)=1;      
    }

/*
 *  check if block has chance to improve solution after
 *  decomposition.  if not, set attblk(q) = 1
 */
    if (nblks>=2) {
      if ((q==1)&&
          (bdfxbl_(q)<=(logrge_(q)-3))) {
        attblk_(q)=1;
      }
      if ((q>1)&&
          (q<nblks)&&
          (bdfxbl_(q)<=((logrge_(q)+logrge_(q-1))/2-3))) {
        attblk_(q)=1;
      }
      if ((q==nblks)&&
          (bdfxbl_(q)<=(logrge_(q-1)-3))) {
        attblk_(q)=1;
      }
    }
  }
/*
 *  display current problem status
 */
  zz1050:;
  if (accflg == 1) {
    printf("BLOCK SOLALG BDFXBL LOGRGE "
        "LOGEFF BLCOLS BLROWS\n");
  }
  if ((scrflg == 1) && (accflg == 0)) {
    printf(".");
  }
  if ((scrflg == 1) || (accflg == 1)) {
    fflush(stdout);
  }
  n1=0;
  n2=0;
  for(q=1; q<=nblks; q++)  {
    if (nblks==1) {
      n=bdfxbl_(q);
    } else {
      if (q==1) {
        n=bdfxbl_(q)+logrge_(q);
      } else {
        if ((q>1)&&
            (q<nblks)) {
          n=bdfxbl_(q)+logrge_(q)+logrge_(q-1);
        }
        if (q==nblks) {
          n=bdfxbl_(q)+logrge_(q-1);
        }
        if (logrge_(q-1)==2) {
          n=n-1;
        }
        if (logrge_(q-1)>=3) {
          n=n-2;
        }
      }
    }
    if (accflg == 1) {
      printf(" %3ld%7ld%7ld%7ld%7ld%7ld%7ld\n",
          q,twosat_(q),bdfxbl_(q),logrge_(q),n,
          ucllim_(q)-lcllim_(q)+1, urwlim_(q)-lrwlim_(q)+1);
    }
    if ((n>n1)&&
        (attblk_(q)==0)) {
      n1=n;
      qblock=q;
    }
    if (n>n2) {
      n2=n;
    }
  }
/*
 *  no decomposition if 1 <= selpgv <= 3
 */
  if ((selpgv>=1) && (selpgv<=3)) {
    goto zz3550;
  }
/*
 *  update mstar and nstar if better case
 *  if same effort bound but more decomposed,
 *  then consider case to be better
 */
  if ((strcmp(d,"D")==0)&&
      (n2<=nstar)) {
    nstar=n2;
    mstar=m2;
  }
/*
 *  make next decision based on current phase:
 * 'D'=decompose; 'C'=compose
 */
  if (strcmp(d,"D")==0) {
/*
 *  decomposition phase
 *  stop decomposing if no candidate block or no space
 */
#ifdef LOGIC
    if (selpgv==4) {
      n2=8;
    } else {
      n2=4; 
    }
#endif
#ifdef MATRIX
    n2=4;
#endif
    if ((n1<=n2)||
        (nblks==blkmax)) {
      if ((n1>n2)&&
          (nblks==blkmax)) {
        if (scrflg == 1) {
          printf("Analysis limited by available memory\n");
          printf("Should increase blkmax allocation\n");
        }
        fprintf(errfil,"Analysis limited by available memory\n");
        fprintf(errfil,"Should increase blkmax allocation\n");
      }
/*
 *  start composition phase
 */
      strcpy(d,"C");
      goto zz3000;
    } else {
/*
 *  attempt further decomposition
 */
      goto zz2000;
    }
  }
  if (strcmp(d,"C")==0) {
/*
 *  composition phase
 */
    goto zz3000;
  }
/*
 *  decomposition phase
 */
  zz2000:;
/*
 *  have already selected qblock in do 1100 loop for decomposition
 */
  if (accflg == 1) {
    printf("\nAttempt decomposition of block %ld\n",qblock);
  }
/*
 *  determine maxcut value based on number of fixed variables 
 *  for block qblock
 */
  maxcut=min(maxctg,bdfxbl_(qblock)-2);
  fnddec();
/*
 *  restore maxcut value
 */
  maxcut=maxctg;
  if (succss==0) {
    if (accflg == 1) {
      printf("Decomposition of block %ld is not possible\n",qblock);
    }
    attblk_(qblock)=1;
    goto zz1050;
  } else {
    if (accflg == 1) {
      printf("Block %ld has been decomposed\n",qblock);
    }
/*
 *  shift attblk entries
 */
    for(q=nblks-1; q>=qblock; q--)  {
      attblk_(q+1)=attblk_(q);
    }
    attblk_(qblock)=0;
/*
 *  record decomposition of block qblock in history vector histdc
 */
    m2=m2+1;
    histdc_(m2)=qblock;
    goto zz50;
  }
/*
 *  composition phase
 */
  zz3000:;
/*
 *  composition phase
 */
  if ((selpgv > 0)&&(selpgv < 10)) {
    if (selpgv<=6) {

#ifdef LOGIC
/*
 *  have regular decomposition/composition case
 *  compose most recent decomposition until the problem with logeff
 *  value equal to nstar is produced
 */
      if (m2>mstar) {
        qblock=histdc_(m2);
        m2=m2-1;
        if (accflg == 1) {
          printf("Composition of blocks %ld and %ld\n",qblock,qblock+1);
        }
        compos();
        attblk_(qblock)=0;
        goto zz50;
      }
#endif

    } else {
/*
 *  have special decomposition/composition case
 *  compose second-to-last block with last one if the most complex
 *  block is not the last one
 */
      for(q=1; q<=nblks; q++)  {
        if (bdfxbl_(q)>bdfxbl_(nblks)) {
          qblock=nblks-1;
          compos();
          attblk_(qblock)=0;
          goto zz50;
        }
      }
    }
  }
/*
 *  select optimal algorithm under program
 *  version 3, 6, or 9
 */
  zz3550:;
  if ((selpgv==3)||
      (selpgv==6)||
      (selpgv==9)) {
/*
 *  select optimal algorithms
 */
    for(q=1; q<=nblks; q++)  {
      qblock=q;
      flgopt=1;
      fndalg();
    }
  }

#ifdef LOGIC /* range computations */
/*
 *  compute ranges for upper time bound
 */
  if (scrflg == 1) {
    printf("\nPostprocessing\n");
  }
  calrge();
  if (succss==-1) {
/*
 *  range data overflow occurred. compose blocks qblock and qblock+1
 */
    zz3750:;
    compos();
/*
 *  select solution algorithm for new block qblock using heuristics
 */
    flgopt=0;
    fndalg();
/*
 *  recompute range data
 */
    calrge();
    if (succss==-1) {
/*
 *  still more overflow. compose blocks qblock annd qblock+1 causing
 *  the overflow
 */
      goto zz3750;
    }
/*
 *  range data are at hand
 *  select optimal algorithm if so requested
 */
    if ((selpgv==3)||
        (selpgv==6)||
        (selpgv==9)) {
      goto zz3550;
    }
  }
/*
 *  permute fixed columns if problem was found to be
 *  satisfiable and if selpgv is equal to 3, 6, or 9
 */
  if (succss==1) {
    if ((selpgv==3)||
        (selpgv==6)||
        (selpgv==9)) {
      if (accflg == 1) {
        printf("Permute fixed columns\n");
      }
/*
 *  routine prmfix permutes fixed columns of each block
 *  if it above and below a certain size - see routine
 *  for details
 */
      prmfix();
    }
/*
 *  scale fixed columns with zero costs so that
 *  the initial values (= -1) assigned to them in
 *  enufix are likely to lead to satisfiability
 */
    for(j=1; j<=ncols; j++)  {
      if ((cifix_(j)!=0)&&
          (cost_(j)==0)&&
          (cnallp_(j)>cnalln_(j))) {
        scalcl(j);
      }
    }
  }
/*
 *  program generator step completed
 */
  if (scrflg == 1) {
    printf("Program Generator step completed\n");
    if (succss==1) {
      if (realts<1.0e6) {
        printf(
        "Intermediate time bound (sec) = %9.4f\n",realts);
      } else {
        printf(
        "Intermediate time bound (sec) = %9.1e\n",realts);
      }
      printf("  if machine speed (mips) = %ld\n",mspeed);
    }
  }
#endif /* range computations */

#ifdef MATRIX
  j = 1; /* to suppress compiler warning; j is used in LOGIC part */
  succss = 1;
#endif

  return;
}
/*
 * **************************************************************
 *  subroutine calrge
 * 
 *  purpose:  calls ranges during composition phase of fndpad, and
 *            diplays range information.
 * 
 * 
 * **************************************************************
 * 
 */
void calrge() {
/*
 */
  void ranges();
/*
 */
  static long q;
/*
 */
  if (accflg == 1) {
    printf("Compute range data\n");
  }
  ranges();
  flgrge=succss;
  if (succss==0) {
    if (accflg == 1) {
      printf("Problem is unsatisfiable\n");
    }
    return;
  }
  if (succss==-1) {
/*
 *  range data overflow occurred involving block qblock
 */
    if (accflg == 1) {
      printf(
          "Range data overflow occurred involving block q = %ld\n",qblock);
    }
    return;
  }
  if (accflg == 1) {
    printf("Range data computed\n");
    printf("BLOCK BDFXBL   NO. OF RANGE CASES\n");
    q=1;
    if (nblks==1) {
      printf(" %3ld%7ld\n",q,bdfxbl_(1));
    } else {
      printf(" %3ld%7ld    %10ld\n",
          q,bdfxbl_(1),ndrge_(1)*nerge_(1));
      if (nblks>=3) {
        for(q=2; q<=nblks-1; q++)  {
          printf(" %3ld%7ld    %10ld\n",
              q,bdfxbl_(q),ndrgep_(q)*nergep_(q));
        }
      }
      printf(" %3ld%7ld    %10ld\n",nblks,bdfxbl_(nblks),
          ndrge_(nblks-1)*nerge_(nblks-1));
    }
  }
  return;
}
/*
 * *************************************************************
 * 
 *  subroutine combng
 * 
 *  purpose: combines blocks with block 1
 *           LOGIC:  blocks must be nearly negative
 *           MATRIX: blocks must be 2sat
 * 
 * *************************************************************
 * 
 */
void combng() {
/*
 */
  void reshuf();
/*
 */
  static long i,j,nb,q;

#ifdef LOGIC /* BEGIN: nearly negative case */
/*
 *  check for entrance conditions
 */
  if ((nblks<=1)||
      (flgrge!=-1)||
      (twosat_(1)!=0)||
      (bdfxbl_(1)!=0)) {
    error(" combng ","     12 ");
  }
/*
 */
  if (accflg == 1) {
    printf("Combine nearly negative blocks\n");
  }
/*
 */
  nb=nblks;
  qblock=2;
/*
 *  begin of loop through blocks
 */
  zz50:;
  if (qblock<=nb) {
    if ((twosat_(qblock)==0)&&
        (bdfxbl_(qblock)==0)) {
/*
 *  block qblock is nearly negative. combine it with block 1
 *  reset column indices
 */
      for(j=1; j<=ncols; j++)  {
        if (ciblk_(j)==qblock) {
          ciblk_(j)=1;
        }
        if (ciblk_(j)>qblock) {
          ciblk_(j)=ciblk_(j)-1;
        }
      }
/*
 *  reset row indices
 */
      for(i=1; i<=nrows; i++)  {
        if (riblk_(i)==qblock) {
          riblk_(i)=1;
        }
        if (riblk_(i)>qblock) {
          riblk_(i)=riblk_(i)-1;
        }
      }
/*
 *  reset twosat(), bdfxbl(), logrge(), attblk()
 */
      if (qblock<nb) {
        for(q=qblock; q<=nb-1; q++)  {
          twosat_(q)=twosat_(q+1);
          bdfxbl_(q)=bdfxbl_(q+1);
          logrge_(q)=logrge_(q+1);
        }
      }
/*
 *  reduce number of blocks
 */
      nb=nb-1;
      goto zz50;
    } else {
/*
 *  block cannot be combined with block 1
 */
      qblock=qblock+1;
      goto zz50;
    }
  }
/*
 *  check if combining of blocks has taken place
 */
  if (nb<nblks) {
/*
 *  at least one block has been combined with block 1
 *  reset nblks to reduced value in nb
 */
    nblks=nb;
/*
 *  reshuffle problem
 */
    reshuf();
  }
#endif /* END: nearly negative case */

#ifdef MATRIX /* BEGIN: 2sat case */

/*
 *  check for entrance conditions
 */
  if ((nblks<=1)||
      (flgrge!=-1)||
      (twosat_(1)!=1)||
      (bdfxbl_(1)!=0)) {
    error(" combng ","    112 ");
  }
/*
 */
  if (accflg == 1) {
    printf("Combine 2sat blocks\n");
  }
/*
 */
  nb=nblks;
  qblock=2;
/*
 *  begin of loop through blocks
 */
  zz50:;
  if (qblock<=nb) {
    if ((twosat_(qblock)==1)&&
        (bdfxbl_(qblock)==0)) {
/*
 *  block qblock is 2sat. combine it with block 1
 *  reset column indices
 */
      for(j=1; j<=ncols; j++)  {
        if (ciblk_(j)==qblock) {
          ciblk_(j)=1;
        }
        if (ciblk_(j)>qblock) {
          ciblk_(j)=ciblk_(j)-1;
        }
      }
/*
 *  reset row indices
 */
      for(i=1; i<=nrows; i++)  {
        if (riblk_(i)==qblock) {
          riblk_(i)=1;
        }
        if (riblk_(i)>qblock) {
          riblk_(i)=riblk_(i)-1;
        }
      }
/*
 *  reset twosat(), bdfxbl(), logrge(), attblk()
 */
      if (qblock<nb) {
        for(q=qblock; q<=nb-1; q++)  {
          twosat_(q)=twosat_(q+1);
          bdfxbl_(q)=bdfxbl_(q+1);
          logrge_(q)=logrge_(q+1);
        }
      }
/*
 *  reduce number of blocks
 */
      nb=nb-1;
      goto zz50;
    } else {
/*
 *  block cannot be combined with block 1
 */
      qblock=qblock+1;
      goto zz50;
    }
  }
/*
 *  check if combining of blocks has taken place
 */
  if (nb<nblks) {
/*
 *  at least one block has been combined with block 1
 *  reset nblks to reduced value in nb
 */
    nblks=nb;
/*
 *  reshuffle problem
 */
    reshuf();
  }

#endif /* END: 2sat case */

  return;
}
/*  last record of probalg.c****** */
