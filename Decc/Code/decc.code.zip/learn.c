/*  first record of learn.c***** */
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h" 

int abs();

/*
 * *****************************************************
 *  module learning
 * 
 *  purpose: learns rows for given problem in layer 1
 *           using theorems given explicitly by file
 *           or generated randomly.  
 *
 * 
 * input:  problem in layer 1.
 *         arrays assumed defined:
 *       - matrix data amslcl, amslrw
 *       - ncols, nrows, nblks
 *       - colnam, rownam, prbnam
 *       - idxrow, idxcol, idxclx
 *       - dlclop, dlrwop
 *       - matrix indices cixxx, rixxx
 *       - lcllim, ucllim, lrwlim, urwlim, scale, 
 *         twosat must have been computed.
 *       - cost(j) for all columns j; must be nonnegative.
 *
 *         cnf formulation of problem in layer 7
 *
 *       - lrnflg = 1 learn from learn file
 *                = 2 learn from random theorems
 *
 *       - file with theorems (optional). see getthms
 *         for format
 *
 *  caution: matrix counts cnxxx, rnxxx may not be used
 *           since they are overlaid by retained indices.
 *           the theorems must specify all variables that
 *           should be fixed, including atf variables that
 *           are to be fixed at default values. Reason for
 *           this rule: the file containing theorems remains
 *           valid if atf default values are changed.
 *
 *       the following variables must be defined
 *       prior to or at begin of lrnrows execution:   
 *       - nthms if random generation of theorems: 
 *                number of desired theorems
 *                if file of theorems is used: the
 *                number of theorems is determined later 
 *                in getthms 
 *       - thmlen wanted length of theorem in case of 
 *                random theorems
 *       - thmlenmax maximum length of a new row which is
 *                added to problem in layer 7
 *
 *  arrays:
 *  thmmat    matrix with theorems for learning
 *            after calling getthm, memory is
 *            allocated in getthms and freed in lrnrows
 *  ptthmmat  pointer to beginning of a theorem in 
 *            thmmat, memory is allocated in getthms
 *            and freed in lrnrows
 *  cxlbegthm index list of column fixing for given theorem
 *            values and atf default fixing
 *            except for monotone atf fixed to preferred value
 *  cxlthm    current list of fixed variables, initialized to
 *            cxlbegthm
 *  cxlpath   index list of variables fixed in enumeration path,
 *            initialized to cxlbnd of enufx2
 *  pathcase  code 1 (=fixed, alternate value not yet tried)
 *            or code 2 (=fixed, alternate value unsatisfiable)
 *            for each node of cxlpath. initialized to bdcase
 *            of enufx2, is changed by learning 
 *
 *  calling sequence:
 *     lrnrows   learns rows
 *       lrnblk  learn rows for a given theorem in a block
 *
 *  procedures:
 *     lrnblk
 *     lrnrows
 *     addrow
 *     appthm
 *     chksize
 *     fixthm
 *     fixthmcl
 *     freethmcl
 *     getthms
 *     lrnout
 *     mkcxlbegthm
 *     modcvatf
 *     myrand
 *     mysrand
 *     negthmcl
 *     redmat1
 *     redmat2
 *     rstthm
 *     smprow
 *     stefix2lrn
 *     svpath
 *     updciina
 *
 * output:  lrnsucc = -1 problem is unsatisfiable regardless
 *                       of atf column fixing. hence no 
 *                       learning possible.
 *                       layer 1 has original cnf formulation
 *                  =  0 no learning possible
 *                       layer 1 has original cnf formulation
 *                  =  1 layer 1 contains revised cnf formulation
 *                       where at least one learned row
 *                       has replaced an original row or has
 *                       been added 
 *                  =  2 layer 1 contains revised cnf formulation
 *                       where at least one learned row
 *                       has replaced an existing row or has
 *                       been added
 *                       learning process was stopped because
 *                       of rowmax or anzmax limit
 *                  = -2 layer 1 contains original cnf formulation
 *                       no learning has taken place
 *                       learning process was stopped because
 *                       of rowmax or anzmax limit
 *
 * caution: uses layers 2,3 for intermediate storage
 *          range data do not exist
 *
 * *******************************************************
 */
/*eject*/ 
/* 
 * *******************************************************
 *   subroutine lrnrows
 * 
 *  purpose: learns rows. for input/output, see module summary
 *           above.
 *
 *
 *  ==============
 *  update history
 *  ==============
 *  date          where            what/reason
 *  =====================================================
 * ******************************************************
 * 
 */
void lrnrows() {
/*
 */
  long j, q, t;
/*
 */
  void chksize();
  void getatf();
  void getthms();
  void lrnblk(); 
  void mkcxlbegthm();
  void modcvatf();
  void redmat1();
  void redmat2();
  void stscas();
  void trancnf();
  void trancl();
  void tranrw();
  void updciina();
  void xaqlrn();
/*
 *  check if there are at least 2 
 *  and at most blkmax blocks
 */
  if (nblks<=1 || nblks>blkmax) {
    error("lrnrows","102");
  }
/*
 *  all atf columns must be in block 1
 */
   for (j=lcllim_(2);j<=ncols;j++) {
     if (cvatf_(j)!=0) {
       error("lrnrows","104");
     }
   }
/*
 *  initialize lrnsucc, thmlen, thmlenmax
 *  must make sure that thmlen <= ncolsx
 */
   lrnsucc = 0;
   thmlen = 6;
   thmlenmax = 5;
/*
 *  store given cnf row formulation of layer 7 in layer 3
 *  learned cnf rows are to be added to layer 3 cnf rows
 */
  trancnf(c7,c3);
   
/*
 *  make all columns and rows deletable
 *  delete the following columns and rows,
 *  which are not used for learning
 *   - non-atf columns of block 1
 *   - rows of block 1
 *   - rows deletable by user, which have 'D' in rownam
 *   - rows with coefficients connecting two blocks
 *     with index >= 2.
 */
  redmat1();
/*
 *  save updated cl and rw data in layer 2
 *  caution: solut1 of layer 2 is modified later
 *  in this routine
 *           
 */
  trancl(c1,c2);
  tranrw(c1,c2); 

/*
 *  store theorems for learning in thmmat, ptthmmat
 *  caution: theorems must include fixing of all atf
 *           columns, whether or not default value is used
 
 */
  getthms(); 
/*
 *  set up for sat solution procedures used in lrnblk:
 *    set optimz to 0; original value has already
 *    been saved by retain() in optimr
 *    set up column selection combinations in selcas
 */
  optimz = 0;
  stscas();
/*
 *  for each block > 1: 
 *    extract proper part for learning and learn using
 *    all theorems in thmmat
 */
  for(q=2; q<=nblks; q++) {
    qblock = q;
/*
 *  retrieve cl and rw data from layer 2
 */
    trancl(c2,c1);
    tranrw(c2,c1);
/*  
 *  delete columns and rows in blocks >= 2 and != qblock
 */
    redmat2();
/*
 *  adjust cvatf values for block 1
 *  preferred value means best for satisfiability
 *
 *  cvatf  monotone default prefer'd coeffs in
 *  value  in rows  value   value    column
 *         of q?
 *    +1     no      true     -
 *    -1     no      false    -
 *  -----------------------------------------
 *    +2     yes     ignore  true      +1s
 *    -2     yes     ignore  false     -1s
 *  -----------------------------------------
 */
    modcvatf();
/*
 *  update ciina of undeleted columns 
 *  using default cvatf values
 */
    updciina();
/*
 *  check if effective learning is possible
 */
    chksize();
    if (succss==0) {
      goto zz1000;
    }
/*
 *  learn for each theorem in thmmat
 */      
    for (t=1; t<=nthms; t++) {
      if (scrflg == 1) {
        printf("*"); fflush(stdout);
      }
/*
 *  update ciina of undeleted columns 
 *  using default cvatf values
 */
      updciina(); 
/*
 *  construct index list cxlbegthm of fixed columns
 *  for theorem t
 *  caution: uses solut1 in layer 1 for temporary storage
 */
      mkcxlbegthm(t);
/*
 *  learn rows for block q
 */
      lrnblk();
      if (scrflg == 1) {
        printf("\n");
      }
      if (lrnsucc == -1) {
/*
 *  block is unsatisfiable regardless of atf fixing
 *  and user row deletion. hence no learning possible
 */
         
         goto zz2000;
       }
       if (abs(lrnsucc) == 2) {
/*
 *  rowmax or anzmax limits storage of new rows
 *  terminate learning
 */
         goto zz2000;
       }       
    }
/*
 *  end of loop of q blocks
 */
    zz1000:;
  }
/*
 *  done
 */
  zz2000:;
/*  
 *  transfer cnf row formulation in layer 3 to layer 1
 */
  trancnf(c3,c1);
/*
 *  free memory of matrix with theorems
 *  (has been allocated in getthms)
 */  
  free(thmmat);
  free(ptthmmat);
 
/*
 *  restore original value of optimz
 */
  optimz = optimr; 
  return;
}
/*eject*/
/* *******************************************************
 *   subroutine lrnblk
 *
 *  purpose:  learn rows for active part of block qblock 
 *            in layer 1 and append new rows to cnf formulation
 *            in layer 3
 *
 *    input:  - problem in layer 1, all columns and rows
 *              which are not relevant for learning in block
 *              qblock are deleted
 *            - cvatf as described in modcvatf
 *            - cxlbegthm  list columns that have to be fixed
 *              cxlbegthm_() = +j: column j has to be fixed
 *                              to True
 *              cxlbegthm_() = -j: column j has to be fixed
 *                              to False 
 *            - thmlenmax  maximum length of a new row which
 *              is added to problem in layer 3; layer 3 has 
 *              original cnf formulation and possibly any
 *              number of already learned rows 
 *            - optimz = 0
 *            - stscas (selection combinations) already done
 *
 *   arrays:
 *  cxlthm    current list of fixed columns
 *  cxlpath   index list of columns fixed in enumeration path,
 *            initialized to cxlbnd of enufx2
 *  pathcase  code 1 (=fixed, alternate value not yet tried)
 *            or code 2 (=fixed, alternate value unsatisfiable)
 *            for each node of cxlpath. initialized to bdcase
 *            of enufx2, is changed by learning 
 * 
 * output:  lrnsucc = -1 problem is unsatisfiable regardless
 *                       of atf column fixing. hence no 
 *                       learning possible.
 *                  =  0 no learning possible for blocks so far
 *                  =  1 some learning occurred so far
 *                  =  2 some learning occurred so far
 *                       learning process was stopped because
 *                       of rowmax or anzmax limit
 *                  = -2 no learning occurred so far
 *                       learning process was stopped because
 *                       of rowmax or anzmax limit
 * 
 *   caution:  after setup in stefx1:
 *               free matrix is in amslcl and amslrw
 *               free and fixed matrix is in bmslcl
 *               and bmslrw
 * 
 *  ==============
 *  update history
 *  ==============
 *  date          where            what/reason
 *  =====================================================
 * ******************************************************
 * 
 */
void lrnblk() {
/*
 *  local variables:
 *  - state = findpath if problem in layer 1 is solved the
 *            first time
 *          = minmzthm if cxlthm contains an unsatisfiable
 *            fixing of some columns 
 *  - ptfree: pointer to column in cxlthm, all columns with
 *            lower index have still to be minimized
 */
  enum learnstate {findpath,minmzthm};
  enum learnstate state;
  long ptfree;
/*
 */
  void addrow();
  long appthm();
  void enufix();
  void error();
  void freethmcl();
  void fixthmcl();
  void fixthm(); 
  void negthmcl();
  void rstthm();
  void smprow();
  void stefx1();
  void stefx2lrn();
  void svpath();
  void updciina();
  void urinac();
  void xaact();
/*
 *  -------------------------------------------------------
 *  initialization
 *   - set node count for tree enumeration to 0
 *   - copy cxlbegthm into cxlthm
 *   - set state to findpath.
 *  -------------------------------------------------------
 */
  ncount=0;
  rstthm();
  state = findpath;
/*eject*/
/*
 *  -------------------------------------------------------
 *  step 0
 *  update ciina according to cvatf 
 *  in addition, fix columns according to cxlthm 
 *  inactivate all satisfied rows.
 *  -------------------------------------------------------
 */
  zz200:;
  updciina();
  fixthm();
  urinac();
/*eject*/ 
/*
 *  -------------------------------------------------------
 *  step 1
 *  solve sat problem by enufix. 
 *  -------------------------------------------------------
 *
 *  extract submatrix of active columns and active rows i
 *  with rhs1(i)=1;
 *  place into block matrix array ablkcl. ablkrw is not
 *  computed, but row pointers ptablr are established.
 */
  xaact();
/*
 *  setup for enufix; part 1:
 *    lcllmt, ucllmt, lrwlmt, urwlmt, amslcl, amslrw,
 *    bmslcl, bmslrw, rposj, solut2, cxlfix, rhs2.
 */
  stefx1();
/*
 *  setup for enufix, part 2:
 *    rhs3, rxleqz, rxleq1, and if twosat(1) = 1: rxleq2.
 */
  stefx2lrn();
/*
 *  check satisfiability using subroutine enufix.
 */
  succss=0;
/*
 * use cxlbnd_(colmax+1) to check later if enufxz/1 or
 * enufx2 has been used. value = -1 means enufxz/1
 * solve sat problem with enufix
 */
  cxlbnd_(colmax+1) = -1;
  enufix();
  if (state==findpath) {
/*
 */  
    if (succss==1) {
/*
 */    
      if (cxlbnd_(colmax+1)==-1) {
/*
 *  state specifies findpath
 *  problem is satisfiable and solved by enufxz/1
    then no learning possible
 */
        goto zz1000;
      }
/*eject*/
/*
 *  expand cxlthm depending on satisfiability
 *  Step 2a: satisfiable
 *  Step 2b: unsatisfiable    
 */ 
/*
 *  -------------------------------------------------------
 *  step 2a (satifiable)
 *  initialize cxlpath and pathcase
 *  then update cxlthm and pathcase
 *  set ptfree
 *  -------------------------------------------------------
 *
 *  store enumeration path of enufx2 in cxlpath and pathcase
 */
      svpath();
/*
 *  append to cxlthm:
 *  - all case 1 columns preceeding the first case 2 column 
 *    in cxlpath with the respective value
 *  - the first case 2 column with reversed value.
 *  change the first case 2 column to case 0 in pathcase
 *  return 0 if no case 2 column exist.
 */
      if (appthm() == 0) {
/*
 *  have no case 2 column in solution path, no learning
 *  possible
 */
        goto zz1000;
      }
/*
 *  set pointer ptfree to index of the last column in 
 *  cxlthm. all columns with a lower index will be checked
 *  if they can be freed
 */
      ptfree = cxlthm_(colmax+1);
/*
 *  have a theorem in cxlthm that has to be minimized
 */
      state = minmzthm;
      goto zz350;
    }
/*eject*/
/*
 *  -------------------------------------------------------
 *  step 2b (unsatisfiable)
 *  cxlthm is already correct
 *  define cxlpath and pathcase as empty
 *  set ptfree
 *  -------------------------------------------------------
 */
    else {
/*
 *  minimize just theorem
 */
      cxlpath_(colmax+1) = 0;
/*
 *  set pointer ptfree to the index after the last column
 *  in cxlthm, all columns with a lower index will be 
 *  checked if they can be freed.
 */
      ptfree = cxlthm_(colmax+1)+1;
/*
 *  have a theorem in cxlthm that has to be minimized
 */
      state = minmzthm;
      goto zz350;
    }
  }
/*eject*/
/*
 *  -------------------------------------------------------
 *  step 3
 *  know: state = minmzthm
 *  want to minimize a theorem:
 *  if have satisfiability, then previously freed column 
 *  has to be fixed again; free next column.
 *  -------------------------------------------------------
 */
  if (succss == 1) { 
    fixthmcl(ptfree);
  }
  else {
    freethmcl(ptfree);
  }
/*
 *  reverse fixing of first column with index lower than ptfree
 *  and with cvatf /= +-1.
 *  ptfree points to column whose fixing has been changed.
 *  if theorem cannot be minimized, then ptfree = 0.
 */
  zz350:;
  negthmcl(&ptfree);
  if (ptfree != 0) {
    goto zz200;
  }
/*eject*/
/*
 *  -------------------------------------------------------
 *  step 4
 *  have a minimized row:
 *  add row to problem in layer 3. get next theorem, if 
 *  solution path not yet processed resp. empty
 *  -------------------------------------------------------
 */
  if (cxlthm_(colmax+1) == 0) {
/*  
 *  problem is unsatisfiable regardless
 *  of atf column fixing and user row deletion 
 */
    lrnsucc = -1;
    goto zz1000;
  }
  if (cxlthm_(colmax+1) < thmlenmax+ncvatf1) {
/*
 *  have a new row given by cxlthm, add row to
 *  cnf formulation in layer 3
 */
    if (scrflg == 1) {
      printf("."); fflush(stdout);
    } 
    addrow(c3);
    if (abs(lrnsucc)==2) {
/*
 *  rowmax or anzmax reached
 *  cannot store new row
 *  terminate learning
 */
      goto zz1000;
    }
/*
 *  use added last row to simplify rows of
 *  cnf formulation
 */
    smprow(c3);
/*
 *  restore cxlthm to cxlbegthm
 *  append to cxlthm  next fixing from solution path
 */
    rstthm();
    if (appthm() == 0) { 
/*
 *  have processed entire solution path (satisfiable case)
 *  or just the theorem (unsatisfiable case)
 */
      goto zz1000;
    } else {
      ptfree = cxlthm_(colmax+1);
      goto zz350;
    }
  }
  else {
/*
 *  new row too long, terminate learning for block
 */
    goto zz1000;
  }
/*eject*/
/*  
 *  -------------------------------------------------------
 *  step 5
 *  learning process for block qblock finished.
 *  -------------------------------------------------------
 */
  zz1000:;
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void addrow(long l) {
/*
 *  add row defined by cxlthm to cnf formulation in layer l>1
 *  procedure is analogous to getcnf: store row
 *  caution: uses solut4 and solut5 vectors
 *           do NOT use with l = 1
 *
 * output:  lrnsucc =  2 some learning occurred so far
 *                       learning process was stopped because
 *                       of rowmax or anzmax limit
 *                  = -2 no learning occurred so far
 *                       learning process was stopped because
 *                       of rowmax or anzmax limit
 *          row has been added to cnf formulation of layer l
 */
  long j,js,jx,nr;
/*
 */
  if (l==1) {
    error("addrow","102");
  }
/*
 *  no space left for additional row
 */
  if ((nrws_(l)+1) >= rowmax) {
    printf("\n*************************************\n");
    printf("Learning stopped due to limit by rowmax.\n");
    printf("If additional learning is desired,\n");
    printf("increase rowmax by 50 percent.\n");
    printf("Start compile of formulation\n");
    printf("*************************************\n");
    fprintf(errfil,"*************************************\n");
    fprintf(errfil,"Learning stopped due to limit by rowmax.\n");
    fprintf(errfil,"If additional learning is desired,\n");
    fprintf(errfil,"increase rowmax by 50 percent and\n");
    fprintf(errfil,"restart compile of formulation\n");
    fprintf(errfil,"*************************************\n");
  }
/*
 *  no space left for additional row entries
 */ 
  if ((nnzs_(l)+cxlthm_(colmax+1))>=anzmax) {
    printf("\n*************************************\n");
    printf("Learning stopped due to limit by anzmax.\n");
    printf("If additional learning is desired,\n");
    printf("increase anzmax by 50 percent.\n");
    printf("Start compile of formulation\n");
    printf("*************************************\n");
    fprintf(errfil,"*************************************\n");
    fprintf(errfil,"Learning stopped due to limit by anzmax.\n");
    fprintf(errfil,"If additional learning is desired,\n");
    fprintf(errfil,"increase anzmax by 50 percent and\n");
    fprintf(errfil,"restart compile of formulation\n");
    fprintf(errfil,"*************************************\n");
  }
  if (((nrws_(l)+1) >= rowmax)||
      ((nnzs_(l)+cxlthm_(colmax+1))>=anzmax)) {
    if (lrnsucc==1) {
/*
 *  some learning has already taken place
 */
      lrnsucc = 2;
    } else {
/*
 *  no learning has taken place so far
 */
      lrnsucc = -2;
    } 
    return;
  }
/*
 *  expand cxlthm entries into solut5 vector
 */
  for (j=1;j<=ncols;j++) {
    solut5_(j) = 0;  
  }
  for (jx=1;jx<=cxlthm_(colmax+1);jx++) {
    js = cxlthm_(jx);
    j = abs(js);
    if (js>0) {
      solut5_(j) = -1;
    } else {
      solut5_(j) = 1;
    }
  }
/* 
 *  caution: solut5 contains cnf row for current problem
 *           the cnf row has coefficients opposite of
 *           theorem fixing specified by cxlthm
 *           solut5 indices are on compiled level
 *           solut4 indices are on colnam level
 *
 *  move input values from solut5 into solut4 vector,
 *  which then contains the cnf row coefficients for 
 *  the cnf formulation in layer l
 */
  for (j=1;j<=ncols;j++) {
    solut4_(j) = 0;  
  }
  for (jnam=1;jnam<=ncols;jnam++) {
    j = idxcol_(jnam);
    if (solut5_(j) != 0) {
      solut4_(jnam) = scale_(j)*solut5_(j);
    } 
  }
/*
 *  have row in solut4
 *  add that row to cnf formulation
 */
/*
 *  update nonzero count for layer l
 */
  nnzs_(l) += cxlthm_(colmax+1);
  nr = nrws_(l);
  ptamr_(nr+1,l) = ptamr_(nr,l) + nzamr_(nr,l); 
  nrws_(l)++;
  nr =  nrws_(l);
  nzamr_(nr,l) = 0;
  for (jnam=1;jnam<=ncols;jnam++) {
/*
 *  increase nzamr counts
 *  store coefficient in amr
 */
    if (solut4_(jnam)==1) {
      nzamr_(nr,l)++;
      amr_(nzamr_(nr,l)+ptamr_(nr,l),l) = jnam;

    } else if (solut4_(jnam)==-1) {
      nzamr_(nr,l)++;
      amr_(nzamr_(nr,l)+ptamr_(nr,l),l) = -jnam;
    }
  }
  if (nzamr_(nr,l)!=cxlthm_(colmax+1)) {
    error("addrow","302");
  }
/*
 *  define row name
 */
  strcpy(&rwnam_(1,nr,l),"@learn");
  strcpy(&rwnam_(54,nr,l),"000  ");
/*
 */
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
long appthm() {
/*
 *  append all case 1 columns of cxlpath to cxlthm up to
 *  the first case 2 column. add case 2 column to cxlthm 
 *  with reversed value, change the case 2 node in pathcase 
 *  to case 0 node. if no case 2 node exists, return 0. 
 *  otherwise, return 1.
 */
  long j, js, jx;
/*
 *  append all case 1 columns in cxlpath to cxlthm
 *  up to the first case 2 column
 */
  for (jx=1; jx<=cxlpath_(colmax+1); jx++) {
    js = cxlpath_(jx);
    j = abs(js);
    if (pathcase_(j) == 1) {
/*
 *  have case 1 column j
 */
      cxlthm_(colmax+1)++;
      cxlthm_(cxlthm_(colmax+1)) = cxlpath_(jx);
    } else if (pathcase_(j) == 2) {
/*
 *  have first case 2 column j
 */
      goto zz100;
    }
  }
/*
 *  have no case 2 column in the path
 */
  return(0);  
/*
 *  have a case 2 column j in cxlpath_(jx), all preceeding
 *  case 1 columns are already appended to cxlthm.
 *  append case 2 column to cxlthm with reversed value.
 */    
  zz100:;
  cxlthm_(colmax+1)++;
  cxlthm_(cxlthm_(colmax+1)) = -cxlpath_(jx);
  pathcase_(j) = 0;

  return(1);
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void chksize() {
/*
 *  check size of problem to determine
 *  if effective learning is possible
 */
  long i,j,m,q;
/*
 */
  q = qblock;
/*
 *  check number of active rows
 */
  m = 0;
  for (i=lrwlim_(q);i<=urwlim_(q);i++) {
    if (riact_(i)==1) {
      m++;
    }
  }
/*
 *  learning not effective if m <= aggmax active rows
 */
  if (m<=aggmax) {
    succss = 0;
    return;
  }
/*
 *  count number of fixed columns in block q
 */
  m = 0;
  for (j=lcllim_(q);j<=ucllim_(q);j++) {
    if (cifix_(j)!=0) {
      m++;
    }
  }
  if (m<=aggmax) {
/*
 *  learning not effective if m <= aggmax active rows
 */
    succss = 0;
    return;
  }
  succss = 1;
  return;  
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void fixthm() {
/*
 *  fix columns according to cxlthm
 */
  long j,js,jx;
/*
 */
  void icinac();
  void icacin();
/*
 */
  for (jx=1;jx<=cxlthm_(colmax+1);jx++) {
    js = cxlthm_(jx);
    j = abs(js);
    if (ciina_(j)==2) {
/*
 *  j cannot be deleted
 */
      error("fixthm","202");
    }
    if (ciact_(j)==1) {
      icacin(j);
    }
    if (js>0) {
      ciina_(j) = 1;
    } else {
      ciina_(j) = -1;
    }
  }
 return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void fixthmcl(long ptfree) {
/*
 *  fix column cxlthm_(ptfree) to opposite value.
 */
  cxlthm_(ptfree) *= -1;
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void freethmcl(long ptfree) {
/*
 *  remove column cxlthm_(ptfree).
 */
  cxlthm_(ptfree) = cxlthm_(cxlthm_(colmax+1));
  cxlthm_(colmax+1)--;

  return;
}
/*eject*/
/* 
 * *******************************************************
 *   subroutine getthms
 * 
 *  purpose: read theorems from file for learning or
 *           generate theorems randomly
 *
 * input:  lrnflg       = 1: theorems are in learn file
 *                      = 2: theorems are to be generated randomly
 *         lrnthmfil_name  learn file has list of theorems, 
 *                      end of each theorem is marked by a
 *                      star '*', each theorem is a list of 
 *                      variable names (user names) separated
 *                      by one or more spaces and/or new line,
 *                      a minus sign before the variable name 
 *                      selects value false (no space between 
 *                      minus sign and variable name allowed),
 *                      otherwise true
 *         nthms        if random generation of theorems: 
 *                      number of theorems to be generated
 *                      (if file of theorems is used, the number
 *                      of theorems is determined in this routine)
 *         thmlen       number of variables in each randomly 
 *                      generated theorem
 *
 * output: thmmat       matrix with theorems
 *                      random generation: first theorem
 *                      is empty theorem, i.e. no variables
 *                      file of theorems: first theorem is empty
 *                      if file begins with '*'  
 *         ptthmmat_(t) index of first variable of theorem t
 *                      in thmmat for t=1,...,nthms
 *                      ptthmmat(nthms+1) = (index of last
 *                      variable in theorem t) + 1 
 *         nthms        number of theorems stored in thmmat
 *
 * caution: theorems must give fixing of all atf
 *          columns, whether or not default value is used
 *
 *  ==============
 *  update history
 *  ==============
 *  date          where            what/reason
 *  =====================================================
 * ******************************************************
 * 
 */
void getthms() {
/*
 */
  long nvars, rc, vb;
  long i, val, t, k;
  static char tmpstr[128+2];
/*
 */
#define tmpstr_(i) tmpstr[(i-1)]  
/*
 */
  long myrand();
  void mysrand();
/*
 *  initialize nvars and nthms if theorems in learn file:
 *  open theorem file and count number of theorems and
 *  total number of variables 
 */
  if (lrnflg == 1) {
    lrnthmfil = fopen(lrnthmfil_name,"r");
    if (lrnthmfil == NULL) {
      printf("Cannot open learn file %s\n",lrnthmfil_name);
      printf("Stop\n");
      fprintf(errfil,"Cannot open learn file %s\n",
                     lrnthmfil_name);
      fprintf(errfil,"Stop\n");
      lbccexit(1);
    }
/*
 *  count number of theorems and the total number of 
 *  variables in the learn file
 */
    nthms = 0;
    nvars = 0;
    while ((rc=fscanf(lrnthmfil,"%129s",tmpstr)) != EOF) {
      if (rc == 0) {
        error("getthms","102");
      }
      else if (strcmp(tmpstr,"*") == 0) {
        nthms++;
      }
      else {
        nvars++;
      }
    }
    fclose(lrnthmfil);
/*
 *  know lrnflg = 2
 *  initialize nvars for random theorems
 */
  } else {
    nthms = 1;
    nvars = nthms * thmlen;    
  }
/*
 *  allocate memory for matrix thmmat, ptthmmat
 */
  thmmat   = (long*) malloc(nvars*sizeof(long));
  ptthmmat = (long*) malloc((nthms+1)*sizeof(long));
  if (thmmat == NULL || ptthmmat == NULL) {
    printf("\nNot enough memory available\n");
    printf("for learning phase. Stop\n");
    fprintf(errfil,"\nNot enough memory available\n");
    fprintf(errfil,"for learning phase. Stop\n");
    lbccexit(1);
  }
/*eject*/
/*
 *  initialize pointer for first theorem
 */
  ptthmmat_(1)=1;
/*
 *  complete matrix thmmat, ptthmmat
 *
 *  read theorems from learn file
 */      
  if (lrnflg == 1) {

    lrnthmfil = fopen(lrnthmfil_name,"r");
    if (lrnthmfil == NULL) {
      error("getthms","202");
    }
    for (t=1; t<=nthms; t++) {
/*
 *  read next theorem
 */      
      ptthmmat_(t+1) = ptthmmat_(t);
/*
 *  read next variable of current theorem
 */      
      zz305:;
      rc = fscanf(lrnthmfil,"%129s",tmpstr);

      if (rc==0 || rc==EOF) {
        error("getthms","302");
      } 
      else if (strcmp(tmpstr,"*") == 0) {
/*
 *  have read theorem
 */
        goto zz400;
      }
      else {
/*
 *  have variable name, find column index and sign 
 */          
        if (tmpstr_(1) == '-') {
          val = -1;
          vb = 1;
        }
        else {
          val = 1;
          vb = 0;
        }
        for (juser=1; juser<=ncolsx; juser++) {
          jnam=idxclx_(juser);
          for(i=1; i<=27; i++)  {
            if ((tmpstr_(vb+i)=='\0') &&
                ((colnam_(i,jnam)=='\0') ||
                 (colnam_(i,jnam)==' '))) {
/*
 *  have a match
 */
              goto zz355;
            }
            if (tmpstr_(vb+i) != colnam_(i,jnam)) {
/*
 *  do not have a match
 */
              goto zz345;
            }
          }
          zz345:;
        }
/*
 *  have no matching colnam, invalid input
 */
        printf("\nUnknown variable %s in learn file\n",
               tmpstr+vb);
        printf("%s\n Stop\n",lrnthmfil_name);
        fprintf(errfil,"\nUnknown variable %s in learn file\n",
               tmpstr+vb);
        fprintf(errfil,"%s\n Stop\n",lrnthmfil_name);
        lbccexit(1);
/*
 *  have a matching colnam
 */
        zz355:;
        jscan=idxcol_(jnam);
        thmmat_(ptthmmat_(t+1)) = scale_(jscan)*val*jscan;
        ptthmmat_(t+1)++; 
        goto zz305; 
      }
      zz400:;
    }
    fclose(lrnthmfil);
  }
/*
 *  know lrnflg = 2
 *  generate theorems randomly
 */      
  else {
    if (thmlen>ncolsx) {
/*
 *  error, theorem length is not allowed to exceed ncolsx
 */
      error("getthms","202");
    }
    if ((ilrncyc==1)&&
        (ilrnzero==0)) {
/*
 *  learn cycle 1, no zero learn cases
 *  initialize generator of random numbers
 */ 
      mysrand(1);
/*
 *  learn only for empty theorem
 */
      ptthmmat_(2) = 1;
    } else {
/*
 *  learn for nthms theorems
 */
      for (t=1; t<=nthms; t++) {
        ptthmmat_(t+1)=ptthmmat_(t);
/*
 *  use solut4 to determine of a randomly picked 
 *  column has already been selected for the current 
 *  theorem.
 *  set solut4(juser) = 0
 */
        for (juser=1; juser<=ncolsx; juser++) {
          solut4_(juser) = 0;
        }
/*
 *  generate next theorem
 *  fix only columns defined by the user
 */      
        for (k=1; k<=thmlen; k++) {
          juser = myrand(1,ncolsx);
/*
 *  if column has already been selected, then pick column 
 *  with next index that has not yet been selected. 
 */        
          while (solut4_(juser) != 0) {
            juser++;
            if (juser > ncolsx) {
              juser = 1;
            }
          }
/*
 *  mark column juser as selected
 */
          solut4_(juser) = 1;
/*
 *  add column juser to theorem
 */ 
          jscan = idxcol_(idxclx_(juser));
          val = (2*myrand(0,1))-1;
          thmmat_(ptthmmat_(t+1)) = val*jscan;
          ptthmmat_(t+1)++;
        }   
      }
    }
  } /* end of random theorem definition */
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void lrnout() {      
/*
 *  output learned rows in lrnoutfil file
 *  uses cnf row data in layer 1
 */
  long js, jx;
/*
 */
  fprintf(lrnrowfil,"* Learned clauses for problem: %s\n*\n",
          &prbnam_(1,1));
  for (inam=1;inam<=nrows;inam++) {
    if (strncmp(&rownam_(1,inam),"@learn",6)==0) {
/*
 *  inam is a learned row, must be nonzero
 */
      if (nzamar_(inam)<=0) {
        error("lrnout","102");
      }
      for (jx=1;jx<=nzamar_(inam);jx++) {
        js = amatrw_(jx+ptamar_(inam));
        jnam = abs(js);
        if (js<0) {
          fprintf(lrnrowfil,"-");
        } else {
          fprintf(lrnrowfil," ");
        }
        fprintf(lrnrowfil,"%s",&colnam_(1,jnam));
        if (jx<nzamar_(inam)) {
          fprintf(lrnrowfil," |\n");
        } else {
          fprintf(lrnrowfil," . * %s\n*\n",&rownam_(1,inam));
        } 
      }
    }      
  }
  fprintf(lrnrowfil,"* End of learned clauses file\n");
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void mkcxlbegthm(long t) {      
/*
 *  make column index list cxlbegthm of theorem t
 *  this is the initial theorem version
 */
  long j, jx;
/*
 *  set solut1 to ciina
 */
  for (j=1;j<=ncols;j++) {
    solut1_(j) = ciina_(j);
  }
/*
 *  modify solut1 using theorem values
 */
  for (jx=ptthmmat_(t); jx<ptthmmat_(t+1); jx++) {
    if (thmmat_(jx)>0) {
      j = thmmat_(jx);
      if (solut1_(j)!=2) {
        solut1_(j) = 1;
      }
    } else {
      j = -thmmat_(jx);
      if (solut1_(j)!=2) {
        solut1_(j) = -1;
      }
    }
  }
/*
 *  construct cxlbegthm from solut1 values
 */
  cxlbegthm_(colmax+1) = 0;
  for (j=1;j<=ncols;j++) {
    if ((solut1_(j)==1) &&
        (cvatf_(j)!=2)) { 
       cxlbegthm_(colmax+1)++;
       cxlbegthm_(cxlbegthm_(colmax+1)) = j;
    }
    else if ((solut1_(j)==-1) &&
             (cvatf_(j)!=-2)) { 
       cxlbegthm_(colmax+1)++;
       cxlbegthm_(cxlbegthm_(colmax+1)) = -j;
    }
  }
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void modcvatf() {
/*
 *  modify cvatf values to indicate monotonicity and
 *  preferred value within rows of block qblock
 *  if no entries in rows of qblock, delete column
 *
 *  output: modified cvatf values; see table below
 *          ncvatf1 = number of columns j with cvatf(j) = +-1
 *  
 *  cvatf  monotone default prefer'd coeffs in
 *  value  in rows  value   value    column
 *         of q?
 *    +1     no      true     -
 *    -1     no      false    -
 *  -----------------------------------------
 *    +2     yes     ignore  true      +1s
 *    -2     yes     ignore  false     -1s
 *  -----------------------------------------
 */
  long i,is,ix,j,nf,pf,q;
/*
 */
  void icacin();
/*
 */
  q = qblock;
  ncvatf1 = 0;
/*
 *  modify cvatf for columns in blocks 1 and q
 */
  for (j=1;j<=ncols;j++) {
    if ((ciina_(j)!=2) &&
        (nzamac_(j)>0)) {
      pf = 0;
      nf = 0;
      for (ix=1;ix<=nzamac_(j);ix++) {
        is = amatcl_(ix+ptamac_(j));
        i = abs(is);
        if ((riblk_(i)==q) &&
            (riact_(i)==1)) {
          if (is>0) {
            pf++;
          } else {
            nf++;
          }
        } 
      }
      if ((nf==0) &&
          (pf==0)) {
        if (ciact_(j)==1) {
          icacin(j);
        }
        ciina_(j) = 2;
      } else if (nf==0) {
        cvatf_(j) = 2;
      } else if (pf==0) {
        cvatf_(j) = -2;
      }
    }
    if ((cvatf_(j)==1) ||
        (cvatf_(j)==-1)) {
      ncvatf1++;
    } 
  }
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */ 
long myrand(long a, long b) 
{
/* 
 *  generate a random number r with a <= r <= b 
 */
  randseed = ((25173*randseed+13849) % 32767);
  return (long)(a+(randseed%(b-a+1)));
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */ 
void mysrand(long s) 
{
/*
 *  use s as a seed for a new sequence of random numbers 
 */ 
  randseed = (unsigned long)s; 
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */ 
void negthmcl(long *ptfree) {
/*
 *  want to minimize columns of cxlthm with 
 *  index < *ptfree:
 *  find next column for minimization index < *ptfree and
 *  with cvatf /=+-1. fix the column to the reverse value. 
 *  set *ptfree to the respective index in cxlthm. 
 *  if no minimization possible, set *ptfree to 0.
 */
  long j;
/*
 */
  (*ptfree)--;
  while ((*ptfree)>0) {
    j = abs(cxlthm_(*ptfree));
    if (cvatf_(j)==-1 ||
        cvatf_(j)==+1) {
      (*ptfree)--;
    }
    else {
      cxlthm_(*ptfree) *= -1;
      return;
    }
  }
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void redmat1() {
/*
 *  make all columns and rows deletable
 *  delete the following columns and rows,
 *  which are not used for learning
 *   - non-atf columns of block 1
 *   - rows of block 1
 *   - rows deletable by user
 *   - rows with coefficients connecting two blocks
 *     with index >= 2.
 */
  long i,j,jx;
/*
 */
  void icacin();
  void iracin();
  void irinac();
/*
 *  make all columns deletable
 */
  for (j=1;j<=ncols;j++) {
    dlclop_(j) = 1;
  }
/*
 *  make all rows active and deletable
 */
  for (i=1;i<=nrows;i++) {
    if (riina_(i)==1) {
      irinac(i);
    }
    dlrwop_(i) = 1;
  }
/*
 *  delete non-atf columns of block 1
 */
  for (j=1;j<=ucllim_(1);j++) {
    if (cvatf_(j)==0) {
      if(ciact_(j)==1) {
        icacin(j);
      }
      ciina_(j) = 2;
    }
  }
/*
 *  delete rows of block 1
 */
   for (i=1;i<=urwlim_(1);i++) {
     if (riact_(i)==1) {
       iracin(i);
     }
     riina_(i) = 2;
   }
/*
 *  delete rows deletable by user
 */
  for (inam=1;inam<=nrows;inam++) {
    if (rownam_(58,inam)=='D') {
      iscan = idxrow_(inam);
      if (riact_(iscan)==1) {
        iracin(iscan);
      }
      riina_(iscan) = 2;
    }
  }
/*  
 *  delete rows connecting two blocks with index >= 2
 */
  for (i=lrwlim_(2);i<=nrows;i++) {
    if ((nzamar_(i)>0) &&
        (riina_(i)!=2)) {
      for (jx=1;jx<=nzamar_(i);jx++) {
        j = abs(amatrw_(jx+ptamar_(i)));
        if ((ciblk_(j)>=2) &&
            (ciblk_(j)!=riblk_(i))) {
          if (riact_(i)==1) {
            iracin(i);
          }
          riina_(i) = 2;
          goto zz200;
        }
      }
    }
    zz200:;
  }
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void redmat2() {
/*
 *  delete columns and rows in blocks >= 2 and != qblock  
 */
  long i,j,q;
/*
 */
  void icacin();
  void iracin();
/*
 */
  q = qblock;
/*
 *  delete columns outside block q 
 */
  for (j=lcllim_(2);j<=ncols;j++) {
    if (ciblk_(j)!=q) {
      if(ciact_(j)==1) {
        icacin(j);
      }
      ciina_(j) = 2;
    }
  }
/*
 *  delete rows outside block q
 */
  for (i=lrwlim_(2);i<=nrows;i++) {
    if (riblk_(i)!=q) {
      if(riact_(i)==1) {
        iracin(i);
      }
      riina_(i) = 2;
    }
  }
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void rstthm() {
/*
 *  copy cxlbegthm into cxlthm
 */
  long j;
/*
 */
  for (j=1; j<= cxlbegthm_(colmax+1); j++) {
    cxlthm_(j) = cxlbegthm_(j);
  }
  cxlthm_(colmax+1) = cxlbegthm_(colmax+1);
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void smprow(long l) {
/*
 *  use last row of cnf formulation in layer l>1
 *  to simplify rows of that formulation
 *
 * input:   cnf formulation in layer l
 *          solut4  =  encoding of last row of cnf formulation 
 *
 * output:  lrnsucc =  0 no learning possible for blocks so far
 *                  =  1 some learning occurred so far
 *          last row of cnf formulation of layer l,
 *          - has been removed since it is dominated by another
 *            nondeletable row, and/or
 *          - has been used to remove dominated rows, and/or 
 *          - has been kept
 */
  long als,fri,fm1,i,inx,j,js,jx,mct,nls,nr,nz,pt;
/*
 *  check entry conditions:
 *  - cnf formulation is not allowed to be in layer 1
 *  - last row must not be deletable
 *  - must have at least two rows
 */
  if (l==1) {
    error("smprow","102");
  }
  if (rwnam_(58,nrws_(l),l)== 'D') {
    error("smprow","104");
  }
  if (nrws_(l) <= 1) {
    error("smprow","106");
  }
/*
 *  fm1 = flag for removal (=1) of last row
 *  fri = flag for removal (=1) of row i<last
 */
  fri = 0;
  fm1 = 0;
  nr = nrws_(l);

/*  
 *  compare last row with all other rows
 */
  for (i=1; i<=nrws_(l)-1; i++) {
    mct = 0;
    for (jx=1; jx<=nzamr_(i,l); jx++) {
      js = amr_(jx+ptamr_(i,l),l);
      j = abs(js);
      if (js*solut4_(j)>0) {
        mct++;
      }      
    }
/*
 */
    if (mct==nzamr_(i,l)) {
/*
 *  row i is shorter than or equal to last row
 *  if row i is not deletable, record this in fm1
 */
      if (rwnam_(58,i,l)!='D') {
        fm1 = 1;
      }
    } else if (mct==nzamr_(nr,l)) {
/*
 *  row i is longer than last row
 *  make row i empty
 */
      nzamr_(i,l) = 0;
      fri = 1;
    }
  }
/*
 *  save nls = number of entries in last row
 *       als = first entry in that row
 */
    nls = nzamr_(nr,l);
    als = amr_(1+ptamr_(nr,l),l);
/*
 *  evaluate fri and fm1
 */
  if (fm1==1) {
/*
 *  last row is dominated by some row i
 *  delete last row
 */
    nzamr_(nr,l) = 0;
  }
  if ((fm1==1)||
      (fri==1)) {
/*
 *  some row was deleted
 *  realign row information to eliminate empty rows
 */
    inx = 0;
    nrws_(l) = 0;
    nnzs_(l) = 0;
/*
 */
    for (i=1; i<=nr; i++) {
      if (nzamr_(i,l)>0) {
/*
 * row i is nonzero
 */
        inx++;
        nrws_(l)++;
        nz = nzamr_(i,l);
        pt = ptamr_(i,l);
        nzamr_(inx,l) = 0;
        if (inx>1) {
          ptamr_(inx,l) = 
                ptamr_(inx-1,l) + nzamr_(inx-1,l);
        }
        for (jx=1; jx<=nz; jx++) {
/*
 *  skip transfer of element x if last row has just
 *  one entry als and x = -als
 */ 
          if ((nls>1) ||
              (als!=-amr_(jx+pt,l))) {
            nzamr_(inx,l)++;
            nnzs_(l)++;
            amr_(nzamr_(inx,l)+ptamr_(inx,l),l) = 
                    amr_(jx+pt,l);
          }
        }
        if (nzamr_(inx,l)==0) {
/*
 *  reduced row is empty; error, since satisfiable
 */
          error("smprow","302");
        }
/*
 *  update row name if row i has been moved to row inx < i
 */
        if (inx<i) {
          strcpy(&rwnam_(1,inx,l),&rwnam_(1,i,l));
        }   
      }
    }
  }
  if ((nrws_(l)==0) ||
      (nnzs_(l)==0)) {
/*
 *  error, must have at least one row
 */
    error("smprow","304");
  }
/*
 *  determine if learning has taken place
 */
  if ((fm1==0)||
      (fri==1)) {
/*
 *  last row was retained or a row was deleted
 */
    lrnsucc = 1;   
  }
  return;
}
/*eject*/
/*
 * ******************************************************
 *  subroutine stefx2lrn
 * 
 *  purpose:  set up for enufix; used in learning process;
 *            part 2lrn:
 *            rhs3
 *            rxleqz, rxleq1
 *            if twosat(q) = 1:  rxleq2
 *            initialize rhs4 and rhs5 to 0
 * 
 * ******************************************************
 * 
 */
void stefx2lrn() {
/*
 */
  static long q,i,ix,iz,ixx,n1;
/*
 */
  q=qblock;
/*
 *  calculate rhs3 vector
 */
  for(i=1; i<=nrows; i++)  {
    rhs3_(i)=rhs2_(i);
  }
/*
 *  for inactive rows i, set rhs3(i) = 0
 */
  for(i=1; i<=nrows; i++)  {
    if (riina_(i)!=0) {
      rhs3_(i)=0;
    }
  }
/*
 *  compute rxleqz, rxleq1, rxleq2
 */
  iz=0;
  ix=0;
  ixx=0;
  for(i=1; i<=nrows; i++)  {
    if (rhs3_(i)==1) {
      n1=nzamsr_(i);
      if (n1==0) {
        iz=iz+1;
        rxleqz_(iz)=i;
      } else {
        if (n1==1) {
          if ((twosat_(q)==0)&&
              (rposj_(i)==0)) {
            goto zz300;
          }
          ix=ix+1;
          rxleq1_(ix)=i;
        } else {
          if ((twosat_(q)==1)&&
              (n1==2)) {
            ixx=ixx+1;
            rxleq2_(ixx)=i;
          }
        }
      }
    }
    zz300:;
  }
  rxleqz_(rowmax+1)=iz;
  rxleq1_(rowmax+1)=ix;
  rxleq2_(rowmax+1)=ixx;
/*
 *  initialize rhs4 and rhs5 to 0
 */
  for(i=1; i<=nrows; i++)  {
    rhs4_(i) = 0;
    rhs5_(i) = 0;
  }  
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void svpath() {
/*
 *  save solution path cxlbnd, bdvalu, bdcase 
 *  in cxlpath, pathcase
 */
  long j,jx;
/*
 */
  cxlpath_(colmax+1) = 0;
  for (jx=1; jx<=cxlbnd_(colmax+1); jx++) {
    j = cxlbnd_(jx);
    cxlpath_(colmax+1)++;
    cxlpath_(cxlpath_(colmax+1)) = bdvalu_(j)*j;
    pathcase_(j) = bdcase_(j);
  }
  return;
}
/*eject*/
/* ****************************************************
 * ****************************************************
 */
void updciina() {
/*
 *  update ciina using default cvatf values
 */
  long j;
/*
 */
  void icacin();
  void icinac();
/*
 */
  for (j=1;j<=ncols;j++) {
    if (ciina_(j)!=2) {
/*  
 *  j is not deleted
 */
      if (cvatf_(j)==0) {
/*
 *  j is not atf column; make j active
 */
        if (ciina_(j)!=0) {
          icinac(j);
        } 
      } else if (cvatf_(j)>0) {
/*
 *  j is atf column and:
 *      not monotone and default value = 1 or
 *      monotone and preferred value = 1
 *  make j inactive at that value
 */
        if (ciact_(j)==1) {
          icacin(j);
        }
        ciina_(j) = 1;
      } else {
/*
 *  j is atf column and:
 *      not monotone and default value = -1 or
 *      monotone and preferred value = -1 
 *  make j inactive at that value
 */
        if (ciact_(j)==1) {
          icacin(j);
        }
        ciina_(j) = -1;
      }
    }
  }
  return;
}
/*  last record of learn.c***** */
