/*  first record of decc.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*
 *  Leibniz System
 *  Copyright 1990-2015 by Leibniz Company
 *  Plano, Texas, U.S.A.
 *  This program is free software: you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free Software
 *  Foundation, either version 3 of the License, or (at your option) any later
 *  version. The file lgpl.txt has the License statement.
 *
 * ===================================================
 * Decc System  - Callable Decomposition Version decc
 * ===================================================
 *
 *  definition of generator versions
 *
 * Version  (selpgv)
 * ________________________
 *   0    find decomposition; no specialy structure analysis (MATRIX only)
 * ________________________
 *   1    Preprocess w/o ELIM1,2; no decomposition
 *        algorithms heuristically selected  
 *        no permutation of columns
 *
 *   Remaining cases all with elim1,2 preproc.
 *
 *   2    no decomp.; algs. heuristically selected
 *        no permutation of fixed columns
 *   3    no decomp.; algs. optimally selected
 *        permute fixed columns
 *   4    decomp.; algs. heuristically selected
 *        no permutation of fixed columns
 *   5    decomp.; algs. optimally selected 
 *        no permutation of fixed columns
 *   6    decomp.; algs. optimally selected     
 *        permute fixed columns
 *   7    like 4, but decomp. with max block last
 *   8    like 5, but decomp. with max block last
 *   9    like 6, but decomp. with max block last
 *
 *  top programs:
 *    decc          stand-alone decomposition (see deccmain)
 *    decc()        callable decomposition; see decc() code
 *                  for conditions that must be satisfied
 *                  before compiler is called
 *
 */     
/*eject*/
/* ************************************* */
void decc() {
/*
 *  callable version of leibniz decomposition program decc
 *  caution: 
 *   - parameters must have been obtained (see getparm() for
 *   - required information)
 *   - allocation by exdyn_alloc() must have been done
 *   - errfil must have been opened
 *  note: allocates and later frees arrays for 
 *        translation of .log file
 * 
 */
  void generate();
  void getcnf();
  void getparm();
  void mktrsprocfil();
  void translat();
  void trdyn_alloc();
  void trdyn_free();

/*
 *  begin program body
 *--------------------
 *  check that allocation for execution has been done and
 *  error output file has been opened
 */
  if ((exalcflg==0)||
      (errfil==NULL)) {
/*
 *  error, allocation has not been done
 */
    error("lbcc","102");
  }
/*
 *  allocate memory for translat if not yet allocated
 */
  if (tralcflg==0) {
    trdyn_alloc();
  }
/*
 *  translate log input to cnf formulation
 */
  translat();
/* 
 *  get cnf formulation of translate step and
 *  store as follows
 *   - row data amatrw, ptamar, nzamar
 *   - column counts nzamac
 */
  getcnf();
  if (succss==0) {
    lbccexit(1);
  }
/*
 *  make code for transfer process if specified 
 *  by mktransfilflg
 */
  if (mktrsprocfilflg==1) {
    mktrsprocfil();
  }
/*
 *  generate program
 */
  generate();
/*
 *  done
 */
  return;
}
/*eject*/
/* **************************************/
void generate() {
/*
 *  compile sat or minsat program from cnf formulation
 *  in layer 1. cnf formulation consists of
 *   - row data amatrw, ptamar, nzamar
 *   - column counts nzamac
 *  allocates and deallocation for lpx execution
 */
  void apmtme();
  void cbllim();
  void chksol();
  void enudec();
  void finmat(); 
  void fndpad();
  void initil();
  void injatf();
  void lpexec();
  void lrnout();
  void lrnrows();
  void prep();
  void putblk();
  void putprg();
  void ranges();
  void retain();
  void rstats();
  void trancnf();
  void trancpr();
  void xnoatf();

  long j,n,q;
 
/*
 *  initialization
 */
  initil();
/*
 *  begin compile process
 */
  iselvr = 1;
/*
 *  save input cnf formulation of layer 1 in layer 7
 *  note: problem must still be processed
 *        by finmat prior to compiling      
 */
  trancnf(c1,c7);
  goto zz315;
/*
 *  top of loop for use of generator versions
 *  specified by selvr array
 */
  zz305:;
/*
 *  insert into layer 1 the cnf formulation from layer 7
 */
  trancnf(c7,c1);
  zz315:;
/*
 *  store matrix data in amatcl
 *  introduce artificial variable and row, in block 1
 *  compute counts, block limits
 *  scale columns with negative costs
 *  construct external index array
 *  initialize various flags
 */  
  finmat();

/*
 *  if minimization case and if apmbnd == 0, enforce
 *  approximate minimization
 */
  if ((optimz == 1) &&
      (apmbnd == 0)) {
    apmflg = 1;
  }

/*
 * get problem statistics
 */
  if (scrflg == 1) {
    rstats();
  }

/*
 *  select program case
 */
  selpgv = selvr_(iselvr);
  if (scrflg == 1) {
    printf("Program generator version: %ld\n",selpgv);
  }

/*
 *  set optimz to 0 if approximate minimization
 *  has been specified
 */
  if (apmflg == 1) {
    optimz = 0;
  }     

/*
 *  preprocess problem
 */
  prep();
/*
 *  caution: if flgatf==1, then the ATF part of the 
 *           problem resides now in layer 5
 */
  
  zz365:

  if (succss == 0) {
    strcpy(parstr,
           "Problem is not satisfiable even "
           "when all clauses with\n"
           "delete option are eliminated. "
           "Program was not generated.\n"
           "Suggest that all clauses that may "
           "cause the unsatisfiability\n"
           "be named and thus become deletable. ");
    printf("%s",parstr);
    fprintf(errfil,"%s",parstr);
    strcpy(parstr,
           "Then a program can be\n"
           "generated and used to analyze "
           "the formulation error.\nStop\n");
    printf("%s",parstr);
    fprintf(errfil,"%s",parstr);
    lbccexit(1);
  }
/*
 *  adjust selvr_(2) depending on sat or minimization
 *  and on number of blocks determined in prep
 *  becomes effective only if nselvr = 2
 *
 * this code was removed 9/29/2000
 * since it can increase upper bound 
 * substantially
  selvr_(2) = 6;
  if ((optimz==1)&&
      (nblks==2)) {
    selvr_(2) = 9;
  }
 */
/*
 *  generate program
 */
  if (scrflg==1) {
    printf("Decomposition Process\n");
  }
/*
 *  allocate memory for lpx
 */
  xpoint_(4) = 1000;  /* max number of structural variables */
  xpoint_(5) = 1000;  /* max number of equations            */
  xpoint_(6) = 10000; /* max number of nonzeros in matrix   */
  xpoint_(7) = 5;     /* iafac (must be in range 3 - 10)    */
  strcpy(xcomnd,"ALC DIM");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  fndpad();
/*
 *  free memory of lpx
 */
  strcpy(xcomnd,"FRE DIM");
  lpexec(xcomnd,xpoint,xvalue);

#ifdef MATRIX
  if  (succss == 0) {
/*  should not happen since trivial decomposition is always possible */
    error("generate","104");
  }
  if (outputprgflg == 1) {
/*
 *  write colcut and rowcut information for each block
 *  into file prgfil
 */
    prgfil = fopen(prgfil_name,"w");
    if (prgfil == NULL) {
      printf("Cannot open blk file %s\n",prgfil_name);
      printf("Stop\n");
      fprintf(errfil,
          "Cannot open blk file %s\n",prgfil_name);
      fprintf(errfil,"Stop\n");
      lbccexit(1);
    }
    putblk();
    fclose(prgfil);
    if (scrflg == 1) {
      printf("\n*** Blocks are in file %s\n",prgfil_name);
    }
  }
  return;
#endif

/*
 */
  if  (succss == 0) {
/*  no range vectors due to unsatisfiability */
    goto zz365;
  }
  if (scrflg==1) {
    printf("\n");
  }
/*
 * if ATF part exists: remove it from layer 5
 * and inject it into current problem in layer 1.
 * after injatf below, layer 5 is available again
 * for other use
 */
  if (flgatf != 0) {
    injatf();
  }
/*
 *  restore optimz to 1 if approximate minimization
 *  has been specified
 */
  if (apmflg == 1) {
    optimz = 1;
  }

/*
 *  store problem in layer 6 
 *  if this is the first pass or
 *  if a better program has been found
 */

  if ((iselvr==1)||
      ((iselvr>1)&&
      (realts<realto))) {
    bstver=selpgv;
    realto=realts;

/*
 *  save current compiled best version in layer 6
 *  caution: must recompute block limits and range data,
 *           and retain indices when layer 6 version is used
 */
    trancpr(c1,c6);
  }

/*
 * check if program at hand is essentially
 * the best possible
 */
  if ((nblks==1)||
      ((selvr_(iselvr)<=3)&&(bdfxbl_(2)<=4))||
      ((selvr_(iselvr)==6)&&(nblks==2))||
      ((selvr_(iselvr)==9)&&(nblks==2))) {
/*
 *  have essentially the best program
 *  skip  remaining cases
 */
    iselvr=nselvr;
  }

  if (iselvr<nselvr) {
/*
 *  start another pass with next version
 */
    iselvr=iselvr+1;
    goto zz305;
  }
/*
 *  minimization case
 *  check if switching to approximate minimization
 *  is required. do switch
 *        if program for exact minimization
 *           has been generated, but no learning
 *           has taken place as yet (the latter condition
 *           prevents switch to approximate minimization
 *           after rows have been learned)
 *        if time bound is exceeded, and
 *        if approximate minimization is permitted
 */
  if (realto > 10.e6) {
    n = 10000000;
  } else {
    n = realto;
  }

  if ((optimz==1)&&
      (apmflg==0)&&
      (apmbnd>=0)&&
      (ilrncyc==1)&&
      (n > apmbnd)) {
    apmflg=1;
/*
 *  reset program generator version
 */
    iselvr=1;
    goto zz305;
  }
/*eject*/
/*
 *  retrieve compiled best version from layer 6,
 *  put into layer 1
 *  compute block limits
 *  caution: range data are not computed since they
 *           are not needed for learning rows
 */
    trancpr(c6,c1);
    cbllim();
/*
 *  learn rows if specified
 *
 *  first check that learning is meaningful
 */
  if ((lrnflg==1)||
      (lrnflg==2)) {
    if (nblks==1) {

/*
 *  just one block means nearly negative matrix and
 *  learning is not needed
 */
      lrnflg = 3;
    } else {
/*
 *  have at least 2 blocks
 *  compute bdfxbl values
 */
      for (q=2;q<=nblks;q++) {
        bdfxbl_(q) = 0;
        for (j=lcllim_(q);j<=ucllim_(q);j++) {
          if (cifix_(j)!=0) {
            bdfxbl_(q)++;
          }
        }
      }
      for (q=2;q<=nblks;q++) {
        if (bdfxbl_(q)>aggmax) {
          goto zz405;
        }
      }
/*
 *  all blocks have <= aggmax fixed variables and 
 *  thus are solved by enufix1, where learning
 *  of rows would slow down solution process
 */ 
      lrnflg = 3;
    }
    if (scrflg == 1) {
      if (lrnflg == 3) {
        printf("Learning requested but not needed\n");
      }
    }
  }

  zz405: 
/*
 *  learn if requested
 */

  if((lrnflg == 1)||
     (lrnflg == 2)) {
/*
 *  save compiled input problem in layer 4
 */
    trancpr(c1,c4);
/*
 *  retain data in xxxxxr arrays
 *  caution: retain destroys counts
 */
    zz425:;
    retain();

    if (ilrnzero==0) {
/*
 *  have first cycle, or learned during
 *  previous cycle. hence have next cycle
 */
      if (scrflg == 1) {
        printf("Learning cycle %ld\n",ilrncyc);
      }
    }
/*
 *  learn additional rows in lrnrows
 *  input:  problem in layer 1
 *          file with theorems (optional)
 *          see getthms for caution statement about theorems
 * output:  lrnsucc = -1 problem is unsatisfiable regardless
 *                       of atf column fixing. hence no 
 *                       learning possible.
 *                  =  0 no learning possible
 *                       layer 1 has original cnf formulation
 *                       (formulation consists of all row matrix
 *                       data and column counts nzamac)  
 *                  =  1 layer 1 contains new cnf formulation
 *                       where at least one learned row
 *                       has replaced an original row or has
 *                       been added 
 *                       (formulation consists of all row matrix
 *                       data and column counts nzamac)
 *                  =  2 layer 1 contains revised cnf formulation
 *                       where at least one learned row
 *                       has replaced an existing row or has
 *                       been added
 *                       (formulation consists of all row matrix
 *                       data and column counts nzamac)
 *                       learning process was stopped because
 *                       of rowmax or anzmax limit
 *                  = -2 layer 1 contains original cnf formulation
 *                       no learning has taken place
 *                       learning process was stopped because
 *                       of rowmax or anzmax limit
 * 
 *  caution: layers 2 and 3 are used by lrnrows
 */
    lrnrows();
    if (lrnsucc == -1) { 
/*  problem is unsatisfiable regardless
 *  of atf variable fixing and user row deletion 
 *  hence no learning possible
 */
      strcpy(parstr,
             "Problem is not satisfiable even "
             "when all clauses with\n"
             "delete option are eliminated. "
             "Learning was not possible.\n"
             "Suggest that all clauses that may "
             "cause the unsatisfiability\n"
             "be named and thus become deletable. ");
      printf("%s",parstr);
      fprintf(errfil,"%s",parstr);
      strcpy(parstr,
             "Then a program can be\n"
             "generated and used to analyze "
             "the formulation error.\nStop\n");
      printf("%s",parstr);
      fprintf(errfil,"%s",parstr);
      lbccexit(1);              
    }
    if (lrnsucc==0) {
      if (lrnflg==2) {
/*
 *  random theorem learning, no success for this cycle
 *  increment ilrnzero
 */
        ilrnzero++;
        if (ilrnzero<nlrnzero) {
/*
 *  have less than max number of cycles
 *  continue learning
 *  retrieve compiled program from layer 4
 *  begin another learning cycle
 */
          trancpr(c4,c1);
          cbllim();
          goto zz425;
        }
      } else {
/*  
 *  specified theorem learning, no success for this cycle
 *  set ilrnzero to max value since no further learning possible
 */
        ilrnzero = nlrnzero;
      }
    }
    if (lrnsucc==1) {
/*
 *  successful learning, reset ilrnzero to 0
 */
      ilrnzero = 0;
    }
/*
 */
    if ((ilrnzero==nlrnzero) ||
        (lrnsucc==-2)) {
/*
 *  no learning possible
 *  if random theorem learning, then also
 *  no learning during the last nlrnzero iterations 
 *     
 *  restore compiled input problem from layer 4
 *  compute block limits
 */
      if (scrflg == 1) {
        printf("Learning not possible\n");
      }
      trancpr(c4,c1);
      cbllim();
      goto zz505;
    }
/*
 *  learning was successful
 */
    if (scrflg == 1) {
        printf("Learning completed\n");
    }
/*
 *  output learned clauses if requested
 */
    if (lrnoutflg==1) {
      if (scrflg == 1) {
        printf("Output learned clauses\n");
      }
      lrnrowfil = fopen(lrnrowfil_name,"w");
      if (lrnrowfil == NULL) {
        printf("Cannot open lrn file %s\n",lrnrowfil_name);
        printf("Stop\n");
        fprintf(errfil,
             "Cannot open lrn file %s\n",lrnrowfil_name);
        fprintf(errfil,"Stop\n");
        lbccexit(1);
      }
      lrnout();
      fclose(lrnrowfil); 
    }
/*
 */
    if (ilrncyc==nlrncyc) {
/*
 *  have reached max number of learning cycles
 *  set lrnflg = 3 to stop further learning
 */
      lrnflg = 3;
    }
    ilrncyc++;

/*
 *  transfer augmented cnf row formulation
 *  from layer 1 to layer 7
 *  compile problem with the additional rows
 */  
    trancnf(c1,c7);
    iselvr = 1;
    goto zz315;
  }
/*eject*/
  zz505:;
/*  layer 1 contains final version
 *  with block limits
 *
 *  compute range data
 *  caution: must first remove atf portion
 *           of problem
 *
 *  save compiled problem in layer 6
 */
  trancpr(c1,c6);
/*
 *  eliminate atf part
 */
  xnoatf();
/*
 *  compute range data
 */
  ranges();
  if (succss == 0) {
/*
 *  error, cannot have succss = 0 since original
 *  range calculation was successful
 */  
    error("generate","312");
  }
/*
 *  transfer compiled problem from layer 6 to layer 1
 */
  trancpr(c6,c1);
/*
 */
  if (apmflg==1) {
/* 
 *  compute estimated time for approximate minimization 
 */
    apmtme();
/*
 *  variable realtl now contains estimated time
 */
  }
/*
 *  retain data in xxxxxr arrays
 *  caution: retain destroys counts
 */
  retain();
/*
 *  initialize execution time flags and total costs
 */
  asgflg=0;
  solflg=0;
  satble=0;
  prcost=0;
  lbcost=0;
/*
 */
  if (outputprgflg==1) {

/*
 *  count number of records of generated program
 */
    lprb=1;
    stoflg=0;
    nrecs=0;
    putprg();
/*
 *  increase nrecs count to include possible
 *  changes of likelihoods, costs, and indices
 *  changed at execution time
 *  likelihood changes:
 *    each new likelihood value may add up to 2 bytes
 */
    nrecs=nrecs+(nrows*2)/pgrmax+1;
/*
 *  changes of trucst and falcst:
 *    each new cost value may add up to 3 bytes.
 */
    nrecs=nrecs+(ncols*2*3)/pgrmax+1;
/*
 *  changes of idxgol, idxgnm, gcoeff:
 *    each new value may add up to 3 bytes
 */
    nrecs=nrecs+(ncols*3*3)/pgrmax+1;
/*
 *  changes of dual, goalxq, glocst, ghicst,
 *  goalus, goalrq:
 *    each new value may add up to 3 bytes;
 *    number of goals = ngols
 */
    nrecs=nrecs+(ngols*6*3)/pgrmax+1;
/*
 *  store current problem on disk
 *  with correct nrecs value
 */
    if (scrflg == 1) {
      printf("Store generated program\n");
    }
    prgfil = fopen(prgfil_name,"w");
    if (prgfil == NULL) {
      printf("Cannot open prg file %s\n",prgfil_name);
      printf("Stop\n");
      fprintf(errfil,
          "Cannot open prg file %s\n",prgfil_name);
      fprintf(errfil,"Stop\n");
      lbccexit(1);
    }
    stoflg=1;
    putprg();
    if (scrflg == 1) {
      printf("Program is stored: %s\n",prgfil_name);
    }
    fclose(prgfil);
  }    
/*
 *  done with generation of program
 *  write summary
 */
  if (scrflg == 1) {
    printf("Program was generated with version = %ld\n",
           bstver);
    if (apmflg == 0) {
      if (realto<1.0e6) {
        printf("Execution time bound (sec) = %10.4f\n",
                  realto);
      } else {
        printf("Execution time bound (sec) = %9.1e\n",
                  realto);
      }
    } else {
      if (realtl<1.0e6) {
        printf("Estimated execution time (sec) = %10.4f\n",
              realtl);
      } else {
        printf("Estimated execution time (sec) = %9.1e\n",
              realtl);
      }
      if (realto<1.0e6) {
        printf(
        "Satisfiability check time bound (sec) = %10.4f\n",
         realto);
      } else {
        printf(
        "Satisfiability check time bound (sec) = %9.1e\n",
         realto);
      }
    }
    printf("   if machine speed (mips) = %ld\n",mspeed);
  }

/*
 *  check satisfiability if requested
 */
  if (satchk==1) {
    if (apmflg == 1) {
      optimz = 0;
    }
    if (scrflg == 1) {
        printf("Satisfiability test: ");
    }

/*
 *  solve problem and, if applicable, check solution
 *  caution: enudec() destroys some counts
 */
    enudec();
    if (scrflg == 1) {
      if (succss == 1) {
        printf("is satisfiable\n");
        chksol();
      } else {
        printf("is unsatisfiable\n");
      }
    }

/*
 *  restore optimization flag if approx. min. case
 */
    if (apmflg == 1) {
      optimz = 1;
    }
  }

/*
 *  done
 */
  return;
}
/*eject*/
/* ************************************* */
void translat() {
/*
 *  translate log file to cnf formulation
 */
  void error();
  void getlog();
  void opens();
/*
 */
  static long err,i;
/*
 *  if condensed input file is to be produced, open that file
 */
  if (condiptflg == 0) {
    condiptfil = fopen(condiptfil_name,"w");
    if (condiptfil == NULL) {
      error("translat","102");
    }
    if (strcmp(begcondiptword,"") == 0) {
      condiptflg = 1;
    }
  }
/*
 *  open virtual files 12 and 13
 *  they simulate previously used disk files
 */
  i = 12;
  opens(&i);
  i = 13;
  opens(&i);
/*
 *  open log file and initialize number of log input files
 *  and log input line count
 */
  logfil_(1) = fopen(&logfil_name_(1,1),"r");
  if (logfil_(1) == NULL) {
    printf("Cannot open input log file %s\n",logfil_name);
    printf("Stop\n");
    fprintf(errfil,
         "Cannot open input log file %s\n",logfil_name);
    fprintf(errfil,"Stop\n");
    lbccexit(1);
  }
  nlogfil = 1;
  logcline_(1) = 0;
/*
 *  translate log file
 */
  if (scrflg==1) {
    strcpy(parstr,filnam);
    strcat(parstr,&namext_(1,1));
    printf("Processing %s\n",parstr);
  }
  err = 0;
  getlog(&err);
/*
 *  err = 0 no warnings, no errors
 *      = 1 if warnings only
 *      = 2 errors and possibly warnings
 */
  if (scrflg==1) {
    if (err > 0) {
      printf("For complete listing of warning/error messages\n");
      printf("see file %s\n",errfil_name);
    }
  }
/*
 *  close all open log input files
 */
  for (i=1;i<=nlogfil;i++) {
    fclose(logfil_(i));
  }
/* 
 *  if condensed input file has been produced, close that file
 */
  if (condiptflg >= 0) {
    fclose(condiptfil);
  }

/*
 *  if err = 2, stop
 */
  if (err == 2) {
    printf("Stop compiler due to errors in log file\n");
    lbccexit(1);
  }
  return;
}
/*  last record of decc.c***** */
