/*  first record of comp.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

#ifdef DEBUG
void damatx(char message[]); 
void dcuts(char message[]);
void dlabels(char message[]);
void doriginalcuts(char message[]);
#endif

int abs();
/*
 * **********************************************************
 *  module component 
 *   
 *  purpose:  finds solution algorithm, or finds a decomposition
 *            for block qblock, or composes two components.
 *
 *            call fndalg for solution algorithm.
 *            call fnddec for decomposition.
 *            call compos for composition.
 *  
 *    input:  problem in layer 1, with correct indices and 
 *            counts.  may have any number of blocks. ('*' means 
 *            condition is tested in fndalg and fnddec).
 *             arrays assumed defined:
 *              - matrix data amatcl, amatrw
 *              - nrows, ncols, nblks
 *              - colnam, rownam
 *              - matrix indices as follows:
 *        *         all columns j active (ciact(j) = 1)
 *        *         all rows i active (riact(i) = 1)
 *                  remaining indices must be consistent with 
 *                  these assignments. 
 *              - counts cnxxx, rnxxx 
 *        *     - all cost(j) must be .ge. 0 if optimz = 1
 *              - scale, idxcol, idxrow, invidxcol, invidxrow 
 *              - dlclop, dlrwop
 *              - lcllim, ucllim, lrwlim, urwlim
 *              - logrge
 *              - optimz
 *              - qblock 
 *              - flgopt = 0: find algorithm by heuristics
 *                       = 1: find optimal algorithm
 *
 *         additional input requirements as well as the output 
 *         are given with each subroutine of this module.
 *
 *    calling sequences:
 *      1.  fndalg        finds solution algorithm for block 
 *                        q = qblock.SPORE_PRINT_COLOR	0.50
 *            if flgopt = 0:
 *            heualg      module component algorithm, uses 
 *                        heuristic selection algorithm
 *            if flgopt = 1: 
 *            optalg      module component algorithm, uses 
 *                        optimal selection algorithm
 *   
 *      2.  fnddec        finds a decomposition of block 
 *                        q = qblock.
 *            decomp      module component decomposition.
 *            outcolrowcut output colcut and rowcut information
 *            savecolrowcut save colcut and rowcut information
 * 
 *            reshuf      reshuffle column and rows so that 
 *                        in the refined decomposition the 
 *                        indices of each block are contiguous.
 *
 *            case mincutflg == ONLYCOLS:
 *              convertcutrows
 *                          for each cut row with 2 entries: 
 *                            convert cut row to cut col
 *
 *            tree decomposition only:
 *              addemptycols add empty columns for splitting of
 *                          components
 *                          caution: uses cl_(j,14,2) 
 *                          (= solut1_(j) of layer 2)
 *                          to store index of new column with
 *                          same name as cut column j
 *              modifycols  modify columns to represent splitting
 *                          of components
 *              modifyrows  modify rows to represent splitting
 *                          of components
 *                          caution: cl_(j,14,2)
 *                          (= solut1_(j) of layer 2)
 *                          is the index of new column with
 *                          same name as cut column j
 *              shiftcutcols shift cut columns to 2nd, unlabeled
 *                          component
 *
 *      linear decomposition:    
 *      3.  compos        module component composition.
 *   
 *   caution:  uses layer 2, 3, and 4 for intermediate storage.
 * *************************************************************
 */

/*eject*/
/* *************************************************************
 *
 * Cutset Information
 *
 *         for internal index j:
 *
 *         cl_(j,17,2), j = 1, 2, ..., ncols 
 *             = 1: j in cutset 
 *             = 0: j not in cutset
 *         cl_(j,18,2), j = 1, 2, ..., ncols
 *             = 1: j in 1st component (labeled)
 *             = 0: j in 2nd component (unlabeled)
 *         rw_(i,21,2), i = 1, 2, ..., nrows
 *             = 1: i in cutset 
 *             = 0: i not in cutset
 *         rw_(i,22,2), i = 1, 2, ..., nrows
 *             = 1: i in 1st component (labeled)
 *             = 0: i in 2nd component (unlabeled)
 *
 *  ------------------------------------------------------
 *
 *         ccut_(jx), jx = 1, 2, ..., ccut(colmax+1)
 *             list of columns j in cutset
 *
 *         rcut_(ix), ix = 1, 2, ..., rcut(rowmax+1)
 *             list of rows i in cutset
 *
 *         caution: ccut value j and rcut value i 
 *                  are internal indices 
 *
 *  -------------------------------------------------------
 *
 *         colcut_(jx,q), jx = 1, 2, ..., colcut_(cutmax+1,q)
 *            list of columns j1 in cutset
 *
 *         rowcut_(ix,q), ix = 1, 2, ..., rowcut_(cutmax+1,q)
 *            list of rows i1 in cutset
 *
 *         caution: colcut value j1 and rowcut value i1 
 *                  are external indices
 *
 * *************************************************************
 *         Tree decomposition: (always ONLYCOLS) 
 *
 *         for cut column j, which has cl_(j,17,2) = 1:
 *         cl_(j,14,2) = index of new column corresponding to
 *                       cut column j
 * ************************************************************
 */

/*eject*/
/* *************************************************************
 *
 * Tree Decomposition Matrix (always ONLYCOLS)
 *
 *
 * |    new block q     |    new block qp1   |
 * |                    |                    |  
 * -------------------------------------------
 * |          |new nodes|          |cut nodes|
 * -------------------------------------------
 * |          |         |          |         |          
 * |          | define  |          |change to|
 * |   0/1    |   0/1   |    0     |    0    |
 * |          |         |          |         |
 * |          |         |          |         |
 * -------------------------------------------
 * |          |         |          |         |
 * |          | define  |          |         |
 * |    0     |    0    |   0/1    |   0/1   |
 * |          |         |          |         |
 * |          |         |          |         |
 * -------------------------------------------
 *            |  add    |
 *            | clique  |                     
 *            -----------          -----------
 *                                 |  add    |
 *                                 | clique  |
 *                                 -----------
 *  
 * 1. The new columns are defined as copies of 
 *    the cut columns
 * 
 * 2. Move the entries of the submatrix 'change to 0'
 *    to the submatrix 'define 0/1'.
 * 
 * Result: two disjoint blocks        
 * *************************************************************
 */

/*eject*/ 
/* *************************************************************
 *  subroutine fndalg
 * 
 *  purpose:  finds solution algorithm for block qblock of 
 *            problem in layer 1.
 *
 *    input:  as specified in module summary.
 * 
 *   output:  solution algorithm specified for each strip 
 *            q = qblock via twosat:
 *              twosat(q) = 0:  some columns have been moved 
 *                from freeto fixed, and some free columns 
 *                have been scaled. submatrix of free columns 
 *                is nearly negative.
 *              twosat(q) = 1:  some columns have been moved 
 *                from free to fixed.  submatrix of free columns 
 *                has 2sat form. this case requires optimz = 0. 
 *              bdfxbl(q) = number of fixed variables in 
 *                strip q.
 **
 *     caution:  uses layers 2, 3, 4 for intermediate storage.
 *
 * ************************************************************
 * 
 */
void fndalg() {
/*
 */
  void heualg();
  void mcfrfx();
  void mcfxfr();
  void optalg();
  void scalcl();
  void trancl();
  void tranpr();
  void xstrip();
/*
 */
  static long i,j,q;
/*
 */
  q=qblock;
/*
 *  edge graph or node graph case
 *  if selpgv = 0 or 10: assign number of columns of block q to
 *                 bdfxbl_(q), and return
 */
  if (selpgv == 0 || selpgv == 10) {
    bdfxbl_(q) = ucllim_(q) - lcllim_(q) + 1;
    return;
  }
/*
 *  verify that all columns are active
 */
  for(j=1; j<=ncols; j++)  {
    if (ciact_(j)!=1) {
      error(" fndalg ","     52 ");
    }
  }
/*
 *  verify that all rows are active
 */
  for(i=1; i<=nrows; i++)  {
    if (riact_(i)!=1) {
      error(" fndalg ","     62 ");
    }
  }
/*
 *  verify that all costs are nonnegative if optimz = 1
 */
  if (optimz==1) {
    for(j=1; j<=ncols; j++)  {
      if (cost_(j)<0) {
        error(" fndalg ","     72 ");
      }
    }
  }
/*
 *  save problem in layer 4
 */
  tranpr(c1,c4);
/*
 *  extract strip q from problem in layer 1 and retain in layer 1.
 */
  xstrip(q);
/*
 *  process strip q
 *  decide on solution via nearly negative or 2sat form
 */
  lcllmt=lcllim_(q);
  ucllmt=ucllim_(q);
  lrwlmt=lrwlim_(q);
  urwlmt=urwlim_(q);
  if (flgopt==0) {
/*
 *  heuristic selection methods are to be used
 */
    heualg();
  } else {
/*
 *  optimal selection methods are to be used
 *  check if a solution algorithm is already on hand. if not, 
 *  use heualg to obtain one
 */
    if (twosat_(q)<0) {
      heualg();
    }
    optalg();
  }
/*
 *  transfer cl of strip q with solution information 
 *  from layer 1 to layer 2
 */
  trancl(c1,c2);
/*
 *  transfer original (thus entire) problem 
 *  from layer 4 to layer 1
 */
  tranpr(c4,c1);
/*
 *  assign scale values and cixxx values of 
 *  strip q in layer 2 to the original problem, 
 *  which now is in layer 1.
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
/*
 *  check if column j of strip q has been scaled.  
 *  if yes, scale column j of layer 1 problem.
 */
    if (scale_(j)!=cl_(j,19,2)) {
/*
 *  scaling error if optimization and cost(j) .ne. 0
 */
      if ((optimz==1)&&
          (cost_(j)!=0)) {
        error(" fndalg ","     302");
      } else {
        scalcl(j);
      }
    }
/*
 *  check if column j of strip q has changed 
 *  fixed\free status. if yes, update column j of 
 *  layer 1 problem accordingly
 */
    if ((cl_(j,13,2)!=0)&&
        (cifre_(j)==1)) {
      mcfrfx(j);
    } else {
      if ((cl_(j,12,2)==1)&&
          (cifix_(j)!=0)) {
        mcfxfr(j);
      }
    }
  }
  return;
}

/*eject*/
/*
 * ************************************************************
 *  subroutine fnddec
 * 
 *  purpose:  finds a decomposition of block qblock of problem 
 *            in layer 1 if this is possible.
 *     
 *    input:  as specified in module summary.
 * 
 *   output:  problem in layer 1 with old (succss = 0) 
 *            or new (succss =1) decomposition.
 *            all input arrays have been adjusted to reflect 
 *            the change of decomposition. 
 *   
 *    caution:  uses layers 2 and 3 for intermediate storage.
 * 
 * ************************************************************* 
 * 
 */
void fnddec() {
/*
 */

  void addemptycols();
  void convertcutrows();
  void decomp();
  void modifycols();
  void modifyrows();  
  void reshuf();
  void outcolrowcut();
  void savecolrowcut();
  void shiftcutcols();

  void tranpr();
  void xcomp();

/*
 */
  long j,i,k,q,q1,qp1;

/*
 *  verify that all columns are active
 */
  for(j=1; j<=ncols; j++)  {
    if (ciact_(j)==0) {
      error(" fnddec ","   12   ");
    }
  }
/*
 *  verify that all rows are active
 */
  for(i=1; i<=nrows; i++)  {
    if (riact_(i)!=1) {
      error(" fnddec ","   22   ");
    }
  }
/*
 *  verify that all cost(j) are .ge. 0 if optimz = 1
 */
  if (optimz==1) {
    for(j=1; j<=ncols; j++)  {
      if (cost_(j)<0) {
        error(" fnddec ","   32   ");
      }
    }
  }
/*
 *  verify that an additional block can be accommodated.
 */
  if (nblks==blkmax) {
    error(" fnddec ","   42   ");
  }

  q=qblock;

/*
 * if block has <= 6 columns, decomposition is not attempted
 * tested Aug 23, 2007, removed again Aug 29, 2007
 */
/*  if (ucllim_(q)-lcllim_(q) <= 6) {
    succss = 0;
    return;
    } */
    
/*
 *  attempt to refine block q
 *  transfer input problem from layer 1 to layer 3 to save it
 */
  tranpr(c1,c3);
/*
 *  extract component q from layer 1 problem and retain 
 *  in layer 1.
 */
  xcomp(q);
/*
 *  decompose component q
 */
  decomp();
/* 
 *  transfer input problem from layer 3 to layer 1
 */
  tranpr(c3,c1);
/*
 *  if no decomposition found, return
 */
  if (succss==0) {
    return;
  }
/*eject*/
/*
 * -----------------------------------------------------------
 *  have a good decomposition of block q in layer 2.
 *  - if mincutflg == ONLYCOLS:
 *      for each cut row with 2 entries: 
 *        convert cut row to cut col
 *  - if decompositionflg == TREE: shift cut columns to 2nd,
 *                                 unlabeled, component
 *  - store cut information in ccut and rcut
 *  - store cut information in colcut and rowcut  
 *  - update input problem in layer 1
 * -----------------------------------------------------------
 */
#ifdef DEBUG
    dlabels("before convertcutrows");
    doriginalcuts("before convertcutrows");
    damatx("before convertcutrows");
#endif

/* 
 *  if mincutflg == ONLYCOLS:
 *    check if there is a cutrow. if yes, must have
 *    two nonzeros. replace by cutcol
 */
  if (mincutflg == ONLYCOLS) {
    convertcutrows();
  }

#ifdef DEBUG
    dlabels("after convertcutrows");
    doriginalcuts("after convertcutrows");
    damatx("after convertcutrows");
#endif

/* 
 *  if decompositionflg == TREE (always ONLYCOLS): 
 *    shift cut columns to 2nd, unlabeled, component 
 */
  if (decompositionflg == TREE) {
    shiftcutcols();
  }

/* 
 *  store cut information in ccut and rcut
 */
  ccut_(colmax+1) = 0;
  for (j=1; j<=ncols; j++) {
    if (cl_(j,17,2) == 1) {
      ccut_(colmax+1)++;
      ccut_(ccut_(colmax+1)) = j;
    }
  }
  rcut_(rowmax+1) = 0;
  for (i=1; i<=nrows; i++) {
    if (rw_(i,21,2) == 1) {
      rcut_(rowmax+1)++;
      rcut_(rcut_(rowmax+1)) = i;
    }
  }

  if (ccut_(colmax+1)+rcut_(rowmax+1) != bstcut) {
    error(" fnddec ","  102   ");
  }

/*
 *  store cut information in colcut and rowcut arrays 
 */
  savecolrowcut();

/*
 *  output cut information of colcut and rowcut arrays 
 */
  if (scrflg == 1) {
    outcolrowcut();
  }

/*
 *  index for second new component
 */
  qp1=q+1;

/*
 *  shift twosat, bdfxbl, logrge, and block indicators
 */
  if (q<nblks) {
    for(q1=nblks; q1>=qp1; q1--)  {
      twosat_(q1+1)=twosat_(q1);
      bdfxbl_(q1+1)=bdfxbl_(q1);
      logrge_(q1+1)=logrge_(q1);
    }
    for(j=lcllim_(qp1); j<=ncols; j++)  {
      ciblk_(j)=ciblk_(j)+1;
    }
    for(i=lrwlim_(qp1); i<=nrows; i++)  {
      riblk_(i)=riblk_(i)+1;
    }
  }
/*
 *  shift logrge(q) to logrge(q+1
 *  retain bstcut (= cutsize) in logrge(q)
 */
  logrge_(qp1)=logrge_(q);
  logrge_(q)=bstcut;
/*
 *  indicate that solution algorithm is now 
 *  unspecified for q and q+1
 */
  twosat_(q)=-1;
  twosat_(qp1)=-1;
  bdfxbl_(q)=0;
  bdfxbl_(qp1)=0;
/*
 *  increment nblks
 */
  nblks=nblks+1;
/*
 *  deduce new block q+1 from unlabeled nodes in layer 2
 */
  for(j=lcllim_(q); j<=ucllim_(q); j++)  {
    if (cl_(j,18,2)==0) {
      ciblk_(j)=qp1;
    }
  }

  for(i=lrwlim_(q); i<=urwlim_(q); i++)  {
    if (rw_(i,22,2)==0) {
      riblk_(i)=qp1;
    }
  }

/*
 *  if decompositionflg == TREE:
 *    make the two new components disjoint
 *    using additional cut columns and clique rows
 */
  if (decompositionflg == TREE) {

    /* check that space is available */
    k = colcut_(cutmax+1,q);
    if (ncols + k > colmax) { 
      /* colmax too small */
      printf("colmax too small for tree decomposition\n");
      fprintf(errfil,
	     "colmax too small for tree decomposition\n");
      error(" fnddec "," 302 ");
    }
    if (nrows + 2*k > rowmax) { 
      /* rowmax too small */
      printf("rowmax too small for tree decomposition\n");
      fprintf(errfil,
	     "rowmax too small for tree decomposition\n");
      error(" fnddec "," 304 ");
    }
    if (nanzs + 2*k*k > anzmax) { 
      /*anzmax too small */
      printf("anzmax too small for tree decomposition\n");
      fprintf(errfil,
	     "anzmax too small for tree decomposition\n");
      error(" fnddec "," 306 ");
    }

    /* add empty columns duplicating the cut colums */
    addemptycols();

    /* modify rows to represent splitting 
     * of the cut columns
     */ 
    modifyrows();

    /* modify columns in agreement 
     * with row data
     */
    modifycols();

#ifdef DEBUG
    dcuts("after modifycols");
    damatx("");
#endif

  } /* end of decompositionflg == TREE */

/*
 *  reshuffle columns and rows so that each block has 
 *  contiguous indices.
 */
  reshuf();

  return;
}

/*eject*/
/*
 * ************************************************************
 *  subroutine addemptycols 
 * 
 *  purpose: add empty columns for splitting of components
 *           the added columns will become part of block q
 *           since the existing cut columns are part of
 *           block q+1
 *  caution: uses solut1_(j) of layer 2 ( = cl_(j,14,2))
 *           to store index of newly created column having
 *           the same name as column j
 * ************************************************************
 * 
 */
void addemptycols() {
/*
 */
  long j,j1,jx,l,q,qp1;
#ifdef DEBUG
  long k;
#endif
/*
 */
  q=qblock;
  qp1 = q+1;

/*  
 *  create one additional column for each cut column
 *  note: cut columns are in block qp1
 */
  for (jx=1; jx<=colcut_(cutmax+1,q); jx++) { /* for loop 1 */
    j1 = colcut_(jx,q);
    j = idxcol_(j1);


    /* create additional column with same name */
    ncols++;
    strcpy(&colnam_(1,ncols),&colnam_(1,j1));
#ifdef DEBUG
    /* modify names to record decomposition */
    k = strlen(&colnam_(1,j1));
    /* sprintf(&colnam_(k+1,j1),"&%ld-2",nblks); */ /*detail*/
    sprintf(&colnam_(k+1,j1),".%ld",nblks);
    if (strlen(&colnam_(1,j1)) > 52) {
      /* error: node name becomes too large by
       * decomposition suffixes
       */
      printf("Node name becomes too large\n");
      printf("due to tree decomposition suffix\n");
      fprintf(errfil,"Node name becomes too large\n");
      fprintf(errfil,"due to tree decomposition suffix\n");
      error("addemptycols","  102  ");
    }
    /* sprintf(&colnam_(k+1,ncols),"&%ld-1",nblks); */ /*detail*/
    sprintf(&colnam_(k+1,ncols),".%ld",nblks);
#endif
    /* define last portion of new column */
    strcpy(&colnam_(58,ncols),&colnam_(58,j1));

/* derive column information from column j
 * as applicable
 */

    /* set column counts to 0 */
    for (l=1;l<=9;l++) {
      cl_(ncols,l,1) = 0;
    }

    /* copy index information of column j */
    for (l=10;l<=lclmax;l++) {
      cl_(ncols,l,1) = cl_(j,l,1);
    }

    /* revise ciblk, idxcol, invidxcol values */
    ciblk_(ncols) = q;
    idxcol_(ncols) = ncols;
    invidxcol_(ncols) = ncols;

    /* define costs using external column j1 */
    trucst_(ncols) = trucst_(j1);
    falcst_(ncols) = falcst_(j1);

    /* define cl_(j,14,2) = index of new column */
    cl_(j,14,2) = ncols;
 
  }/* end for loop 1 */

} /* end of addemptycols */

/*eject*/
/*
 * ************************************************************
 *  subroutine convertcutrows
 * 
 *  purpose: convert all cut rows with 2 entries to cut columns
 *
 *  input: original problem in layer 1
 *
 *         cl_(j,17,2), j = 1, 2, ..., ncols
 *         (= solut4_(j) of layer 2)
 *             = 1: j in cutset
 *             = 0: j not in cutset
 *             
 *         cl_(j,18,2), j = 1, 2, ..., ncols
 *         (= solut5_(j) of layer 2)
 *             = 1: j in 1st component
 *             = 0: j in 2nd component
 *
 *         rw_(i,21,2), i = 1, 2, ..., nrows
 *         (= rhs4_(i) of layer 2)
 *             = 1: i in cutset
 *             = 0: i not in cutset
 *
 *         rw_(i,22,2), i = 1, 2, ..., nrows
 *         (= rhs5_(i) of layer 2)
 *             = 1: i in 1st component
 *             = 0: i in 2nd component
 * 
 * output: above arrays updated
 *         original problem in layer 1 is not changed 
 * 
 * ************************************************************
 * 
 */
void convertcutrows() {
/*
 */
  long i,j1,j2;
/*
 */
  int abs();
/*
 */

  for (i=1;i<=nrows;i++) { /* for i loop */
    if (rw_(i,21,2) == 1) { /* row i is in cut */
      if (nzamar_(i) != 2) {
        /* error: 
         *  due to cut set minimality, unit rows cannot be 
         *  cut rows, and ONLYCOLS uses addition of enough 
         *  parallel rows in subroutine finmat for rows
         *  with >= 3 entries so that cut columns are
         *  always preferred for that case
         */
        error("convertcutrows"," 104 ");
      }

      /* remove row i from cut */
      rw_(i,21,2) = 0;

      /* find replacement cut column */
      j1 = abs(amatrw_(1+ptamar_(i)));
      j2 = abs(amatrw_(2+ptamar_(i)));

      if (/* (cl_(j1,17,2) == 1) ||
	     (cl_(j2,17,2) == 1) || */ 
          /* above condition dropped 1/12/2007 */
          (cl_(j1,18,2) == cl_(j2,18,2))) {
        /* error: 
         *  both j1 and j2 are labeled or unlabeled and thus
         *  in the same component; each case contradicts that
         *  row i is part of a min cut
         */
        error(" convertcutrows "," 202 ");
      }
      
      if (rw_(i,22,2) != cl_(j1,18,2)) {
        /* row i and column j1 have different label values and thus
         * are in different components; declare j1 to be new cut
         * column that replaces row i in cut
         * this assures that new cut does not separate row i edge
         * from other parts of component containing row i
         */
        cl_(j1,17,2) = 1;
      } else { /* declare j2 to be new cut column */
        cl_(j2,17,2) = 1;
      }
    }
  }
  
  return;

} /* end of convertcutrows */

/*eject*/
/*
 * ************************************************************
 *  subroutine modifycols 
 * 
 *  purpose:  modify column data using row data
 *
 *  note: this code is taken from finmat() of exutil.c
 * ************************************************************
 * 
 */
void modifycols() {
/*
 */
  long i,is,j,js,jx;

  void count();
/*
 * determine column counts
 *
 */
  for (j=1; j<=ncols; j++) {
    nzamac_(j) = 0;
  }
  for (i=1; i<=nrows; i++) {
    for (jx=1; jx<=nzamar_(i); jx++) {
      js = amatrw_(jx+ptamar_(i));
      j = abs(js);
      nzamac_(j)++;
    }
  }
/*
 *  find pointer based on counts
 */
  ptamac_(1)=0;
  if (ncols>1) {
    for (j=2; j<=ncols; j++) {
      ptamac_(j)=ptamac_(j-1)+nzamac_(j-1);
    }
  }
/*
 *  obtain entries from amatrw and place into amatcl
 *  first zero out amatcl counts
 */
  for (j=1; j<=ncols; j++) {
    nzamac_(j)=0;
  }
/*  
 *  extract entries from amatrw
 */
  for (i=1; i<=nrows; i++) {
/*
 *  error if no entry in row i
 */
    if (nzamar_(i)==0) {
      error(" modifycols ","  202  ");
    }
    for(jx=1; jx<=nzamar_(i); jx++)  {
      js=amatrw_(jx+ptamar_(i));
      j=abs(js);
/*
 *  place entry into amatcl
 */
      nzamac_(j)=nzamac_(j)+1;
      if (js>0) {
        is=i;
      } else {
        is=-i;
      }
      amatcl_(nzamac_(j)+ptamac_(j))=is;
    }
  }

/*
 *  compute counts
 */
  count();

} /* end modifycols */

/*eject*/
/*
 * ************************************************************
 *  subroutine modifyrows 
 * 
 *  purpose:  modify row data to account for splitting of cut 
 *            column data to the two new blocks
 *  caution:  uses solut1_(j) of layer 2 ( = cl_(j,14,2)), which
 *            is the index of the newly created column having
 *            the same name as column j
 *  caution:  lrwlim_(q) and urwlim_(q) have not yet been updated
 *            and thus are not yet correct for the new decomposition
 * ************************************************************
 * 
 */
void modifyrows() {
/*
 */
  long i,j,js,jx,k,q,qp1,nc;
/*
 */
  q=qblock;
  qp1 = q+1;

  if (colcut_(cutmax+1,q) <= 0) {
    error("modifyrows","  101  ");
  }

/*
 *  for each row i that is in block q and 
 *  has an entry in a cut column j:
 *  move the entry to new column cl_(j,14,2)
 */
  for (i=lrwlim_(q); i<=urwlim_(q); i++) {
    if (riblk_(i) == q) { /* since lrwlim, urwlim not yet updated */
      for (jx=1; jx<=nzamar_(i); jx++) {
        js = amatrw_(jx+ptamar_(i));
        j = abs(js);
        if (cl_(j,17,2) == 1) {
         if (js > 0 ) {
            amatrw_(jx+ptamar_(i)) = cl_(j,14,2);
          } else {
            amatrw_(jx+ptamar_(i)) = -cl_(j,14,2);
          }
        }
      }
    }
  }

/*
 *  add nc clique rows to row data
 *
 *  note: original cut columns are in block qp1, and
 *        copies of cut columns are in block q
 *
 *  caution: if there is just one cut column, then a clique
 *           row is also added and serves as marker in the matrix
 */
  /* code below replaced 10/29/2007 so that colcut size = k 
   * produces k clique rows. original code restored 1/12/2007 so
   * that colcut size <= 2 produces just one clique row 
   */
  if (colcut_(cutmax+1,q) == 2) {
    nc = 1;
  } else {
    nc = colcut_(cutmax+1,q);
  } 
  /* nc = colcut_(cutmax+1,q); */ /* deleted 1/12/2007 */

  for (k=1; k<=nc; k++) {
    /* add clique row for original cut columns, block qp1 */
    nrows++;
    if (k == 1) { /* first row is clique row */
      sprintf(&rownam_(1,nrows),"clique.%ld",nblks);
    } else { /* subsequent rows are parallel clique rows */
      sprintf(&rownam_(1,nrows),"parallel.clique.%ld",nblks);
    }
    riact_(nrows) = 1;
    riina_(nrows) = 0;
    riblk_(nrows) = qp1;
    rhs1_(nrows) = 1;
    rhs2_(nrows) = 1;
    rhs3_(nrows) = 1;
    rhs4_(nrows) = 1;
    rhs5_(nrows) = 1;
    idxrow_(nrows) = nrows;
    invidxrow_(nrows) = nrows;

    ptamar_(nrows) = nanzs;
    nzamar_(nrows) = colcut_(cutmax+1,q);
    for (jx=1; jx<=colcut_(cutmax+1,q); jx++) {
      /* cut column j */
      j = idxcol_(colcut_(jx,q));
      amatrw_(jx+ptamar_(nrows)) = j;
    }
    nanzs += nzamar_(nrows);
  }

  for (k=1; k<=nc; k++) {
    /* add clique row for new cut columns, block q */
    nrows++;
    if (k == 1) { /* first row is clique row */
      sprintf(&rownam_(1,nrows),"clique.%ld",nblks);
    } else { /* subsequent rows are parallel clique rows */
      sprintf(&rownam_(1,nrows),"parallel.clique.%ld",nblks);
    }
    riact_(nrows) = 1;
    riina_(nrows) = 0;
    riblk_(nrows) = q;
    rhs1_(nrows) = 1;
    rhs2_(nrows) = 1;
    rhs3_(nrows) = 1;
    rhs4_(nrows) = 1;
    rhs5_(nrows) = 1;
    idxrow_(nrows) = nrows;
    invidxrow_(nrows) = nrows;

    ptamar_(nrows) = nanzs;
    nzamar_(nrows) = colcut_(cutmax+1,q);
    for (jx=1; jx<=colcut_(cutmax+1,q); jx++) {
      /* cut column cl_(j,14,2) */
      j = idxcol_(colcut_(jx,q));
      amatrw_(jx+ptamar_(nrows)) = cl_(j,14,2);
    }
    nanzs += nzamar_(nrows);
  }
  
} /* end modifyrows */

/*eject*/
/*
 * **********************************************************
 *  subroutine outcolrowcut  
 * 
 *  purpose:  output colcut and rowcut information  
 *
 *  caution:  colcut and rowcut values are external indices 
 * **********************************************************
 * 
 */
void outcolrowcut() {
/*
 */
  long ix,jx,q;
/*
 */
  q=qblock;

  if (rowcut_(cutmax+1,q) > 0) {
    printf("\ncut rows:\n");
    for (ix=1; ix<=rowcut_(cutmax+1,q); ix++) {
      printf(" %s\n",&rownam_(1,rowcut_(ix,q)));
    }
  }

  if (colcut_(cutmax+1,q) > 0) {
    printf("\ncut columns:\n");
    for (jx=1; jx<=colcut_(cutmax+1,q); jx++) {
      printf(" %s\n",&colnam_(1,colcut_(jx,q)));
    }
  }


} /*end outcolrowcut */

/*eject*/
/*
 * ********************************************************
 *  subroutine reshuf
 * 
 *  purpose:  reshuffles columns and rows of problem
 *            in layer 1 such  that each block has contiguous
 *            indices.
 * 
 *    input:  problem in layer 1 with defined block indices.
 * 
 *   output:  reshuffled problem in layer 1 such that each 
 *            block has contiguous indices.  
 *            lcllim, ucllim, lrwlim, urwlim are updated
 *            even if nblks = 1
 * 
 *  caution:  uses layers 2 and 3 for intermediate storage.
 * 
 * *******************************************************
 * 
 */
void reshuf() {
/*
 */
  void tranpr();
/*
 */
  static long q1,j,j1,i,i1,l,ix,is,jx,js,m;
/*
 *  if nblks = 1, no reshuffling is needed
 *                assign correct value to lcllim,ucllim,
 *                lrwlim,urwlim
 */
  if (nblks==1) {
    lcllim_(1)=1;
    lrwlim_(1)=1;
    ucllim_(1)=ncols;
    urwlim_(1)=nrows;
    return;
  }
/*
 *  save input problem in layer 2
 */
  tranpr(c1,c2);
/*
 *  compute number of indices for each block, and place
 *  into solut4 and rhs4
 */
  for(q1=1; q1<=nblks; q1++)  {
    solut4_(q1)=0;
    rhs4_(q1)=0;
  }
  for(j=1; j<=ncols; j++)  {
    q1=ciblk_(j);
    solut4_(q1)=solut4_(q1)+1;
  }
  for(i=1; i<=nrows; i++)  {
    q1=riblk_(i);
    rhs4_(q1)=rhs4_(q1)+1;
  }
/*
 *  calculate starting index for each block
 *  initialize upper limits
 */
  lcllim_(1)=1;
  lrwlim_(1)=1;
  ucllim_(1)=lcllim_(1)-1;
  urwlim_(1)=lrwlim_(1)-1;
  for(q1=2; q1<=nblks; q1++)  {
    lcllim_(q1)=lcllim_(q1-1)+solut4_(q1-1);
    lrwlim_(q1)=lrwlim_(q1-1)+rhs4_(q1-1);
    ucllim_(q1)=lcllim_(q1)-1;
    urwlim_(q1)=lrwlim_(q1)-1;
  }
/*
 *  compute the new position of input column j,
 *  and put into solut5(j)
 */
  for(j=1; j<=ncols; j++)  {
    q1=ciblk_(j);
    ucllim_(q1)=ucllim_(q1)+1;
    solut5_(j)=ucllim_(q1);
  }
/*
 *  compute the new position of input row i,
 *  and put into rhs5_(i)
 */
  for(i=1; i<=nrows; i++)  {
    q1=riblk_(i);
    urwlim_(q1)=urwlim_(q1)+1;
    rhs5_(i)=urwlim_(q1);
  }
/*
 *  update layer 3 problem using layer 2 as input
 *  column j is moved to position solut5_(j)
 */
  for(j=1; j<=ncols; j++)  {
    m=solut5_(j);
    for(l=1; l<=lclmax; l++)  {
      cl_(m,l,3)=cl_(j,l,2);
    }
/*
 *  shift pointer
 */
    ptamc_(m,3)=ptamc_(j,2);
/*
 *  shift total
 */
    nzamc_(m,3)=nzamc_(j,2);
    if (nzamc_(j,2)>0) {
      for(ix=1; ix<=nzamc_(j,2); ix++)  {
        is=amc_(ix+ptamc_(j,2),2);
        i=abs(is);
        if (is>0) {
          amc_(ix+ptamc_(m,3),3)=rhs5_(i);
        } else {
          amc_(ix+ptamc_(m,3),3)=-rhs5_(i);
        }
      }
    }
  }
/*
 *  new idxcol_(j) = solut5_(old(idxcol_(j))
 */
  for(j=1; j<=ncols; j++)  {
    cl_(j,20,3)=solut5_(cl_(j,20,2));
  }
 /*
 *  new invidxcol_(j1) from new idxcol_(j)
 */
  for(j1=1; j1<=ncols; j1++)  {
    j = cl_(j1,20,3); /* = new idxcol(j1) */
    cl_(j,26,3)=j1;
  } 
/*
 *  row i is moved to position rhs5_(i)
 */
  for(i=1; i<=nrows; i++)  {
    m = rhs5_(i);
    for(l=1; l<=lrwmax; l++)  {
      rw_(m,l,3)=rw_(i,l,2);
    }
/*
 *  shift pointer
 */
    ptamr_(m,3)=ptamr_(i,2);
/*
 *  shift total
 */
    nzamr_(m,3)=nzamr_(i,2);
    if (nzamr_(i,2)>0) {
      for(jx=1; jx<=nzamr_(i,2); jx++)  {
        js=amr_(jx+ptamr_(i,2),2);
        j=abs(js);
        if (js>0) {
          amr_(jx+ptamr_(m,3),3)=solut5_(j);
        } else {
          amr_(jx+ptamr_(m,3),3)=-solut5_(j);
        }
      }
    }
  }
/*
 *  new idxrow(i)  = rhs5(old idxrow(i))
 */
  for(i=1; i<=nrows; i++)  {
    rw_(i,23,3)=rhs5_(rw_(i,23,2));
  }
/*
 *  new invidxrow_(i1)
 */
  for(i1=1; i1<=nrows; i1++)  {
    i = rw_(i1,23,3); /* = new idxrow_(i1) */
    rw_(i,27,3) = i1;
  }
/*
 *  transfer reshuffled problem in layer 3 to layer 1
 */
  tranpr(c3,c1);

/* 
 *  validation of indexing functions for debugging
 *  compile with option "-DDEBUG" if changes affecting 
 *  idxcol, invidxcol idxrow, invidxrow have been made 
 *  and must be checked by the code below
 */
#ifdef DEBUG
    for (j=1;j<=ncols;j++) {
    if (invidxcol_(idxcol_(j)) != j) {
      printf(
       "Column indexing error for external column index = %ld/n",j);
      error(" reshuf "," 202 "); 
    }
  }
  for (j=1;j<=nrows;j++) {
    if (invidxrow_(idxrow_(j)) != j) {
      printf(
        "Row indexing error for external row index = %ld/n",j);
      error(" reshuf "," 204 ");
    } 
  }
#endif

  return;
} /* end of reshuf */

/*eject*/
/*
 * **********************************************************
 *  subroutine savecolrowcut  
 * 
 *  purpose:  saves cut information of
 *              ccut_(jx), jx = 1, 2, ..., ccut_(colmax+1)
 *              rcut_(jx), jx = 1, 2, ..., rcut_(rowmax+1)
 *            in
 *              colcut(j1,q), j = 1, 2, ..., colcut_(cutmax+1,q)
 *              rowcut(j1,q), j = 1, 2, ..., rowcut_(cutmax+1,q)
 *
 *  caution: ccut and rcut values are internal indices 
 *           colcut and rowcut values are external indices
 * **********************************************************
 * 
 */
void savecolrowcut() {
/*
 */
  long ix,jx,q,q1;
/*
 */
  q=qblock;

/*  
 *  make room for new node cutset
 */
  if (q < nblks) {
    for (q1 = nblks-1; q1 >= q; q1--) {
      for (jx = 1; jx <= colcut_(cutmax+1,q1); jx++) {
        colcut_(jx,q1+1) = colcut_(jx,q1);
      }
      colcut_(cutmax+1,q1+1) = colcut_(cutmax+1,q1);
      for (ix = 1; ix <= rowcut_(cutmax+1,q1);ix++) {
        rowcut_(ix,q1+1) = rowcut_(ix,q1);
      }
      rowcut_(cutmax+1,q1+1) = rowcut_(cutmax+1,q1);
    }
  }
  colcut_(cutmax+1,nblks+1) = 0;
  rowcut_(cutmax+1,nblks+1) = 0;
/*
 *  save cut information
 */
  if (scrflg == 1) {
    printf("\n");
    printf("size of min cut =%3ld\n",bstcut);
  }
  if (bstcut > cutmax) {
    error("savecolrowcut","   102  ");
  }

/* store cut information of ccut and rcut in 
 * colcut and rowcut arrays
 */

  for (jx=1; jx<=ccut_(colmax+1); jx++) {
    colcut_(jx,q) = invidxcol_(ccut_(jx));
  }
  colcut_(cutmax+1,q) = ccut_(colmax+1);

  for (ix=1; ix<=rcut_(rowmax+1); ix++) {
    rowcut_(ix,q) = invidxrow_(rcut_(ix));
  }
  rowcut_(cutmax+1,q) = rcut_(rowmax+1);

} /* end savecolrowcut */

/*eject*/
/*
 * ************************************************************
 *  subroutine shiftcutcols
 * 
 *  purpose: shift cut columns to 2nd, unlabeled, component
 *
 *  note: the error introduced by the shift is corrected
 *        when cut columns are added in addemptycols and
 *        when the data of cut columns are split in modifyrows
 *        and modifycols
 * ************************************************************
 */
void shiftcutcols() {

  long j;

  for (j=1;j<=ncols;j++) {
    if (cl_(j,17,2) == 1) { /* column j is in cut */
      cl_(j,18,2) = 0; /* assign column j to unlabeled component */
    }
  }

  return;

} /* end shiftcutcols */

/*  last record of comp.c****** */
