/*  first record of getparm.c***** */
/* Version selections  */

/* Select exactly one version size*/
#define version_size "full"
/* #define version_size "student" */

#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

/* ************************************* */
void getparm(char *pardir) {
/*
 *  gets compile parameters from file deccparams.dat
 *  or defines them directly. File deccparams.dat is
 *  in directory pardir. If pardir = empty string, current
 *  directory used.
 */
  long i, ix, m, n, nz;

  void vrsion();

/*
 *  begin program body
 *--------------------
 */

/*
 *  define Leibniz version
 */
  vrsion();

/*
 *  access flag and screen flag for details
 * 
 *  accflg = 1 details shown
 *         = 0 not details
 *
 *  scrflg = 1 print on screen
 *         = 0 no screen printing
 */
  accflg = 0; 
  scrflg = 0;
/*
 *  initialize xerror
 */
  xerror=0;

/*
 *  if no allocation of devices for execution
 *  has been made:
 *  initialize max size of formulations;
 *  caution: see exdyn.c for the
 *  conditions that must be satisfied by the
 *  parameters below
 */
  if (exalcflg==0) { 
    colmax = 1001;
    rowmax = 1001;
    anzmax = 20000;
    blkmax = 40;
    prbmax = 2;
    stomax = 2;
    laymax = 7;
  }

/*eject*/

/*
 *  initialize extension names
 */
  strcpy(&namext_(1,1),".log");
  strcpy(&namext_(1,2),".trs");
  strcpy(&namext_(1,3),".prg");
  strcpy(&namext_(1,4),".err");
  strcpy(&namext_(1,5),".lrn");

/*
 *  initialize version selection
 */
  selvr_(1) = 3;
  selvr_(2) = 6;
  nselvr = 2;
  satchk = 0;

/*
 *  initialize approximate minimization flag
 *  apmflg = 1 approx. minimization
 *         = 0 no approx. minimization
 */
  apmflg = 0;

/*
 *  initialize flags for defining transfer process
 *  trsprocessflg = 0 do not define transfer process
 *                = 1 define transfer process
 *  mktrsprocfilflg = 0 do not make transfer process files
 *                = 1 make transfer process files
 *  keepallvarflg    = 1 keep all variables of log formulation,
 *                    whether or not they are used in facts
 *                = 0 keep only variables used in facts
 *  nonusewarnflg = 0 skip warnings about unused variables
 *                    (specified in .log file but not used
 *                     in clauses)
 *                = 1 warn about unused variables
 *  outputprgflg  = 0 do not output compiled program to .prg file 
 *                = 1 output compiled program
 *  for details about condiptflg and related begcondiptword
 *  and endcondiptword, see below when deccparams.dat records
 *  are processed
 */
  trsprocessflg = 0;
  mktrsprocfilflg = 0;
  mincutflg = LINEAR;
  blockminsize = 0;
/*eject*/
/*  
 *  next two flags are essential for graph/matrix processing
 *  do NOT change their values
 */
  keepallvarflg = 1;   /* do NOT change this value */
  nonusewarnflg = 1;   /* do NOT change this value */

  outputprgflg = 0;
  condiptflg = -1;
  strcpy(begcondiptword,"");
  strcpy(endcondiptword,"");

/*eject*/

/*
 *  initialize time bound that forces switch to 
 *  approx. min.
 *  apmbnd >  0 switch to approx. min. if time bound 
 *                exceeds the specified value (sec)
 *         =  0 must do approx. min.   
 *         = -1 approx. min. not allowed
 */
  apmbnd = -1;

/*
 *  initialize learn flag and max learning cycles
 *  lrnflg    = 0 no learning
 *            = 1 learn using learn file
 *            = 2 learn from random statements
 *            = 3 learning completed
 *  lrnoutflg = 0 no output of learned rows
 *            = 1 file output of learned rows
 *  ilrnzero  = number of times, no learning takes place
 *              during a learning cycle
 *  nlrnzero  = max value allowed for nlrnzero   
 */
  lrnflg = 0;
  lrnoutflg = 0;
  ilrncyc = 1;
  nlrncyc = 1;
  ilrnzero = 0;
  nlrnzero = 5;

/*
 *  initialize machine speed (mips)
 */
  mspeed = 100;
  prbdir[0] = '\0';

/*eject*/

/*
 *  read and process parameter file, which is in directory
 *  pardir. If pardir = empty string, current directory is used.
 */
   strcpy(auxnam,pardir);
   strcat(auxnam,deccparamsname);
   prmfil = fopen(auxnam,"r");
   if (prmfil  == NULL) {
     printf("Cannot open deccparams.dat file %s",
            deccparamsname);
     if (strcmp(pardir,"") != 0) {
       printf("\nin %s directory",pardir);
     }
     printf(".\nStop.\n");
     fprintf(errfil,"Cannot open deccparams.dat file %s\n",
                    deccparamsname);
     if (strcmp(pardir,"") != 0) {
       fprintf(errfil,"\nin %s directory",pardir);
     }
     fprintf(errfil,".\nStop.\n");
     lbccexit(1);
   }

/*
 *  begin of reading loop
 */
  zz50:
  if (fgets(parstr,256,prmfil)==NULL) {
/*
 *  missing ENDATA record
 */
    printf("ENDATA record missing in deccparams.dat\nStop\n");
    fprintf(errfil,
           "ENDATA record missing in deccparams.dat\nStop\n");
    lbccexit(1);
  }

/*
 *  change all string characters 
 *  with ascii code 1-31 or 127-254 by blanks
 */
  nz = strlen(parstr);
  for(i=1; i<=nz; i++)  {
    ix = (int)parstr_(i);
    if (((ix>=1)&&
        (ix<=31))||
        ((ix>=127)&&
        (ix<=254))) {
      parstr_(i) = ' ';
    }
  }
/*
 *  introduce carriage return character and,
 *  if necessary, new end of string character
 */
  if (parstr_(nz) == ' ') {
    parstr_(nz) = '\n';
  } else {
    parstr_(nz+1) = '\n';
    parstr_(nz+2) = '\0';
    nz++;
  }  
/*
 *  compress string and look for '='
 */
  m = 0;
  n = 0;
  for (i=1;i<=256;i++) {
    if (parstr_(i) == ' ') {
      n = n + 1;
    } else {
      parstr_(i-n) = parstr_(i);
      if (parstr_(i) == '=') {
        m = i - n + 1;
      }
      if (parstr_(i-n)=='\n') {
        parstr_(i-n)='\0';
        goto zz55;
      }
    }
  }
  printf("Error while processing deccparams.dat record:\n");
  printf("\n%s\n",parstr);
  printf("Stop\n");
  fprintf(errfil,
      "Error while processing deccparams.dat record:\n");
  fprintf(errfil,"\n%s\n",parstr);
  fprintf(errfil,"Stop\n");
  lbccexit(1);

/*eject*/

  zz55:
 /*  
 *  if parstr has become null string, skip record
 */
  if (parstr_(1)=='\0') {
    goto zz50;
  }

/*
 *  comment - skip to next line
 */
  if (parstr_(1) == '*') {
    goto zz50;
  }

/*
 *  ENDATA record - close parameter file, process parameters
 */
  if (strcmp(parstr,"ENDATA") == 0) {
    fclose(prmfil);
    goto zz80;
  }

/*
 *  process parstr
 */

/*
 *  "show steps on screen"
 */
  if (strncmp(parstr,"showmajo",8) == 0) {
    scrflg = 1;
    printf("show steps on screen\n");
    printf("             Leibniz System\n");
    printf("            decc System\n");
    printf("              Version %s\n",lbzver);
    printf("     Copyright 1990-2015 by Leibniz\n");
    printf("          Plano, Texas, U.S.A.\n\n");
    goto zz50;
  }

  if (strncmp(parstr,"showalld",8) == 0) {
    printf("show all details\n");
    if (scrflg == 0) {
      printf("show steps on screen\n");
      printf("             Leibniz System\n");
      printf("            decc System\n");
      printf("              Version %s\n",lbzver);
      printf(" Copyright 1990-2015 by Leibniz Company\n");
      printf("          Plano, Texas, U.S.A.\n\n");
      scrflg = 1;
    }
    accflg = 1;
    goto zz50;
  }

/*
 *  "output results to program/blocks file"
 */
  if (strncmp(parstr,"outputre",8) == 0) {
    outputprgflg = 1;
    if (scrflg == 1) {
      printf("output results to program/blocks file\n");
    }
    goto zz50;
  }

/*eject*/
/*
 *  all lines of deccparams.dat without '=' must be
 *  processed above this point
 *  below, have error if no '='
 */
  if (m == 0) {
    printf("Cannot decode deccparams.dat record:\n");
    printf("\n%s\n",parstr);
    printf("Possibly '=' missing in record\n");
    printf("Stop\n");
    fprintf(errfil,"Cannot decode deccparams.dat record:\n");
    fprintf(errfil,"\n%s\n",parstr);
    fprintf(errfil,"Possibly '=' missing in record\n");
    fprintf(errfil,"Stop\n");
    lbccexit(1);
  }
/*
 *  error if no r.h.s value in record
 */
  if (parstr_(m) == '\0') {
    printf("Error in deccparams.dat file\n");
    printf(" r.h.s. missing in record\n");
    printf("\n%s\n",parstr);
    printf("Stop\n");
    fprintf(errfil,"Error in deccparams.dat file\n");
    fprintf(errfil," r.h.s. missing in record\n");
    fprintf(errfil,"\n%s\n",parstr);
    fprintf(errfil,"Stop\n");
    lbccexit(1);
  }

/*
 *  extract parameters
 */

/*eject*/

/*
 *  input file
 */
  if (strncmp(parstr,"inputfil",8) == 0) {
    strcpy(filnam,&parstr_(m));
    if (scrflg == 1) {
      printf("input file             = %s\n",filnam);
    }
    goto zz50;
  }

/*
 *  input directory
 */
  if (strncmp(parstr,"inputdir",8) == 0) {
    strcpy(prbdir,&parstr_(m));
    if (scrflg == 1) {
      printf("input directory        = %s\n",prbdir);
    }
    goto zz50;
  }

/*
 *  file extensions
 *  leave existing '.' unchanged by strcpy step
 */
  if (strncmp(parstr,"logic",5) == 0) {
    strcpy(&namext_(2,1),&parstr_(m));
    if (scrflg == 1) {
      printf("logic/matrix file extension    = %s\n",
               &namext_(1,1));
    }
    goto zz50;
  }

  if (strncmp(parstr,"transferfile",12) == 0) {
    strcpy(&namext_(2,2),&parstr_(m));
    if (scrflg == 1) {
      printf("transfer file extension        = %s\n",
               &namext_(1,2));
    }
    goto zz50;
  }

  if (strncmp(parstr,"program",7) == 0) {
    strcpy(&namext_(2,3),&parstr_(m));
    if (scrflg == 1) {
      printf("program/blocks file extension  = %s\n",
               &namext_(1,3));
    }
     goto zz50;
  }

  if (strncmp(parstr,"errorfil",8) == 0) {
    strcpy(&namext_(2,4),&parstr_(m));
    if (scrflg == 1) {
      printf("error file extension           = %s\n",
              &namext_(1,4));
    }
    goto zz50;
  }

  if (strncmp(parstr,"learnedc",8) == 0) {
    strcpy(&namext_(2,5),&parstr_(m));
    if (scrflg == 1) {
      printf("learned clauses file extension = %s\n",
              &namext_(1,5));
    }
    goto zz50;
  }

/*
 *  colmax (max number of variables)
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 */
  if (strncmp(parstr,"colmax(m",8) == 0) {
    if (exalcflg==0) {    
      sscanf(&parstr_(m),"%ld",&colmax);
      if (scrflg == 1) {
        printf("colmax (max columns)   = %ld\n",colmax);
      }
    } else {
      if (scrflg == 1) {
        printf("colmax (max columns) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*
 *  rowmax (max number of clauses)
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 */
  if (strncmp(parstr,"rowmax(m",8) == 0) {
    if (exalcflg==0) {
      sscanf(&parstr_(m),"%ld",&rowmax);
      if (scrflg == 1) {
        printf("rowmax (max rows)      = %ld\n",rowmax);
      }
    } else {
      if (scrflg == 1) {
        printf("rowmax (max rows) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*
 *  anzmax (max number of literals)
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 */
  if (strncmp(parstr,"anzmax(m",8) == 0) {
    if (exalcflg==0) {
      sscanf(&parstr_(m),"%ld",&anzmax);
      if (scrflg == 1) {
        printf("anzmax (max nonzeros)  = %ld\n",anzmax);
      }
    } else {
      if (scrflg == 1) {
        printf("anzmax (max nonzeros) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*
 *  blkmax (max number of blocks)
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 */
  if (strncmp(parstr,"blkmax(m",8) == 0) {
    if (exalcflg==0) {
      sscanf(&parstr_(m),"%ld",&blkmax);
      if (scrflg == 1) {
        printf("blkmax (max blocks)    = %ld\n",blkmax);
      }
    } else {
      if (scrflg == 1) {
        printf("blkmax (max blocks) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*  cutmax (max size of cutset)
 *  
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 *
 *  caution:  if range calculations 
 *            are also done, must consider rgemax 
 *            and cutmax interaction
 *            for example, may require
 *            rgemax >= 2**cutmax
 */
  if (strncmp(parstr,"cutmax(m",8) == 0) {
    if (exalcflg==0) {
      sscanf(&parstr_(m),"%ld",&cutmax);
      if (cutmax < 3 ) {
        printf("specified cutmax = %ld is too small and\n",cutmax);
        printf("is increased to the minimum value = 3\n");
        cutmax = 3;
      }
      if (scrflg == 1) {
        printf("cutmax (max cutset)    = %ld\n",cutmax);
      }
    } else {
      if (scrflg == 1) {
        printf("cutmax (max cutset) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*eject*/ 
/*
 *  decomposition process
 */
  if (strncmp(parstr,"decomposition",12) == 0) {
    strcpy(auxnam,&parstr_(m));
    if (scrflg == 1) {
      printf("decomposition process = %s\n",
         auxnam);
    }

/* linear decomposition */

    if (strcmp(auxnam,"version0")==0) {
      nselvr = 1;
      selvr_(1) = 0;
      decompositionflg = LINEAR;
      goto zz50; 
    } else if (strcmp(auxnam,"version1")==0) {
      nselvr = 1;
      selvr_(1) = 1;
      decompositionflg = LINEAR;
      goto zz50;
    } else if (strcmp(auxnam,"version2")==0) {
      nselvr = 1;
      selvr_(1) = 2;
      decompositionflg = LINEAR;
      goto zz50;
    } else if (strcmp(auxnam,"version3")==0) {
      nselvr = 1;
      selvr_(1) = 3;
      decompositionflg = LINEAR;
      goto zz50;
    } else if (strcmp(auxnam,"version4")==0) {
      nselvr = 1;
      selvr_(1) = 4;
      decompositionflg = LINEAR;
      goto zz50;
    } else if (strcmp(auxnam,"version5")==0) {
      nselvr = 1;
      selvr_(1) = 5;
      decompositionflg = LINEAR;
      goto zz50;
    } else if (strcmp(auxnam,"version6")==0) {
      nselvr = 1;
      selvr_(1) = 6;
      decompositionflg = LINEAR;
      goto zz50;
    } else if (strcmp(auxnam,"version7")==0) {
      nselvr = 1;
      selvr_(1) = 7;
      decompositionflg = LINEAR;
      goto zz50;
    } else if (strcmp(auxnam,"version8")==0) {
      nselvr = 1;
      selvr_(1) = 8;
      decompositionflg = LINEAR;
      goto zz50;
    } else if (strcmp(auxnam,"version9")==0) {
      nselvr = 1;
      selvr_(1) = 9;
      decompositionflg = LINEAR;
      goto zz50;
/* tree decomposition */

    } else if (strcmp(auxnam,"version10")==0) {
      nselvr = 1;
      selvr_(1) = 10;
      decompositionflg = TREE;
      goto zz50;
    }
  }

/*eject*/

/*
 *  cut selection option
 */
  if (strncmp(parstr,"cutselection",12) == 0) {
    strcpy(auxnam,&parstr_(m));
    if (scrflg == 1) {
      printf("cut selection = %s\n",
         auxnam);
    }
    if (strcmp(auxnam,"onlycols")==0) {
      mincutflg = ONLYCOLS;
    } else if (strcmp(auxnam,"prefercols")==0) {
      mincutflg = PREFERCOLS;
    } else if (strcmp(auxnam,"preferrows")==0) {
      mincutflg = PREFERROWS;
    }
    if ((mincutflg == PREFERCOLS || mincutflg == PREFERROWS) &&
        (decompositionflg == TREE)) {
      printf("Tree decomposition cannot use cut selection option\n");
      printf("'prefer cols' or 'prefer rows'\n"); 
      printf("Stop\n");
      fprintf(errfil,
             "Tree decomposition cannot use cut selection option\n");
      fprintf(errfil,
              "'prefer cols' or 'prefer rows'\n");
      fprintf(errfil,"Stop\n");
      lbccexit(1);
    }
    goto zz50;
  }

/*
 *  block min size selection option
 */
  if (strncmp(parstr,"blockminsize",12) == 0) {
    sscanf(&parstr_(m),"%ld",&blockminsize);
    if (scrflg == 1) {
      printf("block min size = %ld\n",
             blockminsize);
    }
    goto zz50;
  } 
/*eject*/
/*
 *  names of transfer files
 *  defs.h file
 */
  if (strncmp(parstr,"transferdefs",12) == 0) {
    strcpy(trsdefsfil_name,prbdir);
    strcat(trsdefsfil_name,&parstr_(m));
    strcpy(trsdefsfil_nopa,&parstr_(m));
    if (scrflg == 1) { 
      printf("transfer defs.h file = %s\n",trsdefsfil_nopa);
    }
    goto zz50;
  }

/*
 *  exts.h file
 */
  if (strncmp(parstr,"transferexts",12) == 0) {
    strcpy(trsextsfil_name,prbdir);
    strcat(trsextsfil_name,&parstr_(m));
    strcpy(trsextsfil_nopa,&parstr_(m));
    if (scrflg == 1) { 
      printf("transfer exts.h file = %s\n",trsextsfil_nopa);
    }
    goto zz50;
  }

/*
 *  code file
 */
  if (strncmp(parstr,"transfercode",12) == 0) {
    strcpy(trscodefil_name,prbdir);
    strcat(trscodefil_name,&parstr_(m));
    strcpy(trscodefil_nopa,&parstr_(m));
    if (scrflg == 1) { 
      printf("transfer code file = %s\n",trscodefil_nopa);
    }
    goto zz50;
  }

/*
 *  learn using specified file
 */
  if (strncmp(parstr,"learnusi",8) == 0) {
    strcpy(auxnam,&parstr_(m));
    if (scrflg == 1) {
      printf("learn using file = %s\n",auxnam);
    }
    if (strcmp(auxnam,"random")==0) {
      lrnflg = 2;
    } else {
      lrnflg = 1;
    }
    goto zz50;
  }

/*
 *  max learning cycles
 */
  if (strncmp(parstr,"maxlearn",8) == 0) {
    sscanf(&parstr_(m),"%ld",&nlrncyc);
    if ((scrflg == 1)&&
        (lrnflg>=1)) {
      printf("max learning cycles = %ld\n",
              nlrncyc);
    }
    goto zz50;
  }

/*
 *  machine speed
 */
  if (strncmp(parstr,"machines",8) == 0) {
    sscanf(&parstr_(m),"%ld",&mspeed);
    if (scrflg == 1) {
      printf("machine speed %ld mips\n",mspeed);
    }
    goto zz50;
   }

/*eject*/

/*
 *  write condensed input into file
 *
 *  condensed: no INCLUDE statements
 *             if a record has only comments or is blank,
 *             it is skipped
 *             all statements in one file
 *
 *  process is controlled by condiptflg
 *  begcondiptword = begin keyword, triggers beginning of
 *                   writing; record containing the keyword
 *                   becomes part of the condensed output
 *                   if keyword = empty string, begin writing
 *                   with first record
 *  endcondiptword = end keyword, triggers end of writing
 *                   record containing the keyword does not
 *                   become part of the condensed output
 *                   if keyword = empty string, no early
 *                   termination
 *  caution: if keyword for begin or end is a special word
 *  of the leibniz syntax, then the test for presence always
 *  uses upper case version for the test
 *  thus the test becomes independent of user version of keywords
 *
 *  condiptflg = 
 *    -1: no writing takes place
 *     0: writing planned, but begin keyword has not yet
 *        been reached
 *     1: begin keyword has been reached or passed, and
 *        writing is taking place
 *     2: end keyword has been reached or passed, and
 *        writing has stopped 
 *
 *  write condensed input into file
 */
  if (strncmp(parstr,"writecondensed",14) == 0) {
    condiptflg = 0;
    strcpy(condiptfil_name,&parstr_(m));
    if (scrflg == 1) {
      printf(
       "write condensed input file into = %s\n",&parstr_(m));
    }
    goto zz50;
   }
/*
 * begin condensed input keyword
 */ 
  if (strncmp(parstr,"begincondensed",14) == 0) {
    strcpy(begcondiptword,&parstr_(m));
    if (scrflg == 1) {
      printf(
       "begin condensed input keyword = %s\n",&parstr_(m));
    }
    goto zz50;
   }
/*
 * end condensed input keyword
 */
  if (strncmp(parstr,"endcondensed",12) == 0) {
    strcpy(endcondiptword,&parstr_(m));
    if (scrflg == 1) {
      printf(
       "end condensed keyword = %s\n",&parstr_(m));
    }
    goto zz50;
   }

/*
 *  unknown record type
 */
  printf("Cannot decode deccparams.dat record:\n");
  printf("\n%s\n",parstr);
  printf("Stop\n");
  fprintf(errfil,"Cannot decode deccparams.dat record:\n");
  fprintf(errfil,"\n%s\n",parstr);
  fprintf(errfil,"Stop\n");
  lbccexit(1);

/*eject*/
/*
 *  done with reading deccparams.dat
 *  assemble file names and finish preparation of parameters
 */
  zz80:

/*
 *  define log, trs, prg, lrn files, 
 *  and learn row file
 *  also initialize problem directory string
 *  in position logfilmax+1 of logfil_name for later use
 *
 *  first check that input file has correct logic file
 *  extension
 */
  m = strlen(&namext_(1,1));
  n = strlen(filnam);
  if (strcmp(&filnam_(max(1,n-m+1)),&namext_(1,1))!=0) {
/*
 *  extension of input file name filnam does not match
 *  log file extension in namext_(1,1)
 */
    printf("Error in deccparams.dat file\n"
           "Input file name extension does"
           " not match logic extension\n"
           "Stop\n");
    fprintf(errfil,
           "Error in deccparams.dat file\n"
           "Input file name extension does"
           " not match logic extension\n"
           "Stop\n");      
    lbccexit(1);   
  }
/*
 *  remove logic file extension from input file name
 */
  filnam_(n-m+1) = '\0';
/*
 *  construct all file names
 */
  strcpy(logfil_name,prbdir);
  strcpy(&logfil_name_(1,logfilmax+1),logfil_name);
  strcat(logfil_name,filnam);
  strcpy(trsprobfil_nopa,filnam);
  strcpy(trsprobfil_name,logfil_name);
  strcpy(prgfil_name,logfil_name);
  strcpy(errfil_name,logfil_name);
  strcpy(lrnrowfil_name,logfil_name);
  strcat(logfil_name,&namext_(1,1));
  strcat(trsprobfil_nopa,&namext_(1,2));
  strcat(trsprobfil_name,&namext_(1,2));
  strcat(prgfil_name,&namext_(1,3));
  strcat(errfil_name,&namext_(1,4));
  strcat(lrnrowfil_name,&namext_(1,5));
  if (lrnflg == 1) {
    strcpy(lrnthmfil_name,prbdir);
    strcat(lrnthmfil_name,auxnam);
  } else {
    strcpy(lrnthmfil_name,"\0");
  }

/*
 *  done
 */
  return;
}
/*  last record of getparm.c***** */
