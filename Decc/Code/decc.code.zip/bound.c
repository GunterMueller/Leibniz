/*  first record of bound.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*
 * **********************************************************
 *  module bounds
 * 
 *  purpose:  establishes bounds on solution,
 *            either by number of fixed variables and range data,
 *            or by running solution program
 * 
 *    input:  ('*' means condition tested in chkque)
 *            problem in layer 1.
 *            arrays assumed defined:
 *             - matrix data amatcl, amatrw
 *             - ncols, nrows, nblks
 *             - colnam, rownam, prbnam
 *             - idxrow, idxcol
 *             - dlclop, dlrwop
 *       - no column j deleted (ciina(j) .ne. 2)
 *       - no row i deleted (riina(i) .ne. 2)
 *               remaining indices must be consistent with these
 *               assignments.
 *               note: ciina(j) = +/-1 and riina(i) = 1 are 
 *                     possible
 *               due to effect of atf variables
 *             - matrix counts cnxxx, rnxxx
 *       - lcllim, ucllim, lrwlim, urwlim, scale, drange, erange,
 *               ndrge, nerge, gpod, gpoe, gpodp, gpoep,
 *               twosat must have been computed.
 *       - rhs1(i) = 1 for all rows i
 *       - cost(j) for all columns j; must be nonnegative.
 * 
 *   calling sequence:
 * 
 *         apmtme      computes estimated time for approx. min.
 * 
 * 
 *         bdtsol      computes upper bound on solution time
 *                     using number of fixed variables and 
 *                     range data
 * 
 *   caution:  uses layer 2 for intermediate storage.
 * **********************************************************
 * 
 * 
 * **********************************************************
 *  subroutine apmtme
 * 
 *  purpose:  computes estimated time bound for approximate
 *            minimization via linear programming
 * 
 *  input:    realts = time bound for satisfiability check
 * 
 *  output:   realtl = estimated time for approx. min.
 * **********************************************************
 * 
 */
void apmtme() {
/*
 *  lp code dependent constant realk = sec/m*m for 1 mips machine
 *                                     where m = number of lp rows
 *  expresses time required to solve an lp with m rows using 1 mip
 * 
 *  constant below is for xmp
 */
  realk=0.01;
  realtl=0.0;
/*
 *  eliminated timing consideration for satisfiability tests
 *  below feb 1994 since the time bound typically is far too large
 *  to be realistic
 * 
 *  time for constructing heuristic solution
 *      realtp = ncols
 *      realtl = realtp * realts
 * 
 *  time for finding optimal lp solution
 */
  realtp=nrows;
  realtp=realtp*realtp;
  realtl=realtl+realtp*realk;
/*
 *  time for rounding (estimated time is taken to be time spent
 *                     so far)
 */
  realtl=realtl*2.0;
/*
 *  have total time for 1 mips machine
 *  adjust time for machine speed
 */
  realtl=realtl/mspeed;
  return;
}
/*
 * *****************************************************************
 *  subroutine bdtsol
 * 
 *  purpose:  computes upper bound on solution time
 *            for problem in layer 1, and
 *            log2 values for each ndrge(q) * nerge(q)
 * 
 *            uses number of fixed variables and range data
 *            to determine bounds
 * 
 *    input:  as specified in module summary
 * 
 *   output:  realts = bound on solution time
 *            logrge(q) = log2 of ndrge(q) * nerge(q); for all q
 * 
 * 
 * ******************************************************************
 * 
 */
void bdtsol() {
/*
 */
  static double realf1,realf2,rexpml;
  static long j,logn,n,nn,q,exp;
/*
 *  compute logrge using ndrge and nerge
 */
  logrge_(nblks)=0;
  if (nblks>1) {
    for(q=1; q<=nblks; q++)  {
      n=ndrge_(q)*nerge_(q);
/*
 *  compute log(2)(n) rounded up and place into logrge(q)
 */
      logn=0;
      nn=1;
      zz350:;
      if (nn<n) {
        logn=logn+1;
        nn=nn*2;
        goto zz350;
      }
      logrge_(q)=logn;
    }
  }
/*
 *  count entries in each block strip
 */
  for(q=1; q<=nblks; q++)  {
/*
 *  initialize counter
 */
    ablkct_(q)=0;
    for(j=lcllim_(q); j<=ucllim_(q); j++)  {
      if (cvatf_(j)==0) {
        ablkct_(q)=ablkct_(q)+nzamac_(j);
      } else {
        ablkct_(q)=ablkct_(q)+1;
      }
    }
/*
 *  if block q >= 2: increase block count if actual count
 *  is less than nrows to account for computing effort
 *  involving all rows
 */
    if ((q>=2)&&(ablkct_(q)<nrows)) {
      ablkct_(q)=nrows;
    }
  }
/*
 *  calculate total number of instructions
 */
  realf1=ablkct_(1);
/*
 *  guard against overflow
 */
  if (bdfxbl_(1)<75) {
    exp=bdfxbl_(1);
  } else {
    exp=75;
  }
  rexpml=1.0;
  if (exp>0) {
    for(n=1; n<=exp; n++)  {
      rexpml=rexpml*2.0;
    }
  }
  if (nblks==1) {
    realts=(realf1*(rexpml+5.))/100.;
  } else {
    realf2=ndrge_(1)*nerge_(1);
    realts=(realf1*realf2*(rexpml+5.))/100.;
    for(q=2; q<=nblks; q++)  {
/*
 *  guard against overflow
 */
      if (bdfxbl_(q)<75) {
        exp=bdfxbl_(q);
      } else {
        exp=75;
      }
      rexpml=1.0;
      if (exp>0) {
        for(n=1; n<=exp; n++)  {
          rexpml=rexpml*2.0;
        }
      }
      realf1=ablkct_(q);
      if (q<nblks) {
        realf2=ndrgep_(q)*nergep_(q);
        realts=realts+(realf1*
            realf2*(rexpml+5.))/100.;
      } else {
        realf2=ndrge_(q-1)*nerge_(q-1);
        realts=realts+(realf1*realf2*
            (rexpml+5.))/100.;
      }
    }
  }
  realts=
     ((realts/10.)*(double)inselt)/((double)mspeed*1000.);
/*
 *  correction factor, introduced Jan 2001
 */
  realts = 2.0 * realts;
/*
 */
  if (accflg == 1) {
    printf("Machine speed (mips) = %ld\n",mspeed);
    printf("Time bound (sec)     = %9.3f\n",realts);
  }
  return;
}
/*  last record of bound.c****** */
