/*  first record of deccmain.c***** */
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*
 *  Leibniz System
 *  Copyright 1990-2015 by Leibniz Company
 *  Plano, Texas, U.S.A.
 *   
 *  This program is free software: you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free Software
 *  Foundation, either version 3 of the License, or (at your option) any later
 *  version. The License statement is in file lgpl.txt, but can also be obtained
 *  from www.gnu.org/licenses/.
 *
 *  We do not make any representation or warranty, expressed or implied, 
 *  as to the condition, merchantability, title, design, operation, or fitness 
 *  of the program for a particular purpose.
 *
 *  We do not assume responsibility for any errors, including mechanics or logic, 
 *  in the operation or use of the program, and have no liability whatsoever 
 *  for any loss or damages suffered by any user as a result of the program.
 * 
 *  In particular, in no event shall we be liable for special, incidental, 
 *  consequential, or tort damages, even if we have been advised of the 
 *  possibility of such damages.
 *
 * ===================================================
 * decc System - Main Decomposition Program deccmain
 * ===================================================
 * caution: all routines must be compiled with -DMATRIX
 *          option
 *          do NOT compile with -DLOGIC option
 *          the #ifdef LOGIC - #endif labels are employed
 *          only to point out code used in the logic case
 */
int main(int argc, char *argv[]){ // argc and argv for deccparams
                                  // file definition
/*
 */
  void exdyn_alloc();
  void exdyn_free();
  void getparm();
  void decc();
/*
 *  begin program body
 *--------------------
 */

  /* deccparams file name option 
   *  if no name given, use default "deccparams.dat" 
   */
  if (argc == 2 && strcmp(argv[1],"") != 0) {
    strcpy(deccparamsname,argv[1]);
  } else {
    strcpy(deccparamsname,"deccparams.dat");
  }

/*  open error file errfil with temporary name deccparams.err
 */
  errfil = fopen("deccparams.err", "w");
  if (errfil == NULL) {
    printf(
      "\nCannot open error file deccparams.err. Stop\n");
    lbccexit(1);
  }
/*
 *  define parameters using deccparams.dat
 *  argument of getparm() is empty string since
 *  deccparams.dat is expected in current directory
 */
  getparm("");
/*
 *  close errfil and reopen with correct name
 */
  fclose(errfil);
  errfil = fopen(errfil_name, "w");
  if (errfil == NULL) {
    printf(
     "\nCannot open error file %s. Stop\n",errfil_name);
    lbccexit(1);
  }
/*
 *  allocate for execution
 */
  exdyn_alloc();
/*
 *  translate .log file and generate program
 */
  decc();
/*
 *  deallocate execution arrays
 */
  exdyn_free();
/*
 *  close errfil
 */
  fclose(errfil);
/*
 * done
 */
  lbccexit(0);
  exit(0); /* added to suppress compiler error message */
}
/*  last record of deccmain.c***** */
