/*  first record of apmsol.c***** */
/*
 * *******************************************************
 *  subroutine apmsol(uname,ustate,utype,uvalue,uerror)
 * 
 *  purpose: approximate minimization of sol prb command
 * 
 *  ucomnd, uname, ustate, utype, uvalue, uerror are
 *  the parameters sent from query2 subroutine.,
 *  sol prb command. we load local variables
 *  pname, pstate, ptype, pvalue, perror
 *  with these values and use them inside apmsol.
 *  prior to exit of apmsol, the input variables are
 *  loaded with the local variables.
 * 
 *  caution: 1. current problem is assumed to be in level 1
 *           2. apmsol does not carry out any steps of the
 *              transfer process. So if that process is used,
 *              must do appropriate transfer steps prior to 
 *              and after call of apmsol
 * *******************************************************
 */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();

/*
 */
void apmsol(char *uname,char *ustate,char *utype,
            long *uvalue,short *uerror) {
/*
 */
  void cstxpr(), disprm(), errmsg(), error();
  void gusxpr(), icacin(), icinac();
  void lpexec(), sol_xct();
  void urinac(), xaact(), xaart();
/*
 */
  static char ucomnd[64+1];
  static char pname[128+1];
  static char pstate[1+1];
  static char ptype[4+1];
  static long pvalue[8];
  static short perror[2];
/*
 *  temporary variables and indices
 */
  static long flg,i,ix,ilp,j,jx,jj,jlp,jjlp,js;
  static long pf1,pf2,pfm1,pfm2,ptry;
  static long br,nr,todo,dolp,ps;
  static long neg,cst,dcst,gcd,hcst,ct;
  static double lr,ur;
/*
 */
  static long majit;
/*
 *  major iteration count (rounding)
 * 
 */
  static long majlm;
/*
 *  major iteration limit (rounding)
 * 
 */
  static long svpd;
/*
 *  indicator for saving primal variable classification and
 *  dual values
 *           = 0: do not save
 *           = 1: do save
 * 
 */
  static long detail;
/*
 *  details of iterations displayed
 *  (=1: display; =0: do not display)
 * 
 */
  static long phase;
/*
 *  phase of solution process
 *           phase = 1: solve lp, and reduce problem
 *           phase = 2: solve reduced lp,
 *                      then round for ip solution
 * 
 */
  static long precsn;
/*
 *  precision level for multiple rounding
 *  (range: 1 .. prcmax)
 * 
 */
  static long trdflg;
/*
 *  rounding flag, see step 1 for details
 */
  static double almzro,almone;
/*
 *  almost 0, almost 1
 * 
 */
  static double eps;
/*
 *  epsilon value used for rounding
 * 
 */
  static double epsb;
/*
 *  epsilon perturbation for right hand side of lp
 * 
 */
  static long opt;
/*
 *  optimization flag
 *  (=1: globally optimal; =0: have lower bound)
 * 
 */
  static long nanzlp;
/*
 *  number of nonzeros in lp, excluding slacks
 * 
 */
  static long ncollp;
/*
 *  number of variables in lp, excluding slacks
 *  (=n1 of lpexec routine)
 * 
 */
  static long nrowlp;
/*
 *  number of rows of lp (=mrows of lpexec routine)
 * 
 */
  static long mgs;
/*
 *  number of active goal rows
 * 
 */
  static long lpmin;
/*
 *  lower bound on minimum cost solution
 * 
 */
  static long nrv;
/*
 *  nmber of rounded variables
 * 
 */
  static long nrdc;
/*
 *  number of rounding cases
 * 
 */
  static double zv;
/*
 *  objective function value
 *  (=z of lpexec routine (maximization))
 * 
 * 
 *  all arrays below are declared
 *  in common block apmcm1,2
 *  definitions are included below
 *       real    * 8      rndzv(casmax)
 *  objective function values of rounded cases
 *       real    * 8      deltaz(prcmax)
 *  best z-value of opposite 0/1 case, for each variable
 *  (used for multiple rounding)
 * 
 *       integer * 4      xcl2lp(colmax)
 *  col index: from level 1 matrix j to xcl2lp(j) = jlp of lp
 *       integer * 4      xlp2cl(colmax)
 *  col index: from jlp of lp to xlp2cl(jlp) = j of level 1 matrix
 *       integer * 4      xrw2lp(rowmax)
 *  row index: from level 1 matrix i to xrw2lp(i) = ilp of lp
 *       integer * 4      xlp2rw(rowmax)
 *  row index: from ilp of lp to xlp2rw(ilp) = i of level 1 matrix
 * 
 *       integer * 4      lpstat(colmax+2*rowmax)
 *  status of lp variables (basic versus nonbasic)
 * 
 *       integer * 4      rndcl(prcmax)
 *  indices of columns j of level 1 matrix to be rounded
 *       integer * 4      rndcas(prcmax,casmax)
 *  matrix of rounding cases
 *       integer * 4      rndfsb(casmax)
 *  flags of feasible rounding cases
 *  (=1: feasible; =0: infeasible)
 *       real * 8         lrrval(6)
 *  lower value for interval i involved in rounding
 *       real * 8         urrval(6)
 *  upper value for interval i involved in rounding
 *       integer * 4      nlurr(6)
 *  number of cases in interval lrrval(i), urrval(i),
 *  and not in interval with index i-1 
 * 
 *       integer * 4      ciacpr(colmax)
 *  indicator for columns active when approximate min.
 *  was started
 *  (=1: was active at start; =0 was not active at start)
 * 
 *  variables used with same interpretation
 *  in lpexec routine
 *  caution: do not use these variables  as temporary
 *           variables  or as indices
 */
  static long mrows;
/*
 *  number of rows of lp (=nrowlp)
 */
  static long ntotal;
/*
 *  number of columns of lp, including slacks
 */
  static long n1;
/*
 *  number of columns of lp, excluding slacks (=ncollp)
 */
  static long n2;
/*
 *  number of slacks of logic rows of lp
 */
  static long n3;
/*
 *  number of nonzeros of lp, including slacks
 * 
 *  lp is constructed using active logic columns and
 *  active goal constraints
 * 
 *  diagram of lp:
 *       |         |       |>= type|<= type|
 *       |  logic  | logic | goal  | goal  |
 *       |   vars  |slacks |slacks |slacks |
 *       |n1=ncollp|   n2  |  mgs  |  mgs  |       rhs
 * ------|---------|-------|-------|-------|      |----|
 *       |  logic  |-1     |       |       |      |    | ki = no. of
 *  n2   |   rows  |   .   |   0   |   0   |      |1-ki|      -1s in
 *       |         |    -1 |       |       |      |    |      logic
 * ------|---------|-------|-------|-------|  =   |----|      rows
 *       |  goal   |       |-1     |+1     |      |red.|
 *  mgs  |  rows   |   0   |   .   |   .   |      |goal| = entry from
 *       |         |       |     -1|     +1|      | qty|   goalrq
 * ------|---------|-------|-------|-------|      |----|   array
 * cost    cost(j)        ghicst(i) glocst(i)
 * 
 * 
 * 
 *  mrows  = nrowlp
 *         = total number of rows of lp
 *         = n2 + mgs
 *  nanzlp = number of nonzeros of lp, excluding slacks
 *  n3     = total number of nonzeros of lp,
 *           including slacks
 *         = nanzlp + n2 + 2*mgs
 *  ntotal = total number of columns of lp,
 *           including slacks
 *         = n1 + n2 + 2*mgs
 * 
 *  goal constraints: given the constraint with
 *                    g = coefficient and x = variable
 *  g.x             ... = b
 *  equivalent:
 *  (-g)(-x)        ... = b
 *  (-g) + (-g)(-x) ... = b + (-g)
 *  (-g)(1-x)       ... = b + (-g)
 *     let y = 1-x = scaled variable = complement of x in logic
 *  (-g)y           ... = b + (-g)
 *   note: (-g) = internal goal coefficient of y
 *              = scaled goal coefficient of x
 *  thus: when a logic column is scaled,
 *        also scale the goal coefficient g,
 *        and substract g from the right hand
 *        side goal value
 * 
 * 
 *  transfer parameters to local variables
 */
  strcpy(ucomnd,"sol_prb");
  strcpy(pname ,uname);
  strcpy(pstate,ustate);
  strcpy(ptype ,utype);
  for(i=1; i<=8; i++)  {
    pvalue_(i)=uvalue_(i);
  }
  for(i=1; i<=2; i++)  {
    perror_(i)=0;
  }
/*eject*/
/*
 * -----------------------------------------
 *  step 1
 *  initialize several local variables
 *  check satisfiability
 * ------------------------------------------
 *
 *  verify that lpx allocation has not been done
 */
  if (lpxalcflg==1) {
    error("apmsol","102");
  }
/*
 *  allocate lpx memory using colmax, rowmax, anzmax
 *  also determine handling of xmp log and error messages
 */
  strcpy(xcomnd,"ALC DIM");
/*
 *  define parameters for memory allocation
 *  also restrict lpx messages to errors only
 * 
 *  relationships used in lpexec:
 *  xpoint(4) = maxstr
 *  xpoint(5) = maxeq
 *  xpoint(6) = maxnz
 *  xpoint(7) = iafac (use iafac = 10)
 */
  xpoint_(4)=colmax+rowmax;
  xpoint_(5)=rowmax;
  xpoint_(6)=anzmax+2*rowmax;
  xpoint_(7)=10;
  lpexec(xcomnd,xpoint,xvalue);
/* 
 *  check parameter pvalue(5) used for precision level,
 *  rounding type, number of phases
 *  if precision level incorrect, replace by 
 *  pstate_(5) = 4*prcmax-2
 */
  if ((pvalue_(5)<1)||
      (pvalue_(5)>4*prcmax)) {
    perror_(1)=nftl;
    errval=1200;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
    pvalue_(5) = 4*prcmax-2;
  }
/*
 *  determine precision level, rounding type, number of phases
 *  0          < pvalue(5) <= prcmax:   2 phases, iterate:
 *                           round, then one multiple rounding case
 *  prcmax+1   < pvalue(5) <= 2*prcmax: 2 phases, iterate:
 *                           one multiple rounding case, then round
 *  2*prcmax+1 < pvalue(5) <= 3*prcmax: 2 phases,
 *                           all multiple rounding cases, then round
 *  3*prcmax+1 < pvalue(5) <= 4*prcmax: 1 phase,
 *                           all multiple rounding cases, then round
 *  "round" means round all variables with values close to 0 or 1,
 *  where "close" depends on the precision level;
 *  "multiple rounding" means select several of the most fractional
 *  variables, round all up and down (all possibilities), then
 *  select one variable that in certain sense is best to be rounded
 *  and fix it to 0 or 1.
 *  phase = 1 means that first the full lp is solved and then
 *  some reductions are made. then reduced lp is solved and used
 *  for rounding and multiple rounding.
 *  phase = 2 means that there is no first phase. thus the full
 *  lp is solved and used for rounding and multiple rounding.
 */
  trdflg=(pvalue_(5)-1)/prcmax;
  precsn=pvalue_(5)-(trdflg*prcmax);
  if (trdflg<=2) {
    phase=1;
  } else {
    phase=2;
  }
/*
 *  major iteration limit
 *  process will shrink lp when limit is reached
 */
  majit=1;
  majlm=30;
/*
 *  set indicator svpd for saving primal/dual values
 */
  svpd=1;
/*
 *  check detail level for log information
 */
  if (ptype_(1) == 'D') {
    detail=1;
  } else {
    detail=0;
  }
/*
 *  caution: almzero, almone, and epsb below, as well as the
 *           subsequently defined pfm2 (step 8 and step 12)
 *           must be so chosen that any slack variable can be
 *           rounded in step 17 once all nonslack variables
 *           have been rounded. this requires:
 *           almzro > epsb*pfm2
 *           almone < 1 - epsb*pfm2
 *  set almost 0, almost 1
 */
  almzro=0.01;
  almone=0.99;
/*
 *  set epsilon value for rounding
 */
  eps=0.0001;
/*
 *  set epsilon perturbation for right hand side of lp
 */
  epsb=0.0001;
/*
 *  reset optimization flag to satisfiability
 */
  optimz=0;
/*
 *  check for satisfiability
 */
  asgflg=1;
  solflg=0;
  satble=0;
  prcost=0;
  sol_xct(pname,pstate,ptype,pvalue,perror);
  if (strcmp(pstate,"U")==0) {
/*
 *  problem is not satisfiable
 *  reset optimz flag, then done
 */
    goto zz2905;
  }
/*
 *  problem is satisfiable
 *  retain currently active columns j in ciacpr(j)
 *  initialize classification in primal array
 */
  for(j=1; j<=ncols; j++)  {
    if (ciact_(j)>0) {
      ciacpr_(j)=1;
    } else {
      ciacpr_(j)=0;
    }
    primal_(j)=ciina_(j);
  }
/*
 *  initialize dual array
 */
  for(i=1; i<=nrows; i++)  {
    dual_(i)=0;
  }
/*
 *  start minimization
 */
  zz135:;
/*
 *  extract matrix for lp formulation
 *  restore all rows i with riina(i) = 1 to active, then make
 *  inactive according to fixed variable values
 */
  urinac();
/*
 *  extract active columns and active rows
 *  into ablkcl and ablkrw
 */
  xaact();
  xaart();
/*
 *  find rows with just one entry; must be active
 *  due to xaart
 *  fix correponding variables to required value
 */
  ps=0;
  flg=0;
  for(i=1; i<=nrows; i++)  {
    if (nzablr_(i)==1) {
/*
 *  have active row with just one entry; get column index
 */
      js=ablkrw_(1+ptablr_(i));
      j=abs(js);
/*
 *  process column
 *  - if it is active (it may have been fixed
 *       due to an already processed row), and
 *  - if primal/dual values need not be retained or
 *       column is not involved in a goal
 */
      if ((ciact_(j)==1)&&
          ((svpd==0)||(ciacgl_(j)==0))) {
/*
 *  fix column j to required value
 */
        icacin(j);
        if (js<0) {
          ciina_(j)=-1;
        } else {
          ciina_(j)=1;
        }
/*
 *  compute dual value if indicator svpd for saving primal/dual
 *  values is = 1
 */
        if (svpd==1) {
          if ((ciina_(j)*cost_(j))>0) {
            dual_(i)=abs(cost_(j));
          }
        }
        flg=1;
      }
    }
  }
  if (flg==1) {
/*
 *  have fixed at least one variable
 *  redo extraction of active columns and rows
 */
    ps=ps+1;
    if (ps>nrows) {
/*
 *  error, cannot have more than nrows passes
 */
      error(" apmsol ","  139   ");
    }
    goto zz135;
  }
/*
 *  compute number of nonzeros in lp and initialize
 *  indicator for active goal used by column
 */
  nanzlp=0;
  for(j=1; j<=ncols; j++)  {
    nanzlp=nanzlp+nzablc_(j);
/*
 */
    ciacgl_(j)=0;
    i=idxgol_(j);
    if (i>0) {
      if ((riina_(i)!=2)&&
          (gcoeff_(j)!=0)) {
/*
 *  column j is not deleted and has nonzero coefficient
 *  in an active goal row
 */
        ciacgl_(j)=1;
        nanzlp=nanzlp+1;
      }
    }
  }
/*
 *  fix active columns without entries and without coefficient
 *  in an active goal row to advantageous value
 */
  for(j=1; j<=ncols; j++)  {
    if ((ciact_(j)>0)&&
        (nzablc_(j)==0)&&
        (ciacgl_(j)==0)) {
      icacin(j);
      if (cost_(j)>=0) {
        ciina_(j)=-1;
      } else {
        ciina_(j)=1;
      }
    }
  }
/*
 *  note: the matrix extracted earlier is still valid for the
 *  (revised) active columns and the (unchanged) active rows
 * 
 */
  if (nanzlp==0) {
/*
 *  lp would have no entry, hence have optimal solution
 *  transfer columns from inactive back to active using ciacpr
 *  record solution in solut1
 *  compute total cost
 *  compute goal usage
 *  set lower bound = upper bound
 */
    opt=1;
    goto zz2705;
  }
/*
 *  lp has at least one entry
 * 
 *  compute reduced goal values goalrq(i) for lp
 */
  for(i=1; i<=nrows; i++)  {
    if ((glflg_(i)==1)&&
        (riina_(i)!=2)) {
/*
 *  row i is active goal row
 */
      goalrq_(i)=goalxq_(i);
    }
  }
/*
 *  adjust goal values for scaling of columns and
 *  fixing of columns
 */
  for(j=1; j<=ncols; j++)  {
    if ((ciina_(j)!=2)&&
        (ciacgl_(j)==1)) {
/*
 *  column j is not deleted and has coefficient
 *  in active goal row
 */
      i=idxgol_(j);
      if (scale_(j)==-1) {
        goalrq_(i)=goalrq_(i)+gcoeff_(j);
      }
      if (ciina_(j)==1) {
        goalrq_(i)=goalrq_(i)-gcoeff_(j);
      }
    }
  }
/*eject*/
/*
 * -----------------------------------------------
 *  step 2
 *  set up lp matrix; compute matrix-to-lp indices
 * -----------------------------------------------
 *  column indices
 */
  ncollp=0;
  for(j=1; j<=ncols; j++)  {
    if (ciact_(j)>0) {
/*
 *  column is active
 */
      ncollp=ncollp+1;
      xcl2lp_(j)=ncollp;
      xlp2cl_(ncollp)=j;
    } else {
      xcl2lp_(j)=0;
    }
  }
/*
 *  row indices
 */
  nrowlp=0;
/*
 *  logic rows
 */
  for(i=1; i<=nrows; i++)  {
    if ((nzablr_(i)>0)&&
        (glflg_(i)==0)) {
      nrowlp=nrowlp+1;
      xrw2lp_(i)=nrowlp;
      xlp2rw_(nrowlp)=i;
    } else {
      xrw2lp_(i)=0;
    }
  }
/*
 *  goal rows
 */
  n2=nrowlp;
  for(i=1; i<=nrows; i++)  {
    if ((glflg_(i)==1)&&
        (riina_(i)!=2)) {
      nrowlp=nrowlp+1;
      xrw2lp_(i)=nrowlp;
      xlp2rw_(nrowlp)=i;
    }
  }
  mgs=nrowlp-n2;
/*eject*/
/*
 * ------------------------------------------------
 *  step 3
 *  set up for xmp execution
 * -------------------------------------------------
 *
 *  determine total number of rows, columns, entries
 */
  mrows=nrowlp;
  ntotal=ncollp+n2+2*mgs;
  n1=ncollp;
  n3=nanzlp+n2+2*mgs;
/*
 *  display lp statistics
 */
  if (detail==1) {
    printf("\nnumber of LP rows     = %6ld",mrows); 
    printf("\nnumber of LP columns  = %6ld",ntotal);
    printf("\nnumber of LP nonzeros = %6ld",n3);
  }
/*
 *  begin xmp execution
 */
  strcpy(xcomnd,"BEG XMP");
  xpoint_(1)=mrows;
  xpoint_(2)=ntotal;
  xpoint_(3)=n3;
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  if (xpoint_(1)==0) {
/*
 *  lp problem is too big for currrent xmp dimensions
 */
    pvalue_(6)=xpoint_(6);
    pvalue_(7)=xpoint_(7);
    pvalue_(8)=xpoint_(8);
    perror_(1)=fatl;
    errval=2020;
    errmsg();
    disprm(ucomnd,uname,ustate,utype,uvalue,perror);
/*
 *  transfer columns from inactive back to active using ciacpr
 */
    goto zz2705;
  }
/*eject*/
/*
 * --------------------------------------------------------
 *  step 4
 *  assemble the lp columns produced by the n1 logic columns
 * --------------------------------------------------------
 */
  for(j=1; j<=ncols; j++)  {
    jlp=xcl2lp_(j);
    if (jlp>0) {
/*
 *  error if column j is zero
 */
      if ((nzablc_(j)==0)&&
          (ciacgl_(j)==0)) {
        error(" apmsol ","     402");
      }
/*
 *  begin lp column
 */
      strcpy(xcomnd,"BEG COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put objective function coefficient of lp column
 *  (xmp maximizes)
 */
      strcpy(xcomnd,"PUT OBJ");
      xpoint_(1)=jlp;
      xvalue_(1)=-cost_(j);
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put lp column
 *  logic coefficients
 */
      if (nzablc_(j)>0) {
        for(ix=1; ix<=nzablc_(j); ix++)  {
          i=abs(ablkcl_(ix+ptablc_(j)));
          ilp=xrw2lp_(i);
          if (ilp>0) {
            strcpy(xcomnd,"PUT COL");
            xpoint_(1)=jlp;
            xpoint_(2)=ilp;
            if (ablkcl_(ix+ptablc_(j))>0) {
              xvalue_(1)=1.0;
            } else {
              xvalue_(1)=-1.0;
            }
            lpexec(xcomnd,xpoint,xvalue);
          } else {
/*
 *  error, row must be part of lp since
 *  routines xaact and xaart created ablkcl and ablkrw data
 */
            error(" apmsol ","     412");
          }
        }
      }
/*
 *  goal coefficient
 */
      if (ciacgl_(j)>0) {
        i=idxgol_(j);
        ilp=xrw2lp_(i);
        if (ilp==0) {
/*
 *  error, ilp must be index of lp row
 */
          error(" apmsol ","     422");
        }
        strcpy(xcomnd,"PUT COL");
        xpoint_(1)=jlp;
        xpoint_(2)=ilp;
        xvalue_(1)=gcoeff_(j);
        lpexec(xcomnd,xpoint,xvalue);
      }
/*
 *  end lp column
 */
      strcpy(xcomnd,"END COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
    }
  }
/*eject*/
/*
 *  no step 5
 * -------------------------------------------------------
 *  step 6
 *  assemble lp columns for lp slack variables
 * -------------------------------------------------------
 */
  jlp=n1;
  for(ilp=1; ilp<=n2+2*mgs; ilp++)  {
    jlp=jlp+1;
/*
 *  begin column
 */
    strcpy(xcomnd,"BEG COL");
    xpoint_(1)=jlp;
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  put objective function coefficient
 */
    strcpy(xcomnd,"PUT OBJ");
    xpoint_(1)=jlp;
    if (ilp<=n2) {
      xvalue_(1)=0.0;
    } else {
      if (ilp<=(n2+mgs)) {
        i=xlp2rw_(ilp);
/*
 *  must change sign of costs since xmp does maximization
 */
        xvalue_(1)=-ghicst_(i);
      } else {
        i=xlp2rw_(ilp-mgs);
        xvalue_(1)=-glocst_(i);
      }
    }
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  put column coefficient
 */
    strcpy(xcomnd,"PUT COL");
    xpoint_(1)=jlp;
    if (ilp<=(n2+mgs)) {
      xpoint_(2)=ilp;
      xvalue_(1)=-1.0;
    } else {
      xpoint_(2)=ilp-mgs;
      xvalue_(1)=1.0;
    }
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  end column
 */
    strcpy(xcomnd,"END COL");
    xpoint_(1)=jlp;
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 *  programming error if jlp .ne. n
 */
  if (jlp!=ntotal) {
    error(" apmsol ","     602");
  }
/*eject*/
/*
 * ------------------------------------------------------
 *  step 7
 *  assign lower und and upper bounds for lp variables
 * ------------------------------------------------------
 */
  for(jlp=1; jlp<=ntotal; jlp++)  {
    strcpy(xcomnd,"PUT BND");
    xpoint_(1)=jlp;
    xvalue_(1)=0.0;
/*
 *  structural variables have upper bound 1.0, slacks have
 *  upper bound 1.0e12 (becomes 'BIG' in xmp)
 */
    if (jlp<=n1) {
      xvalue_(2)=1.0;
    } else {
      xvalue_(2) = 1.0e12;
    }
    lpexec(xcomnd,xpoint,xvalue);
  }
/*eject*/
/*
 * -------------------------------------------------------
 *  step 8
 *  put lp rhs values
 * -------------------------------------------------------
 *  caution: if max perturbation factor pfm2 is changed,
 *           check almzro, almone, and epsb definition
 *           and related caution statement.
 *           pfm2 is defined in step 8, and may be
 *           increased in step 12.
 * initialize factors for epsilon perturbation
 */
  ptry=1;
  pfm1=5;
  pfm2=11;
/*
 */
  pf1=pfm1/2;
  pf2=pfm2/2;
/*
 */
  zz805:;
/*
 */
  for(ilp=1; ilp<=mrows; ilp++)  {
    strcpy(xcomnd,"PUT RHS");
    xpoint_(1)=ilp;
    i=xlp2rw_(ilp);
/*
 *  compute factor pf2 for epsilon perturbation
 */
    pf1=pf1+1;
    if (pf1>pfm1) {
      pf1=2;
    }
    pf2=pf2+pf1;
    if (pf2>pfm2) {
      pf2=pf2-pfm2;
    }
/*
 *  alternate computation of pf2
 *          pf1 = 3*i
 *          pf2 = pf1 - ((pf1/7)*7) + 1
 * 
 */
    if (ilp<=n2) {
      if (nzablr_(i)==0) {
/*
 *  row must be nonzero
 */
        error(" apmsol ","     802");
      }
/*
 * compute neg = number of -1s in row i
 */
      neg=0;
      for(jx=1; jx<=nzablr_(i); jx++)  {
        if (ablkrw_(jx+ptablr_(i))<0) {
          neg=neg+1;
        }
      }
      xvalue_(1)=-neg;
/*
 *  rhs = 1.0 - neg - epsb*pf2
 *  uses epsb*pf2 for epsilon perturbation with above pf2
 */
      xvalue_(1)=xvalue_(1)+1.0-epsb*pf2;
    } else {
/*
 *  rhs = goal +- epsb*pf2 (+/- depends on cost values)
 *  uses epsb*pf2 for epsilon perturbation with above pf2
 */
      xvalue_(1)=goalrq_(i);
      if (glocst_(i)<=ghicst_(i)) {
        xvalue_(1)=xvalue_(1)+epsb*pf2;
      } else {
        xvalue_(1)=xvalue_(1)-epsb*pf2;
      }
    }
    lpexec(xcomnd,xpoint,xvalue);
  }
/*eject*/
/*
 * -------------------------------------------------------
 *  step 9
 *  put nonbasis for logic variables
 * -------------------------------------------------------
 *  for columns j corresponding to jlp in lp, find
 *  cst = maximum absolute cost
 *  gcd = g.c.d of costs (= 0 if all costs are zero)
 */
  cst=0;
  gcd=0;
  for(jlp=1; jlp<=ntotal; jlp++)  {
/*
 *  skip case if this is logic slack
 */
    if ((jlp<=n1)||
        (jlp>(n1+n2))) {
/*
 *  have logic variable or goal usage slack
 *  get cost of column
 */
      if (jlp<=n1) {
/*
 *  logic variables
 */
        j=xlp2cl_(jlp);
        ct=cost_(j);
      } else {
        if (jlp<=(n1+n2+mgs)) {
/*
 *  high slack for goal
 */
          ilp=jlp-n1;
          i=xlp2rw_(ilp);
          ct=ghicst_(i);
        } else {
/*
 *  low slack for goal
 */
          ilp=jlp-(n1+mgs);
          i=xlp2rw_(ilp);
          ct=glocst_(i);
        }
      }
/*
 */
      if (ct!=0) {
        dcst=abs(ct);
        if (dcst>cst) {
          cst=dcst;
        }
        if (gcd==0) {
          gcd=dcst;
        } else {
          if (dcst<gcd) {
            hcst=gcd;
            gcd=dcst;
            dcst=hcst;
          }
          zz915:;
          dcst=dcst-(dcst/gcd)*gcd;
          if (dcst!=0) {
            hcst=gcd;
            gcd=dcst;
            dcst=hcst;
            goto zz915;
          }
        }
      }
    }
  }
/*
 */
  if (cst==0) {
/*
 *  have optimal solution
 *  know gcd = 0
 *  recompute satisfying solution
 */
    asgflg=1;
    solflg=0;
    sol_xct(pname,pstate,ptype,pvalue,perror);
    if (strcmp(pstate,"U")==0) {
      error(" apmsol ","    902 ");
    }
/*
 *  transfer columns from inactive back to active
 *  using ciacpr
 *  record solution in solut1
 *  compute total cost
 *  compute goal usage
 *  set lower bound = upper bound
 */
    opt=1;
    goto zz2705;
  }
/*
 *  maximum absolute cost is positive
 * 
 *  find starting solution
 *  attempt no. 1:
 *  use inlsol if it is nonzero, and use cost otherwise
 */
  for(jlp=1; jlp<=n1; jlp++)  {
    j=xlp2cl_(jlp);
    icacin(j);
    if (inlsol_(j)!=0) {
/*
 *  fix column to initial value given by inlsol
 */
      ciina_(j)=inlsol_(j);
    } else {
/*
 *  inlsol value is zero, so no initial value assigned
 *  use cost to decide on value
 */
      if (cost_(j)>=0) {
        ciina_(j)=-1;
      } else {
        ciina_(j)=1;
      }
    }
  }
/*
 *  check for feasible solution
 */
  asgflg=1;
  solflg=0;
  sol_xct(pname,pstate,ptype,pvalue,perror);
  if (strcmp(pstate,"U")==0) {
/*
 *  cannot use the assigned values
 *  attempt no. 2:
 *  leave inlsol assignments unchanged, but activate the
 *  variables that were fixed according to cost values
 */
    for(jlp=1; jlp<=n1; jlp++)  {
      j=xlp2cl_(jlp);
      if (inlsol_(j)==0) {
        icinac(j);
      }
    }
/*
 *  get feasible solution
 */
    asgflg=1;
    solflg=0;
    sol_xct(pname,pstate,ptype,pvalue,perror);
    if (strcmp(pstate,"U")==0) {
/*
 *  cannot use the assigned values
 *  attempt no. 3: (must be successful)
 *  activate the variables fixed according to inlsol values
 */
      for(jlp=1; jlp<=n1; jlp++)  {
        j=xlp2cl_(jlp);
        if (inlsol_(j)!=0) {
          icinac(j);
        }
      }
/*
 *  get feasible solution
 */
      asgflg=1;
      solflg=0;
      sol_xct(pname,pstate,ptype,pvalue,perror);
      if (strcmp(pstate,"U")==0) {
/*
 *  error, must have satisfiability since it was
 *  established earlier
 */
        error(" apmsol ","  962   ");
      }
    }
/*
 *  have a feasible solution in solut1
 *  fix all active variables to the solution values
 */
    for(j=1; j<=ncols; j++)  {
      if (ciact_(j)>0) {
        icacin(j);
        ciina_(j)=solut1_(j);
      }
    }
  }
/*
 *  have a starting solution given by ciina values
 *  begin computation of continuous solution
 * 
 *  temporarily use goalus array for internal goal usage
 *  calculations, to decided basic/nonbasic goal slack
 *  initialize internal goal usage = l.h.s. of goal row in lp
 */
  if (mgs>0) {
    for(ilp=n2+1; ilp<=n2+mgs; ilp++)  {
      i=xlp2rw_(ilp);
      goalus_(i)=0;
    }
  }
/*
 *  have feasible solution for lp
 */
  if (detail==1) {
    printf("\ninitial solution found");
  }
/*
 *  determine fixing to upper/lower bound using ciina(j) value
 */
  for(jlp=1; jlp<=n1; jlp++)  {
    j=xlp2cl_(jlp);
    if (ciina_(j)==0) {
/*
 *  error, all columns j of lp columns jlp must be inactive
 */
      error(" apmsol ","    992 ");
    }
    if (ciina_(j)==1) {
/*
 *  put nonbasis by setting lp variable jlp to upper bound
 */
      strcpy(xcomnd,"PUT NBS");
      xpoint_(1)=jlp;
      xpoint_(2)=-1;
      lpexec(xcomnd,xpoint,xvalue);
      if (ciacgl_(j)==1) {
/*
 *  increase internal goal usage by goal coefficient
 */
        i=idxgol_(j);
        goalus_(i)=goalus_(i)+gcoeff_(j);
      }
    } else {
/*
 *  put nonbasis by setting lp variable jlp to lower bound
 */
      strcpy(xcomnd,"PUT NBS");
      xpoint_(1)=jlp;
      xpoint_(2)=0;
      lpexec(xcomnd,xpoint,xvalue);
    }
/*
 *   return column j to active
 */
    icinac(j);
  }
/*eject*/
/*
 * -----------------------------------------------------
 *  step 10
 *  put basis and nonbasis for slack variables
 * -----------------------------------------------------
 *  logic slacks are basic
 */
  for(ilp=1; ilp<=n2; ilp++)  {
    strcpy(xcomnd,"PUT BAS");
    xpoint_(1)=n1+ilp;
    xpoint_(2)=ilp;
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 *  goal slacks are basic/nonbasic dependendig on usage
 */
  if (mgs>=1) {
    for(ilp=1; ilp<=mgs; ilp++)  {
      i=xlp2rw_(n2+ilp);
      if (goalus_(i)>=goalrq_(i)) {
/*
 *  high slack is basic, low slack is nonbasic
 */
        strcpy(xcomnd,"PUT BAS");
        xpoint_(1)=n1+n2+ilp;
        xpoint_(2)=n2+ilp;
        lpexec(xcomnd,xpoint,xvalue);
        strcpy(xcomnd,"PUT NBS");
        xpoint_(1)=n1+n2+mgs+ilp;
        xpoint_(2)=0;
        lpexec(xcomnd,xpoint,xvalue);
      } else {
/*
 *  low slack is basic, high slack is nonbasic
 */
        strcpy(xcomnd,"PUT BAS");
        xpoint_(1)=n1+n2+mgs+ilp;
        xpoint_(2)=n2+ilp;
        lpexec(xcomnd,xpoint,xvalue);
        strcpy(xcomnd,"PUT NBS");
        xpoint_(1)=n1+n2+ilp;
        xpoint_(2)=0;
        lpexec(xcomnd,xpoint,xvalue);
      }
    }
  }
/*eject*/
/*
 * ------------------------------------------------------
 *  step 11
 *  factor basis
 * ------------------------------------------------------
 */
  strcpy(xcomnd,"FAC BAS");
  lpexec(xcomnd,xpoint,xvalue);
/*eject*/
/*
 * ------------------------------------------------------
 *  step 12
 *  solve ip at defined precsn level
 * ------------------------------------------------------
 *  solve lp by primal simplex method
 */
  strcpy(xcomnd,"SOL PML");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  termination code is in xpoint(1)
 *  (= 1 if and only if optimal solution found)
 */
  if (xpoint_(1)!=1) {
/*
 *  have error; change r.h.s. perturbation and try again
 */
    if (detail==1) {
      printf("\nrevise perturbation");
    }
    ptry=ptry+1;
    if (ptry>=4) {
      error(" apmsol ","  1202  ");
    }
/*
 */
    pfm1=(pfm1-1)*2+1;
    pfm2=pfm2*3;
    pf1=pfm1/2;
    pf2=pfm2/2;
/*
 *  recompute rhs and start primal simplex method
 */
    goto zz805;
  }
/*
 *  have solved primal problem
 *  display progress
 */
  if (detail==1) {
    printf("\ncontinuous solution found");
  }
/*
 *  if indicator svpd for saving primal/dual values is = 1,
 *  store classification of primal variables in primal array
 *  get optimal dual values, round them, store in dual array
 *  must change sign for dual variables since xmp does
 *  maximization
 */
  if (svpd==1) {
/*
 *  reset indicator to 0
 */
    svpd=0;
/*
 *  classification of primal variables
 *  deleted or fixed variables
 */
    for(j=1; j<=ncols; j++)  {
      primal_(j)=ciina_(j);
    }
/*
 *  lp variables, correspond to ciina(j) = 0
 *  get value and classify as essentially at lower or
 *  upper bound, or as in-between
 */
    for(jlp=1; jlp<=n1; jlp++)  {
      j=xlp2cl_(jlp);
      xpoint_(1)=jlp;
      strcpy(xcomnd,"GET SOL");
      lpexec(xcomnd,xpoint,xvalue);
      if (xvalue_(1)<almzro) {
/*
 *  variable is essentially at lower bound
 */
        primal_(j)=-1;
      } else {
        if (xvalue_(1)>almone) {
/*
 *  variable is essentially at upper bound
 */
          primal_(j)=1;
        } else {
/*
 *  variable is in-between
 */
          primal_(j)=3;
        }
      }
    }
/*
 *  dual values
 */
    for(ilp=1; ilp<=nrowlp; ilp++)  {
      xpoint_(1)=ilp;
      strcpy(xcomnd,"GET DUL");
      lpexec(xcomnd,xpoint,xvalue);
      i=xlp2rw_(ilp);
      dual_(i)=-xvalue_(1)+0.9999;
    }
  }
/*eject*/
/*
 * ------------------------------------------------------
 *  step 13
 *  if trdflg <= 2:
 *    if first phase:
 *      fix all nonbasic variables, 
 *      and check satisfiability
 *      if satisfiable: accept these values
 *      else:           undo the fixing, skip second phase,
 *                      and start rounding process
 *    if second phase:
 *      fix all nonbasic variables,
 *      and start rounding process
 *  if trdflg = 3: skip this step
 * -------------------------------------------------------
 */
  if (trdflg==3) {
/*
 *  have only one phase, so skip this step
 */
    goto zz1405;
  }
/*
 */
  for (jlp=1; jlp<=n1; jlp++) {
    j=xlp2cl_(jlp);
/*
 *  do not fix a variable
 *  if it is a slack and is not involved in a goal
 */
    if ((nzablc_(j)==1)&&
        (ciacgl_(j)==0)) {
      goto zz1300;
    }
    xpoint_(1)=jlp;
    strcpy(xcomnd,"GET SOL");
    lpexec(xcomnd,xpoint,xvalue);
    if (xpoint_(2)==0) {
/*
 *  variable is at lower bound
 */
      icacin(j);
      ciina_(j)=-1;
    } else {
      if (xpoint_(2)==-1) {
/*
 *  variable is at upper bound
 */
        icacin(j);
        ciina_(j)=1;
      }
    }
  zz1300:;}
/*
 *  check satisfiability
 */
  asgflg=1;
  solflg=0;
  sol_xct(pname,pstate,ptype,pvalue,perror);
  if (strcmp(pstate,"U")==0) {
/*
 *  unsatisfiable; return all variables j of lp variables
 *  to active;
 *  since these variables were entered into the lp, they
 *  must have been active when apmsol was entered
 */
    for(jlp=1; jlp<=n1; jlp++)  {
      j=xlp2cl_(jlp);
      if (ciina_(j)!=0) {
        icinac(j);
      }
    }
    goto zz1405;
  } else {
/*
 *  have satisfiability
 *  start second phase if currently in first phase
 */
    if (phase==1) {
      phase=2;
/*
 *  display progress
 */
      if (detail==1) {
        printf(
            "\nfirst phase done, begin second phase");
      }
      goto zz135;
    }
/*
 *  check if all columns j corresponding to lp variables
 *  are fixed
 */
    for(jjlp=1; jjlp<=n1; jjlp++)  {
      j=xlp2cl_(jjlp);
      if (ciact_(j)>0) {
/*
 *  not all columns j have been fixed.
 *  update lp bounds of all fixed variables and resolve
 */
        flg=0;
        for(jlp=1; jlp<=n1; jlp++)  {
          j=xlp2cl_(jlp);
          if (ciina_(j)!=0) {
            flg=1;
            strcpy(xcomnd,"PUT BND");
            xpoint_(1)=jlp;
            if (ciina_(j)==-1) {
/*
 *  fix lp variable jlp to upper bound
 */
              xvalue_(1)=0.0;
              xvalue_(2)=0.0;
            } else {
/*
 *  fix lp variable jlp to lower bound
 */
              xvalue_(1)=1.0;
              xvalue_(2)=1.0;
            }
            lpexec(xcomnd,xpoint,xvalue);
          }
        }
        if (flg==1) {
/*
 *  at least one variable was fixed, so must re-optimize
 *  factor basis
 */
          strcpy(xcomnd,"FAC BAS");
          lpexec(xcomnd,xpoint,xvalue);
/*
 *  solve lp by dual simplex method
 */
          strcpy(xcomnd,"SOL DUL");
          lpexec(xcomnd,xpoint,xvalue);
        }
        goto zz1405;
      }
    }
/*
 *  all columns have been fixed, thus have optimal solution
 *  transfer columns from inactive back to active
 *  using ciacpr
 *  record solution in solut1
 *  compute total cost
 *  compute goal usage
 *  set lower bound = upper bound
 */
    opt=1;
    goto zz2705;
  }
/*eject*/
/*
 * --------------------------------------------------------
 *  step 14
 *  compute lower bound lpmin on objective function
 * --------------------------------------------------------
 */
  zz1405:;
  strcpy(xcomnd,"GET ZVL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  switch sign of objective function since xmp does maximization
 *  round value up and store as lower bound lpmin
 */
  xvalue_(1)=-xvalue_(1);
  if (xvalue_(1)>=0) {
    xvalue_(1)=xvalue_(1)+0.9999;
    lpmin=xvalue_(1);
  } else {
    xvalue_(1)=-xvalue_(1)+0.001;
    lpmin=xvalue_(1);
    lpmin=-lpmin;
  }
/*
 *  display progress
 */
  if (detail==1) {
    printf("\nlower bound (internal value, rounded) = %ld",
             lpmin);
  }
/*eject*/
/*
 * -------------------------------------------------------
 *  step 15
 *  compute rounding bounds and cases for multiple rounding
 * -------------------------------------------------------
 *  rounding bounds
 *  tight rounding:
 *          low   high
 * 
 *          0.01  0.99
 *      (almzro)  (almone)
 * 
 *  loose rounding:
 *  values depend on precision
 *  case  rounding values
 *          low   high
 *   1      0.40  0.60
 *   2      0.35  0.65
 *   3      0.30  0.70
 *   4      0.25  0.75
 *   5      0.20  0.80
 * 
 *  find the 5 loose rounding bounds
 */
  for(j=1; j<=5; j++)  {
    lrrval_(j)=5-j;
    lrrval_(j)=0.20+0.05*lrrval_(j)+eps;
    urrval_(j)=1-lrrval_(j)-eps;
  }
/*
 *  bounds for case 6 are almost 0 and almost 1 with epsilon
 *  perturbation
 */
  lrrval_(6)=almzro-eps;
  urrval_(6)=almone+eps;
/*
 */
  if (trdflg>=1) {
    lr=almzro;
    ur=almone;
  } else {
    i=precsn;
    if (i>5) {
      i=5;
    }
    lr=lrrval_(i);
    ur=urrval_(i);
  }
/*
 *  compute table of rounding cases
 */
  nrdc=2;
  rndcas_(1,1)=-1;
  rndcas_(1,2)=1;
  if (precsn>=2) {
    for(jx=2; jx<=precsn; jx++)  {
      for(j=1; j<=nrdc; j++)  {
        for(i=1; i<=jx-1; i++)  {
          rndcas_(i,2*nrdc-j+1)=rndcas_(i,j);
        }
        rndcas_(jx,j)=-1;
        rndcas_(jx,j+nrdc)=1;
      }
      nrdc=nrdc*2;
    }
  }
/*eject*/
/*
 * ---------------------------------------------------
 *  step 16
 *  begin of major iteration for rounding
 * ---------------------------------------------------
 */
  zz1605:;
/*
 *  increase major iteration count
 */
  majit=majit+1;
  if (majit>majlm) {
/*
 *  shrink lp by formulating remaining problem
 */
    majit=1;
    goto zz135;
  }
/*
 *  compute number of variables in each rounding range
 */
  todo=0;
  for(i=1; i<=6; i++)  {
    nlurr_(i)=0;
  }
/*
 */
  for(jlp=1; jlp<=n1; jlp++)  {
    j=xlp2cl_(jlp);
    if (ciact_(j)>0) {
      todo=todo+1;
/*
 *  do not include a variable in nlurr(i) count
 *  if it is a slack and is not involved in a goal
 */
      if ((nzablc_(j)==1)&&
          (ciacgl_(j)==0)) {
        goto zz1630;
      }
      strcpy(xcomnd,"GET SOL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
      for(i=1; i<=6; i++)  {
        if ((xvalue_(1)>=lrrval_(i))&&
            (xvalue_(1)<=urrval_(i))) {
          nlurr_(i)=nlurr_(i)+1;
          goto zz1630;
        }
      }
    }
  zz1630:;}
/*
 *  check for termination
 */
  if (todo==0) {
/*
 *  rounding process has been completed
 *  transfer columns from inactive back to active
 *  using ciacpr
 *  record solution in solut1
 *  compute total cost
 *  compute goal usage
 *  set lower bound = lpmin
 */
    opt=0;
    goto zz2605;
  }
/*
 *  display progress
 */
  if (detail==1) {
    printf("\nvariables yet to do = %ld",todo);
    for (i=1; i<=6; i++) {
      printf("\n  in range %ld are %ld",i,nlurr_(i));
    }
  }
/*
 *  decide on next step
 */
  if (trdflg>=1) {
/*
 *  multiple rounding is given preference
 */
    for(i=1; i<=6; i++)  {
      if (nlurr_(i)>0) {
/*
 *  multiple rounding is possible
 */
        goto zz1805;
      }
    }
/*
 *  multiple rounding is not possible
 *  hence do rounding
 */
    goto zz1705;
  } else {
/*
 *  have case trdflg = 0
 *  rounding is given preference
 *  hence do rounding
 */
    goto zz1705;
  }
/*eject*/
/*
 * -----------------------------------------------------
 *  step 17
 *  round columns using lr and ur bounds
 * -----------------------------------------------------
 */
  zz1705:;
/*
 *  initialize flag for rounding
 */
  flg=0;
/*
 *  initialize decision variable
 *  for solution of lp in each iteration
 */
  if (trdflg<=1) {
    dolp=1;
  } else {
    dolp=0;
  }
/*
 *  do rounding if possible using lr and ur
 */
  for(jlp=1; jlp<=n1; jlp++)  {
    j=xlp2cl_(jlp);
    if (ciact_(j)>0) {
      strcpy(xcomnd,"GET SOL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
      if ((xvalue_(1)<=lr)||
          (xvalue_(1)>=ur)) {
/*
 *  can fix value for j since value for jlp is
 *  in rounding range
 */
        flg=1;
        icacin(j);
        if (xvalue_(1)<=lr) {
          ciina_(j)=-1;
        } else {
          ciina_(j)=1;
        }
/*
 *  check feasibility
 */
        asgflg=1;
        solflg=0;
        sol_xct(pname,pstate,ptype,pvalue,perror);
        if (strcmp(pstate,"U")==0) {
/*
 *  must fix j to opposite value
 */
          ciina_(j)=-ciina_(j);
/*
 *  enforce solving lp from now on
 */
          dolp=1;
        }
/*
 *  record fixing of variable in lp
 */
        strcpy(xcomnd,"PUT BND");
        xpoint_(1)=jlp;
        if (ciina_(j)==-1) {
          xvalue_(1)=0.0;
          xvalue_(2)=0.0;
        } else {
          xvalue_(1)=1.0;
          xvalue_(2)=1.0;
        }
        lpexec(xcomnd,xpoint,xvalue);
/*
 *  solve lp if required
 */
        if (dolp==1) {
/*
 *  factor basis
 */
          strcpy(xcomnd,"FAC BAS");
          lpexec(xcomnd,xpoint,xvalue);
/*
 *  solve lp by dual simplex method
 */
          strcpy(xcomnd,"SOL DUL");
          lpexec(xcomnd,xpoint,xvalue);
        }
      }
    }
  }
/*
 *  decide on next action
 */
  if ((trdflg==0)&&
      (flg==0)) {
/*
 *  had no progress under rounding with trdflg = 0
 *  go to multiple rounding
 */
    goto zz1805;
  } else {
/*
 *  for any other case, start next major iteration
 */
    goto zz1605;
  }
/*eject*/
/*
 * ------------------------------------------------------
 *  step 18
 *  prepare for multiple rounding
 *  for each active column j, the value of jlp in the lp
 *  cannot be rounded; save current status of lp variables
 * -------------------------------------------------------
 */
  zz1805:;
  for(jlp=1; jlp<=ntotal; jlp++)  {
    strcpy(xcomnd,"GET STS");
    xpoint_(1)=jlp;
    lpexec(xcomnd,xpoint,xvalue);
    lpstat_(jlp)=xpoint_(2);
  }
/*eject*/
/*
 * ------------------------------------------------------
 *  step 19
 *  multiple rounding: select columns for rounding
 * ------------------------------------------------------
 *  display progress
 */
  if (detail==1) {
    printf("\nbegin multiple rounding");
  }
/*
 *  find active columns for rounding, up to precsn columns
 *  select columns with value as far away from 0 and 1
 *  as possible
 */
  nrv=0;
  nrdc=1;
  for(i=1; i<=6; i++)  {
    if (nlurr_(i)>0) {
      for(jlp=1; jlp<=n1; jlp++)  {
        j=xlp2cl_(jlp);
/*
 *  do not consider a variable for fixing
 *  if it is a slack and is not involved in a goal
 */
        if ((nzablc_(j)==1)&&
            (ciacgl_(j)==0)) {
          goto zz1920;
        }
        if (ciact_(j)>0) {
          strcpy(xcomnd,"GET SOL");
          xpoint_(1)=jlp;
          lpexec(xcomnd,xpoint,xvalue);
          if ((xvalue_(1)>=lrrval_(i))&&
              (xvalue_(1)<=urrval_(i))) {
/*
 *  case falls into interval
 */
            if (nrv>=1) {
              for(jx=1; jx<=nrv; jx++)  {
                if (j==rndcl_(jx)) {
/*
 *  case has occured already, so skip it
 */
                  goto zz1920;
                }
              }
            }
            nrv=nrv+1;
            nrdc=nrdc*2;
            rndcl_(nrv)=j;
            if (nrv==precsn) {
              goto zz1925;
            }
          }
        }
      zz1920:;}
    }
  }
/*
 */
  zz1925:;
  if (nrv==0) {
/*
 *  error, must have at least one active column
 */
    error(" apmsol ","    1932");
  }
/*eject*/
/*
 * -----------------------------------------------------
 *  step 20
 *  multiple rounding: evaluate each rounding case
 * -----------------------------------------------------
 *  move the columns with index in rndcl() to inactive
 */
  for(jx=1; jx<=nrv; jx++)  {
    j=rndcl_(jx);
    icacin(j);
  }
/*
 *  do the nrdc rounding cases
 *  flg measures the first feasible case
 */
  flg=1;
  for(nr=1; nr<=nrdc; nr++)  {
/*
 *  fix the columns to the values for this case
 */
    for(jx=1; jx<=nrv; jx++)  {
      j=rndcl_(jx);
      ciina_(j)=rndcas_(jx,nr);
    }
/*
 *  check satisfiability of this case
 */
    asgflg=1;
    solflg=0;
    sol_xct(pname,pstate,ptype,pvalue,perror);
    if (strcmp(pstate,"U")==0) {
/*
 *  record case as unsatisfiable, skip rest for this case
 */
      rndfsb_(nr)=0;
      goto zz2020;
    }
/*
 *  record case as satisfiable
 */
    rndfsb_(nr)=1;
/*
 *  set bounds for lp columns
 */
    for(jx=1; jx<=nrv; jx++)  {
      j=rndcl_(jx);
      jlp=xcl2lp_(j);
      strcpy(xcomnd,"PUT BND");
      xpoint_(1)=jlp;
      if (ciina_(j)==-1) {
        xvalue_(1)=0.0;
        xvalue_(2)=0.0;
      } else {
        xvalue_(1)=1.0;
        xvalue_(2)=1.0;
      }
      lpexec(xcomnd,xpoint,xvalue);
      if ((flg==1)||(jx==nrv)) {
/*
 *  factor basis
 */
        strcpy(xcomnd,"FAC BAS");
        lpexec(xcomnd,xpoint,xvalue);
/*
 *  solve lp by dual simplex method
 */
        strcpy(xcomnd,"SOL DUL");
        lpexec(xcomnd,xpoint,xvalue);
      }
    }
/*
 *  reset flg to zero since first satisfiable case done
 */
    flg=0;
/*
 *  get objective function value
 */
    strcpy(xcomnd,"GET ZVL");
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  retain negative of objective function value in rndzv(nr)
 */
    rndzv_(nr)=-xvalue_(1);
/*
 *  display progress
 */
    if (detail==1) {
      printf("\nrounding case number = %ld",nr);
      printf(" has value = %.2f",rndzv_(nr));
    }
/*
 */
  zz2020:;}
/*eject*/
/*
 * --------------------------------------------------------
 *  step 21
 *  multiple rounding: select best variable
 * --------------------------------------------------------
 * find best rounding case
 */
  br=0;
  for(nr=1; nr<=nrdc; nr++)  {
    if (rndfsb_(nr)==1) {
      if ((br==0)||
          ((br>0)&&(rndzv_(nr)<zv))) {
        zv=rndzv_(nr);
        br=nr;
      }
    }
  }
  if (br==0) {
/*
 *  error, must have selected a best case
 */
    error(" apmsol ","    2112");
  }
/*
 *  find best variable
 */
  if (nrv>=2) {
    for(jx=1; jx<=nrv; jx++)  {
      flg=0;
      for(nr=1; nr<=nrdc; nr++)  {
        if (rndfsb_(nr)==1) {
          if (rndcas_(jx,nr)!=rndcas_(jx,br)) {
/*
 *  have opposite case for fixed variable
 */
            if (flg==0) {
              deltaz_(jx)=rndzv_(nr);
              flg=1;
            } else {
              if (deltaz_(jx)>rndzv_(nr)) {
                deltaz_(jx)=rndzv_(nr);
              }
            }
          }
        }
      }
/*
 *  if flg = 0, then there is no opposite case for index jx
 *  hence the value of the variable with index jx is fixed,
 *  and we should select jx
 */
      if (flg==0) {
        jj=rndcl_(jx);
        goto zz2205;
      }
    }
/*
 *  pick index jx giving maximum deltaz() value
 */
    for(jx=1; jx<=nrv; jx++)  {
      if ((jx==1)||(deltaz_(jx)>zv)) {
        zv=deltaz_(jx);
        jj=rndcl_(jx);
      }
    }
  } else {
    jj=rndcl_(1);
  }
/*eject*/
/*
 * -------------------------------------------------------
 *  step 22
 *  multiple rounding: fix selected variable jj
 *                     release all other variables
 *                     adjust bounds of lp
 * -------------------------------------------------------
 * 
 */
  zz2205:;
  if ((nrv==1)&&
      (ciina_(jj)==rndcas_(1,br))) {
/*
 *  single variable case; have already correct rounded value,
 *  so done for this major iteration
 */
    goto zz1605;
  }
/*
 */
  for(jx=1; jx<=nrv; jx++)  {
    if (rndcl_(jx)==jj) {
/*
 *  have selected variable
 */
      ciina_(jj)=rndcas_(jx,br);
      jlp=xcl2lp_(jj);
      strcpy(xcomnd,"PUT BND");
      xpoint_(1)=jlp;
      if (ciina_(jj)==-1) {
        xvalue_(1)=0.0;
        xvalue_(2)=0.0;
      } else {
        xvalue_(1)=1.0;
        xvalue_(2)=1.0;
      }
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  display progress
 */
      if (detail==1) {
        printf("\nfix variable = %ld",jj);
        printf(" to value = %.1f",xvalue_(1));
        printf("\ncost increase for opposite value = %.2f",
                 zv-rndzv_(br));
      }
    } else {
/*
 *  variable is not the selected one; activate and free up bound
 */
      j=rndcl_(jx);
      icinac(j);
      jlp=xcl2lp_(j);
      strcpy(xcomnd,"PUT BND");
      xpoint_(1)=jlp;
      xvalue_(1)=0.0;
      xvalue_(2)=1.0;
      lpexec(xcomnd,xpoint,xvalue);
    }
  }
/*eject*/
/*
 * ---------------------------------------------------
 *  step 23
 *  multiple rounding: restore previous lp basis
 * ---------------------------------------------------
 */
  for(jlp=1; jlp<=ntotal; jlp++)  {
    strcpy(xcomnd,"RST STS");
    xpoint_(1)=jlp;
    xpoint_(2)=lpstat_(jlp);
    lpexec(xcomnd,xpoint,xvalue);
  }
/*eject*/
/*
 * ---------------------------------------------------
 *  step 24
 *  multiple rounding: factor basis
 * ---------------------------------------------------
 */
  strcpy(xcomnd,"FAC BAS");
  lpexec(xcomnd,xpoint,xvalue);
/*eject*/
/*
 * ---------------------------------------------------
 *  step 25
 *  multiple rounding: solve by dual simplex method
 * ---------------------------------------------------
 */
  strcpy(xcomnd,"SOL DUL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  display progress
 */
  if (detail==1) {
/*
 *  get z value
 */
    strcpy(xcomnd,"GET ZVL");
    lpexec(xcomnd,xpoint,xvalue);
    zv=-xvalue_(1);
    printf("\nobj function value after rounding = %.2f",
             zv);
  }
/*
 *  decide on next step
 */
  if (trdflg==1) {
/*
 *  have each case of multiple rounding followed by rounding
 */
    goto zz1705;
  } else {
/*
 *  for all other cases: start another major iteration
 */
    goto zz1605;
  }
/*eject*/
/*
 * ------------------------------------------------------
 *  step 26
 *  compute difference between lp objective function value
 *  for solution at hand and lower bound lpmin
 * ------------------------------------------------------
 */
  zz2605:;
/*
 *  compute obj function value of current solution,
 *  the way lp would calculate it, with adjustment
 *  for minimization change of sign
 */
  cst=0;
/*
 *  contribution of logic variables
 */
  for(jlp=1; jlp<=n1; jlp++)  {
    j=xlp2cl_(jlp);
    if (ciina_(j)==1) {
      cst=cst+cost_(j);
    }
  }
  if (mgs>=1) {
/*
 *  contribution of goal usage slacks
 */
    for(ix=1; ix<=mgs; ix++)  {
      ilp=n2+ix;
      i=xlp2rw_(ilp);
/*
 *  high usage. add 0.99 to handle effect of rounding down
 */
      jlp=n1+n2+ix;
      strcpy(xcomnd,"GET SOL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
      cst=cst+((long)(xvalue_(1)+0.9999))*ghicst_(i);
/*
 *  low usage. add 0.99 to handle effect of rounding down
 */
      jlp=n1+n2+mgs+ix;
      strcpy(xcomnd,"GET SOL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
      cst=cst+((long)(xvalue_(1)+0.9999))*glocst_(i);
    }
  }
/*
 * compute difference between this total and the lower bound
 */
  if ((opt==0)&&(cst<lpmin)) {
/*
 *  error, lower bound lpmin is not correct
 */
    error("apmsol","2612");
  }
/*
 *  compute dcst = cost difference of fractional lp solution
 *  and integer lp solution, with adjustment for miminization
 *  change of sign. dcst bounds the cost difference between any
 *  best logic solution and the one found by lp and rounding
 */
  dcst=cst-lpmin;
/*
 */
  if (gcd==0) {
    if (dcst!=0) {
/*
 *  error, dcst must be zero if gcd is zero
 */
      error(" apmsol ","  2614  ");
    }
/*
 *  reduce dcst so that it is multiple of gcd
 */
  } else {
    dcst=(dcst/gcd)*gcd;
  }
/*eject*/
/*
 * -----------------------------------------------------
 *  step 27
 *  activate inactive columns using ciacpr
 * -----------------------------------------------------
 */
  zz2705:;
  for(j=1; j<=ncols; j++)  {
    if ((ciina_(j)!=0)&&(ciacpr_(j)==1)) {
/*
 *  reset inactive to active and store solution
 */
      solut1_(j)=ciina_(j);
      icinac(j);
    }
  }
/*eject*/
/*
 * ------------------------------------------------------
 *  step 28
 *  compute output information if no fatal error occurred
 * ------------------------------------------------------
 */
  if (perror_(1)!=fatl) {
/*
 *  compute external goal usage
 *  including for currently deleted goal rows
 *  compute total cost prcost of goal usage
 *  for currently active goal rows
 */
    cst=0;
    if (ngols>0) {
      gusxpr();
/*
 *  save total cost prcost in cst
 */
      cst=prcost;
    }
/*
 *  calculate total cost prcost of logic variables
 */
    cstxpr();
/*
 * compute total cost
 */
    prcost=cst+prcost;
/*
 *  compute lower bound
 */
    if (opt==1) {
      lpmin=prcost;
    } else {
      lpmin=prcost-dcst;
    }
    lbcost=lpmin;
/*
 *  display progress
 */
    if (detail==1) {
      printf("\nfinal solution value = %10ld",prcost);
      printf("\n");
    }
/*
 *  set solution flag solflg and satisfiability flag satble
 */
    solflg=1;
    satble=1;
/*
 *  output values
 */
    strcpy(pstate,"S");
    strcpy(ptype ,"MIN");
    pvalue_(3)=prcost;
    pvalue_(4)=lbcost;
  } else {
/*
 *  had fatal error, do not have a solution
 */
    solflg=0;
    satble=0;
  }
/*eject*/
/*
 * --------------------------------------------------------
 *  step 29
 *  reset assign and optimization flags
 * --------------------------------------------------------
 */
  zz2905:;
/*
 *  set assign flag asgflg
 *  since satisfiability subproblems were used
 */
  asgflg=1;
/*
 *  restore optimization flag
 */
  optimz=1;
/*eject*/
/*
 * --------------------------------------------------------
 *  step 30
 *  if lpx allocation was done in step 3, de-allocate now
 *  then copy internal parameter values to user parameters
 *  except for pname
 * --------------------------------------------------------
 */
  strcpy(xcomnd,"FRE DIM");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  strcpy(ustate,pstate);
  strcpy(utype ,ptype);
  for(i=1; i<=8; i++)  {
    uvalue_(i)=pvalue_(i);
  }
  for(i=1; i<=2; i++)  {
    uerror_(i)=perror_(i);
  }
/*
 */
  return;
}
/*  last record of apmsol.c****** */
