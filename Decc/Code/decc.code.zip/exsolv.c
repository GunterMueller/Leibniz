/*  first record of exsolv.c***** */
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();
/*
 * *****************************************************
 *  module execution
 * 
 *  purpose:  for decomposable cnf problem in layer 1,
 *            enumerates all possible connections between
 *            components and all possible values of fixed
 *            columns within each component, then decides
 *            satisfiability for clauses in active rows i
 *            with rhs1(i) = 1. ignores inactive columns j;
 *            the latter columns must have dlclop(j) = 1.
 *            cifix, scale vectors, range data drange,
 *            erange, gpod, gpoe arrays, and twosat flags
 *            must have been computed.
 * 
 * input:  problem in layer 1.
 *         arrays assumed defined:
 *       - matrix data amslcl, amslrw
 *       - ncols, nrows, nblks
 *       - colnam, rownam, prbnam
 *       - idxrow, idxcol
 *       - dlclop, dlrwop
 *       - matrix indices cixxx, rixxx as follows:
 *         rixxx:  changes from the configuration
 *                 of all active rows (as assumed
 *                 in ranges) must obey the following
 *                 rule:
 *                   if dlrwop(i) = 1, then row i may
 *                   be declared to be inactive.
 *                   if dlrwop(i) = 0, then row i may
 *                   be declared to be inactive only
 *                   if that status is a consequence
 *                   of fixing some variables to
 *                   +1 or -1 (see cixxx below).
 *                 in all cases, subroutine mracin or
 *                 iracin must be used to declare rows
 *                 to be inactive. row i inactive means
 *                 that row i need not be be satisfied.
 *         cixxx: changes from the configuration of
 *                free/fixed columns produced by
 *                subroutine ranges must follow the
 *                rules given below.
 *                - if column j value is to be a constant
 *                  +1 or -1:  must have declared active
 *                  rows thus satisfied by column j to
 *                  be inactive, and must have declared
 *                  column j to be inactive (using
 *                  subroutines mracin and mcfrin or
 *                  mcfxin, whichever applies, or
 *                  the corresponding iracin, icfrin,
 *                  icfxin.)
 *                 - if column j value is to be 0:  if
 *                   nblks > 1, this is permitted only if
 *                   dlclop(j) = 1. in all cases must have
 *                   declared column j to be inactive
 *                   (using subroutine mcfrin or mcfxin,
 *                   whichever applies, or the
 *                   corresponding icfrin, icfxin.
 *                 - in all cases of setting column j to 0,
 *                   +/-1, column j is inactive within
 *                   enudec, and if succss = 1, a solution
 *                   value of solut1(j) = 0 is returned
 *                   (see below).
 *        - matrix counts cnxxx, rnxxx
 *        - lcllim, ucllim, lrwlim, urwlim, scale, drange,
 *          erange, ndrge, nerge, gpod, gpoe, gpodp, gpoep,
 *          twosat must have been computed.
 *        - rhs1: if dlrwop(i) = 1, then rhs1(i) = 0 is
 *                permitted. if dlrwop(i) = 0, then
 *                rhs1(i) = 1 must hold.
 *                by selection rhs1(i) = 0, row i is
 *                effectively disregarded. the same effect
 *                can be achieved by declaring row i to be
 *                inactive.  this second method is more
 *                efficient due to variable fixing
 *                procedure.
 *        - cost(j) for all columns j; must be nonnegative.
 * 
 *      caution:  no check is made whether or not the above
 *                rules for changes of rows/column status
 *                and of rhs1 values have been followed.
 * 
 *   calling sequence:
 *     enudec     enumerates connections between components
 *                via range arrays, solves each component
 *                with some variable fixing as nearly
 *                negative or 2sat problem.  concludes
 *                whether or not entire problem is
 *                satisfiable.
 *       enufxz, enufx1, enufx2
 *                enumerate fixed variables and solve
 *                one component of nearly negative or
 *                2sat problem.
 *         satneg solve a nearly negative problem.
 *           or
 *         sat2st solve a 2sat problem.
 * 
 *   caution: -no part of the arrays of layer 1 are
 *             allowed to be modified by the subroutines
 *             of this module except for rhs2-5 and
 *             solut1-5.
 *            -rhs2-5 and solut1-5 arrays are disturbed
 *             by the module, and are not restored when
 *             this module is done. at exit time, solut1
 *             contains the solution as described above
 *             under output.
 * 
 *            -counts rnxxxx and cnxxxx of layer 1 may
 *             never be used in this subroutine since
 *             irxxxx and icxxxx may have been used to
 *             move rows/columns from active to inactive.
 *             these routines do not maintain the
 *             counts rnxxxx and cnxxxx, but adjust only
 *             the indicator indices rixxxx and cixxxx.
 * 
 * 
 * *******************************************************
 */
/*eject*/ 
/* 
 * *******************************************************
 *   subroutine enudec
 * 
 *  purpose:  for decomposable cnf problem in layer 1,
 *            enumerates all possible connections between
 *            components and all possible values of fixed
 *            columns within each component, then decides
 *            satisfiability for clauses in active rows i
 *            with rhs1(i) = 1.  ignores inactive
 *            columns j; the latter columns must have
 *            dlclop(j) = 1.  cifix, scale vectors,
 *            range data drange, erange, gpod, gpoe arrays,
 *            and twosat flags must have been computed.
 * 
 *    input:  as described in the module summary.
 * 
 *   output:  output is same as for enufix.
 *            either: succss = 1; layer 1 contains input
 *            problem,  except that solution is in solut1
 *            vector. if column j inactive :
 *                           solut1(j) = 0
 *                    if column j fixed or free:
 *                           solut1(j) = +/-1.
 * 
 *            or: succss = 0; layer 1 contains input
 *                problem.
 * 
 *   caution: after setup in stefx1:
 *               free matrix is in amslcl and amslrw
 *               free and fixed matrix is in bmslcl
 *               and bmslrw
 * 
 *  ==============
 *  update history
 *  ==============
 *  date          where            what/reason
 *  =====================================================
 * ******************************************************
 * 
 */
void enudec() {
/*
 */
  static long n1,pair,ppair,j,q;
  void enufix(), error();
  void stefx1(), stefx2(), stscas(), xaact();
/*
 *  set up column selection combinations in selcas
 */
  stscas();
/*
 *  extract submatrix of active columns and active rows i
 *  with rhs1(i)=1;
 *  place into block matrix array ablkcl. ablkrw is
 *  not computed, but row pointers ptablr are established
 */
  xaact();
/*
 * initialize node count for tree enumeration
 */
  ncount=0;
/*eject*/
/*
 *
 *  ------------------------------------------------------
 *  if there is just one block, solve directly by enufix
 *  ------------------------------------------------------
 */
  if (nblks==1) {
    qblock=1;
/*
 *  set up for enufix, part 1:
 *  lcllmt, ucllmt, lrwlmt, urwlmt, amslcl, amslrw,
 *  bmslcl, bmslrw, rposj, solut2, cxlfix
 */
    stefx1();
/*
 *  set up for enufix, part 2:
 *  rhs3, rxleqz, rxleq1, and if twosat(q) = 1: rxleq2
 *  initialize rhs4 and rhs5 as = rhs3
 */
    stefx2();
/*
 *  invoke enufix to solve. solution is in solut1
 */
    enufix();
/*
 * for output of node count to screen, activate code below
 */
/*    printf(
        "\n succss = %ld  prcost = %ld",succss,prcost);
    printf("\n final node count = %ld",ncount); */
/*
 */
    return;
  }
/*eject*/
/*
 *  -------------------------------------------------------
 *  problem has at least two blocks.  it is processed in
 *  two passes.  we start with forward pass.
 *  -------------------------------------------------------
 *  process each strip q
 */
  for(q=1; q<=nblks; q++)  {
    qblock=q;
/*
 *  setup for enufix; part 1:
 *    lcllmt, ucllmt, lrwlmt, urwlmt, amslcl, amslrw,
 *    bmslcl, bmslrw, rposj, solut2, cxlfix, rhs2
 */
    stefx1();
/*
 *  initialize number of range vector pairs leading to
 *  satisfiability to zero (initially nonsatisfiable).
 */
    npairs_(q)=0;
    succss=0;
/*
 *  -------------------------------------------------------
 *  process all range vector combinations of d2|1 and e2/3
 *  for strip q
 *  -------------------------------------------------------
 */
    for(dr=1; dr<=ndrge_(q); dr++)  {
      for(er=1; er<=nerge_(q); er++)  {
/*
 *  check if this combination of range vectors is dominated
 *  by a solved case.  if yes, skip to next case.
 */
        if ((npairs_(q)>0)&&(optimz==0)) {
          for(pair=1; pair<=npairs_(q); pair++)  {
            dr1=ldr_(pair,q);
            er1=ler_(pair,q);
            if ((gpod_(dr,dr1+nerge_(q),q)<0)&&
                (gpoe_(er,er1,q)<0)) {
/*
 *  the pair (dr1,er1) with satisfying solution found
 *  earlier dominates the pair (dr,er).  thus, the pair
 *  (dr,er) can be discarded.
 */
              goto zz710;
            }
          }
        }
/*
 *  increment npairs(q)
 */
        npairs_(q)=npairs_(q)+1;
/*
 *  initialize total cost entry
 */
        if (optimz==1) {
          lcost_(npairs_(q),q)=tt31m1;
        }
/*
 *  set do loop bounds for case analysis combining strip q-1
 *  satisfiable cases with block q cases
 */
        if (q==1) {
          n1=1;
        } else {
          n1=npairs_(q-1);
        }
/*
 *  start case analysis
 */
        for(pair=1; pair<=n1; pair++)  {
/*
 *  if q .gt. 1, look up indices dr1, er1 of range vector
 *  pair producing a satisfying solution for block q-1
 */
          if (q>1) {
            dr1=ldr_(pair,q-1);
            er1=ler_(pair,q-1);
            if (optimz==1) {
              q1cost=lcost_(pair,q-1);
            }
          } else {
            q1cost=0;
          }
/*
 *  setup for enufix, part 2:
 *  rhs3, rxleqz, rxleq1, and if twosat(q) = 1: rxleq2
 *  initialize rhs4 and rhs5 as = rhs3
 */
          stefx2();
/*
 *  check satisfiability using subroutine enufix
 */
          enufix();
/*
 * for output of result to screen, activate code below
 */
/*          printf(
           "\n succss = %ld  prcost = %ld",
           succss,prcost);*/
/*
 *  if problem is satisfiable, record so in ldr, ler,
 *  lcost, ldr1, ler1 arrays, and skip ahead to next
 *  dr, er case.  for optimization, prcost
 *  contains minimal cost for block.
 */
          if ((succss==1)&&
              (optimz==0)) {
            ldr_(npairs_(q),q)=dr;
            ler_(npairs_(q),q)=er;
            if (q>1) {
              ldr1_(npairs_(q),q)=dr1;
              ler1_(npairs_(q),q)=er1;
            }
/*
 *  if q .lt. nblks and if there is space for the solution,
 *  then retain it in retsol
 */
            if ((q<nblks)&&
                (npairs_(q)<=lclmax)) {
              for(j=lcllmt; j<=ucllmt; j++)  {
                retsol_(j,npairs_(q))=solut1_(j);
              }
            }
/*
 *  if this is the last strip (q = nblks), have
 *  satisfiability of entire problem.
 *  save solution of strip nblks in solut5 and
 *  start second phase.
 */
            if (q==nblks) {
              for(j=lcllim_(nblks); j<=ucllim_(nblks); j++)  {
                solut5_(j)=solut1_(j);
              }
              goto zz2000;
            }
            goto zz710;
          }
          if ((succss==1)&&
              (optimz==1)) {
            ttcost=prcost+q1cost;
            if (lcost_(npairs_(q),q)>ttcost) {
/*
 *  have a better solution
 */
              lcost_(npairs_(q),q)=ttcost;
              ldr_(npairs_(q),q)=dr;
              ler_(npairs_(q),q)=er;
              if (q>1) {
                ldr1_(npairs_(q),q)=dr1;
                ler1_(npairs_(q),q)=er1;
              }
/*
 *  if q .lt. nblks and if there is space for the solution,
 *  then retain it in retsol
 */
              if ((q<nblks)&&
                  (npairs_(q)<=lclmax)) {
                for(j=lcllmt; j<=ucllmt; j++)  {
                  retsol_(j,npairs_(q))=solut1_(j);
                }
              }
/*
 *  if q=nblks, save solution of strip nblks in solut5
 */
              if (q==nblks) {
                for(j=lcllim_(nblks); j<=ucllim_(nblks); j++)  {
                  solut5_(j)=solut1_(j);
                }
              }
            }
          }
        }
/*
 *  if no optimization, then there is no solution for
 *  dr, er pair
 */
        if (optimz==0) {
          npairs_(q)=npairs_(q)-1;
        } else {
/*
 *  if optimization, then no solution if and only if
 *  lcost(npairs(q),q) = tt31m1
 */
          if (lcost_(npairs_(q),q)==tt31m1) {
            npairs_(q)=npairs_(q)-1;
          } else {
/*
 *  have a solution.
 *  if q=nblks, start second phase.
 */
            if (q==nblks) {
              goto zz2000;
            }
/*
 *  know q < nblks.  check if present solution is
 *  dominated by another one of block q.
 */
            if (npairs_(q)>1) {
              for(pair=1; pair<=npairs_(q)-1; pair++)  {
                dr1=ldr_(pair,q);
                er1=ler_(pair,q);
                if ((gpod_(dr,dr1+nerge_(q),q)<0)&&
                    (gpoe_(er,er1,q)<0)&&
                    (lcost_(pair,q)<=lcost_(npairs_(q),q))) {
/*
 *  solution for dr, er pair is dominated.  delete it.
 */
                  npairs_(q)=npairs_(q)-1;
                  goto zz710;
                }
              }
            }
          }
        }
      zz710:;}
    }
/*
 *  if for block q no satisfiable case was found,
 *  entire problem is unsatisfiable.
 */
    if (npairs_(q)==0) {
/*
 *  have unsatisfiability, so return. must have
 *  succss = 0 from last call of enufix or from
 *  initialization after the do 500 loop.
 */
      if (succss!=0) {
        error(" enudec ","  702   ");
      }
/*
 * for output of final node count to screen, activate
 * code below
 */
     /* printf("\n final node count = %ld",ncount);*/
/*
 */
      return;
    }
  }
/*eject*/
/*
 * --------------------------------------------------------
 *  start backward pass
 * --------------------------------------------------------
 *  programming error
 */
  error(" enudec ","  2002  ");
  zz2000:;
  dr=ldr1_(1,nblks);
  er=ler1_(1,nblks);
/*
 *  set up remaining strips with correct rhs3 vectors
 *  and solve
 */
  for(q=nblks-1; q>=1; q--)  {
    qblock=q;
/*
 *  search for dr and er in ldr and ler arrays
 */
    for(pair=1; pair<=npairs_(q); pair++)  {
      if ((ldr_(pair,q)==dr)&&
          (ler_(pair,q)==er)) {
/*
 *  have found the desired pair.  locate corresponding
 *  dr1 and er1 in ldr1 and ler1 if q .gt. 1
 */
        if (q>1) {
          dr1=ldr1_(pair,q);
          er1=ler1_(pair,q);
        }
/*
 *  retain pair in ppair
 */
        ppair=pair;
        goto zz2110;
      }
    }
/*
 *  did not find dr and er in ldr and ler arrays
 *  implies error
 */
    error(" enudec ","  2102  ");
    zz2110:;
/*
 *  if solution was retained in retsol, then insert it
 *  into solut5 and skip calculation via enufix
 *  note: lcllmt and ucllmt are not defined at this point
 */
    if (ppair<=lclmax) {
      for(j=lcllim_(q); j<=ucllim_(q); j++)  {
        solut5_(j)=retsol_(j,ppair);
      }
    } else {
/*
 *  must compute solution; set up for enufix, part 1:
 *    lcllmt, ucllmt, lrwlmt, urwlmt, amslcl, amslrw,
 *    bmslcl, bmslrw, rposj, solut2, cxlfix, rhs2
 */
      stefx1();
/*
 *  set up for enufix, part 2:
 *    rhs3, rxleqz, rxleq1, if twosat(q) = 1: rxleq2
 */
      stefx2();
/*
 *  solve strip q with rhs3 vector
 */
      enufix();
/*
 * for output of result to screen, activate code below
 */
     /* printf(
        "\n succss = %ld  prcost = %ld",
        succss,prcost);*/
/*
 *  must have a solution.  if not, programming error
 */
      if (succss==0) {
        error(" enudec ","  2302  ");
      }
/*
 *  save solution of strip q in solut5
 */
      for(j=lcllmt; j<=ucllmt; j++)  {
        solut5_(j)=solut1_(j);
      }
    }
/*
 *  if q .gt. 1, update dr, er for next loop iteration
 */
    if (q>1) {
      dr=dr1;
      er=er1;
    }
  }
/*
 *  solut5 now has correct solution.
 *  indicate success in succss
 *  transfer solut5 to solut1
 *  and return.
 */
  succss=1;
  for(j=1; j<=ncols; j++)  {
    solut1_(j)=solut5_(j);
  }
/*
 * for output of final node count to screen, activate
 * code below
 */
 /* printf("\n final node count = %ld",ncount);*/
/*
 */
  return;
}
/*eject*/
/*
 * ****************************************************
 * subroutine enufix
 * 
 *  invokes enufxz, enufx1, or enufx2 to enumerate all
 *  possible cases for fixed columns.
 *  for input details, see enufxz, enufx1, and enufx2
 *  enufxz: case with no fixed columns
 *  enufx1: direct enumeration, with skipping of case
 *          based on aggregation arguments
 *  enufx2: tree construction, with selection of fixed
 *          column for binding based on several criteria
 * ****************************************************
 *  ==============
 *  update history
 *  ==============
 *  date      where             what was changed/reason
 * ----------------------------------------------------
 * ****************************************************
 * 
 */
void enufix() {
/*
 */
  static long n;
/*
 */
  void enufxz(), enufx1(), enufx2();
/*
 *  determine number of fixed variables
 */
  n=cxlfix_(colmax+1);
/*
 *  case without fixed columns
 */
  if (n==0) {
    enufxz();
    return;
  }
/*
 *  case with fixed columns
 *  select based on number of fixed columns
 * 
 * 
 *  direct enumeration, with skipping of case
 *  based on aggregation arguments
 * 
 *  can be 2sat or nearly negative case
 */
  if (n<=aggmax) {
    enufx1();
    return;
  }
/*
 *  tree construction, with selection of fixed
 *  column for binding based on several criteria
 * 
 *  by selection rule for 2sat in heualg and optalg
 *  using aggmax bound on number of fixed variables,
 *  cannot have 2sat case here and must hence must
 *  have nearly negative case
 */
  enufx2();
  return;
}
/*eject*/
/*
 * ******************************************************
 * subroutine enufxz
 * 
 * purpose:  for cnf problem of layer 1 having no
 *           fixed columns,
 *           decides satisfiability for clauses
 *           in rows i with rhs3(i) = 1. uses only
 *           columns(j) with lcllmt .le. j .le. ucllmt.
 *           assumes nearly negative submatrix
 *           (twosat(qblock)=0) or 2sat submatrix
 *           (twosat(qblock)=1) for free columns j.
 * 
 *   input:
 *           - matrix of free columns and active
 *             rows i with rhs1(i) = 1 of block qblock
 *             in amslcl, amslrw
 *           - fixed (as well as active) columns with
 *             entries in active rows i
 *             having rhs1(i) = 1 are contained in ablkcl
 *             (created by subroutine xaact)
 *           - lcllmt, ucllmt
 *           - rposj
 *           - cxlfix
 *           - rxleqz, rxleq1, rxleq2
 *           - solut2(j) = -1 if j free and satneg case.
 *                         (j of block q).
 *                       =  2 if j free and sat2st case.
 *                       =  0 if j fixed or inactive.
 *           - rhs3
 *           - twosat(qblock) = 0   satneg case.
 *                            = 1   sat2st case.
 * 
 *  output:  succss = 1:  problem is satisfiable
 *                        using columns j,
 *                        lcllmt .le. j .le. ucllmt;
 *                        solut1(j) = solution value.
 *           succss = 0:  problem is not satisfiable
 *                        by columns j,
 *                        lcllmt .le. j .le. ucllmt
 * 
 *  caution: rhs4 and solut4 are changed by the routine
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where          what was changed/reason
 * --------------------------------------------------
 * ******************************************************
 * 
 */
void enufxz() {
/*
 */
  static long n;
/*
 */
  void satneg(), sat2st(), stsat1(), stsat2(), stsat3();
  void cstprb(), error();
/*
 *  determine number of fixed variables and initialize
 *  aggregation index
 */
  n=cxlfix_(colmax+1);
/*
 *  error if n .ne. 0
 */
  if (n!=0) {
    error(" enufxz "," 102    ");
  }
/*
 *  set up for satneg or sat2st
 *    solut1, rhs4, rnred
 */
  stsat1();
/*
 *  check for obvious infeasibility using rxleqz
 *  set up rxlcu1 for satneg or sat2st
 */
  stsat3();
  if (succss==0) {
    return;
  }
  if (twosat_(qblock)==0) {
    satneg();
  } else {
    sat2st();
  }
  if ((succss==1)&&(optimz==1)) {
    cstprb();
  }
  return;
}
/*eject*/
/*
 * ******************************************************
 * subroutine enufx1
 * 
 * purpose:  for cnf problem of layer 1, enumerates all
 *           possible values for fixed columns
 *           using aggregation method, then for
 *           each case decides satisfiability for clauses
 *           in rows i with rhs3(i) = 1. uses only
 *           columns(j) with lcllmt .le. j .le. ucllmt.
 *           assumes nearly negative submatrix
 *           (twosat(qblock)=0) or 2sat submatrix
 *           (twosat(qblock)=1) for free columns j.
 * 
 *   input:
 *           - matrix of free columns and active
 *             rows i with rhs1(i) = 1 of block qblock
 *             in amslcl, amslrw
 *           - fixed (as well as active) columns with
 *             entries in active rows i
 *             having rhs1(i) = 1 are contained in ablkcl
 *             (created by subroutine xaact)
 *           - lcllmt, ucllmt
 *           - rposj
 *           - cxlfix
 *           - rxleqz, rxleq1, rxleq2
 *           - solut2(j) = -1 if j free and satneg case.
 *                         (j of block q).
 *                       =  2 if j free and sat2st case.
 *                       =  0 if j fixed or inactive.
 *           - rhs3
 *           - twosat(qblock) = 0   satneg case.
 *                            = 1   sat2st case.
 * 
 *  output:  succss = 1:  problem is satisfiable
 *                        using columns j,
 *                        lcllmt .le. j .le. ucllmt;
 *                        solut1(j) = solution value.
 *           succss = 0:  problem is not satisfiable
 *                        by columns j,
 *                        lcllmt .le. j .le. ucllmt
 * 
 *  caution: rhs4 and solut4 are changed by the routine
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where          what was changed/reason
 * --------------------------------------------------
 * ******************************************************
 * 
 */
void enufx1() {
/*
 */
  static long n,j,j1,ix,i;
/*
 */
  void satneg(), sat2st(), stsat1(), stsat2(), stsat3();
  void cstprb(), error();
/*
 *  ------------------------------------------------------
 *  step 1
 *  initialize
 *    number of fixed variables
 *    aggregation index
 *    aggregation increment
 *    total cost
 *  ------------------------------------------------------
 */
  n=cxlfix_(colmax+1);
/*
 *  error if n .le. 0 or n .gt. aggmax
 */
  if ((n<=0)||
      (n>aggmax)) {
    error(" enufx1 "," 102    ");
  }
/*
 */
  aggidx=n;
  aggdif=3;
/*
 *  reset aggregation index to zero if few fixed variables
 */
  if (n<aggdif) {
    aggidx=0;
  }
/*
 */
  cost1=tt31m1;
/*eject*/
/*
 *  ------------------------------------------------------
 *  step 2
 *  initialize case vector
 *  ------------------------------------------------------
 *  initialize case vector
 */
  for(j=1; j<=n+1; j++)  {
    fxcase_(j)=0;
  }
/*eject*/
/*
 * -------------------------------------------------------
 *  step 3
 *  set up for satisfiability tests
 * -------------------------------------------------------
 */
  zz300:;
/*
 *  set up for satneg or sat2st
 *    solut1, rhs4, rnred
 */
  stsat1();
/*
 *  decide values for fixed columns; 
 *  know these columns to be nonzero
 *  due to stefx1.
 *  fix solut1 values and update rhs4 vector
 *  first, aggregated columns
 */
  if (aggidx>=1) {
    for(j=1; j<=aggidx; j++)  {
      j1=cxlfix_(j);
/*
 *  values of solut1 given below must not be interpreted
 *  due to aggregation
 */
      solut1_(j1)=-1;
      for(ix=1; ix<=nzablc_(j1); ix++)  {
        i=abs(ablkcl_(ix+ptablc_(j1)));
        rhs4_(i)=0;
      }
    }
  }
/*
 *  non-aggregated columns
 */
  if (n>aggidx) {
    for(j=aggidx+1; j<=n; j++)  {
      j1=cxlfix_(j);
      if (fxcase_(j)==0) {
        solut1_(j1)=-1;
/*
 *  update rhs4
 */
        for(ix=1; ix<=nzablc_(j1); ix++)  {
          i=-ablkcl_(ix+ptablc_(j1));
          if (i>0) {
            rhs4_(i)=0;
          }
        }
      } else {
        solut1_(j1)=1;
        for(ix=1; ix<=nzablc_(j1); ix++)  {
          i=ablkcl_(ix+ptablc_(j1));
          if (i>0) {
            rhs4_(i)=0;
          }
        }
      }
    }
  }
/*eject*/
/*
 * -------------------------------------------------------
 *  step 4
 *  do satisfiability test
 * -------------------------------------------------------
 *  check for obvious infeasibility using rxleqz
 *  set up rxlcu1 for satneg or sat2st
 */
  stsat3();
  if (succss==0) {
    goto zz430;
  }
/*
 *  check satisfiability
 */
  if (twosat_(qblock)==0) {
    satneg();
  } else {
    sat2st();
  }
  if (succss==1) {
/*
 *  problem is satisfiable for this case
 */
    if (aggidx>=1) {
/*
 *  have an aggregated problem. reduce aggregation
 *  index and solve problem again
 */
      aggidx=aggidx-1;
      goto zz300;
    }
/*
 *  problem is not aggregated since aggidx = 0
 *  have valid solution
 */
    if (optimz==0) {
      return;
    } else {
      cstprb();
      if (prcost<cost1) {
        cost1=prcost;
/*
 *  store solution in solut4
 */
        for(j=lcllmt; j<=ucllmt; j++)  {
          solut4_(j)=solut1_(j);
        }
      }
    }
  }
  zz430:;
/*
 *  have optimization problem, or problem is not
 *  satisfiable for current case, or time bound is being
 *  computed add 1 in position aggidx+1 to the binary
 *  number encoded by fxcase vector
 */
  for(j=aggidx+1; j<=n+1; j++)  {
    if (fxcase_(j)==0) {
      fxcase_(j)=1;
      j1=j;
      goto zz460;
    } else {
      fxcase_(j)=0;
    }
  }
/*
 *  programming error
 */
  error(" enufx1 "," 462    ");
/*
 *  check if all cases have been enumerated
 */
  zz460:;
  if (fxcase_(n+1)==0) {
/*
 *  not yet done with all cases
 *  check if aggregation should be extended, based on the number
 *  of zeros in fxcase vector to left of aggidx position
 */
    if (j1>aggidx+aggdif) {
      aggidx=aggidx+aggdif;
    }
/*
 *  start next case
 */
    goto zz300;
  }
/*eject*/
/*
 *  -----------------------------------------------------
 *  step 5
 *  -----------------------------------------------------
 *  problem not satisfiable if optimization is not
 *  involved.  know succss=0.
 */
  if (optimz==0) {
    return;
  }
/*
 *  have optimization case.  no solution if cost1 = tt31m1;
 *  in that case, know succss = 0.
 */
  if (cost1==tt31m1) {
    return;
  }
/*
 *  find solution for best case
 *  place best solution into solut1
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
    solut1_(j)=solut4_(j);
  }
/*
 *  transfer total cost
 */
  prcost=cost1;
  succss=1;
  return;
}
/*eject*/
/*
 * *******************************************************
 * subroutine enufx2
 * 
 * purpose:  for cnf problem of layer 1, enumerates all
 *           possible values for fixed columns
 *           using tree search, then for
 *           each case decides satisfiability for
 *           clauses in rows i with rhs3(i) = 1.
 *           uses only columns(j) with
 *           lcllmt .le. j .le. ucllmt. assumes
 *           nearly negative submatrix (twosat(qblock)=0)
 *           for free columns j.
 * 
 *   input:
 *           - matrix of free columns and active rows i
 *             with rhs1(i) = 1 of
 *             block qblock in amslcl, amslrw
 *           - matrix of free and fixed columns and
 *             active rows i with rhs1(i) = 1 of
 *             block qblock in bmslcl, bmslrw
 *           - fixed (as well as active) columns
 *             with entries in active
 *             rows i having rhs1(i) = 1 are contained
 *             in ablkcl (created by subroutine xaact)
 *           - lcllmt, ucllmt
 *           - rposj
 *           - cxlfix
 *           - rxleqz, rxleq1, rxleq2
 *           - solut2(j) = -1 if j free and satneg case.
 *                         (j of block q).
 *                       =  2 if j free and sat2st case.
 *                       =  1 if column j fixed in block q
 *                               and column j nonzero
 *                       = -1 if column j fixed in block q
 *                               and column j zero
 *                        (due to inactive rows inducing
 *                         a reduced problem)
 *                         this handles the case of
 *                         optimization correctly
 *                         since cost is nonnegative,
 *                         and is zero for false
 *                       =  0 else
 *           - rhs3
 *           - twosat(qblock) = 0   satneg case.
 *                            = 1   sat2st case.
 * 
 *  binding arrays:
 *       cifre(j) /= 0 |   cifix(j) /= 0    | cifre(j) = 0
 *                     |                    | cifix(j) = 0
 *                     | col j/=0  | col j=0|
 *        ------------------------------------------------
 *  bdvalu(j) and bdtemp(j)
 *                  0  | 0 not bd  |   0    |   0
 *                     | +-1 bound |        |   0
 *        ------------------------------------------------
 *  bdcase(j)       0  | 0 not bd  |   0    |      0
 *                     | 1 1st bdg |        |
 *                     | 2 2nd bdg |        |
 *        ------------------------------------------------
 *  bdcons(j)      0 not bound     |   0    |      0
 *               +-1 bound         |   0    |      0
 *        ------------------------------------------------
 *  index lists:       |           |
 *  cxlfix             |list of all|
 *                     |  indices  |
 *        ------------------------------------------------
 *  cxlbnd             |sublist of |
 *                     |  indices  |
 *        ------------------------------------------------
 *  counts:
 *            nconcl    = number of bound values
 *                        of bdcons vector
 *            nconfx    = number of bound values
 *                        of bdcons vector in
 *                        cifix/=0 portion
 *            bdsave(j) = saved bdcons(j)
 *            nsavec    = saved nconcl
 *            nsavex    = saved nconfx
 * 
 * 
 *  caution: bdvalu, bdcase, cxlbnd correspond to
 *           explicitly bound variables j, and not to
 *           variables bound as a consequence by
 *           unit vector processing.
 * 
 *  solution vectors:
 *     cifre(j) /= 0   |   cifix(j) /= 0    | cifre(j) = 0
 *                     |                    | cifix(j) = 0
 *                     | col j/=0 | col j=0 |
 *         ------------------------------------------------
 *  solut1(j) (output) and solut4(j) (intermed)
 *             +-1     |    +-1   |   -1    |      0
 *                     |          |         |
 *                     |          |         |
 *         ------------------------------------------------
 *  solut2(j)  (input)
 *         -1 (satneg) |     1    |   -1    |      0
 *          2 (sat2st) |          |         |
 *         ------------------------------------------------
 * 
 *   enumeration:
 *        parameters:
 *            selmax    = max number of selected columns
 *                        for combination evaluation
 *            scsmax    = max number of combination cases
 *                        of selected columns
 *            covmax    = max row count used in
 *                        evaluation of combinations
 * 
 *        counts:
 *            nslcol    = number of selected columns
 *                        (<= selmax)
 *            nslcas    = number of cases produced by
 *                        selected columns
 *                        (<= scsmax)
 *        indices:
 *            curcas    = index of case currently processed
 * 
 *        arrays:
 *            selcol(k) = column index j of k-th selected
 *                        column k = 1, ..., selmax
 *            covtot(l) = weighted total of number of rows
 *                        with l nonzeros covered by given
 *                        column j using +-1
 *                        (for l=covmax, count is for
 *                         >=covmax case)
 *                        formula is modified when final
 *                        selection is made (see evcmb1)
 *            covmat(i,l) = matrix of covtot vectors,
 *                          one for each combination
 *                        i = 1, ..., scsmax
 *                        l = 1, ..., covmax
 *                        (for l=covmax, count is for
 *                         >=covmax case)
 *            nstrow(i)  = number of rows satisfied by
 *                        case i
 *                        i = 1, ..., scsmax
 *            selcas(i,k) = matrix of possible combinations
 *                        of bindings
 *                        i = 1, ..., scsmax
 *                        k = 1, ..., selmax
 *                        k points to column j = selcol(k)
 * 
 * 
 *  output:  succss = 1:  problem is satisfiable
 *                        using columns j,
 *                        lcllmt .le. j .le. ucllmt;
 *                        solut1(j) = solution value
 *                        minsat only:
 *                          prcost = optimal total cost
 *           succss = 0:  problem is not satisfiable
 *                        by columns j,
 *                        lcllmt .le. j .le. ucllmt
 * 
 *    caution:  rhs4, rhs5, and solut4 are changed
 *              by the routine
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where             what was changed/reason
 * -------------------------------------------------------
 * *******************************************************
 * 
 */
void enufx2() {
/*
 */
  static long flag,i,j,jx,n;
/*
 * 
 */
  void bstcas(), bstjval1(), bstjval2();
  void cstprb(), error();
  void evcmb1(), evcmb2(), evcmb3(), evlcol(), evlunt();
  void intbds();
  void restbd(), retcov(), satneg(), sat2st(), savebd();
  void solunt(), stcomb(), stefx1(), stefx2();
  void stsat1(), stsat2(), stsat3(), stscas();
  void stsel1(), stsel2(), stunt1(), stunt2(), stunt3();
  void tstunq();
/*
 *  error if 2sat case for free columns
 */
  if (twosat_(qblock)==1) {
    error("enufx2","102");
  }
/*
 */
  n=cxlfix_(colmax+1);
/*
 *  error if n .le. aggmax
 */
  if (n<=aggmax) {
    error("enufx2","104");
  }
/*eject*/
/*
 *  ------------------------------------------------------
 *  step 0
 *  initialize arrays
 *  ------------------------------------------------------
 *  initialize  bdvalu, bdcase, cost1
 */
  intbds();
/*eject*/
/*
 *  ------------------------------------------------------
 *  step 1
 *  evaluate current binding
 *  ------------------------------------------------------
 */
  zz1000:;
/*
 *  set up for unit vector processing
 *  set up bdcons, nconcl, nconfx
 */
  stunt1();
/*
 *  set up rhs4, rnared, rnbred, ribred, rxlbw1, rxlbwz
 *  set curcas=-1 to skip case evaluation
 */
  curcas = -1;
  stunt3();
/*
 *  unit vector processing
 *  update bdcons, rhs4, rnared, rnbred, ribred, nconcl, nconfx
 */
  solunt();
  if (succss==0) {
/*
 *  case is obviously infeasible
 *  unbind variable most recently bound
 */
    goto zz4000;
  }
/*
 *  case is not obviously infeasible
 *  save bdcons, nconcl, nconfx
 */
  savebd();
/*
 *  optimization only:
 *    compute lower bound on total cost
 */
  if (optimz==1) {
/*
 *  compute lowbnd
 */
    evlunt();
/*
 *  compare lowbnd with currently best total cost
 */
    if (lowbnd>=cost1) {
/*
 *  lower bound does not beat current total cost
 *  case can be skipped
 *  unbind variable most recently bound
 */
      goto zz4000;
    }
  }
/*
 *  use current rhs4 and rnared to compute rhs5 for
 *  subsequent column selection
 *  must be done now since rhs4 is changed below
 */
  stsel1();
/*
 *  if evalsubflg = 0 (=> there is a row with rhs4 = 1 and
 *  at most one entry in the reduced nearly negative matrix)
 *  and not all variables have been fixed yet 
 *  (=> nconfix < cxlfix_(colmax+1), then guess that subsproblem
 *  will not produce a solution, and therefore fix another
 *  variables.
 */
  if ((evalsubflg == 0) &&
      (nconfx < cxlfix_(colmax+1))) {
    goto zz2000;
  }
/*
 *  set up for satneg or sat2st
 *  set up solut1, rhs4, rnred
 */
  stsat1();
/*
 *  update solut1, rhs4 as follows
 *  for fixed columns: use the nonzero values of bdcons
 *                     or default value (= -1)
 */
  stsat2();
/*
 *  check for obvious infeasibility using rxleqz
 *  set up rxlcu1
 */
  stsat3();
  if (succss==0) {
/*
 *  case is obviously infeasible
 *  bind another variable
 *  note: must be done due to default = -1 choices,
 *        which may trigger infeasibility
 */
    goto zz2000;
  }
/*
 *  check satisfiability
 */
  satneg();
  if (succss==1) {
/*
 *  have a solution
 */
    if (optimz==0) {
      return;
    } else {
      cstprb();
      if (prcost<cost1) {
        cost1=prcost;
/*
 *  store solution in solut4
 */
        for(j=lcllmt; j<=ucllmt; j++)  {
          solut4_(j)=solut1_(j);
        }
/*
 *  check if minsat solution for this case of binding
 *  can be improved by additional binding
 *  the available column j must
 *    be free
 *    have solution value 1
 *    have positive cost
 *    be not bound as consequence of unit resolution
 *  all other variables are bound or at favorable value
 */
        for(j=lcllmt; j<=ucllmt; j++)  {
          if ((cifre_(j)!=0)&&
              (solut1_(j)==1)&&
              (cost_(j)>0)&&
              (bdsave_(j)==0)) {
/*
 *  improvement possible by additional binding
 *  bind another variable
 */
            goto zz2000;
          }
        }
/*
 *  for all free columns j: 
 *     if solut1(j) = 1, then cost(j) = 0. 
 *  hence the free columns contribute 0 to the total cost,   
 *  and no improvement is possible by additional binding
 *
 *  unbind variable most recently bound
 */
        goto zz4000;
      }
    }
  }
/*
 *  sat: have unsatisfiability
 *  minsat: have satisfiable or unsatisfiable
 *  bind another variable
 */
  goto zz2000;
/*eject*/
/*
 *  ------------------------------------------------------
 *  step 2
 *  select another variable for binding
 *  ------------------------------------------------------
 */
  zz2000:;
/*
 *  check if another variable is available for binding
 */
  if (nconfx==cxlfix_(colmax+1)) {
/*
 *  all variables have been bound
 *  unbind variable most recently bound
 */
    goto zz4000;
  }
/*
 */
  if (nconfx>cxlfix_(colmax+1)) {
/*
 *  error, nconfx cannot exceed cxlfix_(colmax+1)
 */
    error("enufx2","2002");
  }
/*
 *  can bind at least one additional variable
 * 
 *  set up covmat and selcol for selection of at most
 *  selmax columns
 */
  stsel2();
/*
 *  evaluate usefulness of all columns jcol that are
 *  fixed and not bound
 */
  for(jx=1; jx<=cxlfix_(colmax+1); jx++)  {
    j=cxlfix_(jx);
    if ((bdcons_(j)==0)) {
      jcol=j;
/*
 *  evaluate jcol
 *  output: covtot
 */
      evlcol();
      if (succss==1) {
/*
 *  column jcol can satisfy some row i where rhs5(i) = 1
 *  retain covtot in covmat and
 *  retain jcol in selcol
 */
        retcov();
      }
    }
  }
/*
 *  check if any column was selected
 */
  if (selcol_(1)==0) {
/* 
 * error, must have selected a column 
 * proof: 
 * assume rhs5 !=0: rhs5(i)=1 and selcol(1)=0
 *     implies that the part of row i in bms 
 *     and not in ams is 0. But then unit 
 *     resolution would have processed row i
 *     or would have discovered unsatisfiability.
 * assume rhs5=0: then previous satneg execution
 *     would have found satisfying solution by
 *     setting all ams columns to -1.
 */
    error("enufx2","2004"); 
  }
/*
 *  the selection depends on how deep we are into the
 *  tree of explicitly fixed variables, and how
 *  many fixed variables remain to be bound. the depth
 *  is given by cxlbnd(colmax+1). the number of fixed
 *  variables that are already bound (explicitly or
 *  implicitly) is given by nconfx.
 * 
 *  the selection method given next is used if
 *  - only one column selected, or
 *  - the tree depth cxlbnd_(colmax+1) satisfies 
 *    a certain bound, or
 *  - the number of variables remaining to be bound
 *         is at most selmax
 * 
 *  if the above case does not apply,
 *  the more complicated selection method given 
 *  later is used. it relies on combinations of 
 *  columns to determine the choice
 */
  if ((selcol_(2)==0)||
      (cxlbnd_(colmax+1)>100)||
      ((cxlfix_(colmax+1)-nconfx)<=selmax)) {
/*
 *  take best column given by selcol(1)
 *  and decide on  +1/-1 value using the number of
 *  rows satisfied when these two values are used
 *  flag=0 means jval is not known to be unique
 */
    jcol=selcol_(1);
    bstjval1();
    flag=0;
    goto zz3000;
  }
/*
 *  the search tree does not satisfy the specified condition,
 *  and there are more than selmax fixed variables
 *  left that are not bound yet
 * 
 *  set up nslcol, nslcas and redefine covmat for
 *  evaluation of combinations
 */
  stcomb();
/*
 *  process each possible combination
 */
  for(i=1; i<=nslcas; i++)  {
    curcas=i;
/*
 *  set up for unit vector processing
 *  restore bdcons, nconcl, nconfx to values
 *  obtained during most recent column evaluation
 */
    restbd();
/*
 *  update bdcons
 */
    stunt2();
/*
 *  set up rhs4, rnared, rnbred, ribred, rxlbw1, rxlbwz
 */
    stunt3();
/*
 *  unit vector processing
 *  update bdcons, rhs4, rnared, rnbred, ribred, nconcl, nconfx
 */
    solunt();
    if (succss==1) {
/*
 *  case is not obviously infeasible
 *  evaluate usefulness of combination of selected
 *  columns and place into covtot
 *
 *  evaluate combination case
 */
      evcmb1();
      if (succss==0) {
/*
 *  there is satisfying solution where all free 
 *  column values = -1.
 *  hence use curcas to select jcol and jval
 */
        istar = curcas;
        if ((istar%2)==0) {
          jcol = selcol_(istar/2);
          jval = -1;
        } else {
          jcol = selcol_((istar+1)/2);
          jval = 1; 
        }
/*
 *  flag = 0 means that jcol is not known to be unique
 */
        flag = 0;
        goto zz3000; 
      }
    } else {
/*
 *  case is obviously infeasible. record this in
 *  covtot by -1s
 */
      evcmb2();
    }
/*
 *  retain covtot in covmat and nsatrow in nstrow
 */
    evcmb3();
  }
/*
 *  test for unsatisfiability and unique column
 *  binding
 *  output: jcol, jval, succss
 */
  tstunq();
  if (succss==0) {
/*
 *  for at least one column, infeasibility
 *  regardless of fixing of that column
 *  unbind column most recently bound
 */
    goto zz4000;
  }
/*
 *  know succss=1. check if there exists a unique
 *  column binding
 */
  if (jcol!=0) {
/*
 *  have unique binding of jcol to jval
 *  flag=1 means that jval is unique
 */
    flag=1;
    goto zz3000;
  }
/*
 *  have no obvious infeasibility and no unique binding
 *  find best combination case
 *  output: istar = best case index
 *          covtot = corresponding row of covmat matrix
 */
  bstcas();
/*
 *  use best combination case istar to find best column
 *  jcol and best value jval for binding
 */
  j = (istar+1)/2;
  jcol = selcol_(j);
/*
 *  select jval value for jcol
 */
  bstjval2();    
/*
 *  bind jcol to jval; flag=0 means that jval is not
 *  known to be unique
 */
  flag=0;
  goto zz3000;
/*eject*/
/*
 *  ------------------------------------------------------
 *  step 3
 *  bind variable jcol to value jval
 *  ------------------------------------------------------
 */
  zz3000:;
/*
 *  update cxlbnd
 */
  cxlbnd_(colmax+1)=cxlbnd_(colmax+1)+1;
  cxlbnd_(cxlbnd_(colmax+1))=jcol;
/*
 *  update bdvalu, bdcase
 */
  bdvalu_(jcol)=jval;
  if (flag==0) {
    bdcase_(jcol)=1;
  } else {
    bdcase_(jcol)=2;
  }
/*
 *  evaluate current binding
 */
  goto zz1000;
/*eject*/
/*
 *  ------------------------------------------------------
 *  step 4
 *  unbind variable most recently bound
 *  ------------------------------------------------------
 */
  zz4000:;
/*
 */
  ncount++;
/*
 *  for output of node count to screen, activate 
 *  code below
 */
/*  if ((ncount/500)*500==ncount) {
    printf("\n node count = %ld",ncount);
  }*/
/*
 *  check if there is a bound column
 */
  if (cxlbnd_(colmax+1)==0) {
/*
 *  no column is bound
 *  this happens if unbinding is requested when
 *  initially no variable has been bound at all,
 *  or if all variables have been unbound
 *  in both cases, we are done with enumeration
 *  decide on succss flag
 */
    if (optimz==0) {
/*
 *  sat case: have no solution
 */
      succss=0;
      return;
    } else {
/*
 *  minsat case: no solution if cost1 = tt31m1
 */
      if (cost1==tt31m1) {
        succss=0;
        return;
      }
/*
 *  have solution for best case in solut4
 *  place that solution into solut1
 */
      for(j=lcllmt; j<=ucllmt; j++)  {
        solut1_(j)=solut4_(j);
      }
/*
 *  transfer total cost
 */
      prcost=cost1;
      succss=1;
      return;
    }
  }
/*
 *  at least one bound variable is left
 *  unbind variable most recently bound
 *  get column index
 */
  jcol=cxlbnd_(cxlbnd_(colmax+1));
  if (bdcase_(jcol)==1) {
/*
 *  evaluate second case for jcol
 */
    bdvalu_(jcol)=-bdvalu_(jcol);
    bdcase_(jcol)=2;
    goto zz1000;
  }
/*
 */
  if (bdcase_(jcol)==2) {
/*
 *  have done second case, eliminate jcol from list
 */
    cxlbnd_(colmax+1)=cxlbnd_(colmax+1)-1;
    bdvalu_(jcol)=0;
    bdcase_(jcol)=0;
/*
 *  check if done with enumeration
 */
    goto zz4000;
  }
/*
 *  error, bdcase(jcol) must be equal 1 or 2
 */
  error(" enufx2 "," 4102   ");
}
/*eject*/
/*
 * *******************************************************
 *  subroutine bstcas
 * 
 *  purpose: finds best case of covmat
 * 
 *  input: covmat
 * 
 * 
 *  output: istar = best row index
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void bstcas() {
/*
 */
  static long i,l;
/*
 */
  void error();
/*
 *  combine covmat rows pairwise
 */
  for(i=1; i<=nslcas; i+=2)  {
    for(l=1; l<=covmax; l++)  {
      if (covmat_(i,l)<=covmat_(i+1,l)) {
        covmat_(i,l) = 2*covmat_(i,l) + covmat_(i+1,l);
      } else {
        covmat_(i,l) = covmat_(i,l) + 2*covmat_(i+1,l);
      }
    }
  }
/*
 *  initialize istar
 */      
  istar=1;
/*
 *  find best row in covmat
 */
  for(i=3; i<=nslcas; i+=2)  {
/*
 *  compare covmat row i with row istar
 */
    for(l=1; l<=covmax; l++)  {
      if (covmat_(i,l)>covmat_(istar,l)) {
/*
 *  have better case, update istar
 */
        istar=i;
        goto zz200;
      }
/*
 */
      if (covmat_(i,l)<covmat_(istar,l)) {
/*
 *  have worse case, skip to next one
 */
        goto zz200;
      }
    }
  zz200:;}
/*
 *  have best case in istar
 */
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine bstjval1
 * 
 *  purpose: finds best value jval for jcol
 *           in simple evaluation case
 * 
 *   input: jcol, rhs5
 * 
 * 
 *  output: best value jval
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void bstjval1() {
/*
 */
static long pos,neg,i,is,ix;
/*
 */
  jval=1;
/*
 *  guess good value for column jval
 */
  pos=0;
  neg=0;
  for(ix=1; ix<=nzbmsc_(jcol); ix++)  {
    is=bmslcl_(ix+ptbmsc_(jcol));
    i=abs(is);
    if (rhs5_(i)==1) {
      if (is>0) {
        pos=pos+1;
      } else {
        neg=neg+1;
      }
    }
  }
  if (neg>=pos) {
    jval=-1;
  }
  if ((optimz==1) &&
      (cost_(jcol)>0)&&
      (cost1<tt31m1)) {
/*
 *  minimization: have already a solution, try lowest cost
 *  case first
 */
    jval=-1;
  }  
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine bstjval2
 * 
 *  purpose: finds best value jval for jcol
 *           in combination evaluation case
 * 
 *   input: istar (is odd), nstrow
 * 
 * 
 *  output: best value jval
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void bstjval2() {
/*
 */
  jval=1;
/*
 *  guess good value for column jval
 */
  if (nstrow_(istar)<=nstrow_(istar+1)) {
    jval = -1;
  }
/*
 */
  if ((optimz==1) &&
      (cost_(jcol)>0)&&
      (cost1<tt31m1)) {
/*
 *  minimization: have already a solution, try lowest cost
 *  case first
 */
    jval=-1;
  }  
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine evcmb1
 * 
 *  purpose: evaluates usefulness of combination of
 *           selected columns and places results into
 *           covtot if solunt did not determine
 *           unsatisfiability
 * 
 *   input: rhs4, rnbred, ribred, nunitres
 * 
 * 
 *  output: succss = 0  have satisfying solution when
 *                      all free columns values = -1
 *                 = 1  covtot contains evaluation of
 *                      combination
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void evcmb1() {
/*
 */
  static long i,ix,l;
/*
 */
  void error();
/*
 *  check if there is a satisfying solution when
 *  all free column values = -1
 */
  succss = 0;
  for (ix=1; ix<=rxlact_(rowmax+1); ix++) {
    i = rxlact_(ix);
    if ((rhs4_(i)==1)&&
        (rnared_(i)<=1)) {
      succss = 1;
    }
  }
  if (succss==0) {
/*
 *  have satisfying solution by assigning 
 *  all free columns values = -1
 */
    return;
  }
/*
 *  initialize covtot
 */
  covtot_(1) = nunitres;
  for(l=2; l<=covmax; l++)  {
    covtot_(l)=0;
  }
/*
 *  process each row
 */
  for (ix=1; ix<=rxlact_(rowmax+1); ix++) {
    i = rxlact_(ix);
    if ((rhs4_(i)==1)&&
        (rnared_(i)<=1)&&
        (ribred_(i)==1)) {
      l=rnbred_(i);
/*
 *  error if l <= 1
 */
      if (l<=1) {
        error(" evcmb1 ","  202   ");
      }
/*
 *  adjust l if it exceeds covmax
 */
      if (l>covmax) {
        l=covmax;
      }
/*
 *  increment count in covtot
 */
      covtot_(l)=covtot_(l)+1;
    }
  }
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine evcmb2
 * 
 *  purpose: evaluates usefulness of combination of
 *           selected columns and places results into
 *           covtot if solunt determined unsatisfiability
 * 
 *   input: none
 * 
 * 
 *  output: covtot
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void evcmb2() {
/*
 */
  static long l;
/*
 *  insert -1s into covtot
 */
  for(l=1; l<=covmax; l++)  {
    covtot_(l)=-1;
  }
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine evcmb3
 * 
 *  purpose: retains covtot results for combination
 *           of columns in covmat
 * 
 *   input: curcas, covtot
 * 
 * 
 *  output: updated covmat row indexed by curcas
 *          covrhs(curcas) = sum of entries of that
 *                           updated covmat row
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void evcmb3() {
/*
 */
  static long l;
/*
 *  retain covtot in covmat and nsatrow in nstrow
 */
  for(l=1; l<=covmax; l++)  {
    covmat_(curcas,l)=covtot_(l);
  }
  nstrow_(curcas) = nsatrow;
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine evlcol
 * 
 *  purpose: evaluates usefulness of fixed and not bound
 *           column jcol for detecting unsatisfiability
 *           jcol satisfies:
 *               bdcons(jcol) = 0
 *               cifix(jcol) /= 0
 *               jcol is nonzero
 * 
 *   input: rhs5, jcol
 * 
 * 
 *  output: covtot, succss
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void evlcol() {
/*
 */
  static long i,is,ix,l,nc[covmax];
  #define nc_(i)  nc[(i-1)]
/*
 */
  void error();
/*
 *  initialize
 */
  for(l=1; l<=covmax; l++)  {
    nc_(l)=0;
    covtot_(l)=0;
  }
  succss=0;
/*
 */
  for(ix=1; ix<=nzbmsc_(jcol); ix++)  {
    is=bmslcl_(ix+ptbmsc_(jcol));
    i=abs(is);
    if (rhs5_(i)==1) {
      l=rnbred_(i)-1;
      succss=1;
/*
 *  error if l <= 0
 */
      if (l<=0) {
        error("evlcol","202");
      }
/*
 *  adjust l if it exceeds covmax
 */
      if (l>covmax) {
        l=covmax;
      }
/*
 *  check sign of column entry
 */
      if (is==i) {
/*
 *  +1 entry in column jcol
 */
        covtot_(l)=covtot_(l)+1;
      } else {
/*
 *  -1 entry in column jcol
 */
        nc_(l)=nc_(l)+1;
      }
    }
  }
/*
 *  done if no row was processed
 */
  if (succss==0) {
    return;
  }
/*
 *  combine nc and covtot to final covtot
 */
  for(l=1; l<=covmax; l++)  {
    if (nc_(l)<=covtot_(l)) {
      covtot_(l)=covtot_(l)+2*nc_(l);
    } else {
      covtot_(l)=nc_(l)+2*covtot_(l);
    }
  }
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine evlunt
 * 
 *  purpose: used for optimization only:
 *           evaluates low bound lowbnd for current case
 *           using bdcons vector computed by solunt
 * 
 *  input: bdcons, solut2
 * 
 * 
 *  output: lowbnd
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void evlunt() {
/*
 */
  static long j;
/*
 */
  void cstprb();
/*
 *  define solut1 using solut2, bdcons, and default = -1
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
/*
 *  initialize solut1 using solut2
 */
    solut1_(j)=solut2_(j);
/*
 *  use bdcons value if nonzero
 */
    if (bdcons_(j)!=0) {
      solut1_(j)=bdcons_(j);
    } else {
      if (solut1_(j)==1) {
/*
 *  j is fixed and not bound column
 *  use default = -1
 */
        solut1_(j)=-1;
      }
/*
 *  solut1(j) = 2 is not possible since that case
 *  occurs only for sat2st. but here we have minsat
 *  and only satneg is possible
 */
    }
  }
/*
 *  compute total cost for solut1 vector
 */
  cstprb();
  lowbnd=prcost;
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine intbds
 * 
 *  purpose: initializes bdvalu, bdcase, cost1
 * 
 *   input: none
 * 
 * 
 *  output: bdvalu, bdcase, cost1
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void intbds() {
/*
 */
  static long j;
/*
 *  initialize count of bound variables
 */
  cxlbnd_(colmax+1)=0;
/*
 *  initialize bdvalu, bdcase
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
    bdvalu_(j)=0;
    bdcase_(j)=0;
  }
/*
 *  initialize total cost
 */
  cost1=tt31m1;
/*
 */
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine restbd
 * 
 *  purpose: restores bdcons, nconcl, nconfx
 * 
 *  input: bdsave, nsavec, nsavex
 * 
 * 
 *  output: bdcons, nconcl, nconfx
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void restbd() {
/*
 */
  static long j;
/*
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
    bdcons_(j)=bdsave_(j);
  }
/*
 */
  nconcl=nsavec;
  nconfx=nsavex;
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine retcov
 * 
 *  purpose: retains cover vector covtot computed
 *           by subroutine evlcol for column jcol in
 *           covmat and retains jcol in selcol
 * 
 *  input: covtot, jcol
 * 
 * 
 *  output: covmat, selcol
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void retcov() {
/*
 */
  static long k,k1,l,l1;
/*
 */
  for(k=1; k<=selmax; k++)  {
/*
 *  compute matrix entries
 */
    for(l=1; l<=covmax; l++)  {
      if (covtot_(l)<covmat_(k,l)) {
/*
 *  covtot vector is lexico-smaller than covmat row
 */
        goto zz100;
      }
      if (covtot_(l)>covmat_(k,l)) {
/*
 *  covtot vector is lexico-larger than covmat row
 *  shift all vectors from k down and retain covtot in
 *  row k
 */
        if (k<selmax) {
          for(k1=selmax-1; k1>=k; k1--)  {
            if (selcol_(k1)>0) {
              for(l1=1; l1<=covmax; l1++)  {
                covmat_(k1+1,l1)=covmat_(k1,l1);
              }
              selcol_(k1+1)=selcol_(k1);
            }
          }
        }
        for(l1=1; l1<=covmax; l1++)  {
          covmat_(k,l1)=covtot_(l1);
        }
        selcol_(k)=jcol;
        return;
      }
    }
  zz100:;}
  return;
}
/*eject*/
/*
 * *********************************************************
 *  subroutine satneg
 * 
 *  purpose: decides satisfiability of the cnf problem in
 *           layer 1 for clauses in rows i with rhs4(i) = 1,
 *           using columns j,  lcllmt .le. j .le. ucllmt.
 *           assumes nearly negative submatrix.
 * 
 *   input:
 *           - matrix of free columns and active rows i with
 *             rhs1(i) = 1 of block qblock in amslcl, amslrw
 *           - lcllmt, ucllmt
 *           - rposj, rnred
 *           - rxleqz, rxleq1, rxleq2, rxlcu1
 *           - solut1(j) = -1 if j free (j of block q).
 *                       = +/- 1 if j fixed.
 *                       =  0 if j inactive.
 *           - rhs4
 * 
 *  output:  succss = 1:  problem is satisfiable
 *                        using columns j,
 *                        lcllmt .le. j .le. ucllmt;
 *                        solut1(j) = solution value.
 *           succss = 0:  problem is not satisfiable
 *                        by columns j,
 *                        lcllmt .le. j .le. ucllmt
 * 
 *    caution:  changes are made to rnred, rxlcu1,
 *              solut1, rhs4
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where               what was changed/reason
 * ------------------------------------------------------
 * ********************************************************
 */
void satneg() {
/*
 */
  static long nx,i,j,ix,is,n,j1;
/*
 */
  nx=rxlcu1_(rowmax+1);
/*
 *  if no entry in rxlcu1, have solution
 */
  zz50:;
  if (nx==0) {
    succss=1;
    return;
  }
/*
 *  define i = last entry of rxlcu1
 */
  i=rxlcu1_(nx);
  nx=nx-1;
/*
 *  skip case if rhs4(i) = 0
 */
  if (rhs4_(i)==0) {
    goto zz50;
  }
/*
 *  define column j with the + 1 of row i
 */
  j=rposj_(i);
/*
 *  fix solut1(j) value to 1
 */
  solut1_(j)=1;
/*
 *  scan column j for all entries
 */
  for(ix=1; ix<=nzamsc_(j); ix++)  {
/*
 *  define signed row index is and row index i
 */
    is=amslcl_(ix+ptamsc_(j));
    i=abs(is);
/*
 *  skip case if rhs4(i) = 0
 */
    if (rhs4_(i)==0) {
      goto zz100;
    }
/*
 *  know rhs4(i) = 1
 *  if column j entry, in row i, is +1, change rhs4(i) to 0
 */
    if (is>0) {
      rhs4_(i)=0;
    } else {
/*
 *  know that rhs4(i) = 1 and that column j entry
 *  of row i is = -1
 *  reduce number of free column entries of row i
 */
      n=rnred_(i);
      n=n-1;
      rnred_(i)=n;
/*
 *  if new row count n is = 1 and rposj(i) > 0,
 *  then rposj(i) is the column index with that remaining
 *  row i entry.  in that case, store i in rxlcu1 list.
 */
      if (n==1) {
        j1=rposj_(i);
        if (j1>0) {
          nx=nx+1;
          rxlcu1_(nx)=i;
        }
      } else {
/*
 *  if new count = 0, problem is not satisfiable
 */
        if (n==0) {
          succss=0;
          return;
        }
      }
    }
  zz100:;}
  goto zz50;
}
/*eject*/
/*
 * *********************************************************
 *  subroutine sat2st
 * 
 *  purpose: decides satisfiability of the cnf problem in
 *           layer 1 for clauses in rows i with rhs4(i) = 1,
 *           using columns j, lcllmt .le. j .le. ucllmt.
 *           assumes 2sat submatrix.
 * 
 *   input:
 *           - matrix of free columns and active rows i with
 *             rhs1(i) = 1
 *             block qblock in amslcl, amslrw
 *           - lcllmt, ucllmt
 *           - ronej, aonej
 *           - rxleqz, rxleq1, rxleq2, rxlcu1
 *           - solut1(j) = 2 if j free (j of block q).
 *                       = +/- 1 if j fixed.
 *                       =  0 if j inactive.
 *           - rhs4
 * 
 *  output:  succss = 1:  problem is satisfiable
 *                        using columns j,
 *                        lcllmt .le. j .le. ucllmt;
 *                        solut1(j) = solution value.
 *           succss = 0:  problem is not satisfiable
 *                        by columns j,
 *                        lcllmt .le. j .le. ucllmt
 * 
 *    caution:  changes are made to ronej, rxlcu1,
 *              solut1, rhs4
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where               what was changed/reason
 * ------------------------------------------------------
 * 
 * ******************************************************
 * 
 */
void sat2st() {
/*
 */
  static long nxcu1,nxeq2,nxrhs,nxsol,tryflg;
  static long jtrys,jtry,aijtry;
  static long i,j,aij,ix,is,js1,j1,jx;
/*
 *  initialize index counters
 */
  nxcu1=rxlcu1_(rowmax+1);
  nxeq2=rxleq2_(rowmax+1);
/*
 *  initialize tryflg
 *    =1 : tentative process
 *    =2 : permanent process
 */
  tryflg=2;
/*eject*/
/*
 * -------------------------------------------------------
 *  step 1
 *  select a row with at most one entry in columns
 *  without solution value
 * -------------------------------------------------------
 * 
 *  if nxcu1 = 0, must process row with two nonzero entries
 */
  zz1000:;
  if (nxcu1==0) {
    goto zz4000;
  }
/*
 *  remove index i from rxlcu1
 */
  i=rxlcu1_(nxcu1);
  nxcu1=nxcu1-1;
/*
 *  if rhs4(i) = 0, skip case
 */
  if (rhs4_(i)==0) {
    goto zz1000;
  }
/*
 *  determine column j with nonzero entry in row i
 */
  j=ronej_(i);
/*
 *  if a value has already been assigned to variable j,
 *  have unsatisfiable case (tryflg = 2) or
 *  must start permanent process
 *  (tryflg = 1)
 */
  if (solut1_(j)!=2) {
    goto zz3000;
  }
/*
 *  determine nonzero entry in row i, column j
 */
  aij=aonej_(i);
/*
 *  assign solution value for variable j
 */
  solut1_(j)=aij;
/*
 *  record index j if tentative process
 */
  if (tryflg==1) {
    nxsol=nxsol+1;
    cxlsol_(nxsol)=j;
  }
/*eject*/
/*
 * ---------------------------------------------------------
 *  step 2
 *  process column j with the assigned solution value;
 *  know aij = solut1(j)
 * ---------------------------------------------------------
 * 
 */
  zz2000:;
  for(ix=1; ix<=nzamsc_(j); ix++)  {
    is=amslcl_(ix+ptamsc_(j));
    i=abs(is);
/*
 *  skip row i if rhs4(i) = 0
 */
    if (rhs4_(i)==0) {
      goto zz2100;
    }
/*
 *  know rhs4(i) = 1
 *  if column j entry in row i is equal to aij,
 *  change rhs4(i) to 0 and
 *  record index i if tentative process
 */
    if (aij*is>0) {
      rhs4_(i)=0;
      if (tryflg==1) {
        nxrhs=nxrhs+1;
        rxlrhs_(nxrhs)=i;
      }
    } else {
      if (nzamsr_(i)<=1) {
/*
 *  row i has no second nonzero, hence must be
 *  unsatisfiable case or must
 *  start permanent process
 */
        goto zz3000;
      }
/*
 *  know that row i has two nonzero entries
 *  find the one in the column j1 different from j
 */
      js1=amslrw_(1+ptamsr_(i));
      j1=abs(js1);
/*
 *  if j1 = j, must select second choice as j1
 */
      if (j1==j) {
        js1=amslrw_(2+ptamsr_(i));
        j1=abs(js1);
      }
/*
 *  if j1 has already a solution value assigned,
 *  have unsatisfiable case
 *  or must start permanent process
 */
      if (solut1_(j1)!=2) {
        goto zz3000;
      }
/*
 *  retain i, j1, and sign of js1 in rxlcu1, ronej, aonej
 */
      nxcu1=nxcu1+1;
      rxlcu1_(nxcu1)=i;
      ronej_(i)=j1;
      if (js1>0) {
        aonej_(i)=1;
      } else {
        aonej_(i)=-1;
      }
    }
  zz2100:;}
  goto zz1000;
/*eject*/
/*
 * ----------------------------------------------------------
 *  step 3
 *  declare unsatisfiable (tryflg = 2) or switch to
 *  permanent process
 *  (tryflg = 1)
 * ----------------------------------------------------------
 * 
 */
  zz3000:;
  if (tryflg==2) {
    succss=0;
    return;
  }
/*
 *  know tryflg = 1
 *  restore problem to point where the value of
 *  variable jtry was determined
 */
  if (nxrhs>0) {
    for(ix=1; ix<=nxrhs; ix++)  {
      rhs4_(rxlrhs_(ix))=1;
    }
  }
  if (nxsol>0) {
    for(jx=1; jx<=nxsol; jx++)  {
      solut1_(cxlsol_(jx))=2;
    }
  }
/*
 *  change solution value of variable jtry and
 *  initialize j, aij, nxcu1.
 *  note that the new aij is not the matrix entry, but is
 *  the solution value.
 */
  solut1_(jtry)=-aijtry;
  j=jtry;
  aij=-aijtry;
  nxcu1=0;
/*
 *  set tryflg = 2 to indicate permanent process
 */
  tryflg=2;
/*
 *  start processing of column j (=jtry)
 */
  goto zz2000;
/*eject*/
/*
 * ---------------------------------------------------------
 *  step 4
 *  know nxcu1 = 0; thus have situation where
 *  two nonzeros are in each
 *  row i with rhs4(i) = 1.
 * --------------------------------------------------------
 *  if there is no candidate row, have satisfiability.
 */
  zz4000:;
  if (nxeq2==0) {
/*
 *  complete assignment of values to solut1 vector
 */
    for(j=lcllmt; j<=ucllmt; j++)  {
      if (solut1_(j)==2) {
        solut1_(j)=-1;
      }
    }
    return;
  }
/*
 *  select candidate row
 */
  i=rxleq2_(nxeq2);
  nxeq2=nxeq2-1;
/*
 *  if rhs4(i) = 0, skip case
 */
  if (rhs4_(i)==0) {
    goto zz4000;
  }
/*
 *  start tentative decision process
 */
  nxrhs=0;
  nxsol=0;
  jtrys=amslrw_(1+ptamsr_(i));
  if (jtrys>0) {
    jtry=jtrys;
    aijtry=1;
  } else {
    jtry=-jtrys;
    aijtry=-1;
  }
/*
 *  assign tentative solution value to solut1 and initialize j, aij
 */
  solut1_(jtry)=aijtry;
  j=jtry;
  aij=aijtry;
/*
 *  set tryflg to indicate tentative process
 */
  tryflg=1;
/*
 *  process column j
 */
  goto zz2000;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine savebd
 * 
 *  purpose: saves bdcons, nconcl, nconfx
 * 
 *  input: bdcons, nconcl, nconfx
 * 
 *  output: bdsave, nsavec, nsavex
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void savebd() {
/*
 */
  static long j;
/*
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
    bdsave_(j)=bdcons_(j);
  }
/*
 */
  nsavec=nconcl;
  nsavex=nconfx;
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine solunt
 * 
 *  purpose: uses unit vector rows i with rhs4(i) = 1
 *           to bind variables j,
 *           lcllmt <= j <= ucllmt
 * 
 *  input: matrix in bmslcl, bmslrw
 *         bdcons(j) = 0 if is not initially bound
 *                   = +-1 if j initially bound to +-1
 *         given bdcons fixing:
 *           rnared(i)  reduced row counts for
 *                      submatrix a of free columns
 *           rnbred(i)  reduced row counts for
 *                      submatrix b of free/fixed columns
 *           ribred(i)  reduction index for row i, so far
 *                          = 1  row i count of submatrix b
 *                               was reduced (possibly also
 *                               satisfied)
 *                          = 0 was not reduced (possibly
 *                          satisfied)
 *           rxlbw1     row index list of b rows
 *                      with one nonzero entry
 *           rxlbwz     row index list of b rows
 *                      with all 0s
 *           rhs4       rhs vector
 *           nconcl     number of +-1s in bdcons vector
 *           nconfx     number of +-1s in bdcons vector and
 *                      with cifix(j)/=0
 *           nsatrow    number of rows satisfied by
 *                      jcol fixing
 * 
 *  output: sucss = 1  reduction completed, no obvious
 *                     unsatisfiability
 *                = 0  reduction stopped since obvious
 *                     unsatisfiability detected
 *          if succss = 1:
 *            bdcons(j) = 0 if j not bound
 *                      = +-1 if j bound initially or
 *                        due to unit vector rows
 *            given bdcons values:
 *              nunitres   number of unit resolution steps
 *              rnared(i)  reduced row count for
 *                         submatrix a of free columns
 *              rnbred(i)  reduced row count for
 *                         submatrix b of free/fixed columns
 *              ribred(i)  reduction index for row i
 *                          = 1  row i count of submatrix b
 *                               was reduced (possibly also
 *                               satisfied)
 *                          = 0 was not reduced (possibly
 *                          satisfied)
 *              rhs4       reduced rhs vector
 *              nconcl     number of +-1s in bdcons vector
 *              nconfx     number of +-1s in bdcons
 *                         vector and with cifix(j)/=0
 *              nsatrow    number of rows satisfied by
 *                         jcol fixing and unit resolution
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void solunt() {
/*
 */
  static long i,is,ix,j,js,jx,n;
/*
 */
  void error();
/*
 *  check for obvious infeasibility
 */
  if (rxlbwz_(rowmax+1)>0) {
    for(ix=1; ix<=rxlbwz_(rowmax+1); ix++)  {
      i=rxlbwz_(ix);
      if (rhs4_(i)==1) {
/*
 *  have obvious infeasibility
 */
        succss=0;
        return;
      }
    }
  }
/*
 *  initialize iteration count and number of 
 *  unit resolution steps
 */
  n=1;
  nunitres = 0;
/*
 *  begin of main loop
 */
  zz205:;
/*
 *  check if unit row exists
 */
  if (rxlbw1_(rowmax+1)==0) {
/*
 *  no further reduction possible
 */
    succss=1;
    return;
  }
/*
 *  remove last row i from index list rxlbw1
 */
  i=rxlbw1_(rxlbw1_(rowmax+1));
  rxlbw1_(rowmax+1)=rxlbw1_(rowmax+1)-1;
/*
 *  skip this case if rhs4(i) = 0
 */
  if (rhs4_(i)==0) {
    goto zz995;
  }
/*
 *  below have rhs4(i)=1
 * 
 *  find column j with nonzero in row i
 */
  if (nzbmsr_(i)==0) {
/*
 *  error, must have nonzero row in bms since i in rxlbw1
 */
    error(" solunt ","  202   ");
  }
  for(jx=1; jx<=nzbmsr_(i); jx++)  {
    js=bmslrw_(jx+ptbmsr_(i));
    j=abs(js);
/*
 *  check if column j is already bound
 */
    if (bdcons_(j)==0) {
/*
 *  have found the index j that is not bound
 */
      goto zz305;
    }
  }
/*
 *  error, must find index j in above loop
 */
  error(" solunt ","  302   ");
/*
 */
  zz305:;
/*
 *  increase unit resolution count
 */
  nunitres++;
/*
 *  bind column j to correct value
 */
  if (js>0) {
    bdcons_(j)=1;
  } else {
    bdcons_(j)=-1;
  }
  nconcl=nconcl+1;
  if (cifix_(j)!=0) {
    nconfx=nconfx+1;
  }
/*
 *  scan column j entries
 */
  if (nzbmsc_(j)==0) {
/*
 *  error, column j must be nonzero
 */
    error(" solunt ","  402   ");
  }
  for(ix=1; ix<=nzbmsc_(j); ix++)  {
    is=bmslcl_(ix+ptbmsc_(j));
    i=abs(is);
/*
 *  update rnbred(i), rnared(i), rxlbw1, rxlbwz
 */
    rnbred_(i)=rnbred_(i)-1;
    if (cifre_(j)!=0) {
      rnared_(i)=rnared_(i)-1;
    }
    if (rnbred_(i)==0) {
      rxlbwz_(rowmax+1)=rxlbwz_(rowmax+1)+1;
      rxlbwz_(rxlbwz_(rowmax+1))=i;
    } else {
      if (rnbred_(i)==1) {
        rxlbw1_(rowmax+1)=rxlbw1_(rowmax+1)+1;
        rxlbw1_(rxlbw1_(rowmax+1))=i;
      }
    }
/*
 *  reduce rhs4(i) if applicable
 *  update ribred
 */
    if (rhs4_(i)==1) {
      if (bdcons_(j)*is>0) {
        rhs4_(i)=0;
        nsatrow++;
      } else {
/*
 *  have rhs4(i)=1 and row i is not satisfied by column j
 */
        ribred_(i) = 1;
        if (rnbred_(i)==0) {
/*
 *  row i cannot be satisfied at all
 */
          succss=0;
          return;
        }
      }
    }
  }
/*
 */
  zz995:;
  if (n==rowmax) {
/*
 *  error, too many iterations
 */
    error(" solunt "," 1002   ");
  }
  n=n+1;
  goto zz205;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine stcomb
 * 
 *  purpose: set up nslcol, nslcas, and covmat
 *           for selection of combination of columns
 *           selcol(1) and selcol(2) must be > 0
 * 
 *  input: selcol
 * 
 *  output: nslcol, nslcas, and covmat
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where              what was changed/reason
 * -------------------------------------------------------
 * 
 * *******************************************************
 */
void stcomb() {
/*
 */
  static long i,k,l;
/*
 */
  void error();
/*
 *  test for entry condition
 */
  if ((selcol_(1)<=0)||
      (selcol_(2)<=0)) {
    error(" stcomb ","  102   ");
  }
/*
 *  compute nslcol, nslcas
 */
  nslcol=0;
  for(k=1; k<=selmax; k++)  {
    if (selcol_(k)==0) {
      goto zz105;
    }
    nslcol=nslcol+1;
  }
/*
 */
  zz105:;
  nslcas=2*nslcol;
/*
 *  set up covmat
 */
  for(i=1; i<=nslcas; i++)  {
    for(l=1; l<=covmax; l++)  {
      covmat_(i,l)=0;
    }
  }
  return;
}
/*eject*/
/*
 * ********************************************************
 * subroutine stefx1
 * 
 * purpose: set up for enufix, part 1:
 *          lcllmt, ucllmt, lrwlmt, urwlmt
 *          amslcl, amslrw, bmslcl, bmslrw, rposj
 *          solut2
 *          cxlfix
 *          if nblks > 1: rhs2
 * *********************************************************
 * 
 */
void stefx1() {
/*
 */
  static long q,i,is,ix,j,jx;
/*
 */
  q=qblock;
/*
 * set up column and row limits for block q
 */
  lcllmt=lcllim_(q);
  ucllmt=ucllim_(q);
  lrwlmt=lrwlim_(q);
  urwlmt=urwlim_(q);
/*
 * initialize row counts and pointers
 */
  for(i=1; i<=nrows; i++)  {
    nzamsr_(i)=0;
    rposj_(i)=0;
    ptamsr_(i)=ptablr_(i);
    nzbmsr_(i)=0;
    ptbmsr_(i)=ptablr_(i);
  }
/*
 * insert strip q matrix into ams and bms arrays
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
/*
 *  free column of strip q into ams
 */
    ptamsc_(j)=ptablc_(j);
    if ((cifre_(j)!=0)&&
        (nzablc_(j)>0)) {
      nzamsc_(j)=nzablc_(j);
      for(ix=1; ix<=nzablc_(j); ix++)  {
        is=ablkcl_(ix+ptablc_(j));
        i=abs(is);
        amslcl_(ix+ptamsc_(j))=is;
        nzamsr_(i)=nzamsr_(i)+1;
        if (is>0) {
          amslrw_(nzamsr_(i)+ptamsr_(i))=j;
          rposj_(i)=j;
        } else {
          amslrw_(nzamsr_(i)+ptamsr_(i))=-j;
        }
      }
    } else {
      nzamsc_(j)=0;
    }
/*
 *  free and fixed column of strip q into bms array
 */
    ptbmsc_(j)=ptablc_(j);
    if (nzablc_(j)>0) {
      nzbmsc_(j)=nzablc_(j);
      for(ix=1; ix<=nzablc_(j); ix++)  {
        is=ablkcl_(ix+ptablc_(j));
        i=abs(is);
        bmslcl_(ix+ptbmsc_(j))=is;
        nzbmsr_(i)=nzbmsr_(i)+1;
        if (is>0) {
          bmslrw_(nzbmsr_(i)+ptbmsr_(i))=j;
        } else {
          bmslrw_(nzbmsr_(i)+ptbmsr_(i))=-j;
        }
      }
    } else {
      nzbmsc_(j)=0;
    }
/*
 */
  }
/*
 * if nblks > 1, set up rhs2 = rhs1 minus inactive rows and
 * minus rows not indexed by q. first rows indexed by q.
 */
  if (nblks>1) {
    for(i=lrwlmt; i<=urwlmt; i++)  {
      rhs2_(i)=rhs1_(i);
    }
/*
 * second, zero out rhs2 in rows not indexed by q
 */
    if (q>1) {
      for(i=1; i<=lrwlmt-1; i++)  {
        rhs2_(i)=0;
      }
    }
    if (q<nblks) {
      for(i=urwlmt+1; i<=nrows; i++)  {
        rhs2_(i)=0;
      }
    }
  }
/*
 * initialize solut2 vector for block q columns.
 * solut2(j) = -1 if column j free in block q
 *                   and satneg case
 *           =  2 if column j free in block q
 *                   and sat2st case
 *           =  1 if column j fixed in block q
 *                   and column j nonzero
 *           = -1 if column j fixed in block q
 *                   and column j zero
 *                (due to inactive rows inducing
 *                 a reduced problem)
 *                this handles the case of optimization
 *                correctly since cost is nonnegative
 *                and is zero for false
 *           =  0 else
 * initialize cxlfix = list of fixed columns in strip q
 *                     in reverse order
 */
  jx=0;
  for(j=ucllmt; j>=lcllmt; j--)  {
    if (cifre_(j)==1) {
      if (twosat_(q)==0) {
        solut2_(j)=-1;
      } else {
        solut2_(j)=2;
      }
    } else {
      if (cifix_(j)!=0) {
        if (nzablc_(j)>0) {
          solut2_(j)=1;
          jx=jx+1;
          cxlfix_(jx)=j;
        } else {
          solut2_(j)=-1;
        }
      } else {
        solut2_(j)=0;
      }
    }
  }
  cxlfix_(colmax+1)=jx;
  return;
}
/*eject*/
/*
 * ******************************************************
 *  subroutine stefx2
 * 
 *  purpose:  set up for enufix;  part 2:
 *            rhs3
 *            rxleqz, rxleq1
 *            if twosat(q) = 1:  rxleq2
 *            initialize rhs4 and rhs5 to 0
 * 
 * ******************************************************
 * 
 */
void stefx2() {
/*
 */
  static long q,i,ix,iz,ixx,n1;
/*
 */
  q=qblock;
/*
 *  calculate rhs3 vector
 */
  if (nblks>1) {
/*
 *  prepare rhs3 vector
 */
    for(i=1; i<=nrows; i++)  {
      rhs3_(i)=rhs2_(i);
    }
/*
 *  if q. gt. 1, insert e1|2 range vector into rhs3
 */
    if ((q>1)&&
        (nzer_(er1,q-1)>0)) {
      for(ix=1; ix<=nzer_(er1,q-1); ix++)  {
        i=abs(erange_(ix+pter_(er1,q-1),q-1));
        i=i-(i/tt14)*tt14;
        rhs3_(i)=1;
      }
    }
/*
 *  if q .lt. nblks, insert d2|1 range vector into rhs3
 */
    if ((q<nblks)&&
        (nzdr_(dr,q)>0)) {
      for(ix=1; ix<=nzdr_(dr,q); ix++)  {
        i=abs(drange_(ix+ptdr_(dr,q),q));
        i=i-(i/tt14)*tt14;
        rhs3_(i)=1;
      }
    }
/*
 *  if q .lt. nblks, subtract e2/3 range vector from rhs3
 */
    if ((q<nblks)&&
        (nzer_(er,q)>0)) {
      for(ix=1; ix<=nzer_(er,q); ix++)  {
        i=abs(erange_(ix+pter_(er,q),q));
        i=i-(i/tt14)*tt14;
        rhs3_(i)=0;
      }
    }
/*
 *  if q .gt. 1, subtract d3/2 range vector from rhs3
 */
    if ((q>1)&&
        (nzdr_(dr1,q-1)>0)) {
      for(ix=1; ix<=nzdr_(dr1,q-1); ix++)  {
        i=abs(drange_(ix+ptdr_(dr1,q-1),q-1));
        i=i-(i/tt14)*tt14;
        rhs3_(i)=0;
      }
    }
/*
 *  for inactive rows i, set rhs3(i) = 0
 */
    for(i=1; i<=nrows; i++)  {
      if (riina_(i)!=0) {
        rhs3_(i)=0;
      }
    }
  } else {
/*
 *  case of just one block
 */
    for(i=1; i<=nrows; i++)  {
      if (riina_(i)!=0) {
        rhs3_(i)=0;
      } else {
        rhs3_(i)=rhs1_(i);
      }
    }
  }
/*
 *  compute rxleqz, rxleq1, rxleq2
 *  initialize rxlact list for rhs3(i) = 1 indices
 */
  iz=0;
  ix=0;
  ixx=0;
  rxlact_(rowmax+1) = 0;
  for(i=1; i<=nrows; i++)  {
    if (rhs3_(i)==1) {
      rxlact_(rowmax+1)++;
      rxlact_(rxlact_(rowmax+1)) = i;
      n1=nzamsr_(i);
      if (n1==0) {
        iz=iz+1;
        rxleqz_(iz)=i;
      } else {
        if (n1==1) {
          if ((twosat_(q)==0)&&
              (rposj_(i)==0)) {
            goto zz300;
          }
          ix=ix+1;
          rxleq1_(ix)=i;
        } else {
          if ((twosat_(q)==1)&&
              (n1==2)) {
            ixx=ixx+1;
            rxleq2_(ixx)=i;
          }
        }
      }
    }
  zz300:;}
  rxleqz_(rowmax+1)=iz;
  rxleq1_(rowmax+1)=ix;
  rxleq2_(rowmax+1)=ixx;
/*
 *  initialize rhs4 and rhs5 to 0
 */
  for(i=1; i<=nrows; i++)  {
    rhs4_(i) = 0;
    rhs5_(i) = 0;
  }  
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stsat1
 * 
 *  purpose:  set up for satneg or sat2st, part 1
 *            solut1
 *            rhs4
 *            rnred
 * 
 * *****************************************************
 * 
 */
void stsat1() {
/*
 */
  static long j,i,ix;
/*
 *  initialize solut1 to solut2
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
    solut1_(j)=solut2_(j);
  }
/*
 *  initialize rhs4 to rhs3, and rnred to nzamsr
 */
  for (ix=1; ix<=rxlact_(rowmax+1); ix++) {
    i = rxlact_(ix);
    rhs4_(i)=rhs3_(i);
    rnred_(i)=nzamsr_(i);
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stsat2
 * 
 *  purpose:  set up for satneg or sat2st, part 2
 *            update solut1, rhs4 using for fixed columns
 *            bdcons or default = -1
 * 
 * *****************************************************
 * 
 */
void stsat2() {
/*
 */
  static long i,is,ix,j,jx;
/*
 *  update solut1
 */
  for(jx=1; jx<=cxlfix_(colmax+1); jx++)  {
    j=cxlfix_(jx);
/*
 *  update solut1 using bdcons or default = -1
 */
    if (bdcons_(j)!=0) {
      solut1_(j)=bdcons_(j);
    } else {
      solut1_(j)=-1;
    }
/*
 *  update rhs4
 */
    for(ix=1; ix<=nzbmsc_(j); ix++)  {
      is=bmslcl_(ix+ptbmsc_(j));
      if ((solut1_(j)*is)>0) {
        i=abs(is);
        rhs4_(i)=0;
      }
    }
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stsat3
 * 
 *  purpose:  set up for satneg or sat2st, part 3
 *            rxlcu1
 *            first check for obvious infeasibility
 *            using rxleqz
 * 
 * *****************************************************
 * 
 */
void stsat3() {
/*
 */
  static long i,js,ix;
/*
 */
  if (rxleqz_(rowmax+1)>0) {
/*
 *  check if problem is obviously infeasible
 */
    for(ix=1; ix<=rxleqz_(rowmax+1); ix++)  {
      if (rhs4_(rxleqz_(ix))==1) {
/*
 *  matrix has zero row i and rhs4(i) = 1; thus problem is infeasible
 */
        succss=0;
        return;
      }
    }
  }
/*
 *  problem is not obviously infeasible
 */
  succss=1;
/*
 *  initialize rxlcu1 to rxleq1
 */
  rxlcu1_(rowmax+1)=rxleq1_(rowmax+1);
  if (rxleq1_(rowmax+1)>0) {
    for(ix=1; ix<=rxleq1_(rowmax+1); ix++)  {
      rxlcu1_(ix)=rxleq1_(ix);
    }
/*
 *  if sat2st case, initialize ronej(i) and 
 *  aonej(i) for rows i of rxleq1
 */
    if (twosat_(qblock)==1) {
      for(ix=1; ix<=rxleq1_(rowmax+1); ix++)  {
        i=rxleq1_(ix);
        js=amslrw_(1+ptamsr_(i));
        if (js>0) {
          ronej_(i)=js;
          aonej_(i)=1;
        } else {
          ronej_(i)=-js;
          aonej_(i)=-1;
        }
      }
    }
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stscas
 * 
 *  purpose: compute table selcas for value combinations
 *
 *  caution: for any column k of selcas:
 *           the combinations involving column k
 *           must be exhaustive. thus, if all satisfiable
 *           cases where k is specified involve only one
 *           value for k, then k can be uniquely fixed to
 *           that value (see tstunq) 
 * *****************************************************
 * 
 */
void stscas() {
/*
 */
  static long i,k;
/*
 */
  void error();
/*
 *  row i = case
 *  col k = variable k
 * 
 */
  for (k=1; k<=selmax; k++) {
    for (i=1; i<=scsmax; i++) {
      selcas_(i,k) = 0;
    }
  }
/*
 */
  for (k=1; k<=selmax; k++) {
    selcas_((k-1)*2+1,k) = 1;
    selcas_((k-1)*2+2,k) = -1;
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stsel1
 * 
 *  purpose: set up rhs5 for evaluation of
 *           fixed and not bound columns
 *           set evalsubflg = 1 if subproblem has
 *           at least 2 entries in each row
 *  note:    rhs5=0 vector means that the
 *           free columns with value = -1 satisfy
 *           all clauses that must still be covered          
 * 
 * *****************************************************
 * 
 */
void stsel1() {
/*
 */
  static long i, ix;
/*
 */
  evalsubflg = 1;
  for (ix=1; ix<=rxlact_(rowmax+1); ix++) {
    i = rxlact_(ix);
    if ((rhs4_(i)==1)&&
        (rnared_(i)<=1)) {
      rhs5_(i)=1;
      evalsubflg = 0;
    } else {
      rhs5_(i)=0;
    }
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stsel2
 * 
 *  purpose: set up covmat and selcol for selection
 *           of at most selmax columns
 * 
 * *****************************************************
 * 
 */
void stsel2() {
/*
 */
  static long k,l;
/*
 */
  for(k=1; k<=selmax; k++)  {
    for(l=1; l<=covmax; l++)  {
      covmat_(k,l)=0;
    }
    selcol_(k)=0;
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stunt1
 * 
 *  purpose:  set up for solunt, part 1:
 *            bdcons
 *            nconcl
 *            nconfx
 * 
 * *****************************************************
 * 
 */
void stunt1() {
/*
 */
  static long j;
/*
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
    bdcons_(j)=bdvalu_(j);
  }
  nconcl=cxlbnd_(colmax+1);
  nconfx=nconcl;
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stunt2
 * 
 *  purpose:  set up for solunt, part 2:
 *            update bdcons for combination evaluation
 * 
 *  input:    bdcons
 *            curcas
 *            nslcol
 *            selcol
 * 
 *  output:  updated bdcons
 * 
 * *****************************************************
 * 
 */
void stunt2() {
/*
 */
  static long j,k;
/*
 */
  void error();
/*
 */
  for(k=1; k<=nslcol; k++)  {
    j=selcol_(k);
    if (bdcons_(j)!=0) {
/*
 *  error, since column j is currently fixed but not bound
 */
      error(" stunt2 ","  102   ");
    }
    bdcons_(j)=selcas_(curcas,k);
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine stunt3
 * 
 *  purpose:  set up for solunt, part 3:
 *            rhs4
 *            rnared
 *            rnbred
 *            ribred
 *            rxlbw1
 *            rxlbwz
 *            nsatrow
 * 
 * *****************************************************
 * 
 */
void stunt3() {
/*
 */
  static long i,is,ix,j;
/*
 */
  void error();
/*
 *  initialize rhs4 to rhs3, rnared, rnbred
 */
  for (ix=1; ix<=rxlact_(rowmax+1); ix++) {
    i = rxlact_(ix);
    rhs4_(i)=rhs3_(i);
    rnared_(i)=nzamsr_(i);
    rnbred_(i)=nzbmsr_(i);
    ribred_(i)=0;
  }
/*
 *  if curcas > 0, identify the variable jcol 
 *  set for curcas value
 */
  if (curcas > 0) {
    jcol = selcol_((curcas+1)/2);
/*
 *  compute number of rows satisfied by jcol
 *  using the current value
 */
    nsatrow = 0;
    for(ix=1; ix<=nzbmsc_(jcol); ix++)  {
      is=bmslcl_(ix+ptbmsc_(jcol));
      i=abs(is);
      if ((bdcons_(jcol)*is>0)&&
          (rhs4_(i)==1)) {
        nsatrow++;
      }
    }
  }
/*
 *  reduce rhs4 and update rnared, rnbred
 *  using bdcons values
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
    if (bdcons_(j)!=0) {
      if (nzbmsc_(j)==0) {
/*
 *  error, column must be nonzero
 */
        error(" stunt3 ","  202   ");
      }
      for(ix=1; ix<=nzbmsc_(j); ix++)  {
        is=bmslcl_(ix+ptbmsc_(j));
        i=abs(is);
/*
 *  update rhs4
 */
        if (bdcons_(j)*is>0) {
          rhs4_(i)=0;
        } else {
          if ((curcas > 0) &&
              (j==jcol)) {
            ribred_(i) = 1;
          }
        }
/*
 *  update rnared
 */
        if (cifre_(j)!=0) {
          rnared_(i)=rnared_(i)-1;
        }
/*
 *  update rnbred
 */
        rnbred_(i)=rnbred_(i)-1;
      }
    }
  }
/*
 *  initialize rxlbw1, rxlbwz using rnbred
 */
  rxlbw1_(rowmax+1)=0;
  rxlbwz_(rowmax+1)=0;
/*
 */
  for (ix=1; ix<=rxlact_(rowmax+1); ix++) {
    i = rxlact_(ix);
    if (rnbred_(i)==1) {
      rxlbw1_(rowmax+1)=rxlbw1_(rowmax+1)+1;
      rxlbw1_(rxlbw1_(rowmax+1))=i;
    } else {
      if (rnbred_(i)==0) {
        rxlbwz_(rowmax+1)=rxlbwz_(rowmax+1)+1;
        rxlbwz_(rxlbwz_(rowmax+1))=i;
      }
    }
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine tstunq
 * 
 *  purpose:  test for unsatisfiability and
 *            unique binding
 * 
 *  input:    covmat
 * 
 *  output:   jcol, jval, succss
 *            sucss = 0: unsatisfiable
 *                  = 1: not obviously unsatisfiable
 *            if succss = 1:
 *              jcol > 0: column jcol can be bound to
 *                        to unique value jval
 *              jcol = 0: no column can be bound
 *                        to unique value; also have jval=0
 * *****************************************************
 * 
 */
void tstunq() {
/*
 */
  static long k,pflg,nflg;
/*
 *  process each column
 */
  for(k=1; k<=nslcol; k++)  {
    if (covmat_((k-1)*2+1,1)==-1) {
      pflg = 0;
    } else {
      pflg = 1;
    }
    if (covmat_((k-1)*2+2,1)==-1) {
      nflg = 0;
    } else {
      nflg = 1;
    }
/*
 */
    if ((pflg==0)&&
        (nflg==0)) {
/*
 *  have unsatisfiability
 */
      succss=0;
      return;
    }
/*
 */
    if (pflg!=nflg) {
/*
 *  have unique binding
 */
      jcol=selcol_(k);
      if (pflg==1) {
        jval=1;
      } else {
        jval=-1;
      }
      succss=1;
      return;
    }
  }
/*
 *  no unsatisfiability, no unique binding
 */
  succss=1;
  jcol=0;
  jval=0;
  return;
}
/*  last record of exsolv.c****** */
