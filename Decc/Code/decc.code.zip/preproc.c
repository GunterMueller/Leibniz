/*  first record of preproc.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();
/*
 * ****************************************************
 *  module preprocessing
 * 
 *  purpose: preprocesses input problem.
 *           looks for monotone columns, declares them 
 *           as internal atf variables. 
 *           looks for clauses with one
 *           variable and without delete option.  
 *           such variables effectively may take on only
 *           one value. 
 *           uses this fact to reduce the matrix.  
 *           a second reduction uses 2sat
 *           clauses to eliminate certain entries in the matrix.
 *           the artificial variable and row (names  = '*') 
 *           are placed into block 1, together with other 
 *           variables and rows that require no or almost 
 *           no checking for satisfiability.
 *           remaining variables and rows are placed into block 2.
 * 
 *  input:   problem in layer 1, with correct indices and counts.
 *           all rows must be active, and all columns free.
 *           arrays assumed defined:
 *            - matrix data amatcl, amatrw
 *            - ncols, nrows, nblks (nblks = 1 required)
 *            - colnam, rownam
 *            - scale
 *            - cost, optimz
 *            - selpgv = 0: analyze problem only for problem
 *                          decomposition into independent
 *                          problems
 *                     = 1: elimination routines are skipped
 *                     >=2: elimination routines are applied
 *  output:  if succss = 1:
 *           preprocessed input problem, and atf part in layer 5
 *            - reduced amatcl, amatrw
 *            - ncols, nrows, each increased by 1
 *            - properly adjusted column and row counts
 *            - nblks = 2, with nontrivial part of problem 
 *              in block 2, or
 *              nblks = 1, in which case problem has become 
 *              trivial
 *            - the revised problem has precisely the same 
 *              behavior as the original one, including 
 *              behavior under variable fixing/deletion and 
 *              row deletion
 *            if succss = 0:
 *            input problem is not satisfiable when all clauses
 *            must be satisfied.  layer 1 contains input problem.
 * 
 *  calling sequence:
 *    prep
 *      monotn
 *      initpp
 *      elim1
 *      delcol
 *      delrow
 *      elim2
 *      uprxls
 *      reshuf (of module component)
 *      disprd
 *      sepblk
 *        bfs
 *        reshuf (of module component)
 * 
 *  caution: module must be called immediately after getcnf, 
 *           and prior to any decomposition or find-algorithm 
 *           steps.  
 *           in particular, problem cannot have been reshuffled, 
 *           i.e, we must have
 *           for all i: idxrow(i) = i
 *           for all j: ifxcol(j) = j
 *           also, the artificial variable and row must be last,
 *           with column index ncols and row index nrows.
 *           no test is made for these conditions.
 * 
 *           reduced problem may have columns containing only 
 *           zeros
 * 
 *           delete row option values and delete column values 
 *           cannot be changed after the preprocessing step 
 *           since the matrix may have been modified, and since 
 *           atf variables may have been introduced.
 * 
 *           uses layers 2, 3, and 4 for intermediate storage.
 *           places atf part of problem into layer  5
 * *********************************************************
 * 
 * 
 * *********************************************************
 *  subroutine prep
 * 
 *  purpose: preprocesses input problem.
 * 
 *  input and output: as specified in module summary.
 * 
 *  caution: uses layers 2, 3, and 4 for intermediate storage.
 *           places atf part of problem into layer 5
 * *********************************************************
 * 
 */
void prep() {
/*
 */
  void count();
  void disprd();
  void elim1();
  void elim2();
  void initpp();
  void monotn();
  void reshuf();
  void sepblk();
  void tranpr();
  void xatf();
  void xnoatf();
/*
 */
  static long i,j,q;
/*
 *  if selpgv eq 0, just decompose, no special structure analysis
 */
/*  if (selpgv==0) { Replaced by code below, March 8, 2008 */
  if ((selpgv==0) || (selpgv == 10)) {
/*
 *  save problem in layer 2
 */
    tranpr(c1,c2);
/*
 *  initialize two blocks and index lists (will not be used)
 */
    initpp();
/*
 *  look for decomposition
 */
    goto zz550;
  }

#ifdef LOGIC
/*
 *  have generate command since selpgv gt 0
 *  declare non-atf monotone columns as atf columns and 
 *  declare delete row option for all rows with any coefficient 
 *  in any atf column
 */
  monotn();
/*
 *  save problem in layer 2
 */
  tranpr(c1,c2);
/*
 *  if there is an atf part of problem,
 *  extract atf part of matrix and place into layer 5
 */
  if (flgatf!=0) {
/*
 *  extract atf part of problem
 */
    xatf();

/*
 *  transfer atf part from layer 1 to layer 5
 */
    tranpr(c1,c5);
/*
 *  restore input problem
 */
    tranpr(c2,c1);
/*
 *  extract non-atf part of problem
 */
    xnoatf();
  }
#endif

/*
 *  introduce two blocks, and initialize rxleq1, rxleq2 lists
 */
  initpp();
/*
 *  if nblks=1, skip rest of preprocessing
 */
  if (nblks==1) {
    goto zz760;
  }
/*
 *  from now on          block 1: one entry per row; incl. artificial
 *  have two blocks               variable and row, and 0 cols, rows
 *                       block 2: reduced problem; requires further
 *                                analysis and possibly decomposition
 */
#ifdef LOGIC
/*
 *  check for infeasibility due to 0 rows without delete row option
 */
  for(i=1; i<=nrows; i++)  {
    if ((nzamar_(i)==0)&&
        (dlrwop_(i)==0)) {
/*
 *  problem is infeasible. restore layer 2 problem to layer 1, set
 *  succss = 0, and return. note: layer 2 problem is not necessarily
 *  input problem since monotn may have declared cvatf(j) = +/-2
 *  for some columns j
 */
      tranpr(c2,c1);
      succss=0;
      return;
    }
  }
#endif

/*
 *  if selpgv le 1, skip elimination routines
 */
  if (selpgv<=1) {
    goto zz550;
  }

#ifdef LOGIC
/*
 *  iterative reduction procedure begins here
 * 
 */
  zz350:;
  if (rxleq1_(rowmax+1)>0) {
/*
 *  process next row with exactly one nonzero entry and without
 *  delete row option. subroutine elim1 may enlarge rxleq1, rxleq2 lists
 */
    elim1();
/*
 *  if succss = 0, then infeasibility has been detected. restore
 *  input problem from layer 2 and return.
 */
    if (succss==0) {
      tranpr(c2,c1);
      return;
    }
    goto zz350;
  }
  if (rxleq2_(rowmax+1)>0) {
/*
 *  process next 2sat row without delete row option. subroutine elim2
 *  may enlarge rxleq1, rxleq2 lists
 */
    elim2();
    goto zz350;
  }
/*
 *  done with preprocessing.  check whether there is a nonempty block 2
 */
#endif

  zz550:;
  for(i=1; i<=nrows; i++)  {
    if (riblk_(i)==2) {
/*
 *  there is a row in block 2.  must also have a column in block 2, but
 *  check for this
 */
      for(j=1; j<=ncols; j++)  {
        if (ciblk_(j)==2) {
/*
 *  there is such a column in block 2. rearrange matrix using reshuf
 */
          reshuf();
          goto zz750;
        }
      }
/*
 *  programming error
 */
      error("  prep  ","   612  ");
    }
  }
/*
 *  there is no row in block 2. cannot have any column in block 2, but
 *  check for this
 */
  for(j=1; j<=ncols; j++)  {
    if (ciblk_(j)==2) {
      error("  prep  ","   622  ");
    }
  }
/*
 *  reset nblks to 1 and recompute block limits using reshuf
 */
  nblks=1;
  reshuf();
/*
 *  compute correct counts
 */
  zz750:;
  count();
  if (accflg==1) {
/*
 *  display reductions
 */
    disprd();
  }
/*
 *  find connected subproblems of block 2, and subdivide that block
 *  correspondingly into appropriate blocks
 */
  if (nblks==2) {
    sepblk();
  }

#ifdef LOGIC
/*
 *  set twosat flags and bdfxbl, logrge values for all blocks
 *  block 1 is known to be nearly negative and to have 2sat form.
 *  though block 1 has 2sat form, cannot assign twosat(1)=1 since
 *  we may combine nearly negative blocks with block 1 in subroutine
 *  combng (module problem algorithms/decomposition)
 */
  zz760:;
  twosat_(1)=0;
  bdfxbl_(1)=0;
  logrge_(1)=0;
#endif

#ifdef MATRIX
/*
 *  set twosat flags and bdfxbl, logrge values for all blocks
 *  selpgv = 0: have twosat_(q) = -1, leave unchanged
 *  selpgv > 0: block 1 is known to have 2sat form.
 *              assign twosat(1)=1 
 */
  zz760:;
  if (selpgv > 0) {
    twosat_(1)=1;
  }
  bdfxbl_(1)=0;
  logrge_(1)=0;
#endif

/*
 *  remaining blocks must still be evaluated for solution algorithms
 */
  if (nblks>1) {
    for(q=2; q<=nblks; q++)  {
      twosat_(q)=-1;
      bdfxbl_(q)=0;
      logrge_(q)=0;
    }
  }
/*
 *  set flag that range data do not exist
 */
  flgrge=-1;
  succss=1;
  return;
}
/*
 * ***************************************************
 *  subroutine bfs
 * 
 *  purpose:  computes shortes routes from given set of column nodes
 *            in cdis to all other nodes by breadth-first-search
 * 
 *   input:   as specified in module summary, plus:
 *              cdis
 * 
 *  output:   solut1(j) = distance from cdis nodes to column node j
 *            rhs1(i)   = distance from cdis nodes to row node i
 *            distance  = tt15m1 (=2**15-1) implies that a node
 *                        cannot be reached from cdis nodes.
 * 
 *  caution:  cdis, rdis lists are extended.
 * 
 * *****************************************************
 * 
 */
void bfs() {
/*
 */
  static long cp1,cp2,dst,i,ix,j,jx,r1,r2;
/*
 *  initialize solut1 vector: value for column j is 0 if j is a source
 *  node, and tt15m1 otherwise.
 */
  for(j=1; j<=ncols; j++)  {
    solut1_(j)=tt15m1;
  }
  for(jx=1; jx<=cdis_(colmax+1); jx++)  {
    j=cdis_(jx);
    solut1_(j)=0;
  }
/*
 *  initialize rhs1 vector entries
 */
  for(i=1; i<=nrows; i++)  {
    rhs1_(i)=tt15m1;
  }
/*
 *  initialize pointers
 */
  cp1=1;
  cp2=cdis_(colmax+1);
  r1=1;
  r2=0;
  dst=1;
/*
 *  do bfs (breadth-first-search) pass
 */
  zz50:;
  for(jx=cp1; jx<=cp2; jx++)  {
    j=cdis_(jx);
    if (nzamac_(j)>0) {
/*
 *  process rows with entry in column j
 */
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=abs(amatcl_(ix+ptamac_(j)));
/*
 *  check if row i has already been encountered
 */
        if (rhs1_(i)==tt15m1) {
/*
 *  row i has not yet been processed.  do it now.
 */
          rhs1_(i)=dst;
          r2=r2+1;
          rdis_(r2)=i;
        }
      }
    }
  }
/*
 *  if no row node was added to rdis list, then done
 */
  if (r1>r2) {
    return;
  }
/*
 *  at least one row node was added.  do second part of bfs pass
 */
  cp1=cp2+1;
  cp2=cp1-1;
  dst=dst+1;
  for(ix=r1; ix<=r2; ix++)  {
    i=rdis_(ix);
    if (nzamar_(i)>0) {
/*
 *  process columns with entry in row i
 */
      for(jx=1; jx<=nzamar_(i); jx++)  {
        j=abs(amatrw_(jx+ptamar_(i)));
/*
 *  check if column j has already been encountered
 */
        if (solut1_(j)==tt15m1) {
          solut1_(j)=dst;
          cp2=cp2+1;
          cdis_(cp2)=j;
        }
      }
    }
  }
/*
 *  if no column nodes were added to list, then done
 */
  if (cp1>cp2) {
    return;
  }
/*
 *  start next bfs pass
 */
  r1=r2+1;
  r2=r1-1;
  dst=dst+1;
  goto zz50;
}
/*
 * ******************************************************
 *  subroutine delcol
 * 
 *  purpose:  deletes the element in row iscan and column jscan stored in
 *            amatcl.  does not adjust cnxxxx or change amatrw data
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where                what was changed/reason
 * -----------------------------------------------------------------
 * 
 * ******************************************************
 */
void delcol() {
/*
 */
  static long shift,ix,is,i;
/*
 */
  if (nzamac_(jscan)==0) {
/*
 *  programming error since column jscan is zero
 */
    error(" delcol ","    52  ");
  }
  shift=0;
  for(ix=1; ix<=nzamac_(jscan); ix++)  {
    is=amatcl_(ix+ptamac_(jscan));
    i=abs(is);
    if (i==iscan) {
      shift=shift+1;
    } else {
      amatcl_(ix-shift+ptamac_(jscan))=amatcl_(ix+ptamac_(jscan));
    }
  }
  if (shift!=1) {
/*
 *  programming error since iscan element was not found in column jscan
 *  or multiple entry of variable in a clause in input data
 */
    error(" delcol ","  102   ");
  }
  nzamac_(jscan)=nzamac_(jscan)-1;
  return;
}
/*
 * **************************************************
 *  subroutine delrow
 * 
 *  purpose:  deletes the element in row iscan and column jscan stored in
 *            amatrw.  does not adjust rnxxxx or change amatcl data
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where                what was changed/reason
 * --------------------------------------------------
 * 
 * **************************************************
 */
void delrow() {
/*
 */
  static long shift,jx,js,j;
/*
 */
  if (nzamar_(iscan)==0) {
/*
 *  programming error since row iscan is zero
 */
    error(" delrow ","    52  ");
  }
  shift=0;
  for(jx=1; jx<=nzamar_(iscan); jx++)  {
    js=amatrw_(jx+ptamar_(iscan));
    j=abs(js);
    if (j==jscan) {
      shift=shift+1;
    } else {
      amatrw_(jx-shift+ptamar_(iscan))=amatrw_(jx+ptamar_(iscan));
    }
  }
  if (shift!=1) {
/*
 *  programming error since jscan element was not found in row iscan
 */
    error(" delrow ","  102   ");
  }
  nzamar_(iscan)=nzamar_(iscan)-1;
/*
 *  increase rhs5 count in level 4
 */
  rw_(iscan,22,4)=rw_(iscan,22,4)+1;
  return;
}
/*
 * *********************************************************
 *  subroutine disprd
 * 
 *  displays reductions
 * 
 * *********************************************************
 */
void disprd() {
/*
 */
  static long j,i;
/*
 *  display values of variables moved to block 1 by preprocessing
 *  do not include artificial variable. values are in solut5 vector
 *  in level 4 ( = cl(.,18,4) vector ). note that the solution
 *  was not reshuffled by reshuf
 */
  printf("Variables with values determined by preprocessing\n");
  for(j=1; j<=ncols-1; j++)  {
    jscan=idxcol_(j);
    if ((ciblk_(jscan)==1)&&
        (cvatf_(jscan)==0)) {
      if (cl_(j,18,4)*scale_(jscan)==1) {
        printf("%s T\n",&colnam_(1,j));
      } else {
        if (cl_(j,18,4)*scale_(jscan)==-1) {
          printf("%s F\n",&colnam_(1,j));
        } else {
          printf("%s any value feasible\n",&colnam_(1,j));
        }
      }
    }
  }
/*
 *  display row reductions. do not include artificial row. counts
 *  are in rhs5 vector in level 4 ( = rw(.,22,4) vector). note
 *  that the reduction counts were not reshuffled by reshuf
 */
  printf("Reduced Row  No. of Entries Removed\n");
  for(i=1; i<=nrows-1; i++)  {
    if (rw_(i,22,4)>0) {
      printf("%s          %5ld\n",
          &rownam_(1,i),rw_(i,22,4));
    }
  }
  return;
}
/*
 * *********************************************************
 *  subroutine elim1
 * 
 *  eliminates matrix entries according to a row with just one entry
 * 
 * *********************************************************
 */
void elim1() {
/*
 */
  void delcol();
  void delrow();
  void uprxls();
/*
 */
  static long i,js,j,ix,is,jx,j1,shift;
/*
 *  a row has exactly one nonzero entry, and that entry is in column j,
 *  say.  then column j is moved to block 1, and matrix entries no longer
 *  needed are eliminated. lists rxleq1, rxleq2 are updated accordingly.
 * 
 *  get row index i
 */
  i=rxleq1_(rxleq1_(rowmax+1));
  rxleq1_(rowmax+1)=rxleq1_(rowmax+1)-1;
/*
 *  check if row i was processed earlier.
 */
  if (riblk_(i)==1) {
/*
 *  row i has already been moved to block 1. hence no further
 *  processing is needed for that row
 */
    succss=1;
    return;
  }
/*
 *  check if row i is zero
 */
  if (nzamar_(i)==0) {
/*
 *  row i must be zero due to earlier processing. but then this
 *  condition would have been detected before. hence have
 *  programming error
 */
    error(" elim1  ","      52");
  }
/*
 *  identify the column j with entry in row i
 */
  js=amatrw_(1+ptamar_(i));
  j=abs(js);
/*
 *  variable j is to be moved to block 1. record required solution
 *  value in solut5(j) in level 4
 */
  if (js>0) {
    cl_(j,18,4)=1;
  } else {
    cl_(j,18,4)=-1;
  }
  ciblk_(j)=1;
/*
 *  scan column j to delete or adjust rows with entries in that column
 *  programming error if column j is zero
 */
  if (nzamac_(j)==0) {
    error(" elim1  ","     102");
  }
  for(ix=1; ix<=nzamac_(j); ix++)  {
    is=amatcl_(ix+ptamac_(j));
    i=abs(is);
/*
 *  programming error if row i is zero
 */
    if (nzamar_(i)==0) {
      error(" elim1  ","     202");
    }
    if (((is>0)&&(js>0))||
        ((is<0)&&(js<0))) {
/*
 *  row i is satisfied by column j, and hence can be reduced
 *  and moved to block 1
 *  adjust columns with entries in row i
 */
      for(jx=1; jx<=nzamar_(i); jx++)  {
        j1=abs(amatrw_(jx+ptamar_(i)));
        if (j1!=j) {
          iscan=i;
          jscan=j1;
          delcol();
/*
 *  if column j1 is now zero, move it to block 1. the column
 *  may have any solution value. record value in solut5(j1) in level 5
 */
          if (nzamac_(j1)==0) {
            cl_(j1,18,4)=0;
            ciblk_(j1)=1;
          }
        }
      }
/*
 *  record that row i has now just one entry, in column j
 *  increase rhs5 count in level 4
 */
      rw_(i,22,4)=rw_(i,22,4)+nzamar_(i)-1;
      nzamar_(i)=1;
      amatrw_(1+ptamar_(i))=js;
      riblk_(i)=1;
    } else {
/*
 *  row i is not satisfied by column j. thus can delete the entry
 *  in row i and column j from row i.  will adjust column j later
 */
      iscan=i;
      jscan=j;
      delrow();
/*
 *  update rxleq1, rxleq2
 */
      uprxls();
      if (nzamar_(i)==0) {
/*
 *  row i has no entry
 */
        if (dlrwop_(i)==0) {
/*
 *  row i has no delete row option. thus original
 *  problem is not satisfiable. set succss = 0 and return
 */
          succss=0;
          return;
        } else {
/*
 *  row has delete row option
 *  move row i to block 1
 */
          riblk_(i)=1;
        }
      }
    }
  }
/*
 *  reduce column j
 */
  shift=0;
  for(ix=1; ix<=nzamac_(j); ix++)  {
    is=amatcl_(ix+ptamac_(j));
    if (((is>0)&&(js<0))||
        ((is<0)&&(js>0))) {
/*
 *  is entry can be removed from column j
 */
      shift=shift+1;
    } else {
      amatcl_(ix-shift+ptamac_(j))=amatcl_(ix+ptamac_(j));
    }
  }
  nzamac_(j)=nzamac_(j)-shift;
/*
 *  declare succss = 1 and return
 */
  succss=1;
  return;
}
/*
 * *********************************************************
 *  subroutine elim2
 * 
 *  eliminates matrix entries according to a 2sat row
 * 
 * *********************************************************
 */
void elim2() {
/*
 */
  void delcol();
  void delrow();
  void scalsp();
  void uprxls();
/*
 */
  static long ii,jjs1,jjs2,jj1,jj2,ix,is,i,ixx;
  static long flag,jx,js,j,js1,js2,cs,m;
/*
 *  a 2sat row, say ii, is used to eliminate matrix entries.  lists
 *  rxleq1, rxleq2 are updated accordingly
 * 
 *  get row index ii
 */
  ii=rxleq2_(rxleq2_(rowmax+1));
  rxleq2_(rowmax+1)=rxleq2_(rowmax+1)-1;
/*
 *  check if row ii still has two nonzeros and is still in block 2
 */
  if ((nzamar_(ii)<=1)||
      (riblk_(ii)==1)) {
/*
 *  row ii has been reduced or is in block 1.  hence skip row ii
 */
    return;
  }
/*
 *  get the two column indices of the 2sat row ii
 */
  jjs1=amatrw_(1+ptamar_(ii));
  jjs2=amatrw_(2+ptamar_(ii));
  jj1=abs(jjs1);
  jj2=abs(jjs2);
/*
 *  scale columns jj1, jj2 to achieve standard reduction case
 */
  if (jjs1>0) {
    jscan=jj1;
    scalsp();
  }
  if (jjs2<0) {
    jscan=jj2;
    scalsp();
  }
/*
 *  find all rows i having entries in both columns jj1, jj2, with
 *  i different from ii. record such rows i in aux vector
 */
  aux_(rowmax+1)=0;
  for(ix=1; ix<=nzamac_(jj1); ix++)  {
    is=amatcl_(ix+ptamac_(jj1));
    i=abs(is);
/*
 *  skip row i if it is actually row ii
 */
    if (i==ii) {
      goto zz100;
    }
/*
 *  search for row i in column jj2
 */
    for(ixx=1; ixx<=nzamac_(jj2); ixx++)  {
      if (abs(amatcl_(ixx+ptamac_(jj2)))==i) {
/*
 *  have found row i in column jj2. record row i in aux vector
 */
        aux_(rowmax+1)=aux_(rowmax+1)+1;
        aux_(aux_(rowmax+1))=i;
        goto zz100;
      }
    }
  zz100:;}
/*
 *  have all rows i with entries in both columns jj1, jj2 in
 *  aux vector
 */
  if (aux_(rowmax+1)==0) {
/*
 *  there is no such row i. thus unscale columns jj1, jj2 and return
 */
    goto zz750;
  }
/*
 *  process each row i recorded in aux vector using the 2sat
 *  clause of row ii
 */
  for(ix=1; ix<=aux_(rowmax+1); ix++)  {
    i=aux_(ix);
/*
 *  find entries for columns jj1 and jj2 in row i
 *  set flag for error check
 */
    flag=0;
    for(jx=1; jx<=nzamar_(i); jx++)  {
      js=amatrw_(jx+ptamar_(i));
      j=abs(js);
      if (j==jj1) {
/*
 *  found entry in column jj1
 */
        js1=js;
        flag=flag+1;
      } else {
        if (j==jj2) {
/*
 *  found entry in column jj2
 */
          js2=js;
          flag=flag+1;
        }
      }
    }
    if (flag!=2) {
/*
 *  programming error
 */
      error(" elim2  ","  402   ");
    }
/*
 *  decide on case for row i and record in auxv1 vector
 *  case = 0 means no reduction is possible. note that
 *  delete column option values have no influence on the
 *  reduction decision
 */
    auxv1_(ix)=0;
    if ((js1>0)&&(js2>0)) {
/*
 *  have case 1
 */
      auxv1_(ix)=1;
    } else {
      if ((js1<0)&&(js2<0)) {
/*
 *  have case 2
 */
        auxv1_(ix)=2;
      } else {
        if ((js1<0)&&(js2>0)) {
/*
 *  have case 3
 */
          auxv1_(ix)=3;
        }
      }
    }
  }
/*
 *  process each row i according to case number
 */
  for(ix=1; ix<=aux_(rowmax+1); ix++)  {
    i=aux_(ix);
    cs=auxv1_(ix);
    if (cs==1) {
/*
 *  have case 1
 *  delete entry in row i, column jj1
 */
      iscan=i;
      jscan=jj1;
      delcol();
      delrow();
      uprxls();
      goto zz500;
    }
    if (cs==2) {
/*
 *  have case 2
 *  delete entry in row i, column jj2
 */
      iscan=i;
      jscan=jj2;
      delcol();
      delrow();
      uprxls();
      goto zz500;
    }
    if (cs==3) {
/*
 *  have case 3
 *  delete all entries of row i, then add one +1 in row i in
 *  column of artificial variable, which is in column ncols
 *  assign row i to block 1
 */
      for(jx=1; jx<=nzamar_(i); jx++)  {
        iscan=i;
        jscan=abs(amatrw_(jx+ptamar_(i)));
        delcol();
/*
 *  if column jscan has become zero, move it to block 1. record
 *  solution value in solut5(jscan) in level 4
 */
        if (nzamac_(jscan)==0) {
          cl_(jscan,18,4)=0;
          ciblk_(jscan)=1;
        }
      }
      rw_(i,22,4)=rw_(i,22,4)+nzamar_(i)-1;
      nzamar_(i)=1;
      amatrw_(1+ptamar_(i))=ncols;
      riblk_(i)=1;
      if (nanzs==anzmax) {
/*
 *  matrix storage too small
 */
        error("  elim2 ","  602   ");
      }
      nzamac_(ncols)=nzamac_(ncols)+1;
      m=nzamac_(ncols)+ptamac_(ncols);
      amatcl_(m)=i;
      nanzs=nanzs+1;
    }
  zz500:;}
/*
 *  undo scaling of columns jj1, jj2
 */
  zz750:;
  if (jjs1>0) {
    jscan=jj1;
    scalsp();
  }
  if (jjs2<0) {
    jscan=jj2;
    scalsp();
  }
  return;
}
/*
 * *********************************************************
 *  subroutine initpp
 * 
 *  purpose:  declares all columns and rows except for artificial
 *            variable and row, to be in block 2. initializes
 *            rxleq1, rxleq2 lists
 * 
 * *********************************************************
 */
void initpp() {
/*
 */
  void uprxls();
/*
 */
  static long i,j;
/*
 *  declare all nonzero columns except last one, and all nonzero rows
 *  except last one, to be in block 2. last column, row contain
 *  artificial variable entry. note that all atf columns (which are now
 *  zero columns) remain in block 1. update nblks to 2 if necessary.
 */
  for(j=1; j<=ncols-1; j++)  {
    if (nzamac_(j)>0) {
      ciblk_(j)=2;
      nblks=2;
    }
  }
  for(i=1; i<=nrows-1; i++)  {
    if (nzamar_(i)>0) {
      riblk_(i)=2;
      nblks=2;
    }
  }
/*
 *  start rxleq1, rxleq2 index lists. exclude rows of block 1. thus
 *  artificial variable row is excluded
 */
  rxleq1_(rowmax+1)=0;
  rxleq2_(rowmax+1)=0;
  for(i=1; i<=nrows-1; i++)  {
    if (riblk_(i)==2) {
      iscan=i;
      uprxls();
    }
  }
/*
 *  initialize solut5 and rhs5 vectors in level 4
 */
  for(j=1; j<=ncols; j++)  {
    cl_(j,18,4)=0;
  }
  for(i=1; i<=nrows; i++)  {
    rw_(i,22,4)=0;
  }
  return;
}
/*
 * ****************************************************
 *  subroutine monotn
 * 
 *  purpose: identifies monotone columns and gives advisory
 * 
 * ****************************************************
 */
void monotn() {
/*
 */
  static long i,ix,j;
/*
 *  declares monotone columns (with zero costs if optimization) to be
 *  atf columns. declares all rows with any coefficient in any atf
 *  column to be deletable
 */
  for(j=1; j<=ncols-1; j++)  {
    if ((cvatf_(j)==0)&&
        ((apmflg==0)||(flggol==0))) {
/*
 *  have non-atf column, and do not have approximate
 *  minimization case with goals (if we have
 *  approximate minimization with goals, then variable
 *  might occur in goal constraint, and hence cannot
 *  be an atf variable)
 */
      if (cnallp_(j)==0) {
/*
 *  column has no positive entries. for any nonnegative cost,
 *  the assignment of false is advantageous. thus assignfalse
 *  with cvatf(j) = -2
 */
        cvatf_(j)=-2;
        flgatf=1;
        if (accflg==1) {
          printf(
              "monotone variable %s\n",&colnam_(1,j));
        }
      } else if (cnalln_(j)==0) {
/*
 *  column has no negative entries
 */
        if ((cost_(j)==0)||
            ((apmflg==0)&&
            (optimz==0))) {
/*
 *  column has zero cost or we have satisfiability case
 *  thus assigntrue with cvatf(j) = 2
 */
          cvatf_(j)=2;
          flgatf=1;
          if (accflg==1) {
            printf(
                  "monotone variable %s\n",&colnam_(1,j));
          }
        }
      }
    }
/*
 *  if cvatf(j) .ne. 0, declare all rows with entries in column j
 *  to be deletable
 */
    if (cvatf_(j)!=0) {
      if (nzamac_(j)>0) {
        for(ix=1; ix<=nzamac_(j); ix++)  {
          i=abs(amatcl_(ix+ptamac_(j)));
          dlrwop_(i)=1;
        }
      }
    }
  }
  return;
}
/*
 * ****************************************************
 *  subroutine scalsp
 * 
 *  purpose:  special scaling subroutine. scales column jscan
 *            data in amatcl, amatrw, but does not change any
 *            other data
 * 
 * ****************************************************
 */
void scalsp() {
/*
 */
  static long i,is,ix,js,jx;
/*
 *  programming error if column jscan is zero
 */
  if (nzamac_(jscan)==0) {
    error(" scalsp ","   52   ");
  }
/*
 *  scale column jscan data of amatcl
 */
  for(ix=1; ix<=nzamac_(jscan); ix++)  {
    is=amatcl_(ix+ptamac_(jscan));
    i=abs(is);
    amatcl_(ix+ptamac_(jscan))=-is;
/*
 *  programming error if row i is zero
 */
    if (nzamar_(i)==0) {
      error(" scalsp ","  102   ");
    }
/*
 *  change entry in row i
 */
    for(jx=1; jx<=nzamar_(i); jx++)  {
      js=amatrw_(jx+ptamar_(i));
      if (abs(js)==jscan) {
        amatrw_(jx+ptamar_(i))=-js;
        goto zz100;
      }
    }
/*
 *  programming error
 */
    error(" scalsp ","  112   ");
  zz100:;}
  return;
}
/*
 * *********************************************************
 *  subroutine sepblk
 * 
 *  purpose:  finds connected subproblems in block nblks
 * 
 *   input:   as specified in module summary, except that problem may
 *            have any number of blocks. assumes that a 1-separation
 *            exists between block nblks and the remaining blocks
 * 
 *  output:   input block nblks has been converted into the blocks
 *            corresponding to the maximal connected submatrices of
 *            block nblks. process may be stopped early if the total
 *            number of blocks (incl. artificial one) would exceed
 *            blkmax.
 * 
 *  caution:  uses layers 2 and 3 for intermediate storage
 * 
 * *********************************************************
 * 
 */
void sepblk() {
/*
 */
  void bfs();
  void reshuf();
  void tranpr();
/*
 */
  static long i,j,n,nb,flag;
/*
 *  flag records whether any rearrangement or breaking up of block
 *  nblks took place; if yes, must reshuffle before exiting
 */
  flag=0;
/*
 *  save current problem in layer 2
 */
  tranpr(c1,c2);
/*
 *  initialize nb = current number of blocks = nblks
 */
  nb=nblks;
/*
 *  initialize cdis list for bfs search
 */
  for(j=1; j<=ncols; j++)  {
    if (ciblk_(j)==nb) {
      cdis_(1)=j;
      cdis_(colmax+1)=1;
      goto zz150;
    }
  }
/*
 *  programming error
 */
  error(" sepblk ","     102");
/*
 *  begin iterative breaking up of block nb
 */
  zz150:;
/*
 *  do not further decomposition if nb = blkmax
 */
  if (nb==blkmax) {
    goto zz350;
  }
/*
 *  find all nodes reachable from node j = cdis(1)
 */
  bfs();
/*
 *  distances from node cdis(1) are now in solut1 and rhs1 vectors
 *  use these distances to break block nb into two blocks if this at
 *  all possible
 *  scan backwards to minimize rearrangement of matrix
 */
  cdis_(1)=0;
  for(j=ncols; j>=1; j--)  {
    if ((ciblk_(j)==nb)&&
        (solut1_(j)==tt15m1)) {
/*
 *  column j must be assigned to new block nb+1
 */
      ciblk_(j)=nb+1;
      cdis_(1)=j;
    }
  }
  if (cdis_(1)!=0) {
/*
 *  block nb can be separated into two blocks
 *  update flag and row indices
 */
    flag=1;
    for(i=1; i<=nrows; i++)  {
      if ((riblk_(i)==nb)&&
          (rhs1_(i)==tt15m1)) {
/*
 *  row i must be assigned to block nb+1
 */
        riblk_(i)=nb+1;
      }
    }
/*
 *  check if block nb has just one column
 */
    n=0;
    for(j=1; j<=ncols; j++)  {
      if (ciblk_(j)==nb) {
        n=n+1;
      }
    }
#ifdef LOGIC
    if ((n==1)&&(selpgv>0)) {
#endif   
#ifdef MATRIX 
    if (((n==1)&&(selpgv==0)) ||
        ((n<=2)&&(selpgv>0))) {
#endif   
/*
 *  selpgv = 0 means decomposition without special structure analysis
 *  n = 1 implies that
 *        block nb has just one column. add that column to block 1,
 *        and redefine block nb+1 to be just nb
 *  selpgv > 0 corresponds to generate command, where
 *  assignments to block 1 are allowed. 
 *  LOGIC case:  n = 1 implies that
 *        block nb has just one column. add that column to block 1,
 *        and redefine block nb+1 to be just nb
 *  MATRIX case: n <= 2 implies that
 *        block nb has <= 2 columns. add the column(s) to block 1,
 *        and redefine block nb+1 to be just nb
 */
      for(j=1; j<=ncols; j++)  {
        if (ciblk_(j)==nb) {
          ciblk_(j)=1;
        } else {
          if (ciblk_(j)==(nb+1)) {
            ciblk_(j)=nb;
          }
        }
      }
      for(i=1; i<=nrows; i++)  {
        if (riblk_(i)==nb) {
          riblk_(i)=1;
        } else {
          if (riblk_(i)==(nb+1)) {
            riblk_(i)=nb;
          }
        }
      }
    } else {
/*
 *  block nb has >= 2 columns (case LOGIC) or 
 *  >= 1 (selpgv = 0) or >= 3 (selpgv > 0) columns (case MATRIX)
 *  increment nb
 */
      nb=nb+1;
    }
/*
 *  start next iteration
 */
    goto zz150;
  }
/*
 *  current block nb cannot be separated into two blocks because
 *  it has no block decomposition, or because nb = blkmax
 */
  zz350:;
  if (flag==0) {
/*
 *  block nb is the original block nblks. thus no separation or
 *  rearangement took place at all
 *  transfer input problem from layer 2 to layer 1 and return
 */
    tranpr(c2,c1);
    return;
  }
/*
 *  at least one separation or rearrangment of the original block
 *  nblks took place. update block indices of input problem in layer 2
 */
  nblks=nb;
  for(j=1; j<=ncols; j++)  {
    cl_(j,21,2)=ciblk_(j);
  }
  for(i=1; i<=nrows; i++)  {
    rw_(i,24,2)=riblk_(i);
  }
/*
 *  transfer problem with updated block indices from layer 2
 *  to layer 1
 */
  tranpr(c2,c1);
/*
 *   reshuffle problem so that each block has contiguous indices
 */
  reshuf();
/*
 *  check that each block has rows and columns
 */
  nb=1;
  for(j=1; j<=ncols; j++)  {
    if ((j>1)&&
        (ciblk_(j)!=ciblk_(j-1))) {
      nb=nb+1;
    }
  }
  if (nb!=nblks) {
/*
 *  programming error
 */
    error(" sepblk ","    1202");
  }
  nb=1;
  for(i=1; i<=nrows; i++)  {
    if ((i>1)&&
        (riblk_(i)!=riblk_(i-1))) {
      nb=nb+1;
    }
  }
  if (nb!=nblks) {
/*
 *  programming error
 */
    error(" sepblk ","    1212");
  }
  return;
}
/*
 * *********************************************************
 *  subroutine uprxls
 * 
 *  purpose: updates row index lists rxleq1, rxleq2 using row iscan
 * 
 * *********************************************************
 */
void uprxls() {
/*
 *  programming error if row iscan is in block 1
 */
  if (riblk_(iscan)==1) {
    error(" uprxls ","   52   ");
  }
  if (dlrwop_(iscan)==0) {
/*
 *  row does not have delete row option, hence is a candidate
 */
    if (nzamar_(iscan)==1) {
      rxleq1_(rowmax+1)=rxleq1_(rowmax+1)+1;
      rxleq1_(rxleq1_(rowmax+1))=iscan;
    } else {
      if (nzamar_(iscan)==2) {
        rxleq2_(rowmax+1)=rxleq2_(rowmax+1)+1;
        rxleq2_(rxleq2_(rowmax+1))=iscan;
      }
    }
  }
  return;
}
/*  last record of preproc.c****** */
