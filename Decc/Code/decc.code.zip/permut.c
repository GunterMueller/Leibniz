/*  first record of permut.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();
/*
 * **********************************************************
 *  module permutations
 *                     
 *  purpose:  permutes and scales fixed columns of each block 
 *            to permit efficient enumeration.              
 *                     
 *  input:  problem with block indices in layer 1.
 *            arrays assumed defined:             
 *             - matrix data amatcl, amatrw       
 *             - ncols, nrows, nblks              
 *             - colnam, rownam
 *             - dlclop, dlrwop                   
 *             - matrix indices  cixxxx, rixxxx   
 *             - counts cnxxx, rnxxx              
 *             - scale, idxcol, idxrow, invidxcol, invidxrow            
 *                     
 *  output:  input problem with permuted fixed columns.
 *                     
 *  caution:  uses layers 2 and 3 for intermediate storage.
 *                     
 *  calling sequence:  
 *     prmfix          
 *       prmval        
 *       prmstr        
 *                     
 * **********************************************************
 * 
 * **********************************************************
 *  subroutine prmfix  
 *                     
 *  purpose: finds a good permutation of fixed columns 
 *           for each block for efficient enumeration.           
 *                     
 *    input: as in module summary.                
 *                     
 *   output: input problem with permuted fixed columns.
 *                     
 *   caution: uses layers 2 and 3 for intermediate storage.
 *                     
 * **********************************************************
 * 
 */
void prmfix() {
/*
 */
  void prmstr();
  void prmval();
  void tranpr();
  void xstrfx();
  void xstrip();
/*
 */
  static long i,imprvp,imprvq,imprvs,ix,ixx,i1;
  static long j,jp,js,jx,jxp,jxx,m;
  static long p,pass,q,shift;
/*
 *  save input problem in layer 3
 */
  tranpr(c1,c3);
/*
 *  find best permutation for each block
 */
  for(q=1; q<=nblks; q++)  {
    qblock=q;
/*
 *  skip block q if at most 3 fixed variables
 *  or more than aggmax variables
 */
    if ((bdfxbl_(q)<3)||
        (bdfxbl_(q)>aggmax)) {
      goto zz100;
    }
/*
 *  extract strip q
 */
    xstrip(q);
/*
 *  save strip q in layer 2
 */
    tranpr(c1,c2);
/*
 *  extract fixed columns of strip q
 */
    xstrfx(q);
/*
 *  find index list of fixed nonzero columns in block q, 
 *  highest index first
 */
    jx=0;
    for(j=ucllim_(q); j>=lcllim_(q); j--)  {
      if ((cifix_(j)!=0)&&
          (cnall_(j)>0)) {
        jx=jx+1;
        cxlfix_(jx)=j;
      }
    }
    cxlfix_(colmax+1)=jx;
/*
 *  skip block q if at most one fixed column recorded 
 *  in cxlfix
 */
    if (cxlfix_(colmax+1)<=1) {
      goto zz5500;
    }
/*
 *  find index list of rows that have their nonzeros 
 *  of strip q within the fixed columns of strip q.  
 *  do not record duplicates of such rows
 */
    ix=0;
    for(i=1; i<=nrows; i++)  {
/*
 *  skip zero rows and rows with nonzeros within strip q 
 *  but outside of fixed columns
 */
      if ((nzamar_(i)==0)||
          (nzamar_(i)<nzamr_(i,2))) {
        goto zz300;
      }
/*
 *  row i is a candidate.  skip row i if duplicate row 
 *  (within strip q) with higher index exists.
 * 
 *  zero out part of solut1 vector
 */
      for(j=lcllim_(q); j<=ucllim_(q); j++)  {
        solut1_(j)=0;
      }
/*
 *  place row i into solut1 vector.  
 *  know row i to be nonzero
 */
      for(jx=1; jx<=nzamar_(i); jx++)  {
        js=amatrw_(jx+ptamar_(i));
        j=abs(js);
        if (js>0) {
          solut1_(j)=1;
        } else {
          solut1_(j)=-1;
        }
      }
/*
 *  compare row i with remaining rows
 */
      if (i<nrows) {
        for(i1=i+1; i1<=nrows; i1++)  {
/*
 *  skip row i1 if zero or if nonzeros exist outside 
 *  of fixed columns
 */
          if ((nzamar_(i1)==0)||
              (nzamar_(i1)<nzamr_(i1,2))) {
            goto zz350;
          }
/*
 *  zero out part of solut2 vector
 */
          for(j=lcllim_(q); j<=ucllim_(q); j++)  {
            solut2_(j)=0;
          }
/*
 *  place row i1 into solut2 vector
 */
          for(jx=1; jx<=nzamar_(i1); jx++)  {
            js=amatrw_(jx+ptamar_(i1));
            j=abs(js);
            if (js>0) {
              solut2_(j)=1;
            } else {
              solut2_(j)=-1;
            }
          }
/*
 *  compare solut1 and solut2.  equality means row i1 
 *  is a duplicate of row i.  thus row i can be ignored.
 */
          for(j=lcllim_(q); j<=ucllim_(q); j++)  {
            if (solut1_(j)!=solut2_(j)) {
/*
 *  row i1 is different from row i
 */
              goto zz350;
            }
          }
/*
 *  row i1 is same as row i
 */
          goto zz300;
        zz350:;}
      }
/*
 *  there is no duplicate of row i with higher index; 
 *  thus record row i
 */
      ix=ix+1;
      rxlntz_(ix)=i;
    zz300:;}
    rxlntz_(rowmax+1)=ix;
/*
 *  skip strip q if no row index in rxlntz
 */
    if (rxlntz_(rowmax+1)==0) {
      goto zz5500;
    }
/*
 *  compute size of permutation vector collection
 */
    if (cxlfix_(colmax+1)>6) {
      psize=6;
    } else {
      psize=cxlfix_(colmax+1);
    }
/*
 *  initialize final permutation fnlprm. note that  
 *  initialization is for all columns, while subsequent
 *  changes are only for columns with changed permutation, 
 *  within block q. thus fnlprm is always
 *  a complete permutation, correct for all columns
 */
    for(j=1; j<=ncols; j++)  {
      fnlprm_(j)=j;
    }
/*
 *  start passes for permutation of fixed columns
 * 
 *  initialize flag for improvement for block q
 */
    imprvq=0;
/*
 *  max number of passes below is a heuristic value
 */
    m=min(cxlfix_(colmax+1)-psize+1,20);
    for(pass=1; pass<=m; pass++)  {
      if (accflg==1) {
        printf("pass no. = %ld\n",pass);
      }
/*
 *  initialize improvement flag for this pass
 */
      imprvp=0;
/*
 *  start iterations for given pass.  below, shift is 
 *  the number of columns to right of the psize column 
 *  collection.  the latter collection will be permuted 
 *  optimally.
 */
      for(shift=0; shift<=cxlfix_(colmax+1)-psize; shift++)  {
/*
 *  initialize improvement flag for shift
 */
        imprvs=0;
/*
 *  extract index list of columns to be permuted
 */
        for(jx=1; jx<=psize; jx++)  {
          cxlinp_(jx)=cxlfix_(jx+shift);
        }
/*
 *  extract rows of rxlntz that do not have any nonzeros 
 *  to the right of the columns of cxlinp.  the rightmost 
 *  column index is given by cxlinp(1)
 */
        ixx=0;
        for(ix=1; ix<=rxlntz_(rowmax+1); ix++)  {
          i=rxlntz_(ix);
/*
 *  scan row i for entry to right of psize column set.  
 *  know row i to be nonzero.
 */
          for(jx=1; jx<=nzamar_(i); jx++)  {
            if (abs(amatrw_(jx+ptamar_(i)))>cxlinp_(1)) {
/*
 *  there is such an entry.  thus row i is not considered in
 *  permutation calculations
 */
              goto zz1210;
            }
          }
/*
 *  row i will be considered in the permutations.  record it.
 */
          ixx=ixx+1;
          rxlinp_(ixx)=i;
        zz1210:;}
        rxlinp_(rowmax+1)=ixx;
        if (rxlinp_(rowmax+1)==0) {
/*
 *  no row can be considered; thus have reached end of 
 *  all shift cases
 */
          goto zz3500;
        }
/*
 *  have cxlinp and rxlinp lists
 *  find best permutation with these lists.
 * 
 *  determine current value.  
 *  for this, initialize height vector for
 *  given ordering of columns
 */
        for(jx=1; jx<=psize; jx++)  {
          j=cxlinp_(jx);
          height_(j)=jx-1;
        }
/*
 *  give height = psize to columns to left of selected set.
 */
        if (lcllim_(q)<cxlinp_(psize)) {
          for(j=lcllim_(q); j<=cxlinp_(psize)-1; j++)  {
            height_(j)=psize;
          }
        }
/*
 *  compute permutation value and retain in bstval
 */
        prmval();
        bstval=pmvalue;
/*
 *  initialize current, temporary, best permutations
 *  curprm, tmpprm, bstprm
 */
        for(j=lcllim_(q); j<=ucllim_(q); j++)  {
          curprm_(j)=j;
          tmpprm_(j)=j;
          bstprm_(j)=j;
        }
/*
 *  try all possible permutations to get better value
 */
        for(p=1; p<=nprms_(psize); p++)  {
/*
 *  update height according to permutation
 */
          for(jx=1; jx<=psize; jx++)  {
/*
 *  the permutation sends jx to jxp as follows:
 */
            jxp=prmdat_(prmlim_(psize)+jx-1,p);
/*
 *  correspondingly, j = cxlinp(jx) is sent to jp=cxlinp(jxp),
 *  and height is jxp-1
 */
            j=cxlinp_(jx);
            jp=cxlinp_(jxp);
            curprm_(j)=jp;
            height_(j)=jxp-1;
          }
/*
 *  compute permutation value
 */
          prmval();
/*
 *  if pmvalue .gt. bstval, retain the improvement
 */
          if (pmvalue>bstval) {
            imprvq=1;
            imprvp=1;
            imprvs=1;
            bstval=pmvalue;
            for(jxx=1; jxx<=psize; jxx++)  {
              j=cxlinp_(jxx);
              bstprm_(j)=curprm_(j);
            }
          }
        }
/*
 *  if no improvement for this shift case, skip to next one
 */
        if (imprvs==0) {
          goto zz1100;
        }
/*
 *  have improvement.  retain in fnlprm
 */
        for(jx=1; jx<=cxlfix_(colmax+1); jx++)  {
          j=cxlfix_(jx);
          tmpprm_(j)=bstprm_(fnlprm_(j));
        }
        for(jx=1; jx<=cxlfix_(colmax+1); jx++)  {
          j=cxlfix_(jx);
          fnlprm_(j)=tmpprm_(j);
        }
/*
 *  update rows indexed by rxlinp.
 */
        for(ix=1; ix<=rxlinp_(rowmax+1); ix++)  {
          i=rxlinp_(ix);
/*
 *  know row i to be nonzero
 */
          for(jx=1; jx<=nzamar_(i); jx++)  {
            js=amatrw_(jx+ptamar_(i));
            j=abs(js);
            if (js>0) {
              amatrw_(jx+ptamar_(i))=bstprm_(j);
            } else {
              amatrw_(jx+ptamar_(i))=-bstprm_(j);
            }
          }
        }
      zz1100:;}
/*
 *  exit from shift cases
 */
      zz3500:;
/*
 *  if no improvement for pass, done for block q
 */
      if (imprvp==0) {
        goto zz4500;
      }
    }
/*
 *  have done all passes or no further improvement possible
 */
    zz4500:;
/*
 *  if improvement for block q, install permutation 
 *  of fnlprm in layer 3 problem
 */
    if (imprvq>0) {
      prmstr();
    }
/*
 *  restore current layer 3 problem to layer 1
 */
    zz5500:;
    tranpr(c3,c1);
  zz100:;}
/* 
 *  validation of indexing functions
 *  can be removed once prmstr has been used several times
 *  code added March 29, 2007 after addition of
 *  inverse indexing functions invidxcol and invidxrow
 */
  for (j=1;j<=ncols;j++) {
    if (invidxcol_(idxcol_(j)) != j) {
      printf("Column indexing error for external col index = %ld/n",j);
      error(" prmstr "," 202 "); 
    }
  }
  for (j=1;j<=nrows;j++) {
    if (invidxrow_(idxrow_(j)) != j) {
      printf("Row indexing error for external row index = %ld/n",j);
      error(" prmstr "," 204 ");
    } 
  }
/*
 */
  return;
}
/*
 * **********************************************************
 *  subroutine prmstr  
 *                     
 *  purpose: installs permutation of fnlprm in layer 3 
 *                     
 * **********************************************************
 * 
 */
void prmstr() {
/*
 */
  void tranpr();
/*
 */
  static long i,ix,j,j1,jp,js,jx,l,q;
/*
 */
  q=qblock;
/*
 *  move copy of input problem from layer 3 to layer 2
 */
  tranpr(c3,c2);
/*
 *  permute column data
 */
  for(jx=1; jx<=cxlfix_(colmax+1); jx++)  {
    j=cxlfix_(jx);
    jp=fnlprm_(j);
/*
 *  the permutation sends j to jp = fnlprm(j).  move cl data
 */
    for(l=1; l<=lclmax; l++)  {
      cl_(jp,l,3)=cl_(j,l,2);
    }
/*
 *  move matrix data
 */
    ptamc_(jp,3)=ptamc_(j,2);
    nzamc_(jp,3)=nzamc_(j,2);
    if (nzamc_(j,2)>0) {
      for(ix=1; ix<=nzamc_(j,2); ix++)  {
        amc_(ix+ptamc_(jp,3),3)=amc_(ix+ptamc_(j,2),2);
      }
    }
  }
/*
 *  update idxcol data
 */
  for(j=1; j<=ncols; j++)  {
/*
 *  so far, j has been moved to jp = cl(j,20,2) = idxcol 
 *  information.
 */
    jp=cl_(j,20,2);
/*
 *  apply the permutation of fnlprm to jp, 
 *  and store in idxcol in layer 3, which is cl_(j,20,3)
 */
    cl_(j,20,3)=fnlprm_(jp);
  }
/*
 *  update invidxcol in layer 3, which is cl_(j,26,3)
 */
  for(j1=1; j1<=ncols; j1++)  {
    j = cl_(j1,20,3); /* = new idxcol_(j1) */
    cl_(j,26,3) = j1;
  }
/*
 *  adjust row data according to column permutation fnlprm
 */
  for(i=1; i<=nrows; i++)  {
    if (nzamr_(i,2)>0) {
      for(jx=1; jx<=nzamr_(i,2); jx++)  {
        js=amr_(jx+ptamr_(i,2),2);
        j=abs(js);
        if ((j>=lcllim_(q))&&
            (j<=ucllim_(q))) {
          jp=fnlprm_(j);
          if (js>0) {
            amr_(jx+ptamr_(i,3),3)=jp;
          } else {
            amr_(jx+ptamr_(i,3),3)=-jp;
          }
        }
      }
    }
  }
  return;
}
/*
 * **********************************************************
 *  subroutine prmval  
 *                     
 *  purpose: calculates value of permutation using given 
 *           height.
 *                     
 * **********************************************************
 * 
 */
void prmval() {
/*
 */
  static long h,i,ix,j,jx,m,n;
/*
 */
  pmvalue=0;
  for(ix=1; ix<=rxlinp_(rowmax+1); ix++)  {
    i=rxlinp_(ix);
    h=psize;
    for(jx=1; jx<=nzamar_(i); jx++)  {
      j=abs(amatrw_(jx+ptamar_(i)));
      if (h>height_(j)) {
        h=height_(j);
      }
    }
/*
 *  calculate n = 2**h
 */
    n=1;
    if (h>0) {
      for(m=1; m<=h; m++)  {
        n=n*2;
      }
    }
    pmvalue=pmvalue+n;
  }
  return;
}
/*  last record of permut.c****** */
