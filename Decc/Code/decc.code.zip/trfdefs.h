/*  first record of trfdefs.h***** */
/*
 * *******************************************************
 * function defs
 * *******************************************************
 * 
 */
/* max and min function*/
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))
/*
 *  global integer arrays
 */
#define delopt_(i)    delopt[(i-1)]
#define varopt_(i)    varopt[(i-1)]   
#define clsxl1_(i)    clsxl1[(i-1)]
#define clsxl2_(i)    clsxl2[(i-1)]
#define litlst_(i)    litlst[(i-1)]
#define nburec_(i)    nburec[(i-1)]
#define tburec_(i)    tburec[(i-1)]
#define xbuchr_(i)    xbuchr[(i-1)]
#define xbuint_(i)    xbuint[(i-1)]
#define crdflg_(i)    crdflg[(i-1)]
#define cwtflg_(i)    cwtflg[(i-1)]
#define sused_(i)     sused[(i-1)]
#define pused_(i)     pused[(i-1)]
#define vused_(i)     vused[(i-1)]
#define qperm_(i)     qperm[(i-1)]
#define qsetix_(i)    qsetix[(i-1)]
#define qused_(i)     qused [(i-1)]
#define buint_(i,j)   buint[(i-1)+(j-1)*(busmax)]
#define setdat_(i,j)  setdat[(i-1)+(j-1)*(eltmax+3)]
#define prdset_(i,j)  prdset[(i-1)+(j-1)*(3)]
#define whrstm_(i,j)  whrstm[(i-1)+(j-1)*(qntmax+1)]
#define trcolusx_(i)  trcolusx[(i-1)]
#define trcvatf_(i)   trcvatf[(i-1)]
#define trtrucst_(i)  trtrucst[(i-1)]
#define trfalcst_(i)  trfalcst[(i-1)]
#define tramatrw_(i)  tramatrw[(i-1)]
#define trptamar_(i)  trptamar[(i-1)]
#define trnzamar_(i)  trnzamar[(i-1)]
/*
 *  global string variables/arrays
 */
#define truec_(i)      truec[(i-1)]
#define falsc_(i)      falsc[(i-1)]
#define strng1_(i)     strng1[(i-1)]
#define strng2_(i)     strng2[(i-1)]
#define strng3_(i)     strng3[(i-1)]
#define state_(i)      state[(i-1)]
#define clsnam_(i)     clsnam[(i-1)]
#define tmpstr_(i)     tmpstr[(i-1)]
#define tmp_(i)        tmp[(i-1)]
#define grpstr_(i)     grpstr[(i-1)]
#define litstr_(i)     litstr[(i-1)]
#define auxmsg_(i)     auxmsg[(i-1)]
#define inputrecord_(i) inputrecord[(i-1)]
#define trprbnam_(i)   trprbnam[(i-1)]
#define trcolnam_(i,j) trcolnam[(i-1)+(j-1)*(vnamln+1)]
#define trrownam_(i,j) trrownam[(i-1)+(j-1)*(ridtln+1)]
#define cnfvar_(i,j)   cnfvar[(i-1)+(j-1)*(vnamln+1)]
#define cnfvarflg_(i)  cnfvarflg[2*(i-1)]
#define buchr_(i,j)    buchr[(i-1)+(j-1)*(bchmax+1)]
#define setnam_(i,j)   setnam[(i-1)+(j-1)*(vnamln+1)]
#define eltnam_(i,j)   eltnam[(i-1)+(j-1)*(enamln+1)]
#define prdnam_(i,j)   prdnam[(i-1)+(j-1)*(enamln+1)]
#define varnam_(i,j)   varnam[(i-1)+(j-1)*(vnamln+1)]
#define nvnam_(i,j)    nvnam[(i-1)+(j-1)*(8+1)]
#define qntnam_(i,j)   qntnam[(i-1)+(j-1)*(enamln+1)]
#define cstval_(i,j,k) cstval[(i-1)+(j-1)*(6+1)+(k-1)*(6+1)*(2)]
/*
 *  string variables passed by arguments
 */
#define tmparg_(i)     tmparg[(i-1)]
/*
 *  local string variables
 */
#define a_(i)          a[(i-1)]
#define arg_(i)        arg[(i-1)]
#define arg1_(i)       arg1[(i-1)]
#define arg2_(i)       arg2[(i-1)]
#define targ_(i)       targ[(i-1)]
#define targ1_(i)      targ1[(i-1)]
#define targ2_(i)      targ2[(i-1)]
#define type_(i)       type[(i-1)]
#define nam_(i)        nam[(i-1)]
#define nam1_(i)       nam1[(i-1)]
#define nam2_(i)       nam2[(i-1)]
#define nam3_(i)       nam3[(i-1)]
#define tmpnam_(i)     tmpnam[(i-1)]
#define tnam_(i)       tnam[(i-1)]
#define litnam_(i)     litnam[(i-1)]
#define tmpvar_(i)     tmpvar[(i-1)]
#define str_(i)        str[(i-1)]
#define msgstr_(i)     msgstr[(i-1)]
#define scrstr_(i)     scrstr[(i-1)]
#define tstr_(i)       tstr[(i-1)]
#define numstr_(i)     numstr[(i-1)]
#define ctmp_(i)       ctmp[(i-1)]
#define stmp_(i)       stmp[(i-1)]
#define ft_(i)         ft[(i-1)]
#define funct_(i)      funct[(i-1)]
#define s1_(i)         s1[(i-1)]
#define s2_(i)         s2[(i-1)]
/*
 */
void error();
void lbccexit();
int lstrncmp();
/*  last record of trfdefs.h****** */
