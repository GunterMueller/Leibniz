/*  first record of prsvar.c***** */
#include<string.h>
#include<stdio.h>
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/*
 * ********************************************************
 *  subroutine prsvar
 * 
 *  purpose:  parses variables section of leibniz source file.
 * 
 *            updates the following data structures:
 * 
 *              varnam :-      stores variable names.
 *              cnfvar :-      stores names in full-blown
 *                             variable list
 *              delopt(j) :-   delete option for variable
 *              cstval(j, ) :- cost information for variable.
 *              varopt(j) :-   assigned true/false option for
 *                             a variable
 * 
 *  caution:  the input string is in tmpstr
 * 
 * **********************************************************
 * 
 */
void prsvar() {
/*
 */
  static char type[1+1];
  static char str[20+1];
  static long indx,l,r,err,chk;
  static long n;
  static char nam[58+1];
  static char msgstr[128+1];
/*
 */
  void chknam();
  void ckeoln();
  void extcmp();
  void fndnam();
  void inperr();
  void prsopt();
  int readlogfil();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  type_(1+1) = '\0';
  str_(20+1) = '\0';
  nam_(58+1) = '\0';
  msgstr_(128+1) = '\0';
/*
 *  read next record from log file
 *  max line length is 125
 */
  zz50:;
  if (readlogfil()==0) {
    return;
  }
/*
 */
  l=0;
  r=0;
/*
 *  get next component of tmpstr
 */
  extcmp(tmpstr,&l,&r);
/*
 * -----------------------
 *  check for keywords
 * -----------------------
 */
  if (lstrncmp(&tmpstr_(l),"ENDATA",r-l+1)==0) {
    inperr(&fatal);
    strcpy(msgstr," LBCC2040: Unexpected ENDATA encountered");
    scrwrt("+W",msgstr);
    return;
  }
  if (lstrncmp(&tmpstr_(l),"FACTS",r-l+1)==0) {
/*
 *  check that variable section is not empty
 */
    if (nvars==0) {
      inperr(&nftl);
      sprintf(msgstr," LBCC1140: VARIABLES section but no "
          "variables defined");
      scrwrt("+W",msgstr);
    }
    ckeoln(tmpstr,&r);
    strcpy(state ,"Q4000");
    return;
  } else if (lstrncmp(&tmpstr_(l),"VARIABLES",r-l+1)==0) {
    inperr(&fatal);
    sprintf(msgstr," LBCC2150: VARIABLES section "
        "already encountered");
    scrwrt("+W",msgstr);
    return;
  } else if (lstrncmp(&tmpstr_(l),"SETS",r-l+1)==0) {
    inperr(&fatal);
    sprintf(msgstr," LBCC2160: SETS section must "
        "come before VARIABLES");
    scrwrt("+W",msgstr);
    return;
  } else if (lstrncmp(&tmpstr_(l),"PREDICATES",r-l+1)==0) {
    inperr(&fatal);
    sprintf(msgstr," LBCC2160: PREDICATES section must "
        "come before VARIABLES");
    scrwrt("+W",msgstr);
    return;
  }
/*
 * ----------------------------------
 *  state definitions
 * ----------------------------------
 * ----------------------------------
 *  state q3000 is variable name
 * ----------------------------------
 */
  if (strcmp(state ,"Q3000")==0) {
/*
 *  check if legal name
 */
    n = min(r-l+1,58);
    strncpy(nam,&tmpstr_(l),n);
    nam_(n+1) = '\0';
    chknam(nam,&err,"V");
    if (err!=0) {
      goto zz50;
    }
/*
 *  search for variable name
 */
    fndnam(nam,&indx,type);
    if (indx>0) {
      inperr(&nftl);
      if (strcmp(type  ,"E")==0) {
        strcpy(str   ,"element");
      } else if (strcmp(type  ,"V")==0) {
        strcpy(str   ,"variable");
      } else if (strcmp(type  ,"S")==0) {
        strcpy(str   ,"set");
      } else if (strcmp(type  ,"P")==0) {
        strcpy(str   ,"predicate");
      } else if (strcmp(type  ,"Q")==0) {
        error(" prsvar ","  202   ");
      } else {
        error(" prsvar ","  204   ");
      }
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr," LBCC1010: %s has already been "
          "defined as a(n) %s",auxmsg,str);
      scrwrt("+W",msgstr);
      goto zz50;
    }
/*
 *  variable name not previously stored; store it
 */
    nvars=nvars+1;
    if (nvars>cvmax) {
      inperr(&fatal);
      n = cvmax;
      sprintf(msgstr," LBCC2170: Too many Boolean variables; "
          "at most %ld allowed",n);
      scrwrt("+W",msgstr);
      return;
    }
    strncpy(&varnam_(1,nvars),&tmpstr_(l),r-l+1);
    varnam_(r-l+2,nvars) = '\0';
/*
 *  store variable name in cnfvar
 */
    ncnfv=ncnfv+1;
    if (ncnfv>cvmax) {
      inperr(&fatal);
      n = cvmax;
      sprintf(msgstr," LBCC2110: Cannot exceed %ld "
          "total variables",n);
      scrwrt("+W",msgstr);
      return;
    }
    strcpy(&cnfvar_(1,ncnfv),&varnam_(1,nvars));
    strcpy(state ,"Q5000");
/*
 *  do not require options to be specified,
 *  suppress error checking.
 */
    chk=0;
    prsopt(&l,&r,&chk,&err);
    if (err!=0) {
      strcpy(state ,"Q3000");
      goto zz50;
    }
/*
 *  store option values
 */
    delopt_(ncnfv)=dopt;
    varopt_(ncnfv)=avopt;
    strcpy(&cstval_(1,1,ncnfv),truec);
    strcpy(&cstval_(1,2,ncnfv),falsc);
    strcpy(state ,"Q3000");
    goto zz50;
  }
/*
 * ---------------------------------------------
 *  error section
 * ---------------------------------------------
 *  error: state not found
 */
  error(" prsvar ","  3902  ");
}
/*  last record of prsvar.c****** */
