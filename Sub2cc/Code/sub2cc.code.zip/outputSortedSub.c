/* first record of outputSortedSub.c *****/
#include "sub2cc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   void outputSortedSub(char* sortedfile):
 *              output sorted subgroups of subgroup[] array and
 *              store in sorted.sub file
 *   int checkNumeric(char *token)
 *   identicalLogic(int i, int j)
 */
/**************************************************************/
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  outputSortedSub(): output sorted subgroups of
*                     subgroup[] array and
*                     store in .sorted.sub file
* --------------------------------------------------------
***************************************************************/
void outputSortedSub(char* sortedfile) {

  int flag, i, id, isort, j;

  FILE* sortedfil;

  sortedfil = openFile(sortedfile,"w");

  fprintf(sortedfil,
          "SORTED SUBGROUPS\n\n");

  /* if master file is used as test file, add caution
   * statement at beginning of sub file
   */
  if (gSelectTestFile == MASTER) {
    fprintf(sortedfil,
       "CAUTION: Master file is used as test file.\n");
    fprintf(sortedfil,
       "         Do NOT use output for statistical\n");
    fprintf(sortedfil,
       "         validation of factors or formulas.\n\n");
  } else {
    fprintf(sortedfil,
       "NOTE: Alternate test file is used for testing.\n");
    fprintf(sortedfil,
       "      Output may be used for validation of\n");
    fprintf(sortedfil,
       "      factors and formulas.\n\n");
  }

  if (gParams.defSizeSubgroup == DEFMAX) {
    fprintf(sortedfil,
	    "Subgroup definitions are of MAX size\n");
  } else if (gParams.defSizeSubgroup == DEFMIN) {
    fprintf(sortedfil,
	    "Subgroup definitions are of MIN size\n");
  } else {
    sub2error("Error of defSizeSubgroup value",
              "outputSortedSub","101");  
  }

  if (gParams.significanceMeasure == UNUSUALNESS) {
    fprintf(sortedfil,
	"Significance measure = unusualness\n\n");
  } else if (gParams.significanceMeasure == ACCURACY) {
    fprintf(sortedfil,
	"Significance measure = accuracy\n\n");
  } else if (gParams.significanceMeasure == BOTH) {
    fprintf(sortedfil,
	"Significance measure = both unusualness and accuracy\n\n");
  } else {
    sub2error("Unknown significance measure",
             "outputSortedSub","102");  
  }
 
  if (gParams.selectOutput == ALL) {
    fprintf(sortedfil,"Output all subgroups\n\n");
  } else if (gParams.selectOutput == REPRESENTATIVE) {
    fprintf(sortedfil,
    "Output representatives of logically identical subgroups\n\n");
  } else {
    sub2error("Unknown output option",
             "outputSortedSub","103");  
  }   

   fprintf(sortedfil,
          "*****************************************\n");

  for (isort=1; isort<=numSubgroup; isort++) {

    i = sortedIndex[isort];

    /* check for termination using subgroup threshold */
    if (subgroup[i].significanceAverage < 
        gParams.subgroupThreshold) {
      /* terminate output of sorted subgroups */
      fprintf(sortedfil,"ENDATA\n");
      closeFile(sortedfil);
      return;
    }


    flag = FALSE;
    if (gParams.selectOutput == REPRESENTATIVE) {
      /* output is restricted to representatives of logically */
      /* identical cases; check if a logically identical case */
      /* has already been listed */
      for (id=1; id<=isort-1; id++) {
        flag = identicalLogic(i,sortedIndex[id]);
        if (flag == TRUE) {
          break;
        }
      }
    }

    if (flag == FALSE) {
      /* list case */
      fprintf(sortedfil,
              "/*eject*/\nSUBGROUP %d significance = %f\n",
              i, subgroup[i].significanceAverage);

      for (j=1; j<=subgroup[i].numRecord; j++) {
        fprintf(sortedfil,"%s",subgroup[i].record[j]);
      }

      fprintf(sortedfil,
          "\n*******************************************\n");
    }
  
  } /* end for isort */

  fprintf(sortedfil,
          "*******************************************\n\n");

  fprintf(sortedfil,"ENDATA\n");
  closeFile(sortedfil); 

  return;

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
* checkNumeric(char *token): check if token has numeric form
* --------------------------------------------------------
***************************************************************/
int checkNumeric(char *token) {

  int j, n;

/*
 *  token is considered numeric if each character
 *  is one of the following:
 *  1 2 3 4 5 6 7 8 9 + - .
 */
  for(j=0; j<=strlen(token)-1; j++)  {
    n = (int)token[j];
    if (((n<48)||
         (n>57))&&
        (n!=43)&&
        (n!=45)&&
        (n!=46)) {
      return FALSE;    
    }
  } /* end for j */

  return TRUE;

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
* identicalLogic(int i, int j): decide if subgroup[i] and
*           subgroup[j] are logically identical; that is, if
*           the target case and explanation are the same up to
*           differences in numerical values of bounds.
*           output: TRUE if records i and j are logically identical
*                   FALSE otherwise
* --------------------------------------------------------
***************************************************************/
int identicalLogic(int i, int j) {

  int len[2], k, m, n;

  char rec[2][MAX_RECLEN];
  char token[2][MAX_RECLEN][MAX_RECLEN];
  char *buffer;

  for (k=1; k<=subgroup[i].numRecord; k++) {
    strcpy(rec[0],subgroup[i].record[k]);
    strcpy(rec[1],subgroup[j].record[k]);

    /* check for end of comparison */
    if ((strncmp(rec[0],"TESTING",6) == 0) &&
        (strncmp(rec[1],"TESTING",6) == 0)) {
      return TRUE;
    }
    if ((strncmp(rec[0],"TESTING",6) == 0) ||
        (strncmp(rec[1],"TESTING",6) == 0)) {
      return FALSE;
    }

    /* extract tokens from rec[0] and rec[1] */
    for (n=0; n<=1; n++) {
      buffer = strtok(rec[n]," \t\n()");
      m = 0;  
      while (buffer != NULL) {
        m++; 
        strcpy(token[n][m],buffer);
        buffer = strtok(NULL," \t\n()");
      }
      len[n] = m;
    } /* end for n */

    if ((len[0] == 0) && (len[1] == 0)) {
      continue;
    }

    if (len[0] != len[1]) {
      /* rec[0] and rec[1] are not logically identical */
      return FALSE;
    }   

    for (m=1; m<=len[0]; m++) {
      if ((strcmp(token[0][m],token[1][m]) != 0) &&
          ((checkNumeric(token[0][m]) == FALSE) ||
          (checkNumeric(token[1][m]) == FALSE))) {
        /* rec[0] and rec[1] are not logically identical */
        return FALSE;
      }
    }
  } /* end for k */

  /* should never get here */
  sub2error("Error: should not reach this part of code",
            "301","identicalLogic");

  /* statement added to suppressor compiler warning */
  return FALSE;
}

/* last record of outputSortedSub.c *****/
