/* first record of extractBestCases.c *****/
#include "sub2cc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   int extractBestCases() extract best cases from .sub.ats and
 *                          .sub.mst files
 */
/**************************************************************/
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  extractBestCases(): extract and sort best subgroup pairs from
*                      files .sub.ats and .sub.mst
* --------------------------------------------------------
***************************************************************/
int extractBestCases() {

  char fileRecAts[MAXLEN];
  char fileRecMst[MAXLEN];
  char name[MAXLEN];
  float fract, significance;

  int lastComp, flag, i, j, k, m, n, ntry;
  int msubgroup, mtotal, moppositesubgroup, moppositetotal;
  /* msubgroup = number of cases in subgroup with implied feature
   * mtotal = number of cases with implied feature
   * moppositesubgroup = number of cases in subgroup not having
   *          the implied feature
   * moppositetotal = number of cases not having implied feature
   * def: 'case in subgroup': satisfies factors defining subgroup
   * def: 'implied feature': 'low', 'high', middle', or 'lowhigh'
   */
  double p;

  FILE* atsfil;
  FILE* mstfil;

  lastComp = 0;       /* to suppress compiler warning */
  moppositesubgroup = 0; /* to suppress compiler warning */
  p = 0.0;            /* to suppress compiler warning */


  /* open .ats.sub, .mst.sub files */
  sprintf(name,"%s%s%s%s",
          gParams.directory, gParams.prefix, 
          gFileExt.ats, gFileExt.sub);
  atsfil = openFile(name,"r");

  sprintf(name,"%s%s%s%s",
          gParams.directory, gParams.prefix, 
          gFileExt.mst, gFileExt.sub);
  mstfil = openFile(name,"r");

  /* initialize number of subgroups */
  numSubgroup = 0;  
/*eject*/  
  while (fgets(fileRecAts,MAX_RECLEN,atsfil) != 0) { /* while #1 */

    if (strncmp(fileRecAts,"SUBGROUP",8) == 0) {

      numSubgroup++;
      if (numSubgroup > MAX_SUBGROUP) {
        sub2error(
       "Error, number of subgroups exceeds MAX_SUBGROUP",
       "extractBestCases","101");
      }

      /* get significance value for the .ats subgroup case */
      sscanf(fileRecAts,"SUBGROUP %d significance = %f",
             &n, &significance);
      if (n != numSubgroup) {
        sub2error(
       "Error, wrong SUBGROUP number in .sub.ats file",
       "extractBestCases","102");
      }
      subgroup[numSubgroup].significanceAts = significance;

      /* store subgroup records of .sub.ats case */
      i = 1;
      flag = 0; /* used to identify first 'Coverage' record */
/*eject*/
      while (fgets(subgroup[numSubgroup].record[i],
                   MAX_RECLEN,atsfil) != 0) { /* while #2 */

        if ((strncmp(subgroup[numSubgroup].record[i],
                   "    Coverage for",16) == 0) &&
            (flag == 0)) {
          /* save i-1 as index of last record to be */
          /* compared with .sub.mst records for case match */
          lastComp = i-1;
          /* insert 'TESTING' record above 'Coverage' record */
          i++;
          if (i > MAX_RECORD) {
            sub2error("Error, subgroup case too large",
                      "extractBestCases","201");
          }
          /* move 'Coverage' from current record i-1 to i */
          strcpy(subgroup[numSubgroup].record[i],
                 subgroup[numSubgroup].record[i-1]);
          /* insert 'TESTING' into i-1 record */
          sprintf(subgroup[numSubgroup].record[i-1],
                  "TESTING significance = %f\n\n",
                  subgroup[numSubgroup].significanceAts);
          flag = 1;                     
        }
        /* extract counts for evaluation of alternate hypothesis */
        if (strncmp(subgroup[numSubgroup].record[i-1],
                   "    Coverage for",16) == 0) {
          if (flag == 1) {
            sscanf(subgroup[numSubgroup].record[i-1],
                   " Coverage for %s",
                   subgroup[numSubgroup].impliedCase);
            sscanf(subgroup[numSubgroup].record[i],
                   " %d out of %d",
                   &msubgroup, &mtotal);
            flag = 2;
          } else if (flag == 2) {
            sscanf(subgroup[numSubgroup].record[i-1],
                   " Coverage for %s",
                   subgroup[numSubgroup].oppositeCase);
            sscanf(subgroup[numSubgroup].record[i],
                   " %d out of %d",
                   &n, &moppositetotal);
            moppositesubgroup = moppositetotal - n;
          }
        } /* end if strncmp(subgroup[numSubgroup].... */
/*eject*/
        if (strncmp(subgroup[numSubgroup].record[i],
            "  VC dim estimate",17) == 0) {
          break; /* break while #2 */
        }
        i++;
        if (i > MAX_RECORD) {
          sub2error("Error, subgroup case too large",
                    "extractBestCases","203");
        } 
      } /* end while #2 */
/*eject*/
      /* find corresponding subgroup in .sub.mst file
       * by matching records from 'TARGET m STAGE n ..'
       * up to but not including 'Coverage for ..' record
       */
 
      ntry = 1; /* number of tries to find matching subgroup */ 
     
      while (fgets(fileRecMst,MAX_RECLEN,mstfil) != 0) {/* while #3 */

        /* test for ENDATA record of .sub.mst file */
        if (strncmp(fileRecMst,"ENDATA",6) == 0) {
          if (ntry == 1) {
            /* this is first try to find matching subgroup */
            /* close .mst file, open .mst file, begin search again */
            closeFile(mstfil);
            sprintf(name,"%s%s%s%s",
                    gParams.directory, gParams.prefix, 
                    gFileExt.mst, gFileExt.sub);
            mstfil = openFile(name,"r");
            ntry = 2;
            continue;
          }
          /* cannot find matching subgroup, even when entire */
          /* .mst file is searched */
          sub2error("Error, unexpected ENDATA in .sub.mst file",
                    "extractBestCases","301");          
        }

        if (strncmp(fileRecMst,"SUBGROUP",8) == 0) {

          /* have SUBGROUP record */
          /* tentatively store significance value */
          /* and compute average significance */
          sscanf(fileRecMst,"SUBGROUP %d significance = %f",
             &n, &significance); /* note: n may differ from */
                                 /*       numSubgroup */
          subgroup[numSubgroup].significanceMst = significance;
          subgroup[numSubgroup].significanceAverage = 
               (subgroup[numSubgroup].significanceAts + 
                subgroup[numSubgroup].significanceMst)/2.0;
/*eject*/        
          /* check whether subgroup is same as .sub.ats case */
                   
          flag = 1; /* 0: does not match .sub.ats case */
                    /* 1: have match */
          j = 1;

          while (fgets(fileRecMst,MAX_RECLEN,mstfil) != 0) {
                                                   /* while #4 */
            if (strcmp(fileRecMst,
                 subgroup[numSubgroup].record[j]) != 0) {
               /* this is a different subgroup */
               flag = 0;
               break; /* break while #4 */
            }
            if (j == lastComp) {
              /* have a match of subgroup case */
              break; /* break while #4 */
            }
            j++;
          } /* end while #4 */  
/*eject*/
          if (flag == 0) {
            /* look for next .sub.mst SUBGROUP case */
            continue; /* continue while #3 */
          } else { 
            /* have matching SUBGROUP case */
            /* restore ntry = 1 */
            ntry = 1;
            /* store subgroup records of .sub.mst case */
            /* insert 'TRAINING' record */
            i++;
            if (i > MAX_RECORD) {
              sub2error("Error, subgroup case too large",
                        "extractBestCases","303");
            }
            sprintf(subgroup[numSubgroup].record[i],
                    "\nTRAINING significance = %f\n\n",
                    subgroup[numSubgroup].significanceMst);

            i++;
            if (i > MAX_RECORD) {
              sub2error("Error, subgroup case too large",
                        "extractBestCases","304");
            } 

            /* store records of .sub.mst file */
            while (fgets(subgroup[numSubgroup].record[i],
                   MAX_RECLEN,mstfil) != 0) { /* while #5 */

              if (strncmp(subgroup[numSubgroup].record[i],
                  "  VC dim estimate",17) == 0) {
                break; /* break while #5 */
              }
              i++;
              if (i > MAX_RECORD) {
                sub2error("Error, subgroup case too large",
                          "extractBestCases","501");
              } 
            } /* end while #5 */
            break; /* break while #3 */    
          } /* end if/else flag == 0 */
        } /* end if strncmp(fileRecMst,"SUBGROUP",8) == 0 */

      } /* end while #3 */
/*eject*/
      /* compute probability under alternate hypothesis
       * = Prob[>= msubgroup cases that satisfy factors among a total
              of mtotal cases | alternate hypothesis]
       * = Prob[<= moppositesubgroup cases that satisfy factors
       *        among a total of moppositetotal cases | 
       *        alternate hypothesis]
       * where alternate hypothesis is a sequence of Bernoulli
       * trials with probability p of case satisfying factors where 
       * p = (msubgroup + moppositesubgroup)/(mtotal + moppositetotal)
       */
      if (((msubgroup+moppositesubgroup) > 0) &&
           ((mtotal+moppositetotal) > 0))  {
        p = ((double)(msubgroup+moppositesubgroup))/
            ((double)(mtotal+moppositetotal));
        subgroup[numSubgroup].probAlternateHypothesis = 
          binomial(p,moppositetotal,moppositesubgroup);
      } else {
        subgroup[numSubgroup].probAlternateHypothesis = 0.999;      
      }      
      i++;
      if (i > MAX_RECORD) {
        sub2error("Error, subgroup case too large",
                  "extractBestCases","302");
      }   
      sprintf(subgroup[numSubgroup].record[i],
      "\n  Define N = number of %s cases satisfying above factors\n",
      subgroup[numSubgroup].oppositeCase);
      i++;
      if (i > MAX_RECORD) {
        sub2error("Error, subgroup case too large",
                  "extractBestCases","303");
      }   
      sprintf(subgroup[numSubgroup].record[i],
        "  Testing has produced value %d - %d = %d for N\n",
        moppositetotal, moppositetotal-moppositesubgroup, 
        moppositesubgroup);
      i++;
      if (i > MAX_RECORD) {
        sub2error("Error, subgroup case too large",
                  "extractBestCases","304");
      }
      sprintf(subgroup[numSubgroup].record[i],
      "  Probability[ N <= %d | alternate hypothesis ] = %f\n",
       moppositesubgroup, 
       subgroup[numSubgroup].probAlternateHypothesis);
/*eject*/
      /* estimate probability under alternate hypothesis
       * for assumed number n of test records
       * estimate the number of records m that are in the
       * subgroup and opposite class as
       * m = (moppositesubgroup/moppositetotal) * n
       */
      for (k=1; k<=7; k++) {

        /* define sample size n */
        if (k <= 5) {
          n = 10 * k;
        } else {
          n = 25 * (k-3);
        }
/*eject*/
        if (k == 1) {
          /* write header */
          i++;
          if (i > MAX_RECORD) {
            sub2error("Error, subgroup case too large",
                  "extractBestCases","306");
          }
          sprintf(subgroup[numSubgroup].record[i],
          "\n/*eject*/\n");
          i++;
          if (i > MAX_RECORD) {
            sub2error("Error, subgroup case too large",
                  "extractBestCases","307");
          }
          sprintf(subgroup[numSubgroup].record[i],
          "  Guide for Selection of Additional Test Records\n\n");
          i++;
          if (i > MAX_RECORD) {
            sub2error("Error, subgroup case too large",
                  "extractBestCases","308");
          }
          sprintf(subgroup[numSubgroup].record[i],
          "    No. of Test   Est. N in   Est. Probability Given\n");
          i++;
          if (i > MAX_RECORD) {
            sub2error("Error, subgroup case too large",
                  "extractBestCases","309");
          }
          sprintf(subgroup[numSubgroup].record[i],
          "    Records of      Subgroup    Alternate Hypothesis\n");
          i++;
          if (i > MAX_RECORD) {
            sub2error("Error, subgroup case too large",
                  "extractBestCases","310");
          }
          sprintf(subgroup[numSubgroup].record[i],
          "    Type %s\n",subgroup[numSubgroup].oppositeCase);
        }
/*eject*/
        /* output test set size and probability */
        fract = moppositesubgroup;
        fract /= moppositetotal;
        fract *= n;
        m = fract + 0.5;
        if (m < n) {
          fract = binomial(p,n,m);
        } else {
          fract = 0.999;
        }
        i++;
        if (i > MAX_RECORD) {
          sub2error("Error, subgroup case too large",
                    "extractBestCases","311");
        }
        sprintf(subgroup[numSubgroup].record[i],
        "      %4d           %4d            %f\n", n, m, fract);
      } /* end for k */      
/*eject*/
      subgroup[numSubgroup].numRecord = i;
      continue; /* continue while #1 */

    } /* end if strncmp(fileRecAts,"SUBGROUP",8) == 0 */

    /* test for ENDATA record of .sub.ats file */
    if (strncmp(fileRecAts,"ENDATA",6) == 0) {      
      closeFile(atsfil);
      closeFile(mstfil);
      return 0;
    }

  } /* end while #1 */
  
  sub2error("Error, missing ENDATA in .sub.ats file",
            "extractBestCases","901");  
  return 1; /* to suppress compiler warning */

} /* end of extractBestCases() */
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  binomial(double p, int n, int k): value of binomial distribution
*       with probability p and a total of n items, summing
*       up the terms for m = 0, 1, .., k
* --------------------------------------------------------
***************************************************************/
double binomial(double p, int n, int k) {

  int j;
  double dist, term;

  /* check correctness of input parameters */
  if ((p < 0.0) || (p > 1.0)) {
    sub2error(
    "Error: parameter p must be 0 <= p <= 1\n",
    "binomial","101");
  }
  if (n <= 0) {
    sub2error(
    "Error: parameter n must be > 0\n",
    "binomial","102");
  } 
  if ((k < 0) || (k > n)) {
    sub2error(
    "Error: parameter k must be 0 <= k <= n\n",
    "binomial","103");
  }

  /* trivial cases */
  if (p == 0.0) {
    return 1.0;
  }
  if (p == 1.0) {
    if (k < n) {
      return 0.0;
    } else {
      return 1.0;
    }
  }

  /* compute sum_{j=0}^{j=k} nChoosej * p^j * (1-p)^{n-j} */
  /* nChoosej = n!/(j!(n-j)!) */

  /* term for j = 0 */
  term = pow(1-p,(double)n);
  dist = term;
  /* terms for j = 1, 2, .., k */
  for (j=1; j<=k; j++) {
    term *= (p / (1-p)) * ((double)(n-j+1)) / ((double)j);
    dist += term;  
  }
  
  return dist; 

}

/* last record of extractBestCases.c *****/
