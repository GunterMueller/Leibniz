/* first record of sub2cc.h *****/

/******************* Includes ***********************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <math.h>
#include <time.h>

/******************* Input Maximums ****************************/
#define MAXLEN 1000
#define MAX_ID 256
#define MAX_SUBGROUP 6000  /* max number of subgroups */
#define MAX_RECORD    100  /* max number of records */
                           /* describing a subgroup */
#define MAX_RECLEN    128  /* max lenth of a record */
#define MAX_DIRECTORY 256

/*************** Attribute and Record Types *******************/
#define NEWTGT 21
#define OLDTGT 22
#define TGTONLY 23
#define ALTERNATE 31
#define MASTER 32
#define DEFMAX 40
#define DEFMIN 41

/************* Miscellaneous Constants *********************/
#define FALSE 0
#define TRUE 1
#define INFTY 999999999.0
#define NEGINFINITY -999999999.0
#define EPSILON 0.0001

/******************* Decision Constants *********************/
#define UNUSUALNESS 1
#define ACCURACY 2
#define BOTH 12
#define ALL 13
#define REPRESENTATIVE 14
/*eject*/
/******************* Custom Data Types **********************/
/* parameters */
struct {
  char  prefix[MAX_ID];
  char  directory[MAX_DIRECTORY];
  char  leibnizpath[MAX_DIRECTORY];
  char  subccdetaildir[MAX_DIRECTORY+MAX_ID];
  char  master2masterABprogram[MAX_DIRECTORY+MAX_ID];
  int   selectOutput;
  float attributeImportanceThreshold;
  int   maxAttributesUsed;
  int   significanceMeasure;
  float subgroupThreshold;
  int   maxExpansion;
  int   defSizeSubgroup;
  int   sortSplitRatio;
} typedef SubccParams;

/* file extensions */
struct {
  char mst[32];
  char mstAB[32];
  char rtr[32];
  char rts[32];
  char rtsA[32];
  char rtsB[32];
  char rtsEqrtr[32];
  char ats[32];
  char rul[32];
  char cut[32];
  char sep[32];
  char sub[32];
  char tgt[32];
  char vot[32];
  char votA[32];
  char votB[32];
} typedef FileExtensions;
/*eject*/
/* subgroup description */
struct {
float significanceAts; /* significance of subgroup, .ats data */
float significanceMst; /* significance of subgroup, .mst data */
float significanceAverage; /* average significance of subgroup */
                 /* 'alternate' case: using .ats and .mst data */
                 /* 'master' case:    using .mst data */
float probAlternateHypothesis; /* probability of event under */
                 /* alternate hypothesis, which is sequence of */
                 /* Bernoulli trials and produces a binomial */
                 /* distribution */
char impliedCase[MAX_ID]; /* string characterizing of subgroup */
                 /* cases: "low", "high", "middle", "low/high" */
char oppositeCase[MAX_ID];/* opposite case */
char record[MAX_RECORD+1][MAX_RECLEN]; 
                      /* records of subgroup */
int numRecord; /* number of records for one subgroup case */
} typedef SubgroupData;
/*eject*/
/******************* Global Variables ***********************/
char lsqccparamsname[MAX_ID];

/* display and control */
int gNumOpenFiles;
int gShowSteps;
int gShowTargetSteps;
int gOutputVariations;
int gKeepSubccdetail;
int gSelectTargetFile;
int gSelectTestFile;

/* control/path parameters */
SubccParams gParams;
 
/* file extensions */
FileExtensions gFileExt;

/* error file */
FILE* errfil;

/* error flag for entire process */
/*  = 0: no errors */
int errorflag;
/*eject*/
/******************* Subgroup Description ***********************/
SubgroupData subgroup[MAX_SUBGROUP+1]; /* contains description of */
                                       /* subgroups */
int numSubgroup; /* total number of subgroups in subgroup[] array */

int sortedIndex[MAX_SUBGROUP+1]; 
                /* sortedIndex[isort] = index of subgroup that is */
                /* in position isort of the ordered subgroups     */
/*eject*/
/******************** Subroutines **************************/

int  sub2cc();

/*********** extractBestCases.c ************/
int extractBestCases();
double binomial(double p, int n, int k);

/************** readFiles.c *************/
void lowerCase(char *ch);
int  parse_param(char *lhs, char *rhs, char *record, 
                 FILE *params);
void readParamsFile();
void shiftLeft(char fileRec[]);

/*********** outputSortedSub.c ************/
void outputSortedSub(char* sortedfile);
int  checkNumeric(char *token);
int  identicalLogic(int i,int id);

/***************** util.c ******************/
void bubbleSort(double *a, int *idx, int n);

void closeFile(FILE* file);
FILE* openFile(char* name, char* mode);
FILE* openFilePrefix(char* extension, char* mode);
FILE* openFileSubccdetail(char* name, char* mode);

void  showSortSteps(char *message);
int   stringCompare(const char *a, const char *b, int n);
void  sub2error(char *m1,char *m2,char *m3);

/************** xRoutines.c ***************/
int Xsubcc();

/* last record of sub2cc.h *****/
