/* first record of xRoutines.c *****/
#include "sub2cc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   int Xsubcc()
 */
/**************************************************************/
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  Xsubcc(): apply subcc
* --------------------------------------------------------
***************************************************************/
int Xsubcc() {

  char cmnd[MAXLEN];

  sprintf(cmnd,"%sSubcc/Code/subcc %s",
          gParams.leibnizpath,lsqccparamsname);

  return(system(cmnd));

}

/**** last record of xRoutines.c ****************/
