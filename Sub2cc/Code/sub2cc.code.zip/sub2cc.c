/* first record of sub2cc.c *****/
/*
 *   Leibniz System: Sub2cc System
 *   Copyright 2008 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * ===================================================
 * Sub2cc System - Callable Subgroup Version sub2cc
 * ===================================================
 *
 *  caution: 
 *   - parameters must have been obtained 
 *     (see readParamsFile() for required information)
 *   - errfil must have been opened (see subccmain() program)
 *   - errfil must be closed after execution of subcc
 *  caution: these conditions are not checked by the program 
 * -----------------------------------------------------------
 *  Leibniz programs used:
 *  Subcc: subcc
 * -----------------------------------------------------------
 */
#include "sub2cc.h"
/***********************************************************/	
int sub2cc() {

  char cmnd[MAXLEN];
  char name[MAXLEN];
  char sortedfile[MAXLEN];

  int i;

  double a[MAX_SUBGROUP+1];

  /* initialize errorflag */
  errorflag = 0;

  /* initialize gNumOpenFiles */
  gNumOpenFiles = 0;

  /* target option 'tgt only' */
  if (gSelectTargetFile == TGTONLY) {
    /* execute subcc */
    showSortSteps("Execute subcc with 'tgt only' option\n");
    if (Xsubcc() != 0) {
      sub2error("Error, execution of subcc with 'tgt only' option",
                "sub2cc","101");
    }    
    if (gNumOpenFiles != 0) {
      sub2error("mismatch of opened/closed files","sub2cc","801");
    }  
    return errorflag;   
  }

  if (gSelectTestFile == MASTER) {
    showSortSteps("Derive subgroups solely from .mst file\n");
  } else { /* ALTERNATE case */
    showSortSteps(
      "Derive subgroups from .mst and .ats files\n");
  }

  /* regular case of sub2cc */
  /* execute subcc */
  showSortSteps("Execute subcc\n");
  if (Xsubcc() != 0) {
    sub2error("Error, execution of subcc ",
              "sub2cc","102");
  }

  /* if gSelectTestFile == MASTER, copy mst.sub output file */
  /* to .ats.mst file */
  if (gSelectTestFile == MASTER) {
    sprintf(cmnd,"cp %s%s%s%s %s%s%s%s",
            gParams.directory, gParams.prefix, 
            gFileExt.mst, gFileExt.sub,
            gParams.directory, gParams.prefix, 
            gFileExt.ats, gFileExt.sub);
    if ( system(cmnd) != 0) {
      sub2error("Error, copy .sub file to .sub.mst file ",
                "sub2cc","102");    
    }
  }

  /* extract best cases from outputfiles ats.sub and .mst.sub */
  if (extractBestCases() != 0) {
    sub2error(
       "Error, extraction of best cases, .sub.ats and .sub.mst",
       "subc22","301");
  }

  /* sort subgroup cases according to average significance */
  for (i = 1; i<=numSubgroup; i++) {
    a[i] = subgroup[i].significanceAverage;
    sortedIndex[i] = i;
  }
  bubbleSort(a,sortedIndex,numSubgroup);
   
  /* output sorted subgroup cases */
  sprintf(sortedfile,"%s%s%s2",
	  gParams.directory, gParams.prefix,
          gFileExt.sub);
  outputSortedSub(sortedfile);

  sprintf(name,"Output in file %s\n\n",sortedfile);
  showSortSteps(name);

  if (gNumOpenFiles != 0) {
    sub2error("mismatch of opened/closed files","sub2cc","901");
  }
  
  return errorflag;
	
}

/***********************************************************/	

/* last record of sub2cc.c *******/
    
