/* first record of util.c *****/
#include "sub2cc.h"
#include "features.h" /* system version selection */
/**************************************************************/
/*
 * subroutines in this file:
 *   void bubbleSort(double* a, int *idx, int n);
 *   void  closeFile(FILE* file);
 *   FILE* openFile(char* name, char* mode)
 *   FILE* openFilePrefix(char* extension, char* mode)
 *   FILE* openFileSubccdetail(char* name, char* mode)
 *   void  showSortSteps(char *message)
 *   void  sub2error(char *m1,char *m2, char *m3)
 */
/***************************************************************/
/*eject*/
/***************************************************************
 *--------------------------------------------------------------
 * bubbleSort(double *a, int *idx, int n):
 *   input:  a[] array with n entries
             idx[i] = i for all i
 *   output: a[] with entries sorted in decreasing order
             idx[i] = original index of a[] value now in position i.
 *--------------------------------------------------------------
 ***************************************************************/
void bubbleSort(double *a, int *idx, int n) {

  int flag, i, j, k;
  double b;

  for (k=n-1; k>=1; k--) {

    flag = 0;

    for (i=1; i<=k; i++) {
      if (a[i] < a[i+1]) {
        b = a[i];
        a[i] = a[i+1];
        a[i+1] = b;
        j = idx[i];
        idx[i] = idx[i+1];
        idx[i+1] = j;
        flag = 1;
      }
    } /* end for i */

    if (flag == 0) {
      return;
    }
 
  } /* end for k */

  return;

} /* end bubbleSort */
/*eject*/
/***************************************************************/
void closeFile(FILE* file) 
{
  fclose(file);
  gNumOpenFiles--;
  return; 
}
/***************************************************************/
FILE* openFile(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,"Error opening %s \n for %s. Stop.\n",
                  name, mode);
          sub2error(message,"openFile","101");
	}

        gNumOpenFiles++;	
	return out;
}
/****************************************************************/
FILE* openFilePrefix(char* extension, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,gParams.directory);
	strcat(file,gParams.prefix);
	strcat(file,extension);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,
            "Error opening %s \n for %s. Stop.\n", file, mode);
	  sub2error(message,"openFilePrefix","101");
	}	

        gNumOpenFiles++;	
	return out;
}
/****************************************************************/
FILE* openFileSubccdetail(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,gParams.subccdetaildir);
	strcat(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,
              "Error opening %s \n for %s. Stop.\n", file, mode);
          sub2error(message,"openFileSubccdetail","101");
	}	

        gNumOpenFiles++;	
	return out;
}	
/*eject*/
/****************************************************
 * showSortSteps(): show sorting steps 
 ****************************************************/
void showSortSteps(char *message) {

  printf("%s",message);
  fprintf(errfil,"%s",message);

  return;
}
/*eject*/
/***************************************************************
* stringCompare(): convert to upper case then compare
****************************************************************/
int stringCompare(const char *a, const char *b, int n)
{
	int i;
	char aPrime[MAX_ID] = {'\0'};

	/* Convert "a" to upper case */
	for (i=0;i<n;i++)
	{

		if (a[i] >=  97 && a[i] <= 122)
			aPrime[i] = a[i] - 32;
		else
			aPrime[i] = a[i];
	}

	return strncmp(aPrime, b, n);

}
/*eject*/
/***************************************************************
*  sub2error(): sub2cc system error termination 
****************************************************************/
void sub2error(char *m1,char *m2, char *m3) {
/*
 */
  printf("%s\nStop\n",m1);
  fprintf(errfil,"%s\nStop\n",m1);

  printf("\n*******SUB2CC SYSTEM ERROR*******\n");
  printf("ERROR IN %s  code %s\n",m2,m3);
  printf("**********************************\n");
  printf("For details, see error file sub2cc.err\n");
/*
 */
  fprintf(errfil,"\n*******SUB2CC SYSTEM ERROR*******\n");
  fprintf(errfil,"ERROR IN %s  code %s\n",m2,m3);
  fprintf(errfil,"**********************************\n");
  exit(1);

}
/* last record of util.c *******/
