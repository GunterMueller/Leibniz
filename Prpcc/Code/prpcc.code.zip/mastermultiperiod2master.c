#include "prpcc.h"

#define curveterm(t) 0.0
        /* typical options for curveterm:
         * sqrt(t)  square root function
         * pow(t,2) quadratic function
         * log(t)   log function
         * 1.0*t    identity function
         */
#define approxfunction(a,b,c,t) a+b*t+c*curveterm(t)

/* Global Input and Output files */
FILE *inputmstfile;
FILE *statfile;
FILE *outputmstfile;
char inputmst_filename[MAX_ID];
char stat_filename[MAX_ID];
char outputmst_filename[MAX_ID];
char lineread[MAXLEN] = {'\0'};
char token[MAX_ENTRY] = {'\0'};
char outputline[MAXLEN] = {'\0'};
char outputtoken[MAX_ATTRIBUTE+1][MAX_ENTRY];
char delimiter = ',';      /* set delimiter */

/* Global Structure for Attributes */
char attribute[MAX_ATTRIBUTE+1][MAX_ENTRY];
char attributeString[MAX_ATTRIBUTE+1][MAX_ENTRY];
int numAttributes = 0;

/* Global Structure for Records and their Values */
int numBeginAttributes;
int numEndAttributes;
int numTimeAttributes;
double timePoint[MAX_TIME_POINT+1];
int numTimePoints;
int numTotalTimeAttributes; /* = numTimeAttributes * numTimePoints */
int numOverallAttributes; /* = overall number of attributes */
double usedTimePoint[MAX_TIME_POINT+1];
int numUsedTimePoints;
double attributeValue[MAX_TIME_POINT+1];

/* Global Structure for function representation */
struct {
  double constant;   /* constant of estimating function */
  double slope;      /* slope of estimating function */
  double curve;      /* coefficient of nonlinear term defined */
                     /*   in curveterm(t) */
                     /* values of function and average slopes: */
  double beginvalue; /*   value at t = first time point */
  double midvalue;   /*   value at t = halfway first - last point */
  double endvalue;   /*   value at t = last time point */
  double beginslope; /*   slope from beginvalue to midvalue */
  double endslope;   /*   slope from midvalue to endvalue */
  double totalslope; /*   slope from beginvalue to endvalue */
} typedef Coefficients;
Coefficients function;

/* global Structure for Control and Ridge Factor */
char control[MAX_ID] = {'\0'};
double ridgeFactor = 1.01;  /* = 1.0 means no ridge effect */

/* Function Prototypes */
void computeFunctionResults();
void getAttributes();
int  getLineread();
void getLinearFunction();
void getNonlinearFunction();
int  getIndex(char *attribute);
void getValueSlope();
void lineread2outputline();
void openFiles();
void outputline2outputtoken();
void readStats();

/*eject*/
/* CAUTION: There must be at least two time points */

/* main function */
int main(int argc, char *argv[])
{

  int i;

  if (argc != 4) {
    printf("Calling Sequence: ./mastermultiperiod2master input.mst input.stat output.mst\n");
    exit(1);
  }
  strcpy(inputmst_filename, argv[1]);
  strcpy(stat_filename, argv[2]);
  strcpy(outputmst_filename, argv[3]);

  /* DEBUG: uncomment below and comment out above */
  /* strcpy(inputmst_filename, "multiperiod.mst");
  strcpy(stat_filename, "multiperiod.stat");
  strcpy(outputmst_filename, "multiperiod.output.mst"); */

  openFiles();

  /* read statistics file */
  readStats();

  /* get attributes */
  getAttributes();
/*eject*/
 /* process data */
  /* Read records and put into DATA section of master file */
  while (getLineread() == 1) {

    if (strcmp(token,"ENDATA") == 0) {
       fprintf(outputmstfile,"ENDATA\n"); 
       fclose(inputmstfile);
       fclose(statfile);
       fclose(outputmstfile);
       return 0;
    }

    /* copy lineread record to outputline */
    strcpy(outputline,lineread);

    /* break up outputline into output tokens */
    outputline2outputtoken(outputline,outputtoken);

    /* write out values of begin attributes as strings */
    for (i=1; i<=numBeginAttributes; i++) {
      fprintf(outputmstfile,"%s\t",outputtoken[i]);
    }

    /* compute and write out function results */
    /* for all time attributes */
    computeFunctionResults();

    /* write out values of end attributes as strings */
    for (i=1; i<=numEndAttributes; i++) {
      fprintf(outputmstfile,"%s\t",
        outputtoken[numBeginAttributes+numTotalTimeAttributes+i]);
    }

    fprintf(outputmstfile,"\n");

  } /* end while loop */

  fprintf(stderr,"mastermultiperiod2master: Unexpected end of ");
  fprintf(stderr,"input mst file %s\n",inputmst_filename);
  exit(1);

} /* end main */
/*eject*/
/*********************************************************
 *  computeFunctionResults()
 * 
 *  purpose:  compute and write out function results for
 *            all time attributes
 *            
 *********************************************************/
void computeFunctionResults() {

  int i, j, n;

  for (i=1; i<=numTimeAttributes; i++) {
    numUsedTimePoints = 0;
    for (j=1; j<=numTimePoints; j++) {
      /* get values from outputtoken[] strings */
      n = numBeginAttributes + (j-1)*numTimeAttributes + i;
      if (strcmp(outputtoken[n],"?") != 0) {
        /* have actual value */
        numUsedTimePoints++;
        usedTimePoint[numUsedTimePoints] = timePoint[j];
        attributeValue[numUsedTimePoints] = atof(outputtoken[n]);
      }
    } /* end for j */
/*eject*/
    if (numUsedTimePoints <= 1) {
      /* consider all values for attribute i to be unknown */
      /* use "?" for all function results of attribute */
      fprintf(outputmstfile,"?\t?\t?\t?\t?\t?\t");
    } else {
      /* have >=2 values for attribute i */
      if (numUsedTimePoints == 2) {
        /* compute constant, slope via subroutine that */
        /* generally uses regression */  
        getLinearFunction();
      } else { 
        /* have >=3 values */
        /* use regression to compute constant, slope, curve */
        getNonlinearFunction();
      }
      /* compute and output beginvalue,midvalue,endvalue,*/
      /*                    beginslope,endslope,totalslope */
      getValueSlope();
      fprintf(outputmstfile,"%f\t%f\t%f\t%f\t%f\t%f\t",
        function.beginvalue,function.midvalue,function.endvalue,
        function.beginslope,function.endslope, function.totalslope);
    } /* end if numUsedTimePoints == 0, else */
      
  } /* end for i */

  return;

}
/*eject*/
/*********************************************************
 *  getAttributes
 * 
 *  purpose:  get attributes
 *            
 *********************************************************/
void getAttributes() {

  int n;

  numAttributes = 0;

  /* process attributes section */
  getLineread();
  /* must have ATTRIBUTES record */
  if (strcmp(token,"ATTRIBUTES") != 0) {
    fprintf(stderr,
    "mastermultiperiod2master: Error: attributes section \n");
    fprintf(stderr,
    "                          out of order, case 1\n");
    fprintf(stderr,
    "current line = %s\n",lineread);
    exit(1);
  }
  fprintf(outputmstfile,"%s\n",lineread);

  /* process attributes */
  for (n=1; n<=numOverallAttributes; n++) {
    getLineread();
    if (strcmp(token,"DATA") == 0) {
      fprintf(stderr,
      "mastermultiperiod2master: Error: attributes section \n");
      fprintf(stderr,
      "                          out of order, case 2\n");
      fprintf(stderr,
      "current line = %s\n",lineread);
      exit(1);
    }
    /* begin or end attribute */
    if ((n <= numBeginAttributes) ||
        (n > numBeginAttributes + numTotalTimeAttributes)) {
            /* list begin/end attribute in output master file */
            fprintf(outputmstfile,"%s\n",lineread);
      numAttributes++;
      if (numAttributes > MAX_ATTRIBUTE) {
        fprintf(stderr,
        "mastermultiperiod2master: MAX_ATTRIBUTE too small\n");
        exit(1);
      }
      continue;
    }
    /* time attribute */
    if (n <= (numBeginAttributes+numTimeAttributes)) {
      /* have attribute of first time period
       * list all related attributes for this case
       * using appropriate suffix 
       *   _beginvalue 
       *   _midvalue  
       *   _endvalue   
       *   _beginslope
       *   _endslope
       *   _totalslope    
       */
      /* fule names */
      /* fprintf(outputmstfile,"%s_beginvalue\n",token);
      fprintf(outputmstfile,"%s_midvalue\t\n",token);
      fprintf(outputmstfile,"%s_endvalue\t\n",token);
      fprintf(outputmstfile,"%s_beginslope\t\n",token);
      fprintf(outputmstfile,"%s_endslope\t\n",token); 
      fprintf(outputmstfile,"%s_totalslope\t\n",token); */
     /* abbreviated names */
      fprintf(outputmstfile,"%s_bv\n",token);
      fprintf(outputmstfile,"%s_mv\t\n",token);
      fprintf(outputmstfile,"%s_ev\t\n",token);
      fprintf(outputmstfile,"%s_bs\t\n",token);
      fprintf(outputmstfile,"%s_es\t\n",token); 
      fprintf(outputmstfile,"%s_ts\t\n",token);
      numAttributes+= 6;
      if (numAttributes > MAX_ATTRIBUTE) {
        fprintf(stderr,
        "mastermultiperiod2master: MAX_ATTRIBUTE too small\n");
        exit(1);
      }
    } 
  } /* end for n */

  /* have processed all attributes */
  getLineread();
  if (strcmp(token,"DATA") != 0) {
    fprintf(stderr,
    "mastermultiperiod2master: Error: attributes section \n");
    fprintf(stderr,
    "                          out of order, case 3\n");
    fprintf(stderr,
    "current line = %s\n",lineread);
    exit(1);
  }

  fprintf(outputmstfile,"DATA\n");

  return;

}
/*eject*/
/*********************************************************
 *  getLineread
 * 
 *  purpose:  get next nonempty, noncomment line of inputmst file
 *            output: lineread (= line)
 *                    token (= first entry of lineread)
 *            
 *********************************************************/
int getLineread() {

  int i;

  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) {

    /* skip over empty and comment lines */
    if ((lineread[0] == '\n') ||
        (lineread[0] == '*')) {
      continue;
    }

    /* strip off carriage return/whitespace at end of line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* store first entry of lineread in token */
    sscanf(lineread,"%s",token);

    return 1;    
  }

  /* file has no non-empty and non-comment line */
  return 0;

}
/*eject*/
/*********************************************************
 *  getLinearFunction
 * 
 *  purpose:  get constant and slope of linear function
 *            by regression
 *            
 *********************************************************/
void getLinearFunction() {

  int i, j, m;
  double det;
  double mu, sigma2, muError, sigma2Error, ratio, val;

  /* caution: use indices 1,...,n and ignore index 0 */
  double Amatrix[MAX_TIME_POINT+1][3]; /* matrix of values */
  double Bmatrix[3][3]; /* = Amatrix^t * Amatrix */
  double Binverse[3][3]; /* inverse of Bmatrix */
  double bvector[MAX_TIME_POINT+1]; /* vector of attribute values */
  double bbar[3]; /* = Amatrix^t * bvector */
  double updatedbbar[3]; /* = Binverse * bbar */
                         /* = estimated function coefficients */

  /* define Amatrix and bvector */
  for (i=1; i<=numUsedTimePoints; i++) {
    Amatrix[i][1] = 1.0;
    Amatrix[i][2] = usedTimePoint[i];
    bvector[i] = attributeValue[i];
  }

  /* define bbar */
  for (i=1; i<=2; i++) {
    bbar[i] = 0.0;
    for (j=1; j<=numUsedTimePoints; j++) {
      bbar[i] += Amatrix[j][i] * bvector[j];
    }
  } 

  /* define Bmatrix = Amatrix^t * Amatrix */
  for (i=1; i<=2; i++) {
    for (j=1; j<=2; j++) {
      Bmatrix[i][j] = 0.0;
      for (m=1; m<=numUsedTimePoints; m++) {
        Bmatrix[i][j] += Amatrix[m][i] * Amatrix[m][j];
      }
    }
  }
/*eject*/
  /* define Binverse */
  det = Bmatrix[1][1]*Bmatrix[2][2] -
        Bmatrix[1][2]*Bmatrix[2][1];
  Binverse[1][1] =  Bmatrix[2][2]/det;
  Binverse[1][2] = -Bmatrix[2][1]/det;
  Binverse[2][1] = -Bmatrix[1][2]/det;
  Binverse[2][2] =  Bmatrix[1][1]/det;

  /* define updatedbbar */
  for (i=1; i<=2; i++) {
    updatedbbar[i] = 0.0;
    for (j=1; j<=2; j++) {
      updatedbbar[i] += Binverse[i][j] * bbar[j];
    }
  }

  /* define constant, slope, and curve */
  function.constant = updatedbbar[1];
  function.slope = updatedbbar[2];
  function.curve = 0.0;

  /* if slope is nonzero, emastermultiperiod2master.cstimate quality of function */
  if (fabs(function.slope) != 0) {

    /* estimate mean and variance of attribute values */
    /* mu = (1/n)sum xj */
    /* sigma2 = [(1/n)sum(xj^2)] - mu^2 */
    mu = 0.0;
    sigma2 = 0.0;
    for (i=1; i<=numUsedTimePoints; i++) {
      mu +=attributeValue[i];
      sigma2 += attributeValue[i] * attributeValue[i];
    }
    mu /= (double)numUsedTimePoints;
    sigma2 = (sigma2/(double)numUsedTimePoints) - mu * mu;

    /* estimate mean and variance of errors */
    muError = 0.0;
    sigma2Error = 0.0;
    for (i=1; i<=numUsedTimePoints; i++) {
      val = function.constant + 
            function.slope * usedTimePoint[i] -
            attributeValue[i];
      muError +=val;
      sigma2Error += val * val;
    }
    muError /= (double)numUsedTimePoints;
    sigma2Error = (sigma2Error/(double)numUsedTimePoints) - 
             muError * muError;

    /* estimate ratio of variances */
    ratio = sigma2Error/sigma2;
    /* if ratio >= REGRESSION_ERROR_THRESHOLD, */
    /*   reject regression and use mean mu */
    if (ratio >= REGRESSION_ERROR_THRESHOLD) {
      function.constant = mu;
      function.slope = 0.0;
    }        
  } /* end if fabs(function.slope) != 0 */

  return;

}
/*eject*/
/*********************************************************
 *  getNonlinearFunction
 * 
 *  purpose:  get constant, slope, and curve of nonlinear function
 *            by regression
 *            
 *********************************************************/
void getNonlinearFunction() {

  int i, j, k, m;
/* OBSOLETE code below, deleted Sept 3, 2010 */
//  double mu, sigma2, muError, sigma2Error, ratio, val;
  double pivot;

  /* caution: use indices 1,...,n and ignore index 0 */
  double Amatrix[MAX_TIME_POINT+1][4]; /* matrix of values */
  double Bmatrix[4][4]; /* = Amatrix^t * Amatrix */
  double Binverse[4][4]; /* inverse of Bmatrix */
  double bvector[MAX_TIME_POINT+1]; /* vector of attribute values */
  double bbar[4]; /* = Amatrix^t * bvector */
  double updatedbbar[4]; /* = Binverse * bbar */
                         /* = estimated function coefficients */

  /* define Amatrix and bvector */
  for (i=1; i<=numUsedTimePoints; i++) {
    Amatrix[i][1] = 1.0;
    Amatrix[i][2] = usedTimePoint[i];
    Amatrix[i][3] = curveterm(usedTimePoint[i]);
    bvector[i] = attributeValue[i];
  }

  /* define bbar */
  for (i=1; i<=3; i++) {
    bbar[i] = 0.0;
    for (j=1; j<=numUsedTimePoints; j++) {
      bbar[i] += Amatrix[j][i] * bvector[j];
    }
  } 

  /* define Bmatrix = Amatrix^t * Amatrix */
  for (i=1; i<=3; i++) {
    for (j=1; j<=3; j++) {
      Bmatrix[i][j] = 0.0;
      for (m=1; m<=numUsedTimePoints; m++) {
        Bmatrix[i][j] += Amatrix[m][i] * Amatrix[m][j];
      }
    }
  }
/*eject*/


  /* compute Binverse using in-place method */

  /* initialize Binverse */
  for (i=1; i<=3; i++) {
    for (j=1; j<=3; j++) {
      Binverse[i][j] = Bmatrix[i][j];      
    }
  }

  /* compute inverse in place */  
  for (k=1;k<=3;k++) {
    if (k == 2) {
      /* addition made Jan 2011:
       * after first pivot, each new entry Binverse'[i][i], i >= 2,
       * has become, in terms of the original matrix entries,
       * =  Binverse[i][i] - 
       *      (Binverse[i][1]*Binverse[1][i]/Binverse[1][1])
       * =  sum of squared x_i values - 
       *      n * (estimated mean for x_i)^2
       * =  n * estimated variance for x_i
       * we increase the Binverse'[i][i] for ridge regression
       * by a factor > 1 
       * this reduces coefficients for slope and curve according
       * ridge regression theory and assures that the coefficients
       * have correct values 
       */
      for (i=2; i<=3; i++) {
        Binverse[i][i] *= ridgeFactor;
      }
    }
    pivot = Binverse[k][k];

    /* if pivot element is too small: normally would stop as
     * described in the commented-out code. But here a very
     * small pivot element indicates that Amatrix has dependent
     * columns. As remedy, simply increase the pivot element
     * as done in the replacement code below.
     */
    /* general code for small pivot element, deleted */
    /* if ( fabs(pivot) < 1.0e-10) {
      fprintf(stderr,
      "mastermultiperiod2master: Error: pivot element too small\n");
      exit(1);
    }
    if (pivot == 0) {
      fprintf(stderr,
      "mastermultiperiod2master: Error: pivot element = 0\n");
      exit(1);
    } */
    /* begin replacement code for small pivot element */
    if ( fabs(pivot) < 1.0e-10) {
      Binverse[k][k] = 1;
      pivot = Binverse[k][k];
    }
    /* end replacement code for small pivot element */
    if (pivot > 1.e200) {
      fprintf(stderr,
      "mastermultiperiod2master: Error: pivot element too large\n");
      exit(1);
    }
    Binverse[k][k] = 1;
    for (j=1;j<=3;j++) {
      Binverse[k][j] = Binverse[k][j]/pivot;
    }
    for (i=1;i<=3;i++) {
      if (i != k) {
        pivot = Binverse[i][k];
        Binverse[i][k] = 0;
        for (j=1;j<=3;j++) {
          Binverse[i][j] = Binverse[i][j] - pivot*Binverse[k][j];
        }
      }
    }
  }

  // inversion check below eliminated jan 2011 due to
  // modification of Binverse after first pivot
  /* check validity of inversion */
  //for (i=1; i<=3; i++) {
  //  for (j=1; j<=3; j++) {
  //    prod = 0.0;
  //    for (k=1; k<=3; k++) {
  //      prod += Bmatrix[i][k] * Binverse[k][j];
  //    }
  //    if (i == j) {
  //      if (prod > 1.0+EPSILON || prod <1.0-EPSILON) {
  //        fprintf(stderr,
  //   "mastermultiperiod2master: Inversion routine failed, case 1\n");
  //         exit(1);
  //      }
  //    } else {
  //      if (fabs(prod)  > EPSILON) {
  //        fprintf(stderr,
  //   "mastermultiperiod2master: Inversion routine failed, case 2\n");
  //        exit(1);
  //      }
  //    } /* end if i == j, else */
  //  } /* end for j */
  //} /* end for i */

  /* define updatedbbar */
  for (i=1; i<=3; i++) {
    updatedbbar[i] = 0.0;
    for (j=1; j<=3; j++) {
      updatedbbar[i] += Binverse[i][j] * bbar[j];
    }
  }

  /* define constant, slope, and curve */
  function.constant = updatedbbar[1];
  function.slope = updatedbbar[2];
  function.curve =  updatedbbar[3];

/* OBSOLETE code below, deleted Sept 3, 2010 */
  /* estimate quality of function */

  /* estimate mean and variance of attribute values */
  /* mu = (1/n)sum xj */
  /* sigma2 = [(1/n)sum(xj^2)] - mu^2 */
//  mu = 0.0;
//  sigma2 = 0.0;
//  for (i=1; i<=numUsedTimePoints; i++) {
//    mu +=attributeValue[i];
//    sigma2 += attributeValue[i] * attributeValue[i];
//  }
//  mu /= (double)numUsedTimePoints;
//  sigma2 = (sigma2/(double)numUsedTimePoints) - mu * mu;

  /* estimate mean and variance of errors */
//  muError = 0.0;
//  sigma2Error = 0.0;
//  for (i=1; i<=numUsedTimePoints; i++) {
//    val = function.constant + 
//          function.slope * usedTimePoint[i] +
//          function.curve * curveterm(usedTimePoint[i]) -
//          attributeValue[i];
//    muError +=val;
//    sigma2Error += val * val;
//  }
//  muError /= (double)numUsedTimePoints;
//  sigma2Error = (sigma2Error/(double)numUsedTimePoints) - 
//           muError * muError;

  /* estimate ratio of variances */
//  ratio = sigma2Error/sigma2;
  /* if ratio >= REGRESSION_ERROR_THRESHOLD, */
  /*   reject regression and use mean mu */
//  if (ratio >= REGRESSION_ERROR_THRESHOLD) {
//    function.constant = mu;
//    function.slope = 0.0;
//    function.curve = 0.0;
//  }

  return;

}
/*eject*/
/*********************************************************
 *  getValueSlope
 * 
 *  purpose:  get function.beginvalue
 *                function.midvalue
 *                function.endvalue
 *                function.beginslope
 *                function.endslope
 *                function.totalslope
 *            
 *********************************************************/
void getValueSlope() {

  double begt, midt, endt;

  begt = timePoint[1];
  endt = timePoint[numTimePoints];
  midt = (begt + endt)/2.0;

  function.beginvalue = approxfunction(function.constant,
                                       function.slope,
                                       function.curve,
                                       begt);
  function.midvalue =   approxfunction(function.constant,
                                       function.slope,
                                       function.curve,
                                       midt);
  function.endvalue =   approxfunction(function.constant,
                                       function.slope,
                                       function.curve,
                                       endt);
  function.beginslope = (function.midvalue - 
                         function.beginvalue)/(midt - begt);
  function.endslope   = (function.endvalue - 
                         function.midvalue)/(endt - midt);
  function.totalslope = (function.endvalue - 
                         function.beginvalue)/(endt - begt);
}
/*eject*/
/*********************************************************
 *  openFiles
 * 
 *  purpose:  opens global input and output files
 *            
 *********************************************************/
void openFiles()
{
  if ((inputmstfile = fopen(inputmst_filename, "r")) == NULL) {
    fprintf(stderr,
    "mastermultiperiod2master: Cannot open inputmst_filename = %s\n", 
    inputmst_filename);
    exit(1);
  }

  if ((statfile = fopen(stat_filename, "r")) == NULL){
    fprintf(stderr, 
    "mastermultiperiod2master: Cannot open stat_filename = %s\n", 
    stat_filename);
    exit(1);
  }

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "mastermultiperiod2master: Cannot open outputmst_filename = %s\n", 
                    outputmst_filename);
    exit(1);
  }

}
/*eject*/
/*********************************************************
 *  outputline2outputtoken
 * 
 *  purpose:  convert outputline to outputtoken
 *            
 *********************************************************/
void outputline2outputtoken() {

  int i, nz;

  char *buffer;
  char saveout[MAXLEN] = {'\0'};


  /* save outputline for possibility of error message */
  strcpy(saveout,outputline);

  buffer = strtok(outputline," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
    "mastermultiperiod2master: Error: empty outputline\n");
    exit(1);
  }
  i = 1;
  strcpy(outputtoken[i],buffer);
  i++;
  nz = numBeginAttributes + 
       numTotalTimeAttributes + 
       numEndAttributes;
  while (i <= nz) {
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL) {
      fprintf(stderr,
        "mastermultiperiod2master: Error: not enough attribute");
      fprintf(stderr,
        "values in outputline, or counts of .stat file are\n");
      fprintf(stderr,
        "in error.\nLine:\n%s\n",
        saveout);
      exit(1);
    }
    strcpy(outputtoken[i],buffer);
    i++;
  } /* end while i <= nz */
/*eject*/
  /* check that entire outputline has been used */
  buffer = strtok(NULL," \t\n");
  if (buffer != NULL) {
    fprintf(stderr,
    "mastermultiperiod2master: Error: outputline has too many\n");
    fprintf(stderr,
    "values or counts of .stat file are in error.\nLine:\n%s\n",
       saveout);
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  readStats
 * 
 *  purpose:  read statistics of .stat file
 *            
 *********************************************************/
void readStats() {

  char *buffer;

  strcpy(control,"BEGIN");

  /* read statistics of .stat file */
  while (fgets(lineread, MAXLEN, statfile) != NULL) { /* while #1 */
    buffer = strtok(lineread," \t\n=");
    if (buffer == NULL) {
      fprintf(stderr,
      "mastermultiperiod2master:Unexpected empty record \n");
      fprintf(stderr,
      "in stat_filename %s\n",
      stat_filename);
      exit(1);
    }

    if (strcmp(buffer,"number_of_begin_attributes") == 0) {
      if (strcmp(control,"BEGIN") != 0) {
        fprintf(stderr,
        "mastermultiperiod2master: records of .stat file %s\n",
        stat_filename);
        fprintf(stderr,
        "out of order, case 1\n");
        exit(1);     
      }
      /* read  number of begin attributes*/
      strcpy(control,"number_of_begin_attributes");
      buffer = strtok(NULL," \t\n=");
      if (buffer == NULL) {
        fprintf(stderr,"mastermultiperiod2master: ");
        fprintf(stderr,
  "Error: undefined number of begin attributes in .stat file %s\n",
        stat_filename);
        exit(1);
      }
      numBeginAttributes = atoi(buffer);
/*eject*/
    } else if (strcmp(buffer,"number_of_end_attributes") == 0) {
      if (strcmp(control,"number_of_begin_attributes") != 0) {
       fprintf(stderr,"mastermultiperiod2master: ");
       fprintf(stderr,
        "mastermultiperiod2master: records of .stat file %s\n",
        stat_filename);
        fprintf(stderr,
        "out of order, case 2\n");
        exit(1);     
      }
      /* read  number of end attributes*/
      strcpy(control,"number_of_end_attributes");
      buffer = strtok(NULL," \t\n=");
      if (buffer == NULL) {
        fprintf(stderr,"mastermultiperiod2master: ");
        fprintf(stderr,
  "Error: undefined number of end attributes in .stat file %s\n",
        stat_filename);
        exit(1);
      }
      numEndAttributes = atoi(buffer);
    } else if (strcmp(buffer,"time_points") == 0) {
      if (strcmp(control,"number_of_end_attributes") != 0) {
       fprintf(stderr,
        "mastermultiperiod2master: records of .stat file %s\n",
        stat_filename);
        fprintf(stderr,
        "out of order, case 3\n");
        exit(1);     
      }
      /* read time points */
      strcpy(control,"time_points");
      numTimePoints = 0;
      buffer = strtok(NULL," \t\n=");
      while (buffer != NULL) { /* while #2 */
        numTimePoints++;
        timePoint[numTimePoints] = atof(buffer);
        buffer = strtok(NULL," \t\n="); 
      } /* end while #2 */
      if (numTimePoints <= 1) {
        fprintf(stderr,"mastermultiperiod2master: ");
        fprintf(stderr,
                "Error: numTimePoints >= 2 is required, but\n");
        fprintf(stderr,
                "have only %d points specified in .stat file\n",
                numTimePoints);
        exit(1);
      }
/*eject*/  
    } else if (strcmp(buffer,
               "number_attributes_for_each_time_point") == 0) {
      if (strcmp(control,"time_points") != 0) {
       fprintf(stderr,
        "mastermultiperiod2master: records of .stat file %s\n",
        stat_filename);
        fprintf(stderr,
        "out of order, case 4\n");
        exit(1);     
      }
      /* read  number of attributes for each time point */
      strcpy(control,"number_attributes_for_each_time_point");
      buffer = strtok(NULL," \t\n=");
      if (buffer == NULL) {
        fprintf(stderr,"mastermultiperiod2master: ");
        fprintf(stderr,
                "Error: undefined number of attributes for ");
       fprintf(stderr,"each time point in ,stat file %s\n",
                stat_filename);
        exit(1);
      }
      numTimeAttributes = atoi(buffer);
      continue; 
    } else {
      fprintf(stderr,"mastermultiperiod2master: ");
      fprintf(stderr,"Unknown option record in .stat_filename %s\n",
                      stat_filename);
      exit(1);
    } /* end if strcmp(buffer,"time_points"), else */

  } /* end while #1 */

  if (strcmp(control,
             "number_attributes_for_each_time_point") != 0) {
    fprintf(stderr,"mastermultiperiod2master: ");
    fprintf(stderr,
    "records of .stat file %s out of order, case 5\n",stat_filename);
    exit(1);
  }

  numTotalTimeAttributes = numTimeAttributes * numTimePoints;
  numOverallAttributes = numBeginAttributes +
                         numTotalTimeAttributes +
                         numEndAttributes;

  return;

}
/********last record of mastermultiperiod2master.c************/
