#include "prpcc.h"

/* program computes results from input master file.
 *   places entire data set into inputRecord[][] array 
 *   derives results in routine computeResults()
 *   outputs the results as a master file in routine outputResults()
 */

/* this particular version of the program computes certain
 * average values and differences from data involving
 * PRE value, MID value, POST value, MID - PRE difference,
 * POST - MID difference, POST - PRE difference attributes.
 * Includes: sorted mean and variance values for groups
 *           Mann-Whitney-Wilcoxon test
 * See README of ProjectBrainHealth/Intervention for details 
 */

/* CAUTION: Must specify subroutines computeResults() and */
/*          outputResults() for specific case */

/* Global Input and Output files */
FILE *inputmstfile;
FILE *outputmstfile;

char   inputmst_filename[MAX_ID];
char   outputmst_filename[MAX_ID];
char   lineread[MAXLEN] = {'\0'};
char   token[MAX_ENTRY] = {'\0'};

/* Input Arrays */
char attribute[MAX_ATTRIBUTE_SMALL+1][MAX_ID];
int numAttributes;
int numInputAttributeSections; 
/* number of attributes sections where each section has */
/* 6 attributes terminating in vPR, vMD, vPS, MDPR, PSMD, PSPR */
 
float recordValue[MAX_ATTRIBUTE_SMALL+1];
float inputRecord[MAX_RECORD_SMALL][MAX_ATTRIBUTE_SMALL+1];
int numInputRecords;

/* number of groups, cases */
int numGroups;
int numCases;

/* values for input attribute section, case, group */
double inputattsectCaseGroupValue  [MAX_ATTRIBUTE_SECTION+1]
                                   [MAX_GROUP+1]
                                   [MAX_GROUP+1]
                                   [MAX_RECORD_SMALL+1];
int numInputattsectCaseGroupValues [MAX_ATTRIBUTE_SECTION+1]
                                   [MAX_GROUP+1]
                                   [MAX_GROUP+1];

struct {
  double avg;    /* average */
//  double dev;    /* standard deviation */
//  double ratio;  /* if dev > 0: avg/dev, else = 0 */
//  double nreq;   /* min sample size if */
//                 /* significance < 0.025 is desired */
//                 /* uses one-tail 2-sigma bound */
                 /* MaNN-Whitney-Wilcoxon test: */
  double uvalue; /* value of U of MWW test*/
  double znorm;  /* z_u for normal approx. of U distribution */
  double diffmed; /* difference of medians of the two series */
  double sreqd;  /* sample size req'd for 0.025 significance */
} typedef StatResults;
StatResults inputattsectCaseGroupPair[MAX_ATTRIBUTE_SECTION+1]
                                     [MAX_GROUP+1]
                                     [MAX_GROUP+1]
                                     [MAX_GROUP+1];

/* control of sample limit in output */
/* any value beyond limit is declared as '> <sampleLimit>' */
int sampleLimit;

/* Output Arrays */
char outputVariable[MAX_ATTRIBUTE_SMALL+1][MAX_ID];
int numOutputVariables;

float outputRecord[MAX_RECORD_SMALL][MAX_ATTRIBUTE_SMALL+1];
int numOutputRecords;

/* function prototypes */
void bubbleSort(double *a, int *idx, int n, int lohirule);
void convertLineread2value();
int  getLineread();
void openfiles();
/* routines specific to the case at hand */
void computeResults();
void outputResults();
void testDifference(double *avg,     double *dev,
                    double *uvalue,  double *znorm,
                    double *diffmed, double *sreqd, 
                    double *x,       int nx,
                    double *y,       int ny);

/* main function */
int main(int argc, char *argv[])
{
  int j;
  int recordType = 0;


  if (argc != 4) {
    fprintf(stderr,
        "Calling Sequence:  ");
    fprintf(stderr,
        "master2resultsmaster2 input.mst output.mst sampleLimit \n");
    exit(1);
  }
  strcpy(inputmst_filename, argv[1]);
  strcpy(outputmst_filename, argv[2]);
  sampleLimit = atoi(argv[3]);

  /* DEBUG: comment out above and uncomment below */
  /* strcpy(inputmst_filename,"initANDdiff.mst");
  strcpy(outputmst_filename,"initANDdiff.result.mst");
  sampleLimit = 99; */

  openfiles();

  while (getLineread() == 1) {
    if (strcmp(token,"ATTRIBUTES") == 0) {
      if (recordType != 0) {
        fprintf(stderr,
        "master2resultsmaster2: Input file out of order:\n");
        exit(1);
      }
      numAttributes = 0;
      recordType = ATTRIBUTE;
      continue;
    }
    if (strcmp(token,"ENDATA") == 0) {
      if (recordType != DATA) {
        fprintf(stderr,
        "master2resultsmaster2: Missing DATA record in input file\n");
        exit(1);
      } else {
        recordType = ENDATA;
        break;
      }
    }
    if (strcmp(token,"DATA") == 0) {
      /* output new attributes */
      numInputRecords = 0;
      recordType = DATA;
      continue;
    }
    if (recordType == ATTRIBUTE) {
      numAttributes++;
      if (numAttributes > MAX_ATTRIBUTE_SMALL) {
        fprintf(stderr,
       "master2resultsmaster2: Too many attributes in input master\n");
       exit(1);
      }
      strcpy(attribute[numAttributes],token);
      continue;
    }
    if (recordType == DATA) {
      convertLineread2value(); /* get record values from lineread */
      numInputRecords++;
      if (numInputRecords > MAX_RECORD_SMALL) {
        fprintf(stderr,
            "master2resultsmaster2: Too many records %d\n",
            numInputRecords);
        exit(1);
      }      
      for (j=1; j<=numAttributes; j++) {
        inputRecord[numInputRecords][j] = recordValue[j];
      }
    }
  }

  if (recordType != ENDATA) {
    fprintf(stderr,
    "master2resultsmaster2: Missing ENDATA record in input file %s\n",
     inputmst_filename);
    exit(1);
  }

  computeResults();
  outputResults();

  fclose(inputmstfile);
  fclose(outputmstfile);

  return 0;
}
/*eject*/
/***************************************************************
 *--------------------------------------------------------------
 * bubbleSort(double *a, int *idx, int n, int lohirule):
 *   input:  a[] array with n entries
 *           idx[i] = i for all i
 *           lohirule = TRUE: sort low to high
 *                      FALSE: sort high to low
 *   output: a[] with entries sorted in order indicated by lohirule.
 *           idx[i] = original index of a[] value now in position i.
 *--------------------------------------------------------------
 ***************************************************************/
void bubbleSort(double *a, int *idx, int n, int lohirule) {

  int flag, i, j, k;
  double b;

  for (k=n-1; k>=1; k--) {

    flag = 0;

    if (lohirule == TRUE) {
      for (i=1; i<=k; i++) {
        if (a[i] > a[i+1]) { /* sort low to high */
          b = a[i];
          a[i] = a[i+1];
          a[i+1] = b;
          j = idx[i];
          idx[i] = idx[i+1];
          idx[i+1] = j;
          flag = 1;
        }
      } /* end for i */
    } else {
      for (i=1; i<=k; i++) {
        if (a[i] < a[i+1]) { /* sort high to low */
          b = a[i];
          a[i] = a[i+1];
          a[i+1] = b;
          j = idx[i];
          idx[i] = idx[i+1];
          idx[i+1] = j;
          flag = 1;
        }
      } /* end for i */
    } /* end if lohirule == TRUE, else */

    if (flag == 0) {
      return;
    }

  } /* end for k */

  return;

} /* end bubbleSort */
/*eject*/
/*********************************************************
 *  computeResults
 * 
 *  purpose:  derives results from input data and puts them
 *            into outputRecords[][] array
 *            
 *********************************************************/
void computeResults() {

  int g, h, i, j, k, m;
//  int count[MAX_ATTRIBUTE_SMALL+1], jump;

  double avg, dev, uvalue, znorm, diffmed, sreqd;
//  float sum[MAX_ATTRIBUTE_SMALL+1]; 

  numInputAttributeSections = 36; 
  /* number of input attribute sections
   * must be specified here
   * each section consists of a leading name plus the suffixes
   * vPR (= PRE value)
   * vMD (= MID value)
   * vPS (= POST value)
   * MDPR (= MID - PRE difference)
   * PSMD (= POST - MID difference)
   * PSPR (= POST - PRE difference)
   * listing begins in column 20 and goes to column 211 
   */

  numGroups = inputRecord[numInputRecords][2]; 
  /* groups must be listed in sequence, with highest group last */
  /* group number is second attribute */

  /* number of cases = 3: MDPR, PSMD, PSPR */
  numCases = 3;
  if (numCases > MAX_GROUP) {
    fprintf(stderr,
      "master2resultsmaster2: Too many cases %d\n",
      numCases);
      exit(1); 
  }

  /* compute output records */
  for (k=1; k<=numInputAttributeSections; k++) {
    /* process the 3 MDPR, PSMD, PSPR difference values */
    /* for each attribute section, which have a total of 6 values */

    for (m=1; m<=numCases; m++) { /* for m, case 1 */
      /* m=1: MDPR case; m=2: PSMD case; m=3: PSPR case */
      j = 19 + 6*(k-1) + 3 + m; /* j = variables index */

      for (g=1; g<=numGroups; g++) { /* for g, case 1 */
        /* handle the records of group g */
        numInputattsectCaseGroupValues[k][m][g] = 0;
//        sum[g] = 0;
//        count[g] = 0;
        for (i=1; i<=numInputRecords; i++) {
          /* process each record i */
          if ((inputRecord[i][2] == g) &&
              (inputRecord[i][j] != QUESTION_MARK)) {
//            sum[g] += inputRecord[i][j];
//            count[g]++;
            numInputattsectCaseGroupValues[k][m][g]++;
            inputattsectCaseGroupValue[k][m][g]
              [numInputattsectCaseGroupValues[k][m][g]] =
              inputRecord[i][j];
          }
        } /* end for i */

        /* compute average and store */
//      if (count[g] > 0) {
//          outputRecord[k][numCases*(m-1) + g] = 
//             sum[g]/(float)count[g];
//        } else {
//          outputRecord[k][numCases*(m-1) + g] = QUESTION_MARK;
//        }

      } /* end for g, case 1 */

    } /* end for m, case 1 */

//    /* compute differences from the average values */
//    jump = (numGroups*(numGroups-1))/2;  /* number of group pairs */
//    j = 0;
//
//    for (g=1; g<=numGroups-1; g++) { /* for g, case 2 */
//      for (h=g+1; h<=numGroups; h++) {
//
//        j++;
//        for (m=1; m<=numCases; m++) { /* for m, case 2 */
//          /* difference of MDPR avg, PSMD avg, or PSPR avg */
//          if ((outputRecord[k][numGroups*(m-1) + g] != 
//               QUESTION_MARK) &&
//              (outputRecord[k][numGroups*(m-1) + h] != 
//               QUESTION_MARK)) {
//            outputRecord[k][numCases*numGroups + jump*(m-1) + j] = 
//              outputRecord[k][numGroups*(m-1) + g] - 
//              outputRecord[k][numGroups*(m-1) + h];         
//          } else {
//            outputRecord[k][numCases*numGroups + jump*(m-1) + j] =
//               QUESTION_MARK;
//          }
//        } /* end for m, case 2 */
//
//      } /* end for h */
//    } /* end for g, case 2 */

    /* compute average 
//   * std deviation, N likely required for 0.025 significance
     * Mann-Whitney-Wilcoxon test: uvalue, znorm, diffmed, sreqd
     * use data of inputattsectCaseGroupValue[][][][]
     */
    for (m=1; m<=numCases; m++) { /* for m, case 3 */
      for (g=1; g<=numGroups-1; g++) {
        for (h=g+1; h<=numGroups; h++) {
          testDifference(&avg,&dev,&uvalue,&znorm,&diffmed,&sreqd,
                         inputattsectCaseGroupValue[k][m][g],
                         numInputattsectCaseGroupValues[k][m][g],
                         inputattsectCaseGroupValue[k][m][h],
                         numInputattsectCaseGroupValues[k][m][h]);
          inputattsectCaseGroupPair[k][m][g][h].avg = avg;
//          inputattsectCaseGroupPair[k][m][g][h].dev = dev;
          if (avg != QUESTION_MARK) {
//            if (dev > 0) {
//              inputattsectCaseGroupPair[k][m][g][h].ratio = 
//                   fabs(avg/dev);
//            } else {
//              inputattsectCaseGroupPair[k][m][g][h].ratio = 0.0;
//            }
//            if (fabs(avg) > EPSILON) {
//              /* want smallest nreq such we get the result
//               * where the average difference is less than avg/2
//               * with probability at most 0.025.
//               * For this, pick nreq = N
//               * such that mu/2 >= 2 * sigma_N
//               * here use: mu = avg and sigma_N = dev /sqrt(N)
//               * hence, nreq = 2 * dev^2 / (avg^2/4) rounded up
//               */
//              inputattsectCaseGroupPair[k][m][g][h].nreq = 
//                   roundUpToInt(2 * dev*dev/(avg*avg/4));
//            } else {
//              inputattsectCaseGroupPair[k][m][g][h].nreq  = 0;
//            }
            /* Mann-Whitney-Wilcoxon test */
            inputattsectCaseGroupPair[k][m][g][h].uvalue = uvalue;
            inputattsectCaseGroupPair[k][m][g][h].znorm = znorm;
            inputattsectCaseGroupPair[k][m][g][h].diffmed = diffmed;
            inputattsectCaseGroupPair[k][m][g][h].sreqd = sreqd;
          } else {
//            inputattsectCaseGroupPair[k][m][g][h].ratio = 
//                 QUESTION_MARK;
//             inputattsectCaseGroupPair[k][m][g][h].nreq =
//                 QUESTION_MARK;
            /* Mann-Whitney-Wilcoxon test */
            inputattsectCaseGroupPair[k][m][g][h].uvalue =
                 QUESTION_MARK;
            inputattsectCaseGroupPair[k][m][g][h].znorm =
                 QUESTION_MARK;
            inputattsectCaseGroupPair[k][m][g][h].diffmed =
                 QUESTION_MARK;
            inputattsectCaseGroupPair[k][m][g][h].sreqd =
                 QUESTION_MARK;
          } /* end if avg != QUESTION_MARK..., else */
        }
      }
    } /* end for m, case 3 */
           
  } /* end for k */ 

  return;

}
/*eject*/
/*********************************************************
 *  convertLineread2value
 * 
 *  purpose:  converts data record to numerical values
 *            
 *********************************************************/
void convertLineread2value() {


  int j;

  char *buffer;
  char saveread[MAXLEN];

  strcpy(saveread,lineread);

  for (j=1; j<=numAttributes; j++) {

    if (j == 1) {
      buffer = strtok(saveread," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }
    if (buffer == NULL) {
      fprintf(stderr,
           "master2resultsmaster2: line has too few entries\n%s\n",
           lineread);
      exit(1);
    }
    if (strcmp(buffer,"?") == 0) {
      recordValue[j] = QUESTION_MARK;
    } else {    
      sscanf(buffer,"%f",&recordValue[j]);
    }

  } /* end for j */

  /* check that entire line has been read */
  buffer = strtok(NULL," \t\n");
  if (buffer != NULL) {
      fprintf(stderr,
         "master2resultsmaster2: line has too many entries\n%s\n",
         lineread);
      exit(1);
  }

  return;   
}
/*eject*/
/*********************************************************
 *  getLineread
 * 
 *  purpose:  get next nonempty, noncomment line of inputmst file
 *            output: lineread (= line)
 *                    token (= first entry of lineread)
 *            
 *********************************************************/
int getLineread() {

  int i;

  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) {

    /* skip over empty and comment lines */
    if ((lineread[0] == '\n') ||
        (lineread[0] == '*')) {
      continue;
    }

    /* strip off carriage return/whitespace at end of line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* store first entry of lineread in token */
    sscanf(lineread,"%s",token);

    return 1;    
  }

  /* file has no non-empty and non-comment line */
  return 0;

}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles()
{
  if ((inputmstfile = fopen(inputmst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "master2resultsmaster2: Cannot open %s\n", inputmst_filename);
    exit(1); 
  }   

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2resultsmaster2: Cannot open %s\n", outputmst_filename);
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  outputResults
 * 
 *  purpose:  outputs results of outputRecords[][] array
 *            in master file format
 *            
 *********************************************************/
void outputResults() {

  int g, h, k, m;
//  int j, nlim;

  char att[MAX_ID];

  /* output variable names */

  fprintf(outputmstfile,"ATTRIBUTES\n"); 

  fprintf(outputmstfile,"attributeSection\n");

//  for (g=1; g<=numGroups; g++) {
//    fprintf(outputmstfile,"Gp%dMDPR_avg\n",g);
//  }
//
//  for (g=1; g<=numGroups; g++) {
//    fprintf(outputmstfile,"Gp%dPSMD_avg\n",g);
//  }
//
//  for (g=1; g<=numGroups; g++) {
//    fprintf(outputmstfile,"Gp%dPSPR_avg\n",g);
//  }
//
//  for (g=1; g<=numGroups-1; g++) {
//    for (h=g+1; h<=numGroups; h++) {
//      fprintf(outputmstfile,"diff%d%dMDPR\n",g,h);
//    }
//  }
//
//  for (g=1; g<=numGroups-1; g++) {
//    for (h=g+1; h<=numGroups; h++) {
//      fprintf(outputmstfile,"diff%d%dPSMD\n",g,h);
//    }
//  }
//
//  for (g=1; g<=numGroups-1; g++) {
//    for (h=g+1; h<=numGroups; h++) {
//      fprintf(outputmstfile,"diff%d%dPSPR\n",g,h);
//    }
//  }

  for (g=1; g<=numGroups-1; g++) {
    for (h=g+1; h<=numGroups; h++) {
      fprintf(outputmstfile,"avg%d%dMDPR\n",g,h);
      fprintf(outputmstfile,"difm%d%dMDPR\n",g,h);
//      fprintf(outputmstfile,"dev%d%dMDPR\n",g,h);
//      fprintf(outputmstfile,"ratio%d%dMDPR\n",g,h);
//      fprintf(outputmstfile,"Nreq%d%dMDPR\n",g,h);
/*      fprintf(outputmstfile,"uval%d%dMDPR\n",g,h);*//* keep code */
      fprintf(outputmstfile,"znor%d%dMDPR\n",g,h);
      fprintf(outputmstfile,"sreq%d%dMDPR\n",g,h);
    }
  }

  for (g=1; g<=numGroups-1; g++) {
    for (h=g+1; h<=numGroups; h++) {
      fprintf(outputmstfile,"avg%d%dPSMD\n",g,h);
      fprintf(outputmstfile,"difm%d%dPSMD\n",g,h);
//      fprintf(outputmstfile,"dev%d%dPSMD\n",g,h);
//      fprintf(outputmstfile,"ratio%d%dPSMD\n",g,h);
//      fprintf(outputmstfile,"Nreq%d%dPSMD\n",g,h);
/*      fprintf(outputmstfile,"uval%d%dPSMD\n",g,h);*//* keep code */
      fprintf(outputmstfile,"znor%d%dPSMD\n",g,h);
      fprintf(outputmstfile,"sreq%d%dPSMD\n",g,h);
    }
  }

  for (g=1; g<=numGroups-1; g++) {
    for (h=g+1; h<=numGroups; h++) {
      fprintf(outputmstfile,"avg%d%dPSPR\n",g,h);
      fprintf(outputmstfile,"difm%d%dPSPR\n",g,h);
//      fprintf(outputmstfile,"dev%d%dPSPR\n",g,h);
//      fprintf(outputmstfile,"ratio%d%dPSPR\n",g,h);
//      fprintf(outputmstfile,"Nreq%d%dPSPR\n",g,h);
/*      fprintf(outputmstfile,"uval%d%dPSPR\n",g,h);*//* keep code */
      fprintf(outputmstfile,"znor%d%dPSPR\n",g,h);
      fprintf(outputmstfile,"sreq%d%dPSPR\n",g,h);
    }
  }

  /* output computed values */

  fprintf(outputmstfile,"DATA\n");
//  nlim = numCases*numGroups + numCases*numGroups*(numGroups-1)/2;

  for (k=1; k<=numInputAttributeSections; k++) {

    /* eliminate "_vPR" from end of attribute name */
    strcpy(att,attribute[19 + 6*(k-1) + 1]);
    att[strlen(attribute[19 + 6*(k-1) + 1]) - 3] = '\0';
 
    fprintf(outputmstfile,"%s", att);

//    /* averages and differences */
//    for (j=1; j<=nlim; j++) {
//      if (outputRecord[k][j] != QUESTION_MARK) {
//        fprintf(outputmstfile,"\t%f",outputRecord[k][j]);
//      } else {
//        fprintf(outputmstfile,"\t?");
//      }
//    }

    /* output comparisons of sorted records */
    for (m=1; m<=numCases; m++) {
      for (g=1; g<=numGroups-1; g++) {
        for (h=g+1; h<=numGroups; h++) {
 
          /* average */
          if (inputattsectCaseGroupPair[k][m][g][h].avg !=
                     QUESTION_MARK) {
            fprintf(outputmstfile,"\t%f",
              inputattsectCaseGroupPair[k][m][g][h].avg);
          } else {
            fprintf(outputmstfile,"\t?");
          }
          /* diffmed */
          if (inputattsectCaseGroupPair[k][m][g][h].diffmed !=
                     QUESTION_MARK) {
            fprintf(outputmstfile,"\t%f",
              inputattsectCaseGroupPair[k][m][g][h].diffmed);
          } else {
            fprintf(outputmstfile,"\t?");
          }
//          /* standard deviation */
//          if (inputattsectCaseGroupPair[k][m][g][h].dev !=
//                     QUESTION_MARK) {
//            fprintf(outputmstfile,"\t%f",
//              inputattsectCaseGroupPair[k][m][g][h].dev);
//          } else {
//            fprintf(outputmstfile,"\t?");
//          }
//          /* ratio = average / (standard deviation) */
//          if (inputattsectCaseGroupPair[k][m][g][h].ratio !=
//                     QUESTION_MARK) {
//            fprintf(outputmstfile,"\t%f",
//              inputattsectCaseGroupPair[k][m][g][h].ratio);
//          } else {
//            fprintf(outputmstfile,"\t?");
//          }
//          /* nreq */
//          if (inputattsectCaseGroupPair[k][m][g][h].nreq !=
//                     QUESTION_MARK) {
//            fprintf(outputmstfile,"\t%f",
//              inputattsectCaseGroupPair[k][m][g][h].nreq);
//          } else {
//            fprintf(outputmstfile,"\t?");
//          }
/* keep code below */
          /* uvalue */
          /* if (inputattsectCaseGroupPair[k][m][g][h].uvalue !=
                     QUESTION_MARK) {
            fprintf(outputmstfile,"\t%f",
              inputattsectCaseGroupPair[k][m][g][h].uvalue);
          } else {
            fprintf(outputmstfile,"\t?");
          } */
          /* znorm */
          if (inputattsectCaseGroupPair[k][m][g][h].znorm !=
                     QUESTION_MARK) {
            fprintf(outputmstfile,"\t%f",
              inputattsectCaseGroupPair[k][m][g][h].znorm);
          } else {
            fprintf(outputmstfile,"\t?");
          }          
          /* sreqd */
          /* sreqd = 0 implies have already significance <= 0.025 */
          if (inputattsectCaseGroupPair[k][m][g][h].sreqd !=
                     QUESTION_MARK) {
            if (inputattsectCaseGroupPair[k][m][g][h].sreqd <= 
               sampleLimit) {
              fprintf(outputmstfile,"\t%f",
                inputattsectCaseGroupPair[k][m][g][h].sreqd);
              } else {
                fprintf(outputmstfile,"\t>%d",sampleLimit);
              }
          } else {
            fprintf(outputmstfile,"\t?");
          }
        } /* end for g */
      } /* end for h */
    } /* end for m */

    fprintf(outputmstfile,"\n");

  } /* end for k */

  fprintf(outputmstfile,"ENDATA\n");

  return;

}
/*eject*/
/*********************************************************
 *  testDifference
 * 
 *  purpose:  for two given vectors, computed the average
 *            gap of the sorted vectors and the standard
 *            deviation
 *            Mann-Whitney-Wilcoxon test:
 *              U value
 *              z_u of U using normal approximation
 *              difference of medians
 *              sample size required for significance 0.025
 *                  sample size = 0 means that we have already 
 *                  significance  <= 0.025           
 *********************************************************/
void testDifference(double *avgt,     double *devt,
                    double *uvaluet,  double *znormt,
                    double *diffmedt, double *sreqdt,      
                    double *xt,       int nxt,
                    double *yt,       int nyt) {

  int i, j, jlo, nx, ny, shift;
  int idx[MAX_RECORD+1];

  double avg, diff, fac, jy, var;
  double uvalue, znorm, diffmed, sreqd;
  double medx, medy, umean, uvar;

  double *x;
  double *y;

  /* make x the shorter vector and y the longer one */
  if (nxt <= nyt) {
    x = xt;
    nx = nxt;
    y = yt;
    ny = nyt;
    shift = FALSE;
  } else {
    x = yt;
    nx = nyt;
    y = xt;
    ny = nxt;
    shift = TRUE;     
  }

  if (ny > MAX_RECORD) {
    fprintf(stderr, 
    "master2resultsmaster2: MAX_RECORD too small for bubble sort%d\n",
     ny);
    exit(1);
  }

   if (nx <= 2) {
       *avgt =     QUESTION_MARK;
       *devt =     QUESTION_MARK;
       *uvaluet =  QUESTION_MARK;
       *znormt =   QUESTION_MARK;
       *diffmedt = QUESTION_MARK;
       *sreqdt =   QUESTION_MARK;
       return;
  } 

  /* sort x and y vector in place from low to high */
  bubbleSort(x, idx, nx, TRUE);
  bubbleSort(y, idx, ny, TRUE);

  /* compute average difference and standard deviation */
  /* between the sorted vectors */
  avg = 0.0;
  var = 0.0;
  fac = ny-1;
  fac /= (float) (nx-1);

  for (i=1; i<=nx; i++) {
    if (i == 1) {
      diff = x[1] - y[1];
    } else if (i == nx) {
      diff = x[nx] - y[ny];
    } else {
      /* jy is continuous index of y corresponding to i of x */
      /* use convex combination of y[jlo] and y[jlo+1] for estimate */
      jy = 1 + ((float)(i-1))*fac;
      jlo = jy;
      diff = x[i] - ((jy-(float)jlo)*y[jlo+1] +
                    ((float)jlo+1-jy)*y[jlo]);
    }

    avg += diff;
    var += diff * diff; 
  }

  avg /= (float)nx;
  var = (var - avg*avg)/(float)(nx-1);
  if (shift == TRUE) {
    avg = -avg;
  }

  *avgt = avg;
  *devt = sqrt(var);

  /* Mann-Whitney-Wilcoxon test */

  /* U value */
  uvalue = 0.0;

  for (i=1; i<= nx; i++) {
    for (j=1; j<=ny; j++) {
      if (y[j] < x[i]) {
        uvalue += 1.0;
      } else if (y[j] == x[i]) {
        uvalue += 0.5;
      } else {
        break;
      }
    } /* end for j */
  } /* end for i */

  /* mean and variance of U */
  umean = ((double) nx) * ((double) ny)/2.0;
  uvar =  ((double) nx) * ((double) ny) * 
          ((double)nx + (double)ny + 1.0)/12.0;

  if (shift == TRUE) {
   uvalue = umean - uvalue;
  }

  /* z_u for U value using normal approximation */
  znorm = fabs(uvalue - umean)/sqrt(uvar);



  /* medians */
  if (nx%2 != 0) {
    medx = x[nx/2+1];
  } else {
    medx = (x[nx/2] + x[nx/2+1])/2.0;
  }
  if (ny%2 != 0) {
    medy = y[ny/2+1];
  } else {
    medy = (y[ny/2] + y[ny/2+1])/2.0;
  }

  /* difference of medians */
  if (shift == FALSE) {
    diffmed = medx - medy;
  } else {
    diffmed = medy - medx;
  }

  /* sample size required for 0.025 significance
   * sqrt(factor for size increase) = 2.0/znorm 
   *                                  for 0.025 significance
   * hence:
   * factor = (2.0/znorm)^2
   */
  if (znorm > 0.01) {
    if (znorm < 2.0) {
      sreqd = (2.0/znorm) * (2.0/znorm);
    } else {
      /* current sample gives already 0.025 significance */
      /* convention: set sreqd = 0.0 */
      sreqd = 0.0;
    }
  } else {
    sreqd = (2.0/0.01) * (2.0/0.01);
  }
  /* use max of nx and ny, which is ny, as current sample size */
  sreqd *=(double)ny;
  sreqd = (double) roundUpToInt(sreqd);

  *uvaluet = uvalue;
  *znormt  = znorm;
  *diffmedt = diffmed;  
  *sreqdt = (double)sreqd;
  
  return;

}

/* last record of master2resultsmaster2.c****/
