#include "prpcc.h"

/* Global Input and Output files */
FILE *inputmstfile;
FILE *outputmstfile;
char inputmst_filename[MAX_ID];
char outputmst_filename[MAX_ID];

char lineread[MAXLEN] = {'\0'};
char token[MAX_ENTRY] = {'\0'};
char outputline[MAXLEN] = {'\0'};
char outputtoken[MAX_ATTRIBUTE+1][MAX_ENTRY];

/* function prototypes */
void openfiles(char *inputmst_filename, char *outputmst_filename);
void outputline2token();

/* main function */
int main(int argc, char *argv[])
{

  if (argc != 3) {
    fprintf(stderr,
    "Calling Sequence:  parsefile input.mst output.mst\n");
    exit(1);
  }
  strcpy(inputmst_filename, argv[1]);
  strcpy(outputmst_filename, argv[2]);

  /* DEBUG: comment out above and uncomment below */
  /* strcpy(inputmst_filename, "services.stocks");
  strcpy(outputmst_filename, "services.sl"); */

  openfiles(inputmst_filename,outputmst_filename);

  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) {
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0')) {
      continue;
    }

    /* copy lineread record to outputline */
    strcpy(outputline,lineread);

    /* parse outputline, keep result in token */
    outputline2token();

    /* output token */
    fprintf(outputmstfile,"%s\n",token);
  }

  fclose(inputmstfile);
  fclose(outputmstfile);

  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *inputmst_filename, char *outputmst_filename)
{
  if ((inputmstfile = fopen(inputmst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "master2doublemaster: Cannot open %s\n", "inputmst_filename");
    exit(1); 
  }   

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2doublemaster: Cannot open %s\n", "ouputmst_filename");
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  outputline2token
 * 
 *  purpose:  parse outputline, put result into token
 *            successful case: token is all alpha upper case
 *            and is the last string satisfying that condition
 *            
 *********************************************************/
void outputline2token() {

  int flag, i, j, succss;

  char *buffer;
  char saveout[MAXLEN] = {'\0'};


  /* save outputline for possibility of error message */
  strcpy(saveout,outputline);

  succss = 0;
  i = 0;
  while (1) {

    if (i == 0) {
      buffer = strtok(outputline," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }

    if (buffer == NULL) {
      if (succss == 0) {
        fprintf(stderr,
          "parsefile: Error: did not find information for token ");
          fprintf(stderr,
        "in outputline\nLine:\n%s\n",saveout);
        strcpy(token,saveout);
      }
      return;
    }

    flag = 1;
    /* check for all alpha upper case alpha chars; the last  */
    /* buffer for which this holds, is the solution */
    for (j=0; j<=strlen(buffer)-1; j++) {
      if (buffer[j] <= 64 || buffer[j] >= 91) {
        flag = 0;
        break;
      }
    }
    if (flag == 1) {
      strcpy(token,buffer);
      succss = 1;
    }
    i++;
  } /* end while */

  /* error, should not get here */
  fprintf(stderr,
    "parsefile: Error: should not get here\n");
    exit(1);

  return;

}

/* last record of master2doublemaster.c****/
