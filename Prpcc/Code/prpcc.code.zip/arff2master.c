#include "prpcc.h"

struct {
  char oldToken[MAX_ENTRY];
  char newToken[MAX_ENTRY];
} typedef Substitution;

/* Global Input and Output files */
FILE *arffile;
FILE *subfile;
FILE *mstfile;

/*Global Structure for Substitutions */
char Attributes[MAX_ATTRIBUTE][MAX_ENTRY];
int numAttributes = 0;
Substitution globalSubs[MAX_ATTRIBUTE];
int numglobalSubs = 0;
int subAttributes[MAX_ATTRIBUTE];
Substitution localSubs[MAX_ATTRIBUTE];
int numlocalSubs = 0;
int alphanumericerror;

/* function prototypes */
void openfiles(char *arf_filename, 
               char *sub_filename, 
               char *mst_filename);
void writeline(FILE *outputFile, char line[]);
void shiftLeft(char fileRec[]);
int getIndex(char *attribute);
void substr(char dest[], char src[], int offset, int len);
void checkalphanumeric(char *token);


/*
 * CAUTION: 1. Attribute names in input .arff file must consist of
 *             alphanumeric characters plus underscore.
 *          2. The program adds a leading "x" to each attribute
 *             name to assure that the name begins with an alpha 
 *             character.
 *          3. The input .arff file is assumed to have correct format
 *             with regard to .arff rules.
 *          4. Delimiter character is ',' for data records.
 *          5. Remove ^M end-of-line characters by dos2unix.
 */
/*eject*/
/* main function */
int main(int argc, char *argv[])
{
  char control[MAX_ID];
  char arf_file[MAX_ID];
  char sub_file[MAX_ID];
  char mst_file[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  int i, nz;
  char *buffer;
  char token[MAXLEN] = {'\0'};

  fprintf(stderr,
          "CAUTION: arf file must be in UNIX format\n");
  fprintf(stderr,
          "         Use dos2unix if in DOS format\n");

  if (argc != 4) {
    printf(
   "Calling Sequence:  arff2master input.arf input.sub master.mst\n");
    exit(1);
  }
  strcpy(arf_file, argv[1]);
  strcpy(sub_file, argv[2]);
  strcpy(mst_file, argv[3]);

/* DEBUG: uncomment below and comment out above */
/*  strcpy(arf_file, "tinyexample.arff");
  strcpy(sub_file, "tinyexample.sub");
  strcpy(mst_file, "tinyexample.mst"); */

  openfiles(arf_file, sub_file, mst_file);

  strcpy(control,"START");
/*eject*/
  /* process input arff file */
  while (fgets(lineread, MAXLEN, arffile) != NULL) { /* while # 1 */

    /* strip off carriage return and whitespace */
    /* at the end of the line */
    nz = strlen(lineread);
    i = nz - 1;
    while (lineread[i]>=1 && lineread[i]<=32) { /* while #2 */
      lineread[i] = '\0';
      i--;
    } /* end while #2 */

    /* first record of input arff file */
    if (strcmp(control,"START") == 0) {
      /* first line of input arff file must specify "@relation" */
      /* corresponding record of master file is "ATTRIBUTES" */
      if ( strncmp(lineread,"@relation",9) != 0) {
        fprintf(stderr,
    "Error: first record of input arff file must have '@relation'\n");
        exit(1);
      }
      fprintf(mstfile, "ATTRIBUTES\n");
      strcpy (control,"ATTRIBUTES");
      continue;    
    } /* end if strcmp(control,"START") == 0 */
/*eject*/
    /* "@data" record of input arff file */
    if (strncmp(lineread,"@data",5) == 0) {
      strcpy(control,"DATA");
      fprintf(mstfile, "DATA\n");
      /* parse substitution file */
      while (fgets(lineread, MAXLEN, subfile) != NULL) {/* while #3 */
        nz = strlen(lineread);
        i = nz - 1;
        /* strip off carriage return and whitespace */
        /* at the end of the line */
        while (lineread[i]>=1 && lineread[i]<=32) { /* while #4 */
          lineread[i] = '\0';
          i--;
        } /* end while #4 */

        buffer = strtok(lineread, ",\n");
        if (buffer != NULL) {
          if (strcmp(buffer,"<all>") == 0) {
            //add to global substitutions
            buffer = strtok(NULL, ",\n");
            strcpy(globalSubs[numglobalSubs].oldToken, buffer);
            buffer = strtok(NULL, ",\n");
            strcpy(globalSubs[numglobalSubs].newToken, buffer);
            numglobalSubs++;	
          } else {
            /* local substitution option currently not implemented */
            fprintf(stderr,
            "Error: current version only supports global ");
            fprintf(stderr,
            "substitutions using '<all>' and not local ");
            fprintf(stderr,
            "substitutions\n");
            exit(1);
            //add to local substitutions
            /*index = getIndex(buffer);
            subAttributes[numlocalSubs] = index;
            buffer = strtok(NULL, ",\n");
            strcpy(localSubs[numlocalSubs].oldToken, buffer);
            buffer = strtok(NULL, ",\n");
            strcpy(localSubs[numlocalSubs].newToken, buffer);
            numlocalSubs++; */	  
          } /* end if strcmp(buffer,"<all>") == 0 */
        } /* end if buffer != NULL */
      } /* end while #3 */

      printf("Global Substitutions:\n");
      for (i=0; i<numglobalSubs; i++) {
        printf("%s    %s\n" , 
               globalSubs[i].oldToken, globalSubs[i].newToken);
      }
      /* printf("Local Substitutions:\n");
      for (i=0; i<numlocalSubs; i++) {
        printf("%d    %s    %s\n", 
               subAttributes[i], localSubs[i].oldToken, 
               localSubs[i].newToken);
      } */
      continue;    
    } /* end if strncmp(lineread,"@data",5) == 0 */
/*eject*/
    /* attribute record of input arff file */
    if (strcmp(control,"ATTRIBUTES") == 0) {
      if (strncmp(lineread,"@attribute class",16) == 0) {
        /* class attribute */
        /* master has corresponding TARGET statement */
        fprintf(mstfile, "class\tTARGETCASES_1_10_10\n");
        
        continue;       
      } else {
        /* process attribute */
        buffer = strtok(lineread," \t");
        if (strcmp(buffer,"@attribute") != 0) {
          fprintf(stderr,
          "Error: attribute record must begin with '@attribute'\n");
          exit(1);
        }
        buffer = strtok(NULL," \t");
        token[0] = 'x';
        strcpy(&token[1],buffer);
        /* check that attribute name is alphanumeric */
        checkalphanumeric(token);
        fprintf(mstfile, "%s\n",token);
        continue;
      } /* end if strncmp(lineread,"@attribute class"..., else */    
    } /* end if  strcmp(control,"ATTRIBUTES") == 0 */
/*eject*/
    /* data record of input arff file */
    if (strcmp(control,"DATA") == 0) {
      /* extract tokens of record */
      /* input arff file uses comma as delimiter */
      buffer = strtok(lineread," ,\t\n");
      if (buffer == NULL) {
        fprintf(stderr,
            "Error: non-null data record has no entries\n");
        exit(1);
      }
      while (buffer != NULL) { /* while #5 */
        strcpy(token,buffer);
        /* check for global substitution */
        for (i=0; i<=numglobalSubs; i++) {
          if (strcmp(token,globalSubs[i].oldToken) == 0) {
            strcpy(token,globalSubs[i].newToken);
            break;
          }
        } /* end for i */
        fprintf(mstfile,"%s ",token);
        buffer = strtok(NULL," ,\t\n");
      } /* end while #5 */
      fprintf(mstfile,"\n");             
      continue;
    } /* end if strcmp(control,"DATA") == 0 */

  } /* end while #1 */
/*eject*/
  fprintf(mstfile,"ENDATA\n");

  fclose(arffile);
  fclose(mstfile);
  fclose(subfile);
  
  return 0;
} /* end main */
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens global input and output files
 *            
 *********************************************************/
void openfiles(char *arf_filename, 
               char *sub_filename, 
               char *mst_filename)
{
  if ((arffile = fopen(arf_filename, "r")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", "arf_filename");
    exit(1);
  }

  if ((subfile = fopen(sub_filename, "r")) == NULL){
    fprintf(stderr, "Cannot open %s\n", "sub_filename");
    exit(1);
  }

  if ((mstfile = fopen(mst_filename, "w")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", "mst_filename");
    exit(1);
  }

}


/*********************************************************
 *  writeline
 * 
 *  purpose:  output line of text to specified file
 *            
 *********************************************************/
void writeline(FILE *outputFile, char line[])
{
  fprintf(outputFile, "%s\n", line);
}


/*********************************************************
*	Shift the line left
*   Ascii 32 = space, 9 = tab
**********************************************************/
void shiftLeft(char fileRec[])
{
  while(fileRec[0] == 32 || fileRec[0] == 9) {
    strcpy(fileRec, fileRec+1);
  }
}


/*********************************************************
 *  getIndex
 * 
 *  purpose:  returns index for attribute name as 
 *            appears in mst file ATTRIBUTES section
 *********************************************************/
int getIndex(char *attribute)
{
  int i = 0;
  for (i=0; i<numAttributes; i++) {
    if (strcmp(Attributes[i], attribute) == 0) {
      return i;
    }
  }
  
  printf("Error in getIndex():  Attribute not found: %s\n", attribute);
  exit(1);

  return 0;
}


/*********************************************************
 *  substr
 * 
 *  purpose:  copies substring into another string
 *            
 *********************************************************/
void substr(char dest[], char src[], int offset, int len)
{
  int i;
  for(i = 0; i < len && src[offset + i] != '\0'; i++)
    dest[i] = src[i + offset];
  dest[i] = '\0';
}


/*********************************************************
 *  checkalphanumeric
 * 
 *  purpose:  checks if token has alphanumeric form
 *            
 *********************************************************/
void checkalphanumeric(char *token) {

  int j, n;

  /* first character of token must be alpha or underscore */
  n = (int)token[0];
  if (((n<65)||
      (n>90))&&
      ((n<97)||
      (n>122))&&
      (n!=95)) {
    fprintf(stderr,
            "Error: First character '%c' of attribute '%s' must be ",
            token[0], token);
    fprintf(stderr,
            "alpha or underscore\n");
    alphanumericerror = TRUE;    
  }
/*
 *  remaining characters must be alphanumeric or underscore
 */
  for(j=1; j<=strlen(token)-1; j++)  {
    n = (int)token[j];
    if (((n<65)||
        (n>90))&&
        ((n<97)||
        (n>122))&&
        ((n<48)||
        (n>57))&&
        (n!=95)) {
      fprintf(stderr,
              "Error: Character '%c' of attribute '%s' must be ",
              token[j], token);
      fprintf(stderr,
              "alphanumeric or underscore\n");
      alphanumericerror = TRUE;     
    }
  } /* end for j */

  return;

}

/**********last record of arff2master.c******************/
