#include "prpcc.h"

/* Global Input and Output files */
FILE *onemstfile;
FILE *twomstfile;
FILE *totalmstfile;

/* function prototypes */
void openfiles(char *onemst_filename, char *twomst_filename,
               char *totalmst_filename);
int stringCompare(const char *a, const char *b, int n);
void writeline(FILE *output_trn, char line[]);

/* main function */
int main(int argc, char *argv[])
{
  char onemst_filename[MAX_ID];
  char twomst_filename[MAX_ID];
  char totalmst_filename[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  int recordType, termflag;

  if (argc != 4) {
    fprintf(stderr,
"Calling Sequence: twomasters2onemaster one.mst two.mst total.mst\n");
    exit(1);
  }
  strcpy(onemst_filename, argv[1]);
  strcpy(twomst_filename, argv[2]);
  strcpy(totalmst_filename, argv[3]);

  /* DEBUG: Comment out above and uncomment below */
  /* strcpy(onemst_filename, "sample.1.mst");
  strcpy(twomst_filename, "sample.2.mst");
  strcpy(totalmst_filename, "total.mst"); */  

  openfiles(onemst_filename,twomst_filename,totalmst_filename);

  /* copy ATTRIBUTES section of onemstfile to totalmstfile */
  recordType = 0;
  while (fgets(lineread, MAXLEN, onemstfile) != NULL) { 
    /* while #1 */
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0')) {
      continue;
    }
    writeline(totalmstfile,lineread);
    if (stringCompare(lineread,"DATA",4) == 0) {
      recordType = DATA;
      break;
    }
  } /* end while #1 */
  if (recordType != DATA) {
    fprintf(stderr,"Missing DATA record in input onemst file\n");
    exit(1);
  }

  /* advance twomstfile to DATA record */
  recordType = 0;
  while (fgets(lineread, MAXLEN, twomstfile) != NULL) { 
    /* while #2 */
    if (stringCompare(lineread,"DATA",4) == 0) {
      recordType = DATA;
      break;
    }
  } /* end while #2 */
  if (recordType != DATA) {
    fprintf(stderr,"Missing DATA record in input twomst file\n");
    exit(1);
  }

  /* alternately read record from onemst and twomst, and write */
  /* to totalmst file */
  /* if either input file is exhausted, stop using that file */
  termflag = 0;
  while (termflag != 3) { /* while #3 */
    /* process onemst */
    if ((termflag == 0) || (termflag == 1)) {
      if (fgets(lineread, MAXLEN, onemstfile) == NULL) {
        fprintf(stderr,
                "Missing ENDATA record in input onemst file\n");
        exit(1);
      }
      if (stringCompare(lineread,"ENDATA",6) == 0) {
        /* onemst has been processed */
        if (termflag == 1) {
          /* both onemst and twomst have been processed */
          termflag = 3;
          continue;
        }
        if (termflag == 0) {
          /* onemst has been processed */
          termflag = 2;
        }    
      } else {
        writeline(totalmstfile,lineread);
      } /* end if stringCompare(lineread,"ENDATA",6) == 0 */
    } /* end if (termflag == 0) || (termflag == 1) */

    /* process twomst */
    if ((termflag == 0) || (termflag == 2)) {
      if (fgets(lineread, MAXLEN, twomstfile) == NULL) {
        fprintf(stderr,
                "Missing ENDATA record in input twomst file\n");
        exit(1);
      }
      if (stringCompare(lineread,"ENDATA",6) == 0) {
        /* twomst has been processed */
        if (termflag == 2) {
          /* both onemst and twomst have been processed */
          termflag = 3;
          continue;
        }
        if (termflag == 0) {
          /* twomst has been processed */
          termflag = 1;
        }    
      } else {
        writeline(totalmstfile,lineread);
      } /* end if stringCompare(lineread,"ENDATA",6) == 0 */
    } /* end if (termflag == 0) || (termflag == 1) */    
  } /* end while #3 */

  /* finish totalmst */
  writeline(totalmstfile,lineread);  

  fclose(onemstfile);
  fclose(twomstfile);
  fclose(totalmstfile);

  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *onemst_filename, char *twomst_filename,
               char *totalmst_filename)
{
  if ((onemstfile = fopen(onemst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "twomasters2onemaster: Cannot open %s\n", "onemst_filename");
    exit(1); 
  }   

  if ((twomstfile = fopen(twomst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "twomasters2onemaster: Cannot open %s\n", "twomst_filename");
    exit(1);
  }
  if ((totalmstfile = fopen(totalmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "twomasters2onemaster: Cannot open %s\n", "totalmst_filename");
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  writeline
 * 
 *  purpose:  prints line of text to a file
 *            
 *********************************************************/
void writeline(FILE *output_trn, char line[])
{
  fprintf(output_trn, "%s", line);
}
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}

/* last record of master2trainmsttestmst.c****/
