#include "prpcc.h"

/* input and output files */
FILE *inputmstfile;
FILE *sequencefile;
FILE *outputmstfile;
char inputmst_filename[MAX_ID];
char sequence_filename[MAX_ID];
char outputmst_filename[MAX_ID];

/* call parameters */
int numCallParams;
char callParams[2+3*MAX_CONDITION+1][MAX_ID];
int sampleSize;

/* attribute names and lines */
char attribute[MAX_ATTRIBUTE+1][MAX_ID];
char attributeLine[MAX_ATTRIBUTE+1][MAX_ENTRY];
char sequenceAttribute[MAX_ATTRIBUTE+1][MAX_ID];
int attributeIndex[MAX_ATTRIBUTE+1];
int numAttributes; /* total number of attributes */
int numSequenceAttributes; /* number of sequence attributes */
                   /* must match number of attributes */

/* records */
char record[MAX_ATTRIBUTE+1][MAX_NUM];

/* function prototypes */
void openfiles();
void outputAttributes();
void outputRecord();
void storeAttribute(char lineread[]);
void storeSequenceAttribute(char lineread[]);
void storeParameters();
int stringCompare(const char *a, const char *b, int n);

/* main function */
int main(int argc, char *argv[])
{
  char lineread[MAXLEN] = {'\0'};
  int i, nz;
  int recordType;

  numCallParams = argc - 1;
  for (i=1; i<=numCallParams; i++) {
    strcpy(callParams[i],argv[i]);
    }

  /* DEBUG parameter definition */
  /* numCallParams = 3;
  strcpy(callParams[1],"sample.mst");
  strcpy(callParams[2],"sequence.mst");
  strcpy(callParams[3],"reordered.mst"); */
  /* end DEBUG definitions */

  /* store call parameters in file names and options */
  storeParameters();

  /* open all files */
  openfiles();

  numAttributes = 0;
  numSequenceAttributes = 0;

  recordType = FALSE;

  /* read sequence file */
  while (fgets(lineread, MAXLEN, sequencefile) != NULL) {

    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return and whitespace 
     * at the end of the line
     */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    if (stringCompare(lineread, "ATTRIBUTES", 10) == 0) {
      recordType = ATTRIBUTE;

    } else if ((stringCompare(lineread, "ENDATA", 6) == 0) ||
	      (stringCompare(lineread, "ENDDATA", 7) == 0)) {
      recordType = ENDATA;
      break; 
   
    } else if (lineread[0] == '*') {
      continue;
		
    } else if (strcmp(lineread,"") == 0) {
      continue;

    } else if (recordType == ATTRIBUTE) {
      storeSequenceAttribute(lineread);
			
    } else {
      fprintf(stderr,
"master2sequencemaster: unidentifiable\n %s\n line in sequence file\n",
      lineread);
      exit(1); 
    }
  }

  if (recordType != ENDATA) {
    fprintf(stderr,
        "master2sequencemaster: sequence file has no ENDATA\n");
      exit(1);
  }
  if (numSequenceAttributes == 0) {
    fprintf(stderr,
     "master2sequencemaster: sequence file contains no attributes\n");
      exit(1);
  }

  recordType = FALSE;

  /* read input master file */
  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) {

    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return and whitespace 
     * at the end of the line
     */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* Determine record type */
    if (stringCompare(lineread, "DATA", 4) == 0) {
      outputAttributes();
      fprintf(outputmstfile,"DATA\n");
      recordType = DATA;

    } else if (stringCompare(lineread, "ATTRIBUTES", 10) == 0) {
      recordType = ATTRIBUTE;

    } else if ((stringCompare(lineread, "ENDATA", 6) == 0) ||
	      (stringCompare(lineread, "ENDDATA", 7) == 0)) {
      recordType = ENDATA;
      break; 
   
    } else if (lineread[0] == '*') {
      continue;
		
    } else if (strcmp(lineread,"") == 0) {
      continue;

    } else if (recordType == ATTRIBUTE) {
      storeAttribute(lineread);
			
    } else if (recordType == DATA) {
      outputRecord(lineread);

    } else {
      fprintf(stderr,
        "master2sequencemaster: unidentifiable line in input master\n");
      exit(1); 
    }
  }

  if (recordType != ENDATA) {
     fprintf(stderr,
        "master2sequencemaster: missing ENDATA of input.mst\n");
      exit(1);
  }

  fprintf(outputmstfile,"ENDATA\n");

  /* close files */
  fclose(inputmstfile);
  fclose(sequencefile);
  fclose(outputmstfile); 
  
  return 0;

}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input, sequence, and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles()
{
  if ((inputmstfile = fopen(inputmst_filename, "r")) == NULL) {
    fprintf(stderr, "master2sequencemaster: Cannot open %s\n", 
                    inputmst_filename);
    exit(1); 
  }   

  if ((sequencefile = fopen(sequence_filename, "r")) == NULL) {
    fprintf(stderr, "master2sequencemaster: Cannot open %s\n", 
                    sequence_filename);
    exit(1);
  }

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, "master2sequencemaster: Cannot open %s\n", 
                    outputmst_filename);
    exit(1); 
  }

  return;
  
}
/*eject*/
/*********************************************************
 *  outputAttributes
 * 
 *  purpose:  output correctly sequenced attributes of
 *            input master in output master
 *********************************************************/
void outputAttributes() {

  int i, j, flag;
  int duplicate[MAX_ATTRIBUTE+1];

  for (j=1; j<=numAttributes; j++) {
    duplicate[j] = 0;
  } 

  fprintf(outputmstfile,"ATTRIBUTES\n");

  /* determine index of attributes for output master file */
  for (i=1; i<=numSequenceAttributes; i++) {
    flag = FALSE;

    for (j=1; j<=numAttributes; j++) {
      if (strcmp(sequenceAttribute[i],attribute[j]) == 0) {
        flag = TRUE;
        attributeIndex[i] = j;
        duplicate[j]++;
        if (duplicate[j] > 1) {
          fprintf(stderr,
          "Error, duplicate attribute name %s in sequence file\n",
          attribute[j]);
          exit(1);
        }
        break;
      }
    }

    if (flag == FALSE) {
      fprintf(stderr, 
 "master2sequencemaster: Cannot find attribute %s of sequence file in input master file\n", 
         sequenceAttribute[i]);
      exit(1); 
    }
  }

  /* output attribute lines to output master according to indices */
  for (i=1; i<=numSequenceAttributes; i++) {
    fprintf(outputmstfile,"%s\n",attributeLine[attributeIndex[i]]);
  }

  return;

}
/*eject*/
/*********************************************************
 *  outputRecord
 * 
 *  purpose:  output record in attributeIndex[] sequence
 *********************************************************/
void outputRecord(char fileRec[]) {

  char saveread[MAXLEN];
  char *buffer;
  int i;

  strcpy(saveread,fileRec);

  /* get data entries as strings */
  for (i=1; i<=numAttributes; i++) {
    if (i == 1) {
      buffer = strtok(fileRec, " \t\n");
    } else {
      buffer = strtok(NULL, " \t\n");
    }
    if (buffer == NULL) {
      fprintf(stderr,
  "master2sequencemaster: error,data record \n%s\n has too few entries\n",
       saveread);
    exit(1); 
    }
    strcpy(record[i],buffer);
  } /* end for i */

  buffer = strtok(NULL, " \t\n");
  if (buffer != NULL) {
      fprintf(stderr,
 "master2sequencemaster: error, data record \n%s\n has too many entries\n",
       saveread);
    exit(1); 
  }

  /* output entries according to attributeIndex[] */
  for (i=1; i<=numSequenceAttributes; i++) {
    fprintf(outputmstfile,"%s\t",record[attributeIndex[i]]);
  }
  fprintf(outputmstfile,"\n");

  return;

}
/*eject*/
/*********************************************************
 *  storeAttribute
 *
 *  purpose:  store attribute line in attributeLine[]
 *                  attribute name in attribute[]
 *********************************************************/
void storeAttribute(char lineread[]) {

  char *buffer;

  numAttributes++;
  if (numAttributes+1 > MAX_ATTRIBUTE) {
    fprintf(stderr,
            "master2sequencemaster: error, too many attributes\n");
    exit(1);
  }

  strcpy(attributeLine[numAttributes],lineread);
  buffer = strtok(lineread," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
            "master2sequencemaster: error, empty attribute line\n");
    exit(1); 
  }  
  strcpy(attribute[numAttributes],buffer);

  return;
}
/*eject*/
/*********************************************************
 *  storeParameters
 *
 *  input:    numCallParams, callParams[] 
 *  purpose:  store parameters of call
 *********************************************************/
void storeParameters() {

  if (numCallParams!=3){
    fprintf(stderr,
      "Calling Sequence:  master2sequencemaster input.mst sequence.mst output.mst\n");
    exit(1);
  }
  strcpy(inputmst_filename, callParams[1]);
  strcpy(sequence_filename, callParams[2]);
  strcpy(outputmst_filename, callParams[3]);

  return;
}
/*eject*/
/*********************************************************
 *  storeSequenceAttribute
 *
 *  purpose:  store attribute in sequenceAttribute[]
 *********************************************************/
void storeSequenceAttribute(char lineread[]) {

  char *buffer;

  numSequenceAttributes++;
  if (numSequenceAttributes+1 > MAX_ATTRIBUTE) {
    fprintf(stderr,
     "master2sequencemaster: error, too many sequence attributes\n");
    exit(1);
  }

  buffer = strtok(lineread," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
    "master2sequencemaster: error, empty sequence attribute line\n");
    exit(1); 
  }  
  strcpy(sequenceAttribute[numSequenceAttributes],buffer);

  return;
}
/*eject*/
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}


/* last record of master2sequencemaster.c****/
