/* first record of master2subdnfmaster.c****/
#include "prpcc.h"

/* input and output files */
FILE *mstfile;
FILE *submstfile;
char mst_filename[MAX_ID];
char submst_filename[MAX_ID];

/* call parameters */
int numCallParams;
char callParams[MAX_CONDITION*MAX_CONDITION+1][MAX_ID];

/* attribute names and lines */
char attribute[MAX_ATTRIBUTE+1][MAX_ID];
char attributeLine[MAX_ATTRIBUTE+1][MAX_ENTRY];
int attributeKeepFlag[MAX_ATTRIBUTE+1];
int numAttributes; /* total number of attributes */

/* arrays for sorting records according to one attribute */
struct{
char name[MAX_ID]; /* name of attribute whose */
                   /* values are to be sorted */
int index; /* index of attribute to be sorted */
double value[MAX_RECORD_HUGE+1]; /* values of */
                                /* attribute to be sorted */
} typedef SortAttribute;
SortAttribute attributeToBeSorted;

/* records */
char record[MAX_RECORD_HUGE+1][MAX_ATTRIBUTE+1][MAX_NUM];
int numRecords; /* total number of records */
int numInputRecords;
int sortedRecordIndex[MAX_RECORD_HUGE+1];
  /* sortedRecordIndex[i] = just before output step, index */
  /*      of record that becomes ith record in final output */

/* DNF formula */
struct{
  char name[MAX_ID];     /* attribute */
  int index;             /* index of attribute */
  char relation[MAX_ID]; /* relation of DNF term */
  double value;          /* bound value */
} typedef DNFterm;
struct{
  DNFterm term[MAX_CONDITION+1];
  int numTerms;
} typedef DNFclause;
DNFclause clause[MAX_CONDITION+1];
int numClauses;

/* bounds on record size for acceptance */
int lowRecordSize;
int highRecordSize;

/* options */
struct{
  int deleteMonotoneAttributes;
  int omitATTRIBUTESsection;
  int omitDATAstatement;
  int omitENDATAstatement;
  int sortAttribute; /* TRUE: sort one attribute */
                     /* FALSE: no sorting */
  int low2high; /* TRUE: sort low to high */
                /* FALSE: sort high to low */
  int nodisplayInputParameters; 
} typedef OptionList;

OptionList option;

/* function prototypes */
void bubbleSort(double *a, int *idx, int n, int lohirule);
void checkRecord(char lineread[]);
void completeFormula();
void computeAttributeKeepFlag();
int  getIndex(char *attribute);
void openfiles();
void outputSubDnfmaster();
void sortAttribute();
void storeAttribute(char lineread[]);
void storeParameters();

/* main function */
int main(int argc, char *argv[])
{
  char lineread[MAXLEN] = {'\0'};
  int endDataFlag = FALSE;
  int i, nz;
  int recordType = FALSE;  /* suppresses compiler warning */

  numCallParams = argc - 1;
  for (i=1; i<=numCallParams; i++) {
    strcpy(callParams[i],argv[i]);
    }

  /* DEBUG parameter definition */
  /* numCallParams = 5;
  strcpy(callParams[1],"small.train.mst");
  strcpy(callParams[2],"output.mst");
  strcpy(callParams[3],"-sort");
  strcpy(callParams[4],"x");
  strcpy(callParams[5],"low2high"); */
  /* end DEBUG definitions */

  /* store call parameters in file names and limit arrays */
  storeParameters();

  /* open all files */
  openfiles();

  numAttributes = 0;
  numRecords = 0;
  numInputRecords = 0;

  /* read input master file */
  while (fgets(lineread, MAXLEN, mstfile) != NULL) {

    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return and whitespace 
     * at the end of the line
     */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* Determine record type */
    if (strncmp(lineread, "DATA", 4) == 0) {
      recordType = DATA;
      completeFormula(); /* add indices to terms of DNF formula */

      if ((option.sortAttribute == TRUE) && 
          (attributeToBeSorted.index == 0)) {
        /* specified attribute for sorting of records */
        /* is not among the given attributes of input file */
        fprintf(stderr,
           "master2subdnfmaster: Attribute %s ",
           attributeToBeSorted.name);
        fprintf(stderr,
          "for sorting does not occur in input file\n");
        exit(1);       
      }

    } else if (strncmp(lineread, "ATTRIBUTES", 10) == 0) {
      recordType = ATTRIBUTE;

    } else if ((strncmp(lineread, "ENDATA", 6) == 0) ||
	      (strncmp(lineread, "ENDDATA", 7) == 0)) {
      endDataFlag = TRUE;
      break; 
   
    } else if (lineread[0] == '*') {
      continue;
		
    } else if (strcmp(lineread,"") == 0) {
      continue;

    } else if (recordType == ATTRIBUTE) {
      storeAttribute(lineread);
			
    } else if (recordType == DATA) {
      /* check record using DNF formula
       * if DNF formula is satisfied, keep record
       * else discard record
       */
      numInputRecords++;
      checkRecord(lineread);

    } else {
      fprintf(stderr,
        "master2subdnfmaster: unidentifiable line in input master\n");
      exit(1); 
    }
  }

  if (endDataFlag == FALSE) {
    fprintf(stderr,
        "master2subdnfmaster: missing ENDATA in input file\n");
      exit(1);
  }

  /* option: delete monotone attributes */
  if (option.deleteMonotoneAttributes == TRUE) {
    computeAttributeKeepFlag();
  }

  /* initialize index for records */
  for (i=1; i<=numRecords; i++) {
    sortedRecordIndex[i] = i;
  }

  /* option: sort according to specified attribute */
  if (option.sortAttribute == TRUE) {
    sortAttribute();
  }

  /* output subdnf master */
  outputSubDnfmaster();

  /* close files */
  fclose(mstfile);
  fclose(submstfile); 
  
  return 0;

}
/*eject*/
/***************************************************************
 *--------------------------------------------------------------
 * bubbleSort(double *a, int *idx, int n, int lohirule):
 *   input:  a[] array with n entries
 *           idx[i] = i for all i
 *           lohirule = TRUE: sort low to high
 *                      FALSE: sort high to low
 *   output: a[] with entries sorted in order indicated by lohirule.
 *           idx[i] = original index of a[] value now in position i.
 *--------------------------------------------------------------
 ***************************************************************/
void bubbleSort(double *a, int *idx, int n, int lohirule) {

  int flag, i, j, k;
  double b;

  for (k=n-1; k>=1; k--) {

    flag = 0;

    if (lohirule == TRUE) {
      for (i=1; i<=k; i++) {
        if (a[i] > a[i+1]) { /* sort low to high */
          b = a[i];
          a[i] = a[i+1];
          a[i+1] = b;
          j = idx[i];
          idx[i] = idx[i+1];
          idx[i+1] = j;
          flag = 1;
        }
      } /* end for i */
    } else {
      for (i=1; i<=k; i++) {
        if (a[i] < a[i+1]) { /* sort high to low */
          b = a[i];
          a[i] = a[i+1];
          a[i+1] = b;
          j = idx[i];
          idx[i] = idx[i+1];
          idx[i+1] = j;
          flag = 1;
        }
      } /* end for i */
    } /* end if lohirule == TRUE, else */

    if (flag == 0) {
      return;
    }

  } /* end for k */

  return;

} /* end bubbleSort */
/*eject*/
/*********************************************************
 *  checkRecord
 * 
 *  purpose:  parse record
 *            determine number of non"?" entries
 *            keep record if
 *              - number of non"?" entries > lowRecordSize
 *              - number of non"?" entries < highRecordSize
 *              - non"?" attribute entries observe limits
 *                specified in lowLimit and highLimit
 *********************************************************/
void checkRecord(char fileRec[])
{

  int i, j, jx, n;
  int formulaflag, clauseflag;

  double rec[MAX_ATTRIBUTE+1], val;

  char saveRec[MAXLEN];
  char rel[MAX_ID];
  char *buffer;

  strcpy(saveRec,fileRec); /* for error messages */

  numRecords++;
  if (numRecords+1 > MAX_RECORD_HUGE) {
    fprintf(stderr,
            "master2subdnfmaster: error, too many records\n");
    exit(1);
  }
  
  //Read first record entry
  buffer = strtok(fileRec, " \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
            "master2subdnfmaster: error, empty record line\n");
    exit(1); 
  }
  j = 1;
  if (buffer[0] == '?') {
    n = 0;
  } else {
    n = 1;
    rec[j] = atof(buffer);
  }

  strcpy(record[numRecords][j],buffer);

  //process remaining record entries
  for (j=2; j<=numAttributes; j++) {
    buffer = strtok(NULL," \t\n)");
    if (buffer == NULL){
      fprintf(stderr,
       "master2subdnfmaster: error, record has too few entries:\n");
      fprintf(stderr,"%s\n",saveRec);     
      exit(1); 
    }
    strcpy(record[numRecords][j],buffer); 
    if (buffer[0] != '?') {
      n++;
      rec[j] = atof(buffer);
    }  
  } /* end for j */

  /* check if entire record has been processed */
  buffer = strtok(NULL," \t\n)");
  if (buffer != NULL){
    fprintf(stderr,
      "master2subdnfmaster: error, record has too many entries:\n");
      fprintf(stderr,"%s\n",saveRec);  
    exit(1); 
  }  

  /* recordSize limits */
  /* check if n < lowRecordSize or > highRecordSize */
  if ((n < lowRecordSize) || (n > highRecordSize)) {
    numRecords--;
    return;
  }

  /* check if record entries satisfy DNF formula */
  if (numClauses == 0) { /* empty formula is always satisfied */
    formulaflag = TRUE;
  } else {
    formulaflag = FALSE;
  }
  for (i=1; i<=numClauses; i++) {
    clauseflag = TRUE;
    for (jx=1; jx<=clause[i].numTerms; jx++) {
      j = clause[i].term[jx].index;
      val = clause[i].term[jx].value;
      strcpy(rel,clause[i].term[jx].relation);
      if (record[numRecords][j][0] == '?') {
        /* clause evaluates to False */
        clauseflag = FALSE;
        break;
      }
      /* test condition of term */
      if (strcmp(rel,"le") == 0) {
        if (rec[j] > val) {
          clauseflag = FALSE;
          break;
        } else {
          continue;
        }
      } 
      if (strcmp(rel,"ge") == 0) {
        if (rec[j] < val) {
          clauseflag = FALSE;
          break;
        } else {
          continue;
        }
      }
      if (strcmp(rel,"lt") == 0) {
        if (rec[j] >= val) {
          clauseflag = FALSE;
          break;
        } else {
          continue;
        }
      }
      if (strcmp(rel,"gt") == 0) {
        if (rec[j] <= val) {
          clauseflag = FALSE;
          break;
        } else {
          continue;
        }
      }
      if (strcmp(rel,"eq") == 0) {
        if (rec[j] != val) {
          clauseflag = FALSE;
          break;
        } else {
          continue;
        }
      }
      fprintf(stderr,
      "Error in master2subdnfmaster: should not reach this point\n");
      exit(1);    
    } /* end for jx */
    if (clauseflag == TRUE) {
      formulaflag = TRUE;
      break;
    }
  } /* end for i */

  if (formulaflag == FALSE) {
    /* skip record */
    numRecords--;
    return;
  }
/*eject*/
  /* if records are to be sorted according to one attribute, */
  /* retain value of that attribute */
  /* if value unknown, assign QUESTION_MARK, which is a large value */
  if (option.sortAttribute == TRUE) {
    if (record[numRecords][attributeToBeSorted.index][0] != '?') {
      attributeToBeSorted.value[numRecords] = 
        rec[attributeToBeSorted.index];
    } else {
      attributeToBeSorted.value[numRecords] = QUESTION_MARK;
    }
  }

  return;

}

/*eject*/
/*********************************************************
 *  completeFormula
 * 
 *  purpose:  add attribute indices to DNF formula
 *********************************************************/
void completeFormula() {

  int i, j;

  for (i=1; i<=numClauses; i++) {
    for (j=1; j<=clause[i].numTerms; j++) {
      clause[i].term[j].index = getIndex(clause[i].term[j].name);
    }
  }

  return;

}
/*eject*/
/*********************************************************
 *  computeAttributeKeepFlag
 * 
 *  purpose:  compute attributeKeepFlag[]
 *            attribute is kept iff its column is not monotone
 *********************************************************/
void computeAttributeKeepFlag() {

  char oneEntry[MAX_ID];
  int i, j, monotoneFlag;

  /* find and delete monotone columns */
  for (j=1; j<=numAttributes; j++) {
    monotoneFlag = 0;
    oneEntry[0] = '\0';
    for (i=1; i<=numRecords; i++) {
      if (record[i][j][0] == '?') {
        continue;
      } else {
        if (strcmp(oneEntry,record[i][j]) !=0) {
          monotoneFlag++;
          strcpy(oneEntry,record[i][j]);          
        } 
        if (monotoneFlag >= 2) {
          break;
        }
      }
    } /* end for i */

    if (monotoneFlag < 2) {
      attributeKeepFlag[j] = FALSE;
    }
   
  } /* end for j */  

  return;

}
/*eject*/
/*********************************************************
 *  getIndex
 * 
 *  purpose:  returns index for attribute name as 
 *            appears in mst file ATTRIBUTES section
 *********************************************************/
int getIndex(char *name)
{
  int i;
  for (i=1; i<=numAttributes; i++) {
    if (strcmp(attribute[i], name) == 0) {
      return i;
    }
  }
  
  printf(
  "master2subdnfmaster: getIndex():  Attribute not found: %s\n", 
  name);
  exit(1);

  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles()
{
  if ((mstfile = fopen(mst_filename, "r")) == NULL) {
    fprintf(stderr, "master2subdnfmaster: Cannot open %s\n", 
                    mst_filename);
    exit(1); 
  }   

  if ((submstfile = fopen(submst_filename, "w")) == NULL) {
    fprintf(stderr, "master2subdnfmaster: Cannot open %s\n", 
                    submst_filename);
    exit(1);
  }
}
/*eject*/
/*********************************************************
 *  outputSubDnfmaster
 * 
 *  purpose:  output reduced master to submaster file
 *********************************************************/
void outputSubDnfmaster() {

  int i, j;

  if (option.omitATTRIBUTESsection == FALSE) {
    fprintf(submstfile,"ATTRIBUTES\n");

    for (j=1; j<=numAttributes; j++) {
      if (attributeKeepFlag[j] == TRUE) {
        fprintf(submstfile,"%s\n",attributeLine[j]);
      }
    }
  }

  if (option.omitDATAstatement == FALSE) {
    fprintf(submstfile,"DATA\n");
  }

  for (i=1; i<=numRecords; i++) {
    for (j=1; j<=numAttributes; j++) {
      if (attributeKeepFlag[j] == TRUE) {
        fprintf(submstfile,"%s\t",record[sortedRecordIndex[i]][j]);
      }
    }
    fprintf(submstfile,"\n");
  }

  if (option.omitENDATAstatement == FALSE) {
    fprintf(submstfile,"ENDATA\n");  
  }
/*eject*/
  /* display summary of results */
  if (option.nodisplayInputParameters == FALSE) {
    printf("Results:\n");
    printf("  Number of attributes:  %d\n",numAttributes);
    printf("  Number of records of input file:  %d\n",
           numInputRecords);
    printf("  Number of records of output file:  %d\n",
           numRecords);

    printf("\n");
    printf("Output in %s\n\n",submst_filename);
  }

  return;

}
/*eject*/
/*********************************************************
 *  sortAttribute
 *
 *  purpose:  sort records according to one attribute
 *********************************************************/
void sortAttribute() {

  int i;
  double a[MAX_RECORD_HUGE+1];

  if (attributeKeepFlag[attributeToBeSorted.index] == FALSE) {
    /* attribute to be sorted has been deleted */
    fprintf(stderr,"master2subdnfmaster: Attribute %s ",
                   attributeToBeSorted.name);
    fprintf(stderr,"is to be used to sort records, but that ");
    fprintf(stderr,"attribute has been deleted\n");
  }

  for (i=1; i<=numRecords; i++) {
    a[i] = attributeToBeSorted.value[i];
  }
  bubbleSort(a,sortedRecordIndex,numRecords,option.low2high);

  return;

}
/*eject*/
/*********************************************************
 *  storeAttribute
 *
 *  purpose:  store attribute line in attributeLine[]
 *                  attribute name in attribute[]
 *********************************************************/
void storeAttribute(char lineread[]) {

  char *buffer;

  numAttributes++;
  if (numAttributes+1 > MAX_ATTRIBUTE) {
    fprintf(stderr,
            "master2subdnfmaster: error, too many attributes\n");
    exit(1);
  }
  strcpy(attributeLine[numAttributes],lineread);
  buffer = strtok(lineread," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
            "master2subdnfmaster: error, empty attribute line\n");
    exit(1); 
  }  
  strcpy(attribute[numAttributes],buffer);

  /* initialize option for keeping attribute */
  attributeKeepFlag[numAttributes] = TRUE;

  /* check is this is the attribute according to which */
  /* the final output records are to be sorted */
  if ((option.sortAttribute == TRUE) &&
      (strcmp(attribute[numAttributes],
              attributeToBeSorted.name) == 0)) {
    attributeToBeSorted.index = numAttributes;
  }

  return;
}
/*eject*/
/*********************************************************
 *  storeParameters
 *
 *  input:    numCallParams, callParams[] 
 *  purpose:  store parameters of call
 *********************************************************/
void storeParameters() {

  int j, k;

  /* initialize options to default values */

  option.deleteMonotoneAttributes = FALSE;
  option.omitATTRIBUTESsection = FALSE;
  option.omitDATAstatement = FALSE;
  option.omitENDATAstatement = FALSE;
  option.sortAttribute = FALSE;

  lowRecordSize = 0;
  highRecordSize = MAX_ATTRIBUTE + 1;

  numClauses = 0;

  if (numCallParams<=2) {
    fprintf(stderr,
      "Calling Sequence:  master2subdnfmaster master.mst submaster.mst  options limits DNF-clauses\n");
    exit(1);
  }
  strcpy(mst_filename, callParams[1]);
  strcpy(submst_filename, callParams[2]);

  k = 3;
  while (k < numCallParams) { /* while #1 */

    /* options */
    if ((strcmp(callParams[k],"-delete") == 0) &&
        (strcmp(callParams[k+1],"monotone") == 0) &&
        (strcmp(callParams[k+2],"attributes") == 0)) {
      option.deleteMonotoneAttributes = TRUE;
      k += 3;
      continue;
    }
    if ((strcmp(callParams[k],"-nodisplay") == 0) &&
        (strcmp(callParams[k+1],"input") == 0) &&
        (strcmp(callParams[k+2],"parameters") == 0)) {
      option.nodisplayInputParameters = TRUE;
      k += 3;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"ATTRIBUTES") == 0) &&
        (strcmp(callParams[k+2],"section") == 0)) {
      option.omitATTRIBUTESsection = TRUE;
      k += 3;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"DATA") == 0) &&
        (strcmp(callParams[k+2],"statement") == 0)) {
      option.omitDATAstatement = TRUE;
      k += 3;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"ENDATA") == 0) &&
        (strcmp(callParams[k+2],"statement") == 0)) {
      option.omitENDATAstatement = TRUE;
      k += 3;
      continue;
    }

    if (strcmp(callParams[k],"-sort") == 0) {
      option.sortAttribute = TRUE;
      strcpy(attributeToBeSorted.name,callParams[k+1]);
      attributeToBeSorted.index = 0;
      if (strcmp(callParams[k+2],"low2high") == 0) {
        option.low2high = TRUE;
      } else if (strcmp(callParams[k+2],"high2low") == 0) {
        option.low2high = FALSE;        
      } else {
        fprintf(stderr,
         "master2subdnfmaster: Unknown rule %s for -sort option\n",
         callParams[k+2]);
        exit(1);
      }
      k += 3;
      continue;
    }

    /* record limits */
    if (strcmp(callParams[k],"-recordsize") == 0) {
      if (strcmp(callParams[k+1],"gt") == 0) {
        lowRecordSize = atoi(callParams[k+2]);
        k += 3;
        continue;
      } else if (strcmp(callParams[k+1],"lt") == 0) {
        highRecordSize = atoi(callParams[k+2]);
        k += 3;
        continue;       
      } else {
        fprintf(stderr,
    "master2subdnfmaster:  '-recordsize' not followed by lt or gt\n");
        exit(1);
      }
    }

    /* DNF clauses */ 
    if (strncmp(callParams[k],"-clause",7) == 0) {
      numClauses++;
      j = 1; /* j = index of clause term */
      k++;
      while ((callParams[k][0] != '-') &&
             (k < numCallParams)) { /* while #2 */
        strcpy(clause[numClauses].term[j].name,callParams[k]);
        k++;
        strcpy(clause[numClauses].term[j].relation,callParams[k]);
        k++;
        clause[numClauses].term[j].value = atof(callParams[k]);
        k++;
        clause[numClauses].numTerms = j;
        j++;
      } /* end while #2 */
      continue;
    }
    fprintf(stderr,
    "Error in storeParameters: should not reach this point\n");
    exit(1);
  } /* end while #1 */

  if (k != numCallParams + 1) {
    fprintf(stderr,"Error in storeParameters, likely caused\n");
    fprintf(stderr,"by incomplete list of options/formula\n");
    exit(1);
  }

  /* display parameters */
  if (option.nodisplayInputParameters == FALSE) {
    printf("\nFiles:\n");
    printf("  Input:  %s\n",callParams[1]);
    printf("  Output: %s\n",callParams[2]);
    printf("Options and DNF formula:");
    for (k=3; k<=numCallParams; k++) {
      if (callParams[k][0] == '-') {
        printf("\n");
      }
      printf(" %s",callParams[k]);
    }
    printf("\n");
  }

   return;

}

/* last record of master2subdnfmaster.c****/
