#include "prpcc.h"

/* input and output files */
FILE *mstfile;
FILE *submstfile;
char mst_filename[MAX_ID];
char submst_filename[MAX_ID];

/* call parameters */
int numCallParams;
char callParams[2+3*MAX_CONDITION+1][MAX_ID];
int sampleSize;

/* attribute names and lines */
char attribute[MAX_ATTRIBUTE+1][MAX_ID];
char attributeLine[MAX_ATTRIBUTE+1][MAX_ENTRY];
int attributeFlag[MAX_ATTRIBUTE+1];
double maxValue[MAX_ATTRIBUTE+1], minValue[MAX_ATTRIBUTE+1];
double scale[MAX_ATTRIBUTE+1];
int numAttributes; /* total number of attributes */

/* records */
char record[MAX_RECORD_HUGE+1][MAX_ATTRIBUTE+1][MAX_NUM];
double value[MAX_RECORD_HUGE+1][MAX_ATTRIBUTE+1];
int recordFlag[MAX_RECORD_HUGE+1];
int numRecords; /* total number of records */

/* samples */
double sample[MAX_RECORD+1][MAX_ATTRIBUTE+1];
int sampleRecordIndex[MAX_RECORD+1];
int numSamples;

/* distances */
double distance[MAX_RECORD_HUGE+1];
double maxminDistMaster2Sample;

/* options */
struct{
  int omitATTRIBUTESsection;
  int omitDATAstatement;
  int omitENDATAstatement;
  int nodisplayInputParameters;
  int sampleSize;
} typedef OptionList;

/* seed array for random generator */
unsigned int mySeed[6];

OptionList option;

/* function prototypes */
void addSample(int nc);
double distance2Vectors(double *x, double *y);
void distanceUpdate(double *x);
int findSample();
void initialize();
double myRand();
void mySrand2();
void openfiles();
void outputSubmaster();
void storeAttribute(char lineread[]);
void storeParameters();
void storeRecord(char lineread[]);
int stringCompare(const char *a, const char *b, int n);

/* main function */
int main(int argc, char *argv[])
{
  char lineread[MAXLEN] = {'\0'};
  int endDataFlag = 0;
  int i, m, n, nz;
  int recordType = FALSE;  /* suppresses compiler warning */

  numCallParams = argc - 1;
  for (i=1; i<=numCallParams; i++) {
    strcpy(callParams[i],argv[i]);
    }

  /* DEBUG parameter definition */
  /* numCallParams = 5;
  strcpy(callParams[1],"smallmaster.mst");
  strcpy(callParams[2],"samplemaster.mst");
  strcpy(callParams[3],"-sample");
  strcpy(callParams[4],"size");
  strcpy(callParams[5],"5"); */
  /* end DEBUG definitions */

  /* store call parameters in file names and options */
  storeParameters();

  /* open all files */
  openfiles();

  numAttributes = 0;
  numRecords = 0;

  /* read input master file */
  while (fgets(lineread, MAXLEN, mstfile) != NULL) {

    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return and whitespace 
     * at the end of the line
     */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* Determine record type */
    if (stringCompare(lineread, "DATA", 4) == 0) {
      recordType = DATA;

    } else if (stringCompare(lineread, "ATTRIBUTES", 10) == 0) {
      recordType = ATTRIBUTE;

    } else if ((stringCompare(lineread, "ENDATA", 6) == 0) ||
	      (stringCompare(lineread, "ENDDATA", 7) == 0)) {
      endDataFlag = TRUE;
      break; 
   
    } else if (lineread[0] == '*') {
      continue;
		
    } else if (strcmp(lineread,"") == 0) {
      continue;

    } else if (recordType == ATTRIBUTE) {
      storeAttribute(lineread);
			
    } else if (recordType == DATA) {
      storeRecord(lineread);

    } else {
      fprintf(stderr,
        "master2samplemaster: unidentifiable line in input master\n");
      exit(1); 
    }
  }

  /* initialize arrays */
  initialize();

  /* construct samples */
  for (m=1; m<=sampleSize; m++) {
    /* select next sample */
    n = findSample();
    if (n == 0) {
      break;
    }
    /* store sample */
    addSample(n);
    /* update distance[] */
    distanceUpdate(sample[numSamples]);
  }  

  /* output submaster */
  outputSubmaster();

  /* close files */
  fclose(mstfile);
  fclose(submstfile); 
  
  return 0;

}
/*eject*/
/************************************************************
 *   addSample(): add record nc to sample[]
 ************************************************************/
void addSample(int nc) {

  int j;

  /* add record nc to sample records */
  numSamples++;
  if (numSamples > MAX_RECORD) {
    fprintf(stderr,
       "MAX_RECORD is too small in addSample()\n");
    exit(1);
  }

  for (j=1; j<=numAttributes; j++) {
    sample[numSamples][j] = value[nc][j];
  }
  /* store reference index */
  sampleRecordIndex[numSamples] = nc;

  /* mark record as used */
  recordFlag[nc] = FALSE;

}
/*eject*/
/************************************************************
 *   distance2vectors(): compute distance between two
 *   records; entries are scaled using scale[] values
 ************************************************************/
double distance2vectors(double *x, double *y) {

  int j;

  double dist;

  dist = 0.0;

  for (j=1; j<=numAttributes; j++) {
    if ((attributeFlag[j] == TRUE) &&
        (x[j] != QUESTION_MARK) &&
        (y[j] != QUESTION_MARK)) {
      dist += pow((x[j]-y[j])/scale[j],2);
    }
  }
  dist = sqrt(dist);

  return dist;

}
/*eject*/
/************************************************************
 *   distanceUpdate(): update distance[] using 
 *   sample record x
 ************************************************************/
void distanceUpdate(double *x) {

  int n;

  for (n=1; n<=numRecords; n++) {
    if (recordFlag[n] == TRUE) {
      distance[n] = min(distance[n],
                        distance2vectors(x,value[n]));
      if (distance[n] <= EPSILON) {
        /* record n is duplicate of sample record x */
        /* mark record n as FALSE and thus no longer */
        /* available */
        recordFlag[n] = FALSE;
      }
    }
  }

  return;

}
/*eject*/
/************************************************************
 *   findSample(): find sample vector
 *   using kmeans++ initialization
 ************************************************************/
int findSample() {

  int n, nselect;
  double thresh, maxdist, squaresum, partialsum;

  maxdist = 0.0;
  squaresum = 0.0;

  for (n=1; n<=numRecords; n++) {
    if (recordFlag[n] == TRUE) {
      squaresum += distance[n] * distance[n];

      maxdist = max(maxdist,distance[n]);
    }
  }

  maxminDistMaster2Sample = maxdist;

  if (maxdist <= EPSILON) {
    /* all records are duplicates of sample records */
    nselect = 0;
  } else {
    /* use kmeans++ initialization rule: draw randomly using */
    /* distance^2 as weight */
    thresh = squaresum * myRand();
    partialsum = 0.0;
    nselect = 0;
    for (n=1; n<=numRecords; n++) {
      if (recordFlag[n] == TRUE) {
        partialsum += distance[n] * distance[n];
        if (partialsum >= thresh) {
          nselect = n;
          break;
        }
      }
    }
  }

  return nselect;

}
/*eject*/
/************************************************************
 * initialize(): initialize maxValue[], minValue[], scale[], one
 * vector of sample[], seeds for random number generator
 ************************************************************/
void initialize() {

  int j, n;

  /* define maxValue[], minValue[] */
  for (j=1; j<=numAttributes; j++) {
    maxValue[j] = NEGINFINITY;
    minValue[j] = INFTY;
    if (attributeFlag[j] == TRUE) {
      for (n=1; n<=numRecords; n++) {
        if (value[n][j] != QUESTION_MARK) {
          maxValue[j] = max(maxValue[j],value[n][j]);
          minValue[j] = min(minValue[j],value[n][j]);
        }
      }
    } /* end if attributeFlag == TRUE */
    if ((maxValue[j] == NEGINFINITY) ||
        (maxValue[j] == minValue[j])) {
      attributeFlag[j] = FALSE;
    }
  }

  /* define scale[] and midpoint of space as first sample vector */
  for (j=1; j<=numAttributes; j++) {
    if (attributeFlag[j] == TRUE) {
      scale[j] = maxValue[j] - minValue[j];
      sample[0][j] = (maxValue[j] + minValue[j])/2.0;
    } else {
    /* pro forma definition */
      scale[j] = 1.0;
      sample[0][j] = 0.0;
    } 
  }

  /* initialize recordFlag[] and distance[] */
  for (n=1; n<=numRecords; n++) {
    recordFlag[n] = TRUE;
    distance[n] = distance2vectors(value[n],sample[0]);    
  }

  /* initialize seeds for random number generator */
  mySrand2();

  return;

}
/*eject*/
/************************************************************
 * myRand() and mySrand2(); random generator, uses 5 individual
 * generators called according to another generator
 ************************************************************/
double myRand() {
  /* random number generator using 5 individual generators */
  /* called according to another generator */
  int k;
  double fac;
  mySeed[0] = ( MULTIPLIER * mySeed[0] + INCREMENT ) % MODULUS;
  fac = (double) mySeed[0];
  fac /= DIVISOR;
  /* select one of 5 generators */
  if (fac <= 0.20) { 
    k = 1;
  } else if (fac <= 0.40) {
    k = 2;
  } else if (fac <= 0.60) { 
    k = 3;
  } else if (fac <= 0.80) { 
    k = 4;
  } else                  { 
    k = 5;
  }
  /* generator random number */
  mySeed[k] = ( MULTIPLIER * mySeed[k] + INCREMENT ) % MODULUS;
  fac = (double) mySeed[k];
  fac /= DIVISOR;
  return fac;
}

/* initialize seed array */ 
void mySrand2() {
  mySeed[0] = INITIAL_SEED;
  mySeed[1] = SEED1;
  mySeed[2] = SEED2;
  mySeed[3] = SEED3;
  mySeed[4] = SEED4;
  mySeed[5] = SEED5;
} 
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles()
{
  if ((mstfile = fopen(mst_filename, "r")) == NULL) {
    fprintf(stderr, "master2samplemaster: Cannot open %s\n", 
                    mst_filename);
    exit(1); 
  }   

  if ((submstfile = fopen(submst_filename, "w")) == NULL) {
    fprintf(stderr, "master2samplemaster: Cannot open %s\n", 
                    submst_filename);
    exit(1);
  }
}
/*eject*/
/*********************************************************
 *  outputSubmaster
 * 
 *  purpose:  output sample to submaster file
 *********************************************************/
void outputSubmaster() {

  int i, j;

  if (option.omitATTRIBUTESsection == FALSE) {
    fprintf(submstfile,"ATTRIBUTES\n");

    for (j=1; j<=numAttributes; j++) {
      fprintf(submstfile,"%s\n",attributeLine[j]);
    }
  }

  if (option.omitDATAstatement == FALSE) {
    fprintf(submstfile,"DATA\n");
  }

  for (i=1; i<=numSamples; i++) {
    for (j=1; j<=numAttributes; j++) {
      fprintf(submstfile,"%s\t",record[sampleRecordIndex[i]][j]);
    }
    fprintf(submstfile,"\n");
  }


  if (option.omitENDATAstatement == FALSE) {
    fprintf(submstfile,"ENDATA\n");  
  }
/*eject*/
  /* display summary of results */
  if (option.nodisplayInputParameters == FALSE) {
    printf("Results:\n");
    printf("  Number of attributes:  %d\n",numAttributes);
    printf("  Number of records:  %d\n",numRecords);
    printf("  Number of samples:  %d\n",numSamples);
    if (numSamples < sampleSize) {
      printf(
       "    Warning: number of samples < requested sample size\n");
    }
    printf("  Maxmin distance master to sample: %f\n",
           maxminDistMaster2Sample);
    printf ("    when all intervals are scaled to width 1\n\n");
    printf("Output in ./%s\n\n",submst_filename);
  }

  return;

}
/*eject*/
/*********************************************************
 *  storeAttribute
 *
 *  purpose:  store attribute line in attributeLine[]
 *                  attribute name in attribute[]
 *********************************************************/
void storeAttribute(char lineread[]) {

  int i;

  char *buffer;

  numAttributes++;
  if (numAttributes+1 > MAX_ATTRIBUTE) {
    fprintf(stderr,
            "master2samplemaster: error, too many attributes\n");
    exit(1);
  }

  /* initialize option for keeping attribute */
  attributeFlag[numAttributes] = TRUE;

  /* search for TARGET and DELETE substring */
  /* and update attributeFlag[] as needed */
  for (i=0; i<=strlen(lineread)-1; i++) {
    if (strncmp(&lineread[i],"DELETE",6) == 0) {
      attributeFlag[numAttributes] = DELETE;
      break;
    }
    if (strncmp(&lineread[i],"TARGET",6) == 0) {
      attributeFlag[numAttributes] = TARGET;
      break;
    }
  }

  strcpy(attributeLine[numAttributes],lineread);
  buffer = strtok(lineread," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
            "master2samplemaster: error, empty attribute line\n");
    exit(1); 
  }  
  strcpy(attribute[numAttributes],buffer);

 

  return;
}
/*eject*/
/*********************************************************
 *  storeParameters
 *
 *  input:    numCallParams, callParams[] 
 *  purpose:  store parameters of call
 *********************************************************/
void storeParameters() {

  int k;

  /* initialize options to default values */
  option.nodisplayInputParameters = FALSE;
  option.omitATTRIBUTESsection = FALSE;
  option.omitDATAstatement = FALSE;
  option.omitENDATAstatement = FALSE;
  option.sampleSize = 500;

  if ((numCallParams<=2) || ((numCallParams-2)%3!=0)) {
    fprintf(stderr,
      "Calling Sequence:  master2samplemaster master.mst submaster.mst -sample size <size>\n");
    exit(1);
  }
  strcpy(mst_filename, callParams[1]);
  strcpy(submst_filename, callParams[2]);

  for (k=3; k<=numCallParams; k+=3) {

    /* options */
    if ((strcmp(callParams[k],"-nodisplay") == 0) &&
        (strcmp(callParams[k+1],"input") == 0) &&
        (strcmp(callParams[k+2],"parameters") == 0)) {
      option.nodisplayInputParameters = TRUE;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"ATTRIBUTES") == 0) &&
        (strcmp(callParams[k+2],"section") == 0)) {
      option.omitATTRIBUTESsection = TRUE;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"DATA") == 0) &&
        (strcmp(callParams[k+2],"statement") == 0)) {
      option.omitDATAstatement = TRUE;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"ENDATA") == 0) &&
        (strcmp(callParams[k+2],"statement") == 0)) {
      option.omitENDATAstatement = TRUE;
      continue;
    }

    /* sample size */
    if (strcmp(callParams[k],"-sample") == 0) {
      if (strcmp(callParams[k+1],"size") == 0) {
        sampleSize = atoi(callParams[k+2]);
        continue;      
      } else {
        fprintf(stderr,
      "master2samplemaster:  '-sample' not followed by 'size'\n");
        exit(1);
      }
    }

    /* unknown parameter */
    fprintf(stderr,
        "master2samplemaster:  parameter not recognized:\n");
        fprintf(stderr,
         "                   %s %s %s\n",
        callParams[k],callParams[k+1],callParams[k+2]);
    exit(1);

  } /* end for k */

  /* display parameters */
  if (option.nodisplayInputParameters == FALSE) {
    printf("\nFiles:\n");
    printf("  Input:  %s\n",callParams[1]);
    printf("  Output: %s\n",callParams[2]);
    printf("Options and Limits:\n");
    for (k=3; k<=numCallParams; k+=3) {
      printf("  %s\t%s\t%s\n",
             callParams[k],callParams[k+1],callParams[k+2]);
    }
  }

   return;
}
/*eject*/
/*********************************************************
 *  storeRecord
 * 
 *  purpose:  parse record and store in value[]
 *********************************************************/
void storeRecord(char fileRec[])
{
  char *buffer;
  int j;

  numRecords++;
  if (numRecords+1 > MAX_RECORD_HUGE) {
    fprintf(stderr,
            "master2samplemaster: error, too many records\n");
    exit(1);
  }
  
  //Read first record entry
  buffer = strtok(fileRec, " \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
            "master2samplemaster: error, empty record line\n");
    exit(1); 
  }
  j = 1;
  if (buffer[0] == '?') {
    value[numRecords][j] = QUESTION_MARK;
  } else {
    value[numRecords][j] = atof(buffer);
  }
  strcpy(record[numRecords][j],buffer);

  //process remaining record entries
  for (j=2; j<=numAttributes; j++) {
    buffer = strtok(NULL," \t\n)");
    if (buffer == NULL){
      fprintf(stderr,
            "master2samplemaster: error, record has too few entries\n");
      exit(1); 
    }
    strcpy(record[numRecords][j],buffer); 
    if (buffer[0] == '?') {
      value[numRecords][j] = QUESTION_MARK;
    } else {
      value[numRecords][j] = atof(buffer);
    }
  }

  /* check if entire record has been processed */
  buffer = strtok(NULL," \t\n)");
  if (buffer != NULL){
    fprintf(stderr,
        "master2samplemaster: error, record has too many entries\n");
    exit(1); 
  }  

  return;

}
/*eject*/
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}


/* last record of master2samplemaster.c****/
