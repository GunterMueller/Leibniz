/* first record of prpcc.h *****/

/******************* Includes **********************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <math.h>
#include <time.h>

/******************* Input Maximums ****************************/
#define MAX_ATTRIBUTE 2000  /* 300 */
#define MAX_CLASS 10     /* max classes for targets */
#define MAX_CONDITION 10 /* max conditions for master2submaster */
#define MAXLEN 5000	       /* length of buffer for file line */ 
#define MAX_RECORD 20100
#define MAX_ID 256
#define MAX_DIRECTORY 256
#define MAX_ENTRY 256
#define MAX_INTERVAL 10
#define MAX_NUM 15  /* max digits of numerical record entry */
/******************* Test File Record Types ********************/
#define A 1
#define B 2
#define SKIP 10
#define ATTRIBUTE 11
#define DATA 12
#define RECORD 13
#define ENDATA 14

#define FALSE 0
#define TRUE 1
#define INFINITY 999999999.0
#define NEGINFINITY -999999999.0

/* last record of prpcc.h ****/
