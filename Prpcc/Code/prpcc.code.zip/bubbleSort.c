/* first record of bubbleSort.c *****/
Two versions of Bubble Sort:

**********************************************************************
**********************************************************************
Sorting when arrays start with index = 0:

/***************************************************************
 *--------------------------------------------------------------
 * bubbleSort(double *a, int *idx, int n, int lohirule):
 *   input:  a[] array with n entries
 *           lohirule = TRUE: sort low to high
 *                      FALSE: sort high to low
 *   output: a[] with entries sorted in order indicated by lohirule.
 *           idx[i] = original index of a[] value now in position i.
 *   caution: arrays start with index = 0
 *--------------------------------------------------------------
 ***************************************************************/
void bubbleSort(double *a, int *idx, int n, int lohirule) {

  int flag, i, j, k;
  double b;

  /* initialize idx[] */
  for (i=0; i<n; i++) {
    idx[i] = i;
  }

  if (n == 1) {
    return;
  }

  for (k=n-2; k>=0; k--) {

    flag = 0;

    if (lohirule == TRUE) {
      for (i=0; i<=k; i++) {
        if (a[i] > a[i+1]) { /* sort low to high */
          b = a[i];
          a[i] = a[i+1];
          a[i+1] = b;
          j = idx[i];
          idx[i] = idx[i+1];
          idx[i+1] = j;
          flag = 1;
        }
      } /* end for i */
    } else {
      for (i=0; i<=k; i++) {
        if (a[i] < a[i+1]) { /* sort high to low */
          b = a[i];
          a[i] = a[i+1];
          a[i+1] = b;
          j = idx[i];
          idx[i] = idx[i+1];
          idx[i+1] = j;
          flag = 1;
        }
      } /* end for i */
    } /* end if lohirule == TRUE, else */

    if (flag == 0) {
      return;  /* initialize idx[] */
  for (i=0; i<n; i++) {
    idx[i] = i;
  }

  if (n == 1) {
    return;
  }
    }

  } /* end for k */

  return;

} /* end bubbleSort */
/*eject*/
**********************************************************************
**********************************************************************

Sorting when arrays start with index = 1:

/***************************************************************
 *--------------------------------------------------------------
 * bubbleSort(double *a, int *idx, int n, int lohirule):
 *   input:  a[] array with n entries
 *           idx[i] = i for all i
 *           lohirule = TRUE: sort low to high
 *                      FALSE: sort high to low
 *   output: a[] with entries sorted in order indicated by lohirule.
 *           idx[i] = original index of a[] value now in position i.
 *
 *--------------------------------------------------------------
 ***************************************************************/
void bubbleSort(double *a, int *idx, int n, int lohirule) {

  int flag, i, j, k;
  double b;

  /* initialize idx[] */
  for (i=1; i<nn; i++) {
    idx[i] = i;
  }

  if (n == 1) {
    return;
  }

  for (k=n-1; k>=1; k--) {

    flag = 0;

    if (lohirule == TRUE) {
      for (i=1; i<=k; i++) {
        if (a[i] > a[i+1]) { /* sort low to high */
          b = a[i];
          a[i] = a[i+1];
          a[i+1] = b;
          j = idx[i];
          idx[i] = idx[i+1];
          idx[i+1] = j;
          flag = 1;
        }
      } /* end for i */
    } else {
      for (i=1; i<=k; i++) {
        if (a[i] < a[i+1]) { /* sort high to low */
          b = a[i];
          a[i] = a[i+1];
          a[i+1] = b;
          j = idx[i];
          idx[i] = idx[i+1];
          idx[i+1] = j;
          flag = 1;
        }
      } /* end for i */
    } /* end if lohirule == TRUE, else */

    if (flag == 0) {
      return;
    }

  } /* end for k */

  return;

} /* end bubbleSort */

**********************************************************************
**********************************************************************
/* last record of bubbleSort.c *****/
