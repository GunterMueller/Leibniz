#include "prpcc.h"

#define curveterm(t) log(t)
        /* typical options for curveterm:
         * sqrt(t)
         * pow(t,2)
         * log(t)
         */
#define approxfunction(a,b,c,t) a+b*t+c*curveterm(t)

struct {
  char oldToken[MAX_ENTRY];
  char newToken[MAX_ENTRY];
} typedef Substitution;

/* Global Input and Output files */
FILE *csvfile;
FILE *subfile;
FILE *statfile;
FILE *mstfile;
char csv_file[MAX_ID];
char sub_file[MAX_ID];
char stat_file[MAX_ID];
char mst_file[MAX_ID];
char lineread[MAXLEN] = {'\0'};
char outputline[MAXLEN] = {'\0'};
char outputtoken[MAX_ATTRIBUTE][MAX_ENTRY];
char delimiter = ',';      /* set delimiter */

/* Global Structure for Substitutions */
char attribute[MAX_ATTRIBUTE][MAX_ENTRY];
int numAttributes = 0;
Substitution globalSub[MAX_ATTRIBUTE];
int numglobalSubs = 0;
int subAttributeIndex[MAX_ATTRIBUTE];
Substitution localSub[MAX_ATTRIBUTE];
int numLocalSubs = 0;
int alphanumericerror;

/* Global Structure for Records and their Values */
int numBeginAttributes;
int numEndAttributes;
int numTimeAttributes;
double timePoint[MAX_TIME_POINT+1];
int numTimePoints;
int numTotalTimeAttributes; /* = numTimeAttributes * numTimePoints */
double usedTimePoint[MAX_TIME_POINT+1];
int numUsedTimePoints;
double attributeValue[MAX_TIME_POINT+1];

/* Global Structure for function representation */
struct {
  double constant;   /* constant of estimating function */
  double slope;      /* slope of estimating function */
  double curve;      /* coefficient of nonlinear term defined */
                     /*   in curveterm(t) */
                     /* values of function and average slopes: */
  double beginvalue; /*   value at t = first time point */
  double midvalue;   /*   value at t = halfway first - last point */
  double endvalue;   /*   value at t = last time point */
  double beginslope; /*   slope from beginvalue to midvalue */
  double endslope;   /*   slope from midvalue to endvalue */
} typedef Coefficients;
Coefficients function;

/* global Structure for Control */
char control[MAX_ID] = {'\0'};

/* Function Prototypes */
void checkAlphanumeric(char *token);
void checkNumeric(char *token);
void computeFunctionResults();
void getAttributes();
void getLinearFunction();
void getNonlinearFunction();
int  getIndex(char *attribute);
void getValueSlope();
void lineread2outputline();
void openFiles(char *csv_filename, 
               char *sub_filename,
               char *stat_filename, 
               char *mst_filename);
void outputline2outputtoken();
void parseSubstitution();
void readStats();
void shiftLeft(char fileRec[]);
void subStr(char dest[], char src[], int offset, int len);
void writeLine(FILE *outputFile, char line[]);

/*
 * CAUTION: 1. Must change delimiter character if not ','.
 *             See "set delimiter" below.
 *          2. The first line of the csv file MUST be
 *             contain the attribute names
 *          3. Attribute names must follow Leibniz convention,
 *             thus must be alphanumeric plus underscore, 
 *             with leading alpha.
 *          4. Attribute list MUST NOT contain blanks.
 *          5. There must be at least two time points
 */

/* main function */
int main(int argc, char *argv[])
{

  int i;
  char comnd[MAX_ID];

 if (argc != 5) {
    printf("Calling Sequence:  csvmultiperiod2master input.csv input.sub input.stat master.mst\n");
    exit(1);
  }
  strcpy(csv_file, argv[1]);
  strcpy(sub_file, argv[2]);
  strcpy(stat_file, argv[3]);
  strcpy(mst_file, argv[4]);

  /* DEBUG: uncomment below and comment out above */
  /* strcpy(csv_file, "tinytest.csv");
  strcpy(sub_file, "tinytest.sub");
  strcpy(stat_file, "tinytest.stat");
  strcpy(mst_file, "tinytest.mst"); */

  /* convert csv file from DOS to Unix */
  sprintf(comnd,"dos2unix %s",csv_file);
  if (system(comnd) != 0) {
    fprintf(stderr,"dos2unix conversion of input file %s failed\n",
                   csv_file);
    exit(1);
  }

  openFiles(csv_file, sub_file, stat_file, mst_file);

  strcpy(control,"STATISTICS");

  /* read statistics file */
  readStats();

  /* get attributes */
  strcpy(control,"ATTRIBUTES"); 
  writeLine(mstfile, "ATTRIBUTES");
  getAttributes();

  /* parse substitution file */
  parseSubstitution();
/*eject*/
 /* process data */
  writeLine(mstfile, "DATA");
  /* Read records and put into DATA section of master file */
  while (fgets(lineread, MAXLEN, csvfile) != NULL) {

    /* convert lineread record to outputline */
    lineread2outputline(lineread,outputline);

    /* break up outputline into output tokens */
    outputline2outputtoken(outputline,outputtoken);

    /* write out values of begin attributes as strings */
    for (i=1; i<=numBeginAttributes; i++) {
      fprintf(mstfile,"%s\t",outputtoken[i]);
    }

    /* compute and write out function results */
    /* for all time attributes */
    computeFunctionResults();

    /* write out values of end attributes as strings */
    for (i=1; i<=numEndAttributes; i++) {
      fprintf(mstfile,"%s\t",
        outputtoken[numBeginAttributes+numTotalTimeAttributes+i]);
    }

    fprintf(mstfile,"\n");

  } /* end while loop */

  writeLine(mstfile, "ENDATA");
  
  fclose(csvfile);
  fclose(subfile);
  fclose(statfile);
  fclose(mstfile);

  /* convert csv file from Unix to DOS */
  sprintf(comnd,"unix2dos %s",csv_file);
  if (system(comnd) != 0) {
    fprintf(stderr,"unix2dos conversion of input file %s failed\n",
                   csv_file);
    exit(1);
  }
  
  return 0;

} /* end main */
/*eject*/
/*********************************************************
 *  checkAlphanumeric
 * 
 *  purpose:  checks if token has alphanumeric form
 *            
 *********************************************************/
void checkAlphanumeric(char *token) {

  int j, n;

  /* first character of token must be alpha or underscore */
  n = (int)token[0];
  if (((n<65)||
      (n>90))&&
      ((n<97)||
      (n>122))&&
      (n!=95)) {
    fprintf(stderr,
            "Error: First character '%c' of attribute '%s' must be ",
            token[0], token);
    fprintf(stderr,
            "alpha or underscore\n");
    alphanumericerror = TRUE;    
  }
/*
 *  remaining characters must be alphanumeric or underscore
 */
  for(j=1; j<=strlen(token)-1; j++)  {
    n = (int)token[j];
    if (((n<65)||
        (n>90))&&
        ((n<97)||
        (n>122))&&
        ((n<48)||
        (n>57))&&
        (n!=95)) {
      fprintf(stderr,
              "Error: Character '%c' of attribute '%s' must be ",
              token[j], token);
      fprintf(stderr,
              "alphanumeric or underscore\n");
      alphanumericerror = TRUE;     
    }
  } /* end for j */

  return;

}
/*eject*/
/*********************************************************
 *  checkNumeric
 * 
 *  purpose:  checks if token has numeric form
 *            
 *********************************************************/
void checkNumeric(char *token) {

  int j, n;

/*
 *  characters must 0 or 1 .. or .. 9 or period or + or -
 */
  for(j=0; j<=strlen(token)-1; j++)  {
    n = (int)token[j];
    if (((n<48)||
         (n>57))&&
        (n!=43)&&
        (n!=45)&&
        (n!=46)) {
      fprintf(stderr,
              "Error: Character '%c' of value '%s' must be ",
              token[j], token);
      fprintf(stderr,
              "numeric or period\n");
      alphanumericerror = TRUE;     
    }
  } /* end for j */

  return;

}
/*eject*/
/*********************************************************
 *  computeFunctionResults()
 * 
 *  purpose:  compute and write out function results for
 *            all time attributes
 *            
 *********************************************************/
void computeFunctionResults() {

  int i, j, n;

  for (i=1; i<=numTimeAttributes; i++) {
    numUsedTimePoints = 0;
    for (j=1; j<=numTimePoints; j++) {
      /* get values from outputtoken[] strings */
      n = numBeginAttributes + (j-1)*numTimeAttributes + i;
      if (strcmp(outputtoken[n],"?") != 0) {
        /* have actual value */
        numUsedTimePoints++;
        usedTimePoint[numUsedTimePoints] = timePoint[j];
        checkNumeric(outputtoken[n]);
        attributeValue[numUsedTimePoints] = atof(outputtoken[n]);
      }
    } /* end for j */

    if (numUsedTimePoints <= 1) {
      /* consider all values for attribute i to be unknown */
      /* use "?" for all function results of attribute */
      fprintf(mstfile,"?\t?\t?\t?\t?\t?\t?\t?\t");
    } else {
      /* have >=2 values for attribute i */
      if (numUsedTimePoints == 2) {
        /* compute constant, slope via subroutine that */
        /* generally uses regression */  
        getLinearFunction();
      } else { 
        /* have >=3 values */
        /* use regression to compute constant, slope, curve */
        getNonlinearFunction();
      }
      /* compute beginvalue,midvalue,endvalue,*/
      /*         beginslope,endslope */
      getValueSlope();
      /* output all function data */
      fprintf(mstfile,"%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t",
        function.constant,function.slope,function.curve,
        function.beginvalue,function.midvalue,function.endvalue,
        function.beginslope,function.endslope);
    } /* end if numUsedTimePoints == 0, else */
      
  } /* end for i */

  return;

}
/*eject*/
/*********************************************************
 *  getAttributes
 * 
 *  purpose:  get attributes
 *            
 *********************************************************/
void getAttributes() {

  int i, startindex;
  char token[MAXLEN] = {'\0'};

  numAttributes = 0;
  /* Grab the first line to get attributes */
  if (fgets(lineread, MAXLEN, csvfile) != NULL) {

    alphanumericerror = FALSE;  
    startindex = 0;
    i=0;
    
    while (lineread[i] != '\n' && lineread[i] != '\0') {
      if (lineread[i] == delimiter) {
        if (i==startindex) {
          fprintf(stderr,
           "Error: Null Token found on attribute line\n");
          fprintf(stderr,
           "Missing attribute names\n");
          exit(1);
        } else {
          subStr(token, lineread, startindex, i-startindex);
          checkAlphanumeric(token);
          numAttributes++;
          if ((numAttributes<=numBeginAttributes) ||
              (numAttributes > numBeginAttributes + 
                               numTotalTimeAttributes)) {
            /* list begin/end attribute in output master file */
            writeLine(mstfile, token);
          } else if (numAttributes <= numBeginAttributes +
                                      numTimeAttributes) { 
            /* have time attribute, define attributes with suffix
             *   _constant 
             *   _slope,
             *   _curve 
             *   _beginvalue 
             *   _midvalue  
             *   _endvalue   
             *   _beginslope
             *   _endslope    
             */
            fprintf(mstfile,"%s_constant\tDELETE\n",token);
            fprintf(mstfile,"%s_slope\tDELETE\n",token);
            fprintf(mstfile,"%s_curve\tDELETE\n",token);
            fprintf(mstfile,"%s_beginvalue\n",token);
            fprintf(mstfile,"%s_midvalue\t\n",token);
            fprintf(mstfile,"%s_endvalue\t\n",token);
            fprintf(mstfile,"%s_beginslope\t\n",token);
            fprintf(mstfile,"%s_endslope\t\n",token);     
          }
          if (numAttributes > MAX_ATTRIBUTE) {
            fprintf(stderr,
            "master2masterABTarget: error, too many attributes\n");
            fprintf(stderr,
            "must increase MAX_ATTRIBUTE in prpcc.h\n");
            exit(1);
          }
          strcpy(attribute[numAttributes-1], token);
          startindex = i+1;
        }
      }
      i++;
    } /* end while */
    /* grab last token */
    if (startindex == i) {
      fprintf(stderr,
      "Null Token found on attribute line\n");
      fprintf(stderr,  "Missing attribute name... Exiting\n");
      exit(1);
    } else {
      subStr(token, lineread, startindex, i-startindex);
      checkAlphanumeric(token);
      numAttributes++;
      if (numAttributes != numBeginAttributes +
                           numTotalTimeAttributes + 
                           numEndAttributes) {
        /* not enough attributes in record */
        fprintf(stderr,"Error: attribute line of .csv input file\n");
        fprintf(stderr,"and counts of .stat file are inconsistent.\n");
        exit(1);
      }
      /* if last attribute is an end attribute, write it out */
      if (numAttributes > numBeginAttributes + 
                          numTotalTimeAttributes) {
        /* list end attribute in output master file */
        writeLine(mstfile, token);
      }
      /* store last attribute */
      strcpy(attribute[numAttributes-1], token);  
    }
  } else {
    fprintf(stderr,
    "Error Reading .csv file.  No input on first line.  Exiting\n");
    exit(1);
  }
  if (alphanumericerror == TRUE) {
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  getIndex
 * 
 *  purpose:  returns index for attribute name as 
 *            appears in mst file ATTRIBUTES section
 *********************************************************/
int getIndex(char *name)
{
  int i = 0;
  for (i=0; i<numAttributes; i++) {
    if (strcmp(attribute[i], name) == 0) {
      return i;
    }
  }
  
  printf("Error in getIndex():  Attribute not found: %s\n", name);
  exit(1);

  return 0;
}
/*eject*/
/*********************************************************
 *  getLinearFunction
 * 
 *  purpose:  get constant and slope of linear function
 *            by regression
 *            
 *********************************************************/
void getLinearFunction() {

  int i, j, m;
  double det;
  double mu, sigma2, muError, sigma2Error, ratio, val;

  /* caution: use indices 1,...,n and ignore index 0 */
  double Amatrix[MAX_TIME_POINT+1][3]; /* matrix of values */
  double Bmatrix[3][3]; /* = Amatrix^t * Amatrix */
  double Binverse[3][3]; /* inverse of Bmatrix */
  double bvector[MAX_TIME_POINT+1]; /* vector of attribute values */
  double bbar[3]; /* = Amatrix^t * bvector */
  double updatedbbar[3]; /* = Binverse * bbar */
                         /* = estimated function coefficients */

  /* define Amatrix and bvector */
  for (i=1; i<=numUsedTimePoints; i++) {
    Amatrix[i][1] = 1.0;
    Amatrix[i][2] = usedTimePoint[i];
    bvector[i] = attributeValue[i];
  }

  /* define bbar */
  for (i=1; i<=2; i++) {
    bbar[i] = 0.0;
    for (j=1; j<=numUsedTimePoints; j++) {
      bbar[i] += Amatrix[j][i] * bvector[j];
    }
  } 

  /* define Bmatrix = Amatrix^t * Amatrix */
  for (i=1; i<=2; i++) {
    for (j=1; j<=2; j++) {
      Bmatrix[i][j] = 0.0;
      for (m=1; m<=numUsedTimePoints; m++) {
        Bmatrix[i][j] += Amatrix[m][i] * Amatrix[m][j];
      }
    }
  }

  /* define Binverse */
  det = Bmatrix[1][1]*Bmatrix[2][2] -
        Bmatrix[1][2]*Bmatrix[2][1];
  Binverse[1][1] =  Bmatrix[2][2]/det;
  Binverse[1][2] = -Bmatrix[2][1]/det;
  Binverse[2][1] = -Bmatrix[1][2]/det;
  Binverse[2][2] =  Bmatrix[1][1]/det;

  /* define updatedbbar */
  for (i=1; i<=2; i++) {
    updatedbbar[i] = 0.0;
    for (j=1; j<=2; j++) {
      updatedbbar[i] += Binverse[i][j] * bbar[j];
    }
  }

  /* define constant, slope, and curve */
  function.constant = updatedbbar[1];
  function.slope = updatedbbar[2];
  function.curve = 0.0;

  /* if slope is nonzero, estimate quality of function */
  if (fabs(function.slope) != 0) {

    /* estimate mean and variance of attribute values */
    /* mu = (1/n)sum xj */
    /* sigma2 = [(1/n)sum(xj^2)] - mu^2 */
    mu = 0.0;
    sigma2 = 0.0;
    for (i=1; i<=numUsedTimePoints; i++) {
      mu +=attributeValue[i];
      sigma2 += attributeValue[i] * attributeValue[i];
    }
    mu /= (double)numUsedTimePoints;
    sigma2 = (sigma2/(double)numUsedTimePoints) - mu * mu;

    /* estimate mean and variance of errors */
    muError = 0.0;
    sigma2Error = 0.0;
    for (i=1; i<=numUsedTimePoints; i++) {
      val = function.constant + 
            function.slope * usedTimePoint[i] -
            attributeValue[i];
      muError +=val;
      sigma2Error += val * val;
    }
    muError /= (double)numUsedTimePoints;
    sigma2Error = (sigma2Error/(double)numUsedTimePoints) - 
             muError * muError;

    /* estimate ratio of variances */
    ratio = sigma2Error/sigma2;
    /* if ratio >= REGRESSION_ERROR_THRESHOLD, */
    /*   reject regression and use mean mu */
    if (ratio >= REGRESSION_ERROR_THRESHOLD) {
      function.constant = mu;
      function.slope = 0.0;
    }        
  } /* end if fabs(function.slope) != 0 */

  return;

}
/*eject*/
/*********************************************************
 *  getNonlinearFunction
 * 
 *  purpose:  get constant, slope, and curve of nonlinear function
 *            by regression
 *            
 *********************************************************/
void getNonlinearFunction() {

  int i, j, k, m;
/* OBSOLETE code below, deleted Sept 3, 2010 */
//  double mu, sigma2, muError, sigma2Error, ratio, val;
  double pivot, prod;

  /* caution: use indices 1,...,n and ignore index 0 */
  double Amatrix[MAX_TIME_POINT+1][4]; /* matrix of values */
  double Bmatrix[4][4]; /* = Amatrix^t * Amatrix */
  double Binverse[4][4]; /* inverse of Bmatrix */
  double bvector[MAX_TIME_POINT+1]; /* vector of attribute values */
  double bbar[4]; /* = Amatrix^t * bvector */
  double updatedbbar[4]; /* = Binverse * bbar */
                         /* = estimated function coefficients */

  /* define Amatrix and bvector */
  for (i=1; i<=numUsedTimePoints; i++) {
    Amatrix[i][1] = 1.0;
    Amatrix[i][2] = usedTimePoint[i];
    Amatrix[i][3] = curveterm(usedTimePoint[i]);
    bvector[i] = attributeValue[i];
  }

  /* define bbar */
  for (i=1; i<=3; i++) {
    bbar[i] = 0.0;
    for (j=1; j<=numUsedTimePoints; j++) {
      bbar[i] += Amatrix[j][i] * bvector[j];
    }
  } 

  /* define Bmatrix = Amatrix^t * Amatrix */
  for (i=1; i<=3; i++) {
    for (j=1; j<=3; j++) {
      Bmatrix[i][j] = 0.0;
      for (m=1; m<=numUsedTimePoints; m++) {
        Bmatrix[i][j] += Amatrix[m][i] * Amatrix[m][j];
      }
    }
  }

  /* increase diagonal in rows i >= 2 for ridge regression */
  /* this reduces coefficients for slope and curve according */
  /* ridge regression theory and assures that they have */
  /* correct values */
  for (i=2; i<=3; i++) {
    Bmatrix[i][i] *= 1.05;
  }

  /* compute Binverse using in-place method */

  /* initialize Binverse */
  for (i=1; i<=3; i++) {
    for (j=1; j<=3; j++) {
      Binverse[i][j] = Bmatrix[i][j];      
    }
  }

  /* compute inverse in place */  
  for (k=1;k<=3;k++) {
    pivot = Binverse[k][k];
    if ( fabs(pivot) < 1.0e-10) {
      fprintf(stderr,"Error: pivot element too small\n");
      exit(1);
    }
    if (pivot == 0) {
      fprintf(stderr,"Error: pivot element = 0\n");
      exit(1);
    }
    if (pivot > 1.e200) {
      fprintf(stderr,"Error: pivot element too large\n");
      exit(1);
    }
    Binverse[k][k] = 1;
    for (j=1;j<=3;j++) {
      Binverse[k][j] = Binverse[k][j]/pivot;
    }
    for (i=1;i<=3;i++) {
      if (i != k) {
        pivot = Binverse[i][k];
        Binverse[i][k] = 0;
        for (j=1;j<=3;j++) {
          Binverse[i][j] = Binverse[i][j] - pivot*Binverse[k][j];
        }
      }
    }
  }

  /* check validity of inversion */
  for (i=1; i<=3; i++) {
    for (j=1; j<=3; j++) {
      prod = 0.0;
      for (k=1; k<=3; k++) {
        prod += Bmatrix[i][k] * Binverse[k][j];
      }
      if (i == j) {
        if (prod > 1.0+EPSILON || prod <1.0-EPSILON) {
          fprintf(stderr,"Error: inversion routine has failed\n");
           exit(1);
        }
      } else {
        if (fabs(prod)  > EPSILON) {
          fprintf(stderr,"Error: inversion routine has failed\n");
          exit(1);
        }
      } /* end if i == j, else */
    } /* end for j */
  } /* end for i */

  /* define updatedbbar */
  for (i=1; i<=3; i++) {
    updatedbbar[i] = 0.0;
    for (j=1; j<=3; j++) {
      updatedbbar[i] += Binverse[i][j] * bbar[j];
    }
  }

  /* define constant, slope, and curve */
  function.constant = updatedbbar[1];
  function.slope = updatedbbar[2];
  function.curve =  updatedbbar[3];

/* OBSOLETE code below, deleted Sept 3, 2010 */
  /* estimate quality of function */

  /* estimate mean and variance of attribute values */
  /* mu = (1/n)sum xj */
  /* sigma2 = [(1/n)sum(xj^2)] - mu^2 */
//  mu = 0.0;
//  sigma2 = 0.0;
//  for (i=1; i<=numUsedTimePoints; i++) {
//    mu +=attributeValue[i];
//    sigma2 += attributeValue[i] * attributeValue[i];
//  }
//  mu /= (double)numUsedTimePoints;
//  sigma2 = (sigma2/(double)numUsedTimePoints) - mu * mu;

  /* estimate mean and variance of errors */
//  muError = 0.0;
//  sigma2Error = 0.0;
//  for (i=1; i<=numUsedTimePoints; i++) {
//    val = function.constant + 
//          function.slope * usedTimePoint[i] +
//          function.curve * curveterm(usedTimePoint[i]) -
//          attributeValue[i];
//    muError +=val;
//    sigma2Error += val * val;
//  }
//  muError /= (double)numUsedTimePoints;
//  sigma2Error = (sigma2Error/(double)numUsedTimePoints) - 
//           muError * muError;

  /* estimate ratio of variances */
//  ratio = sigma2Error/sigma2;
  /* if ratio >= REGRESSION_ERROR_THRESHOLD, */
  /*   reject regression and use mean mu */
//  if (ratio >= REGRESSION_ERROR_THRESHOLD) {
//    function.constant = mu;
//    function.slope = 0.0;
//    function.curve = 0.0;
//  }

  return;

}
/*eject*/
/*********************************************************
 *  getValueSlope
 * 
 *  purpose:  get function.beginvalue
 *                function.midvalue
 *                function.endvalue
 *                function.beginslope
 *                function.endslope
 *            
 *********************************************************/
void getValueSlope() {

  double begt, midt, endt;

  begt = timePoint[1];
  endt = timePoint[numTimePoints];
  midt = (begt + endt)/2.0;

  function.beginvalue = approxfunction(function.constant,
                                       function.slope,
                                       function.curve,
                                       begt);
  function.midvalue =   approxfunction(function.constant,
                                       function.slope,
                                       function.curve,
                                       midt);
  function.endvalue =   approxfunction(function.constant,
                                       function.slope,
                                       function.curve,
                                       endt);
  function.beginslope = (function.midvalue - 
                         function.beginvalue)/(midt - begt);
  function.endslope   = (function.endvalue - 
                         function.midvalue)/(endt - midt);
}
/*eject*/
/*********************************************************
 *  lineread2outputline
 * 
 *  purpose:  convert lineread to outputline
 *            
 *********************************************************/

void lineread2outputline() {

  int counter, i, j, nz, startindex;
  int subTok;

  char token[MAXLEN] = {'\0'}; 

  /* strip off carriage return/whitespace at the end of line */
  nz = strlen(lineread);
  i = nz - 1;
  while (lineread[i]>=1 && lineread[i]<=32) {
    lineread[i] = '\0';
    i--;
  }

  //printf("%s\n\n", lineread);
    
  /* Shift the line left (remove whitespace at beginning) */
  shiftLeft(lineread);
    
  /* Remove commented lines and blank lines */
  if (strncmp(lineread, "*", 1) == 0) {
    return;		
  } else if (strncmp(lineread, "\n", 1) == 0) { 
    return;
  } else {
    startindex = 0;
    i = 0;
    counter = 0;
    strcpy(outputline, "");  //clear the outputline

    /* must parse character by character in case of empty fields */
    while (lineread[i] != '\n' && lineread[i] !='\0') {
      if (lineread[i] == delimiter) {
        if (i==startindex) {
          /* old code: interpret blank excel field as "?" */
          /* strcat(outputline, "?\t"); */
          /* startindex = i+1; */
          /* alternate code: terminate if excel field is blank */
          fprintf(stderr,"Line\n%s\nof .csv input file indicates blank field of excel file",lineread);
          exit(1);
        } else {
          subStr(token, lineread, startindex, i-startindex);

          //now search for substitutions
          subTok = 0;
          for (j=0; j<numglobalSubs; j++) {
            if (strcmp(globalSub[j].oldToken, token) == 0) {
              strcat(outputline, globalSub[j].newToken);
              strcat(outputline, "\t");
              startindex = i+1;
              subTok = 1;
            }
          }
          if (subTok == 0) {
            for (j=0; j<numLocalSubs; j++) {
              if (counter == subAttributeIndex[j]) {
                if (strcmp(localSub[j].oldToken, token) == 0) {
                  strcat(outputline, localSub[j].newToken);
                  strcat(outputline, "\t");
                  startindex = i+1;
                  subTok = 1;
                }
              }
            }
          }

          //if no substitutions, output token to line
          if (subTok == 0) {
            strcat(outputline,token);
            strcat(outputline,"\t");
            startindex = i+1;
          }
        }  // end else
        counter++;
      } //end if (linerad[i] == ',')
      i++;
    }

    /* grab the last token on the line */
    if (startindex == i) {
      /* old code: interpret blank excel field as "?" */
      /* strcat(outputline, "?"); */
      /* alternate code: terminate if excel field is blank */
      fprintf(stderr,"Line\n%s\nof .csv input file indicates blank field of excel file",lineread);
      exit(1);
    } else {
      subStr(token, lineread, startindex, i-startindex);
	
      //now check for substitutions
      subTok = 0;
      for (j=0; j<numglobalSubs; j++) {
        if (strcmp(globalSub[j].oldToken, token) == 0) {
          strcat(outputline, globalSub[j].newToken);
          subTok = 1;
        }
      }
      if (subTok == 0) {
        for (j=0; j<numLocalSubs; j++) {
          if (counter == subAttributeIndex[j]) {
            if (strcmp(localSub[j].oldToken, token) == 0) {
              strcat(outputline, localSub[j].newToken);
              subTok = 1;
            }
          }
        }
      }

      //if no substitutions, output token to line
      if (subTok == 0) {
        strcat(outputline, token);
      }
    } //end else for last token

  }

 return;

}
/*eject*/
/*********************************************************
 *  openFiles
 * 
 *  purpose:  opens global input and output files
 *            
 *********************************************************/
void openFiles(char *csv_filename, 
               char *sub_filename,
               char *stat_filename,
               char *mst_filename)
{
  if ((csvfile = fopen(csv_filename, "r")) == NULL) {
    fprintf(stderr, "Cannot open csv_filename = %s\n", csv_file);
    exit(1);
  }

  if ((subfile = fopen(sub_filename, "r")) == NULL){
    fprintf(stderr, "Cannot open sub_filename = %s\n", sub_file);
    exit(1);
  }

  if ((statfile = fopen(stat_filename, "r")) == NULL){
    fprintf(stderr, "Cannot open stat_filename = %s\n", stat_file);
    exit(1);
  }

  if ((mstfile = fopen(mst_filename, "w")) == NULL) {
    fprintf(stderr, "Cannot open mst_filename = %s\n", mst_file);
    exit(1);
  }

}
/*eject*/
/*********************************************************
 *  outputline2outputtoken
 * 
 *  purpose:  convert outputline to outputtoken
 *            
 *********************************************************/
void outputline2outputtoken() {

  int i, nz;

  char *buffer;
  char saveout[MAXLEN] = {'\0'};


  /* save outputline for possibility of error message */
  strcpy(saveout,outputline);

  buffer = strtok(outputline," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,"Error: empty outputline\n");
    exit(1);
  }
  i = 1;
  strcpy(outputtoken[i],buffer);
  i++;
  nz = numBeginAttributes + 
       numTotalTimeAttributes + 
       numEndAttributes;
  while (i <= nz) {
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL) {
      fprintf(stderr,
        "Error: not enough attribute values in outputline\n");
      fprintf(stderr,
        "       or counts of .stat file are in error.\nLine:\n%s\n",
        saveout);
      exit(1);
    }
    strcpy(outputtoken[i],buffer);
    i++;
  } /* end while i <= nz */
  /* check that entire outputline has been used */
  buffer = strtok(NULL," \t\n");
  if (buffer != NULL) {
    fprintf(stderr,
       "Error: outputline has too many values\n");
    fprintf(stderr,
       "       or counts of .stat file are in error.\nLine:\n%s\n",
       saveout);
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  parseSubstitution
 * 
 *  purpose:  parse substitution file
 *            
 *********************************************************/
void parseSubstitution() {

  int i, index, nz;
  char *buffer;

  while (fgets(lineread, MAXLEN, subfile) != NULL) {
    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return/whitespace at the end of line */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    buffer = strtok(lineread, ",\n");
    if (buffer) {
      if (strcmp(buffer,"<all>") == 0) {
      //add to global substitutions
        buffer = strtok(NULL, ",\n");
        strcpy(globalSub[numglobalSubs].oldToken, buffer);
        buffer = strtok(NULL, ",\n");
        strcpy(globalSub[numglobalSubs].newToken, buffer);
        numglobalSubs++;	
      } else {
        //add to local substitutions
        index = getIndex(buffer);
        subAttributeIndex[numLocalSubs] = index;
        buffer = strtok(NULL, ",\n");
        strcpy(localSub[numLocalSubs].oldToken, buffer);
        buffer = strtok(NULL, ",\n");
        strcpy(localSub[numLocalSubs].newToken, buffer);
        numLocalSubs++;	  
      }
    }
  }

  printf("Global Substitutions:\n");
  for (i=0; i<numglobalSubs; i++) {
    printf("%s    %s\n" , globalSub[i].oldToken, 
                          globalSub[i].newToken);
  }
  printf("Local Substitutions:\n");
  for (i=0; i<numLocalSubs; i++) {
    printf("%d    %s    %s\n", subAttributeIndex[i], 
                               localSub[i].oldToken, 
                               localSub[i].newToken);
  }

  return;

}
/*eject*/
/*********************************************************
 *  readStats
 * 
 *  purpose:  read statistics of .stat file
 *            
 *********************************************************/
void readStats() {

  char *buffer;

  /* read statistics of .stat file */
  while (fgets(lineread, MAXLEN, statfile) != NULL) { /* while #1 */
    buffer = strtok(lineread," \t\n=");
    if (buffer == NULL) {
      fprintf(stderr,
              "Error: Unexpected empty record in stat_file %s\n",
              stat_file);
      exit(1);
    }

    if (strcmp(buffer,"number_of_begin_attributes") == 0) {
      if (strcmp(control,"STATISTICS") != 0) {
        fprintf(stderr,
        "records of .stat file %s out of order, case 1\n",stat_file);
        exit(1);     
      }
      /* read  number of begin attributes*/
      strcpy(control,"number_of_begin_attributes");
      buffer = strtok(NULL," \t\n=");
      if (buffer == NULL) {
        fprintf(stderr,
  "Error: undefined number of begin attributes in .stat file %s\n",
        stat_file);
        exit(1);
      }
      numBeginAttributes = atoi(buffer);
    } else if (strcmp(buffer,"number_of_end_attributes") == 0) {
      if (strcmp(control,"number_of_begin_attributes") != 0) {
        fprintf(stderr,
        "records of .stat file %s out of order, case 2\n",stat_file);
        exit(1);     
      }
      /* read  number of end attributes*/
      strcpy(control,"number_of_end_attributes");
      buffer = strtok(NULL," \t\n=");
      if (buffer == NULL) {
        fprintf(stderr,
  "Error: undefined number of end attributes in .stat file %s\n",
        stat_file);
        exit(1);
      }
      numEndAttributes = atoi(buffer);
    } else if (strcmp(buffer,"time_points") == 0) {
      if (strcmp(control,"number_of_end_attributes") != 0) {
        fprintf(stderr,
        "records of .stat file %s out of order, case 3\n",stat_file);
        exit(1);     
      }
      /* read time points */
      strcpy(control,"time_points");
      numTimePoints = 0;
      buffer = strtok(NULL," \t\n=");
      while (buffer != NULL) { /* while #2 */
        numTimePoints++;
        timePoint[numTimePoints] = atof(buffer);
        buffer = strtok(NULL," \t\n="); 
      } /* end while #2 */
      if (numTimePoints <= 1) {
        fprintf(stderr,
                "Error: numTimePoints >= 2 is required, but\n");
        fprintf(stderr,
                "have only %d points specified in .stat file\n",
                numTimePoints);
        exit(1);
      }  
    } else if (strcmp(buffer,
               "number_attributes_for_each_time_point") == 0) {
      if (strcmp(control,"time_points") != 0) {
        fprintf(stderr,
        "records of .stat file %s out of order, case 4\n",stat_file);
        exit(1);     
      }
      /* read  number of attributes for each time point */
      strcpy(control,"number_attributes_for_each_time_point");
      buffer = strtok(NULL," \t\n=");
      if (buffer == NULL) {
        fprintf(stderr,
                "Error: undefined number of attributes for ");
       fprintf(stderr,"each time point in ,stat file %s\n",
                stat_file);
        exit(1);
      }
      numTimeAttributes = atoi(buffer);
      continue; 
    } else {
      fprintf(stderr,"Unknown option record in .stat_file %s\n",
                      stat_file);
      exit(1);
    } /* end if strcmp(buffer,"time_points"), else */

  } /* end while #1 */

  if (strcmp(control,
             "number_attributes_for_each_time_point") != 0) {
    fprintf(stderr,
    "records of .stat file %s out of order, case 5\n",stat_file);
    exit(1);
  }

  numTotalTimeAttributes = numTimeAttributes * numTimePoints;

  return;

}
/*eject*/
/*********************************************************
*	Shift the line left
*   Ascii 32 = space, 9 = tab
**********************************************************/
void shiftLeft(char fileRec[])
{
  while(fileRec[0] == 32 || fileRec[0] == 9) {
    strcpy(fileRec, fileRec+1);
  }
}
/*eject*/
/*********************************************************
 *  subStr
 * 
 *  purpose:  copies substring into another string
 *            
 *********************************************************/
void subStr(char dest[], char src[], int offset, int len)
{
  int i;
  for(i = 0; i < len && src[offset + i] != '\0'; i++)
    dest[i] = src[i + offset];
  dest[i] = '\0';
}
/*eject*/
/*********************************************************
 *  writeLine
 * 
 *  purpose:  output line of text to specified file
 *            
 *********************************************************/
void writeLine(FILE *outputFile, char line[])
{
  fprintf(outputFile, "%s\n", line);
}
/**********last record of csv2master.c******************/
