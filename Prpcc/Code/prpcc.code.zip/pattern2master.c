#include "prpcc.h"

/* Global Input and Output files */
FILE *inputptnfile;
FILE *outputmstfile;

/* function prototypes */
void openfiles(char *inputptn_filename, char *outputmst_filename);
int stringCompare(const char *a, const char *b, int n);

/* main function */
int main(int argc, char *argv[])
{
  char inputptn_filename[MAX_ID];
  char outputmst_filename[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  char pattern[MAX_RECORD][MAXLEN];
  char charA[10], charB[10];

  int i, j;
  int recordType = 0;
  int nRecord = 0;

  if (argc != 5) {
    fprintf(stderr,
    "Calling Sequence: pattern2master input.ptn output.mst charA charB\n");
    exit(1);
  }
  strcpy(inputptn_filename, argv[1]);
  strcpy(outputmst_filename, argv[2]);
  if (strlen(argv[3]) >= 2) {
    fprintf(stderr,"charA can have only one character\n");
    exit(1);
  }
  if (strlen(argv[4]) >= 2) {
    fprintf(stderr,"charB can have only one character\n");
    exit(1);
  }
  strcpy(charA,argv[3]);
  strcpy(charB,argv[4]);

  /* input specification for testing */
  /* strcpy(inputptn_filename, "embeddedtriangle.ptn");
  strcpy(outputmst_filename,"embeddedtriangle.ats" );
  strcpy(charA,"A");
  strcpy(charB,"B"); */
  

  openfiles(inputptn_filename,outputmst_filename);

  while (fgets(lineread, MAXLEN, inputptnfile) != NULL) { /* while */
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0') ||
        (lineread[0] == '*')) {
      continue;
    }

    if (recordType == 0) {
      if (stringCompare(lineread,"DATA",4) == 0) {
        fprintf(outputmstfile,"ATTRIBUTES\n");
        fprintf(outputmstfile,"class TARGET DELETE\n");
        fprintf(outputmstfile,"x\n");
        fprintf(outputmstfile,"y\n");
        fprintf(outputmstfile,"DATA\n");
        recordType = DATA;
        continue;
      }
      fprintf(stderr,
              "Missing DATA record or records out of order\n");
      exit(1);        
    }

    if (strncmp(lineread,"ENDATA",6) == 0) {
      if (recordType != DATA) {
        fprintf(stderr,"Missing pattern records or out of order\n");
        exit(1);
      }
      recordType = ENDATA;
      break;
    }

    if (recordType == DATA) {
      nRecord++;
      strcpy(pattern[nRecord],lineread);
    }

  } /* end while */
  if (recordType != ENDATA) {
    fprintf(stderr,"Missing ENDATA record in input file\n");
    exit(1);
  }

  for (j=nRecord; j>=1; j--) { /* begin for j */
    strcpy(lineread,pattern[j]);  
    for (i=1; i<=strlen(lineread); i++) { /*begin for i */
      if ((lineread[i-1] == ' ') ||
          (lineread[i-1] == '\n')) {
        break;
      }
      if (lineread[i-1] == charA[0]) {
        fprintf(outputmstfile,"%d\t%d\t%d\n",A,i,nRecord-j+1);
      } else if (lineread[i-1] == charB[0]) {
        fprintf(outputmstfile,"%d\t%d\t%d\n",B,i,nRecord-j+1);
      }
    } /* end for i */
  } /* end for j */

  fprintf(outputmstfile,"ENDATA\n");
  recordType = ENDATA;

  fclose(inputptnfile);
  fclose(outputmstfile);

  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *inputptn_filename, char *outputmst_filename)
{
  if ((inputptnfile = fopen(inputptn_filename, "r")) == NULL) {
    fprintf(stderr, 
    "pattern2master: Cannot open %s\n", "inputptn_filename");
    exit(1); 
  }   

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "pattern2master: Cannot open %s\n", "ouputmst_filename");
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}

/* last record of pattern2master.c****/
