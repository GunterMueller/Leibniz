#include "prpcc.h"

/* Global Input and Output files */
FILE *inputptnfile;
FILE *outputmstfile;

/* function prototypes */
void openfiles(char *inputptn_filename, char *outputmst_filename);
int stringCompare(const char *a, const char *b, int n);

/* main function */
int main(int argc, char *argv[])
{
  char inputptn_filename[MAX_ID];
  char outputmst_filename[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  char pattern[MAX_RECORD][MAXLEN];
  char charA, charB;

  int i, j;
  int recordType = 0;
  int nRecord = 0;

  if (argc != 3) {
    fprintf(stderr,
    "Calling Sequence:  pattern2master input.ptn output.mst\n");
    exit(1);
  }
  strcpy(inputptn_filename, argv[1]);
  strcpy(outputmst_filename, argv[2]);

  openfiles(inputptn_filename,outputmst_filename);

  while (fgets(lineread, MAXLEN, inputptnfile) != NULL) { /* while */
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0') ||
        (lineread[0] == '*')) {
      continue;
    }

    if (recordType == 0) {
      if (stringCompare(lineread,"PATTERNS",8) == 0) {
        fprintf(outputmstfile,"ATTRIBUTES\n");
        fprintf(outputmstfile,"class TARGET DELETE\n");
        fprintf(outputmstfile,"x\n");
        fprintf(outputmstfile,"y\n");
        fprintf(outputmstfile,"DATA\n");
        recordType = A;
        continue;
      }
    }

    if (recordType == A) {
      if (strncmp(lineread,"A=",2) != 0) {
        fprintf(stderr,"Missing 'A=' record or out of order\n");
        exit(1);
      }
      charA = lineread[2];
      recordType = B;
      continue;
    }

    if (recordType == B) {
      if (strncmp(lineread,"B=",2) != 0) {
        fprintf(stderr,"Missing 'B=' record or out of order\n");
        exit(1);
      }
      charB = lineread[2];
      recordType = DATA;
      continue;
    }

    if (recordType == DATA) {
      if (strncmp(lineread,"DATA",4) != 0) {
        fprintf(stderr,"Missing 'DATA' record or out of order\n");
        exit(1);
      }
      recordType = RECORD;
      continue;
    }

    if (strncmp(lineread,"ENDATA",6) == 0) {
      if (recordType != RECORD) {
        fprintf(stderr,"Missing pattern records or out of order\n");
        exit(1);
      }
      recordType = ENDATA;
      break;
    }

    if (recordType == RECORD) {
      nRecord++;
      strcpy(pattern[nRecord],lineread);
    }

  } /* end while */
  if (recordType != ENDATA) {
    fprintf(stderr,"Missing ENDATA record in input file\n");
    exit(1);
  }

  for (j=nRecord; j>=1; j--) { /* begin for j */
    strcpy(lineread,pattern[j]);  
    for (i=1; i<=strlen(lineread); i++) { /*begin for i */
      if ((lineread[i-1] == ' ') ||
          (lineread[i-1] == '\n')) {
        break;
      }
      if (lineread[i-1] == charA) {
        fprintf(outputmstfile,"%d\t%d\t%d\n",A,i,nRecord-j+1);
      } else if (lineread[i-1] == charB) {
        fprintf(outputmstfile,"%d\t%d\t%d\n",B,i,nRecord-j+1);
      } else {
        fprintf(stderr,"Wrong pattern symbol\npattern = %s\n",
                        lineread);
        exit(1);
      }
    } /* end for i */
  } /* end for j */

  fprintf(outputmstfile,"ENDATA\n");
  recordType = ENDATA;

  fclose(inputptnfile);
  fclose(outputmstfile);

  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *inputptn_filename, char *outputmst_filename)
{
  if ((inputptnfile = fopen(inputptn_filename, "r")) == NULL) {
    fprintf(stderr, 
    "pattern2master: Cannot open %s\n", "inputptn_filename");
    exit(1); 
  }   

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "pattern2master: Cannot open %s\n", "ouputmst_filename");
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}

/* last record of pattern2master.c****/
