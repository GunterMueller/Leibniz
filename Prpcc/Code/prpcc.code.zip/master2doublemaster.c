#include "prpcc.h"

/* Global Input and Output files */
FILE *inputmstfile;
FILE *outputmstfile;

/* function prototypes */
void openfiles(char *inputmst_filename, char *outputmst_filename);
int stringCompare(const char *a, const char *b, int n);
void writeline(FILE *output_trn, char line[]);

/* main function */
int main(int argc, char *argv[])
{
  char inputmst_filename[MAX_ID];
  char outputmst_filename[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  int recordType = 0;

  if (argc != 3) {
    fprintf(stderr,
    "Calling Sequence:  master2doublemaster input.mst output.mst\n");
    exit(1);
  }
  strcpy(inputmst_filename, argv[1]);
  strcpy(outputmst_filename, argv[2]);

  openfiles(inputmst_filename,outputmst_filename);

  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) {
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0')) {
      continue;
    }
    writeline(outputmstfile,lineread);
    if (stringCompare(lineread,"ENDATA",6) == 0) {
      if (recordType != DATA) {
        fprintf(stderr,"Missing DATA record in input file\n");
        exit(1);
      } else {
        recordType = ENDATA;
        break;
      }
    }
    if (stringCompare(lineread,"DATA",4) == 0) {
      recordType = DATA;
      continue;
    }
    if (recordType == DATA) {
      writeline(outputmstfile,lineread);
    }
  }

  if (recordType != ENDATA) {
    fprintf(stderr,"Missing ENDATA record in input file\n");
    exit(1);
  }

  fclose(inputmstfile);
  fclose(outputmstfile);

  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *inputmst_filename, char *outputmst_filename)
{
  if ((inputmstfile = fopen(inputmst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "master2doublemaster: Cannot open %s\n", "inputmst_filename");
    exit(1); 
  }   

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2doublemaster: Cannot open %s\n", "ouputmst_filename");
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  writeline
 * 
 *  purpose:  prints line of text to a file
 *            
 *********************************************************/
void writeline(FILE *output_trn, char line[])
{
  fprintf(output_trn, "%s", line);
}
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}

/* last record of master2doublemaster.c****/
