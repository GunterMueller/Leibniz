#include "prpcc.h"

/* CAUTION: This program is used by subcc and sub2cc and therefore */
/*          must NOT be changed */

 /* Global Input and Output files */
FILE *mstfile;
FILE *msplAfile;
FILE *msplBfile;
FILE *attributefile;

/* attribute data */
struct {
  char name[MAX_ID];
  char record[MAX_ID];
  char class[MAX_CLASS+1][MAX_ID];
  int numClasses;
} typedef AttributeData;
AttributeData attribute[MAX_ATTRIBUTE+1];
int numAttributes; /* total number of attributes */

/* target data */
char target[MAX_ID];   /* target name */
int indexTarget;       /* index of target attribute  */
int numIntervals;         /* number of target intervals */
float low[MAX_INTERVAL];  /* low values of intervals    */
float high[MAX_INTERVAL]; /* high values of intervals   */


/* function prototypes */
void openfiles(char *mst_filename, 
               char *split_Afilename, 
               char *split_Bfilename, 
               char *a_file);
void writeline(FILE *output_trn, char line[]);
int splitABrecords(char fileRec[]);
/*eject*/
/* main function */
int main(int argc, char *argv[])
{
  char *buffer;
  char mst_file[MAX_ID];
  char mspl_Afile[MAX_ID];
  char mspl_Bfile[MAX_ID];
  char att_file[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  int line;
  int endDataFlag = 0;
  int flag, i, j, k, nz, set;
  int rec_count = 0;
  int recordType = 0;  /* value = 0 suppresses compiler warning */

  if (argc != 9 && argc != 11) {
    fprintf(stderr,
      "Calling Sequence:  master2masterABTarget master.mst attributes.mspl setA.mspl setB.mspl target numIntervals low[i] high[i], i = 1,... numIntervals\n");
    exit(1);
  }
  strcpy(mst_file, argv[1]);
  strcpy(att_file, argv[2]);
  strcpy(mspl_Afile, argv[3]);
  strcpy(mspl_Bfile, argv[4]);
  strcpy(target, argv[5]);
  numIntervals = atoi(argv[6]);

  j = 6;
  for (i=1;i<=numIntervals;i++) {
    j++;
    low[i] = atof(argv[j]);
    j++;
    high[i] = atof(argv[j]);
    if (low[i] > high[i]) {
      fprintf(stderr,
      "master2masterABTarget: error, low[%d]=%f > high[%d]=%f\n",
      i,low[i],i,high[i]);
      exit(1); 
    }
    if (i > 1 && low[i] < high[i-1]) {
      fprintf(stderr,
      "master2masterABTarget: error, low[%d]=%f < high[%d]=%f\n",
	      i,low[i],i-1,high[i-1]);
      exit(1);
    }
  }


 /*DEBUG*/
  /* for use, comment out above code and uncomment the code below */
 /* strcpy(mst_file, "example.1.mst");
  strcpy(att_file, "attributes.mspl");
  strcpy(mspl_Afile,"setA.mspl");
  strcpy(mspl_Bfile,"setB.mspl");
  strcpy(target, "f1");
  numIntervals = 1; 
  low[1] = 0.20;
  high[1] = 0.21; */


/*eject*/
  numAttributes = 0;
  indexTarget = 0;

  openfiles(mst_file, mspl_Afile, mspl_Bfile, att_file);

  while (fgets(lineread, MAXLEN, mstfile) != NULL) { /* while #1 */
    line++;

    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return and whitespace at end of line */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* printf("%s\n" , lineread); */ /* debugging output */
/*eject*/
    /* DATA record */
    if (strncmp(lineread, "DATA", 4) == 0) {
      recordType = DATA;
      
      /* check that target index has been found during */
      /* earlier processing of attributes */
      if (indexTarget == 0) {
        fprintf(stderr, 
          "error: unknown target in master2masterABTarget\n");
          exit(1);
      }

      /* output attributes */
      for (i=1; i<=numAttributes; i++) {

        if (i == indexTarget) {
          /* use DELETE option */
          fprintf(attributefile,"%s DELETE * selected target \n",
                  target);
        } else {
          /* check if attribute and target are in a class */
          flag = 0;
          for (j=1; j<=attribute[indexTarget].numClasses; j++) {
            for (k=1; k<=attribute[i].numClasses; k++) {
              if (strcmp(attribute[indexTarget].class[j],
                         attribute[i].class[k]) == 0) {
                flag = k;
                break;
              }
            } /* end for k */
            if (flag > 0) {
              break;
            }
          } /* end for j */
          if (flag > 0) { /* attribute and target are in a class */
            fprintf(attributefile,
                    "%s DELETE * attribute and target are in %s\n",
                    attribute[i].name,
                    attribute[i].class[k]);       
          } else { /* attribute record is not changed */
            writeline(attributefile,attribute[i].record);
          }
        } /* end if/else i == indexTarget */
 
      } /* end for i */

      /* begin processing of data into A and B sets */
      writeline(msplAfile, "BEGIN A");
      writeline(msplBfile, "BEGIN B");
/*eject*/
/* ATTRIBUTE, ENDATA, comment, empty line records */
    } else if (strncmp(lineread, "ATTRIBUTES", 10) == 0) {
      recordType = ATTRIBUTE;
      writeline(attributefile, "ATTRIBUTES");
    } else if ((strncmp(lineread, "ENDATA", 6) == 0) ||
	      (strncmp(lineread, "ENDDATA", 7) == 0)) {
      endDataFlag = TRUE;
      writeline(msplBfile, "ENDATA");
      break;    
    } else if (strncmp(lineread, "*", 1) == 0) {
      continue;		
    } else if (strncmp(lineread, "\n", 1) == 0) {
      continue;			
    } else {
/*eject*/
/* have attribute or data record */

      if (recordType == DATA) { 
        /* case 1: data record */
        /* function to determine A or B is called here */
        set = splitABrecords(lineread);
        if (set == A) {
          writeline(msplAfile, lineread);
        } else if (set == B) {
          writeline(msplBfile, lineread);
        } else if (set != SKIP) {
          /* error, must be SKIP if not A or B */
          fprintf(stderr, "error: master2masterABTarget\n");
          exit(1);
        }
        rec_count++;

      } else if (recordType == ATTRIBUTE) {
        /* case 2: attribute record */  
        numAttributes++;
        if (numAttributes > MAX_ATTRIBUTE) {
          fprintf(stderr, 
          "too many attributes in master2masterABTarget\n");
          exit(1);
        }
        /* store record */
        strcpy(attribute[numAttributes].record,lineread);
        /* store attribute name */
        buffer = strtok(lineread," \t\n");
        strcpy(attribute[numAttributes].name,buffer);
        /* check for target name */
        if (strcmp(attribute[numAttributes].name,target) == 0) {
          indexTarget = numAttributes;
        }
        /* extract CLASS options */
        attribute[numAttributes].numClasses = 0;
        buffer = strtok(NULL," \t\n");
        if (buffer != NULL) {
          while (strncmp(buffer,"CLASS",5) == 0) {
            attribute[numAttributes].numClasses++;
            strcpy(
            attribute[numAttributes].class[attribute[
                      numAttributes].numClasses],buffer);
            buffer = strtok(NULL," \t\n");
            if (buffer == NULL) {
              break;
            }
          }
        } /* end if buffer != NULL */
      } /* end if/else recordType == DATA */
    } /* end if/else strncmp(lineread, "DATA",4) == 0 */
  } /* end while #1 */

  fclose(mstfile);
  fclose(msplAfile);
  fclose(msplBfile);
  fclose(attributefile);
  
  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *mst_filename, char *split_Afilename, char *split_Bfilename, char *attribute_file)
{
  if ((mstfile = fopen(mst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "master2masterABTarget: Cannot open %s\n", "mst_filename");
    exit(1); 
  }   

  if ((msplAfile = fopen(split_Afilename, "w")) == NULL) {
    fprintf(stderr, 
    "master2masterABTarget: Cannot open %s\n", "split_Afilename");
    exit(1);
  }

  if ((msplBfile = fopen(split_Bfilename, "w")) == NULL) {
    fprintf(stderr, 
    "master2masterABTarget: Cannot open %s\n", "split_Bfilename");
    exit(1);
  }

  if ((attributefile = fopen(attribute_file, "w")) == NULL) {
    fprintf(stderr, 
    "master2masterABTarget: Cannot open %s\n", "attribute_file");
    exit(1);
  }
}
/*eject*/
/*********************************************************
 *  writeline
 * 
 *  purpose:  prints line of text to a file
 *            
 *********************************************************/
void writeline(FILE *output_trn, char line[])
{
  fprintf(output_trn, "%s\n", line);
}
/*eject*/
/*********************************************************
 *  splitABrecords
 * 
 *  purpose:  parse raw line of text and find attribute values
 *            tests for membership in A or B
 *********************************************************/
int splitABrecords(char fileRec[])
{
  /* Returns 1 = Set A, 2 = Set B, SKIP = skip record */
  /* Modify this function to determine membership */

  /* caution: values start with index = 1 */

  float valf;
  int ai = 1;  //vector index
  char *buffer;
  char copyRec[MAXLEN];
  char allValues[MAX_ATTRIBUTE+1][MAX_RECORD];

  valf = 0.0; /* to suppress compiler warning */

  strcpy(copyRec, fileRec);

  /* Parse the copyRec and get the values */
  /* for the attributes of interest */
  /* This will ensure that the original line */
  /* is not altered by strtok */
  buffer = strtok(copyRec, " \t");
  if (buffer) {
    strcpy(allValues[ai], buffer);      /* Copy first Value */
    ai++;

    while (buffer) {
      buffer = strtok(NULL, " \t");
      if (buffer) {
	strcpy(allValues[ai], buffer);  /* Copy rest of Values */
	ai++;
      }
    }
  }

  if (strcmp(allValues[indexTarget],"?") == 0) {
    return SKIP;
  }
  valf = atof(allValues[indexTarget]);

  if (numIntervals == 1) {
    if (valf < low[1]) {
      return A;
    } else if (valf > high[1]) {
      return B;
    } else {
      return SKIP;
    }
  } else if (numIntervals == 2) {
    if (valf < low[1] || valf > high[2]) {
      return A;
    } else if (valf > high[1] && valf < low[2]) {
      return B;
    } else {
      return SKIP;
    }
  }

  /* error, numIntervals must be equal 1 or 2 */
  fprintf(stderr,"master2masterABTarget: numIntervals error\n");
  exit(1);

}

/* last record of master2masterABTarget.c****/
