#include "prpcc.h"

/* Global Input and Output files */
FILE *inputdatafile;
FILE *outputregfile;
char inputdata_filename[MAX_ID];
char outputreg_filename[MAX_ID];

/* file name specification from command line */
char inputmst_filename[MAX_ID]; /* input mst file for training */
char inputats_filename[MAX_ID]; /* input ats file for testing */
char outputmstreg_filename[MAX_ID]; /* output file for input mst */
char outputatsreg_filename[MAX_ID]; /* output file for input ats */

char lineread[MAXLEN] = {'\0'};
char token[MAX_ENTRY] = {'\0'};
char outputline[MAXLEN] = {'\0'};
char outputtoken[MAX_ATTRIBUTE+1][MAX_ENTRY];
char delimiter = ',';      /* set delimiter */

/* Global Structure for Attributes */
char attribute[MAX_ATTRIBUTE+1][MAX_ENTRY];
int  numAttributes;
char regressAttribute[MAX_REGRESSION_VAR+1][MAX_ENTRY];
int  regressIndex[MAX_REGRESSION_VAR+1];
int  numRegressAttributes;
/* yvar is stored in regressAttribute[0] */
/* yvar is not counted in numRegressAttributes */

/* Global Structure for Records and their Values */
double Amatrix[MAX_RECORD+1][MAX_REGRESSION_VAR+1];
/* Amatrix[i][0] = 1.0 for all records i = 1,...,numAmatrixRows */
int    numAmatrixRows;
double bvector[MAX_RECORD+1];

/* Global Structure for Regression Results */

/* regression coefficients produced by computeRegression */
double regressCoefficient[MAX_REGRESSION_VAR+1];
/* regressCoefficient[0] = constant of regression function */

/* collection of regression coefficients for */
/* enumeration of ridge factor cases */
double regressCoeffArray[MAX_RIDGE_FACTOR+1][MAX_REGRESSION_VAR+1];
int numRidgeFactors;

/* Global Structure for Regression Parameters and Errors */
double ridgeFactor;
double meanError;
double varError;
double estimate[MAX_RECORD+1];
/* estimate[i] = estimated yvalue for record i, */ 
/*               i = 1,...,numAmatrixRows */

/* Function Prototypes */
void computeError();
void computeRegression();
void getAttributes();
void getData();
int  getLineread();
int  getIndex(char *attribute);
void getRegressIndex();
void openFiles();
void outputline2outputtoken();
void outputResults();

/*eject*/
/* CAUTION: There must be at least two time points */

/* main function */
int main(int argc, char *argv[])
{

  int i,j;

  double saveRidgeFactor;

  numRegressAttributes = 0;
  /* numRegressAttributes does not count yvar */

  if (argc < 8) {
    printf("Calling Sequence: ./master2regression input.mst input.ats output.mst.reg output.ats.reg ridgeFactor yvar xvar1 xvar2 ... xvark\n");
    exit(1);
  }
  strcpy(inputmst_filename, argv[1]);
  strcpy(inputats_filename, argv[2]);
  strcpy(outputmstreg_filename, argv[3]);
  strcpy(outputatsreg_filename, argv[4]);
  sscanf(argv[5],"%lf",&ridgeFactor);
  for (i=6; i<argc; i++) {
    strcpy(regressAttribute[i-6],argv[i]);
  }
  numRegressAttributes = argc - 7;

  if (numRegressAttributes > MAX_REGRESSION_VAR) {
    fprintf(stderr,
      "master2regression: Error: MAX_REGRESSION_VAR too small \n");
  }

  /* DEBUG: uncomment below and comment out above */
  /* strcpy(inputmst_filename, "regress.input.mst");
  strcpy(inputats_filename, "regress.input.ats");
  strcpy(outputmstreg_filename, "regress.output.mst.reg");
  strcpy(outputatsreg_filename, "regress.output.ats.reg");
  ridgeFactor = 1.05;
  strcpy(regressAttribute[0],"yvar");
  strcpy(regressAttribute[1],"xvar1");
  strcpy(regressAttribute[2],"xvar2");
  numRegressAttributes = 2; */

  /* training with input.mst file */
  strcpy(inputdata_filename,inputmst_filename);
  strcpy(outputreg_filename,outputmstreg_filename);

  /* open input and output files */
  openFiles();

  /* get attributes */
  getAttributes();

  /* get indices for regression variables */
  getRegressIndex();

  /* get data */
  getData();
  if (numAmatrixRows < numRegressAttributes+1) {
    /* training mst file does not have enough data records */
    /* with values for all regression variables */
    fprintf(stderr,
     "master2regression: Error: Not enough records in training\n");
    fprintf(stderr,
      "mst file with values for all regression variables\n");
    exit(1);
  }

  /* save input ridge factor */
  saveRidgeFactor = ridgeFactor;

  /* compute regression for range of ridge factors */
  numRidgeFactors = 30;
  if (numRidgeFactors > MAX_RIDGE_FACTOR) {
    fprintf(stderr,
    " master2regression: Error: MAX_RIDGE_FACTOR too small\n");
    exit(1);
  }
  for (i=0; i<=numRidgeFactors; i++) {
    /* define ridge factor case */
    ridgeFactor = 1.0 + ((double)i)*0.01; 
    /* compute regression */
    computeRegression();
    /* store regression coefficients */
    for (j=0; j<=numRegressAttributes; j++) {
      regressCoeffArray[i][j] = regressCoefficient[j];
    }
  }

  /* restore input ridge factor */
  ridgeFactor = saveRidgeFactor;

  /* compute regression for specified ridge factor */
  computeRegression();

  /* compute error */
  computeError();

  /* output regression results */
  outputResults();

  /* testing with input.ats file */
  strcpy(inputdata_filename,inputats_filename);
  strcpy(outputreg_filename,outputatsreg_filename);

  /* open input and output files */
  openFiles();

  /* get data */
  getData();
  if (numAmatrixRows == 0) {
    /* testing ats file does not have any data records */
    /* where values are known for all regression variables */
    fprintf(stderr,
     "master2regression: Warning: There are no records in\n");
    fprintf(stderr,
      "ats file with values known for all regression variables\n");
    exit(0);
  }

  /* compute error */
  computeError();

  /* output regression results */
  outputResults();
  
  return 0;

} /* end main */
/*eject*/
/*********************************************************
 *  computeError
 * 
 *  purpose:  compute regression errors
 *            
 *********************************************************/

void computeError() {

  int i, j;

  double error; 

  meanError = 0.0;
  varError = 0.0;

  for (i=1; i<=numAmatrixRows; i++) {
    estimate[i] = 0.0;
    for (j=0; j<=numRegressAttributes; j++) {
      estimate[i] += Amatrix[i][j] * regressCoefficient[j];
    }
    error = estimate[i] - bvector[i];
    meanError += error;
    varError  += error * error;
  }

  meanError /= numAmatrixRows;
  varError  -= meanError*meanError*(double)numAmatrixRows;
  varError  /= ((double)numAmatrixRows) - 1;

  return;

}
/*eject*/
/*********************************************************
 *  computeRegression
 * 
 *  purpose:  compute regression results
 *            
 *********************************************************/

void computeRegression() {

  int i, j, k, m;
  double pivot;

  /* caution: use indices 0, 1,...,numRegressAttributes */
  double Bmatrix[MAX_REGRESSION_VAR+1][MAX_REGRESSION_VAR+1]; 
         /* = Amatrix^t * Amatrix */
  double Binverse[MAX_REGRESSION_VAR+1][MAX_REGRESSION_VAR+1];
         /* inverse of Bmatrix */
  double bbar[MAX_REGRESSION_VAR+1]; 
         /* = Amatrix^t * bvector */
  double updatedbbar[MAX_REGRESSION_VAR+1]; 
         /* = Binverse * bbar */
         /* = estimated function coefficients */

  /* define bbar */
  for (i=0; i<=numRegressAttributes; i++) {
    bbar[i] = 0.0;
    for (j=1; j<=numAmatrixRows; j++) {
      bbar[i] += Amatrix[j][i] * bvector[j];
    }
  } 

  /* define Bmatrix = Amatrix^t * Amatrix */
  for (i=0; i<=numRegressAttributes; i++) {
    for (j=0; j<=numRegressAttributes; j++) {
      Bmatrix[i][j] = 0.0;
      for (m=1; m<=numAmatrixRows; m++) {
        Bmatrix[i][j] += Amatrix[m][i] * Amatrix[m][j];
      }
    }
  }
/*eject*/


  /* compute Binverse using in-place method */

  /* initialize Binverse */
  for (i=0; i<=numRegressAttributes; i++) {
    for (j=0; j<=numRegressAttributes; j++) {
      Binverse[i][j] = Bmatrix[i][j];      
    }
  }

  /* compute inverse in place */  
  for (k=0;k<=numRegressAttributes;k++) {
    if (k == 1) {
      /* after first pivot, each new entry Binverse'[i][i], i >= 2,
       * has become, in terms of the original matrix entries,
       * =  Binverse[i][i] - 
       *      (Binverse[i][1]*Binverse[1][i]/Binverse[1][1])
       * =  sum of squared x_i values - 
       *      n * (estimated mean for xvari)^2
       * =  n * estimated variance for xvari
       * we increase the Binverse'[i][i] for ridge regression
       * by ridgeFactor > 1 
       * this reduces coefficients for xvar1, xvar2,... according to
       * ridge regression theory and assures that the coefficients
       * have correct values 
       */
      for (i=1; i<=numRegressAttributes; i++) {
        Binverse[i][i] *= ridgeFactor;
      }
    }
    pivot = Binverse[k][k];

    /* if pivot element is too small: normally would stop as
     * described in the commented-out code. But here a very
     * small pivot element indicates that Amatrix has dependent
     * columns. As remedy, simply increase the pivot element
     * as done in the replacement code below.
     */
    /* general code for small pivot element, deleted */
    /* if ( fabs(pivot) < 1.0e-10) {
      fprintf(stderr,
      "master2regression: Error: pivot element too small\n");
      exit(1);
    }
    if (pivot == 0) {
      fprintf(stderr,
      "master2regression: Error: pivot element = 0\n");
      exit(1);
    } */
    /* begin replacement code for small pivot element */
    if ( fabs(pivot) < 1.0e-10) {
      Binverse[k][k] = 1;
      pivot = Binverse[k][k];
    }
    /* end replacement code for small pivot element */
    if (fabs(pivot) > 1.e200) {
      fprintf(stderr,
      "master2regression: Error: pivot element too large\n");
      exit(1);
    }
    Binverse[k][k] = 1;
    for (j=0;j<=numRegressAttributes;j++) {
      Binverse[k][j] = Binverse[k][j]/pivot;
    }
    for (i=0;i<=numRegressAttributes;i++) {
      if (i != k) {
        pivot = Binverse[i][k];
        Binverse[i][k] = 0;
        for (j=0;j<=numRegressAttributes;j++) {
          Binverse[i][j] = Binverse[i][j] - pivot*Binverse[k][j];
        }
      }
    }
  }

  /* define updatedbbar */
  for (i=0; i<=numRegressAttributes; i++) {
    updatedbbar[i] = 0.0;
    for (j=0; j<=numRegressAttributes; j++) {
      updatedbbar[i] += Binverse[i][j] * bbar[j];
    }
  }

  /* keep results in regressCoefficient[] */
  for (i=0; i<=numRegressAttributes; i++) {
    regressCoefficient[i] = updatedbbar[i];
  }

  return;

}
/*eject*/
/*********************************************************
 *  getAttributes
 * 
 *  purpose:  get attributes
 *            
 *********************************************************/
void getAttributes() {

  numAttributes = 0;

  /* process attributes section */
  getLineread();
  /* must have ATTRIBUTES record */
  if (strcmp(token,"ATTRIBUTES") != 0) {
    fprintf(stderr,
    "master2regression: Error: attributes section \n");
    fprintf(stderr,
    "                          out of order, case 1\n");
    fprintf(stderr,
    "current line = %s\n",lineread);
    exit(1);
  }

  /* process attributes */
  while (getLineread() == 1) {
    if (strcmp(token,"DATA") == 0) {
      return;
    }
    /* store attribute */
    numAttributes++;
    if (numAttributes > MAX_ATTRIBUTE) {
      fprintf(stderr,
      "master2regression: Error: MAX_ATTRIBUTE too small\n");
    }
    strcpy(attribute[numAttributes],token);
  } /* end while */

  fprintf(stderr, "master2regression: Error: Missing DATA record\n");

}
/*eject*/
/*********************************************************
 *  getData
 * 
 *  purpose:  get data
 *********************************************************/
void getData() {

  int j;

  /* Read records */
  numAmatrixRows = 0;

  while (getLineread() == 1) {

    if (strcmp(token,"ENDATA") == 0) {
      fclose(inputdatafile);
      return;
    }

    /* copy lineread record to outputline */
    strcpy(outputline,lineread);

    /* break up outputline into output tokens */
    outputline2outputtoken(outputline,outputtoken);

    /* store attribute values in bvector[] and Amatrix[][] */
    numAmatrixRows++;
    if (numAmatrixRows > MAX_RECORD) {
      fprintf(stderr,
       "master2regression: Error: MAX_RECORD too small\n");
      exit(1);
    }
    /* bvector entry */
    if (strcmp(outputtoken[regressIndex[0]],"?") == 0) {
      numAmatrixRows--;
      continue;
    }
    sscanf(outputtoken[regressIndex[0]],"%lf",
           &bvector[numAmatrixRows]);
    /* Amatrix entries */
    Amatrix[numAmatrixRows][0] = 1.0;
    for (j=1; j<=numRegressAttributes; j++) {
      if (strcmp(outputtoken[regressIndex[j]],"?") == 0) {
        numAmatrixRows--;
        break;
      }
      sscanf(outputtoken[regressIndex[j]],"%lf",
             &Amatrix[numAmatrixRows][j]);
    }
  } /* end while loop */

  fprintf(stderr,"master2regression: Unexpected end of ");
  fprintf(stderr,"input mst file %s\n",inputdata_filename);
  exit(1);

}
/*eject*/
/*********************************************************
 *  getIndex
 * 
 *  purpose:  returns index for attribute name as 
 *            appears in mst file ATTRIBUTES section
 *********************************************************/
int getIndex(char *attr)
{
  int i;
  for (i=1; i<=numAttributes; i++) {
    if (strcmp(attribute[i],attr) == 0) {
      return i;
    }
  }
  
  printf("Error in getIndex():  Attribute not found: %s\n", attr);
  exit(1);

  return 0;
}
/*eject*/
/*********************************************************
 *  getLineread
 * 
 *  purpose:  get next nonempty, noncomment line of inputmst file
 *            output: lineread (= line)
 *                    token (= first entry of lineread)
 *            
 *********************************************************/
int getLineread() {

  int i;

  while (fgets(lineread, MAXLEN, inputdatafile) != NULL) {

    /* skip over empty and comment lines */
    if ((lineread[0] == '\n') ||
        (lineread[0] == '*')) {
      continue;
    }

    /* strip off carriage return/whitespace at end of line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* store first entry of lineread in token */
    sscanf(lineread,"%s",token);

    return 1;    
  }

  /* file has no non-empty and non-comment line */
  strcpy(token,"");
  strcpy(lineread,"");
  return 0;

}
/*eject*/
/*********************************************************
 *  getRegressIndex
 * 
 *  purpose:  get indices of regression variables
 *            
 *********************************************************/
void getRegressIndex() {

  int i;

  for (i=0; i<=numRegressAttributes; i++) {
    regressIndex[i] = getIndex(regressAttribute[i]);
  }

  return;

}
/*eject*/
/*********************************************************
 *  openFiles
 * 
 *  purpose:  opens global input and output files
 *            
 *********************************************************/
void openFiles()
{
  if ((inputdatafile = fopen(inputdata_filename, "r")) == NULL) {
    fprintf(stderr,
    "master2regression: Cannot open inputdata_filename = %s\n", 
    inputdata_filename);
    exit(1);
  }

  if ((outputregfile = fopen(outputreg_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2regression: Cannot open outputreg_filename = %s\n", 
                    outputreg_filename);
    exit(1);
  }

}
/*eject*/
/*********************************************************
 *  outputline2outputtoken
 * 
 *  purpose:  convert outputline to outputtoken
 *            
 *********************************************************/
void outputline2outputtoken() {

  int i, nz;

  char *buffer;
  char saveout[MAXLEN] = {'\0'};


  /* save outputline for possibility of error message */
  strcpy(saveout,outputline);

  buffer = strtok(outputline," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
    "master2regression: Error: empty outputline\n");
    exit(1);
  }
  i = 1;
  strcpy(outputtoken[i],buffer);
  i++;
  nz = numAttributes;
  while (i <= nz) {
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL) {
      fprintf(stderr,
        "master2regression: Error: not enough attribute values");
      fprintf(stderr,
        "in outputline\nLine:\n%s\n",saveout);
      exit(1);
    }
    strcpy(outputtoken[i],buffer);
    i++;
  } /* end while i <= nz */
/*eject*/
  /* check that entire outputline has been used */
  buffer = strtok(NULL," \t\n");
  if (buffer != NULL) {
    fprintf(stderr,
    "master2regression: Error: outputline has too many\n");
    fprintf(stderr,
    "values\nLine:\n%s\n",saveout);
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  outputResults
 * 
 *  purpose:  output regression results
 *            
 *********************************************************/

void outputResults() {

  int i, j;

  double rfac;

  /* regression results */
  fprintf(outputregfile,
          "#ridgefactor\t%f\n",(float)ridgeFactor);

  fprintf(outputregfile,
          "#constant\t%f\n",(float)regressCoefficient[0]);

  for (j=1; j<=numRegressAttributes; j++) {
    fprintf(outputregfile,"#coeff(%s)\t%f\n",
            attribute[regressIndex[j]],
            (float)regressCoefficient[j]);
  }

  fprintf(outputregfile,
          "#meanerror\t%f\n",(float)meanError); 

  fprintf(outputregfile,
          "#varianceerror\t%f\n",(float)varError);
 
  /* regression attributes */
  fprintf(outputregfile, "#ATTRIBUTES\n#RECORD\n");

  fprintf(outputregfile,
          "#%s\n",regressAttribute[0]);/* yvar */

  fprintf(outputregfile,
          "#ESTIMATE\n#ERROR\n");

  for (j=1; j<=numRegressAttributes; j++) {
    fprintf(outputregfile,"#%s\n",regressAttribute[j]); /* xvarj */
  }

  fprintf(outputregfile, "#Ridge F.\tConstant\tCoefficients\n");
  for (i=0; i<=numRidgeFactors; i++) {
    /* ridge factor */
    rfac = 1.0 + ((double)i)*0.01; 
    fprintf(outputregfile,"#%f\t",rfac);
    /* regression coefficients */
    for (j=0; j<=numRegressAttributes; j++) {
      fprintf(outputregfile,"%f\t",regressCoeffArray[i][j]);
    }
    fprintf(outputregfile,"\n");
  }
  

  fprintf(outputregfile, "#DATA\n");

  for (i=1; i<=numAmatrixRows; i++) {
    fprintf(outputregfile,"%d\t",i); /* RECORD */
    fprintf(outputregfile,"%f\t",(float)bvector[i]);  /* yvalue */
    fprintf(outputregfile,"%f\t",(float)estimate[i]); /* yestimate */
    fprintf(outputregfile,"%f\t",(float)(estimate[i]-bvector[i]));
                                                      /* ERRROR */
    for (j=1; j<=numRegressAttributes; j++) {
      fprintf(outputregfile,"%f\t",(float)Amatrix[i][j]);
                                                      /* xvaluej */
    }
    fprintf(outputregfile,"\n");
  } 

  fprintf(outputregfile, "#ENDATA\n");

  fclose(outputregfile);

  return;

}
/********last record of master2regression.c************/
