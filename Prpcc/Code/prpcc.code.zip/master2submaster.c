#include "prpcc.h"

/* NOTE: Program replaced by more general */
/* master2subdnfmaster Sep 2010 */

/* input and output files */
FILE *mstfile;
FILE *submstfile;
char mst_filename[MAX_ID];
char submst_filename[MAX_ID];

/* call parameters */
int numCallParams;
char callParams[2+3*MAX_CONDITION+1][MAX_ID];

/* attribute names and lines */
char attribute[MAX_ATTRIBUTE+1][MAX_ID];
char attributeLine[MAX_ATTRIBUTE+1][MAX_ENTRY];
int attributeKeepFlag[MAX_ATTRIBUTE+1];
double attributeMin[MAX_ATTRIBUTE+1];
double attributeMax[MAX_ATTRIBUTE+1];
int attributeWithLimit[MAX_ATTRIBUTE+1];
int numAttributes; /* total number of attributes */

/* records */
char record[MAX_RECORD_HUGE+1][MAX_ATTRIBUTE+1][MAX_NUM];
int numRecords; /* total number of records */
int numInputRecords;

/* Limits */
struct{
  char name[MAX_ID]; /* attribute for which limit is defined */
  int index;         /* index of attribute */
  float value;       /* low/high bound for acceptance */
} typedef LimitArray;
LimitArray lowLimit[MAX_CONDITION+1];
LimitArray highLimit[MAX_CONDITION+1];

/* number of attribute limits */
int numLowLimits;
int numHighLimits;

/* bounds on record size for acceptance */
int lowRecordSize;
int highRecordSize;

/* options */
struct{
  int deleteMonotoneAttributes;
  int omitATTRIBUTESsection;
  int omitDATAstatement;
  int omitENDATAstatement;
  int nodisplayInputParameters;
} typedef OptionList;

OptionList option;

/* function prototypes */
void openfiles();
void addAttribute(char lineread[]);
void checkRecord(char lineread[]);
void completeLimits();
void computeAttributeKeepFlag();
void outputSubmaster();
void storeAttribute(char lineread[]);
void storeParameters();
int stringCompare(const char *a, const char *b, int n);

/* main function */
int main(int argc, char *argv[])
{
  char lineread[MAXLEN] = {'\0'};
  int endDataFlag = 0;
  int i, j, nz;
  int recordType = FALSE;  /* suppresses compiler warning */

  numCallParams = argc - 1;
  for (i=1; i<=numCallParams; i++) {
    strcpy(callParams[i],argv[i]);
    }

  /* DEBUG parameter definition */
  /* numCallParams = 8;
  strcpy(callParams[1],"smallmaster.mst");
  strcpy(callParams[2],"output.mst");
  strcpy(callParams[3],"-delete");
  strcpy(callParams[4],"monotone");
  strcpy(callParams[5],"attributes");
  strcpy(callParams[6],"status");
  strcpy(callParams[7],"gt");
  strcpy(callParams[8],"0"); */
  /* end DEBUG definitions */

  /* store call parameters in file names and limit arrays */
  storeParameters();

  /* open all files */
  openfiles();

  numAttributes = 0;
  numRecords = 0;
  numInputRecords = 0;

  for (j=1; j<=MAX_ATTRIBUTE; j++) {
    attributeMin[j] = INFTY;
    attributeMax[j] = NEGINFINITY;
    attributeWithLimit[j] = FALSE;
  }

  /* read input master file */
  while (fgets(lineread, MAXLEN, mstfile) != NULL) {

    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return and whitespace 
     * at the end of the line
     */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* Determine record type */
    if (stringCompare(lineread, "DATA", 4) == 0) {
      recordType = DATA;
      completeLimits(); /* add indices to low/high limits */

    } else if (stringCompare(lineread, "ATTRIBUTES", 10) == 0) {
      recordType = ATTRIBUTE;

    } else if ((stringCompare(lineread, "ENDATA", 6) == 0) ||
	      (stringCompare(lineread, "ENDDATA", 7) == 0)) {
      endDataFlag = TRUE;
      break; 
   
    } else if (lineread[0] == '*') {
      continue;
		
    } else if (strcmp(lineread,"") == 0) {
      continue;

    } else if (recordType == ATTRIBUTE) {
      storeAttribute(lineread);
			
    } else if (recordType == DATA) {
      /* check record for low/high limits
       * if any limit is violated, discard record
       * else keep record
       */
      numInputRecords++;
      checkRecord(lineread);

    } else {
      fprintf(stderr,
        "master2submaster: unidentifiable line in input master\n");
      exit(1); 
    }
  }

  /* option: delete monotone attributes */
  if (option.deleteMonotoneAttributes == TRUE) {
    computeAttributeKeepFlag();
  }

  /* output submaster */
  outputSubmaster();

  /* close files */
  fclose(mstfile);
  fclose(submstfile); 
  
  return 0;

}
/*eject*/
/*********************************************************
 *  checkRecord
 * 
 *  purpose:  parse record
 *            determine number of non"?" entries
 *            keep record if
 *              - number of non"?" entries > lowRecordSize
 *              - number of non"?" entries < highRecordSize
 *              - non"?" attribute entries observe limits
 *                specified in lowLimit and highLimit
 *********************************************************/
void checkRecord(char fileRec[])
{
  char *buffer;
  int j, jx, n;
  float val;

  numRecords++;
  if (numRecords+1 > MAX_RECORD_HUGE) {
    fprintf(stderr,
            "master2submaster: error, too many records\n");
    exit(1);
  }
  
  //Read first record entry
  buffer = strtok(fileRec, " \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
            "master2submaster: error, empty record line\n");
    exit(1); 
  }
  if (buffer[0] == '?') {
    n = 0;
  } else {
    n = 1;
  }
  j = 1;
  strcpy(record[numRecords][j],buffer);

  //process remaining record entries
  for (j=2; j<=numAttributes; j++) {
    buffer = strtok(NULL," \t\n)");
    if (buffer == NULL){
      fprintf(stderr,
            "master2submaster: error, record has too few entries\n");
      exit(1); 
    }
    strcpy(record[numRecords][j],buffer); 
    if (buffer[0] != '?') {
      n++;
    }  
  }

  /* check if entire record has been processed */
  buffer = strtok(NULL," \t\n)");
  if (buffer != NULL){
    fprintf(stderr,
        "master2submaster: error, record has too many entries\n");
    exit(1); 
  }  

  /* recordSize limits */
  /* check if n < lowRecordSize or > highRecordSize */
  if ((n < lowRecordSize) || (n > highRecordSize)) {
    numRecords--;
    return;
  }

  /* check if record entries satisfy attribute low limits */
  for (jx=1; jx<=numLowLimits; jx++) {
    j = lowLimit[jx].index;
    if (record[numRecords][j][0]!='?') {
      val = (float)atof(record[numRecords][j]);
      attributeMin[j] = min(attributeMin[j],val);
      attributeMax[j] = max(attributeMax[j],val);
      if (val <= lowLimit[jx].value) {
        numRecords--;
        return;
      }
    }
  }

  /* check if record entries satisfy attribute high limits */
  for (jx=1; jx<=numHighLimits; jx++) {
    j = highLimit[jx].index;
    if (record[numRecords][j][0]!='?') {
      val = (float)atof(record[numRecords][j]);
      attributeMin[j] = min(attributeMin[j],val);
      attributeMax[j] = max(attributeMax[j],val);
      if (val >= highLimit[jx].value) {
        numRecords--;
        return;
      }
    }
  }

  /* records satisfies all limits, keep it */
  return;

}
/*eject*/
/*********************************************************
 *  completeLimits
 * 
 *  purpose:  add attribute indices to low/highLimit arrays
 *********************************************************/
void completeLimits() {

  int flag, i, j;

  for (i=1; i<=numLowLimits; i++) {
    flag = 0;
    for (j=1; j<=numAttributes; j++) {
      if (strcmp(lowLimit[i].name,attribute[j]) == 0) {
        lowLimit[i].index = j;
        attributeWithLimit[j] = TRUE;
        flag = 1;
        break;
      }
    }
    if (flag == 0) {
      fprintf(stderr,
    "master2submaster:  Unknown attribute specified in low limit\n");
      exit(1);
    }
  }

  for (i=1; i<=numHighLimits; i++) {
    flag = 0;
    for (j=1; j<=numAttributes; j++) {
      if (strcmp(highLimit[i].name,attribute[j]) == 0) {
        highLimit[i].index = j;
        attributeWithLimit[j] = TRUE;
        flag = 1;
        break;
      }
    }
    if (flag == 0) {
      fprintf(stderr,
  "master2submaster:  Unknown attribute specified in high limit\n");
      exit(1);
    }
  }
  return;

}
/*eject*/
/*********************************************************
 *  computeAttributeKeepFlag
 * 
 *  purpose:  compute attributeKeepFlag[]
 *            attribute is kept iff its column is not monotone
 *********************************************************/
void computeAttributeKeepFlag() {

  char oneEntry[MAX_ID];
  int i, j, monotoneFlag;

  /* find and delete monotone columns */
  for (j=1; j<=numAttributes; j++) {
    monotoneFlag = 0;
    oneEntry[0] = '\0';
    for (i=1; i<=numRecords; i++) {
      if (record[i][j][0] == '?') {
        continue;
      } else {
        if (strcmp(oneEntry,record[i][j]) !=0) {
          monotoneFlag++;
          strcpy(oneEntry,record[i][j]);          
        } 
        if (monotoneFlag >= 2) {
          break;
        }
      }
    } /* end for i */

    if (monotoneFlag < 2) {
      attributeKeepFlag[j] = FALSE;
    }
   
  } /* end for j */  

  return;

}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles()
{
  if ((mstfile = fopen(mst_filename, "r")) == NULL) {
    fprintf(stderr, "master2submaster: Cannot open %s\n", 
                    mst_filename);
    exit(1); 
  }   

  if ((submstfile = fopen(submst_filename, "w")) == NULL) {
    fprintf(stderr, "master2submaster: Cannot open %s\n", 
                    submst_filename);
    exit(1);
  }
}
/*eject*/
/*********************************************************
 *  outputSubmaster
 * 
 *  purpose:  output reduced master to submaster file
 *********************************************************/
void outputSubmaster() {

  int i, j;

  if (option.omitATTRIBUTESsection == FALSE) {
    fprintf(submstfile,"ATTRIBUTES\n");

    for (j=1; j<=numAttributes; j++) {
      if (attributeKeepFlag[j] == TRUE) {
        fprintf(submstfile,"%s\n",attributeLine[j]);
      }
    }
  }

  if (option.omitDATAstatement == FALSE) {
    fprintf(submstfile,"DATA\n");
  }

  for (i=1; i<=numRecords; i++) {
    for (j=1; j<=numAttributes; j++) {
      if (attributeKeepFlag[j] == TRUE) {
        fprintf(submstfile,"%s\t",record[i][j]);
      }
    }
    fprintf(submstfile,"\n");
  }

  if (option.omitENDATAstatement == FALSE) {
    fprintf(submstfile,"ENDATA\n");  
  }
/*eject*/
  /* display summary of results */
  if (option.nodisplayInputParameters == FALSE) {
    printf("Results:\n");
    printf("  Number of attributes:  %d\n",numAttributes);
    printf("  Number of records of input file:  %d\n",
           numInputRecords);
    printf("  Number of records of output file:  %d\n",
           numRecords);

    printf("  Min and max values of attributes with limits:\n");
    for (j=1; j<=numAttributes; j++) {
      if (attributeWithLimit[j] == TRUE) {
      printf("    %s  min = %f  max = %f\n",
             attribute[j], attributeMin[j], attributeMax[j]);
      }
    }
    printf("\n"); 

    printf("Output in ./%s\n\n",submst_filename);
  }

  return;

}
/*eject*/
/*********************************************************
 *  storeAttribute
 *
 *  purpose:  store attribute line in attributeLine[]
 *                  attribute name in attribute[]
 *********************************************************/
void storeAttribute(char lineread[]) {

  char *buffer;

  numAttributes++;
  if (numAttributes+1 > MAX_ATTRIBUTE) {
    fprintf(stderr,
            "master2submaster: error, too many attributes\n");
    exit(1);
  }
  strcpy(attributeLine[numAttributes],lineread);
  buffer = strtok(lineread," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,
            "master2submaster: error, empty attribute line\n");
    exit(1); 
  }  
  strcpy(attribute[numAttributes],buffer);

  /* initialize option for keeping attribute */
  attributeKeepFlag[numAttributes] = TRUE;

  return;
}
/*eject*/
/*********************************************************
 *  storeParameters
 *
 *  input:    numCallParams, callParams[] 
 *  purpose:  store parameters of call
 *********************************************************/
void storeParameters() {

  int k;

  /* initialize options to default values */

  option.deleteMonotoneAttributes = FALSE;
  option.omitATTRIBUTESsection = FALSE;
  option.omitDATAstatement = FALSE;
  option.omitENDATAstatement = FALSE;

  lowRecordSize = 0;
  highRecordSize = MAX_ATTRIBUTE + 1;

  numLowLimits = 0;
  numHighLimits = 0;

  if ((numCallParams<=2) || ((numCallParams-2)%3!=0)) {
    fprintf(stderr,
      "Calling Sequence:  master2submaster master.mst submaster.mst triples of options and limits\n");
    exit(1);
  }
  strcpy(mst_filename, callParams[1]);
  strcpy(submst_filename, callParams[2]);

  for (k=3; k<=numCallParams; k+=3) {

    /* options */
    if ((strcmp(callParams[k],"-delete") == 0) &&
        (strcmp(callParams[k+1],"monotone") == 0) &&
        (strcmp(callParams[k+2],"attributes") == 0)) {
      option.deleteMonotoneAttributes = TRUE;
      continue;
    }
    if ((strcmp(callParams[k],"-nodisplay") == 0) &&
        (strcmp(callParams[k+1],"input") == 0) &&
        (strcmp(callParams[k+2],"parameters") == 0)) {
      option.nodisplayInputParameters = TRUE;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"ATTRIBUTES") == 0) &&
        (strcmp(callParams[k+2],"section") == 0)) {
      option.omitATTRIBUTESsection = TRUE;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"DATA") == 0) &&
        (strcmp(callParams[k+2],"statement") == 0)) {
      option.omitDATAstatement = TRUE;
      continue;
    }
    if ((strcmp(callParams[k],"-omit") == 0) &&
        (strcmp(callParams[k+1],"ENDATA") == 0) &&
        (strcmp(callParams[k+2],"statement") == 0)) {
      option.omitENDATAstatement = TRUE;
      continue;
    }

    /* record limits */
    if (strcmp(callParams[k],"-recordsize") == 0) {
      if (strcmp(callParams[k+1],"gt") == 0) {
        lowRecordSize = atoi(callParams[k+2]);
        continue;
      } else if (strcmp(callParams[k+1],"lt") == 0) {
        highRecordSize = atoi(callParams[k+2]);
        continue;       
      } else {
        fprintf(stderr,
      "master2submaster:  '-recordsize' not followed by lt or gt\n");
        exit(1);
      }
    }

    /* attribute limits */ 
    if (strcmp(callParams[k+1],"gt") == 0) {
      numLowLimits++;
      strcpy(lowLimit[numLowLimits].name,callParams[k]);
      lowLimit[numLowLimits].value = (float) atof(callParams[k+2]);
      continue;

    } else if (strcmp(callParams[k+1],"lt") == 0) {
      numHighLimits++;
      strcpy(highLimit[numHighLimits].name,callParams[k]);
      highLimit[numHighLimits].value = (float) atof(callParams[k+2]);
      continue;
    } else {
        fprintf(stderr,
        "master2submaster:  parameter not recognized:\n");
        fprintf(stderr,
                "                   %s %s %s\n",
                callParams[k],callParams[k+1],callParams[k+2]);
        exit(1);
    }

  } /* end for k */

  /* display parameters */
  if (option.nodisplayInputParameters == FALSE) {
    printf("\nFiles:\n");
    printf("  Input:  %s\n",callParams[1]);
    printf("  Output: %s\n",callParams[2]);
    printf("Options and Limits:\n");
    for (k=3; k<=numCallParams; k+=3) {
      printf("  %s\t%s\t%s\n",
             callParams[k],callParams[k+1],callParams[k+2]);
    }
  }

   return;
}
/*eject*/
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}


/* last record of master2submaster.c****/
