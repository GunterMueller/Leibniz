#include "prpcc.h"

/* CAUTION: Must specify function for new column in */
/*          subroutine newColValue */

/* Global Input and Output files */
FILE *inputmstfile;
FILE *outputmstfile;

char   inputmst_filename[MAX_ID];
char   outputmst_filename[MAX_ID];
char   lineread[MAXLEN] = {'\0'};
char   token[MAX_ENTRY] = {'\0'};
double recordValue[MAX_ATTRIBUTE];

/* Global structure for computation of values for new column */
/* as a function of specified attributes of ATTRIBUTES list */
struct {
float value;           /* value of variable in one record */
char  name[MAX_ENTRY]; /* attribute name of variable */
int   index;           /* attribute index of variable */
} typedef Variable;

Variable variable[MAX_ATTRIBUTE+1];
/* 
 * Caution: variable[0] is the new variable added
 *            at end of attributes list
 *          variable[1],.,variable[numVariables] are old variables
 *             specified in the input mst file 
 */
int numVariables; /* = number of old variables */

int numAttributes; /* = number old attributes */
                   /* = variable[0].index - 1 */

/* function prototypes */
void convertLineread2value();
int  getLineread();
void newColValue();
void openfiles();

/* main function */
int main(int argc, char *argv[])
{
  int i;
  int recordType = 0;


  if (argc <= 4) {
    fprintf(stderr,
        "Calling Sequence:  ");
    fprintf(stderr,
        "master2newcolmaster1 input.mst output.mst \\ \n");
    fprintf(stderr,
        "                   ");
    fprintf(stderr,                
        "new_variable old_variable_1..old_variable_k\n");
    exit(1);
  }
  strcpy(inputmst_filename, argv[1]);
  strcpy(outputmst_filename, argv[2]);
  for (i=0; i<=argc-4; i++) {
    strcpy(variable[i].name,argv[i+3]);
    variable[i].index = 0;
  }
  numVariables = argc-4;

  /* DEBUG: comment out above and uncomment below */
  /* strcpy(inputmst_filename,"input.brain.mst");
  strcpy(outputmst_filename,"output.brain.mst");  
  strcpy(variable[0].name,"Reduced_JP_Mem");
  strcpy(variable[1].name,"JP_Mem");
  strcpy(variable[2].name,"LM1_A_endvalue");
  numVariables = 2; */

  openfiles();

  while (getLineread() == 1) {
    if (strcmp(token,"ATTRIBUTES") == 0) {
      if (recordType != 0) {
        fprintf(stderr,
        "master2newcolmaster1: Input file out of order:\n");
        exit(1);
      }
      numAttributes = 0;
      fprintf(outputmstfile,"ATTRIBUTES\n");
      recordType = ATTRIBUTE;
      continue;
    }
    if (strcmp(token,"ENDATA") == 0) {
      if (recordType != DATA) {
        fprintf(stderr,
        "master2newcolmaster1: Missing DATA record in input file\n");
        exit(1);
      } else {
        fprintf(outputmstfile,"ENDATA\n");
        recordType = ENDATA;
        break;
      }
    }
    if (strcmp(token,"DATA") == 0) {
      /* output new attributes */
      fprintf(outputmstfile,"%s\n",variable[0].name);
      fprintf(outputmstfile,"DATA\n");
      recordType = DATA;
      continue;
    }
    if (recordType == ATTRIBUTE) {
      numAttributes++;
      fprintf(outputmstfile,"%s\n",lineread);
      for (i=1; i<=numVariables; i++) {
        if (strcmp(token,variable[i].name) == 0) {
          variable[i].index = numAttributes;
          continue;
        }
      }
    }
    if (recordType == DATA) {
      convertLineread2value(); /* get record values from lineread */
      newColValue(); /* compute new col value */
      if (variable[0].value == QUESTION_MARK) {
        fprintf(outputmstfile,"%s\t?\n",lineread);
      } else {
        fprintf(outputmstfile,"%s\t%f\n", lineread, 
                              (float)variable[0].value);
      }
    }
  }

  if (recordType != ENDATA) {
    fprintf(stderr,
    "master2newcolmaster1: Missing ENDATA record in input file %s\n",
     inputmst_filename);
    exit(1);
  }

  fclose(inputmstfile);
  fclose(outputmstfile);

  return 0;
}
/*eject*/
/*********************************************************
 *  convertLineread2value
 * 
 *  purpose:  converts data record to numerical values
 *            
 *********************************************************/
void convertLineread2value() {


  int j;

  char *buffer;
  char saveread[MAXLEN];

  strcpy(saveread,lineread);

  for (j=1; j<=numAttributes; j++) {

    if (j == 1) {
      buffer = strtok(saveread," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }
    if (buffer == NULL) {
      fprintf(stderr,
           "master2newcolmaster1: line has too few entries\n%s\n",
           lineread);
      exit(1);
    }
    if (strcmp(buffer,"?") == 0) {
      recordValue[j] = QUESTION_MARK;
    } else {    
      sscanf(buffer,"%lf",&recordValue[j]);
    }

  } /* end for j */

  /* check that entire line has been read */
  buffer = strtok(NULL," \t\n");
  if (buffer != NULL) {
      fprintf(stderr,
         "master2newcolmaster1: line has too many entries\n%s\n",
         lineread);
      exit(1);
  }

  return;   
}
/*eject*/
/*********************************************************
 *  getLineread
 * 
 *  purpose:  get next nonempty, noncomment line of inputmst file
 *            output: lineread (= line)
 *                    token (= first entry of lineread)
 *            
 *********************************************************/
int getLineread() {

  int i;

  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) {

    /* skip over empty and comment lines */
    if ((lineread[0] == '\n') ||
        (lineread[0] == '*')) {
      continue;
    }

    /* strip off carriage return/whitespace at end of line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* store first entry of lineread in token */
    sscanf(lineread,"%s",token);

    return 1;    
  }

  /* file has no non-empty and non-comment line */
  return 0;

}
/*eject*/
/*********************************************************
 *  newColValue
 * 
 *  purpose:  computes value for new column, using current
 *            record in lineread and rules specified here
 *            
 *********************************************************/
void newColValue() {

  int i;

  /* extract values for old variables */
  for (i=1; i<=numVariables; i++) {
    variable[i].value = recordValue[variable[i].index];
    if (variable[i].value == QUESTION_MARK) {
      variable[0].value = QUESTION_MARK;
      return;
    } 
  }

  /* BEGIN: insert code for function computation */

  /* definitions:
   *  var1 = GROUP_ID = group number
   *  var2 = COWAT_ZdPSPR = COWAT difference between POST 
   *                              and PRE
   *  output value:
   *  if var1 = 1: output = -1 if var2 <= 4.5
   *                         1 if var2 >= 5.5
   *                         0 otherwise
   *  if var1 = 2: output = -1 if var2 <= 4.5
   *                         1 if var2 >= 6.5
   *                         0 otherwise
   *  if var1 = 3: output = -1 if var2 <= -3.5
   *                         1 if var2 >= 1.5
   *                         0 otherwise   
   */
   if (variable[1].value == 1.0) {
     if (variable[2].value <= 4.5) {
       variable[0].value = -1;
     } else if (variable[2].value >= 5.5) {
       variable[0].value = 1;
     } else {
       variable[0].value = 0;
     }
   } else if (variable[1].value == 2.0) {
     if (variable[2].value <= 4.5) {
       variable[0].value = -1;
     } else if (variable[2].value >= 6.5) {
       variable[0].value = 1;
     } else {
       variable[0].value = 0;
     }    
   } else if (variable[1].value == 3.0) {
     if (variable[2].value <= -3.5) {
       variable[0].value = -1;
     } else if (variable[2].value >= 1.5) {
       variable[0].value = 1;
     } else {
       variable[0].value = 0;
     }
   } else {
     fprintf(outputmstfile,
       "master2newcolmaster1: group value out of range: %lf\n",
       variable[1].value);
     exit(1);
   }

  /* END: insert code for function computation */
  
  return;

}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles()
{
  if ((inputmstfile = fopen(inputmst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "master2newcolmaster1: Cannot open %s\n", "inputmst_filename");
    exit(1); 
  }   

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2newcolmaster1: Cannot open %s\n", "ouputmst_filename");
    exit(1);
  }

  return;

}

/* last record of master2newcolmaster1.c****/
