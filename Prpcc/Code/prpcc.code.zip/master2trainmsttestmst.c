#include "prpcc.h"

/* Global Input and Output files */
FILE *mstfile;
FILE *trainmstfile;
FILE *testmstfile;

/* function prototypes */
void openfiles(char *mst_filename, char *trainmst_filename,
               char *testmst_filename);
int stringCompare(const char *a, const char *b, int n);
void writeline(FILE *output_trn, char line[]);

/* main function */
int main(int argc, char *argv[])
{
  char mst_filename[MAX_ID];
  char trainmst_filename[MAX_ID];
  char testmst_filename[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  int alt,recordType = 0;

  if (argc != 4) {
    fprintf(stderr,
    "Calling Sequence:  master2trainmsttestmst input.mst train.mst test.mst\n");
    exit(1);
  }
  strcpy(mst_filename, argv[1]);
  strcpy(trainmst_filename, argv[2]);
  strcpy(testmst_filename, argv[3]);

  openfiles(mst_filename,trainmst_filename,testmst_filename);
  alt = 0;
  while (fgets(lineread, MAXLEN, mstfile) != NULL) {
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0')) {
      continue;
    }
    if (stringCompare(lineread,"ENDATA",6) == 0) {
      if (recordType != DATA) {
        fprintf(stderr,"Missing DATA record in input file\n");
        exit(1);
      } else {
        writeline(trainmstfile,lineread);
        writeline(testmstfile,lineread);
        recordType = ENDATA;
        break;
      }
    }
    if (stringCompare(lineread,"DATA",4) == 0) {
      if (recordType != 0) {
        fprintf(stderr,"Input records out of order\n");
        exit(1);
      } else {
        writeline(trainmstfile,lineread);
        writeline(testmstfile,lineread);
        recordType = DATA;
        continue;
      }
    }
    if (recordType == 0) {
      writeline(trainmstfile,lineread);
      writeline(testmstfile,lineread);
      continue;
    }
    if (recordType == DATA) {
      if (alt == 0) {
        writeline(trainmstfile,lineread);
        alt = 1;
      } else {
        writeline(testmstfile,lineread);
        alt = 0;
      }
      continue;
    }
    fprintf(stderr,"Input file in error\n");
    exit(1);   
  }
  if (recordType != ENDATA) {
    fprintf(stderr,"Missing ENDATA record in input file\n");
    exit(1);
  }

  fclose(mstfile);
  fclose(trainmstfile);
  fclose(testmstfile);

  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *mst_filename, char *trainmst_filename,
               char *testmst_filename)
{
  if ((mstfile = fopen(mst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "master2trainmsttestmst: Cannot open %s\n", "mst_filename");
    exit(1); 
  }   

  if ((trainmstfile = fopen(trainmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2trainmsttestmst: Cannot open %s\n", "trainmst_filename");
    exit(1);
  }
  if ((testmstfile = fopen(testmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2trainmsttestmst: Cannot open %s\n", "testmst_filename");
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  writeline
 * 
 *  purpose:  prints line of text to a file
 *            
 *********************************************************/
void writeline(FILE *output_trn, char line[])
{
  fprintf(output_trn, "%s", line);
}
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}

/* last record of master2trainmsttestmst.c****/
