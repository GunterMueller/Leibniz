#include "prpcc.h"

FILE *inputfil;
FILE *outputfil;
FILE *numberfil;
FILE *variablefil;

int main() {

  int nvar;
  double val;

  char fileRec[MAXLEN];
  char saveword[MAXLEN];
  char lowbound[MAXLEN];
  char highbound[MAXLEN];
  char type[MAXLEN];
  char *buffer;
  char quote[2];

  inputfil = fopen("input.mst","r");          
  outputfil = fopen("round.1.inputfile","w"); 
  numberfil = fopen("number.h","w");
  variablefil = fopen("variable.h","w");            

  strcpy(quote,"\"");
  nvar = 0;

  while (fgets(fileRec,MAXLEN,inputfil) != NULL) { /* while # 1*/

    if (strncmp(fileRec,"function",8) == 0 ) {
       continue;
    }

    if (strncmp(fileRec,"ATTRIBUTES",10) == 0) {
      fprintf(outputfil,"%s",fileRec);
      fprintf(outputfil,"PARETO\t TARGETVLO\n");
      continue;
    }

    if (strncmp(fileRec,"DATA",4) == 0) {
      fprintf(outputfil,"f1\t DELETE\n");
      fprintf(outputfil,"%s",fileRec);
      fprintf(numberfil,"nvar = %d;\n",nvar);
      fprintf(variablefil,"fprintf(domainfil,%sf1 DELETE\\n%s);\n",
                       quote,quote);
      break;
    }  

    buffer = strtok(fileRec," \t\n");
    strcpy(saveword,buffer);
    buffer = strtok(NULL," \t\n");
    strcpy(type,buffer);
    nvar++;
    if (strcmp(type,"DELETE") == 0) {
      fprintf(outputfil,"%s %s\n",saveword,type);
      fprintf(variablefil,"fprintf(domainfil,%s%s %s\\n%s);\n", 
                      quote,saveword,type,quote);    
    } else {
      buffer = strtok(NULL," \t\n");
      strcpy(lowbound,buffer);
      buffer = strtok(NULL," \t\n");
      strcpy(highbound,buffer);
      fprintf(outputfil,"%s\t %s %s %s\n",
              saveword,type,lowbound,highbound);
      fprintf(variablefil,
              "fprintf(domainfil,%s%s %s %s %s\\n%s);\n",
                    quote,saveword,type,lowbound,highbound,quote);
    }

  } /* end while # 1 */

  /* process records */
  while (fgets(fileRec,MAXLEN,inputfil) != NULL) { /* while # 2*/
        
    if (strncmp(fileRec,"ENDATA",6) == 0) {
      fprintf(outputfil,"%s",fileRec);
      break;
    }

    buffer = strtok(fileRec," \t\n");
    /* buffer has function value */
    strcpy(saveword,buffer);
    sscanf(saveword,"%lf",&val);
    if  (val >= 999999.) {
      strcpy(buffer,"9999999");
      strcpy(saveword,"9999999");
    }   
   
    while (buffer != NULL) {
      fprintf(outputfil,"%s ",buffer);
      buffer = strtok(NULL," \t\n");   
   }
   /* repeat function value */
   fprintf(outputfil,"%s\n",saveword);

  } /* end while # 2 */

  fclose(inputfil);
  fclose(outputfil);
  fclose(numberfil);
  fclose(variablefil);

  exit(0);

}
