

struct {
  double avg;    /* average */
  double dev;    /* standard deviation */
  double ratio;  /* if dev > 0: avg/dev, else = 0 */
  double nreq    /* min sample size if */
                 /* significance < 0.025 is desired */
                 /* uses one-tail 2-sigma bound */
} StatResults;
StatResults inputattsectCaseGroupPair[MAX_ATTRIBUTE_SECTION+1]  k
                                     [MAX_GROUP+1]              m
                                     [MAX_GROUP+1]              g
                                     [MAX_GROUP+1];             h



    for (g=1; g<=numGroups-1; g++) { /* for g, case 2 */
      for (h=g+1; h<=numGroups; h++) {
        for (m=1; m<=numCases; m++) { /* for m, case 2 */
