#include "prpcc.h"

FILE *mrtrfile;
FILE *rtsAfile;
FILE *rtsBfile;
FILE *rtsfile;

void openfiles(char *mrtr_filename, char *rtsA_filename, char *rtsB_filename, char *rts_filename);
void writeline(FILE *output_file, char line[]);
int stringCompare(const char *a, const char *b, int n);

int main(int argc, char *argv[])
{

  char mrtr_file[MAX_ID];
  char rtsA_file[MAX_ID];
  char rtsB_file[MAX_ID];
  char rts_file[MAX_ID];
  char fileRec[MAXLEN] = {'\0'};
  char outputline[MAXLEN+1] = {'\0'};
  int i, nz;
  int endDataFlag = 0;
  int recordType = 0;  /* value = 0 suppresses compiler warning */

  if (argc != 5) {
    printf("Calling Sequence: fileAB2test input.fileAB output.rtsA output.rtsB output.rts\n");
    exit(1);
  }

  strcpy(mrtr_file, argv[1]);
  strcpy(rtsA_file, argv[2]);
  strcpy(rtsB_file, argv[3]);
  strcpy(rts_file, argv[4]);

  openfiles(mrtr_file, rtsA_file, rtsB_file, rts_file);

  while (fgets(fileRec, MAXLEN, mrtrfile) != NULL) {

    nz = strlen(fileRec);
    i = nz - 1;
    /* strip off carriage return and whitespace at the end of the line */
    while (fileRec[i]>=1 && fileRec[i]<=32) {
      fileRec[i] = '\0';
      i--;
    }

    if (strncmp(fileRec, "*", 1) == 0) 
      continue;		
    else if (strncmp(fileRec, "\n", 1) == 0) 
      continue;
    else if ((stringCompare(fileRec, "BEGIN A", 7) == 0) ||
	     (stringCompare(fileRec, "begin a", 7) == 0)) {
      recordType = A;
      writeline(rtsfile, "*BEGIN A");
      writeline(rtsAfile, "*BEGIN A");
    }
    else if ((stringCompare(fileRec, "BEGIN B", 7) == 0) ||
	     (stringCompare(fileRec, "begin b", 7) == 0)) {
      recordType = B;	
      writeline(rtsfile, "*BEGIN B");
      writeline(rtsBfile, "*BEGIN B");
    }
    else if ((stringCompare(fileRec, "ATTRIBUTES", 10) == 0) ||
	     (stringCompare(fileRec, "attributes", 10) == 0)) {
      recordType = ATTRIBUTE;
      writeline(rtsfile, "*ATTRIBUTES");
      writeline(rtsAfile, "*ATTRIBUTES");
      writeline(rtsBfile, "*ATTRIBUTES");
    }
    else if (((stringCompare(fileRec, "ENDATA", 6) == 0) ||
	      (stringCompare(fileRec, "ENDDATA", 7) == 0)) ||
	     ((stringCompare(fileRec, "endata", 6) == 0) ||
	      (stringCompare(fileRec, "enddata", 7) == 0))) {
      endDataFlag = TRUE;
      writeline(rtsAfile, "ENDATA");
      writeline(rtsBfile, "ENDATA");
      writeline(rtsfile, "ENDATA");
      break;
    }
    else {
      if (recordType == ATTRIBUTE) {
	strcpy(outputline, "*");
	strcat(outputline, fileRec);
	writeline(rtsfile, outputline);
	writeline(rtsAfile, outputline);
	writeline(rtsBfile, outputline);
      }
      else if (recordType == A) {
	writeline(rtsfile, fileRec);
	writeline(rtsAfile, fileRec);
      }
      else if (recordType == B) {
	writeline(rtsfile, fileRec);
	writeline(rtsBfile, fileRec);
      }
    }
  }

  fclose(mrtrfile);
  fclose(rtsAfile);
  fclose(rtsBfile);
  fclose(rtsfile);

  return 0;
}

void openfiles(char *mrtr_filename, char *rtsA_filename, char *rtsB_filename, char *rts_filename)
{
  if ((mrtrfile = fopen(mrtr_filename, "r")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", "mrtr_filename");
    exit(1);
  }

  if ((rtsAfile = fopen(rtsA_filename, "w")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", "rtsA_filename");
    exit(1);
  }

  if ((rtsBfile = fopen(rtsB_filename, "w")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", "rtsB_filename");
    exit(1);
  }

  if ((rtsfile = fopen(rts_filename, "w")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", "rts_filename");
    exit(1);
  }

}

void writeline(FILE *output_file, char line[])
{
  fprintf(output_file, "%s\n", line);
}

/******************************************************************************
* First convert to upper case then compare
******************************************************************************/
int stringCompare(const char *a, const char *b, int n)
{
	int i;
	char aPrime[MAX_ID] = {'\0'};

	/* Convert "a" to upper case */
	for (i=0;i<n;i++)
	{

		if (a[i] >=  97 && a[i] <= 122)
			aPrime[i] = a[i] - 32;
		else
			aPrime[i] = a[i];
	}

	return strncmp(aPrime, b, n);

}

/*********************************************************
 *  subroutine error
 * 
 *  purpose:  print an error message on the screen
 * 
 *********************************************************/
void error(char *m1,char *m2) 
{
  printf("ERROR IN %s code %s\n", m1, m2);
  printf("**********************************\n");
}
/*************** end of file train2test.c **************/
