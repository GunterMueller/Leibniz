#include "prpcc.h"

/* Global Arrays and Variables */
double trainVector[MAX_RECORD+1][MAX_ATTRIBUTE+1];
int numTrainVectors;

double testVector[MAX_ATTRIBUTE+1];
int numTestVectors;

double solutionVector[MAX_ATTRIBUTE+1];
double differenceVector[MAX_ATTRIBUTE+1];
double maxDifference, totDifference;
double distance[MAX_RECORD+1];

int numVariables;
int statusVariable[MAX_ATTRIBUTE+1]; /* = ACTIVE: active */
                                     /* = DELETE: deleted */
                                     /* = DISCARD: discarded */

/* Global Input and Output files */
FILE *trainmstfile;
FILE *testatsfile;
FILE *matchatsmstfile;
FILE *matcherrorfile;

/* function prototypes */
double distance2vectors(double *x, double *y, int type);
void record2vector(char *rec, double *x);
void openfiles(char *trainmst_filename, char *testats_filename,
               char *matchatsmst_filename,char *matcherror_filename);
int stringCompare(const char *a, const char *b, int n);
void writeline(FILE *output_file, char line[]);
void writevector(FILE *output_file, double *vector, int n);

/* main function */
int main(int argc, char *argv[])
{
  char trainmst_filename[MAX_ID];
  char testats_filename[MAX_ID];
  char matchatsmst_filename[MAX_ID];
  char matcherror_filename[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  int  i, j, n, nmatch, recordType;
  double mindist;

  recordType = 0;
  numTrainVectors = 0;
  numTestVectors = 0;
  numVariables = 0;


    if (argc != 5) {
    fprintf(stderr,"Calling Sequence:  ");
    fprintf(stderr,"matchtraintest train.mst test.ats match.ats.mst\n");
    exit(1);
  }
  strcpy(trainmst_filename, argv[1]);
  strcpy(testats_filename, argv[2]);
  strcpy(matchatsmst_filename, argv[3]);
  strcpy(matcherror_filename, argv[4]);

  /* DEBUG: comment out above two sections and activate code below */
  /* strcpy(trainmst_filename, "train.mst");
  strcpy(testats_filename, "test.ats");
  strcpy(matchatsmst_filename, "match.ats.mst"); */

  openfiles(trainmst_filename,testats_filename,
            matchatsmst_filename,matcherror_filename);

  /* store train.mst records in trainVector[][] */
  while (fgets(lineread, MAXLEN, trainmstfile) != NULL) {
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0')) {
      continue;
    }
    if (stringCompare(lineread,"ATTRIBUTES",10) == 0) {
      continue;
    }
    if (stringCompare(lineread,"ENDATA",6) == 0) {
      if (recordType != DATA) {
        fprintf(stderr,"Missing DATA record in input train.mst file\n");
        exit(1);
      } else {
        recordType = ENDATA;
        break;
      }
    }
    if (stringCompare(lineread,"DATA",4) == 0) {
      if (recordType != 0) {
        fprintf(stderr,"Input records out of order\n");
        exit(1);
      } else {
        writeline(matchatsmstfile,lineread);
        recordType = DATA;
        continue;
      }
    }
    if (recordType == 0) {
      numVariables++;
      statusVariable[numVariables] = ACTIVE;
      for (i=1; i<strlen(lineread); i++) {
        if (strncmp(&lineread[i],"DELETE",6) == 0) {
          statusVariable[numVariables] = DELETE;
        }
        if (strncmp(&lineread[i],"DISCARD",7) == 0) {
          statusVariable[numVariables] = DISCARD;
          break;
        }
      }
      writeline(matchatsmstfile,lineread);
      continue;
    }
    if (recordType == DATA) {
      /* store train.mst record */
      numTrainVectors++;
      record2vector(lineread, trainVector[numTrainVectors]);
      continue;
    }
    fprintf(stderr,"Input file in error\n");
    exit(1);   
  }
  if (recordType != ENDATA) {
    fprintf(stderr,"Missing ENDATA record in train.mst file\n");
    exit(1);
  }

  /* process test.ats file records */
  recordType = 0;
  while (fgets(lineread, MAXLEN, testatsfile) != NULL) {
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0')) {
      continue;
    }
    if (stringCompare(lineread,"ENDATA",6) == 0) {
      if (recordType != DATA) {
        fprintf(stderr,"Missing DATA record in input test.ats file\n");
        exit(1);
      } else {
        writeline(matchatsmstfile,lineread);
        recordType = ENDATA;
        break;
      }
    }
    if ((stringCompare(lineread,"*DATA",5) == 0) ||
        (stringCompare(lineread,"DATA",4) == 0)) {
      if (recordType != 0) {
        fprintf(stderr,"Input records out of order\n");
        exit(1);
      } else {
        recordType = DATA;
        continue;
      }
    }
    if (recordType == 0) {
      continue;
    }
    if (recordType == DATA) {
      numTestVectors++;
      /* convert record to vector */
      record2vector(lineread,testVector);
      /* initialize solution vector */
      for (j=1; j<=numVariables; j++) {
        if (statusVariable[j] == ACTIVE) {
          solutionVector[j] = testVector[j];
        } else {
          solutionVector[j] = 0.0; 
        }
      }
      /* find matching records in trainVector[][] */
      distance[1] = distance2vectors(testVector,trainVector[1],ACTIVE);
      mindist = distance[1];
      for (n=2; n<=numTrainVectors; n++) {
        distance[n] = distance2vectors(testVector,
                                       trainVector[n],ACTIVE);
        mindist = min(mindist,distance[n]);
      }
      /* solution vector DELETE values = average of best matches */
      nmatch = 0;
      for (n=1; n<=numTrainVectors; n++) {
        if (distance[n] == mindist) {
          nmatch++;
          for (j=1; j<=numVariables; j++) {
            if (statusVariable[j] == DELETE) {
              solutionVector[j] += trainVector[n][j];
            }
          }
        }
      }
      if (nmatch == 0) {
        fprintf(stderr,"Error: zero matches\n");
        exit(1);
      }
      for (j=1; j<=numVariables; j++) {
        if (statusVariable[j] == DELETE) {
          solutionVector[j] /= (double)nmatch;
        }
      }
      /* write vectors into match.ats.mst file */
      fprintf(matchatsmstfile,
      /* uncomment/comment out for long output version */
      "Test = %d   Number of Matches = %d  Min Distance = %d\n",
        numTestVectors, nmatch, (int)mindist);
       /* "Test = %d  \n",
        numTestVectors); */
      fprintf(matcherrorfile,"%d\t",(int)mindist);
      /* test vector */
      writevector(matchatsmstfile, testVector, numVariables);
      /* solution vector vector */
      writevector(matchatsmstfile, solutionVector, numVariables);
      /* difference vector; only considers DELETE attributes */
      totDifference = 0.0;
      maxDifference = 0.0;
      for (j=1 ;j<=numVariables; j++) {
        if (statusVariable[j] != DELETE) {
          differenceVector[j] = 0;
        } else {
          differenceVector[j] = testVector[j] - solutionVector[j];
          if (differenceVector[j] < 0.0) {
            totDifference -= differenceVector[j];
            if (maxDifference < -differenceVector[j]) {
              maxDifference = -differenceVector[j];
            }
          } else {
            totDifference += differenceVector[j];
            if (maxDifference < differenceVector[j]) {
              maxDifference = differenceVector[j];
            }
          }
        }
      }
      writevector(matchatsmstfile, differenceVector, numVariables);
      /* accuracy */
      fprintf(matchatsmstfile,
      "Max Absolute Difference = %d   Sum Absolute Difference = %d\n", 
          (int)maxDifference, (int)totDifference);
      fprintf(matchatsmstfile, "\n");
      fprintf(matcherrorfile,"%d\n",(int)maxDifference);
      continue;            
    } /* end if recordType == DATA */  

    fprintf(stderr,"Input file in error\n");
    exit(1);   
  }
  if (recordType != ENDATA) {
    fprintf(stderr,"Missing ENDATA record in ats.mst file\n");
    exit(1);
  } 

  fclose(trainmstfile);
  fclose(testatsfile);
  fclose(matchatsmstfile);
  fclose(matcherrorfile);

  return 0;
}
/*eject*/
/************************************************************
 *   distance2vectors(): compute distance between two
 *   vectors using entries of specified type
 ************************************************************/
double distance2vectors(double *x, double *y, int type) {

  int j;
  double dist;

  dist = 0.0;
  for (j=1; j<=numVariables; j++) {
     if (statusVariable[j] == type) {
       dist += pow((x[j]-y[j]),2);
     }
  }
  dist = sqrt(dist);

  return dist;

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  record2vector(): convert record to numerical vector x
* --------------------------------------------------------
***************************************************************/
void record2vector(char *rec, double *x) {

  int j;
  char *buffer;
  char saveRec[MAXLEN];

  /* copy record rec into saveRec since strtok modifies string */
  strcpy(saveRec,rec);
  
  buffer = strtok(saveRec," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,"Unexpected train.mst record");
    exit(1);
  }
  x[1] = (double) atof(buffer);

  for (j=2; j<=numVariables; j++) {
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL) {
      fprintf(stderr,"unexpected end of train.mst record");
      exit(1);
    }
    x[j] = (double) atof(buffer);
  } /* end for j */

   /* verify that end of record has been reached */
   buffer = strtok(NULL," \t\n");
   if (buffer != NULL) {
     fprintf(stderr,"train.mst record has too many entries");
     exit(1);
   }

  return;

}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *trainmst_filename, char *testats_filename,
               char *matchatsmst_filename,char *matcherror_filename)
{

  if ((trainmstfile = fopen(trainmst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "matchtraintest: Cannot open %s\n", "trainmst_filename");
    exit(1);
  }
  if ((testatsfile = fopen(testats_filename, "r")) == NULL) {
    fprintf(stderr, 
    "matchtraintest: Cannot open %s\n", "testats_filename");
    exit(1);
  }
  if ((matchatsmstfile = fopen(matchatsmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "matchtraintest: Cannot open %s\n", "matchatsmst_filename");
    exit(1); 
  } 
  if ((matcherrorfile = fopen(matcherror_filename, "w")) == NULL) {
    fprintf(stderr, 
    "matchtraintest: Cannot open %s\n", "matcherror_filename");
    exit(1); 
  }     

  return;

}
/*eject*/
/*********************************************************
 *  stringCompare
 * 
 *  purpose:  First converts to upper case then compare
 *            
 *********************************************************/
int stringCompare(const char *a, const char *b, int n)
{
  int i;
  char aPrime[MAX_ID] = {'\0'};
  
  /* Convert "a" to upper case */
  for (i=0;i<n;i++)
    {
      if (a[i] >=  97 && a[i] <= 122)
	aPrime[i] = a[i] - 32;
      else
	aPrime[i] = a[i];
    }
  
  return strncmp(aPrime, b, n);
}
/*********************************************************
 *  writeline
 * 
 *  purpose:  prints line of text to a file
 *            
 *********************************************************/
void writeline(FILE *output_file, char line[])
{
  fprintf(output_file, "%s", line);
}
/*eject*/
/*********************************************************
 *  writevector
 * 
 *  purpose:  prints double vector of length n as integers
 *            on one line, with tab spacing
 *            
 *********************************************************/
void writevector(FILE *output_file, double *vector, int n)
{
  int j;

  for (j=1; j<=n; j++) {
    fprintf(output_file, "%d\t", (int)(vector[j]+0.5));
  }
  fprintf(output_file, "\n");
}

/* last record of matchtraintest.c****/
