#include "prpcc.h"

/* Global Input and Output files */
FILE *inputmstfile;
FILE *outputcsvfile;

/* function prototypes */
void openfiles(char *inputmst_filename, char *outputcsv_filename);

/* main function */
int main(int argc, char *argv[])
{

  int flag;

  char inputmst_filename[MAX_ID];
  char outputcsv_filename[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  char *buffer;
  char comnd[MAX_ID];
  int recordType = 0;

  flag = FALSE; /* to suppress compiler warning */

  if (argc != 3) {
    fprintf(stderr,
    "Calling Sequence:  master2csv input.mst output.csv\n");
    exit(1);
  }
  strcpy(inputmst_filename, argv[1]);
  strcpy(outputcsv_filename, argv[2]);

/* DEBUG; Uncomment below and comment out above */
/*   strcpy(inputmst_filename,"tiny.mst");
   strcpy(outputcsv_filename,"tiny.csv"); */

  openfiles(inputmst_filename,outputcsv_filename);

  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) {
    /* while #1 */

    buffer = strtok(lineread," \t\n");
    if ((buffer == NULL) || (buffer[0] == '*')) {
      continue;
    }

    /* process header records */
    if (strcmp(buffer,"ATTRIBUTES") == 0) {
      if (recordType != 0) {
        fprintf(stderr,"Records of input file %s out of order\n",
                       inputmst_filename);
        exit(1);
      } else {
        recordType = ATTRIBUTE;
        flag = FALSE;
        continue;
      }
    }
    if (strcmp(buffer,"DATA") == 0) {
      fprintf(outputcsvfile,"\n");
      recordType = DATA;
      continue;
    }
    if (strcmp(buffer,"ENDATA") == 0) {
      if (recordType != DATA) {
        fprintf(stderr,"Missing DATA record in input file %s\n",
                       inputmst_filename);
        exit(1);
      } else {
        recordType = ENDATA;
        break;
      }
    }

    /* process attribute/data records */
    if (recordType == ATTRIBUTE) {
      if (flag == FALSE) {
        fprintf(outputcsvfile,"%s",buffer);
        flag = TRUE;       
      } else {
        fprintf(outputcsvfile,",%s",buffer);
      }      
      continue;      
    }   
    if (recordType == DATA) {
      flag = FALSE;
      while (buffer != NULL) {
        if (flag == FALSE) {
          fprintf(outputcsvfile,"%s",buffer);
          flag = TRUE;       
        } else {
          fprintf(outputcsvfile,",%s",buffer);
        }
        buffer = strtok(NULL," \t\n");
      } 
      fprintf(outputcsvfile,"\n");     
      continue;      
    }

  } /* end while #1 */

  if (recordType != ENDATA) {
    fprintf(stderr,"Missing ENDATA record in input file %s\n",
                   inputmst_filename);
    exit(1);
  }

  fclose(inputmstfile);
  fclose(outputcsvfile);

  /* convert csv file from Unix to DOS */
  sprintf(comnd,"unix2dos %s",outputcsv_filename);
  if (system(comnd) != 0) {
    fprintf(stderr,"unix2dos conversion of output file %s failed\n",
                   outputcsv_filename);
    exit(1);
  }

  return 0;
}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles(char *inputmst_filename, char *outputcsv_filename)
{
  if ((inputmstfile = fopen(inputmst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "master2csv: Cannot open input file %s\n", inputmst_filename);
    exit(1); 
  }   

  if ((outputcsvfile = fopen(outputcsv_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2csv: Cannot open output file %s\n", outputcsv_filename);
    exit(1);
  }

  return;

}

/* last record of master2csv.c****/
