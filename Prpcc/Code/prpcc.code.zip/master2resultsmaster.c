#include "prpcc.h"

/* program computes results from input master file.
 *   places entire data set into inputRecord[][] array 
 *   derives results in routine computeResults()
 *   outputs the results as a master file in routine outputResults()
 */

/* this particular version of the program computes certain
 * average values and differences from data involving
 * beginvalue, midvalue, endvalue, beginslope, endslope
 * attributes. 
 * See README of ProjectBrainHealth/Intervention for details 
 */

/* CAUTION: Must specify subroutines computeResults and */
/*          outputResults for specific case */

/* CAUTION: Does not handle unknown values correctly. Hence */
/*          produces spuriously large values for some entries */

/* Global Input and Output files */
FILE *inputmstfile;
FILE *outputmstfile;

char   inputmst_filename[MAX_ID];
char   outputmst_filename[MAX_ID];
char   lineread[MAXLEN] = {'\0'};
char   token[MAX_ENTRY] = {'\0'};

/* Input Arrays */
char attribute[MAX_ATTRIBUTE+1][MAX_ID];
int numAttributes;
int numInputAttributeSections; 
/* number of attributes sections where each section has */
/* 5 attributes terminating in beginvalue, midvalue, endvalue, */
/* beginslope, endslope */
 

float recordValue[MAX_ATTRIBUTE+1];
float inputRecord[MAX_RECORD][MAX_ATTRIBUTE+1];
int numInputRecords;

/* Group_ID is an attribute of the input data */
int groupSize[MAX_ATTRIBUTE+1]; /* contains size of the groups */
int numGroups;

/* Output Arrays */
char outputVariable[MAX_ATTRIBUTE+1][MAX_ID];
int numOutputVariables;

float outputRecord[MAX_RECORD][MAX_ATTRIBUTE+1];
int numOutputRecords;

/* function prototypes */
void convertLineread2value();
int  getLineread();
void openfiles();
/* routines specific to the case at hand */
void computeResults();
void outputResults();

/* main function */
int main(int argc, char *argv[])
{
  int j;
  int recordType = 0;


  if (argc != 3) {
    fprintf(stderr,
        "Calling Sequence:  ");
    fprintf(stderr,
        "master2resultsmaster input.mst output.mst \n");
    exit(1);
  }
  strcpy(inputmst_filename, argv[1]);
  strcpy(outputmst_filename, argv[2]);

  /* DEBUG: comment out above and uncomment below */
  /* strcpy(inputmst_filename,"input.intervention.mst");
  strcpy(outputmst_filename,"results.intervention.mst"); */ 

  openfiles();

  while (getLineread() == 1) {
    if (strcmp(token,"ATTRIBUTES") == 0) {
      if (recordType != 0) {
        fprintf(stderr,
        "master2resultsmaster: Input file out of order:\n");
        exit(1);
      }
      numAttributes = 0;
      recordType = ATTRIBUTE;
      continue;
    }
    if (strcmp(token,"ENDATA") == 0) {
      if (recordType != DATA) {
        fprintf(stderr,
        "master2resultsmaster: Missing DATA record in input file\n");
        exit(1);
      } else {
        recordType = ENDATA;
        break;
      }
    }
    if (strcmp(token,"DATA") == 0) {
      /* output new attributes */
      numInputRecords = 0;
      recordType = DATA;
      continue;
    }
    if (recordType == ATTRIBUTE) {
      numAttributes++;
      if (numAttributes > MAX_ATTRIBUTE) {
        fprintf(stderr,
       "master2resultsmaster: Too many attributes in input master\n");
       exit(1);
      }
      strcpy(attribute[numAttributes],token);
      continue;
    }
    if (recordType == DATA) {
      convertLineread2value(); /* get record values from lineread */
      numInputRecords++;
      for (j=1; j<=numAttributes; j++) {
        inputRecord[numInputRecords][j] = recordValue[j];
      }
    }
  }

  if (recordType != ENDATA) {
    fprintf(stderr,
    "master2resultsmaster: Missing ENDATA record in input file %s\n",
     inputmst_filename);
    exit(1);
  }

  computeResults();
  outputResults();

  fclose(inputmstfile);
  fclose(outputmstfile);

  return 0;
}
/*eject*/
/*********************************************************
 *  computeResults
 * 
 *  purpose:  derives results from input data and puts them
 *            into outputRecords[][] array
 *            
 *********************************************************/
void computeResults() {

  int g, h, i, j, jump, k, m;

  float sum[MAX_ATTRIBUTE+1];

  numInputAttributeSections = 32; /* number of input attribute sections */
  /* must be specified here */
  /* each section consists of a leading name plus the suffix */
  /* beginvalue, midvalue, endvalue, beginslope, or endslope */
  /* listing begins in column 1 and goes to column 161 */

  numGroups = inputRecord[numInputRecords][1]; 
  /* groups must be listed in sequence, with highest group last */


  /* determine size of each group */
  for (g=1; g<=numGroups; g++) {
    groupSize[g] = 0;
  }
  for (i=1; i<=numInputRecords; i++ ) {
    groupSize[(int)inputRecord[i][1]]++;
  }

  /* compute output records */
  for (k=1; k<=numInputAttributeSections; k++) {
    /* process beginslope and endslope values */
    /* for each set of 5 related variables */

    for (m=1; m<=2; m++) {
      /* m=1: beginslope case; m=2: endslope case */
      j = 1 + 5*(k-1) + 3 + m; /* = variables index */

      for (g=1; g<=numGroups; g++) { /* for g, case 1 */
        /* handle the records of group g */
        sum[g] = 0;

        for (i=1; i<=numInputRecords; i++) {
          /* process each record i */
          if (inputRecord[i][1] == g) {
            sum[g] += inputRecord[i][j];
          }
        } /* end for i */

        /* compute average and store */
        outputRecord[k][3*(m-1) + g] = sum[g]/(float)groupSize[g];

      } /* end for g, case 1 */

    } /* end for m */

    /* compute differences from the average values */
    jump = (numGroups*(numGroups-1))/2;  /* number of group pairs */
    j = 0;

    for (g=1; g<=numGroups-1; g++) { /* for g, case 2 */
      for (h=g+1; h<=numGroups; h++) {

        j++;
        for (m=1; m<=2; m++) {
          /* difference of beginslope avg or endslope avg */
          outputRecord[k][2*numGroups + jump*(m-1) + j] = 
            outputRecord[k][numGroups*(m-1) + g] - 
            outputRecord[k][numGroups*(m-1) + h];
        }
        /* total difference of beginslope and endslope avg */
        outputRecord[k][2*numGroups + 2*jump + j] = 
          outputRecord[k][2*numGroups + j] + 
          outputRecord[k][2*numGroups + jump + j];

      } /* end for h */
    } /* end for g, case 2 */

  } /* end for k */ 

  return;

}
/*eject*/
/*********************************************************
 *  convertLineread2value
 * 
 *  purpose:  converts data record to numerical values
 *            
 *********************************************************/
void convertLineread2value() {


  int j;

  char *buffer;
  char saveread[MAXLEN];

  strcpy(saveread,lineread);

  for (j=1; j<=numAttributes; j++) {

    if (j == 1) {
      buffer = strtok(saveread," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }
    if (buffer == NULL) {
      fprintf(stderr,
           "master2resultsmaster: line has too few entries\n%s\n",
           lineread);
      exit(1);
    }
    if (strcmp(buffer,"?") == 0) {
      recordValue[j] = QUESTION_MARK;
    } else {    
      sscanf(buffer,"%f",&recordValue[j]);
    }

  } /* end for j */

  /* check that entire line has been read */
  buffer = strtok(NULL," \t\n");
  if (buffer != NULL) {
      fprintf(stderr,
         "master2resultsmaster: line has too many entries\n%s\n",
         lineread);
      exit(1);
  }

  return;   
}
/*eject*/
/*********************************************************
 *  getLineread
 * 
 *  purpose:  get next nonempty, noncomment line of inputmst file
 *            output: lineread (= line)
 *                    token (= first entry of lineread)
 *            
 *********************************************************/
int getLineread() {

  int i;

  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) {

    /* skip over empty and comment lines */
    if ((lineread[0] == '\n') ||
        (lineread[0] == '*')) {
      continue;
    }

    /* strip off carriage return/whitespace at end of line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* store first entry of lineread in token */
    sscanf(lineread,"%s",token);

    return 1;    
  }

  /* file has no non-empty and non-comment line */
  return 0;

}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles()
{
  if ((inputmstfile = fopen(inputmst_filename, "r")) == NULL) {
    fprintf(stderr, 
    "master2resultsmaster: Cannot open %s\n", "inputmst_filename");
    exit(1); 
  }   

  if ((outputmstfile = fopen(outputmst_filename, "w")) == NULL) {
    fprintf(stderr, 
    "master2resultsmaster: Cannot open %s\n", "ouputmst_filename");
    exit(1);
  }

  return;

}
/*eject*/
/*********************************************************
 *  outputResults
 * 
 *  purpose:  outputs results of outputRecords[][] array
 *            in master file format
 *            
 *********************************************************/
void outputResults() {

  int g, h, j, k, n;

  char att[MAX_ID];

  /* output variable names */

  fprintf(outputmstfile,"ATTRIBUTES\n");

  fprintf(outputmstfile,"attributeSection\n");

  for (g=1; g<=numGroups; g++) {
    fprintf(outputmstfile,"Gp%dbegslope_avg\n",g);
  }

  for (g=1; g<=numGroups; g++) {
    fprintf(outputmstfile,"Gp%dendslope_avg\n",g);
  }

  for (g=1; g<=numGroups-1; g++) {
    for (h=g+1; h<=numGroups; h++) {
      fprintf(outputmstfile,"diff%d%dbegval\n",g,h);
    }
  }

  for (g=1; g<=numGroups-1; g++) {
    for (h=g+1; h<=numGroups; h++) {
      fprintf(outputmstfile,"diff%d%dendval\n",g,h);
    }
  }

  for (g=1; g<=numGroups-1; g++) {
    for (h=g+1; h<=numGroups; h++) {
      fprintf(outputmstfile,"diff%d%dtotval\n",g,h);
    }
  }

  /* output computed values */

  fprintf(outputmstfile,"DATA\n");
  n = 2*numGroups + 3*numGroups*(numGroups-1)/2;

  for (k=1; k<=numInputAttributeSections; k++) {

    strcpy(att,attribute[1 + 5*(k-1) + 1]);
    att[strlen(attribute[1 + 5*(k-1) + 1]) - 11] = '\0';
    /* eliminate "_beginvalue" from end of attribute name */
    fprintf(outputmstfile,"%s", att);

    for (j=1; j<=n; j++) {
      fprintf(outputmstfile,"\t%f",outputRecord[k][j]);
    }
    fprintf(outputmstfile,"\n");

  } /* end for k */

  fprintf(outputmstfile,"ENDATA\n");

  return;

}
/* last record of master2resultsmaster.c****/
