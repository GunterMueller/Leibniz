#include "prpcc.h"

FILE *msplfile;
FILE *mrtrfile;
FILE *mrtsfile;

void openfiles(char *mspl_filename, char *mrtr_filename, char *mrts_filename);
void writeline(FILE *output_trn, char line[]);
int stringCompare(const char *a, const char *b, int n);

int main(int argc, char *argv[])
{
  char mspl_file[MAX_ID];
  char mrtr_file[MAX_ID];
  char mrts_file[MAX_ID];
  char fileRec[MAXLEN] = {'\0'};
  int endDataFlag = 0;
  int i, nz;
  int numArecs = 1;
  int numBrecs = 1;
  int recordType = 0;  /* value = 0 suppresses compiler warning */

  if (argc != 4) {
    printf("Calling Sequence: masterAB2trainABtestAB input.msAB output.trainAB output.testAB\n");
    exit(1);
  }

  strcpy(mspl_file, argv[1]);
  strcpy(mrtr_file, argv[2]);
  strcpy(mrts_file, argv[3]);

  openfiles(mspl_file, mrtr_file, mrts_file);

  while (fgets(fileRec, MAXLEN, msplfile) != NULL) {

    nz = strlen(fileRec);
    i = nz - 1;
    /* strip off carriage return and whitespace at the end of the line */
    while (fileRec[i]>=1 && fileRec[i]<=32) {
      fileRec[i] = '\0';
      i--;
    }

    if (strncmp(fileRec, "*", 1) == 0) 
      continue;		
    else if (strncmp(fileRec, "\n", 1) == 0) 
      continue;
    else if ((stringCompare(fileRec, "BEGIN A", 7) == 0) ||
	     (stringCompare(fileRec, "begin a", 7) == 0)) {
      recordType = A;
      writeline(mrtrfile, "BEGIN A");
      writeline(mrtsfile, "BEGIN A");
    }
    else if ((stringCompare(fileRec, "BEGIN B", 7) == 0) ||
	     (stringCompare(fileRec, "begin b", 7) == 0)) {
      recordType = B;	
      writeline(mrtrfile, "BEGIN B");
      writeline(mrtsfile, "BEGIN B");
    }
    else if ((stringCompare(fileRec, "ATTRIBUTES", 10) == 0) ||
	     (stringCompare(fileRec, "attributes", 10) == 0)) {
      recordType = ATTRIBUTE;
      writeline(mrtrfile, "ATTRIBUTES");
      writeline(mrtsfile, "ATTRIBUTES");
    }
    else if (((stringCompare(fileRec, "ENDATA", 6) == 0) ||
	      (stringCompare(fileRec, "ENDDATA", 7) == 0)) ||
	     ((stringCompare(fileRec, "endata", 6) == 0) ||
	      (stringCompare(fileRec, "enddata", 7) == 0))) {
      endDataFlag = TRUE;
      writeline(mrtrfile, "ENDATA");
      writeline(mrtsfile, "ENDATA");
      break;
    }
    else {
      if (recordType == A) {
	/*split A records into training and testing sets */
	if ((numArecs % 2) == 0) {
	  writeline(mrtrfile, fileRec);
	}
	else {
	  writeline(mrtsfile, fileRec);
	}
	numArecs++;
      }
      else if (recordType == B) {
	if ((numBrecs % 2) == 0) {
	  writeline(mrtrfile, fileRec);
	}
	else {
	  writeline(mrtsfile, fileRec);
	}
	numBrecs++;
      }
      else if (recordType == ATTRIBUTE) {
	/* write attribute names to both files */
	writeline(mrtrfile, fileRec);
	writeline(mrtsfile, fileRec);
      }
    }
  }
  

  fclose(msplfile);
  fclose(mrtrfile);
  fclose(mrtsfile);

  return 0;
}


void openfiles(char *mspl_filename, char *mrtr_filename, char *mrts_filename)
{
  if ((msplfile = fopen(mspl_filename, "r")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", mspl_filename);
    exit(1);
  }

  if ((mrtrfile = fopen(mrtr_filename, "w")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", mrtr_filename);
    exit(1);
  }

  if ((mrtsfile = fopen(mrts_filename, "w")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", mrts_filename);
    exit(1);
  }

}

void writeline(FILE *output_trn, char line[])
{
  fprintf(output_trn, "%s\n", line);
}

/*********************************************************
 *  subroutine error
 * 
 *  purpose:  print an error message on the screen
 * 
 *********************************************************/
void error(char *m1,char *m2) 
{
  printf("ERROR IN %s code %s\n", m1, m2);
  printf("**********************************\n");
}

/******************************************************************************
* First convert to upper case then compare
******************************************************************************/
int stringCompare(const char *a, const char *b, int n)
{
	int i;
	char aPrime[MAX_ID] = {'\0'};

	/* Convert "a" to upper case */
	for (i=0;i<n;i++)
	{

		if (a[i] >=  97 && a[i] <= 122)
			aPrime[i] = a[i] - 32;
		else
			aPrime[i] = a[i];
	}

	return strncmp(aPrime, b, n);

}


/*************** end of file mastersplit2traintest.c **************/
