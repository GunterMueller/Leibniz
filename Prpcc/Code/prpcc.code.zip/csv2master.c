#include "prpcc.h"

struct {
  char oldToken[MAX_ENTRY];
  char newToken[MAX_ENTRY];
} typedef Substitution;

/* Global Input and Output files */
FILE *csvfile;
FILE *subfile;
FILE *mstfile;

/*Global Structure for Substitutions */
char Attributes[MAX_ATTRIBUTE][MAX_ENTRY];
int numAttributes = 0;
Substitution globalSubs[MAX_ATTRIBUTE];
int numglobalSubs = 0;
int subAttributes[MAX_ATTRIBUTE];
Substitution localSubs[MAX_ATTRIBUTE];
int numlocalSubs = 0;
int alphanumericerror;

/* function prototypes */
void openfiles(char *csv_filename, char *sub_filename, char *mst_filename);
void writeline(FILE *outputFile, char line[]);
void shiftLeft(char fileRec[]);
int getIndex(char *attribute);
void substr(char dest[], char src[], int offset, int len);
void checkalphanumeric(char *token);


/*
 * CAUTION: 1. Must change delimiter character if not ','.
 *             See "set delimiter" below.
 *          2. The first line of the csv file MUST be
 *             contain the attribute names
 *          3. Attribute names must follow Leibniz convention,
 *             thus must be alphanumeric plus underscore, 
 *             with leading alpha.
 *          4. Attribute list MUST NOT contain blanks.
 */
/*eject*/
/* main function */
int main(int argc, char *argv[])
{
  char csv_file[MAX_ID];
  char sub_file[MAX_ID];
  char mst_file[MAX_ID];
  char lineread[MAXLEN] = {'\0'};
  char outputline[MAXLEN] = {'\0'};
  int i, j, nz;
  char *buffer;
  char comnd[MAX_ID];
  int index;
  int counter, subTok;
  int startindex;
  char token[MAXLEN] = {'\0'};
  char delimiter = ',';      /* set delimiter */

  if (argc != 4) {
    printf("Calling Sequence:  csv2master input.csv input.sub master.mst\n");
    exit(1);
  }
  strcpy(csv_file, argv[1]);
  strcpy(sub_file, argv[2]);
  strcpy(mst_file, argv[3]);

/* DEBUG: uncomment below and comment out above */
/*  strcpy(csv_file, "input.csv");
  strcpy(sub_file, "empty.substitute");
  strcpy(mst_file, "outputtest.mst"); */

  /* convert csv file from DOS to Unix */
  sprintf(comnd,"dos2unix %s",csv_file);
  if (system(comnd) != 0) {
    fprintf(stderr,"dos2unix conversion of input file %s failed\n",
                   csv_file);
    exit(1);
  }

  openfiles(csv_file, sub_file, mst_file);
  

  writeline(mstfile, "ATTRIBUTES");

  /* Grab the first line to get attributes */
  if (fgets(lineread, MAXLEN, csvfile) != NULL) {

    alphanumericerror = FALSE;  
    startindex = 0;
    i=0;
    
    while (lineread[i] != '\n' && lineread[i] != '\0') {
      if (lineread[i] == delimiter) {
	if (i==startindex) {
	  fprintf(stderr,
            "Error: Null Token found on attribute line\n");
          fprintf(stderr,
            "Missing attribute names\n");
	  exit(1);
	}
	else {
	  substr(token, lineread, startindex, i-startindex);
          checkalphanumeric(token);
	  writeline(mstfile, token);
	  strcpy(Attributes[numAttributes], token);
	  numAttributes++;
          if (numAttributes > MAX_ATTRIBUTE) {
            fprintf(stderr,
            "master2masterABTarget: error, too many attributes\n");
            fprintf(stderr,
            "must increase MAX_ATTRIBUTE in prpcc.h\n");
            exit(1);
          }
	  startindex = i+1;
	}
      }
      i++;
    }
    /* grab last token */
    if (startindex == i) {
      printf("Null Token found on attribute line\n  Missing attribute name... Exiting\n");
      exit(1);
    }
    else {
      substr(token, lineread, startindex, i-startindex);
      checkalphanumeric(token);
      writeline(mstfile, token);
      strcpy(Attributes[numAttributes], token);
      numAttributes++;
      if (numAttributes > MAX_ATTRIBUTE) {
        fprintf(stderr,
        "master2masterABTarget: error, too many attributes\n");
        fprintf(stderr,
        "must increase MAX_ATTRIBUTE in prpcc.h\n");
        exit(1);
      }
    }
  }
  else {
    printf("Error Reading .csv file.  No input on first line.  Exiting\n");
    exit(1);
  }
  if (alphanumericerror == TRUE) {
    exit(1);
  }
/*eject*/
  /* parse substitution file */
  while (fgets(lineread, MAXLEN, subfile) != NULL) {
    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return and whitespace at the end of the line */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    buffer = strtok(lineread, ",\n");
    if (buffer) {
      if (strcmp(buffer,"<all>") == 0) {
	//add to global substitutions
	buffer = strtok(NULL, ",\n");
	strcpy(globalSubs[numglobalSubs].oldToken, buffer);
	buffer = strtok(NULL, ",\n");
	strcpy(globalSubs[numglobalSubs].newToken, buffer);
	numglobalSubs++;	
      }
      else {
	//add to local substitutions
	index = getIndex(buffer);
	subAttributes[numlocalSubs] = index;
	buffer = strtok(NULL, ",\n");
	strcpy(localSubs[numlocalSubs].oldToken, buffer);
	buffer = strtok(NULL, ",\n");
	strcpy(localSubs[numlocalSubs].newToken, buffer);
	numlocalSubs++;	  
      }
    }
  }

  printf("Global Substitutions:\n");
  for (i=0; i<numglobalSubs; i++) {
    printf("%s    %s\n" , globalSubs[i].oldToken, globalSubs[i].newToken);
  }
  printf("Local Substitutions:\n");
  for (i=0; i<numlocalSubs; i++) {
    printf("%d    %s    %s\n", subAttributes[i], localSubs[i].oldToken, localSubs[i].newToken);
  }
/*eject*/
  writeline(mstfile, "DATA");
  /* Read records and put into DATA section of master file */
  while (fgets(lineread, MAXLEN, csvfile) != NULL) {

    /* strip off carriage return and whitespace at the end of the line */
    nz = strlen(lineread);
    i = nz - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    //printf("%s\n\n", lineread);
    
    /* Shift the line left (remove whitespace at beginning) */
    shiftLeft(lineread);
    
    /* Remove Commented lines and Blank Lines */
    if (strncmp(lineread, "*", 1) == 0) 
      continue;		
    else if (strncmp(lineread, "\n", 1) == 0) 
      continue;
    else {
      startindex = 0;
      i = 0;
      counter =0;
      strcpy(outputline, "");  //clear the outputline

      /* must parse character by character in case of empty fields */
      while (lineread[i] != '\n' && lineread[i] !='\0') {
	if (lineread[i] == delimiter) {
	  if (i==startindex) {
            /* old code: interpret blank excel field as "?" */
	    /* strcat(outputline, "?\t"); */
	    /* startindex = i+1; */
	    /* alternate code: terminate if excel field is blank */
            fprintf(stderr,"Line %s of .csv input file indicates blank field of excel file",lineread);
            exit(1);
	  }
	  else {
	    substr(token, lineread, startindex, i-startindex);

	    //now search for substitutions
	    subTok = 0;
	    for (j=0; j<numglobalSubs; j++) {
	      if (strcmp(globalSubs[j].oldToken, token) == 0) {
		strcat(outputline, globalSubs[j].newToken);
		strcat(outputline, "\t");
		startindex = i+1;
		subTok = 1;
	      }
	    }
	    if (subTok == 0) {
	      for (j=0; j<numlocalSubs; j++) {
		if (counter == subAttributes[j]) {
		  if (strcmp(localSubs[j].oldToken, token) == 0) {
		    strcat(outputline, localSubs[j].newToken);
		    strcat(outputline, "\t");
		    startindex = i+1;
		    subTok = 1;
		  }
		}
	      }
	    }

	    //if no substitutions, output token to line
	    if (subTok == 0) {
	      strcat(outputline,token);
	      strcat(outputline,"\t");
	      startindex = i+1;
	    }
	  }  // end else
	  counter++;
	} //end if (linerad[i] == ',')
	i++;
      }

      /* grab the last token on the line */
      if (startindex == i) {
        /* old code: interpret blank excel field as "?" */
	/* strcat(outputline, "?"); */
	/* alternate code: terminate if excel field is blank */
        fprintf(stderr,"Line %s of .csv input file indicates blank field of excel file",lineread);
        exit(1);
      }
      else {
	substr(token, lineread, startindex, i-startindex);
	
	//now check for substitutions
	subTok = 0;
	for (j=0; j<numglobalSubs; j++) {
	  if (strcmp(globalSubs[j].oldToken, token) == 0) {
	    strcat(outputline, globalSubs[j].newToken);
	    subTok = 1;
	  }
	}
	if (subTok == 0) {
	  for (j=0; j<numlocalSubs; j++) {
	    if (counter == subAttributes[j]) {
	      if (strcmp(localSubs[j].oldToken, token) == 0) {
		strcat(outputline, localSubs[j].newToken);
		subTok = 1;
	      }
	    }
	  }
	}

	//if no substitutions, output token to line
	if (subTok == 0) {
	  strcat(outputline, token);
	}
      } //end else for last token

      writeline(mstfile, outputline);
    } /* end else */
  } /* end while loop */
/*eject*/
  writeline(mstfile, "ENDATA");
  
  fclose(csvfile);
  fclose(mstfile);
  fclose(subfile);

  /* convert csv file from Unix to DOS */
  sprintf(comnd,"unix2dos %s",csv_file);
  if (system(comnd) != 0) {
    fprintf(stderr,"unix2dos conversion of input file %s failed\n",
                   csv_file);
    exit(1);
  }
  
  return 0;
} /* end main */
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens global input and output files
 *            
 *********************************************************/
void openfiles(char *csv_filename, char *sub_filename, char *mst_filename)
{
  if ((csvfile = fopen(csv_filename, "r")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", "csv_filename");
    exit(1);
  }

  if ((subfile = fopen(sub_filename, "r")) == NULL){
    fprintf(stderr, "Cannot open %s\n", "sub_filename");
    exit(1);
  }

  if ((mstfile = fopen(mst_filename, "w")) == NULL) {
    fprintf(stderr, "Cannot open %s\n", "mst_filename");
    exit(1);
  }

}
/*eject*/
/*********************************************************
 *  writeline
 * 
 *  purpose:  output line of text to specified file
 *            
 *********************************************************/
void writeline(FILE *outputFile, char line[])
{
  fprintf(outputFile, "%s\n", line);
}

/***********************************************************
*	Shift the line left
*   Ascii 32 = space, 9 = tab
************************************************************/
void shiftLeft(char fileRec[])
{
  while(fileRec[0] == 32 || fileRec[0] == 9) {
    strcpy(fileRec, fileRec+1);
  }
}
/*eject*/
/*********************************************************
 *  getIndex
 * 
 *  purpose:  returns index for attribute name as 
 *            appears in mst file ATTRIBUTES section
 *********************************************************/
int getIndex(char *attribute)
{
  int i = 0;
  for (i=0; i<numAttributes; i++) {
    if (strcmp(Attributes[i], attribute) == 0) {
      return i;
    }
  }
  
  printf("Error in getIndex():  Attribute not found: %s\n", attribute);
  exit(1);

  return 0;
}
/*eject*/
/*********************************************************
 *  substr
 * 
 *  purpose:  copies substring into another string
 *            
 *********************************************************/
void substr(char dest[], char src[], int offset, int len)
{
  int i;
  for(i = 0; i < len && src[offset + i] != '\0'; i++)
    dest[i] = src[i + offset];
  dest[i] = '\0';
}
/*eject*/
/*********************************************************
 *  checkalphanumeric
 * 
 *  purpose:  checks if token has alphanumeric form
 *            
 *********************************************************/
void checkalphanumeric(char *token) {

  int j, n;

  /* first character of token must be alpha or underscore */
  n = (int)token[0];
  if (((n<65)||
      (n>90))&&
      ((n<97)||
      (n>122))&&
      (n!=95)) {
    fprintf(stderr,
            "Error: First character '%c' of attribute '%s' must be ",
            token[0], token);
    fprintf(stderr,
            "alpha or underscore\n");
    alphanumericerror = TRUE;    
  }
/*
 *  remaining characters must be alphanumeric or underscore
 */
  for(j=1; j<=strlen(token)-1; j++)  {
    n = (int)token[j];
    if (((n<65)||
        (n>90))&&
        ((n<97)||
        (n>122))&&
        ((n<48)||
        (n>57))&&
        (n!=95)) {
      fprintf(stderr,
              "Error: Character '%c' of attribute '%s' must be ",
              token[j], token);
      fprintf(stderr,
              "alphanumeric or underscore\n");
      alphanumericerror = TRUE;     
    }
  } /* end for j */

  return;

}

/**********last record of csv2master.c******************/
