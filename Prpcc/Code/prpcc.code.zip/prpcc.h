/* first record of prpcc.h *****/

/******************* Includes **********************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <math.h>
#include <time.h>

/******************* Input Maximums ****************************/
#define MAX_ATTRIBUTE 1000   /* 300 */
#define MAX_ATTRIBUTE_SMALL 250
#define MAX_ATTRIBUTE_SECTION  50
#define MAX_CLASS 10         /* max classes for targets */
#define MAX_TIME_POINT 20    /* max number of time points */
#define MAX_CONDITION 50 /* max conditions for master2submaster */
#define MAXLEN 15000	       /* length of buffer for file line */ 
#define MAX_RECORD 5000
#define MAX_RECORD_HUGE 22000
#define MAX_RECORD_SMALL 200
#define MAX_REGRESSION_VAR 100
#define MAX_RIDGE_FACTOR 30
#define MAX_TARGET MAX_ATTRIBUTE
#define MAX_GROUP 10
#define MAX_ID 256
#define MAX_DIRECTORY 256
#define MAX_ENTRY 256
#define MAX_INTERVAL 10
#define MAX_NUM 15  /* max digits of numerical record entry */
/******************* Test File Record Types ********************/
#define A 1
#define B 2
#define SKIP 10
#define ATTRIBUTE 11
#define DATA 12
#define RECORD 13
#define ENDATA 14

#define FALSE 0
#define TRUE 1
#define ACTIVE 1
#define DELETE 2
#define DISCARD 3
#define TARGET 4
#define INFTY 999999999.0
#define NEGINFINITY -999999999.0
#define QUESTION_MARK 909090909
#define EPSILON 0.0001
#define REGRESSION_ERROR_THRESHOLD 0.7
/*eject*/
/******************* Substitution Functions *********************/
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))
#define CLOSE_TO_ONE 0.9999
#define roundDownToInt(x) ((x) >=0?(int)((x)):(int)((x)-CLOSE_TO_ONE))
#define roundUpToInt(x) ((x) >=0?(int)((x)+CLOSE_TO_ONE):(int)((x)))

/************ constants for random number generator *************/
#define  INITIAL_SEED      17
#define  SEED1             5      /* additional seed */
#define  SEED2             43     /* additional seed */
#define  SEED3             405    /* additional seed */
#define  SEED4             8287   /* additional seed */
#define  SEED5             52307  /* additional seed */
#define  MULTIPLIER        25173
#define  INCREMENT         13849
#define  MODULUS           65336
#define  DIVISOR  65535.0

/* last record of prpcc.h ****/
