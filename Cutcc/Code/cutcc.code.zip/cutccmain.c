/* first record of cutccmain.c *****/
/*
 *  Leibniz System: Cutcc System
 *  Copyright 1990-2015 by Leibniz Company
 *  Plano, Texas, U.S.A.
 *  
 *  This program is free software: you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free Software
 *  Foundation, either version 3 of the License, or (at your option) any later
 *  version. The License statement is in file lgpl.txt, but can also be obtained
 *  from www.gnu.org/licenses/.
 *
 *  We do not make any representation or warranty, expressed or implied, 
 *  as to the condition, merchantability, title, design, operation, or fitness 
 *  of the program for a particular purpose.
 *
 *  We do not assume responsibility for any errors, including mechanics or logic, 
 *  in the operation or use of the program, and have no liability whatsoever 
 *  for any loss or damages suffered by any user as a result of the program.
 * 
 *  In particular, in no event shall we be liable for special, incidental, 
 *  consequential, or tort damages, even if we have been advised of the 
 *  possibility of such damages.
 *
 * ===================================================
 * Cutcc System - Main Learning Program cutccmain
 * ===================================================
 */
#include "cutcc.h" 

int main(int argc, char *argv[]){ // argc and argv for lsqccparams
                                  // file definition

  void readParamsFile();
  int cutcc();
  /* lsqccparams file name option 
   *  if no name given, use default "lsqccparams.dat" 
   */
  if (argc > 1 && strcmp(argv[1],"") != 0) {
    strcpy(lsqccparamsname,argv[1]);
  } else {
    strcpy(lsqccparamsname,"lsqccparams.dat");
  }
  gRunType = CUTPOINT;
    
  /* Feb 29, 2007:
   * disabled options for CUTPOINT, ENTROPY, ENTROPY_MDL
   * and instead used given argument as expansion factor for
   * selected sigma
   *	
   * begin disabled code
   */
  /* If given an input parameter, can run the following: 
   * 
   * CUTPOINT 0, ENTROPY 1, or ENTROPY_MDL 2 
   *
   * If no parameter given run CUTPOINT 
   */
  /* if (argc == 2 && atoi(argv[1]) != 0) {
       gRunType = atoi(argv[1]); 
       if (gRunType > 2 || gRunType < 1) {
         printf(
           "Invalid parameter %d entered, enter nothing, 0,1,2.\n", 
           gRunType);
         fprintf(errfil, 
           "Invalid parameter %d entered, enter nothing, 0,1,2.\n", 
           gRunType);
         cuterror("main","100");
       }
     } else {
       gRunType = CUTPOINT;
     }
  * end disabled code
  */
	
 /* open error file errfil */
    if ((errfil = fopen("cutcc.err", "w")) == NULL) {	
      printf("\n Cannot open error file cutcc.err. Stop");
      exit(1);
    }
		
 /*
  * Read lsqccparams.dat file 
  */
    readParamsFile();
	
 /*
  * execute cutcc 
  */
    cutcc();

    fclose(errfil);
	
    return errorflag;
}
/* last record of cutccmain.c *******/
