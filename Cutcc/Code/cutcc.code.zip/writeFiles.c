/* first record of writeFiles.c *****/
#include "cutcc.h"

void writeTrainResults() {
/*****************************************************************
* Writes out all output files resulting from training:
* .trn, .ptl, .cut if applicable, and vis
******************************************************************/
  /*
   * Write the output files .trn, .ptl, and
   * .cut if applicable
   */
  writeData(TRNFILE);
  writePartialLogic();
  if (gParams.doTrainNew == TRUE) {
    writeCutFile();
  }
		
  /*
   * Do the graphic illustration of cut points 
   */
  cutIllustration();

  if (gShowSteps) {
    /* cutpoint and visualization output */
    printf("\n***\n");    
    printf("Cutpoints and Visualization\n");
    printf("Output in files %s%s\n", 
           gParams.prefix,gFileExt.cut);
    printf("                %s%s\n", 
           gParams.prefix,gFileExt.vis);     
    printf("***\n\n");

    /* training file output */
    printf("\n***\n");
    printf("Training file successfully converted to logic data\n");
    printf("using ");
    if (gParams.doTrainNew == TRUE) {
      printf("new ");
    } else if(gParams.doTrainOld == TRUE) {
      printf("old ");
    } else { /* must be one of the two options above */
      cuterror("trainingDataProcessing","201");
    }
    printf(".cut file\n");         
    printf("Output in file %s%s\n", 
           gParams.prefix,gFileExt.trn); 
    printf("***\n\n");
  }	
}

/*eject*/
/*****************************************************************
* Writes out the logic data 
* Can write it to an internal table (input TABLE)
* or can write it out to a file (input TRNFILE or TSTFILE)
****************************************************************/
void writeData(int outputType)
{

  FILE *outrecFile = NULL; 
  char hold[MAX_ID];

  if (outputType == TRNFILE) { /* output .trn file */

    /* open the training output file */
    outrecFile = openFilePrefix(gFileExt.trn, "w");

    /* include partial data file */
    strcpy(hold, "include ");
    strcat(hold, gParams.prefix);   
    strcat(hold, gFileExt.ptl);
    fprintf(outrecFile, "%s\n", hold);

    /* Write BEGIN A record */
    fprintf(outrecFile, "BEGIN A\n");

    writeLogic(outputType, outrecFile, gDataRecords, 
               gAcount+gBcount);

    fprintf(outrecFile, "ENDATA");
    fclose(outrecFile);

  } else if (outputType == TSTFILE) { /*output .tst file */

    /* open the testing output file */
    outrecFile = openFilePrefix(gFileExt.tst, "w");

    writeLogic(outputType, outrecFile, gDataRecords, gTestRecCount);

    fprintf(outrecFile, "ENDATA");
    fclose(outrecFile);
    
  } else if (outputType == TABLE) { /*output table */

    writeLogic(outputType, outrecFile, gDataRecords, 
               gAcount+gBcount);
  } else {

    cuterror("writeData","101");

  }
	
}

/*eject*/
/*****************************************************************/
void writeLogic(int outputType, FILE *outrecFile, Record records[], int count)
{

	Value recValue;
	int recIndex;				// used to loop through the records
	int ai;						// attribute index
	int AB_flag;
	
	memset(lvalues,0,sizeof(lvalues));
	/* Dynamically allocate space for lvalues */
	/* +2: 1 for more var than cut + 1 for starting at index 1 */
	
	/* Loop through the records */
	for (recIndex = 0; recIndex < count; recIndex++)
	{
		
		AB_flag = records[recIndex].AB_flag;

		/* Loop through the attributes */
 		for (ai=1; ai <= gNumAttributes; ai++)
		{
			
			/* Initialize first value with UNA_OR_ABS, will be overwitten with real value */
			lvalues[1] = UNA_OR_ABS;

			recValue.rat = records[recIndex].value[ai].rat;
			recValue.code = records[recIndex].value[ai].code;
			
			/* Don't want to write out an unavailable/absent value */
			if (recValue.code == UNAVAILABLE || recValue.code == ABSENT) {	
				
				/* Defaulted to unavailable or absent */
				if (TABLE == outputType) writeLogicTable (ai, AB_flag, lvalues, recIndex);

				/* Don't write out this value */
				continue;
			}

			/*  So we have that later when we check that z_i != z_j */
			gLogicOut[recIndex].zValue[ai] = recValue.rat;

			/* Write out the values to an internal table or file */
			writeScheme(outputType, outrecFile, recValue, ai, AB_flag, lvalues, recIndex);

			/* Add a line break */
			if (outputType == TRNFILE || outputType == TSTFILE) {			
				if (ai != gNumAttributes) 
					fprintf(outrecFile, "\n");
			}


		}

		/* At end of attribute, write period, line break and comment */
		if (outputType == TRNFILE || outputType == TSTFILE)
		{
			fprintf(outrecFile, ".\n");
			
			if (outputType == TRNFILE) 
				fprintf(outrecFile, "*end record %d of line %d\n", recIndex+1, gTrainingLine[recIndex+1]);
			else 
				fprintf(outrecFile, "*end record %d of line %d\n", recIndex+1, gTestingLine[recIndex+1]);
		}


		if (recIndex == gAcount-1 && outputType == TRNFILE)
			fprintf(outrecFile, "BEGIN B\n");
		

	}

}

/*eject*/	
/******************************************************************************
*   Can write to a file (in set mode or regular mode) or can write
*   to an internal table that is used to see if the records are
*   separable.
*******************************************************************************/
void writeScheme(int outputType, FILE *outrecFile, Value recValue, 
					int ai, int AB_flag, int lvalues[], int recIndex)
{

	/* If writing to a file */
	if (outputType == TSTFILE || outputType == TRNFILE) {
		if (gSet[ai] == TRUE)
			writeFileSetValues(ai, AB_flag, outrecFile, recValue);
		else
			writeFileNonSetValues(ai, AB_flag, outrecFile, recValue);
	}

	/* Writing to an internal table */
	else  
		writeTableValues(ai, AB_flag, lvalues, recValue, recIndex);
	

	
}

/*eject*/
/******************************************************************
*  var >= 1 to exclude first, meaningless variable
*  encoding:
*  if UNCERTAIN: NEG ... NEG (OMITTED) POS ... POS
*     OMITTED entries correspond to values in interval of uncertainty
*  if NUM:       NEG ... NEG (OMITTED) POS ... POS
*     OMITTED entries correspond to values equal to cutpoints
*******************************************************************/
void writeFileNonSetValues(int ai, int AB_flag, FILE *outrecFile, 
                           Value recValue)
{
  int var = 1;

  while (var <= gCutVector[ai]) {
    if (gUncertainFlag[ai] == TRUE) {	       
      if (recValue.rat < gUncertainLow[ai][var]) {
        fprintf(outrecFile, "-%s_%d ", gAttribute[ai], var);
      } else if (recValue.rat > gUncertainHigh[ai][var]) {
        fprintf(outrecFile, " %s_%d ", gAttribute[ai], var);
      } 
    } else { /* May 18, 2007: added EPSILON for UNAVAILABLE case
              * March 4, 2009: reduced EPSILON to 0.0000005 and
              * used '(double)' for value comparison
              */
      if (gParams.unavailableOrAbsent == UNAVAILABLE) {
	if ((double)recValue.rat < 
            (double)gCutMatrix[ai][var]-EPSILON) {
	  fprintf(outrecFile, "-%s_%d ", gAttribute[ai], var);
	} else if ((double)recValue.rat > 
                   (double)gCutMatrix[ai][var]+EPSILON) {
	  fprintf(outrecFile, " %s_%d ", gAttribute[ai], var);
	}
      } else if (gParams.unavailableOrAbsent == ABSENT) {
	if (recValue.rat <= gCutMatrix[ai][var]) {
	  fprintf(outrecFile, "-%s_%d ", gAttribute[ai], var);
	} else if (recValue.rat > gCutMatrix[ai][var]) {
	  fprintf(outrecFile, " %s_%d ", gAttribute[ai], var);
	}
      } else {
	cuterror("writeFileNonSetValues","101");
      }
    }
    var++;
  }

}

/*eject*/
/******************************************************************************
*  if value strictly within interval: positive variable
*  if value equal to one of the two interval endpoints: variable omitted
*  else: negative variable
*******************************************************************************/
void writeFileSetValues(int ai, int AB_flag, FILE *outrecFile, Value recValue)
{
  int var = 1; 
  float cutValue1 = 0, cutValue2 = 0;

  while (var <= gCutVector[ai]+1) {		
    varToCutValues(ai, var, &cutValue1, &cutValue2);
    if (recValue.rat > cutValue1 && recValue.rat < cutValue2) {
      fprintf(outrecFile, " %s_%d ", gAttribute[ai], var);
    } else if (recValue.rat < cutValue1 || recValue.rat > cutValue2){
      fprintf(outrecFile, "-%s_%d ", gAttribute[ai], var);
    }
    var++;
  }
		
}

/*eject*/
/******************************************************************************
*  Form: POS NEG ... NEG, POS POS ... NEG, ..., POS POS ... POS
*  CAUTION: this representation for debugging only since it does not
*  have omitted values and thus does not agree with file values
*  see preceding routines writeFileNonSetValues and writeFileSetValues
*  for details of file values
*******************************************************************************/
void writeTableValues(int ai, int AB_flag, int lvalues[], Value recValue, int recIndex)
{
  int var = 1;

  lvalues[var] = POS;
  while (var <= gCutVector[ai]) {
    if (recValue.rat > gCutMatrix[ai][var]) {
      lvalues[var+1] = POS;
    } else {
      lvalues[var+1] = NEG;
    }
    var++;
  }
  writeLogicTable(ai, AB_flag, lvalues, recIndex);

}

/*eject*/
/******************************************************************************/
void writeLogicTable (int ai, int AB_flag, int lvalues[], int recIndex)
{
	int var, varCount;

	varCount = gCutVector[ai] + 1;

	gLogicOut[recIndex].AB_flag = AB_flag;
		
	for (var = 1; var <= varCount; var++)
	{
		gLogicOut[recIndex].lvalues[ai][var] = lvalues[var];  
	}
	
	
}

/*eject*/
/******************************************************************************/
void writeCutFile() {
  int ai, sig, i, cut;
  float fac;
  FILE* out;

  out = openFilePrefix(gFileExt.cut, "w");
	

  fprintf(out, "CUTPOINTS\n");
  fprintf(out, "*attribute type count cutpoints\n");

  /* logic a little complicated because names of deleted 
   * attributes are kept separately based 
   * on gBeforeDel vector 
  */

  ai = 0;

  for (i = 1; i <= gBeforeDel; i++) { /* begin for i #1 */
		
    /* If deleted write DELETE and continue */
    if (gDeleteVector[i]) {
      fprintf(out, "%s", gAttributeDel[i]);
      fprintf(out, "\tDELETE\n");
      continue;
    }

    ai++;

    /* Write the attribute name */
    fprintf(out, "%s", gAttribute[ai]);

   /* Write out if set or numb */
    if (gSet[ai]) {
      fprintf(out, "\tSET");
    } else {
      if (gUncertainFlag[ai] == FALSE) {
        fprintf(out, "\tNUM");
      } else {
        fprintf(out, "\tUNCERTAIN");
      }
    }
    /* Write out the num cuts */
    fprintf(out, "\t%d", gCutVector[ai]);

    /* Write out the cutpoints */
    if (gUncertainFlag[ai] == FALSE) {
      for (cut = 1; cut <= gCutVector[ai]; cut++) {
        fprintf(out, "\t%f", gCutMatrix[ai][cut]);
      }
    } else {
      for (cut = 1; cut <= gCutVector[ai]; cut++) {
        fprintf(out, "\t%f [ %f , %f ]", 
                gCutMatrix[ai][cut], 
                gUncertainLow[ai][cut],
                gUncertainHigh[ai][cut]);
			}
    }
    fprintf(out, "\n");

  } /* end for i #1 */

  fprintf(out, "ENDATA\n\n");

  /* Second section of cut file: write literals and rules */

  fprintf(out,"LITERALS AND RULES\n");

  ai = 0;

  for (i = 1; i <= gBeforeDel; i++) { /* begin for i #2 */
		
    /* If deleted write DELETE and continue */
    if (gDeleteVector[i]) {
      fprintf(out, " %s\tDELETE\n", gAttributeDel[i]);
      continue;
    }

    ai++;

    
    for (cut=1; cut<=gCutVector[ai]+1; cut++) { /* begin for cut */

      if ((cut==gCutVector[ai]+1)&&(gSet[ai]==FALSE)) {
        break;
      }

      for (sig=1; sig<=2; sig++) { /* begin for sig */
        /* sig = 1: positive literal */
        /* sig = 2: negative literal */

        if (sig == 1) {
          /* Write positive literal for this cut */
          fprintf(out," %s_%d\t", gAttribute[ai],cut);
        } else {
          /* Write negative literal for this cut */
          fprintf(out,"-%s_%d\t", gAttribute[ai],cut);
        }

        if (gSet[ai]) { /* if type == SET */
      /* SET:                                 */
      /*  var_1  | var_2  | ...  | var_nCut+1 */

     
          if (cut==1) {
            if (sig == 1) {
              fprintf(out,"( %s < %f )\n",
                      gAttribute[ai],gUncertainLow[ai][cut]);
            } else {
              fprintf(out,"( %s > %f )\n",
                    gAttribute[ai],gUncertainHigh[ai][cut]); 
            } 
          } else if (cut > 1 && cut <= gCutVector[ai] ) {
            if (sig == 1) {
              fprintf(out,"( %s > %f && %s < %f )\n",
                      gAttribute[ai],gUncertainHigh[ai][cut-1],
                      gAttribute[ai],gUncertainLow[ai][cut]);
            } else {
	      fprintf(out,"( %s < %f || %s > %f )\n",
                      gAttribute[ai],gUncertainLow[ai][cut-1],
                      gAttribute[ai],gUncertainHigh[ai][cut]);
            }
          } else { /* cut = gCutVector[ai]+1 */
            if (sig == 1) {
              fprintf(out,"( %s > %f )\n",
                      gAttribute[ai],gUncertainHigh[ai][cut-1]);
            } else {
              fprintf(out,"( %s < %f )\n",
                    gAttribute[ai],gUncertainLow[ai][cut-1]);
            }
          }
        } else { /* end if type==SET, begin if type==NUM/UNCERTAIN */
      /* NUM or UNCERTAIN                     */
      /*       |        | ...         |       */
      /*     var_1    var_2         var_nCut  */
	  if (sig==1) {
            fprintf(out,"( %s > %f )\n",
                    gAttribute[ai],gUncertainHigh[ai][cut]);
          } else {
            fprintf(out,"( %s < %f )\n",
                    gAttribute[ai],gUncertainLow[ai][cut]);
          }                
        } /* end of if type */

      } /* end for sig */

    } /* end for cut */ 
    
  } /* end for i #2 */

  fprintf(out, "ENDATA\n\n");

  /* Third section of cut file: write scaling factors */

  fprintf(out,"SCALING FACTORS\n");

  ai = 0;

  for (i = 1; i <= gBeforeDel; i++) { /* begin for i #3 */
		
    /* If deleted write DELETE and continue */
    if (gDeleteVector[i]) {
      fprintf(out, "%s\tDELETE\n", gAttributeDel[i]);
      continue;
    }

    ai++;

    fprintf(out,"%s\t",gAttribute[ai]);

    /* If SET option, write SET and continue */
    if (gSet[ai]==TRUE) {
      fprintf(out, "SET\n");
      continue;
    }

    if (gCutVector[ai] > 0) {
      fac = 0;
      for (cut=1; cut<=gCutVector[ai]; cut++) { /* begin for cut */
        if (gUncertainFlag[ai] == FALSE) {
          if (fac < gAboveValue[ai][cut]-gBelowValue[ai][cut]) {
            fac = gAboveValue[ai][cut]-gBelowValue[ai][cut];
          }
        } else {
          if (fac < gUncertainHigh[ai][cut]-gUncertainLow[ai][cut]) {
            fac = gUncertainHigh[ai][cut]-gUncertainLow[ai][cut];
	  }
	}	
      } /* end for cut */

      if (fac == 0) {
        printf("Unexpected factor = 0.0\n");
        fprintf(errfil,"Unexpected factor = 0.0\n");
        cuterror("writeCutFile","501");
      }

      fprintf(out,"%f\n",fac);
    } else {
      /* attribute has no cutpoints */
      fprintf(out,"NOCUTPOINT\n");
    }
    
  } /* end for i #3 */


  fprintf(out, "ENDATA");

  fclose(out);
	
}
/*eject*/
/******************************************************************************/
void writePartialLogic()
{
	FILE* out;
	int ai, flg;    
	
	out = openFilePrefix(gFileExt.ptl, "w");

	/* Write out the number of cuts per attribute */
	for (ai = 1; ai <= gNumAttributes; ai++)
	{
		fprintf(out, "*Attribute %s ", gAttribute[ai]);
		fprintf(out, "%d cut(s): ", gCutVector[ai]);
		printCutPoints(out, ai);
	}
	fprintf(out, "\n");

	fprintf(out, "MINIMIZE\n");
	fprintf(out, "partial_log_file\n\n");

	fprintf(out, "SETS\n");
	fprintf(out, "define cases\n");
	fprintf(out, "pos\n");
	fprintf(out, "neg\n\n");

	fprintf(out, "PREDICATES\n");
        flg = 0;
	for (ai=1; ai <= gNumAttributes; ai++)
	{
		
	  if (printVar(out, ai) == 1) {
            flg = 1;
          }

	}
        if (flg == 0) {
          errorflag++;
	  if (gShowSteps) {
            printf("Error Number: %d\n",errorflag);
            printf("All attributes have 0 cutpoints\n");
	  }
          fprintf(errfil,"Error Number: %d\n",errorflag);
          fprintf(errfil,"All attributes have 0 cutpoints\n");
        }

	fprintf(out,"include %s%s\n",gParams.prefix,gFileExt.prd);
		
	fprintf(out, "\n");

	fprintf(out, "VARIABLES\n");
	fprintf(out, "dummy_variable\n");
	fprintf(out, "AFORMULA\n");
	fprintf(out, "BFORMULA\n\n");

	fprintf(out, "FACTS\n");
	fprintf(out, "dummy_variable.\n");

	fprintf(out, "ENDATA\n");

	fclose(out);	
	
}

/*eject*/
/***************************************************************/
void printCutPoints(FILE *out, int ai)
{
	int i;

	for(i = 1; i <= gCutVector[ai]; i++) {
	  if (i%4 == 0) {
			fprintf(out, "\n*          ");
	  }	
	  fprintf(out, "%.3f  ", gCutMatrix[ai][i]);
	  if (gUncertainFlag[ai] == TRUE) {
	    fprintf(out,"[%.3f , %.3f ]  ",
		    gUncertainLow[ai][i],
		    gUncertainHigh[ai][i]);
	  }
	}
	fprintf(out, "\n");
}

/*eject*/
/****************************************************************/
int printVar(FILE *out, int ai)
{
  int i, flg = 0;
  int numVar;
	
  numVar = gCutVector[ai] + 1;

  /* Write out variables from compact notation */
  if (gSet[ai] == FALSE) numVar--;

  for (i=1; i<= numVar; i++) {
    flg = 1;
    fprintf(out, 
      "define %s_%d on cases\n", gAttribute[ai], i);
    fprintf(out, 
      "  %s_%d(pos) truecost = %d\n", gAttribute[ai], i, 100-i);
    fprintf(out, 
      "  %s_%d(neg) truecost = %d\n", gAttribute[ai], i, 100+i);
  }
  return flg;
}

/* last record of writeFiles.c *******/
