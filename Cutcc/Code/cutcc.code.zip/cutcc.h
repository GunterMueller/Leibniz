/* first record of cutcc.h *****/
#ifndef CUTCC_H
#define CUTCC_H

/******************* Includes ***********************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <math.h>
#include <time.h>

/******************* Input Maximums ****************************/
#define MAX_SIGMA 20
#define MAX_BETA 50	  /* Should be > 2 times MAX_SIGMA */
#define MAX_ATTRIBUTE 600 /* 300 */
#define MAXLEN 5000	  /* length of buffer for file line */ 
#define MAX_RECORD 4000
#define MAX_ID 256
#define MAX_DIRECTORY 256
#define MAX_CUTS 20


/******************* Test File Record Types ********************/
#define A 1
#define B 2
#define TEST 3
#define ATTRIBUTE 3
#define NUM_CUTS 4
#define DELETE 5
#define CUT_VALUE 6
#define TRUECOST 7
#define SET 8

/******************* Misc. Constant Labels *********************/
#define POS 1
#define NEG 2
#define TOTAL 1
#define PARTIAL 2
#define UNAVAILABLE 1
#define UNA_OR_ABS 9
#define ABSENT 2
#define EFFECTIVE 1
#define PERFECT 2
#define NONE_FOUND -1
#define FALSE 0
#define TRUE 1
#define INFTY 999999999.0
#define NEGINFINITY -999999999.0
#define EPSILON 0.0000005

/******************* Output Types *****************************/
#define TABLE 1			//write outfile to internal table
#define TRNFILE 2		//write output file to actual training file
#define TSTFILE 3		//write output file to actual testing file 

/******************* Modes ************************************/
#define TRAINING 1		// finding the cutpoints and converting training data
#define TESTING 2		// converting the testing data

/******************* Run Types *******************************/
/*** If no parameter is given then
     the cutpoint algorithm is run (default) *****/

#define CUTPOINT 0
#define ENTROPY 1
#define ENTROPY_MDL 2

/************************************************************/
/* Random number generator **********************************/

#define  INITIAL_SEED      17
#define  MULTIPLIER        25173
#define  INCREMENT         13849
#define  MODULUS           32767    /*65536*/
#define  FLOATING_MODULUS  65536.0

/*eject*/
unsigned gSeed; 
/******************* Custom Data Types **********************/
struct {
	int AB_flag;
	int lvalues[MAX_ATTRIBUTE][MAX_CUTS+1];
	float zValue[MAX_ATTRIBUTE];  // only critical if z_i != z_j
} typedef LogicRec;

struct { 
	float rat;    		// rational value
	int code; 		// code Unavailable or Absent
} typedef Value;

struct {
		int AB_flag;
		Value value[MAX_ATTRIBUTE];  
} typedef Record;

struct {
		int AB_flag;
		Value value;  
} typedef Record_1d;

struct {
  int relevanceCount[MAX_ATTRIBUTE][MAX_CUTS+1];
  int nested[MAX_RECORD];
  int criticalFlag[MAX_ATTRIBUTE][MAX_CUTS+1];
} typedef NestedData;

/* Holds the attribute that will be modified */
struct {
  int ai;				//attribute index
  int variable;
  float cutLocation;
  float attractiveness;
  int cutSigma;
  float uncertainLow;
  float uncertainHigh;
  float belowValue;
  float aboveValue;
  float usefulness;
  float separationCriterion;
} typedef AttributeModify;

struct {
  char prefix[MAX_ID];
  char directory[MAX_DIRECTORY];
  int doTraining;
  int doTrainNew;
  int doTrainOld;
  int minCuts;
  int maxCuts;
  int totalOrpartial;
  int unavailableOrAbsent;
  int effectiveOrperfect;
  int doTesting;
} typedef CutccParams;

/* File extensions */
struct {
	char rtr[32];
	char rts[32];
	char cut[32];
	char trn[32];
	char tst[32];
	char ptl[32];
	char vis[32];
        char prd[32];
} typedef FileExtensions;

/*eject*/
/******************* Global Variables ***********************/

/* lsqccparams file name */
char lsqccparamsname[MAX_ID];

/* Holds the number of attributes before and after deletion */
int gNumAttributes;

int gBeforeDel; 
int gCutVector[MAX_ATTRIBUTE+1];
int gDeleteVector[MAX_ATTRIBUTE+1];
int gNumDistinctValues[MAX_ATTRIBUTE+1];
int gSet[MAX_ATTRIBUTE+1];
char gAttribute[MAX_ATTRIBUTE+1][MAX_ID];
char gAttributeDel[MAX_ATTRIBUTE+1][MAX_ID];  // holds deleted attribute names
int gShowSteps;

/* Holds the input records */
Record gDataRecords[MAX_RECORD+1];

/* Holds record number line number correspondance */
int gTrainingLine[MAX_RECORD+1];
int gTestingLine[MAX_RECORD+1];

/* Number of A and B records */
int gAcount;				
int gBcount;

/* current and previous counts for nested cases */
int currentCount;
int previousCount;		

/* Cut values */
float gCutMatrix[MAX_ATTRIBUTE+1][MAX_CUTS+1];

/* Min cuts */
int gMinCuts[MAX_ATTRIBUTE+1];

/* Max cuts */
int gMaxCuts[MAX_ATTRIBUTE+1];

/* Uncertainty information */
int   gUncertainFlag[MAX_ATTRIBUTE+1];
float gUncertainLow[MAX_ATTRIBUTE+1][MAX_CUTS+1];
float gUncertainHigh[MAX_ATTRIBUTE+1][MAX_CUTS+1];
float gBelowValue[MAX_ATTRIBUTE+1][MAX_CUTS+1];
float gAboveValue[MAX_ATTRIBUTE+1][MAX_CUTS+1];						
/* Structure to hold input file */
CutccParams gParams;   

/* Table to hold the records in logic form */
LogicRec gLogicOut[MAX_RECORD+1];

/* Number of testing variables */
int gTestRecCount;   

/* Error file */
FILE* errfil;

/* error flag for unsuccessful training/testing */
/*  = 0: no errors */
int errorflag;

/* Runtype given as input parameter (nothing or 0 is CUTPOINT) */
int gRunType;  // CUTPOINT 0, ENTROPY 1, or ENTROPY_MDL 2

/* Static allocated memory (was dynamic) */
Record_1d records[MAX_RECORD+1];
float beta[MAX_BETA];
float convolution[MAX_RECORD+1];
float AB[MAX_RECORD+1];
int ABint[MAX_RECORD+1];
float cutValue[MAX_RECORD+1];
int ties[MAX_RECORD+1];
int lvalues[MAX_CUTS+1];


FileExtensions gFileExt;

/*eject*/
/********************************************************/

int  cutcc();
void testingDataProcessing();
void trainingDataProcessing();
void writeTrainResults();
void writeData(int outputType);
void writeExtraTestFile();
void modifyMatchingAvg();
void calcNewTruecost();
void addBestMarker(int ai);
void finalAttributeCheck();
void cutIllustration();

void getBestCutPoint(int ai, int var, float *cutPoint, 
		     int *intervalSize, int *cutSigma, 
		     float *uncertainLow, float *uncertainHigh,
                     float *belowValue, float *aboveValue,
		     float *attractiveness,
		     float *usefulness, float *separationCriterion);
void findUncertainInterval(float *uncertainLow, float *uncertainHigh,
                           float *belowValue, float *aboveValue,
		           int cutIndex, int uncertainDelta, 
			   int recCount, int locSigma);
int recordCompare(const void *rec1, const void *rec2);
int getHighestCutValue(Record_1d rec[], int recCount, float *delta,
		       float beta[], int *n, int locSigma);
int calculateSigma(int recCount);
void removeUnavailable(Record_1d rec[], int *recCount);
void loadAB(Record_1d rec[], float AB[], int recCount);
void averageDuplicates(Record_1d rec[], float AB[], int recCount);
void calculateConvolution(float AB[], float convolution[], int recCount,
			  float beta[], int locSigma);
void getBetaValues(int locSigma, float beta[]);
void calculateCut(float convolution[], float cutValue[], int recCount);
int getBiggestDropoff(int recCount, float cutValue[], int start, 
				float AB[], int locSigma);
int getClosestToMiddle(int tieCount, int ties[], int middle, 
		       int beg, int end);
float getUsefulness(Record_1d rec[], int recCount, int cutIndex);
/************************* entropy ************************/
float getBestEntropy(int ai, int var, float *cutPoint, int *intervalSize);
int getLowestEntropy(float AB[MAX_RECORD], int ABint[MAX_RECORD], 
		     int recCount, float *entropy);
float getEntropy(int currentOne, int ABint[MAX_RECORD], 
		 int recCount, int highLow);
void mdlDiscretize();
void mdlAttribute(int ai);
float mdl(int ai, int var, float cutPoint);
float delta(float S, float S1, float S2, int k, int k1, int k2);
float log2d(double value);
float log2i(int value);

/************************* end entropy *********************/

void readParamsFile();
void shiftLeft(char fileRec[]);
void loadInputRecords(int runType);
void addAttribute(char fileRec[]);
void addRecord(int AB_flag, char fileRec[], 
	       Record records[], int currentLine);
void countDistinctValues();
void loadCutFile();
void readCutLine(char fileRec[], int *ai);
int parse_param(char *lhs, char *rhs, char *record, FILE *params);
void lowerCase(char *ch);

void refineInterval(NestedData* nd);
float attributeSelect(NestedData* nd, AttributeModify* am);
void unableToSeparateTermination(NestedData* nd);
void updateScheme(AttributeModify am);
void addCutPoint(AttributeModify am);

float sigmaFunction(float p, float q, int m, int N);
void getABRatio(float *p, float *q, Record_1d records[], int recCount);
int calculateSigmaNew(int N, Record_1d records[]);

int testSeparation(NestedData *nd);
int separateOneFromOther(int separating, NestedData *nd, int *equalCount);
void accumDuplicates(int i, NestedData *nd, int j, int separating);
int compare(int separating, int i, int j);
void accumDuplicates(int i, NestedData *nd, int j, int separating);
int checkUnavailableAbsent(int ai, int separating, int i, int j);

FILE* openFile(char* name, char* mode);
void varToCutValues(int ai, int var, float *epsilon1, float *epsilon2);
void getMatchingRecords(Record_1d records[], 
			int ai, int var, int *recCount);
int stringCompare(const char *a, const char *b, int n);
void cuterror(char *m1,char *m2);
FILE* openFilePrefix(char* extension, char* mode);
void enddataError(char *suffix);
void memoryError(char *m1, char *m2);

void writeLogic(int outputType, FILE *outrecFile, 
		Record records[], int count);
void writeScheme(int outputType, FILE *outrecFile, Value recValue, 
		 int ai, int AB_flag, int lvalues[], int recIndex);
void writeFileNonSetValues(int ai, int AB_flag, FILE *outrecFile, 
			   Value recValue);
void writeFileSetValues(int ai, int AB_flag, FILE *outrecFile, 
			Value recValue);
void writeTableValues(int ai, int AB_flag, int lvalues[], 
		      Value recValue, int recIndex);
void writeLogicTable (int ai, int AB_flag, int lvalues[], 
		      int recIndex);
void writeCutFile();
void writePartialLogic();
void printCutPoints(FILE *out, int ai);
int printVar(FILE *out, int ai);
void writeLsqccParams();
void writeLogicFile();

void quickSort(Record_1d Array[], int p, int r);
int randPartition(Record_1d Array[], int p, int r);
int lessThan(Record_1d a, Record_1d b);
void exchange(Record_1d *a, Record_1d *b);
unsigned rand2();
void srand2(double k);
 
#endif  

/* last record of cutcc.h *******/
