/* first record of entropyPLUGIN.c *****/
#include "cutcc.h"
/***************************************************************/
/* Returns the gain                                            */
/***************************************************************/
float getBestEntropy(int ai, int var, float *cutPoint, int *intervalSize)
{
		
	/* New declarations */
	float currentEntropy;
	float entropyGain;
	float lowestEntropy;
	int entropyIndex;
	const int HIGH = 2;

	int recCount;  
	int i;
		
	memset(records,0,sizeof(records));
		
	/* get all records that need to be separated for that var and ai */
	getMatchingRecords(records, ai, var, &recCount);

	memset(ABint,0,sizeof(ABint));
	memset(AB,0,sizeof(AB));

	/* Sort the records */
	quickSort(records, 0, (recCount-1));

	/* Load the table with 1 for A, 0 for B */
	loadAB(records, AB, recCount);

	/* Make the AB value for duplicates the average of those
	 * with that value . */
	for (i=0;i<recCount;i++) ABint[i] = (int) AB[i];
	averageDuplicates(records, AB, recCount);

	/* Calculate the current entropy */
	currentEntropy = getEntropy(0, ABint, recCount, HIGH);

	entropyIndex = getLowestEntropy(AB, ABint, recCount, &lowestEntropy);

	/* If no suitable index found, return gain of 0 so this attribute not picked */
	if (entropyIndex == recCount+1) {
		*cutPoint = NEGINFINITY;
		return 0;
	}

	/* Get the cut value */
	*cutPoint = (records[entropyIndex].value.rat + records[entropyIndex-1].value.rat) / (float) 2;

	/* Calculate entropy gain */
	entropyGain = currentEntropy - lowestEntropy;
	if (entropyGain < 0) entropyGain = 0;

	return entropyGain;

}
/***************************************************************/
/* The current one for entropy is included in the upper side   */
/***************************************************************/
int getLowestEntropy(float AB[], int ABint[], 
					 int recCount, float *entropy)
{
	int ties[25];
	int tieIndex = 0; /* =0 to remove warning, lowEntropy is checked */
	int middle;
	float highEntropy = -1, lowEntropy = -1;
	float currentLowest = 1;
	float lowPortion, highPortion;
	int i;
	const int LOW = 1;
	const int HIGH = 2;

	*entropy  = 1;

	for (i=1;i<recCount;i++)
	{
		if (AB[i] == AB[i-1]) continue;

		lowEntropy = getEntropy(i, ABint, recCount, LOW);

		highEntropy = getEntropy(i, ABint, recCount, HIGH);

		lowPortion = (float) i / (float) recCount;
		highPortion = (float) (recCount-i) / (float) recCount;
		*entropy = (lowPortion * lowEntropy) + (highPortion * highEntropy);

		if (*entropy <= currentLowest)
		{
			if (*entropy < currentLowest)
			{
				tieIndex = 0;
				currentLowest = *entropy;
				memset(ties, 0, sizeof(ties));  // clear out ties
			}

			ties[tieIndex] = i;
			tieIndex++;
		}
	}

	if (lowEntropy == -1) //All of same type
	{
		*entropy = 1;
		return recCount + 1; // to 0
	}

	*entropy = currentLowest;


	/* Of the ties pick the one closest to the middle */
	middle = (int) ((recCount-1)/2);
	
	return getClosestToMiddle(tieIndex, ties, middle, 0, recCount-1);
}

/***************************************************************/
float getEntropy(int currentOne, int ABint[], int recCount, int highLow)
{
	int begin, end;
	int aCount = 0, bCount = 0;
	float aPortion, bPortion;
	int i;
	float logAportion, logBportion;
	const int LOW = 1;

	if (highLow == LOW) {
		begin = 0;
		end = currentOne;
	} else {
		begin = currentOne;
		end = recCount;
	}

	for (i=begin; i < end; i++)
	{
		if (ABint[i] == A) aCount++;
		else bCount++;
	}

	if ((aCount + bCount) <= 0)
		cuterror("getEntropy","100");
		
	aPortion = (float) aCount / (float) (aCount+bCount);
	bPortion = (float) bCount / (float) (aCount+bCount);

	if (aPortion > 0) logAportion = (float) (log(aPortion)/log(2));
	else logAportion = 0;

	if (bPortion > 0) logBportion = (float) (log(bPortion)/log(2));
	else logBportion = 0;


	return (float)  ( ((-1*aPortion) * logAportion) - (bPortion * logBportion) );
}
/***************************************************************/
void mdlDiscretize()
{

	int ai;


	for (ai = 1; ai <= gNumAttributes; ai++)
	{
		if (gSet[ai] == TRUE) continue;

		mdlAttribute(ai);
	}

}
/***************************************************************/
void mdlAttribute(int ai)
{
	AttributeModify am;
	float cutPoint = 0;
	int DUMMY = 0;
	int var;
	float gain;

	var = 1;

	/* Get the first entropy marker value */
	gain = getBestEntropy(ai, 1, &cutPoint, &DUMMY);
	if (gain == 0) {
		printf("No good marker found for index %d.\n", ai);
		fprintf(errfil, "No good marker found for index %d.\n", ai);
		cuterror("mdlAttribute","100");
	}
	
	am.ai = ai;
	am.variable = var;
	am.cutLocation = cutPoint;
	am.attractiveness = gain;
	am.cutSigma = 0;
	updateScheme(am);

	/* Continue to refine per minimum description length principle */
	while (var <= gCutVector[ai] + 1)
	{
		gain = getBestEntropy(ai, var, &cutPoint, &DUMMY);
		if (gain <= 0) { var++; continue; }
		if (gain >= mdl(ai,var, cutPoint)) {  
			am.ai = ai;
			am.variable = var;
			am.cutLocation = cutPoint;
			am.attractiveness = gain;
			am.cutSigma = 0;
			updateScheme(am);
			var = 1;
		} 
		else
			var++;
	}

	
}
/***************************************************************/
float mdl(int ai, int var, float cutPoint)
{
	/* New declarations */
	float S1, S2, S;
	int S_A = FALSE, S_B = FALSE, S1_A = FALSE, S1_B = FALSE, 
		S2_A = FALSE, S2_B = FALSE;
	int k = 0, k1 = 0 , k2 = 0;
	int cutIndex;
	float mdlValue;
	
	const int LOW = 1;
	const int HIGH = 2;
	
	int recCount;  
	int i;

	/* initialize cutIndex to supress compiler warning*/
        cutIndex = 0;
	
	memset(records,0,sizeof(records));
			
	/* get all records that need to be separated for that var and ai */
	getMatchingRecords(records, ai, var, &recCount);

	memset(AB,0,sizeof(AB));
	memset(ABint,0,sizeof(AB));

	/* Sort the records */
	quickSort(records, 0, (recCount-1));

	/* Load the table with 1 for A, 0 for B */
	loadAB(records, AB, recCount);

	/* Copy to intAB b/c of way functions already written */
	for (i=0;i<recCount;i++) ABint[i] = (int) AB[i];
	
	/* Get the cut index */
	for (i = 1;i<recCount;i++) {
		if (records[i-1].value.rat <= cutPoint &&
			records[i].value.rat >= cutPoint) {
			cutIndex = i;
			break;
		}
	}

	/* Calculate the current entropy */
	S1 = getEntropy(cutIndex, ABint, recCount, LOW);
	S2 = getEntropy(cutIndex, ABint, recCount, HIGH);
	S = getEntropy(0, ABint, recCount, HIGH); 

	/* Determine the number of class labels */
	for (i = 0; i< recCount; i++)
	{
		if (records[i].AB_flag == A) S_A = TRUE;
		else S_B = TRUE;

		if (i < cutIndex) {
			if (records[i].AB_flag == A) S1_A = TRUE;
			else S1_B = TRUE;
		}
		else {
			if (records[i].AB_flag == A) S2_A = TRUE;
  			else S2_B = TRUE;
		}
	}

	k = S_A + S_B;
	if (k < 2) {printf("ERROR why only one label?\n"); exit(1);}
	k1 = S1_A + S1_B;
	k2 = S2_A + S2_B;


	/* Assuming all input correct, this mdlValue has been confirmed
	   using Excel */
	mdlValue = (float) ( log2i(recCount-1) + delta(S, S1, S2, k, k1, k2) ) 
				/ (float) recCount;
	

	return mdlValue;

}
/***************************************************************/
float delta(float S, float S1, float S2, int k, int k1, int k2)
{
	float returnValue;

	returnValue = log2d(pow(3,k) - 2) - (k*S - k1*S1 - k2*S2);

	return returnValue;
}
/***************************************************************/
float log2d(double value)
{
	return (float) log(value) / (float) log(2);
}	
/***************************************************************/
float log2i(int value)
{
	return (float) log(value) / (float) log(2);
}	
/* last record of entropy.c *******/
