/* first record of sigmaSelection.c *****/
#include "cutcc.h"
/******************************************************************************/
int calculateSigmaNew(int N, Record_1d records[])
{
	float p,q;
	int m = 1;
	int upperBound;
	float previousValue = 1;
	float currentValue = 1;
	int limsigmaA, limsigmaB;
	int limsigma; /* March 13, 2007: tail analysis */
        double sig;   /* March 13, 2007: tail analysis */

	getABRatio(&p, &q, records, N);

	upperBound = (int) floor((float)N/(float)4);
 
	while(m < upperBound) 
	{
		currentValue = sigmaFunction(p,q,m,N);

		if (currentValue <= 1)
			break;

		previousValue = currentValue;

		m++;
	}

	if (fabs(currentValue - 1) > fabs(previousValue - 1))
		m = m - 1;
	
	// If greater than max sigma just make it equal to max sigma
	if (m > MAX_SIGMA) {
		m = MAX_SIGMA;
	}

	/* limit sigma to minimum of |A|/4, |B|/4 */	
        limsigmaA = ceil((float)N * p/4.0);
        limsigmaB = ceil((float)N * q/4.0);
        if (m > limsigmaA) {
          m = limsigmaA;
        }
        if (m > limsigmaB) {
          m = limsigmaB;
        }

	/* March 13, 2007: tail analysis:
	 * limit sigma to sqrt(N*p*q) so that sequences
	 * of 2*sqrt(N*p*q) As or Bs are detected at the endpoints
	 * of the label sequence
	 */
	sig = (double)N * (double)p * (double)q;
		sig = sqrt(sig) + 0.5;
		limsigma = (int)sig;
	if (limsigma < m) {
		  m = limsigma;
		}

        if (m <= 0) {
          m = 1; /* m must be at least 1 */
        }

	return m;
}
/******************************************************************************/
void getABRatio(float *p, float *q, Record_1d records[], int recCount)
{
	int i;
	int locA = 0, locB = 0;

	for (i=0; i < recCount; i++)
	{
		if (records[i].AB_flag == A)
			locA++;
		else
			locB++;
	}

	*p = (float) locA / (float) recCount;
	*q = (float) locB / (float) recCount;
}
/******************************************************************************/
float sigmaFunction(float p, float q, int m, int N)
{

	return (float) ((N - 2*m)*p*q*(pow(p,m-1)+pow(q,m-1)-pow(p*q,m-1)));

}

/* last record of sigmaSelection.c *******/
