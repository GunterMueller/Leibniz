/* first record of cutcc.c *****/
/*
 *  Leibniz System: Cutcc System
 *  Copyright 1990-2015 by Leibniz Company
 *  Plano, Texas, U.S.A.
 *  This program is free software: you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free Software
 *  Foundation, either version 3 of the License, or (at your option) any later
 *  version. The file lgpl.txt has the License statement.
 *
 * ===================================================
 * Cutcc System - Callable Learning Version cutcc
 * ===================================================
 *
 *  caution: 
 *   - parameters must have been obtained 
 *     (see readParamsFile() for required information)
 *   - errfil must have been opened (see cutccmain() program)
 *   - errfil must be closed after execution of cutcc
 *  caution: these conditions are not checked by the program 
 * -----------------------------------------------------------
 */
#include "cutcc.h"
/******************************************************************************/	
int cutcc()
{
        /* initialize errorflag */
        errorflag = 0;
    
	/* Seed the random number generator for quicksort */
	srand2(INITIAL_SEED);

	/* Calculate the cut points using training records */
	if (gParams.doTraining == TRUE)
		trainingDataProcessing();
	
	/* Convert testing records to log using cut points */
	if (gParams.doTesting == TRUE)
		testingDataProcessing();

        return errorflag;	
	
}

/*eject*/
/***********************************************************/	
void testingDataProcessing()
{
	/* Clear out these values (may be populated from training) */
	memset(gCutMatrix,0,sizeof(gCutMatrix));
	memset(gDataRecords,0,sizeof(gDataRecords));
	gNumAttributes = 0;
	gBeforeDel = 0;
	
	/* Load the cut file information */
	loadCutFile();
	
	/* Read the testing file */
	loadInputRecords(TESTING);
	
	/* Write the output file */
	writeData(TSTFILE); 

	/* if training not done, write partial data file */
	if (gParams.doTraining != TRUE) {
		writePartialLogic();
	}

	if (gShowSteps) {
          printf("\n***\n");
          printf("Testing file successfully transformed ");
          printf("to logic data\n");
          printf("Output in file %s%s\n",
                 gParams.prefix,gFileExt.tst); 
          printf("***\n\n");
	}
	fprintf(errfil,"\n***\n");
	fprintf(errfil,"Testing file successfully transformed ");
	fprintf(errfil,"to logic data\n");
	fprintf(errfil,"Output in file %s%s\n",
                gParams.prefix,gFileExt.tst); 
	fprintf(errfil,"***\n\n");

}

/*eject*/
/*********************************************************/	
void trainingDataProcessing() {

  /* 
   * Structure to hold the nestedness information 
   */
  NestedData nd;

  int saveAtt, saveBef;

  /*
   * Initialize the nested data 
   */
  memset(&nd,0,sizeof(nd));
  currentCount = -1;
  previousCount = 0;
  gNumAttributes = 0;
  gBeforeDel = 0;

  /* 
   * Read the training file 
   */
  loadInputRecords(TRAINING);

  /* 
   * Training using new .cut file 
   */
  if (gParams.doTrainNew == TRUE) { /* begin train with new */
                                    /* .cut file            */
    /*
     * Initialize the logic 
     */
    writeData(TABLE);

    /*
     * Get the values using the minimum description length 
     * principle 
     */
    if (gRunType == ENTROPY_MDL) {
      mdlDiscretize();
    } else {
    /* 
     * Continue to refine logic encoding until all of the A
     * and B records are separated by logic values 
     */
      while (testSeparation(&nd) == FALSE) {

        /* 
         * if degree of separation = effective and 
         *    no progress has been made, 
         * then terminate refinement process
         */
        if ((gParams.effectiveOrperfect == EFFECTIVE) &&
            (previousCount == currentCount)) {
          break;
        }

        /*
         * Add a marker to the critical interval 
         */
        refineInterval(&nd);

       /*
        * Update the internal table to reflect the new marker 
        */
        writeData(TABLE);

      }
    }

    /* Have attained separation, or have terminated refinement
     * process. Add markers to attributes so that
     * each has minimum number of required markers 
     */
    finalAttributeCheck();

  } else if (gParams.doTrainOld == TRUE) { /* begin train with old */
                                           /* .cut file            */
    /* save number of used attributes and number of attributes
     * before deletion as derived from training file .rtr; 
     * these values must be compatible with those of .cut file
     * this is checked after loading cutfile
     */
    saveAtt = gNumAttributes;
    gNumAttributes = 0;
    saveBef = gBeforeDel;
    gBeforeDel = 0;

    /* Load the cut file information */
    loadCutFile();

    /* check compatibility of .rtr file with .cut file */
    if (saveAtt != gNumAttributes || saveBef != gBeforeDel) {
      printf("Files .rtr and .cut are not compatible\n");
      printf("Must train with 'new' option\n");
      fprintf(errfil,"Files .rtr and .cut are not compatible\n");
      fprintf(errfil,"Must train with 'new' option\n");
      cuterror("trainingDataProcessing","201");
    }
   
  } else { /* must be one of the two options above */
    cuterror("trainingDataProcessing","301");
  }

  /*
   * write out all output files resulting from training:
   * .trn, .ptl, .cut if applicable, and .vis
   */
  writeTrainResults();

}

/*eject*/
/****************************************************/	
void cutIllustration()
{
	int recCount, ai, var, i;
	FILE *visual;
	int count;

	visual = openFilePrefix(gFileExt.vis, "w");

	memset(records,0,sizeof(records));
	
	/* Loop through the attributes */
	for (ai = 1; ai <= gNumAttributes; ai++)
	{

		fprintf(visual, "\n******************************************************\n");
		fprintf(visual, "Attribute: %s", gAttribute[ai]);
		fprintf(visual, "\n******************************************************\n");

		count = 1;

		/* Loop through the variables for that attribute */
		for (var = 1; var <= gCutVector[ai]+1; var++)
		{
			/* get all records that need to be separated for that var and ai */
			getMatchingRecords(records, ai, var, &recCount);

			/* Sort the records */
			quickSort(records, 0, (recCount-1));

			/* print all values */
			for (i=0; i < recCount; i++)
			{
				fprintf(visual, "%4d)\t%c\t%f", count++, (records[i].AB_flag==A)?'A':'B', 
					records[i].value.rat);
				if (gUncertainFlag[ai] == TRUE) {
				  if (((var <= gCutVector[ai]) &&
				       (records[i].value.rat >= gUncertainLow[ai][var])) ||
				      ((var >= 2) &&
				       (records[i].value.rat <= gUncertainHigh[ai][var-1]))) {
				    fprintf(visual,"     U");
				  }
				}
				fprintf(visual,"\n");
			}

			/* If not last cutpoint, print marker line */
			if (var < gCutVector[ai]+1)
				fprintf(visual,"--------------------------------------------------\n");

		}

	}

	fprintf(visual, "ENDATA\n");

	fclose(visual);


}

/* last record of cutcc.c *******/


