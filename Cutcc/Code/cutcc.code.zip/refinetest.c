/* first record of refinement.c *****/
#include "cutcc.h"
/******************************************************************************/
void refineInterval(NestedData* nd)
{
	float heuristicval;
	AttributeModify am;
	
	heuristicval = attributeSelect(nd, &am);

	/* Print out message */
	if (gShowSteps) {
	  printf("Variable =  %s_%d\nPotential = %.1f\n",
		 gAttribute[am.ai],am.variable,heuristicval);
	}
	fprintf(errfil,"Variable =  %s_%d\nPotential = %.1f\n",
		 gAttribute[am.ai],am.variable,heuristicval);

	/* Increment the scheme and add the new cut value */
	updateScheme(am);
	
}
/*****************************************************************************
*  Want to find the best attribute, variable, and location combination that
*  will best help in separation.
******************************************************************************/
float attributeSelect(NestedData* nd, AttributeModify* am)
{
	
	float max = 0;
	float separationHeuristic = 0;
	int varCount;
	float cutLocation = 0;
	float attractiveness;
	int cutSigma;
	float uncertainLow;
	float uncertainHigh;
	float belowValue;
	float aboveValue;
	float usefulness;
	float separationCriterion;
	int ai;
	int var;
	int intervalSize = 0;
	int maxRec = 0;
	static int iteration;

	iteration++;

	/* Find the ai and variable combination that will
	 * give the greatest separation. */
	for (ai = 1; ai <= gNumAttributes; ai++)
	{
		varCount = gCutVector[ai]+1;

		/* If already have max cuts for an attribute, continue */
		if (gCutVector[ai] == gMaxCuts[ai]) continue;

		/* Skip if we are doing special set processing */
		if (gSet[ai] == TRUE) continue;

		/* Look at all the variables for an attribute */
		for (var = 1; var <= varCount; var++)
		{

			/* Process if are duplicates for the attribute */
			if (nd->relevanceCount[ai][var] > 0)
			{
								
				/* make sure the interval is critical */
				if (nd->criticalFlag[ai][var] != TRUE) continue;

				/* Calculate the heuristic for the best cut
				 * point for the variable/attribute combination. */

				if (gRunType == ENTROPY) {
				  attractiveness = getBestEntropy(ai, var, &cutLocation, &intervalSize);
				  separationHeuristic = nd->relevanceCount[ai][var] * attractiveness;
				  cutSigma = 0;
				  uncertainLow = 0;
				  uncertainHigh = 0;
				  belowValue = 0;
				  aboveValue = 0;
				  usefulness = 0;
				} else {
				    getBestCutPoint(ai, var, &cutLocation, 
						    &intervalSize, &cutSigma,
						    &uncertainLow, &uncertainHigh,
						    &belowValue, &aboveValue,
						    &attractiveness,
						    &usefulness, &separationCriterion);
				  /* old criterion was based on attractiveness */
				  /* separationHeuristic = nd->relevanceCount[ai][var] * 
				     attractiveness; */
				  separationHeuristic = nd->relevanceCount[ai][var] *
				    separationCriterion;
				}
				if (separationHeuristic < 0){
					fprintf(errfil, "Fatal error in attributeSelect\n");
					printf("Fatal error in attributeSelect\n");
					cuterror("attributeSelect", "100");
				}

				/* Add it to the list, will grab max with biggest interval */
				if (separationHeuristic >= max) {
					if (separationHeuristic > max || intervalSize > maxRec) {
						am->ai = ai;
						am->variable = var;
						am->cutLocation = cutLocation;
						am->attractiveness = attractiveness;
						am->cutSigma = cutSigma;
						/* caution: the next two values are used later */
						/*          only if gUncertainFlag[ai] = TRUE */
						am->uncertainLow = uncertainLow; 
						am->uncertainHigh = uncertainHigh;
						am->belowValue = belowValue; 
						am->aboveValue = aboveValue;
						am->usefulness = usefulness;
						am->separationCriterion = separationCriterion;
						max = separationHeuristic;
						maxRec = intervalSize;
        /* code added Aug 09, 2010 for speed up since refinement  */
        /* potential is no longer used for selection of attributes */
        if ((gParams.maxCuts == 1) || 
            (gNumDistinctValues[ai] == 2)) {
          /* exactly one cut will be selected for attribute ai */
          /* stop search for best cut */
          goto zz100;
        }
					}
				}

			} // end for relevanceCount
			
		} // end for var

	} // end for ai

	zz100:; 

	if (gShowSteps){
		printf("Iteration %d\n", iteration);
	}
	fprintf(errfil,"Iteration %d\n", iteration);

	/* If unable to separate using the number of cuts limit given */
	if (max == 0)
		unableToSeparateTermination(nd);

	return max;
	
}

/*eject*/
/*****************************************************************************/
void unableToSeparateTermination(NestedData* nd)
{
	
	int i; 

	if (gShowSteps) {
	  printf("\nWarning: Cannot separate using max number of cuts %d.\n", gParams.maxCuts);
	}
	fprintf(errfil,"\nWarning: Cannot separate using max number of cuts %d.\n", gParams.maxCuts);
    
	/* Write out the records that still need to be modified */
	if (gShowSteps) {
		printf("Records still nested:\n");
		for (i=1; i<MAX_RECORD; i++)
			if (nd->nested[i] > 0) printf("%d\n", i+1);
	}
	fprintf(errfil,"Records still nested:\n");
		for (i=1; i<MAX_RECORD; i++)
		  if (nd->nested[i] > 0) fprintf(errfil,"%d\n", i+1);

	/* Make sure there is no attribute without a marker */
	finalAttributeCheck();

	/*
	 * write out all output files resulting from training:
	 * .trn, .ptl, .cut if applicable, and .vis
	 */	    
        writeTrainResults();

	/* Convert testing records to logic using cut points */
	if (gParams.doTesting == TRUE)
		testingDataProcessing();

	exit(errorflag);
}
/*****************************************************************************/
void updateScheme(AttributeModify am)
{
	gCutVector[am.ai]++;

	if (gShowSteps) {
	  printf("Attribute = %s\nSigma = %d\n",
		 gAttribute[am.ai],am.cutSigma);
	  printf("Attractiveness = %.2f\n",am.attractiveness);
	  printf("Usefulness = %.2f\n",am.usefulness);
	  printf("Separation criterion = %.2f\n",am.separationCriterion);
	  printf("New cut point = %.3f\n",am.cutLocation);
	  printf("Uncertainty interval (used only if UNCERTAIN specified) = [ %.3f , %.3f ]\n",
		 am.uncertainLow,am.uncertainHigh);
	  printf("Value immediately below cutpoint = %.3f\n",am.belowValue);
	  printf("Value immediately above cutpoint = %.3f\n",am.aboveValue);
          printf("Number of cuts increased from %d to %d\n\n",
		 gCutVector[am.ai]-1, gCutVector[am.ai]);
	}
	fprintf(errfil,"Attribute = %s\nSigma = %d\n",
		gAttribute[am.ai],am.cutSigma);
	fprintf(errfil,"Attractiveness = %.2f\n",am.attractiveness);
	fprintf(errfil,"Usefulness = %.2f\n",am.usefulness);
	fprintf(errfil,"Separation criterion = %.2f\n",am.separationCriterion);
	fprintf(errfil,"New cut point = %.3f\n",am.cutLocation);
	fprintf(errfil,
		"Uncertainty interval (used only if UNCERTAIN specified) = [ %.3f , %.3f ]\n",
		am.uncertainLow,am.uncertainHigh);
	fprintf(errfil,"Value immediately below cutpoint = %.3f\n",am.belowValue);
	fprintf(errfil,"Value immediately above cutpoint = %.3f\n",am.aboveValue);
	fprintf(errfil,"Number of cuts increased from %d to %d\n\n",
		 gCutVector[am.ai]-1, gCutVector[am.ai]);
	addCutPoint(am);
}

/*eject*/
/******************************************************************************
*  Move the current cut values over to make room for the new one.
*******************************************************************************/
void addCutPoint(AttributeModify am)
{
	
	int i;
	
	for(i=gCutVector[am.ai]; i>=am.variable; i--) {
		gCutMatrix[am.ai][i+1] = gCutMatrix[am.ai][i];
		gUncertainLow[am.ai][i+1] = gUncertainLow[am.ai][i];
		gUncertainHigh[am.ai][i+1] = gUncertainHigh[am.ai][i];
		gBelowValue[am.ai][i+1] = gBelowValue[am.ai][i];
		gAboveValue[am.ai][i+1] = gAboveValue[am.ai][i];
	}

	gCutMatrix[am.ai][am.variable] = am.cutLocation;
	if (gUncertainFlag[am.ai] == TRUE)
        {
	  gUncertainLow[am.ai][am.variable] = am.uncertainLow;
	  gUncertainHigh[am.ai][am.variable] = am.uncertainHigh;
	}
	else
	{
	  gUncertainLow[am.ai][am.variable] = am.cutLocation;
	  gUncertainHigh[am.ai][am.variable] = am.cutLocation;
	}

	gBelowValue[am.ai][am.variable] = am.belowValue;
	gAboveValue[am.ai][am.variable] = am.aboveValue;

}
/* last record of refinement.c *******/


