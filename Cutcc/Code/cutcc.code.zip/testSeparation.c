/* first record of testSeparation.c *****/
#include "cutcc.h"
/*************************************************************/
int testSeparation(NestedData *nd)
{
	
  int separated;
  int Aseparated;
  int Bseparated;
  int equalCount = 0;

  /* Clear out nested data */
  memset(nd,0,sizeof(NestedData));
			
  /* Check separation A from B */
  if (gShowSteps) {
    printf("Checking separation of A from B.\n");
  }
  fprintf(errfil,"Checking separation of A from B.\n");

  Aseparated = separateOneFromOther(A, nd, &equalCount);

  if (Aseparated == TRUE) {
    if (gShowSteps) {
      printf("A separated from B.\n");
    }
    fprintf(errfil,"A separated from B.\n");
  }

  /* Check separation B from A */
  if (gShowSteps) {
    printf("Checking separation of B from A.\n");
  }
  fprintf(errfil,"Checking separation of B from A.\n");

  Bseparated = separateOneFromOther(B, nd, &equalCount);

  if (Bseparated == TRUE) {
    if (gShowSteps) {
      printf("B separated from A.\n");
    }
    fprintf(errfil,"B separated from A.\n");
  }

  /* 
   * if either A not separated from B or vice-versa
   * then not separated 
   */
  if (Aseparated == FALSE || Bseparated == FALSE) {
    separated = FALSE;
  } else {
    separated = TRUE;
  }

  /*
   * update current and previous counts of nestedness
   */
  previousCount = currentCount;
  currentCount = equalCount;

  if (separated == FALSE) {
    if (gShowSteps) {
      printf("%d nested record combinations\n", equalCount);
    }
    fprintf(errfil,"%d nested record combinations\n", equalCount);
  }

  return separated;

}
/************************************************************/
int separateOneFromOther(int separating, NestedData *nd, int *equalCount)
{
	int i,j,totalCount;
	int separated = TRUE;
	const int EQUAL = 1;			//record is equal to the next one
    
	
	/* For each record check all other records to see how */
	/* many are nested */
	totalCount = gAcount + gBcount;

	for (i = 0; i < totalCount; i++)
	{
		
		for (j = i+1; j < totalCount; j++)
		{
			
			/* in compare make sure one A and one B     */
			/* also in compare will need to check for k */
			if (compare(separating, i,j) == EQUAL)
			{
				/* with k only want to accum ones different */
				accumDuplicates(i, nd, j, separating); 
				separated = FALSE;
				(*equalCount)++;
				nd->nested[i] = TRUE; nd->nested[j] = TRUE;
			}

		}
	}

	return separated;

}
/*****************************************************************************
*	Accumulate the duplicate vector at the crossover point between pos
*   and neg.  That corresponds to the critical interval.
*   e.g. POS POS NEG NEG, means that the second interval is the 
*   critical interval and it should be accumulated.
******************************************************************************/
void accumDuplicates(int i, NestedData *nd, int j, int separating)
{
	int ai = 0;
	int var = 0;
	
	for (ai = 1; ai <= gNumAttributes; ai++) {

		/* Continue if this one should not be counted; e.g. an A record
		has value UNAVAILABLE and currently separating on A. */
		if (checkUnavailableAbsent(ai, separating,i,j) == TRUE)
			continue;

		for (var = 1; var<= gMaxCuts[ai]+1; var++) {

			/* If on a border point (... POS NEG...) or at the end (... POS) */
			if (gLogicOut[i].lvalues[ai][var+1] != POS || var == gMaxCuts[ai]+1) {

				/* Internally, the representation is still POS
					for the first variable, e.g., POS NEG NEG ... NEG */
				nd->relevanceCount[ai][var] += 1; 

				/* Accumulate the criticalFlag if critical */
				if (gLogicOut[i].zValue[ai] != gLogicOut[j].zValue[ai])
					nd->criticalFlag[ai][var] = TRUE;

				/* Only need accumulate one variable for each ai */
				break;
			}
		}
	}

}
/****************************************************************************
*  Function encodes fairly complex logic to tell when one record is nested
*  within another under UNAVAILABLE or ABSENT.
*****************************************************************************/
int checkUnavailableAbsent(int ai, int separating, int i, int j)
{
	
	if (gParams.unavailableOrAbsent == UNAVAILABLE)
	{
		/* if the set we want to separate from the other 
			 * has an unavailable value for this index then we
			 * don't look at it for separation because the DNF 
			 * clause won't have a value here.  Check both i and
			 * j because either could be "separating".
		*/
		if (gLogicOut[i].lvalues[ai][1] == UNA_OR_ABS &&
			gLogicOut[i].AB_flag == separating)
			return TRUE;
		if (gLogicOut[j].lvalues[ai][1] == UNA_OR_ABS &&
			gLogicOut[j].AB_flag == separating)
			return TRUE;
	}
	else //unavailableOrAbsent == ABSENT
	{
		/* Absent means that if either one is absent then 
		* you don't know so you have to skip this one. */
		if ((gLogicOut[j].lvalues[ai][1] == UNA_OR_ABS) ||
			(gLogicOut[i].lvalues[ai][1] == UNA_OR_ABS))
			return TRUE;
	}

	return FALSE;

}

/*****************************************************************************
*	Compare two records to see if the same
******************************************************************************/
int compare(int separating, int i, int j)
{
	
	int ai; 
	int var_count, l;
	int diffFlag;
	const int EQUAL = 1;			//record is equal to the next one
    const int NOT_EQUAL = 0;		//record not equal to next record


	/* If they are both the same type don't care if equal or not */
	if (gLogicOut[i].AB_flag == gLogicOut[j].AB_flag)
		return NOT_EQUAL;
	
	/* Loop through the indices */
	for (ai = 1; ai <= gNumAttributes; ai++)
	{
		diffFlag = FALSE;
		var_count = gCutVector[ai]+1;
		
		if (checkUnavailableAbsent(ai, separating, i, j) == TRUE)
			continue;

		/* Check and see if any of the variables are different */
		for (l = 1; l <= var_count; l++)
		{
			if (gLogicOut[i].lvalues[ai][l] != 
				gLogicOut[j].lvalues[ai][l])
				return NOT_EQUAL;
		}

	}
 
	/* If the records are not different for any ai, return EQUAL */
	return EQUAL;

}


/* last record of testSeparation.c *******/
