/* first record of util.c *****/
#include "cutcc.h"
/******************************************************************************/
void varToCutValues(int ai, int var, float *cutValue1, float *cutValue2)
{
	
	/* If currently have no markers return pos and neg infinity */
	if (gCutVector[ai] == 0)
	{
		*cutValue1 = NEGINFINITY;
		*cutValue2 = INFTY;
		return;
	}
	
	if (var == 1)
	{
		*cutValue1 = NEGINFINITY;
		*cutValue2 = gCutMatrix[ai][var];
	}
	else if (var == gCutVector[ai]+1)
	{
		*cutValue1 = gCutMatrix[ai][var - 1];
		*cutValue2 = INFTY;
	}
	else
	{
		*cutValue1 = gCutMatrix[ai][var - 1];
		*cutValue2 = gCutMatrix[ai][var];
	}
}
/******************************************************************************/
FILE* openFile(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];

	strcpy(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
		printf("Error opening %s \n for %s. Stop.\n", name, mode);
		exit(1);
	}
	
	return out;
}
/******************************************************************************/
FILE* openFilePrefix(char* extension, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];

	strcpy(file,gParams.directory);
	strcat(file,gParams.prefix);
	strcat(file,extension);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
		printf("Error opening %s \n for %s. Stop.\n", file, mode);
		exit(1);
	}	
	
	return out;
}	
/******************************************************************************
*  Get all of the records that have values that fall into
*  the cuts that correspond to the ai and variable given.
*******************************************************************************/
void getMatchingRecords(Record_1d records[], int ai, int var, int *recCount)
{
	float cutLocation1, cutLocation2;
	int A_flag = FALSE, B_flag = FALSE;
	int i = 0;
	int index = 0;

	*recCount = 0;
	
	varToCutValues(ai, var, &cutLocation1, &cutLocation2);

	while (i<gAcount+gBcount)
	{
		if (gDataRecords[i].value[ai].rat > cutLocation1 &&    //each bucket of form (...] 
			gDataRecords[i].value[ai].rat <= cutLocation2 &&
			gDataRecords[i].value[ai].code == 0)  // Only get non unavailable, abscent
		{
			records[index].value.rat = gDataRecords[i].value[ai].rat;
			records[index].AB_flag = gDataRecords[i].AB_flag;
			
			if (gDataRecords[i].AB_flag == A)
				A_flag = TRUE;
			else
				B_flag = TRUE;
			
			(*recCount)++;

			index++;

		}
		i++;
	}
	
	if (A_flag == FALSE && B_flag == FALSE)
	{
	  if (gShowSteps) {
		printf("\nNote: no records have values falling into interval %d in attribute %s.\n", 
		var, gAttribute[ai]);
	  }
		fprintf(errfil,"\nNote: no records have values falling into interval %d in attribute %s.\n", 
		var, gAttribute[ai]);
	}

}
/******************************************************************************
* First convert to upper case then compare
******************************************************************************/
int stringCompare(const char *a, const char *b, int n)
{
	int i;
	char aPrime[MAX_ID] = {'\0'};

	/* Convert "a" to upper case */
	for (i=0;i<n;i++)
	{

		if (a[i] >=  97 && a[i] <= 122)
			aPrime[i] = a[i] - 32;
		else
			aPrime[i] = a[i];
	}

	return strncmp(aPrime, b, n);

}
/******************************************************************************
* -------------------------------------------------------
*  cuterror(): cutcc system error termination
* ------------------------------------------------------- 
******************************************************************************/
void cuterror(char *m1,char *m2) {
/*
 */

  printf("\n*******CUTCC SYSTEM ERROR*******\n");
  printf("ERROR IN %s  code %s\n",m1,m2);
  printf("**********************************\n");
  printf("For details, see error file cutcc.err\n");
/*
 */
  fprintf(errfil,"\n*******CUTCC SYSTEM ERROR*******\n");
  fprintf(errfil,"ERROR IN %s  code %s\n",m1,m2);
  fprintf(errfil,"**********************************\n");
  exit(1);

}
/*****************************************************************************/
void enddataError(char *suffix)
{
  printf(
    "\nError: No ENDATA statment to terminate %s file.\n", 
     suffix);
  fprintf(errfil, 
    "Error: No ENDATA statment to terminate %s file.\n", suffix);
  exit(1);

}
/*****************************************************************************/
void memoryError(char *m1, char *m2)
{
	printf("\n*******CUTCC SYSTEM ERROR*******\n");
	printf("Unable to allocate memory in %s, program terminated.\n", m1);
	printf("**********************************\n");
	fprintf(errfil,"Unable to allocate memory in %s, program terminated.\n", m1);

	cuterror(m1,m2);
}
/*****************************************************************************/

void quickSort(Record_1d Array[], int p, int r)
{
	int q;

	if (p < r)
	{
		q = randPartition(Array, p, r);
		quickSort(Array, p, q-1);
		quickSort(Array, q+1, r);
	}

}
/*****************************************************************************/
int randPartition(Record_1d Array[], int p, int r)
{
	int M = r - p;
	int rnd;
	int i, j;
	Record_1d x;

	rnd = p + (int) (((double)rand()/(RAND_MAX))*M);

	if(rnd>r||rnd<p)
	{
		printf("Error in rand, invalid rnd %d.\n", rnd);
		exit(1);
	}

	exchange(&Array[r], &Array[rnd]);

	x.value.rat = Array[r].value.rat;
	x.value.code = Array[r].value.code;
	x.AB_flag = Array[r].AB_flag;

	i = p - 1;

	for (j=p;j<=r-1;j++)
	{
		if (lessThan(Array[j], x)==TRUE)
		{
			i++;
			exchange(&Array[i], &Array[j]);
		}
	
	}

	exchange(&Array[i+1], &Array[r]);
	return i+1;

}
/*****************************************************************************/
int lessThan(Record_1d a, Record_1d b)
{
	if (a.value.code > 0) return TRUE;
	if (b.value.code > 0) return FALSE;
	
	if (a.value.rat < b.value.rat) return TRUE;
	if (a.value.rat > b.value.rat) return FALSE;

	/* So value the same */
	if (a.AB_flag == b.AB_flag) return TRUE;

	/* Same value diff AB flag */
	if (a.AB_flag == A) return FALSE;
	else return TRUE;
}
/*****************************************************************************/
void exchange(Record_1d *a, Record_1d *b)
{

	int AB_flag;
	Value value;

	AB_flag = a->AB_flag;
	value.rat = a->value.rat;
	value.code = a->value.code;

	a->AB_flag = b->AB_flag;
	a->value.rat = b->value.rat;
	a->value.code = b->value.code;

	b->AB_flag = AB_flag;
	b->value.rat = value.rat;
	b->value.code = value.code;

}
/*****************************************************************************/
unsigned rand2(void)
 {
    gSeed = (MULTIPLIER * gSeed + INCREMENT ) % MODULUS;
    return gSeed;
  }
/*****************************************************************************/
void srand2(double k)
 {
   gSeed = (int) k; 
 }  
/* last record of util.c *******/
