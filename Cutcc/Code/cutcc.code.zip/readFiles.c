/* first record of readFiles.c *****/
#include "cutcc.h"
/***************************************************************/
void readParamsFile()
{
  FILE *cutccParams;
  char record[MAXLEN] = {'\0'};
  char lhs[MAXLEN], rhs[MAXLEN];
  int cv[20] = {0};
  int beginReadFlag;

  char globalversion[5];
	
  cutccParams = openFile(lsqccparamsname, "r");

  /* Set default values */
  strcpy(gFileExt.rtr, ".rtr");
  strcpy(gFileExt.rts, ".rts");
  strcpy(gFileExt.cut, ".cut");
  strcpy(gFileExt.trn, ".trn");
  strcpy(gFileExt.tst, ".tst");
  strcpy(gFileExt.ptl, ".ptl");
  strcpy(gFileExt.vis, ".vis");
  strcpy(gFileExt.prd, ".prd");
  gParams.doTraining = FALSE;
  gParams.doTrainNew = TRUE;
  gParams.doTrainOld = FALSE;
  gParams.doTesting = FALSE;
  gParams.minCuts = 1;
  gParams.maxCuts = 2;
  gParams.effectiveOrperfect = EFFECTIVE;
  gParams.totalOrpartial = PARTIAL;
  gParams.unavailableOrAbsent = UNAVAILABLE;

  /* Set beginReadFlag */
  beginReadFlag = TRUE;

/*eject*/	
  /* Loop at the file and look for tokens */
  while (parse_param(lhs, rhs, record, cutccParams)) {
    /*
     * caution: parse_param() converts lhs to lower case
     *          this affects the tests below
     */
		
    /* Show steps on screen */
    if (strcmp(lhs,"showstepsonscreen") == 0) {
      gShowSteps = TRUE;
      printf("\n");
      printf("show steps on screen\n\n");
      printf("                    Leibniz System\n");
      printf("                    cutcc Program\n");
#include "../../GlobalVersion/globalversion.h"
      printf("                     Version %s\n",globalversion);
      printf("        Copyright 2001-2015 by Leibniz Company\n");
      printf("                 Plano, Texas, U.S.A.\n\n");
      continue;
    }

    /* "ENDATA" */
    if (strcmp(lhs, "endata") == 0 ||
      strcmp(lhs, "enddata") == 0) {
      cv[11] = TRUE;
      if (gShowSteps == TRUE ) {
        printf("\n**************************************\n\n");
      }
      break;
    }

    /* check for "begin...cc" specification */
    if ((strncmp(lhs,"begin",5) == 0) &&
        (strncmp(&lhs[strlen(lhs)-2],"cc",2) == 0)) {
      beginReadFlag = FALSE;
      if ((strcmp(lhs,"begincutcc") == 0)||
          (strcmp(lhs,"beginallcc") == 0)) {
        beginReadFlag = TRUE;
      }
      continue;
    }
    if (beginReadFlag == FALSE) {
      continue;
    }
		
/*eject*/
    /*  "file name without extension = " */
    if (strcmp(lhs,"filenamewithoutextension") == 0) {
      strcpy(gParams.prefix,rhs);
      cv[1] = TRUE;
      if (gShowSteps == TRUE) {
        printf("file name without extension = %s\n",
               gParams.prefix);
      }
     continue;
    }

    /* "training/testing directory = " */
    if (strcmp(lhs,"training/testingdirectory") == 0) {
      strcpy(gParams.directory,rhs);
      cv[2] = TRUE;
      if (gShowSteps == TRUE) {
        printf("training/testing directory = %s\n",
               gParams.directory);
      }
      continue;
    }

    /* "Leibniz directory = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"leibnizdirectory") == 0) {
      continue;
    }
/*eject*/

    /*  "cutpoint file extension           (default: cut) = " */
    if (strcmp(lhs, "cutpointfileextension(default:cut)") == 0) {
      strcpy(gFileExt.cut,".");
      strcat(gFileExt.cut,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "cutpoint file extension           (default: cut) = %s\n",
          rhs);
      }
      continue;
    }

    /*  "distribution file extension       (default: dis) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "distributionfileextension(default:dis)") == 0) {
      continue;
    }

    /*  "executable file extension         (default: exe)  = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"executablefileextension(default:exe)") == 0) {
      continue;
    }

    /*  "minimization file extension       (default: min)  = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"minimizationfileextension(default:min)") == 0){
      continue;
    }

   /*  "master file extension            (default: mst)  = " */
   /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs, "masterfileextension(default:mst)") == 0) {
      continue;
    }

    /*  "master AB file extension        (default: mstAB) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs, "masterabfileextension(default:mstab)") == 0) {
      continue;
    }
/*eject*/
    /*  "optimal record file extension     (default: opt) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "optimalrecordfileextension(default:opt)") == 0) {
      continue;
    }

    /*  "pyrpred file extension            (default: prd) = " */
    if (strcmp(lhs, "pyrpredfileextension(default:prd)") == 0) {
      strcpy(gFileExt.prd,".");
      strcat(gFileExt.prd,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "pyrpred file extension            (default: prd) = %s\n",
        rhs);
      }
      continue;
    }

    /*  "partial data file extension       (default: ptl) = " */
    if (strcmp(lhs,
        "partialdatafileextension(default:ptl)") == 0) {
      strcpy(gFileExt.ptl,".");
      strcat(gFileExt.ptl,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "partial data file extension       (default: ptl) = %s\n",
        rhs);
      }
      continue;
    }

    /*  "pyramid file extension            (default: pyr) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "pyramidfileextension(default:pyr)") == 0) {
      continue;
    }
/*eject*/
    /*  "rational training file extension  (default: rtr) = " */
    if (strcmp(lhs,
             "rationaltrainingfileextension(default:rtr)") == 0) {
      strcpy(gFileExt.rtr,".");
      strcat(gFileExt.rtr,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational training file extension  (default: rtr) = %s\n",
        rhs);
      }
      continue;
    }

    /*  "rational testing file extension   (default: rts) = " */
    if (strcmp(lhs,
             "rationaltestingfileextension(default:rts)") == 0) {
      strcpy(gFileExt.rts,".");
      strcat(gFileExt.rts,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational testing file extension   (default: rts) = %s\n",
        rhs);
      }
      continue;
    }

    /*  "rational testing A file extension (default: rtsA) = " */
    if (strcmp(lhs,
             "rationaltestingafileextension(default:rtsa)") == 0) {
    /*  note: not used by cutcc, hence no action here */
      continue;
    }

    /*  "rational testing B file extension (default: rtsB) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
             "rationaltestingbfileextension(default:rtsb)") == 0) {
      continue;
    }   

    /*  "rational testEqtrain file ext. (default: rtsEqrtr) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
       "rationaltesteqtrainfileext.(default:rtseqrtr)") == 0) {
      continue;
    }

    /*  "alternate testing file            (default: ats)   = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
             "alternatetestingfile(default:ats)") == 0) {
      continue;
    }
/*eject*/
    /*  "rule file extension               (default: rul)   =  " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "rulefileextension(default:rul)") == 0) {
      continue;
    }

    /*  "separation file extension         (default: sep) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "separationfileextension(default:sep)") == 0) {
      continue;
    }

    /*  "subgroup file extension           (default: sub) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "subgroupfileextension(default:sub)") == 0) {
      continue;
    }

    /*  "target file extension             (default: tgt) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "targetfileextension(default:tgt)") == 0) {
      continue;
    }

/*eject*/				
    /*  "logic training file extension     (default: trn) = " */
    if (strcmp(lhs,
      "logictrainingfileextension(default:trn)") == 0) {
      strcpy(gFileExt.trn,".");
      strcat(gFileExt.trn,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "logic training file extension     (default: trn) = %s\n",
        rhs);
      }
      continue;
    }

    /*  "logic testing file extension      (default: tst) = " */
    if (strcmp(lhs,
      "logictestingfileextension(default:tst)") == 0) {
      strcpy(gFileExt.tst,".");
      strcat(gFileExt.tst,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "logic testing file extension      (default: tst) = %s\n",
        rhs);
      }
      continue;
    }

    /*  "visualization file extension      (default: vis) = " */
    if (strcmp(lhs,
       "visualizationfileextension(default:vis)") == 0) {
      strcpy(gFileExt.vis,".");
      strcat(gFileExt.vis,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "visualization file extension      (default: vis) = %s\n",
        rhs);
      }
      continue;
    }
/*eject*/
    /*  "vote file extension               (default: vot) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "votefileextension(default:vot)") == 0) {
      continue;
    }

    /*  "vote A file extension              (default: vot) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "voteafileextension(default:vota)") == 0) {
      continue;
    }

    /*  "vote B file extension              (default: vot) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "votebfileextension(default:votb)") == 0) {
      continue;
    }

/*eject*/

    /* "missing entries (absent, unavailable) = " */
    if (strcmp(lhs, "missingentries(absent,unavailable)") == 0) {
      if (gShowSteps == TRUE ) {
       printf("missing entries (absent, unavailable) = %s\n",rhs);
      }
      if (strcmp(rhs,"unavailable")==0) {
        gParams.unavailableOrAbsent = UNAVAILABLE;
        continue;
      } else if (strcmp(rhs,"absent")==0) {
        gParams.unavailableOrAbsent = ABSENT;
        continue;
      }
    /*
     *  if none of the above rhs case applies, output is
     *  generated below that the record cannot be interpreted
     */ 
    }


    /*  "do logic training = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "dologictraining") == 0) {
      continue;
    }

    /*  "number/type of separations (4 total, 40 partial) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "number/typeofseparations(4total,40partial)") == 0) {
      continue;
    }

    /*  "nestedness delete option (not allowed, least cost, all) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "nestednessdeleteoption(notallowed,leastcost,all)") == 0){
      continue;
    }

    /*  "fraction A population (0.xx) = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "fractionapopulation(0.xx)") == 0) {
      continue;
    }

    /*  "cost type A error = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "costtypeaerror") == 0) {
      continue;
    }

    /*  "cost type B error = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "costtypeberror") == 0) {
      continue;
    }

    /*  "do logic testing = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "dologictesting") == 0) {
      continue;
    }

/*eject*/

   /* "dotraining transformation (new, old, skip) = "  */
   if (strcmp(lhs,
       "dotrainingtransformation(new,old,skip)") == 0) {
      gParams.doTraining = TRUE;
      if (gShowSteps == TRUE ) {
        printf("do training transformation (new, old, skip) ");
        printf("= %s\n",rhs);        
      }
      cv[3] = TRUE;
      if (strcmp(rhs,"new") == 0) {
        gParams.doTrainNew = TRUE;
        gParams.doTrainOld = FALSE;
        continue;
      } else if (strcmp(rhs,"old") == 0) {
        gParams.doTrainNew = FALSE;
        gParams.doTrainOld = TRUE;
        continue;
      } else if (strcmp(rhs,"skip") == 0) {
        gParams.doTraining = FALSE;
        gParams.doTrainNew = FALSE;
        gParams.doTrainOld = FALSE;
        continue;
      }
    /*
     *  if none of the above rhs case applies, output is
     *  generated below that the record cannot be interpreted
     */ 
    }
		
    /* "do training transformation" became obsolete May 2007 */
    if (strcmp(lhs, "dotrainingtransformation") == 0) {
      gParams.doTraining = TRUE;
      gParams.doTrainNew = TRUE;
      gParams.doTrainOld = FALSE;
      if (gShowSteps == TRUE ) {
        printf("do training transformation\n");
      }
      cv[3] = TRUE;
      continue;
    }

    /* "min cuts = " */
    if (strcmp(lhs, "mincuts") == 0) {
      if (gShowSteps == TRUE ) {
        printf("min cuts = %s\n", rhs);
      }
      if (rhs != NULL) {
        gParams.minCuts = (int) atoi(rhs);
      }
      continue;
    }

   /* "max cuts = " */
    if (strcmp(lhs, "maxcuts") == 0) {
      if (gShowSteps == TRUE ) {
        printf("max cuts = %s\n", rhs);
      }
      if (rhs != NULL) {
        gParams.maxCuts = (int) atoi(rhs);
      }
      continue;
    }

/*eject*/

    /* "degree of separation (effective, perfect) = " */
    if (strcmp(lhs,
        "degreeofseparation(effective,perfect)") == 0) {
      if (gShowSteps == TRUE ) {
       printf(
         "degree of separation (effective, perfect) = %s\n",rhs);
      }
      if (strcmp(rhs,"effective")==0) {
        gParams.effectiveOrperfect = EFFECTIVE;
        continue;
      } else if (strcmp(rhs,"perfect")==0) {
        gParams.effectiveOrperfect = PERFECT;
        continue;
      }
    /*
     *  if none of the above rhs case applies, output is
     *  generated below that the record cannot be interpreted
     */ 
    }

    /* "do testing transformation" */
    if (strcmp(lhs, "dotestingtransformation") == 0) {
      gParams.doTesting = TRUE;
      if (gShowSteps == TRUE ) {
        printf("do testing transformation\n");
      }
      cv[8] = TRUE;
      continue;
    }
/*eject*/
    /* "subcc detail directory = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"subccdetaildirectory") == 0) {
      continue;
    }

    /* "show target processing steps"  */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
       "showtargetprocessingsteps") == 0) {
      continue;   
    }

    /* "output variations of subgroups"  */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
       "outputvariationsofsubgroups") == 0) {
      continue;   
    }

    /* "keep subcc detail directory" */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"keepsubccdetaildirectory") == 0) {
      continue;
    }

    /* "attribute importance threshold = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"attributeimportancethreshold") == 0) {
      continue;
    }

    /* "max number of attributes used = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"maxnumberofattributesused") == 0) {
      continue;
    }

    /* "subgroup selection threshold = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"subgroupselectionthreshold") == 0) {
      continue;
    }

    /* "max number of expansions = " */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,"maxnumberofexpansions") == 0) {
      continue;
    }

    /* "compute subgroups (new tgt, old tgt, tgt only) = "  */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "computesubgroups(newtgt,oldtgt,tgtonly)") == 0) {
      continue;   
    }

    /* "master to masterAB program ="  */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "mastertomasterabprogram") == 0) {
      continue;   
    }

    /* "use (master, alternate) testing file          = "  */
    /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "use(master,alternate)testingfile") == 0) {
      continue;   
    }

/*eject*/
    /* line cannot be interpreted */
    printf(
   "\nRecord in file lsqccparams.dat cannot be interpreted:\n\n");
    printf(" %s \n", record);
    printf("Please correct lsqccparams.dat file\n");
    printf("and execute cutcc again\n");
    fprintf(errfil, 
   "\nRecord in file lsqccparams.dat cannot be interpreted:\n\n");
    fprintf(errfil, " %s \n", record);
    fprintf(errfil, "Please correct lsqccparams.dat file\n");
    fprintf(errfil,	"and execute cutcc again\n");
    cuterror("readParamsFile", "103");

  } /* end of while */

  /* confirm that all the information was entered */
  if (cv[8]+cv[3]==0) {
    printf(
      "Neither training nor testing is specified\n");
    printf(
      " in lsqccparams.dat.\n");
    fprintf(errfil,
      "Neither training nor testing is specified\n");
    fprintf(errfil,
      " in lsqccparams.dat.\n");     
    cuterror("readParamsFile", "100");
  }

  if(cv[1]==0) {
    printf(
      "Filename without extension is not specified\n");
    printf(
      " in lsqccparams.dat.\n");
    fprintf(errfil,
      "Filename without extension is not specified\n");
    fprintf(errfil,
      " in lsqccparams.dat.\n"); 
    cuterror("readParamsFile", "101");
  }

  if (cv[11]==0){
    enddataError("lsqccparams.dat");
  }

  fclose(cutccParams);
  return;
		
}

/*eject*/
/*****************************************************************************
* --------------------------------------------------------
*  parse_param(): parse parameters
* --------------------------------------------------------
******************************************************************************/
int parse_param(char *lhs, char *rhs, char *record, FILE *params) {
  char     str[128+1], ch;
  int      i, ix, l=0, r=0, nz;
  int      right = 0;
 
  if (feof(params)) {
    return(0);
  }
  fgets(str, 126, params);
  while (str[0] == '*') {
    if (feof(params)) {
      return(0);
    }
    fgets(str, 126, params);
  }  
/*
 *  change all string characters 
 *  with ascii code 1-31 or 127-254 by blanks
 */
  nz = strlen(str);
  for(i=0; i<=nz-1; i++)  {
    ix = (int)str[i];
    if (((ix>=1)&&
        (ix<=31))||
        ((ix>=127)&&
        (ix<=254))) {
      str[i] = ' ';
    }
  }
/*
 *  introduce carriage return character and,
 *  if necessary, new end of string character
 */
  if (str[nz-1] == ' ') {
    str[nz-1] = '\n';
  } else {
    str[nz] = '\n';
    str[nz+1] = '\0';
    nz++;
  }  
  
  strcpy(record, str);
  for (i = 0; i <= nz-1; i++) {
    ch = str[i];
    switch (ch) {
      case ' ':
                break;  
      case '=':
                right = 1;
                break;
      case '\n':
                break;
      default:
				if (right) {
				 rhs[r++] = ch;
               } else {
				 lowerCase(&ch);
                 lhs[l++] = ch;
               }
    }
  }
  lhs[l] = '\0';
  rhs[r] = '\0';  
  return(1);
}

/*eject*/
/****************************************************************************/
void lowerCase(char *ch)
{
	if (*ch >= 65 && *ch <= 90)
		*ch += 32;
}
/*****************************************************************************
*	Shift the line left
*   Ascii 32 = space, 9 = tab
******************************************************************************/
void shiftLeft(char fileRec[])
{
	while(fileRec[0] == 32 || fileRec[0] == 9) {
		strcpy(fileRec, fileRec+1);
	}

}
/*****************************************************************************
* This function loads all of the file data into two
* internal tables, one for A and one for B.
* It expects either a training file in the form of:
* BEGIN A
* 1 2 ... n
* ...
* BEGIN B
* 1 2 ... n
* ...
* ENDATA (optional)
* 
* or a testing file in the form of:
* 1 2 ... n
* ...
* 1 2 ... n
* The default is it is expecting testing records;
* It also expects a run type, TRAINING or TESTING
******************************************************************************/
void loadInputRecords(int runType) 
{
	
	int recordType = 0;  /* value = 0 suppresses compiler warning */
	FILE *inrecFile;  
	char fileRec[MAXLEN] = {'\0'};
	char fileExt[32];
	int endDataFlag = 0;
	int *lineCountPtr;
	int recCount = 0;
	int lineCount = 0;

	gAcount = 0;
	gBcount = 0;
	gTestRecCount = 0;
	    
	if (runType == TRAINING) {
		strcpy(fileExt, gFileExt.rtr);
		lineCountPtr = gTrainingLine;
	}
	else {
		strcpy(fileExt, gFileExt.rts);
		lineCountPtr = gTestingLine;
	}

			
	inrecFile = openFilePrefix(fileExt, "r");

    /* Loop at file of input records */
    while (fgets(fileRec, MAXLEN, inrecFile) != NULL) {

		lineCount++;
		
		/* Shift the line left (remove whitespace at beginning) */
		shiftLeft(fileRec);

		/* Determine record type */
		if ((stringCompare(fileRec, "BEGIN A", 7) == 0) ||
                    (stringCompare(fileRec, "begin a", 7) == 0)) 	
			recordType = A;
		else if ((stringCompare(fileRec, "BEGIN B", 7) == 0) ||
                         (stringCompare(fileRec, "begin b", 7) == 0))
			recordType = B;	
		else if ((stringCompare(fileRec, "ATTRIBUTES", 10) == 0) ||
                         (stringCompare(fileRec, "attributes", 10) == 0))
			 recordType = ATTRIBUTE;
		else if (((stringCompare(fileRec, "ENDATA", 6) == 0) ||
				(stringCompare(fileRec, "ENDDATA", 7) == 0)) ||
                         ((stringCompare(fileRec, "endata", 6) == 0) ||
				(stringCompare(fileRec, "enddata", 7) == 0))) {
			endDataFlag = TRUE;
			break;
		}		
		else if (strncmp(fileRec, "*", 1) == 0) 
			continue;		
		else if (strncmp(fileRec, "\n", 1) == 0) 
			continue;			
		else 
		{
			/* If testing type process that way */
			if (runType == TESTING) {
				lineCountPtr[++recCount] = lineCount;
				addRecord(TEST, fileRec, gDataRecords, gTestRecCount);
				gTestRecCount++;
				continue;
			}

			
			/* Have a data or Attribute record */
			if (recordType == A) {
				lineCountPtr[++recCount] = lineCount;
				addRecord(A, fileRec, gDataRecords, gAcount+gBcount);
				gAcount++;
			}
			else if (recordType == B) {
				lineCountPtr[++recCount] = lineCount;
				addRecord(B, fileRec, gDataRecords, gAcount+gBcount);
				gBcount++;
			}
			else if (recordType == ATTRIBUTE) 
				addAttribute(fileRec);
			else {
				printf("Invalid record type in %s file.\n", fileExt);
				fprintf(errfil, "Invalid record type in %s file.\n", fileExt);
				cuterror("loadInputRecords","100");
			}


			/* Check if too many records */
			if (gAcount+gBcount > MAX_RECORD || gTestRecCount > MAX_RECORD) {
				printf("Exceeded max number of records %d\n.", MAX_RECORD);
				fprintf(errfil,"Exceeded max number of records %d\n.", MAX_RECORD);
				cuterror("loadInputRecords","101");
			}

			
			
		}
	}

	if (!endDataFlag) {
		enddataError(fileExt);
	}

	/* test for nonzero record counts */
	if (runType == TRAINING) {
	  if (gAcount == 0 || gBcount == 0) {
	    printf(
     "Warning: rational training file has no A or B records. Stop\n");
            fprintf(errfil,
     "Warning: rational training file has no A or B records. Stop\n");
	    exit(1);
	  }
          /* count distinct values for each attributes */
          countDistinctValues();
	} else { /* TESTING case */
	  if (gTestRecCount == 0) {
            printf("Warning: rational testing file has no records. Stop\n");
            fprintf(errfil,
                   "Warning: rational testing file has no records. Stop\n");
	    exit(1);
	  }
	}


	fclose(inrecFile);
	
}

/*eject*/
/******************************************************************************/
void addAttribute(char fileRec[])
{

	char deleteHold[MAX_ID] = {"\0"};
	char nameHold[MAX_ID] = {"\0"};
	char *buffer;
	int count = 0;
	int i;

	/* Convert line feed or carriage return to null */
	for(i=0;i<MAXLEN;i++) {
		if (fileRec[i] == 10) fileRec[i] = 0;
		if (fileRec[i] == 13) fileRec[i] = 0;
	}
	
	//Read first value
	buffer = strtok(fileRec, " \t\n");
	if (buffer == NULL)
	{
	  printf("Error reading in attribute token, make sure line has an attribute.\n");
	  fprintf(errfil,"Error reading in attribute token, make sure line has an attribute.\n");
		cuterror("addAttribute","100");
	}
			
	strcpy(nameHold, buffer);

	/* read token following attribute name */
	buffer = strtok(NULL, " \t\n");

	/* skip over CLASS AND TARGET options */
	if (buffer != NULL) {
	  while ((strncmp(buffer,"CLASS",5) == 0) ||
	    (strncmp(buffer,"TARGET",6) == 0)) {
	    buffer = strtok(NULL," \t\n");
	    if (buffer == NULL) {
	      break;
	    }
	  }
	}

	if (buffer != NULL) {
	  strcpy(deleteHold, buffer);
	}
	
	/* Increment number of attributes before deletion */
	gBeforeDel++;
	gDeleteVector[gBeforeDel] = FALSE;

	/* If deleteHold == "DELETE", store that info and return */
	if (stringCompare(deleteHold,"DELETE",6)==0)
	{
	  gDeleteVector[gBeforeDel] = TRUE;
	  strncpy(gAttributeDel[gBeforeDel], nameHold,MAX_ID-1);
	  return;
	}

	/* Increment the number of attributes */
	gNumAttributes++;

	/* Check if gNumAttributes exceeds maximum */
	if (gNumAttributes > MAX_ATTRIBUTE) {
	  printf("Max number of attributes %d exceeded.\n",
		 MAX_ATTRIBUTE);
	  fprintf(errfil,"Max number of attributes %d exceeded.\n",
		  MAX_ATTRIBUTE);
	  cuterror("addAttribute","101");
	}
		
	/* Copy in the attribute name */
	strncpy(gAttribute[gNumAttributes], nameHold,MAX_ID-1);
	gMinCuts[gNumAttributes] = gParams.minCuts;
	gMaxCuts[gNumAttributes] = gParams.maxCuts;
	gUncertainFlag[gNumAttributes] = FALSE;

	/* check for buffer = NULL or comment '*' */
	if ((buffer == NULL ) || (buffer[0] == '*')) {
	  return;
	}
	
	/* Check if SET # # # ... # */
	if (stringCompare(buffer, "SET",3)==0)
	{
	  /* add the value to the set values */ 
	  gSet[gNumAttributes] = TRUE;
			
	  buffer = strtok(NULL, " \t\n");
	  while(buffer != NULL && buffer[0] != '*')
	  {
	    /* check if UNCERTAIN, MINCUTS, or MAXCUTS is used with SET */
	    if ((stringCompare(buffer, "UNCERTAIN",9)==0)||
		(stringCompare(buffer, "MAXCUTS",7)==0) ||
                (stringCompare(buffer, "MINCUTS",7)==0) )
	    {
	      printf(
                "Error: UNCERTAIN, MINCUTS, or MAXCUTS used with SET.\n");
	      printf("       See attribute %s.\n",
		     gAttribute[gNumAttributes]);
	      fprintf(errfil,
		"Error: UNCERTAIN, MINCUTS, or MAXCUTS used with SET.\n");
	      fprintf(errfil,
		      "       See attribute %s.\n", 
		      gAttribute[gNumAttributes]);
	      cuterror("addAttribute","201");
	    }
	    count++;
	    gCutMatrix[gNumAttributes][count] = (float) atof(buffer);
	    gUncertainLow[gNumAttributes][count] = 
	      gCutMatrix[gNumAttributes][count];
	    gUncertainHigh[gNumAttributes][count] = 
	      gCutMatrix[gNumAttributes][count];
	    buffer = strtok(NULL, " \t\n");
	  }
	  gCutVector[gNumAttributes] = count;
	  gMaxCuts[count] = count;
	  return;	  
	}

 zz100:;
	/* check for buffer = NULL or comment '*' */
	if ((buffer == NULL ) || (buffer[0] == '*')) {
	  return;
	}
		
	/* check if UNCERTAIN option */
	if (stringCompare(buffer, "UNCERTAIN",9)==0)
        {
	  gUncertainFlag[gNumAttributes] = TRUE;

	  /* check if missing entries = absent is specified */
	  /* in parameter file */
	  if (gParams.unavailableOrAbsent == ABSENT)
	  {
	    printf("Error: UNCERTAIN is not allowed when\n");
	    printf("       missing entries = absent is specified in\n");
	    printf("       lsqccparams.dat. See attribute %s.\n", 
		   gAttribute[gNumAttributes]);
	    fprintf(errfil,"Error: UNCERTAIN is not allowed when\n");
	    fprintf(errfil,
		    "       missing entries = absent is specified in\n");
	    fprintf(errfil,"       lsqccparams.dat. See attribute %s.\n", 
		    gAttribute[gNumAttributes]);
	    cuterror("addAttribute","202");
	  }
	  buffer = strtok(NULL, " \t\n");
	  goto zz100;
	}

        /* check if MINCUTS option */
	if (stringCompare(buffer, "MINCUTS",7)==0) {
	  /* get mincuts value */
	  buffer = strtok(NULL, " \t\n");
	  if ((buffer == NULL) || (buffer[0] == '*') ||
	      (stringCompare(buffer, "UNCERTAIN",9)==0) ||
	      (stringCompare(buffer, "SET",3)==0)) {
	    printf("Error: MINCUTS option without value.\n");
	    printf("       See attribute %s\n.",
		   gAttribute[gNumAttributes]);
	    fprintf(errfil,"Error: MINCUTS option without value.\n");
	    fprintf(errfil,"       See attribute %s\n.",
		   gAttribute[gNumAttributes]);
	    cuterror("addAttribute","301");
	  }
	  gMinCuts[gNumAttributes] = (int) atoi(buffer);
	  buffer = strtok(NULL, " \t\n");
	  goto zz100;
	}

	/* check if MAXCUTS option */
	if (stringCompare(buffer, "MAXCUTS",7)==0) {
	  /* get maxcuts value */
	  buffer = strtok(NULL, " \t\n");
	  if ((buffer == NULL) || (buffer[0] == '*') ||
	      (stringCompare(buffer, "UNCERTAIN",9)==0) ||
	      (stringCompare(buffer, "SET",3)==0)) {
	    printf("Error: MAXCUTS option without value.\n");
	    printf("       See attribute %s\n.",
		   gAttribute[gNumAttributes]);
	    fprintf(errfil,"Error: MAXCUTS option without value.\n");
	    fprintf(errfil,"       See attribute %s\n.",
		   gAttribute[gNumAttributes]);
	    cuterror("addAttribute","302");
	  }
	  gMaxCuts[gNumAttributes] = (int) atoi(buffer);
	  buffer = strtok(NULL, " \t\n");
	  goto zz100;
	}

	/* unknown option */
	printf(
	       "Error: Illegal combination of options or unknown option\n");
	printf(
	       "       for attribute %s\n", gAttribute[gNumAttributes]);
	fprintf(errfil,
	       "Error: Illegal combination of options or unknown option\n");
	fprintf(errfil,
	       "       for attribute %s\n", gAttribute[gNumAttributes]);
	cuterror("addAttribute","301");

}

/*eject*/
/*******************************************************************************
* This subroutine adds the record to the A or B table
* and populates the table of high and low values.
********************************************************************************/
void addRecord(int AB_flag, char fileRec[], Record records[], int currentLine)
{
	int ai = 1;  //vector index
	Value recordValue;
	int new_vi = 0;
	char *buffer;

	recordValue.rat = 0; recordValue.code = 0;

	/* Read first value */
	buffer = strtok(fileRec, " \t");
	if (buffer == NULL)
	{
		printf("Error reading in value token, make sure line has a numeric value.\n");
		fprintf(errfil,"Error reading in value token, make sure line has a numeric value.\n");
		cuterror("addRecord", "100");
	}
		
	/* Decide if unavailable or has value */
	if (strcmp(buffer, "?") == 0) {
		if (gParams.unavailableOrAbsent == UNAVAILABLE)
			recordValue.code = UNAVAILABLE;
		else
			recordValue.code = ABSENT;
	}
	else
		recordValue.rat = (float) atof(buffer);


	/* If the attribute has not been deleted read in value */	
	if (gDeleteVector[ai] == FALSE) {
 		new_vi++;

		records[currentLine].AB_flag = AB_flag;
		records[currentLine].value[new_vi].rat = recordValue.rat;
		records[currentLine].value[new_vi].code = recordValue.code;
	}

	recordValue.rat = 0; recordValue.code = 0;
	
	/* Read in the remaining values for a line */
	for (ai=2; ai <= gBeforeDel; ai++){ /* for loop remaining values */

		buffer = strtok(NULL, " \t\n");
		if (buffer == NULL) {
			printf("Read in null token, make sure each line has a value for each attribute.\n");
			printf("Even deleted attributes need a value, if unknown put a '?' in its place.\n");
			fprintf(errfil,"Read in null token, make sure each line has a value for each attribute.\n");
			fprintf(errfil,"Even deleted attributes need a value, if unknown put a '?' in its place.\n");
			cuterror("addRecord", "101");
		}

		if (strcmp(buffer, "?") == 0) {
			if (gParams.unavailableOrAbsent == UNAVAILABLE)
				recordValue.code = UNAVAILABLE;
			else
				recordValue.code = ABSENT;
		}
		else
			recordValue.rat = (float) atof(buffer);


		/* Only want values that are not to be deleted */
		if (gDeleteVector[ai] == FALSE) {
			
			new_vi++;

			records[currentLine].AB_flag = AB_flag;
			records[currentLine].value[new_vi].rat = recordValue.rat;
			records[currentLine].value[new_vi].code = recordValue.code;
			
		}

		recordValue.rat = 0; recordValue.code = 0;

	} /* end for loop remaining values */
	
}
/*eject*/
/*******************************************************************
* Count number of distinct values for each attribute.
* gnumDistinctValues[ai] = 1: one distinct value
*                        = 2: two distinct values
*                        = gAcount+gBcount: >= 3 distinct values
********************************************************************/
void countDistinctValues() {

  int ai, i;
  double value, value1, value2;

  value1 = 0.0; /* to suppress compiler warning */
  value2 = 0.0; /* to suppress compiler warning */

  for (ai = 1; ai<=gNumAttributes; ai++) {
    gNumDistinctValues[ai] = 0;

    for (i=0; i<=gAcount+gBcount-1; i++) {
      if (gDataRecords[i].value[ai].code == 0) {
        /* value is known and not equal to unavailable or absent */
        value = gDataRecords[i].value[ai].rat;
        if (gNumDistinctValues[ai] == 0) {
          value1 = value;
          gNumDistinctValues[ai] = 1;
        } else if (gNumDistinctValues[ai] == 1) {
          if (value != value1) {
            value2 = value;
            gNumDistinctValues[ai] = 2;
          }
        } else if (gNumDistinctValues[ai] == 2) {
          if ((value != value1) && (value != value2)) {
            gNumDistinctValues[ai] = gAcount+gBcount;
            break;
          }
        } /* end if NumDistinctValues[ai] == 0, else */
      } /* end if gDataRecords[i].value[ai].code == 0 */ 
    } /* end for i */

  } /* end for ai */

  return;
}
/*eject*/
/*******************************************************************************
* Read the cut file created by the training process.
********************************************************************************/
void loadCutFile()
{
	FILE *cutFile; 
	char fileRec[MAXLEN] = {'\0'};
	int endataCheckFlag = 0;
	int ai = 0;
	
	cutFile = openFilePrefix(gFileExt.cut, "r");
	
	/* Loop at file of input records */
    while (fgets(fileRec, MAXLEN, cutFile) != NULL) {
		
		/* Shift the line left (remove whitespace at beginning) */
		shiftLeft(fileRec);

		if ((stringCompare(fileRec, "CUTPOINTS", 9) == 0) ||
			(strncmp(fileRec, "*", 1) == 0) ||
			(strncmp(fileRec, "\n", 1) == 0) ||
			(strncmp(fileRec, "\r", 1)	== 0))
		{
			continue;
		}
		else if (stringCompare(fileRec, "ENDATA", 6) == 0 ||
				stringCompare(fileRec, "ENDDATA", 7) == 0) {
			endataCheckFlag = TRUE;
			break;
		}
		else 
		{
			/* Read in the cut line */
		  readCutLine(fileRec, &ai);
		}

	}

	if (!endataCheckFlag) {
		enddataError(gFileExt.cut);
		
	}
		
 	fclose(cutFile);

}

/*eject*/
/******************************************************************************/
void readCutLine(char fileRec[], int *ait)
{
	char *buffer; 
	char nameHold[MAX_ID];
	int cut;
	int ai;

	ai = *ait;

	/* Index counts all incoming attributes, including deleted ones */
	gBeforeDel++;

	/* Read in attribute name */
	buffer = strtok(fileRec, " \t\n");
	if (buffer == NULL) {
	  printf("No attribute name to tokenize when one\n");
	  printf("should exist in %s file.\n", gFileExt.cut);
	  fprintf(errfil,"No attribute name to tokenize whe one\n");
	  fprintf(errfil,"should exist in %s file.\n", gFileExt.cut);
		cuterror("readCutLine","100");
	}
	strcpy(nameHold, buffer);
	
	/* Check if delete */
	buffer = strtok(NULL, " \t\n");
	if (buffer == NULL) {
	  printf("No second value (DELETE, SET, NUM, or UNCERTAIN)\n");
	  printf("to tokenize when one should exist in %s file.\n", gFileExt.cut);
	  fprintf(errfil,
		  "No second value (DELETE, SET, NUM, or UNCERTAIN)\n");
	  fprintf(errfil,
		  "to tokenize when one should exist in %s file.\n", gFileExt.cut);
	  cuterror("readCutLine","101");
	}
	if (stringCompare(buffer, "DELETE", 6) == 0)  {
		gDeleteVector[gBeforeDel] = TRUE;
		*ait = ai;
		return;
	}

	/* not deleted */
	strcpy(gAttribute[++ai], nameHold);
	gNumAttributes++;

	gUncertainFlag[ai] = FALSE;
	gSet[ai] = FALSE;

	/* Check if SET, NUM, or UNCERTAIN */
	if (stringCompare(buffer, "SET", 3) == 0) {
	  gSet[ai] = TRUE;
        } else if (stringCompare(buffer, "UNCERTAIN", 9) == 0) {
	  gUncertainFlag[ai] = TRUE;
	} else if (stringCompare(buffer, "NUM", 3) != 0) {
	  printf("Second value should be DELETE, SET, NUM, or\n");
	  printf("UNCERTAIN for line in %s file.\n", gFileExt.cut);
	  fprintf(errfil,"Second value should be DELETE, SET, NUM, or\n");
	  fprintf(errfil,"UNCERTAIN for line in %s file.\n", gFileExt.cut);
	  cuterror("readCutLine","102");
	}

	/* Get the number of cuts */
	buffer = strtok(NULL, " \t\n");
	if (buffer == NULL) {
		printf("No num cuts value to tokenize when one should exist in %s file.\n", gFileExt.cut);
		fprintf(errfil,"No num cuts value to tokenize when one should exist in %s file.\n", gFileExt.cut);
		cuterror("readCutLine","103");
	}
	gCutVector[ai] = atoi(buffer);

	/* Read in the cut values */
	for (cut=1; cut <= gCutVector[ai]; cut++){
		
		buffer = strtok(NULL, " \t\n");
		if (buffer == NULL) {
			printf("Insufficient cut values on a line in %s file.\n", gFileExt.cut);
			fprintf(errfil,
				"Insufficient cut values on a line in %s file.\n", gFileExt.cut);
			cuterror("readCutLine","104");
		}
		
		gCutMatrix[ai][cut] = (float) atof(buffer);

		if (gUncertainFlag[ai] == TRUE) { /* begin uncertainty interval processing */

		  /* opening bracket */
		  buffer = strtok(NULL, " \t\n");
		  if ((buffer==NULL) || (strcmp(buffer,"[") != 0)) { 
		    printf("Uncertainty interval [ missing on a line in %s file.\n", 
			   gFileExt.cut);
		    fprintf(errfil,
			    "Uncertainty interval [ missing on a line in %s file.\n",
			   gFileExt.cut);
		    cuterror("readCutLine","105");
                  }
		  
		  /* low value of interval */
		  buffer = strtok(NULL, " \t\n");
		  if (buffer == NULL) { 
		    printf("Uncertainty interval value missing on a line in %s file.\n",
			  gFileExt.cut);
		    fprintf(errfil,
			    "Uncertainty interval value missing on a line in %s file.\n", 
			    gFileExt.cut);
		    cuterror("readCutLine","106");
		  }
		  gUncertainLow[ai][cut] = (float) atof(buffer);

		  /* separating comma */
		  buffer = strtok(NULL, " \t\n");
		  if ((buffer == NULL) || (strcmp(buffer,",") != 0)){ 
		    printf("Uncertainty interval comma missing on a line in %s file.\n", 
			   gFileExt.cut);
		    fprintf(errfil,
			    "Uncertainty interval comma missing on a line in %s file.\n", 
			    gFileExt.cut);
		    cuterror("readCutLine","107");
		  }

		  /* high value of interval */
		  buffer = strtok(NULL, " \t\n");
		  if (buffer == NULL) { 
		    printf("Uncertainty interval value missing on a line in %s file.\n", 
			   gFileExt.cut);
		    fprintf(errfil,
			    "Uncertainty interval value missing on a line in %s file.\n", 
			    gFileExt.cut);
		    cuterror("readCutLine","108");
		  }
		  gUncertainHigh[ai][cut] = (float) atof(buffer);

		  /* closing bracket */
		  buffer = strtok(NULL, " \t\n");
		  if ((buffer==NULL) || (strcmp(buffer,"]") != 0)) { 
		    printf("Uncertainty interval [ missing on a line in %s file.\n", 
			   gFileExt.cut);
		    fprintf(errfil,
			    "Uncertainty interval [ missing on a line in %s file.\n", 
			    gFileExt.cut);
		    cuterror("readCutLine","109");
                  }
		} else {
		  gUncertainLow[ai][cut] = gCutMatrix[ai][cut];
		  gUncertainHigh[ai][cut] = gCutMatrix[ai][cut];
		} /* end of uncertainty interval processing */
		
	}

	*ait = ai;
	return;


}
/* last record of readFiles.c *******/


