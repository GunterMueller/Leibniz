/* first record of cutPoint.c *****/
#include "cutcc.h"

/******************************************************************************/
void getBestCutPoint(
       int ai, int var, float *cutPoint,
       int *intervalSize, int *cutSigma,
       float *uncertainLow, float *uncertainHigh,
       float *belowValue, float *aboveValue, 
       float *attractiveness,
       float *usefulness, float *separationCriterion)
{
	int recCount;  
	int cutIndex;
        int uncertainDelta;
	float delta;
	int locSigma;
	int n; // Used for sigma threshold index
	
	/* Allocate Arrays */
	memset(records,0,sizeof(records));
	memset(beta,0,sizeof(beta));
			
	/* get all records that need to be separated for that var and ai */
	getMatchingRecords(records, ai, var, &recCount);


	/* Sort the records */
	quickSort(records, 0, (recCount-1));
	
	/* Calculate sigma */
	locSigma = calculateSigmaNew(recCount, records);

	/* Needed to break ties when finding best cut */
	*intervalSize = recCount;

	/* If fewer than 6 records, don't use this for separation */ 
	if (recCount < 6) {
		*cutPoint = NEGINFINITY;
		*separationCriterion = 0;
		return;
	}

	/* Get the highest cut value */
	cutIndex = getHighestCutValue(records, recCount, &delta, beta, &n, locSigma);

	/* No cutValue found, all same z value */
	if (cutIndex == NONE_FOUND){
		*cutPoint = NEGINFINITY;
		*separationCriterion = 0;
		return;
	}

	/* Get the cut value */
	*cutPoint = (records[cutIndex].value.rat + records[cutIndex-1].value.rat) / (float) 2;

	/* Compensate for sigma used */
	*attractiveness = delta/(beta[0] - 2*beta[n+1]);

	/* Store sigma value */
	*cutSigma = locSigma;

	/* Compute uncertainty interval */
        uncertainDelta = 1;
        if (locSigma >= 2) {
          uncertainDelta = locSigma/2;
        }

        findUncertainInterval(
           uncertainLow,uncertainHigh,belowValue,aboveValue,
           cutIndex,uncertainDelta,recCount,locSigma);

	/* Compute usefulness */
	*usefulness = getUsefulness(records, recCount, cutIndex);

	/* Compute separationCriterion */
	*separationCriterion = *attractiveness + *usefulness;

    return;

}

/*eject*/
/************************************************************
*  Put a best marker into any attribute 
*  that still does not have one.
*************************************************************/
void addBestMarker(int ai)
{

	AttributeModify am;
	float cutLocation;
	float attractiveness;
	int cutSigma;
	float uncertainLow;
	float uncertainHigh;
	float belowValue;
	float aboveValue;
	float usefulness;
	float separationCriterion;
	int varCount;
	float max = 0;
	float separationHeuristic = 0;
	int maxRec = 0;
	int intervalSize;
	int var;

	
	while (gCutVector[ai] < gMinCuts[ai]) 
	{
		varCount = gCutVector[ai]+1;
		max = 0;
		maxRec = 0;

		/* Look at all the variables for an attribute */
		for (var = 1; var <= varCount; var++)
		{

			/* Calculate the heuristic for the best cut
			 * point for the variable/attribute combination. */
		        if (gRunType == ENTROPY){
			  attractiveness = getBestEntropy(ai, var, &cutLocation, 
							  &intervalSize);
			  separationHeuristic = attractiveness;
			  cutSigma = 0;
			  uncertainLow = 0;
			  uncertainHigh = 0;
			  belowValue = 0;
			  aboveValue = 0;
			  usefulness = 0;
			} else {
			  getBestCutPoint(
			     ai, var, &cutLocation, 
			     &intervalSize, &cutSigma,
			     &uncertainLow, &uncertainHigh,
			     &belowValue, &aboveValue,
			     &attractiveness,
			     &usefulness, &separationCriterion);
			  /* old criterion was based on attractiveness */
			  /* separationHeuristic = attractiveness; */
			  separationHeuristic = separationCriterion;
			}
			// If no suitable markers found, continue
			if (separationHeuristic==0) continue;

			if (separationHeuristic < 0){
				fprintf(errfil, "Fatal error in addBestMarker\n");
				printf("Fatal error in addBestMarker\n");
				cuterror("addBestMarker", "100");
			}
				
			/* Add it to the list, will grab max with biggest interval */
			if (separationHeuristic >= max) {
				if (separationHeuristic > max || intervalSize > maxRec) {
					am.ai = ai;
					am.variable = var;
					am.cutLocation = cutLocation;
					am.attractiveness = attractiveness;
					am.cutSigma = cutSigma;
					/* caution: the next two values are used later */
					/*          only if gUncertainFlag[ai] = TRUE */
					am.uncertainLow = uncertainLow;
					am.uncertainHigh = uncertainHigh;
					am.belowValue = belowValue;
					am.aboveValue = aboveValue;
					am.usefulness = usefulness;
					am.separationCriterion = separationCriterion;
					max = separationHeuristic;
					maxRec = intervalSize;
				}
			}

		} // end for var

		// If none found just stay with current number of markers
		if (max==0) break;		

		updateScheme(am);

	} // end while

	if (gCutVector[ai] == 0) {
	  if (gShowSteps) {
	    printf("Warning: No suitable marker found for %s consider deleting attribute.\n\n", gAttribute[ai]);
	  }
	  fprintf(errfil,"Warning: No suitable marker found for %s consider deleting attribute.\n\n", gAttribute[ai]);
		cutLocation = 0;
	}


}

/*eject*/
/********************************************************/	
void finalAttributeCheck()
{
	int ai;

	for (ai=1; ai <= gNumAttributes; ai++) {
		if (gCutVector[ai] < gMinCuts[ai] && gSet[ai] == FALSE) {
			if (gShowSteps)
				printf("Attribute %s has fewer than %d marker(s), try to refine.\n", 
					gAttribute[ai], gMinCuts[ai]);
			addBestMarker(ai);
		}
	}
}

/*eject*/
/*****************************************************************/
int recordCompare(const void *rec1, const void *rec2)
{
	Record_1d *a, *b;

	a = (Record_1d*) rec1;
	b = (Record_1d*) rec2;

	if (a->value.code > 0) return -1;
	if (b->value.code > 0) return 1;
	
	if (a->value.rat < b->value.rat) return -1;
	if (a->value.rat > b->value.rat) return 1;

	/* So value the same */
	if (a->AB_flag == b->AB_flag) return -1;

	/* Same value diff AB flag */
	if (a->AB_flag == A) return 1;
	else return 1;
}
/********************************************************************/
void findUncertainInterval(float *uncertainLow, float *uncertainHigh,
                           float *belowValue, float *aboveValue,
			   int cutIndex, int uncertainDelta,
                           int recCount, int locSigma){
/* 
 *  find uncertain interval for 
 *     cutpoint given by cutIndex and
 *     maximum interval width given by uncertainDelta;
 *  rule: at most uncertainDelta values are to the left 
 *  of the cutpoint, and at most uncertainDelta values
 *  are to the right of the cutpoint
 *  modified Mar 4, 2007: reduce uncertainty interval if one
 *  of its endpoints is too close to lowest or highest value
 *
 *  belowValue = attribute value immediately below cutpoint
 *  aboveValue = attribute value immediately above cutpoin
 */

/* old code, replaced March 13, 2007 */
//  *uncertainLow = records[cutIndex-uncertainDelta].value.rat;
//  *uncertainHigh = records[cutIndex+uncertainDelta-1].value.rat;

/* March 13, 2007: improved tail analysis */
    if (cutIndex-uncertainDelta < 2*locSigma) {
    /* left endpoint of uncertainty interval is within         */
    /* 2*locSigma of lowest value; reduce uncertainty interval */
       *uncertainLow = records[cutIndex-1].value.rat;
      } else {
      *uncertainLow = records[cutIndex-uncertainDelta].value.rat;
    }
    if (cutIndex+uncertainDelta-1 > recCount-2*locSigma+1) {
    /* right endpoint of uncertainty interval is within        */
    /* 2*locSigma of lowest value; reduce uncertainty interval */ 
        *uncertainHigh = records[cutIndex].value.rat;
    } else {
      *uncertainHigh = records[cutIndex+uncertainDelta-1].value.rat;
    }

    *belowValue = records[cutIndex-1].value.rat;
    *aboveValue = records[cutIndex].value.rat;

  return;
  
}
/************************************************************************/

int getHighestCutValue(Record_1d rec[], int recCount, float *delta,
					float beta[], int *n, int locSigma)
{

	int start = 0;
	int cutIndex;
	int i;

	memset(convolution,0,sizeof(convolution));
	memset(AB,0,sizeof(AB));
	memset(cutValue,0,sizeof(cutValue));

	/* Load the table with 1 for A, 0 for B */
	loadAB(rec, AB, recCount);

	/* Make the AB value for duplicates the average of those
	 * with that value . */
	averageDuplicates(rec, AB, recCount);

	/* Calculate the convolution values */
	calculateConvolution(AB, convolution, recCount, beta, locSigma);
	
	/* Calculate the cutValue values */
	calculateCut(convolution, cutValue, recCount);

	/* First valid delta is 2 * sigma + 1 */
	start = 1 + 2 * locSigma;

	/* Calculate n for threshold */
	*n = (int) floor(1.5*locSigma);

	/* Get the biggest dropoff in cut value */
	cutIndex = getBiggestDropoff(recCount, cutValue, start, AB, locSigma);

	if (cutIndex == NONE_FOUND)
	{
		/* No valid index found, see if there is valid index in the
		 * border areas that were not searched. If so, set the sigma value
		 * to 1 and get the best value */
		for (i=1; i<recCount; i++)
			if (AB[i] != AB[i-1]) {

				/* Set sigma to 1 to search small space */
				locSigma = 1;
								
				/* First valid delta is 2 * sigma + 1 */
				start = 1 + 2 * locSigma;

				*n = (int) floor(1.5*locSigma);

				/* Calculate the convolution values */
				calculateConvolution(AB, convolution, recCount, beta, locSigma);
	
				/* Calculate the cutValue values */ 
				calculateCut(convolution, cutValue, recCount);

				cutIndex = getBiggestDropoff(recCount, cutValue, start, AB, locSigma);
				break;
			}
	}

	
	if (cutIndex == NONE_FOUND)
		*delta = 0;
	else
		*delta = cutValue[cutIndex];

	return cutIndex;
	

}

/*eject*/
/******************************************************************************
*  Remove the unavailable or absent values before doing cut detection.
*  Here unavailable refers to unavailable or absent.
*******************************************************************************/
void removeUnavailable(Record_1d rec[], int *recCount)
{
	int i = 0;
	int numUnavailable = 0;
	
	for (i=0;i<*recCount;i++) {
		if(rec[i].value.code == UNAVAILABLE ||
		  rec[i].value.code == ABSENT) {
			numUnavailable++;
		}
	}

	if (numUnavailable == 0)
		return;

	/* Remove records by copying in records starting with
	ones not unavailable. */
	for (i=0;i< *recCount;i++)
	{
		rec[i].AB_flag = rec[i+numUnavailable].AB_flag;
		rec[i].value.rat   = rec[i+numUnavailable].value.rat;
		rec[i].value.code   = rec[i+numUnavailable].value.code;
	}

	(*recCount) -= numUnavailable;

}	
/******************************************************************************/
void loadAB(Record_1d rec[], float AB[], int recCount)
{
	int i = 0;

	for(i=0;i<recCount;i++)
	{
		if (rec[i].AB_flag == A)
			AB[i] = 1;
		else
			AB[i] = 0;
		
	}
}
/******************************************************************************
*	Want all consecutive duplicates to get their AB values averaged out.
*******************************************************************************/
void averageDuplicates(Record_1d rec[], float AB[], int recCount)
{
	int i = 0, k;
	int iSub;
	float consecTotal;		// consecutive total
	int consecCount = 0;
	float average;

	while(i<recCount-1)
	{
		consecCount = 0;
		consecTotal = 0;


 		if (rec[i].value.rat == rec[i+1].value.rat)
		{
			iSub = i;
			while(rec[iSub].value.rat == rec[iSub+1].value.rat)
			{
				consecCount++;
				consecTotal += AB[iSub];
				iSub++;

				if (iSub >= recCount-1) break;
			}
			
			/* Get the last one of the sequence */
			consecTotal += AB[iSub];
			consecCount++;
			
	
			/* Calculate the average value */
			average = consecTotal / (float) consecCount;
			
			/* Average out the values */
			for (k=i; k<=iSub; k++) {
				AB[k] = average;
			}

			/* Don't have to loop over that part again */
			i = iSub;  

		}
	
		i++;
	}			// end while
}

/*eject*/
/******************************************************************************
*	Calculate the convolution value
*******************************************************************************/
void calculateConvolution(float AB[], float convolution[], int recCount,
						  float beta[], int locSigma)
{
	
	int i;
	float dummy = .5;   // Used as a filler
	int j;
	
	/* Calculate the convolution coefficents */
	getBetaValues(locSigma, beta);
	
	/* Calculate the sigma values, anything that goes out of bounds uses
	 * the dummy value.  This is okay because the indices that have out of bounds
	 * values (based on sigma) will not be used.  */
	for (i=0; i<recCount; i++)
	{
		convolution[i] = beta[0]*AB[i];

		for (j=1;j<=(2*locSigma);j++)
		{
			convolution[i] += (beta[j]*((i-j>=0)?AB[i-j]:dummy) ) +
						  (beta[j]*((i+j<recCount)?AB[i+j]:dummy));
		}
	}


	
}
/*****************************************************************************/
void getBetaValues(int locSigma, float beta[])
{
	int i;
	float sum;

	for (i=0;i<=(2*locSigma);i++)
	{
		beta[i] = (float) (1/(locSigma*sqrt(2*3.14159)) *
			               exp(-.5*((float)i/locSigma)*((float)i/locSigma)));
	}

	sum = beta[0];

	/* Add them up to normalize to 1 */
	for (i=1;i<=(2*locSigma);i++)
	{
		sum += 2*beta[i];
	}

	/* Normalize to 1 */
	for (i=0;i<=(2*locSigma);i++)
	{
		beta[i] = beta[i]/sum;
	}

}
/******************************************************************************/
void calculateCut(float convolution[], float cutValue[], int recCount)
{
	int i;

	cutValue[0] = 0;
	for (i=1; i<recCount; i++) 	{
		cutValue[i] = (float) fabs(convolution[i] - convolution[i-1]);
	}
}
/*******************************************************************************
*	In the case of a tie want to get the one closest to the middle.
********************************************************************************/
int getBiggestDropoff(int recCount, float cutValue[], int start, 
				float AB[], int locSigma)
{
	float max = 0;
	int tieCount = 0;
	int middle;
	int j;
	int returnIndex;
	
	/* Allocate array */
	memset(ties,0,sizeof(ties));

	for(j=start; j<recCount-(2*locSigma); j++)
	{
	  if (cutValue[j] >= max &&
		    AB[j] != AB[j-1])         
		{
			/* If strictly greater than current max, clear out ties */
			if (cutValue[j] > max) {
				memset(ties, 0, sizeof(ties));
				tieCount = 0;
				max = cutValue[j];
			}
			
			ties[tieCount] = j;	
			tieCount++;
		}
	}
		
	/* Of the ties pick the one closest to the middle */
	middle = (int) ((recCount-1)/2);

	/* If no valid cutpoint found return NONE_FOUND */
	if (tieCount==0) {
		return NONE_FOUND;
	}
	
	returnIndex = getClosestToMiddle(tieCount, ties, middle, 0, recCount-1);

	return returnIndex;


}

/*eject*/
/******************************************************************************
* Get the index closest to the middle within the given range.
*******************************************************************************/
int getClosestToMiddle(int tieCount, int ties[], int middle, int beg, int end)
{
	int i;
	int localMax;
	int diff;
	int minDiff;

        localMax = -1;

	/* Initialize to a maximum value */
	minDiff = 2 * middle + 1;

	for (i=0; i<tieCount; i++)
	{
		diff = abs(middle-ties[i]);

		/* If it is the one closest to the middle */
		if (diff < minDiff &&
			ties[i] >= beg &&
			ties[i] <= end )
		{
			localMax = ties[i];
			minDiff = diff;
		}
	}

	if (localMax==-1){
		fprintf(errfil, "Fatal error in getClosestToMiddle\n");
		cuterror("getClosestToMiddle", "103");
	}
	return localMax;
}
/***********************************************************************
* Compute usefulness of cutpoint
***********************************************************************/
float getUsefulness(Record_1d rec[], int recCount, int cutIndex)
{
  int nAleft = 0, nAright = 0, nBleft = 0, nBright = 0;
  float pAleft, pAright;
  float usefulness;
  int i;

  for (i=0; i<recCount; i++) {
    if (i <= (cutIndex-1)) {
      /* value is to left of cutpoint */
      if (rec[i].AB_flag == A) {
	nAleft++;
      } else {
	nBleft++;
      }
    } else {
      if (rec[i].AB_flag == A) {
	nAright++;
      } else {
	nBright++;
      }
    }
  }

  if (((nAleft+nBleft) == 0) |
      ((nAright+nBright) == 0)) {
    fprintf(errfil,"Fatal error in getUsefulness\n");
    cuterror("getUsefulness","101");
  }

  pAleft = nAleft;
  pAleft /= nAleft + nBleft;
  pAright = nAright;
  pAright /= nAright + nBright;

  usefulness  = pAleft * (1 - pAright);
  if (usefulness < ((1 - pAleft) * pAright)) {
    usefulness = (1 - pAleft) * pAright;
  }

  return usefulness;
}

/* last record of cutPoint.c *******/


