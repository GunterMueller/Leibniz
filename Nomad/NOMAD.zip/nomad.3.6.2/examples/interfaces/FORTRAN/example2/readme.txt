This example shows how to write a FORTRAN program calling NOMAD,
with a black-box routine written in FORTRAN.

It has been tested on a X system with g++ and gfortran.

Type 'make' to compile and './test.exe' to execute.
