//---------------------     formula.c begin     ----------------------
//
//  author:  Anja Remshagen
//  date:    July 16, 2003
//  
//  description:
//
//--------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "structs.h"
#include "fcts.h"
#include "macros.h"
#include "global.h"

//--------------------------------------------------------------------
//  int addRow (int *newRow, struct Rows *rws, struct Cols *cls)
//
//  pre condition:
//    Either newRow[0]==-1, or newRow contains a valid row,
//    possibly, a row of length 0.
//  description:
//    Add the row newRow to the rows rws and columns cls,
//    and update all statistics if newRows contains a row. 
//    Otherwise, rws and cls remains unchanged.
//  return value:
//    0: There was no new row, that is newRow[0]==-1 or
//       the new row was not added to to length limitations
//    1: The new row newRow was added to rws and cls.
//
//--------------------------------------------------------------------
/*eject*/
int addRow (int *newRow, struct Rows *rws, struct Cols *cls)
{
  int rw;
  int i;

  if (newRow[0] == -1) {
    return 0;
  }
  if (newRow[0] > MAX_ROW_LEN) {
    return 0;
  }

  // check if some rows need to be deleted 
  if (newRow[0]+rws->idxLast > rws->nLitMax  ||
      rws->n == rws->nMax) {
    rearrangeRows(rws,newRow[0]);
    regenCols(rws,cls);
  }
  else {
    // check if col needs to be regenerated
    for (i=1; i<=newRow[0]; i++) {
      if (cls->len[newRow[i]] == cls->lenMax[newRow[i]]) {
	regenCols(rws,cls);
	break;
      }
    }
  }

  if (newRow[0]+rws->idxLast > rws->nLitMax  ||
      rws->n == rws->nMax) {
    return 0;
  }

  rw = addToRows(newRow, rws);
  addToCols(rw, newRow, cls, rws);  

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int addToCols (int rw, int *newRow,
//	           struct Cols *cls, struct Rows *rws)
//
//  description:
//    add row newRow to column information cls.
//  return value:
//    1
//
//--------------------------------------------------------------------
int addToCols (int rw, int *newRow, 
	       struct Cols *cls, struct Rows *rws)
{
  int i, nPos, var, id;

  id = rws->id;

  // check if col needs to be resized
  for (i=1; i<=newRow[0]; i++) {
    if (cls->len[newRow[i]] == cls->lenMax[newRow[i]]) {
      printf("ERROR: addToCols needs to rearrange columns\n");
      exit(33);
    }
  }

  nPos = 0;
  cls->nLit += newRow[0];
  for (i=1; i<=newRow[0]; i++) {
    cls->col[cls->idx[newRow[i]]+cls->len[newRow[i]]] = rw; 
    cls->len[newRow[i]]++;
    var = abs(newRow[i]);
    // update decomposition into hard and easy part
    if (newRow[i] > 0 && cls->hard[var] == 0) {
      nPos++;
      if (nPos > 1) {
	cls->hard[var] = 1;
	if (vrs->val[id][var] == Free) {
	  cls->nHardAct++;
	}
      }
    }
  }

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int addToRows (int *newRow, struct Rows *rws)
//
//  description:
//    add row newRow to row information rws.
//  return value:
//    1
//
//--------------------------------------------------------------------
int addToRows (int *newRow, struct Rows *rws)
{
  int i, rw, var, id;

  if (newRow[0]+rws->idxLast > rws->nLitMax  ||
      rws->n == rws->nMax) {
    printf("ERROR: addToRows has not enough memory\n");
    exit(33);
  }

  // add row newRow to the end of rws->row
  rw = rws->n+1;
  rws->idx[rw] = rws->idxLast;
  rws->len[rw] = newRow[0];
  rws->lenAct[rw] = 0;
  rws->nTrue[rw]  = 0;
  rws->nFalse[rw] = 0;
  rws->act[rw] = 1; 
  id = rws->id;
  for (i=1; i<=newRow[0]; i++) {
    rws->row[rws->idx[rw]+i-1] = newRow[i];
    var = abs(newRow[i]);
    if (vrs->val[id][var] == Free) {
      rws->lenAct[rw]++;
    }
    else if ((newRow[i] > 0 && vrs->val[id][var] == True) ||
		     (newRow[i] < 0 && vrs->val[id][var] == False)) {
      rws->nTrue[rw]++;
      rws->act[rw] = 0;
    }
    else if ((newRow[i] > 0 && vrs->val[id][var] == False) ||
	      (newRow[i] < 0 && vrs->val[id][var] == True)) {
      rws->nFalse[rw]++;
    }
  }

  if (rws->act[rw] == 0) {
    rws->nSat++;
  }

  // update general row data
  rws->n++;
  rws->nLit += newRow[0];
  rws->idxLast += newRow[0];

  return rw;
}
/*eject*/
//--------------------------------------------------------------------
//  int checkCNF (struct CNF *cnf)
//
//  description:
//    check if all variables are fixed to the same value in R and S
//  return value:
//    1
//
//--------------------------------------------------------------------
int checkCNF (struct CNF *cnf)
{
  int i, lit, var;

  // check if variables are deleted
  // check if variables are assigned different values
  for (i=1; i<=cnf->n; i++) {
    if (vrs->val[1][i] == 10) {
      printf(" 10");
    }
    if (vrs->val[2][i] == 10) {
      printf(" 20");
    }
    if ((vrs->val[1][i] == 1 || vrs->val[1][i] == -1) &&
	vrs->val[2][i] == 0) {
      printf(" 1");
    }
    if ((vrs->val[2][i] == 1 || vrs->val[2][i] == -1) &&
	vrs->val[1][i] == 0) {
      printf(" 2");
    }
    if (vrs->val[1][i] == -1 && vrs->val[2][i] == 1) {
      printf(" -1");
    }
    if (vrs->val[2][i] == -1 && vrs->val[1][i] == 1) {
      printf(" -2");
    }
  }

  // check if variable fixing in tree corresponds
  // to fixing in R and S
  for (i=-cnf->n; i<=cnf->n; i++) {
    litFlg[i] = 0;
  }
  for (i=1; i<=tree->n; i++) {
    lit = tree->lit[i];
    var = abs(lit);
    litFlg[var] = 1;
    if (lit<0) {
      if (vrs->val[1][var] != -1) {
	printf(" TR%d",lit);
      }
      if (vrs->val[2][var] != -1) {
	printf(" TS%d",lit);
      }
    }
    else {
      if (vrs->val[1][var] != 1) {
	printf(" TR%d",lit);
      }
      if (vrs->val[2][var] != 1) {
	printf(" TS%d",lit);
      }
    }
  }
  for (i=1; i<=cnf->n; i++) {  
    if (vrs->val[1][i] != 0 &&
	litFlg[i] == 0) {
      printf(" R%d",i);
    }
    if (vrs->val[2][i] != 0 &&
	litFlg[i] == 0) {
      printf(" S%d",i);
    }
  }
  for (i=-cnf->n; i<=cnf->n; i++) {
    litFlg[i] = 0;
  }

  printf("end\n");
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int decompose (struct Rows* rws, struct Cols* cls)
//
//  precondition:
//    rws->nTrue[i] == 0  for all rows i
//    vrs->val[rws->id][var] = Free  for all variables var
//    cls->nHardAct == cnf->n
//  description:
//    Partition the columns of the formula rws/cls into two sets
//    so that one set of clauses induces a Horn formula.
//  return value:
//    1
//--------------------------------------------------------------------
int decompose (struct Rows* rws, struct Cols* cls)
{
  int cli, rwi, i;

  // nTrue
  for (cli = 1; cli <= cnf->n; cli++) {
    for (i=0; i<cls->len[cli]; i++) {
      rwi = cls->col[i+cls->idx[cli]];
      rws->nTrue[rwi]++;
      if (rws->nTrue[rwi] > 1) {
	break;
      }
    }
    // if the loop was completed, the current column belongs
    // to the easy part
    if (i == cls->len[cli]) {
      cls->hard[cli] = 0;
      cls->nHardAct--;
    }
    // the loop was not completed, update the counter of 
    // positive literals per row nTrue
    else {
      for (; i>=0; i--) {
	rwi = cls->col[i+cls->idx[cli]];
	rws->nTrue[rwi]--;
      }      
    }
  }

  // reset rws->nTrue[i] to 0 for all rows i
  for (rwi=1; rwi <= rws->n; rwi++) {
    rws->nTrue[rwi]= 0;
  }

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int delRow (int rwdel, struct Rows *rws, struct Cols *cls)
//
//  precondition:
//    the row with index delrw exists in formula rws/cls
//  description:
//    Delete row rwdel from rws/cls. Update all row and col data.
//  return value:
//    1
//
//--------------------------------------------------------------------
int delRow (int rwdel, struct Rows *rws, struct Cols *cls)
{
  printf("ERROR: delRow should never be called\n");

  //------------------------------------------------------------------
  //   delete the column data of row rwdel
  //   CAUTION: this steps needs to be performed before the row
  //            data is deleted
  //------------------------------------------------------------------
  delFromCols(rwdel,rws,cls);

  //   delete row data of row rwdel
  delFromRows(rwdel,rws,cls);

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int delFromCols (int rwdel, struct Rows *rws, struct Cols *cls)
//
//  precondition:
//    the row with index delrw exists in formula rws/cls
//  description:
//    Delete column data of row rwdel from cls.
//  return value:
//    1
//
//--------------------------------------------------------------------
int delFromCols (int rwdel, struct Rows *rws, struct Cols *cls)
{
  int j, i, cli;

  for (j=0; j<rws->len[rwdel]; j++) {
    cli = rws->row[j+rws->idx[rwdel]];

    // find rwdel in column cli
    for (i=0; i<cls->len[cli]; i++) {
      if (cls->col[i+cls->idx[cli]]== rwdel) {
	break;
      }
    }
    cls->len[cli]--;
    cls->col[i+cls->idx[cli]] = cls->col[cls->len[cli]+cls->idx[cli]];
  }
  cls->nLit = cls->nLit - rws->len[rwdel];

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int delFromRows (int rwdel, struct Rows *rws, struct Cols *cls)
//
//  precondition:
//    the row with index delrw exists in formula rws/cls
//  description:
//    Delete row data of row rwdel from rws.
//    Update original index rws->n to rwdel in cls.
//  return value:
//    1
//
//--------------------------------------------------------------------
int delFromRows (int rwdel, struct Rows *rws, struct Cols *cls)
{
  int j, i, cli;

  //   update index rws->n to rwdel in cls
  for (j=0; j<rws->len[rws->n]; j++) {
    cli = rws->row[j+rws->idx[rws->n]];
    // find rws->n in column cli and set to rwdel
    for (i=0; i<cls->len[cli]; i++) {
      if (cls->col[i+cls->idx[cli]] == rws->n) {
	cls->col[i+cls->idx[cli]] = rwdel;
	break;
      }
    }
  }

  // delete row data of row rwdel
  rws->nLit = rws->nLit - rws->len[rwdel];
  if (rws->act[rwdel] == 0) {
    rws->nSat--;
  }
  rws->idx[rwdel]    = rws->idx[rws->n];
  rws->len[rwdel]    = rws->len[rws->n];
  rws->lenAct[rwdel] = rws->lenAct[rws->n];
  rws->act[rwdel]    = rws->act[rws->n];
  rws->nTrue[rwdel]  = rws->nTrue[rws->n];
  rws->nFalse[rwdel] = rws->nFalse[rws->n];

  rws->n--;
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int delVarIn (struct Rows* rws, struct Cols* cls, int var)
//
//  description:
//    delete variable var in rws/cls.
//    CAUTION: other cnf formula is inconsistent since the row and
//             column data is not modified; if the other formula was
//             fixed to true or false, the truth value is retained 
//             by setting the corresponding bit to 1 in vrs->val[var].
//  return value:
//    1
//
//--------------------------------------------------------------------
int delVarIn (struct Rows* rws, struct Cols* cls, int var)
{
  int id, cli, rwi, i;

  id = rws->id;
  //--------------------------------------------
  //   check if variable has not been deleted
  //--------------------------------------------
  if (vrs->val[id][var] == Del) {
    //   variable has been deleted
    printf("ERROR: variable has been deleted already\n");
    exit(205);
  }
  //-------------------------------------------------
  //   update column and row data if free variable 
  //-------------------------------------------------
  if (vrs->val[id][var] == Free) {
    if (cls->hard[var] == 1) {
      cls->nHardAct--;
    }
    cli = var;
    for (i=0; i<cls->len[cli]; i++) {
      rwi = cls->col[cls->idx[cli]+i];
      rws->lenAct[rwi]--;
    }
    cli = -var;
    for (i=0; i<cls->len[cli]; i++) {
      rwi = cls->col[cls->idx[cli]+i];
      rws->lenAct[rwi]--;
    }
  }
  //---------------------------------------
  //   update row data if fixed variable
  //   (column data is okay)
  //---------------------------------------
  else {
    // update column set to true
    if (vrs->val[id][var] == True) {
      cli = var;
    }
    else {
      cli = -var;
    }
    for (i=0; i<cls->len[cli]; i++) {
      rwi = cls->col[cls->idx[cli]+i];
      rws->nTrue[rwi]--;
      if (rws->nTrue[rwi] == 0) {
	rws->act[rwi] = 1;
	rws->nSat--;
      }
    }
    // update column set to false
    cli = -cli;
    for (i=0; i<cls->len[cli]; i++) {
      rwi = cls->col[cls->idx[cli]+i];
      rws->nFalse[rwi]--;
    }    
  }
  
  vrs->val[id][var] = Del;
  
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int fixAsgnIn (struct Rows *rws, struct Cols *cls, int lit)
//
//  precondition:
//    the literal asgn->lit is not fixed and not deleted
//  postcondition:
//    fix literal asgn->lit to True in the given rows rws and 
//    columns cls:
//    1) visit all rows that contain literal asgn.lit
//       a) if row not yet satisfied then
//          set rowstate = True and increment no. satisfied rows 
//       b) decrement no. of active literals 
//       c) increment no. of True literals
//    2) visit all rows that contain literal -asgn.lit
//       a) decrement no. of active literals
//       b) increment no. of False literals
//       c) if the rowstate is undetermined and 
//          all literals are False then
//          set rowstate = False and increment no. of False rows
//       c) if the rowstate is undetermined and 
//          all but one literals are False then
//          add remaining literal to unitList
//  return value
//    -1  if the no. of False rows >= 1
//     1  if all rows are True
//     0  otherwise
//
//--------------------------------------------------------------------
int fixAsgnIn (struct Rows *rws, struct Cols* cls, int fixlit) 
{
  int i, rwi, j, cli, lit;
  int var, val;
  int rc;
  int id;

  id = rws->id;

  if (fixlit > 0) {
    var = fixlit;
    val = True;
  }
  else {
    var = -fixlit;
    val = False;
  }

  // check if variable already fixed in current formula
  // or if variable has been deleted
  if (vrs->val[id][var] == Del) {
	printf("ERROR: tried to fix variable %d that has been"
		" deleted\n",var);
	exit(10);
  }
  else if (vrs->val[id][var] != Free) {
    printf("ERROR: tried to fix variable %d that has been already"
		" fixed\n",var);
	exit(10); 
  }
  
  //------------------------------------------------------------------
  //   fix variable 
  //------------------------------------------------------------------
  // update statistics
  if (cls->hard[var] == 1) {
    cls->nHardAct--;
  }
  
  vrs->val[id][var] = val;
  
  // update now satisfied rows
  rc = 0;
  for (i=0; i<cls->len[fixlit]; i++) {
    rwi = cls->col[i+cls->idx[fixlit]];
    rws->lenAct[rwi]--;
    rws->act[rwi] = 0;
    rws->nTrue[rwi]++;
    if (rws->nTrue[rwi] == 1) {
      rws->nSat++;
    }
  }
  // update still unsatisfied rows
  for (i=0; i<cls->len[-fixlit]; i++) {
    rwi = cls->col[i+cls->idx[-fixlit]];
    rws->lenAct[rwi]--;
    rws->nFalse[rwi]++;
    
    //--------------------------------
    //   check for unit row
    //--------------------------------
    if (rws->act[rwi] == 1) {
      if (rws->lenAct[rwi] == 1) {
	// find unit literal and add it to the unit queue or
	// candidate queue respectively
	for (j=0; j<rws->len[rwi]; j++) {
	  lit = rws->row[rws->idx[rwi]+j];
	  cli = abs(lit);
	  if (vrs->val[id][cli] == Free) {
	    if (id == 2 && cli <= vrs->nQ) {
	      // add literal to candidate list
	      qLit->n++;
	      qLit->lit[qLit->n] = lit;
	      qLit->info[qLit->n] = -1;
	    }
	    else {
	      // add literal to unit list
	      unitLit->n++;
	      unitLit->lit[unitLit->n] = lit;
	      if (rws->id == 1) {
		unitLit->info[unitLit->n] = rwi;
	      }
	      else {
		unitLit->info[unitLit->n] = 0;
	      }
	    }
	    break;
	  }
	}
      }
      else if (rws->lenAct[rwi] == 0) {
	rc = -1;
      }
    }
  }
  
  if (rws->nSat == rws->n) {
    rc = 1;
  }
  
  return rc;
}
/*eject*/
//--------------------------------------------------------------------
//  int freeVar (int var)
//
//  description:
//    Free variable var.
//
//  return value:
//    1: var is freed in R, var was not fixed in S
//    2: var is freed in S, var was not fixed in R
//    3: var is freed in R and in S
//    0: variable was not fixed previously
//
//--------------------------------------------------------------------
int freeVar (int var)
{
  int result;

  result = 0;
  result += freeVarIn(rwsR,clsR,var);
  result += freeVarIn(rwsS,clsS,var);

  if (result == 0) {
	printf("Error: tried to free unfixed variable %d\n",var);
	exit(21);
  }

  return result;
}
/*eject*/
//--------------------------------------------------------------------
//  int freeVarIn (struct Rows* rws, struct Cols *cls, int var)
//
//  description:
//    Free variable var.
//
//  return value:
//    rws->id: var was fixed in rws and cls and is freed
//    0:       var was not fixed in rws and cls
//
//--------------------------------------------------------------------
int freeVarIn (struct Rows* rws, struct Cols *cls, int var)
{
  int lit, i, rwi, id;

  id = rws->id;
  //---------------------------------------
  //   determine previous variable value
  //---------------------------------------
  if (vrs->val[id][var] == True) {
    lit = var;
  }
  else if (vrs->val[id][var] == False) {
    lit = -var;
  }
  else if (vrs->val[id][var] == Del) {
    printf("ERROR: try to free deleted variable\n");
	exit(307);
  }
  else {
    // variable has not been fixed in rws and cls
    return 0;
  }
  vrs->val[id][var] = Free;

  if (cls->hard[var] == 1) {
    cls->nHardAct++;
  }

  //------------------------------------------------------------------
  //   free lit in each row 
  //------------------------------------------------------------------
  for (i=0; i<cls->len[lit]; i++) {
    rwi = cls->col[i+cls->idx[lit]];
	rws->lenAct[rwi]++;
	rws->nTrue[rwi]--;
	if (rws->nTrue[rwi] == 0) {
	  rws->act[rwi] = 1;  
	  rws->nSat--;
	}
  }
  //------------------------------------------------------------------
  //   free -lit in each row 
  //------------------------------------------------------------------
  for (i=0; i<cls->len[-lit]; i++) {
    rwi = cls->col[i+cls->idx[-lit]];
	rws->lenAct[rwi]++;
	rws->nFalse[rwi]--;
  }

  return id;
}
/*eject*/
//--------------------------------------------------------------------
//  int genCols (struct Rows *rws, struct Col* cls)
//
//  description:
//    Generate the column information from the row information rws.
//    Save the data in cls.
//
//--------------------------------------------------------------------
int genCols (struct Rows *rws, struct Cols* cls)
{
  int i,j,l;
  int nLitFreePerCol, nLitFree, k;

  // allocate memory
  cls->nLit = rws->nLit;
  cls->nLitMax = rws->nLitMax;
  if (rws->id == 1) {
    cls->nLitMax += 2*vrs->nQ;
  }
  cls->idx = calloc((2*cnf->n)+1,sizeof(int));
  cls->len = calloc((2*cnf->n)+1,sizeof(int));
  cls->lenMax = calloc((2*cnf->n)+1,sizeof(int));
  cls->col = calloc(cls->nLitMax,sizeof(int));
 
  // initialize col length and col index
  cls->len = cls->len+cnf->n;
  for (i=-cnf->n; i<=cnf->n; i++) {
	cls->len[i] = 0;
  }
  for (i=1; i<=rws->n; i++) {
    for (j=0; j < rws->len[i]; j++) {
      l = rws->row[j+rws->idx[i]];
      cls->len[l]++;
    }
  }

  // determine cls->lenMax[i] and cls->idx[i]
  cls->lenMax = cls->lenMax + cnf->n;
  cls->idx = cls->idx + cnf->n;

  nLitFree = cls->nLitMax - cls->nLit;
  nLitFreePerCol = nLitFree / (2*vrs->nQ);
  k = nLitFree - (2 * vrs->nQ * nLitFreePerCol);

  cls->idx[-cnf->n] = 0;
  for (i=-cnf->n; i<cnf->n; i++) {
    if (i == 0) {
      cls->lenMax[i] = 0;
    }
    else if (i < -vrs->nQ || i > vrs->nQ) {
      cls->lenMax[i] = cls->len[i];
    }
    else {
      cls->lenMax[i] = cls->len[i] + nLitFreePerCol;
      if (k > 0) {
	k--;
	cls->lenMax[i]++;
      }
    }
    cls->idx[i+1] = cls->idx[i] + cls->lenMax[i];
  }
  cls->lenMax[cnf->n] = cls->nLitMax - cls->idx[cnf->n];
 
  // initialize row information for each column
  for (i=-cnf->n; i<=cnf->n; i++) {
    cls->len[i] = 0;
  }
  for (i=1; i<=rws->n; i++) {
    for (j = 0; j < rws->len[i]; j++) {
      l = rws->row[j+rws->idx[i]];
      cls->col[cls->idx[l]+cls->len[l]] = i;
      cls->len[l]++;
    }
  }
  
  cls->hard = calloc(cnf->n+1,sizeof(int));
  cls->nHardAct = cnf->n;
  for (i=1; i<=cnf->n; i++) {
    cls->hard[i] = 1;
  }
  
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int getVarIdx (char *name)
//
//  description:
//    determine the index of the variable name
//  return value:
//    0   if there is no variable with name "name" 
//    >0  index of the variable name
//--------------------------------------------------------------------
int getVarIdx (char *name)
{
  int i;

  for (i=1; i<=cnf->n; i++) {
    if (strcmp(vrs->name[i],name) == 0) {
	return i;
    }
  }
  return 0;
}
/*eject*/
//--------------------------------------------------------------------
//  int lowercase (char *word)
//
//  description:
//    change all uppercase letters in word to lowercase letters.
//  return value:
//    1
//
//--------------------------------------------------------------------
int lowercase (char *word)
{
  int i;
  for (i=0; i < strlen(word); i++) {
    word[i] = tolower(word[i]);
  }
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int nextWord (char *word)
//
//  description:
//    read the next word from the input file that is not a 
//    comment. treat the symbols '-', '|', and '.' as separate 
//    words that do not need to be separated from other words by
//    a white space character.
//  return value:   
//    1  if the next word is contained in word
//    0  if all words have been read
//--------------------------------------------------------------------
int nextWord (char* word) 
{
  int i;

  // read until the beginning of a string is reached
  while (readC != EOF && 
	 (readComment == 1 || isspace(readC) || readC == '*') &&
	 (readComment == 1 || readC != '.') && 
	 (readComment == 1 || readC != '-') &&
	 (readComment == 1 || readC != '|')) {
	if (readC == '*') {
	  readComment = 1;
	}
    if (readComment == 1 && readC == '\n') {
	  readComment = 0;
	}
    readC = getc(finput);
  }

  if (readC == EOF) {
    word[0] = '\0';
    return 0;
  }

  if (readC == '.' || readC == '-' || readC == '|') {
    word[0] = readC;
    word[1] = '\0';
    readC = getc(finput);
    return 1;
  }
  
  i = 0;
  while (readC != EOF && readC != '*' && !isspace(readC) 
	 && readC !='.' && readC != '|') {
    word[i] = readC;
    i++;
    readC = getc(finput);
  }

  word[i] = '\0';
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int nextWordSetup ()
//
//  description:
//    initialize variables for function nextWord
//  return value:   
//    1
//--------------------------------------------------------------------
int nextWordSetup () 
{
  readComment = 0;
  readC = ' ';
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int printCNF (struct CNF *cnf)
//
//  description:
//    print the content of structure cnf on screen
//
//--------------------------------------------------------------------
int printCNF (struct CNF *cnf)
{
  printf("\n*****   cnf content   *****\n");
  printf("name: %s\n",cnf->name);

  printVars(cnf->vars);
  printRows(cnf->rowsR);
  printCols(cnf->colsR);
  printRows(cnf->rowsS);
  printCols(cnf->colsS);

  printf("*****   end of cnf content   *****\n");
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int printCols (struct Rows *cls)
//
//  description:
//    print the content of structure cls on screen
//
//--------------------------------------------------------------------
int printCols (struct Cols* cls)
{
  int i, j, r;

  printf("*****   col content   *****\n");

  printf("no. cols %d\n",cnf->n);
  printf("no. literals %d (maximum %d)\n",cls->nLit, cls->nLitMax);
  printf("no. act hard vars %d\n",cls->nHardAct);
 
  printf("col hard len(Max) ...rows...\n");
  for (i=-cnf->n; i<=cnf->n; i++) {    
    if (i > 0) {
      printf("%3d%4d ",i, cls->hard[i]);
    }
    else {
      printf("%3d   - ",i);
    }
    printf("%3d (%2d)",cls->len[i], cls->lenMax[i]);
    for (j = 0; j < cls->len[i]; j++) {
      r = cls->col[j+cls->idx[i]];
      printf("%5d",r);
    }  
    printf("\n");
  }
  printf("*****   end of col content   *****\n");
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int printRows (struct Rows *rws)
//
//  description:
//    print the content of structure vrs on screen
//
//--------------------------------------------------------------------
int printRows (struct Rows* rws)
{
  int i, j, l;

  printf("*****   row %d content   *****\n",rws->id);

  printf("no. rows %d (org %d, max %d)\n",rws->n,rws->nOrg,rws->nMax);
  printf("no. literals %d (max %d)\n",rws->nLit, rws->nLitMax);
  printf("no. satisfied rows %d\n",rws->nSat);
  printf("  idxLast %d\n",rws->idxLast);
 
  for (i=1; i<=rws->n; i++) {
    printf("row %3d: ",i);
    for (j = 0; j < rws->len[i]; j++) {
      l = rws->row[j+rws->idx[i]];
      printf("%3d (%s)",l,cnf->vars->name[abs(l)]);
    }  
    printf("\n          lenAct:%3d true:%3d false:%3d act:%3d\n",
	   rws->lenAct[i], rws->nTrue[i], 
	   rws->nFalse[i], rws->act[i]);
  }
  printf("*****   end of row content   *****\n");
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int printVars (struct Vars *vrs)
//
//  description:
//    print the content of structure vrs on screen
//
//--------------------------------------------------------------------
int printVars (struct Vars* vrs)
{
  int i;

  printf("*****   variable content   *****\n");
  printf("no. variables %d\n",cnf->n);
  printf("no. Q variables %d\n",vrs->nQ);
  printf("no. X variables %d\n",vrs->nX);
  printf("no. Y variables %d\n",vrs->nY);
  for (i=1; i<=cnf->n; i++) {
	  printf("%3d %s %3d %3d\n",i,vrs->name[i],
			vrs->val[1][i],vrs->val[2][i]);
  }
  printf("*****   end of variable content   *****\n");
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int readFormula (char *input)
//
//  description:
//    read the qallsat instance
//    generate all data (column data)
//
//--------------------------------------------------------------------
int readFormula (char *input) 
{
  // open input file
  nextWordSetup();
  if ((finput = fopen(input,"r")) == NULL) {
    printf("Error: Cannot open input file %s\n",input);
    exit(10);
  }

  // allocate memory for the structures
  cnf = malloc(sizeof(struct CNF));
  cnf->vars  = malloc(sizeof(struct Vars));
  cnf->rowsR = malloc(sizeof(struct Rows));
  cnf->colsR = malloc(sizeof(struct Cols));
  cnf->rowsS = malloc(sizeof(struct Rows));
  cnf->colsS = malloc(sizeof(struct Cols));

  readPrbName();

  readVars(input);

  rwsR = cnf->rowsR;
  rwsR->id = 1;
  readRows(rwsR,input);
  clsR = cnf->colsR;
  genCols(rwsR,clsR);

  rwsS = cnf->rowsS;
  rwsS->id = 2;
  readRows(rwsS,input);
  clsS = cnf->colsS;
  genCols(rwsS,clsS);

  decompose(rwsR,clsR);
  decompose(rwsS,clsS);

  fclose(finput);
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int readPrbName ()
//
//  description:
//    read the problem name
//
//--------------------------------------------------------------------
int readPrbName () 
{
  char word[100+1];

  nextWord(word);
  lowercase(word);

  if (strcmp(word,"satisfy") != 0) {
    printf("Error: Keyword satisfy\n missing");
    exit(11);
  }

  nextWord(word);
  cnf->name = calloc(strlen(word)+1, sizeof(char));
  strcpy(cnf->name,word);

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int readRows (struct Rows *rws, char *input)
//
//  description:
//    Read all rows of a CNF formula. Save the information in rws.
//    Allocate memory for range information 
//--------------------------------------------------------------------
int readRows (struct Rows *rws, char *input)
{
  char word[100+1];
  char wordLower[100+1];
  int nLit, nLitAll, nRwsAll;
  int rwi, var;
  int state;
  int sign;

  //------------------------------------------------------------------
  //   determine the number of rows and the number of literals 
  //------------------------------------------------------------------
  rws->n = 0;
  rws->nLit = 0;
  nLit = 0;
  nLitAll = 0;
  nRwsAll = 0;
  state = 0;
  while (nextWord(word) == 1 &&
	 lowercase(word) == 1 &&
	 strcmp(word,"endata") != 0) { 
    switch (state) {
    case 0:  // read a variable or a negation sign
    case 1:  // read a variable
      if (word[0] == 'q' || word[0] == 'x' || word[0] == 'y') {
	nLit++;
	nLitAll++;
	state = 2;
      }
      else if (strcmp(word,"-") == 0 ||
	       strcmp(word,"or")) {
	if (state == 1) {
	  printf("ERROR: invalid double negation\n");
	  exit(15);
	}
	state = 1;
      }
      else {  // strcmp(word,'-') != 0
	printf("ERROR: literal expected\n");
	exit(15);
      }
      break;
    case 2:  // end of clause marker "." or connective "or" 
             // or "|" expected
      if (strcmp(word,"or") == 0 || strcmp(word,"|") == 0) {
	state = 0;
      }
      else if (strcmp(word,".") == 0) {
	state = 10;
      }
      else {
	printf("ERROR: connective or end of clause expected\n");
	exit(15);
      }
      break;
    case 10:  // expect keyword "name"
      if (strcmp(word,"name") != 0) {
	printf("ERROR: expect 'NAME' or 'name after clause '.'\n");
        printf("       but have = %s\n",word);
	exit(15);
      }
      state = 11;
      break;
    case 11:  // read name of clause
      if (word[0] != 'r' && word[0] != 's') {
	printf("ERROR: expect clause name start = 'r' or 's'\n");   
        printf("       but have clause name = %s\n",word);
	exit(15);
      }
      else if ((rws->id == 1 && word[0] == 'r') ||
	       (rws->id == 2 && word[0] == 's')) {
        // valid clause of this current cnf formula
	rws->n++;
	rws->nLit += nLit;
	nLit = 0;
      }
      nLit = 0;
      state = 0;
      nRwsAll++;
      break;
    } 
  }
/*eject*/
  fclose(finput);
  nextWordSetup();
  if ((finput = fopen(input,"r")) == NULL) {
    printf("Error: Cannot open input file %s\n",input);
    exit(10);
  }
  while (nextWord(word) == 1 &&
	 lowercase(word) == 1 &&
	 strcmp(word,"facts") != 0);

  //------------------------------------------------------------------
  //   read and store the rows information
  //------------------------------------------------------------------
  if (rws->id == 1) {
    // allocate additional memory for formula R since 
    // learning of clauses can increase the formula
    rws->nMax = 7 * nRwsAll;
    rws->nLitMax = 20 * rws->nMax;
  }
  else {
    rws->nMax = rws->n;
    rws->nLitMax = rws->nLit;
  }
  rws->idx = calloc(rws->nMax+1,sizeof(int));
  rws->len = calloc(rws->nMax+1,sizeof(int));
  rws->row = calloc(rws->nLitMax,sizeof(int));

  rwi = 1;
  nLit = 0;
  rws->idx[0] = 0;
  rws->len[0] = 0;
  rws->idx[1] = 0;
  rws->len[1] = 0;
  sign = 1;
  while (rwi <= rws->n) { 
    nextWord(word);
    strcpy(wordLower,word);
    lowercase(wordLower);
    
    if (strcmp(wordLower,"-") == 0 ||
	strcmp(word,"not") == 0) {
      sign = -1;
    }
    else if (strcmp(word,".") == 0) {
      nextWord(word);
      nextWord(word);
      if ((rws->id == 1 && (word[0] == 'r' || word[0] == 'R')) ||
	       (rws->id == 2 && (word[0] == 's' || word[0] == 'S'))) {
        //  have read a valid clause
	//  setup next row
	rwi++;
	if (rwi <= rws->n) {
	  rws->len[rwi] = 0;
	  rws->idx[rwi] = rws->idx[rwi-1]+rws->len[rwi-1];
	}
      }
      else {
	// recently read clause does not belong to current formula 
	nLit -= rws->len[rwi];
	rws->len[rwi] = 0;	
      }
    }
    else if (strcmp(wordLower,"or") != 0 &&
	     strcmp(wordLower,"|") != 0 &&
	     nLit < rws->nLit) {
      //   word is a variable of current clause with sign sign            
      if ((var = getVarIdx(word)) == 0) {
	printf("ERROR: invalid variable name %s\n",word);
	exit(16);
      }
      rws->row[rws->len[rwi]+rws->idx[rwi]] = sign*var;
      rws->len[rwi]++;
      nLit++;
      sign = 1;
    }
  }

  // check if a y variable is used in R
  if (rws->id == 1) {
    for (nLit=0; nLit<rws->nLit; nLit++) {
      var = abs(rws->row[nLit]);
      if (vrs->name[var][0] == 'y' ||
	  vrs->name[var][0] == 'Y') {
	printf("ERROR: invalid variable in formula R\n");
	exit(17);
      }
    }
  }
  // check if a x variable is used in S
  if (rws->id == 2) {
    for (nLit=0; nLit<rws->nLit; nLit++) {
      var = abs(rws->row[nLit]);
      if (vrs->name[var][0] == 'x' ||
	  vrs->name[var][0] == 'X') {
	printf("ERROR: invalid variable in formula S\n");
	exit(17);
      }
    }
  }
/*eject*/
  //------------------------------------------------------------------
  //   generate row statistics
  //------------------------------------------------------------------
  rws->nSat = 0;
  rws->lenAct = calloc(rws->nMax+1,sizeof(int));
  rws->nTrue  = calloc(rws->nMax+1,sizeof(int));
  rws->nFalse = calloc(rws->nMax+1,sizeof(int));
  rws->act    = calloc(rws->nMax+1,sizeof(int));
  for (rwi=1; rwi<=rws->n; rwi++) {
	rws->lenAct[rwi] = rws->len[rwi];
	rws->nTrue[rwi] = 0;
	rws->nFalse[rwi] = 0;
	rws->act[rwi] = 1;
  }
  rws->idxLast = rws->idx[rws->n]+rws->len[rws->n];
  rws->nOrg = rws->n;

  fclose(finput);
  nextWordSetup();
  if ((finput = fopen(input,"r")) == NULL) {
    printf("Error: Cannot open input file %s\n",input);
    exit(10);
  }
  while (nextWord(word) == 1 &&
	 lowercase(word) == 1 &&
	 strcmp(word,"facts") != 0);

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int readVars (char *input)
//
//  precondition:
//    finput is a filepointer to the file with name input.
//    input contais a Variable section but not a set and 
//    predicate section.
//  description:
//    read all variable names from file input and store the 
//    information in cnf->vrs.
//
//--------------------------------------------------------------------
int readVars (char *input)
{
  int i, iQ, iX, iY, n;
  int rc;
  char name[100+1];
  
  vrs = cnf->vars;
  //------------------------------------------------------------------
  //   count the number of variables
  //------------------------------------------------------------------
  cnf->n = 0;  
  vrs->nQ = 0;
  vrs->nX = 0;
  vrs->nY = 0;
  nextWord(name);
  lowercase(name);
  if (strcmp(name,"variables") == 0) {
    rc = nextWord(name);
    lowercase(name);
    while (rc == 1 && 
	   strcmp(name,"sets") != 0 &&
	   strcmp(name,"facts") != 0 ) {
      cnf->n++;
      if (name[0] == 'q') {
	vrs->nQ++;
      }
      else if (name[0] == 'x') {
	vrs->nX++;
      }
      else if (name[0] == 'y') {
	vrs->nY++;
      }
      else {
	printf("\nERROR: Invalid variable name\n");
	exit(14);
      }
      rc = nextWord(name);
      lowercase(name);
    }
  }
  else {
    printf("Error: No valid variables are defined in the"
	   " input file\n");
    exit(13);
  }
/*eject*/
  // close and reopen the input file to read the variable names
  fclose(finput);
  nextWordSetup();
  if ((finput = fopen(input,"r")) == NULL) {
    printf("Error: Cannot open input file %s\n",input);
    exit(10);
  }
  while (nextWord(name) == 1 && 
	 lowercase(name) == 1 &&
	 strcmp(name,"variables") != 0);

  //------------------------------------------------------------------
  //   read the variable names
  //------------------------------------------------------------------
  vrs->name = calloc(cnf->n+1,sizeof(char*));
  iQ = 0;
  iX = vrs->nQ;
  iY = vrs->nQ + vrs->nX;
  n = 0;
  while (n < cnf->n) {
    nextWord(name);
    n++;
    if (name[0] == 'q' || name[0] == 'Q') {
      iQ++;
      i = iQ;
    }
    else if (name[0] == 'x' || name[0] == 'X') {
      iX++;
      i = iX;
    }
    else if (name[0] == 'y' || name[0] == 'Y') {
      iY++;
      i = iY;
    }
    else {
      printf("\nERROR: invalid variable name\n");
      exit(101);
    }
    vrs->name[i] = calloc(strlen(name)+1,sizeof(char));
    strcpy(vrs->name[i],name);
  }

  vrs->val = calloc(2,sizeof(int*));
  vrs->val -= 1;
  vrs->val[1] = calloc(cnf->n+1,sizeof(int));
  vrs->val[2] = calloc(cnf->n+1,sizeof(int));
  for (i=1; i<=cnf->n; i++) {
    vrs->val[1][i] = 0;
	vrs->val[2][i] = 0;
  }

  while (strcmp(name,"facts") != 0 &&
	 nextWord(name) == 1 &&
	 lowercase(name) == 1);
	 
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int rearrangeRows (struct Rows* rws, int s)
//
//  description:
//    delete some of the learned rows,
//    shift all rows to the left to free unused space between rows
//    (due to deletion of rows).
//  return value:
//    1
//
//--------------------------------------------------------------------
int rearrangeRows (struct Rows* rws, int s)
{
  int rwdel;
  int rwi,rwj;
  int j;
  int *row;

  //printf("Rearrange Rows\n");

  // delete the first third of the learned rows
  // that are the rows with index rws->nOrg+1,..rwdel
  rwdel = rws->nMax - rws->nOrg;
  rwdel = (rwdel+2)/3;
  rwdel = rws->nOrg + rwdel;

  row = rws->row;

  // shift the last two third of learned rows to the left
  
  rwj = rws->nOrg;
  for (rwi=rwdel+1; rwi<=rws->n; rwi++) {
    rwj++;
    rws->idx[rwj]    = rws->idx[rwj-1] + rws->len[rwj-1];
    rws->len[rwj]    = rws->len[rwi];
    rws->lenAct[rwj] = rws->lenAct[rwi];
    rws->act[rwj]    = rws->act[rwi];
    rws->nTrue[rwj]  = rws->nTrue[rwi];
    rws->nFalse[rwj] = rws->nFalse[rwi];
    
    for (j=0; j<rws->len[rwi]; j++) {
      row[j+rws->idx[rwj]] = row[j+rws->idx[rwi]];
    }    
  }
    
  rws->n = rwj;
  rws->idxLast = rws->idx[rws->n] + rws->len[rws->n];

  rws->nLit = 0;
  rws->nSat = 0;
  for (rwi=1; rwi<=rws->n; rwi++) {
    rws->nLit += rws->len[rwi];
    if (rws->nTrue[rwi] > 0) {
      rws->nSat++;
    }
  }

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int rearrangeRows1 (struct Rows* rws, int s)
//
//  description:
//    delete some of the learned rows,
//    shift all rows to the left to free unused space between rows
//    (due to deletion of rows).
//  return value:
//    1
//
//--------------------------------------------------------------------
int rearrangeRows1 (struct Rows* rws, int s)
{
  int delrow;
  int var,lit;
  int rwi,rwj;
  int j;
  int *row;
  int id;

  //printf("Rearrange Rows\n");
  row = rws->row;
  rwj = rws->nOrg;
  id = rws->id;
  for (rwi = rws->nOrg + 1; rwi<=rws->n; rwi++) {
    // check if rwi should be deleted    
    delrow = 0;
    for (j=MAX_ROW_LEN_ACT; j<rws->len[rwi]; j++) {
      lit = row[j+rws->idx[rwi]];
      var = abs(lit);
      if (vrs->val[id][var]*var == lit) {
	delrow = 1;
	break;
      }
    }

    if (delrow == 0) {
      // copy row rwi to rwj
      rwj++;
      rws->idx[rwj]    = rws->idx[rwj-1] + rws->len[rwj-1];
      rws->len[rwj]    = rws->len[rwi];
      rws->lenAct[rwj] = rws->lenAct[rwi];
      rws->act[rwj]    = rws->act[rwi];
      rws->nTrue[rwj]  = rws->nTrue[rwi];
      rws->nFalse[rwj] = rws->nFalse[rwi];
      for (j=0; j<rws->len[rwi]; j++) {
	row[j+rws->idx[rwj]] = row[j+rws->idx[rwi]];
      }    
    }
    else {
      printf("Delete row %d\n",rwi);
    }
  }

  if (rws->n == rwj) {
    printf("NO row has been deleted, have no memory left\n");
    exit(100);
  }
    
  rws->n = rwj;
  rws->idxLast = rws->idx[rws->n] + rws->len[rws->n];

  rws->nLit = 0;
  rws->nSat = 0;
  for (rwi=1; rwi<=rws->n; rwi++) {
    rws->nLit += rws->len[rwi];
    if (rws->nTrue[rwi] > 0) {
      rws->nSat++;
    }
  }

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int regenCols (struct Rows* rws, struct Cols* cls)
//
//  description:
//    regenerate the column data from the row information rws
//    
//  return value:
//    1
//
//--------------------------------------------------------------------
int regenCols (struct Rows* rws, struct Cols* cls)
{
  int i,j,l;
  int nLitFreePerCol, nLitFree, k;

  //printf("Regenerate Columns\n");

  // determine the column length
  for (i=-cnf->n; i<=cnf->n; i++) {
	cls->len[i] = 0;
  }
  for (i=1; i<=rws->n; i++) {
    for (j=0; j < rws->len[i]; j++) {
      l = rws->row[j+rws->idx[i]];
      cls->len[l]++;
    }
  }

  cls->nLit = rws->nLit;
  // determine cls->lenMax[i] and cls->idx[i]
  nLitFree = cls->nLitMax - cls->nLit;
  nLitFreePerCol = nLitFree / (2*vrs->nQ);
  k = nLitFree - (2 * vrs->nQ * nLitFreePerCol);

  cls->idx[-cnf->n] = 0;
  for (i=-cnf->n; i<cnf->n; i++) {
    if (i == 0) {
      cls->lenMax[i] = 0;
    }
    else if (i < -vrs->nQ || i > vrs->nQ) {
      cls->lenMax[i] = cls->len[i];
    }
    else {
      cls->lenMax[i] = cls->len[i] + nLitFreePerCol;
      if (k > 0) {
	k--;
	cls->lenMax[i]++;
      }
    }
    cls->idx[i+1] = cls->idx[i] + cls->lenMax[i];
  }
  cls->lenMax[cnf->n] = cls->nLitMax - cls->idx[cnf->n];
 
  // initialize row information for each column
  for (i=-cnf->n; i<=cnf->n; i++) {
    cls->len[i] = 0;
  }
  for (i=1; i<=rws->n; i++) {
    for (j = 0; j < rws->len[i]; j++) {
      l = rws->row[j+rws->idx[i]];
      cls->col[cls->idx[l]+cls->len[l]] = i;
      cls->len[l]++;
    }
  }
    
  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int resizeCols (struct Cols* cls, int s)
//
//  description:
//    add at least one free entry to each column.    
//    
//  return value:
//    1
//
//--------------------------------------------------------------------
int resizeCols (struct Cols* cls, int s)
{
  int cli, j;
  int *newcol;
  int newidx;

  printf("ERROR: resizeCols should never be called\n");
  
  // set s to be the maximum{s,nFreeLit,nLit/2,8*cnf->n}
  if (cls->nLit/2 > s) {
    s = cls->nLit;
  }
  if (8*cnf->n > s) {
    s = 8*cnf->n;
  }
  
  // set s to be the number of free entries per column
  s = s/(2*cnf->n) + 1;

  // allocate new memory for col
  cls->nLitMax = cls->nLit + s * 2*cnf->n;
  if ((newcol = calloc(cls->nLitMax,sizeof(int))) == NULL) {
    printf("ERROR: cannot allocate memory in resizeCols()\n");
  }

  // copy col data to newcol
  // update cls->idx and cls->lenMax
  
  for (cli = -cnf->n; cli <= cnf->n; cli++) {
    if (cli == -cnf->n) {
      newidx = 0;
    }
    else if (cli == 0) continue;
    else if (cli == 1) {
      newidx = cls->idx[-1] + cls->lenMax[-1];
    }
    else {
      newidx = cls->idx[cli-1] + cls->lenMax[cli-1];
    }

    for (j=0; j< cls->len[cli]; j++) {
      newcol[newidx+j] = cls->col[cls->idx[cli]+j];
    }
    cls->idx[cli] = newidx;
    cls->lenMax[cli] = cls->len[cli] + s;
  }
  free(cls->col);
  cls->col = newcol;

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int resizeRows (struct Rows* rws, int s)
//
//  description:
//    shift all rows to the left to free unused space between rows
//    (due to deletion of rows).
//    If there is less memory available than needed for s literals
//    or less memory than half of the already used one, then
//    allocate new memory.
//  return value:
//    1
//
//--------------------------------------------------------------------
int resizeRows (struct Rows* rws, int s)
{
  int rwi, j;
  int newindex;
  int *newrow;
  int *oldrow;
  int *newidx;
  int *newlen;
  int *newlenAct;
  int *newact;
  int *newnTrue;
  int *newnFalse;

  printf("ERROR: resizeRows should never be called\n");

  //------------------------------------------------------------------
  //   resize literal array
  //------------------------------------------------------------------
  if (s <= (rws->nLit)/2) {
    s = rws->nLit/2 + 1;
  }

  rws->nLitMax = rws->nLit + s;
  newrow = calloc(rws->nLitMax,sizeof(int));
  oldrow = rws->row;
    
  // copy all rows in row to newrow removing any unused space
  // => rws->idx and rws->idxLast are updated
  for (rwi=1; rwi<=rws->n; rwi++) {
    newindex = rws->idx[rwi-1]+rws->len[rwi-1];
    for (j=0; j<rws->len[rwi]; j++) {
      newrow[j+newindex] = oldrow[j+rws->idx[rwi]];
    }
    rws->idx[rwi] = newindex;
  }
  rws->row = newrow;
  free(oldrow);
  rws->idxLast = rws->idx[rws->n] + rws->len[rws->n];

  //------------------------------------------------------------------
  //   resize row arrays
  //------------------------------------------------------------------
  s = rws->n/2 + 1;
  if (s > rws->nMax - rws->n) {
    rws->nMax = rws->n + s;
    s = rws->nMax + 1;
    newidx    = calloc(s,sizeof(int));
    newlen    = calloc(s,sizeof(int));
    newlenAct = calloc(s,sizeof(int));
    newact    = calloc(s,sizeof(int));
    newnTrue  = calloc(s,sizeof(int));
    newnFalse = calloc(s,sizeof(int));

    for (rwi = 0; rwi<=rws->n; rwi++) {
      newidx[rwi]    = rws->idx[rwi];
      newlen[rwi]    = rws->len[rwi];
      newlenAct[rwi] = rws->lenAct[rwi];
      newact[rwi]    = rws->act[rwi];
      newnTrue[rwi]  = rws->nTrue[rwi];
      newnFalse[rwi] = rws->nFalse[rwi];
    }

    // free old memory
    free(rws->idx);
    free(rws->len);
    free(rws->lenAct);
    free(rws->act);
    free(rws->nTrue);
    free(rws->nFalse);

    rws->idx    = newidx;
    rws->len    = newlen;
    rws->lenAct = newlenAct;
    rws->act    = newact;
    rws->nTrue  = newnTrue;
    rws->nFalse = newnFalse;
  }

  return 1;
}
/*eject*/
//--------------------------------------------------------------------
//  int restoreVar (struct Rows* rws, struct Cols* cls, int var)
//
//  description:
//    Restore the deleted variable var to vrs->valSave[var].
//  return value:
//    1
//
//--------------------------------------------------------------------
int restoreVarIn (struct Rows* rws, struct Cols* cls, int var)
{ 
  int id, i, rwi;

  id = rws->id;

  if (vrs->val[id][var] != Del) {
    printf("ERROR: variable %d cannot be restored"
			"since it has not been deleted", var);
	exit(100);
  }
  vrs->val[id][var] = Free;

  //-------------------------------------------------
  //   update row and column data 
  //-------------------------------------------------
  if (cls->hard[var]) {
    cls->nHardAct++;
  }
  for (i=0; i<cls->len[var]; i++) {
    rwi = cls->col[cls->idx[var]+i];
	rws->lenAct[rwi]++;
  }
  for (i=0; i<cls->len[-var]; i++) {
    rwi = cls->col[cls->idx[-var]+i];
	rws->lenAct[rwi]++;
  }

  return 1;
}
//---------------------     formula.c end       ----------------------

