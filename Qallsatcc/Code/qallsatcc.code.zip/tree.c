//---------------------     tree.c begin     -------------------------
//
//  author:  Anja Remshagen
//  date:    August 22, 2003
//  
//  description:
//
//--------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include "macros.h"
#include "structs.h"
#include "fcts.h"
#include "global.h"

//--------------------------------------------------------------------
//  int addToTree (struct Assignment asgn)
//
//  description:
//    Add assignment asgn to the search tree.
//  return value:
//    1   
//
//--------------------------------------------------------------------
int addToTree (struct Assignment asgn)
{
  tree->n++;
  tree->lit[tree->n] = asgn.lit;
  tree->info[tree->n] = asgn.info;
  //printf("add to tree %d  treesize %d\n", asgn.lit,tree->n);
  return 1;
}
//--------------------------------------------------------------------
//  int backtrack (int *newRow)
//
//  description:
//    Backtrack in the search tree trS:
//    Backtrack one node in the tree if the row newRow is empty,
//    that is newRow[0] === 0.
//    Otherwise, backtrack to the first node in the tree that occurs
//    in the  row newRow.
//    Empty the set of unit literals unitLit and the candidate list 
//    qLit.
//  return value: 
//     -1  if search tree is empty
//      0  if backtracking successful and tree is not empty
//--------------------------------------------------------------------
int backtrack (int *newRow)
{
  int i;

  //------------------------------------------------------------------
  //   learned first clause
  //   -> restart
  //------------------------------------------------------------------
  /*
    if (firstClause == 1 && newRow[0] >= 0) {
    firstClause = 0;

     caution: tree->n > 0 versus tree->n > tree->bottom
    if (tree->bottom != 0) {
      printf("ERROR: tree bottom is not at root\n");
    }

     backtrack to root in order to restart
    while (tree->n > 0) {
      freeVar(abs(tree->lit[tree->n]));
      tree->n--;
    }
    unitLit->n = 0;
    qLit->n = 0;

    if (newRow[0] == 0) return -1;
    else return 0;
  }
  */
  //printf("backtrack %ld\n", trS->nNodesQallsat);

  if (newRow[0] >= 0) {
    //----------------------------------------------------------------
    //   backtrack until new row is no more unsatisfied
    //----------------------------------------------------------------
    // set literal flag for each literal in new row
    for (i=1; i<= newRow[0]; i++) {
      litFlg[newRow[i]] = 1;
    }
    // backtrack in tree and free literals 
    // caution: tree->n > 0 versus tree->n > tree->bottom
    while (tree->n > 0  &&
	   litFlg[-tree->lit[tree->n]] == 0) {
      freeVar(abs(tree->lit[tree->n]));
      tree->n--;
    }
    // delete literal flags
    for (i=1; i<= newRow[0]; i++) {
      litFlg[newRow[i]] = 0;
    }
  }
  
  //------------------------------------------------------------------
  //   backtrack to next node not yet set to opposite value
  //------------------------------------------------------------------
  while (tree->n > tree->bottom  &&
	 tree->info[tree->n] >= 0) {
    freeVar(abs(tree->lit[tree->n]));
    tree->n--;
  }
  if (tree->n == tree->bottom) {
    return -1;
  }
    
  freeVar(abs(tree->lit[tree->n]));
  unitLit->n = 1;
  unitLit->lit[1] = -tree->lit[tree->n];
  unitLit->info[1] = 0;
  tree->n--;
  
  //   empty qLit
  qLit->n = 0;

  return 0;
}
//--------------------------------------------------------------------
//  int backtrackIn (int *newRow, struct Rows *rws, struct Cols *cls)
//
//  description:
//    Backtrack in the search tree trS:
//    Backtrack one node in the tree if the row newRow is empty,
//    that is newRow[0] === 0.
//    Otherwise, backtrack to the first node in the tree that occurs
//    in the  row newRow.
//    Empty the set of unit literals unitLit and the candidate list 
//    qLit.
//  return value: 
//     -1  if search tree is empty
//      0  if backtracking successful and tree is not empty
//--------------------------------------------------------------------
int backtrackIn (int *newRow, struct Rows *rws, struct Cols *cls)
{
  int i;

  //------------------------------------------------------------------
  //   backtrack until new row is no more unsatisfied
  //------------------------------------------------------------------
  if (newRow[0] >= 0) {
    // ??? should never happen
    // set literal flag for each literal in new row
    for (i=1; i<= newRow[0]; i++) {
      litFlg[newRow[i]] = 1;
    }
    // backtrack in tree and free literals 
    // caution: tree->n > 0 versus tree->n > tree->bottom
    while (tree->n > tree->bottom  &&
	   litFlg[-tree->lit[tree->n]] == 0) {
      freeVarIn(rws,cls,abs(tree->lit[tree->n]));
      tree->n--;
    }
    // delete literal flags
    for (i=1; i<= newRow[0]; i++) {
      litFlg[newRow[i]] = 0;
    }
  }
  
  //------------------------------------------------------------------
  //   backtrack to next node not yet set to opposite value
  //------------------------------------------------------------------
  while (tree->n > tree->bottom  &&
	 tree->info[tree->n] >= 0) {
    freeVarIn(rws,cls,abs(tree->lit[tree->n]));
    tree->n--;
  }
  if (tree->n == tree->bottom) {
    return -1;
  }
  
  freeVarIn(rws,cls,abs(tree->lit[tree->n]));
  unitLit->n = 1;
  unitLit->lit[1] = -tree->lit[tree->n];
  unitLit->info[1] = 0;
  tree->n--;
  
  //   empty qLit
  qLit->n = 0;
  
  return 0;
}
//--------------------------------------------------------------------
//  int computeRangeAll (struct Rows* rws, struct Cols* cls)
//
//  description:
//    determine the range vector resulting from the current solution 
//    values for X (R case) or Y (S case) and fixed Q values
//  Return value:
//    1
//--------------------------------------------------------------------
int computeRangeAll (struct Rows* rws, struct Cols* cls)
{
  int id;
  int rwi, j, i;
  int lit;
  int begj, endj;
  int val;
  int pos, neg;

  id = rws->id;

  if (range->flg[id] == 0) {
    // no values have been computed to determine the range vector
    return 0;
  }
  
  if (id == 1) {
    begj = vrs->nQ + 1;
    endj = vrs->nQ + vrs->nX;
  }
  else {
    begj = vrs->nQ + vrs->nX + 1;
    endj = vrs->nQ + vrs->nX + vrs->nY;
  }
  
  if (range->flg[id] == 1) {
    // mark all rows satisfied by the current assignment
    // to the X (if id=1) or Y (if id=2) vaiables
    for (rwi = 1; rwi <= rws->n; rwi++) {
      range->vector[id][rwi] = 0;
    }
    for (j = begj; j <= endj; j++) {
      if (range->value[j] != 0) {
	lit = j*range->value[j];
	for (i=0; i < cls->len[lit]; i++) {
	  rwi = cls->col[cls->idx[lit] + i];
	  range->vector[id][rwi] = 1;
	}
      }
    }
    range->flg[id] = 2;
  }

  
  // mark all rows satisfied by the current 
  // assignment to the Q vaiables
  for (rwi = 1; rwi <= rws->n; rwi++) {
    range->vectorAll[id][rwi] = range->vector[id][rwi];
  }  
  for (j=1; j <= vrs->nQ; j++) {
    val = vrs->val[id][j];
    if (val != 0) {
      lit = j*val;
      for (i=0; i < cls->len[lit]; i++) {
	rwi = cls->col[cls->idx[lit] + i];
	range->vectorAll[id][rwi] = 1;
      }
    }    
  }

  // use heuristic to fix the free X, resp. Y, variables
  for (j = begj; j <= endj; j++) {
    if (range->value[j] == 0) {
      // count the occurrences of +j in not yet satisfied rows
      pos = 0;
      for (i=0; i < cls->len[j]; i++) {      
	rwi = cls->col[cls->idx[j] + i];
	if (range->vectorAll[id][rwi] == 0) {
	  pos++;
	}
      }
      // count the occurrences of -j in not yet satisfied rows
      neg = 0;
      for (i=0; i < cls->len[-j]; i++) {      
	rwi = cls->col[cls->idx[-j] + i];
	if (range->vectorAll[id][rwi] == 0) {
	  neg++;
	}
      }
      // if no. of occurrences of +j > no. of occurrences of -j
      // then set j to true; otherwise, set j to false.
      if (pos > neg) {
	for (i=0; i < cls->len[j]; i++) {      
	  rwi = cls->col[cls->idx[j] + i];
	  range->vectorAll[id][rwi] = 1;
	}
      }
      else {
	for (i=0; i < cls->len[-j]; i++) {      
	  rwi = cls->col[cls->idx[-j] + i];
	  range->vectorAll[id][rwi] = 1;
	}
      }
    }
  }

  return 1;
}//--------------------------------------------------------------------
//  int computeRangePart (struct Rows* rws, struct Cols* cls)
//
//  description:
//    determine the range vector resulting from the current solution 
//    values for X (R case) or Y (S case) and fixed Q values
//  Return value:
//    1
//--------------------------------------------------------------------
int computeRangePart (struct Rows* rws, struct Cols* cls)
{
  int id;
  int rwi, j, i;
  int lit;
  int begj, endj;
  int val;

  id = rws->id;

  // ??? assume no satisfying assignment has been stored
  if (range->timer >= 10) {
    range->flg[id] = 0;
  }

  if (range->flg[id] == 0) {
    // initialize the vector range->vectorAll for getAsgnQallsat
    // to reflect rws->act
    for (rwi = 1; rwi <= rws->n; rwi++) {
      if (rws->act[rwi] == 1) { 
	range->vectorAll[id][rwi] = 0;
      }
      else {
	range->vectorAll[id][rwi] = 1;
      }
    }  
    return 0;
  }
  
  if (id == 1) {
    begj = vrs->nQ + 1;
    endj = vrs->nQ + vrs->nX;
  }
  else {
    begj = vrs->nQ + vrs->nX + 1;
    endj = vrs->nQ + vrs->nX + vrs->nY;
  }
  
  if (range->flg[id] == 1) {
    // mark all rows satisfied by the current assignment
    // to the X (if id=1) or Y (if id=2) vaiables
    for (rwi = 1; rwi <= rws->n; rwi++) {
      range->vector[id][rwi] = 0;
    }
    for (j = begj; j <= endj; j++) {
      if (range->value[j] != 0) {
	lit = j*range->value[j];
	for (i=0; i < cls->len[lit]; i++) {
	  rwi = cls->col[cls->idx[lit] + i];
	  range->vector[id][rwi] = 1;
	}
      }
    }
    range->flg[id] = 2;
  }

  
  // mark all rows satisfied by the current 
  // assignment to the Q vaiables
  for (rwi = 1; rwi <= rws->n; rwi++) {
    range->vectorAll[id][rwi] = range->vector[id][rwi];
  }  
  for (j=1; j <= vrs->nQ; j++) {
    val = vrs->val[id][j];
    if (val != 0) {
      lit = j*val;
      for (i=0; i < cls->len[lit]; i++) {
	rwi = cls->col[cls->idx[lit] + i];
	range->vectorAll[id][rwi] = 1;
      }
    }    
  }

  return 1;
}
//--------------------------------------------------------------------
//  int getAsgnQallsat (struct Assignment *asgn)
//
//  precondition:
//    each variable is either 
//    - free in R and S   or
//    - fixed in R and S  or
//    - deleted in R and S
//  description:
//    Find the next literal that has to be set to True in the search
//    tree.
//    Use the first available literal:
//    a) first literal in list unitLiterals that is not fixed 
//    b) first literal in q list that is not yet fixed
//    c) best literal according to statistics
//
//--------------------------------------------------------------------
int getAsgnQallsat (struct Assignment *asgn) 
{
  int cli, i, rwi, j, l, cnt;
  int pos[4];      // counter does ignore range data
  int neg[4];      // counter does ignore range data
  int best[4];


  asgn->lit = 0;
  while (unitLit->n > 0  &&  asgn->lit == 0) {
    //-----------------------------
    //   have unit literal
    //-----------------------------
    cli = abs(unitLit->lit[unitLit->n]);
    if (vrs->val[1][cli] == Free) {
      asgn->lit = unitLit->lit[unitLit->n];
      asgn->info = unitLit->info[unitLit->n];
    }
    (unitLit->n)--;
  }
  while (qLit->n > 0  &&  asgn->lit == 0) {
    //-----------------------------
    //   have Q unit literal
    //-----------------------------
    cli = abs(qLit->lit[qLit->n]);
    if (vrs->val[1][cli] == 0) {
      asgn->lit = qLit->lit[qLit->n];
      asgn->info = qLit->info[qLit->n];
    }
    (qLit->n)--;
  }
  if (asgn->lit == 0) {
    //------------------------------------------------
    //   select from not yet fixed Q variable
    //------------------------------------------------
    
    // compute range information for S
    computeRangePart(rwsS,clsS);

    for (i=1;i<=3; i++) {
      best[i] = 0;
    }
    for (cli=1; cli <= vrs->nQ; cli++) {
      if (vrs->val[1][cli] == Free) {
	// make sure that asgn contains a literal
	// in case all R rows are satisfied.
	if (asgn->lit == 0) {
	  asgn->lit = cli;
	  asgn->info = -1;
	}
	for (i=1; i<=3; i++) {
	  pos[i] = 0;
	  neg[i] = 0;
	}
	// count positive and negative occurrences of cli in R
	for (j=0; j<clsR->len[cli]; j++) {
	  rwi = clsR->col[j+clsR->idx[cli]];
	  if (rwsR->act[rwi] == 1) {
	    if ((l=rwsR->lenAct[rwi]) >= 3) {
	      pos[3]++;
	    }
	    else {
	      pos[l]++;
	    }
	  }
	}
	for (j=0; j<clsR->len[-cli]; j++) {
	  rwi = clsR->col[j+clsR->idx[-cli]];
	  if (rwsR->act[rwi] == 1) {
	    if ((l=rwsR->lenAct[rwi]) >= 3) {
	      neg[3]++;
	    }
	    else {
	      neg[l]++;
	    }
	  }
	}
	// count positive and negative occurrences of cli in S
 	for (j=0; j<clsS->len[cli]; j++) {
 	  rwi = clsS->col[j+clsS->idx[cli]];
	  //if (rwsS->act[rwi] == 1) {  // original selection
	  if (range->vectorAll[2][rwi] == 0) {
	    if ((l=rwsS->lenAct[rwi]) >= 3) {
 	      neg[3]++;
 	    }
 	    else {
 	      neg[l]++;
 	    }
 	  }
	}
	for (j=0; j<clsS->len[-cli]; j++) {
	  rwi = clsS->col[j+clsS->idx[-cli]];
  	  //if (rwsS->act[rwi] == 1) {  // original selection
  	  if (range->vectorAll[2][rwi] == 0) {
	    if ((l=rwsS->lenAct[rwi]) >= 3) {
  	      pos[3]++;
  	    }
  	    else {
  	      pos[l]++;
  	    }
  	  }
 	}

	// column cli better candidate?
	i = 1;
	while (i <= 3) {
	  cnt = pos[i]+neg[i];
	  if (cnt > best[i]) {
	    // col cli is a better candidate
	    best[i] = cnt;
	    i++;
	    while (i <= 3) {
	      cnt = pos[i]+neg[i];
	      best[i] = cnt;
	      i++;
	    }
	    if (pos[1]+pos[2]+pos[3] > neg[1]+neg[2]+neg[3]) {
	      asgn->lit = cli;
	    }
	    else {
	      asgn->lit = -cli;
	    }
	    asgn->info = -1;
	  }
	  else if (cnt < best[i]) {
	    // col cli is not a better candidate
	    i = 4;
	  }
	  i++;
	}
      }
    }
  }
  
  if (asgn->lit != 0) return 1;
  else return 0;
}
//--------------------------------------------------------------------
//  int getAsgnSat (struct Rows *rws, struct Cols *cls,
//                  struct Assignment *asgn)
//
//  description:
//    Find the next literal that has to be set to True in cnf formula
//    rws/cls and has to be addded to the search tree.
//    Use the first available literal:
//    a) first literal in list unitLiterals that is not fixed 
//    b) best literal according to statistics
//       a monotone variable has highest priority
//
//--------------------------------------------------------------------
int getAsgnSat (struct Rows *rws, struct Cols *cls,
                struct Assignment *asgn)
{
  int cli, i, rwi, j, l, cnt, id;
  int pos[4];
  int neg[4];
  int best[4];
  int nPos, nNeg;

  id = rws->id;
  asgn->lit = 0;
  while (unitLit->n > 0  &&  asgn->lit == 0) {
    //-----------------------------
    //   have unit literal
    //-----------------------------
    cli = abs(unitLit->lit[unitLit->n]);
    if (vrs->val[id][cli] == Free) {
      asgn->lit = unitLit->lit[unitLit->n];
      asgn->info = unitLit->info[unitLit->n];
    }
    (unitLit->n)--;
  }
  while (qLit->n > 0  &&  asgn->lit == 0) {
    //-----------------------------
    //   have Q unit literal
    //-----------------------------
    cli = abs(qLit->lit[qLit->n]);
    if (vrs->val[id][cli] == Free) {
      asgn->lit = qLit->lit[qLit->n];
      asgn->info = qLit->info[qLit->n];
    }
    (qLit->n)--;
  }
  if (asgn->lit == 0) {
    //------------------------------------------------
    //   select from not yet fixed variables
    //------------------------------------------------
    for (i=1;i<=3; i++) {
      best[i] = 0;
    }
    for (cli=1; cli <= cnf->n; cli++) {
      if (vrs->val[id][cli] == Free) {
	for (i=1; i<=3; i++) {
	  pos[i] = 0;
	  neg[i] = 0;
	}
	
	nPos = 0;
	for (j=0; j<cls->len[cli]; j++) {
	  rwi = cls->col[j+cls->idx[cli]];
	  if (rws->act[rwi] == 1) {
	    nPos++;
	    if ((l=rws->lenAct[rwi]) >= 3) {
	      pos[3]++;
	    }
	    else {
	      pos[l]++;
	    }
	  }
	}
	if (nPos == 0) {
	  asgn->lit = -cli;
	  asgn->info = 0;
	  return 1;
	}

	nNeg = 0;
	for (j=0; j<cls->len[-cli]; j++) {
	  rwi = cls->col[j+cls->idx[-cli]];
	  if (rws->act[rwi] == 1) {
	    nNeg++;
	    if ((l=rws->lenAct[rwi]) >= 3) {
	      neg[3]++;
	    }
	    else {
	      neg[l]++;
	    }
	  }
	}
	if (nNeg == 0) {
	  asgn->lit = cli;
	  asgn->info = 0;
	  return 1;
	}
	
	// column cli better candidate?
	i = 1;
	while (i <= 3) {
	  cnt = pos[i]+neg[i];
	  if (cnt > best[i]) {
	    // col cli is a better candidate
	    best[i] = cnt;
	    i++;
	    while (i <= 3) {
	      cnt = pos[i]+neg[i];
	      best[i] = cnt;
	      i++;
	    }
	    if (pos[1]+pos[2]+pos[3] > neg[1]+neg[2]+neg[3]) {
	      asgn->lit = cli;
	    }
	    else {
	      asgn->lit = -cli;
	    }
	    asgn->info = -1;
	  }
	  else if (cnt < best[i]) {
	    // col cli is not a better candidate
	    i = 4;
	  }
	  i++;
	}
      }
    }
  }
  if (asgn->lit != 0) return 1;
  else return 0;
}
//--------------------------------------------------------------------
//  int initSearch ()
//
//  precondition:
//
//  description:
//    initialize the structure tr for the tree search
//    find unit literal and unit q literals in S.
//  return value:
//     -1  if an empty row in R has been found
//     -2  if an empty row in S has been found
//   < -2  if an empty row in R and S has been found
//      1  otherwise
//
//--------------------------------------------------------------------
int initSearch ()
{
  int rc, rwi, lit, j, i;

  // allocate memory for range information
  range = malloc(sizeof(struct Range));
  range->vector[1] = calloc(rwsR->nMax+1,sizeof(int));
  range->vector[2] = calloc(rwsS->nMax+1,sizeof(int));
  range->vectorAll[1] = calloc(rwsR->nMax+1,sizeof(int));
  range->vectorAll[2] = calloc(rwsS->nMax+1,sizeof(int));

  range->value = calloc(cnf->n+1,sizeof(int));

  // set range flags to 0
  range->flg[0] = 0;
  range->flg[1] = 0;
  range->flg[2] = 0;
  range->timer = 0;

  // allocate memory for tree information
  trS = malloc(sizeof(struct TreeSearch));
  trS->tree = (struct Tree*) malloc(sizeof(struct Tree));
  trS->unitLit = malloc(sizeof(struct Set));
  trS->qLit = malloc(sizeof(struct Set));

  tree = trS->tree;
  tree->n = 0;
  tree->bottom = 0;
  tree->lit = (int*) calloc(2*(cnf->n)+1,sizeof(int));
  tree->info = calloc(2*(cnf->n)+1,sizeof(int));
  tree->lit[0] = 0;
  tree->info[0] = 0;

  i = rwsR->n + rwsS->n + 1; 
  unitLit = trS->unitLit;
  unitLit->n = 0;
  unitLit->lit = calloc(i,sizeof(int));
  unitLit->info = calloc(i,sizeof(int));

  qLit = trS->qLit;
  qLit->n = 0;
  qLit->lit = calloc(i,sizeof(int));
  qLit->info = calloc(i,sizeof(int));

  // init literal flag
  litFlg = calloc((2*cnf->n)+1,sizeof(int)); 
  litFlg = litFlg + cnf->n;
  for (i=-cnf->n; i<=cnf->n; i++) {
    litFlg[i] = 0;
  }

  // init statistics
  trS->nRowsSat = 0;
  trS->nRowsUnsat = 0;
  trS->nNodesQallsat = 0;
  trS->nNodesSat = 0;

  // store all unit literals in unitLit and 
  // store the unit q literals in S in  qLit
  rc = 1;
  for (rwi = 1; rwi <= rwsR->n; rwi++) {
    if (rwsR->act[rwi] == 1) {
      if (rwsR->lenAct[rwi] == 0) {
	rc = -1;
      }
      else if (rwsR->lenAct[rwi] == 1) {
	// have unit row, find unit literal
	for (j=0; j<rwsR->len[rwi]; j++) {	
	  lit = rwsR->row[rwsR->idx[rwi]+j];
	  if (vrs->val[1][abs(lit)] == Free) {
	    // add literal to unit list
	    unitLit->n++;
	    unitLit->lit[unitLit->n] = lit;
	    unitLit->info[unitLit->n] = rwi;
	    break;
	  }
	}
      }
    }
  }
  for (rwi = 1; rwi <= rwsS->n; rwi++) {
    if (rwsS->act[rwi] == 1) {
      if (rwsS->lenAct[rwi] == 0) {
	rc = rc - 2;
      }
      else if (rwsS->lenAct[rwi] == 1) {
	// have unit row, find unit literal
	for (j=0; j<rwsS->len[rwi]; j++) {	
	  lit = rwsS->row[rwsS->idx[rwi]+j];
	  if (vrs->val[2][abs(lit)] == Free) {
	    if (abs(lit) <= vrs->nQ) {
	      // add literal to q list
	      qLit->n++;
	      qLit->lit[qLit->n] = lit;
	      qLit->info[qLit->n] = rwi;
	    }
	    else {
	      // add literal to unit list
	      unitLit->n++;
	      unitLit->lit[unitLit->n] = lit;
	      unitLit->info[unitLit->n] = rwi;
	    }
	    break;
	  }
	}
      }
    }
  }

  count = 0;
  
  testFlg = 0;

  return rc;  
}
//--------------------------------------------------------------------
//  int learnSat (int *newRow, struct Rows *rws, struct Cols *cls)
//
//  description:
//    Learn a new row from satisfiability in S. One by one, delete
//    the q variables in the tree and solve S. If S becomes 
//    satisfiable, add the q variable again to the formula and
//    add the corresponding q literal to the new row newRow.
//  precondition:
//    Only q variables have been selected and fixed previously; 
//    Possibly, some y variables are fixed due to unit resolution. 
//    The current assignment can be extended to a solution of S.
//  postcondition:
//    If only a useless row can be learned, newRow[0] = -1.
//    A row is useless, if it contains all q variables in the 
//    current tree. (This row will be always satisfied afer the 
//    next backtracking step.)
//    Otherwise, newRow contains a clause with literals 
//    newRow[1..l] where the length l if given by newRow[0].
//    each literal newRow[i] is a q variable.
//  return value:
//   -1: No new row was learned.
//    0: An new row of length 0 was determined, and newRow[0]==0.
//    l>0: newRow contains a new row of length l. 
//
//--------------------------------------------------------------------
int learnSat (int *newRow, struct Rows *rws, struct Cols *cls)
{
  int var, lit;
  int result;
  int learned;
  int j, jMemTree, i;
  int jStart;  // number literals further removed from
               // learned clause in second learning step
  int id;
  int hole, iHole;

  //printf("*** learning");

  newRowSave[0] = 0;
  learned = 0;
  id = rws->id;
 
  //----------------------------
  //   delete all free q vars
  //----------------------------
  for (var=1; var<=vrs->nQ; var++) {
    if (vrs->val[id][var] == Free) {
      delVarIn(rws,cls,var);
    }
  }
  
  //----------------------------
  //   sharpen clause: step 1
  //----------------------------
  iHole = 0;
  hole = -1;
  jMemTree = 0;
  for (j=tree->n; j>=1; j--) {
    lit = tree->lit[j];
    var = abs(lit);
    if (var <= vrs->nQ) {
      // delete q variable tentatively
      delVarIn(rws,cls,var);
      // Solve SAT instance
      result = solve(rws,cls);
      if (result == -1) {
	restoreVarIn(rws,cls,var);
	fixAsgnIn(rws,cls,lit);
	newRowSave[0]++;
	newRowSave[newRowSave[0]] = -lit;
	if (newRowSave[0] > MAX_ROW_LEN_ACT) {
	  printf(" ***   Exceed MAX_ROW_LEN_ACT in learnSat\n");
	  jMemTree = j-1;
	  break;
	}
	// 
	if (hole == -1 || hole == 0) {
	  hole = 0;
	  iHole++;
	}

      }
      else {
	litFlg[0]++;
	litFlg[litFlg[0]]= lit;
	learned = 1;
	if (hole == 0) hole = 1;
      }
    }
    else {
      freeVarIn(rws,cls,var);
      litFlg[0]++;
      litFlg[litFlg[0]]= lit;
    }
  }

  //------------------------------------------------------------------
  //  sharpen clause: step 2
  //------------------------------------------------------------------
  /*
  testFlg = 1;
  printf("*** current learned clause:\n");
  for (i=1; i<=newRowSave[0]; i++) {
    printf("%4d",newRowSave[i]);
  }
  printf("\n");
  */

  jStart = 0;
  i = 0;
  //  iHole = 8;
  while (i < iHole && jStart == i && newRowSave[0] > i) {
    i++;
    lit = newRowSave[i];
    var = abs(lit);
    freeVarIn(rws,cls,var);
    fixAsgnIn(rws,cls,lit);

    result = tryValues(rws,cls,i-1);
    if (result == 1) {
      learned = 1;
      jStart++;
    }

    freeVarIn(rws,cls,var);
    fixAsgnIn(rws,cls,-lit);
  }
  //  testFlg = 0;

  //------------------------------------------------------------------
  //   print learning information
  //------------------------------------------------------------------
  /*  
  if (learned == 0) {
    printf("no clause learned\n");
  }
  else {
    i = 1;
    for (j=tree->n; j>=1; j--) {
      lit = tree->lit[j];
      var = abs(lit);
      if (var <= vrs->nQ) {
	printf("%4d",lit);
	if (i <= newRowSave[0] && abs(newRowSave[i]) == var) {
	  if (i <= jStart){
	    printf("X");
	  }
	  else {
	    printf("*");
	  }
	  i++;
	}
	else {
	  printf(" ");
	}
      }    
    }
    printf("\n");
  }
  */

  //------------------------------------------------------------------
  //   clean up after sharpening clause
  //------------------------------------------------------------------

  //   restore variables in tree that have been deleted 
  //   and reset variables that have been freed/deleted
  for (var=1; var<=vrs->nQ; var++) {
    if (vrs->val[id][var] == Del) {
      restoreVarIn(rws,cls,var);
    }
  }
  for (j=1; j<=litFlg[0]; j++) {
    var = abs(litFlg[j]);
    fixAsgnIn(rws,cls,litFlg[j]);
    litFlg[j] = 0;
  }
  litFlg[0] = 0;

  if (learned == 0 || newRowSave[0]+jMemTree > MAX_ROW_LEN) {
    newRow[0] = -1;
  }
  else {
    for (j= 1+jStart; j <= newRowSave[0]; j++) {
      newRow[j-jStart] = newRowSave[j];
    }
    newRow[0] = newRowSave[0] - jStart;
    for (j=jMemTree; j>=1; j--) {
      lit = tree->lit[j];
      var = abs(lit);
      if (var <= vrs->nQ) {
	newRow[0]++;
	newRow[newRow[0]] = -lit;
      }
    }
  }
  /*
  printf("final learned clause:\n");
  for (i=1; i<=newRow[0]; i++) {
    printf("%4d",newRow[i]);
  }
  printf("\n");
  */
  return newRow[0];
}
//--------------------------------------------------------------------
//  int tryValues (struct Rows *rws, struct Cols *cls, int idx)
//
//  description:
//    solve SAT instance rws/cls where all values of the variables
//    given by the literals newRowSave[1,..,idx] are tried.
//    If all instances are satisfiable return 1
//  precondition:
//    newRowSave contains a learned clause with at least idx literals
//    all literals in newRowSave are set to false in rws/cls;
//    additonal variables may be fixed or deleted
//  postcondition:
//    no change of values
//  return value:
//    1: rws/cls is satisfiable for all truth values of the variables
//       given by the literals newRowSave[1,..,idx].
//    0: otherwise
//
//--------------------------------------------------------------------
int tryValues (struct Rows *rws, struct Cols *cls, int idx) {
  int result;
  int var, lit;

  // base case
  if (idx == 0) {
    result = solve(rws,cls);
    if (result == 1) {    
      //printf(" sat\n");
      return 1;
    }
    else {
      //      printf(" unsat\n");
      return 0;
    }
  }
  // recursive step
  else {
    result = tryValues (rws, cls, idx-1);
    if (result == 1) {
      lit = newRowSave[idx];
      var = abs(lit);
      freeVarIn(rws,cls,var);
      fixAsgnIn(rws,cls,lit);
      result = tryValues(rws,cls,idx-1);
      freeVarIn(rws,cls,var);
      fixAsgnIn(rws,cls,-lit);
      if (result == 1) {    
	return 1;
      }
      else {
	return 0;
      }
    }
    else {
      return 0;
    }
      
  }
}
//--------------------------------------------------------------------
//  int learnUnsat (int *newRow, struct Rows *rws, struct Cols *cls)
//
//  precondition:
//    rws->id = 1
//  description:
//    Learn a new row. If no row can be learned, set newRow[0]=-1.
//    Otherwise the literals of the row are saved in array 
//    newRow[1..l] where the length l if given by newRow[0].
//  return value:
//   -1: No new row was learned.
//    0: An new row of length 0 was determined, and newRow[0]==0.
//    l>0: newRow contains a new row of length l. 
//
//--------------------------------------------------------------------
int learnUnsat (int *newRow, struct Rows *rws, struct Cols *cls)
{
  int j;
  int lit, var;
  int result;
  int learned;

  newRowSave[0] = 0;
  learned = 0;
  //-----------------------------
  //   sharpen conflict clause
  //-----------------------------
  for (j=tree->n; j>=1; j--) {
    lit = tree->lit[j];
    var = abs(lit);
    if (var <= vrs->nQ + vrs->nX) {
      // delete q variable tentatively
      freeVarIn(rws,cls,var);
      if (var <= vrs->nQ) {
	result = solve(rws,cls);
	if (result == 1) {
	  fixAsgnIn(rws,cls,lit);
	  newRowSave[0]++;
	  if (newRowSave[0] > MAX_ROW_LEN) {
	    break;
	  }
	  newRowSave[newRowSave[0]] = -lit;
	}      
	else {
	  litFlg[0]++;
	  litFlg[litFlg[0]] = lit;
	  learned = 1;
	}      
      }
      else {
	litFlg[0]++;
	litFlg[litFlg[0]] = lit;
      }
    }
  }
  //-------------------------------------------------------------
  //   reset variables that have been freed
  //-------------------------------------------------------------
  for (j=1; j<=litFlg[0]; j++) {
    // ??? litFlg[j];
    fixAsgnIn(rws,cls,litFlg[j]);
    litFlg[j] = 0;
  }
  litFlg[0] = 0;

  if (learned == 0 || newRowSave[0] > MAX_ROW_LEN) { 
    newRow[0] = -1;
  }
  else {
    for (j=0; j<=newRowSave[0]; j++) {
      newRow[j] = newRowSave[j];
    }
  }  
  
  return newRow[0];
}
//--------------------------------------------------------------------
//  int printTreeSearch (struct TreeSearch *trS)
//
//  description:
//    print the content of the tree-search structure in trS on screen.
//
//--------------------------------------------------------------------
int printTreeSearch (struct TreeSearch* trS)
{
  printf("\n*****   tree search content   *****\n");
 
  printTree(trS->tree);
  printSet(trS->unitLit);
  printSet(trS->qLit);

  printf("*****   end of tree search content   *****\n");
  return 1;
}
//--------------------------------------------------------------------
//  int printTree (struct Tree *tr)
//
//  description:
//    print the content of the tree in structure tr on screen
//
//--------------------------------------------------------------------
int printTree (struct Tree* tr)
{
  int i;

  printf("*****   tree content   *****\n");
 
  if (tr->n == 0) printf("empty tree\n");

  for (i=1; i<=tr->n; i++) {
	printf("%3d:",i);
	printf("%12s %5d",vrs->name[abs(tr->lit[i])], tr->lit[i]);
	printf(" %5d\n",tr->info[i]);
  }
  printf("*****   end of tree content   *****\n");
  return 1;
}
//--------------------------------------------------------------------
//  int printSet (struct Set *set)
//
//  description:
//    print the content of the set in structure set on screen
//
//--------------------------------------------------------------------
int printSet (struct Set* set)
{
  int i;

  printf("*****   set content   *****\n");
 
  if (set->n == 0) printf("empty set\n");

  for (i=1; i<=set->n; i++) {
	printf("%3d",i);
	printf("%12s %3d",vrs->name[abs(set->lit[i])],set->lit[i]);
	printf(" %3d\n",set->info[i]);
  }
  printf("*****   end of set content   *****\n");
  return 1;
}
//--------------------------------------------------------------------
//  int rangeSat (struct Rows* rws, struct Cols* cls)
//
//  description:
//    determine if current solution values for X (R case) or Y (S case)
//    plus fixed Q values satisfy all clauses 
//  Return value:
//    1 if current solution values for X (R case) or Y (S case)
//      plus fixed Q values satisfy all clauses 
//    0 otherwise
//--------------------------------------------------------------------
int rangeSat (struct Rows* rws, struct Cols* cls)
{
  int rwi, id;

  if (computeRangeAll(rws,cls) == 1) {
    id = rws->id;
    for (rwi = 1; rwi <= rws->n; rwi++) {
      if (range->vectorAll[id][rwi] == 0) {
	range->timer++;
	return 0;
      }
    }  
    return 1;
  }
  else {
    return 0;
  }
}
//--------------------------------------------------------------------
//  int resetSolve (struct Rows *rws, struct Cols *cls)
//
//  description:
//    Free all variables fixed below the bottom of the tree
//    Reset the bottom of the tree to 0.
//    Empty the list of unit literal unitLit.
//  Return value:
//    1
//
//--------------------------------------------------------------------
int resetSolve (struct Rows *rws, struct Cols *cls)
{
  while (tree->n > tree->bottom) {
    freeVarIn(rws,cls,abs(tree->lit[tree->n]));
    tree->n--;
  }
  tree->bottom = 0;
  unitLit->n = 0;
  
  return 1;
}
//--------------------------------------------------------------------
//  int setupSolve (struct Rows *rws)
//
//  description:
//    Setup tree.
//    Find unit literals and store in unitLit. 
//    Check if all rows evaluate to false.
//  return value:
//    1  if all rows evaluate to true
//   -1  if all rows evaluate to false
//    0  if value of the cnf formual is undetermined
//
//--------------------------------------------------------------------
int setupSolve (struct Rows *rws)
{
  int rwi, j, lit, id; 
  int rc;

  tree->bottom = tree->n;
  unitLit->n = 0;
  newRow[0] = -1;

  if (rws->n == rws->nSat) {
    return 1;
  }

  id = rws->id;
  rc = 0;
  for (rwi = 1; rwi <= rws->n; rwi++) {
    if (rws->act[rwi] == 1) {
      if (rws->lenAct[rwi] == 0) {
	rc = -1;
	break;
      }
      else if (rws->lenAct[rwi] == 1) {
	// have unit row, find unit literal
	for (j=0; j<rws->len[rwi]; j++) {	
	  lit = rws->row[rws->idx[rwi]+j];
	  if (vrs->val[id][abs(lit)] == Free) {
	    // add literal to unit list
	    unitLit->n++;
	    unitLit->lit[unitLit->n] = lit;
	    unitLit->info[unitLit->n] = rwi;
	    break;
	  }
	}
      }
    }
  }

  return rc;
}
//--------------------------------------------------------------------
//  int solve (struct Rows *rws, struct Cols *cls)
//
//  description:
//    solve the CNF formula given by rows rws, columns cls, and
//    variables vrs where the variables in the search tree tree are 
//    fixed in rws and cls.
//    Use the search tree tree to solve the formula by backtracking
//    search.
//  precondition:
//    If rws/cls is formual S, all Q variables are either fixed
//    or deleted. The list qLit with Q-unit-literals is empty.
//  postcondition:
//    The formula given by rws and cls and the search tree tree is 
//    restored to the state when the function solve() is entered.
//    The list of unit literals unitLit and q literals qLit is 
//    emptied.
//    newRow[0] is set to -1.
//  return value:
//     1  if the formula rws/cls is satisfiable     
//    -1  if the formula rws/cls is unsatisfiable
//--------------------------------------------------------------------
int solve (struct Rows *rws, struct Cols *cls) 
{
  int solved;
  int result;
  struct Assignment asgn;
  int j, id;

  /* print test information
  int var;
  id = rws->id;
  if (testFlg == 1) {
    for (var=1; var<=vrs->nQ; var++) {
      if (vrs->val[id][var] == Del) {
	printf("%4dD",var);
      }
      else {
	printf("%4d",var*vrs->val[id][var]);
      }
    }
    }*/

  solved = setupSolve(rws);

  while (solved == 0) {
    getAsgnSat(rws,cls,&asgn);
    addToTree(asgn);
    result = fixAsgnIn(rws,cls,asgn.lit);
    if (result == 1) {
      solved = 1;
    }
    else if (result == -1) {
      solved = backtrackIn(newRow,rws,cls);
      trS->nNodesSat++;
    }
    /* Horn clause case eliminated
    else if(cls->nHardAct == 0 &&
	    unitLit->n == 0) {
      solved = 1;
      count++;
      }*/
  }

  // update range information if a solution exists
  // store solution in range->value 
  if (solved == 1) {
    id = rws->id;
    range->flg[id] = 1;
    range->timer = 0;
    if (id == 1) {
      for (j = vrs->nQ + 1; j <= vrs->nQ + vrs->nX;
	   j++) {
	range->value[j] = vrs->val[id][j];
      }
    }
    if (id == 2) {
      for (j = vrs->nQ + vrs->nX + 1; j <= vrs->nQ + vrs->nX + vrs->nY;
	   j++) {
	range->value[j] = vrs->val[id][j];
      }
    }
  }


  resetSolve(rws,cls);

  return solved;
}
//----------------------     tree.c end     --------------------------
