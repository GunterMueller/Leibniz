#ifndef STRUCTS_H
#define STRUCTS_H
#include <time.h>

//--------------------------------------------------------------------
//
//   Structures
//
//--------------------------------------------------------------------
struct Vars {
  int nQ;       // no. Q variables
  int nX;       // no. X variables
  int nY;       // no. Y variables
  char **name;  // variable names
  int **val;     // val[i][id] =  
                 //  0 = Free  if var i not fixed in formula id
		//   1 = True  if var i set to True in formula id
		//  -1 = False if var i set to False in formula id
		//  10 = Del   if var i has been deleted in formula id
};

//--------------------------------------------------------------------
//  Structure Rows
//
//  description:
//    The literals of each row are stored consecutively in array row.
//    The indices of the rows 1,...,nOrg remain unchanged
//    CAUTION:
//    The rows are not necessarily stored consecutively in array row.
//    That is, the literals of row i can be stored after the literals 
//    of a row j with i < j.
//    The following properties must hold:
//    - the literals of row i are stored at 
//      row[idx[i],..,idx[i]+len[i]-1]
//    - 0 <= idxLast is the index of the first cell in row that does
//      not contain an entry and after which no more entries follow 
//
//--------------------------------------------------------------------
struct Rows {
  int id;       // = 1 if R
                // = 2 if S
  int n;        // no. rows
  int nOrg;     // original no. rows
  int nMax;     // maximum no. rows for which memory is allocated
  int nLit;     // no. of current literals
  int nLitMax;  // maximum no. literals for which memory is allocated
  int nSat;     // no. rows evaluating to True
  int *idx;     // idx[i] = index of the first literal in row i
                // in array row for i = 1,2,..,n
                // idx[0] = 0
  int *len;     // len[i] = no. of literals in row i
                //   for i = 1,2,..,n
                // len[0] = 0
  int *row;     // literals of each row 
  int idxLast;  // index of first unused cell in row after which
                //   after which no more row entries follow 
  int *lenAct;  // lenAct[i] = no. of active literals in row i
  int *act;	// act[i] = 1 if row is active
		//        = 0 if row is satisfied
		//        = -1 if row is deleted
                //   for i = 1,2,..,n
  int *nTrue;   // nTrue[i] = no. of literals set to True in row i
                //   for i = 1,2,..,n
  int *nFalse;  // nFalse[i] = no. of literals set to False or deleted
		//   in row i for i = 1,2,..,n
};

//--------------------------------------------------------------------
//
//  Structure Cols
//
//  description:
//    The column data is stored in the order of th column idices
//    in array column. 
//    The literals of each column are stored consecutively in array 
//    col: the literals of col i are stored at 
//      col[ idx[i],..,idx[i]+len[i]-1 ]
//
//--------------------------------------------------------------------
struct Cols {
  int nLit;     // no. of current literals
  int nLitMax;  // maximum no. of literals for which memory is allocated
  int *idx;     // idx[i] = index of the first literal in column i
                // in array col for i = +/-1,+/-2,..,+/-n
  int *lenMax;  // lenMax[i] = number free cells succeeding the entries
                // for column i in array col
  int *len;     // len[i] = no. of literals in column i
                // for i = +/-1,+/-2,..,+/-n
  int *col;     // rows of each column 
  int *hard;    // val[i] = 1  if variable i belongs to hard part
                //        = 0  if variable i belongs to the easy
                //             part of the formula
  int nHardAct; // no. of unfixed variables in the hard part of the 
                // cnf formula
};

struct CNF {
  char *name;
  int n;
  struct Vars *vars;  // variable information
  struct Rows *rowsR; // rows of CNF formula R
  struct Cols *colsR; // columns of CNF formula R
  struct Rows *rowsS; // rows of CNF formula S
  struct Cols *colsS; // columns of CNF formula S
};

//--------------------------------------------------------------------
//
//   Tree Structures
//
//--------------------------------------------------------------------
struct Set {  
  int n;       // no. elements in the set
  int *lit;    // lit[1..n]: literals
  int *info;   // info[1..n] = row index that forces the literal to
               //              true due to unit row
               //            = -1 if other value needs to be 
               //              processed as well
};

struct Tree {
  int n;       // size of the tree;
  int bottom;  // bottom+1 is the index of the root in the 
               // current tree
  int *lit;    // lit[1..n]: literals set to true
  int *info;   // info[1..n]
               // >  0  literal set to true due to unit resolution
               //       opposite value is not tried
               // =  0  opposite value has been tried
               // = -1  opposite value has not yet been tried
};

struct TreeSearch {
  struct Tree *tree;    // no. current rows
  struct Set  *unitLit; // list of literals in unit clauses
  struct Set  *qLit;    // list of Q literals in unit clauses in S  

  // statistics
  int nRowsSat;      // number of new learned rows due 
                     // to satisfiability of S
  int nRowsUnsat;    // number of new learned rows
                     // to unsatisfiability of R
  long nNodesQallsat;// number of calls of backtracking procedure
                     // during main qallsat solver
  long nNodesSat;    // number of total calls of backtracking 
                     // procedure during all sat solving proecesses
};

struct Assignment {
  int lit;     // literal to be fixed
  int info;    // reason for literal fixing
               // > 0  literal set to true due to unit resolution
               //      opposite value is not tried
               // = 0  opposite value has been tried
               // = -1 opposite value has not yet been tried
};

//--------------------------------------------------------------------
//
//   Range Vector Structure
//
//--------------------------------------------------------------------
struct Range {
  int *value;
  int flg[2+1];
  int *vector[2+1];
  int *vectorAll[2+1];
  int timer;
};

//--------------------------------------------------------------------
//
//   Time Structure
//
//--------------------------------------------------------------------
struct Timer {
  time_t start;
  time_t prev;
};

#endif
