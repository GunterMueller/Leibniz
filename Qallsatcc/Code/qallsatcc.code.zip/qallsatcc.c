/* main program */
/**************************************************************
 *  
 *  qallsatcc: Solves problem Q-ALL SAT
 *
 *  For definition of Q-ALL SAT, see Chapter 4 of the book 
 *  Design of Logic-based Intelligent Systems, Wiley, 2004.
 *
 *  This progam is an implementation of the solution algorithm for 
 *  Q-ALL SAT described in the paper
 *
 *  A. Remshagen, and K. Truemper, "A Solver for Quantified Formula
 *  Problem Q-ALL SAT, 2007, available at
 *  http://www.utdallas.edu/~klaus/Wpapers/qallsatcc.pdf
 *
 *  A related predecessor algorithm is described in
 *  A. Remshagen, and K. Truemper, "An Effective Algorithm for the
 *  Futile Questioning Problem",  
 *  Journal of Automated Reasoning 34 (2005) 31-47.
 *       
 *  Copyright (C) A. Remshagen, K. Truemper (independent copyright
 *                holders)
 *
 *  This program is free software: 
 *  you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License 
 *  as published by the Free Software Foundation, 
 *  either version 3 of the License, or (at your option) any later
 *  version. The License statement is in file lgpl.txt, 
 *  but can also be obtained from www.gnu.org/licenses/.
 *
 *  We do not make any representation or warranty, expressed or implied, 
 *  as to the condition, merchantability, title, design, operation, or fitness 
 *  of the program for a particular purpose.
 *
 *  We do not assume responsibility for any errors, including mechanics or logic, 
 *  in the operation or use of the program, and have no liability whatsoever 
 *  for any loss or damages suffered by any user as a result of the program.
 *     
 *  In particular, in no event shall we be liable for special, incidental, 
 *  consequential, or tort damages, even if we have been advised of the 
 *  possibility of such damages. 
 *
 **************************************************************/  
/*eject*/
#include <stdio.h>
#include <time.h>
#include "macros.h"
#include "structs.h"
#include "global.h"
#include "fcts.h"


int main (int argc, char *argv[]) {
  //------------------------------------------------------------------
  //   Local variables
  //------------------------------------------------------------------
  int resultR, resultS;
  struct Assignment asgn;
  int solved;
  
  long runtime;

  //------------------------------------------------------------------
  //   Read input
  //------------------------------------------------------------------
  if (argc <= 1) {
    printf("Usage: %s <filename>\n",argv[0]);
    return 0;
  }
  readFormula(argv[1]);

  // DEBUG: comment out above 5 lines
  //        activate line below 
  // readFormula("small.log"); 

  //------------------------------------------------------------------
  //   start timer
  //------------------------------------------------------------------
  initTimer(); 
/*eject*/
  //------------------------------------------------------------------
  //   Solve Q-ALL SAT
  //------------------------------------------------------------------
  initSearch();
  solved = 0;
  while (solved == 0) {
    if(getAsgnQallsat(&asgn) == 0) {
      //--------------------------------------------------------------
      //   all Q variables are fixed
      //--------------------------------------------------------------
      resultR = solve(rwsR,clsR);
      if (resultR == -1) {
	//------------------------
	//   R is unsatisfiable
	//------------------------
	//printf("R is unsatisfiable, all vars fixed\n");
	newRow[0] = -1;
	solved = backtrack(newRow);
	trS->nNodesQallsat++;
	continue;
      }
      else {
	//printf("R is satisfiable, all vars fixed\n");
	resultS = solve(rwsS,clsS);
	if (resultS == 1) {
	  //----------------------
	  //   S is satisfiable
	  //----------------------
	  //printf("  S is satisfiable\n");
	  learnSat(newRow,rwsS,clsS);
	  trS->nRowsSat += addRow(newRow,rwsR,clsR);
	  solved = backtrack(newRow);
	  trS->nNodesQallsat++;
	  continue;
	}
	else {
	  //printf("  S is unsatisfiable, done\n");
	  solved = 1;
	  break;
	}
      }
    }
    //----------------------------------------------------------------
    //   fix selected literal
    //----------------------------------------------------------------
    addToTree(asgn);

    resultR = fixAsgnIn(rwsR,clsR,asgn.lit);
    if (resultR == -1) {
      //------------------------
      //   R is unsatisfiable
      //------------------------
      //printf("R is unsatisfiable after fixing var\n");
      newRow[0] = -1;
      solved = backtrack(newRow);
      trS->nNodesQallsat++;
      continue;
    }
    
    resultS = fixAsgnIn(rwsS,clsS,asgn.lit);
    if (resultS == 0) {
      resultS = rangeSat(rwsS,clsS);
    } 
/*eject*/
    if (resultS == 1) {
      //----------------------
      //   S is satisfiable
      //----------------------
      //printf("S is satisfied after fixing var\n");
      learnSat(newRow,rwsS,clsS);
      trS->nRowsSat += addRow(newRow,rwsR,clsR);
      solved = backtrack(newRow);
      trS->nNodesQallsat++;
      continue;
    }
    else if (resultS == -1) {
      //------------------------
      //   S is unsatisfiable
      //------------------------
      //printf("S is unsatisfiable after fixing var\n");
      resultR = solve(rwsR,clsR);
      if (resultR == 1) {
	solved = 1;
      }
      else {
	//------------------------
	//   R is unsatisfiable
	//------------------------
	//printf("  R is unsatisfiable \n");
	newRow[0] = -1;
	solved = backtrack(newRow);
	trS->nNodesQallsat++;
	continue;
      }
      
    }
  }
/*eject*/  
  //------------------------------------------------------------------
  //   Print results
  //------------------------------------------------------------------
  runtime = getTime();
  printf("\nINSTANCE %s\n",cnf->name);
  printf("Time: %ld\n",runtime);
  printf("no. R-conflict clauses: %d\n",trS->nRowsUnsat);
  printf("no. S-conflict clauses: %d\n",trS->nRowsSat);
  printf("no. nodes in Qallsat tree: %ld\n",trS->nNodesQallsat);
  printf("total no. nodes in Sat trees: %ld\n",trS->nNodesSat);
  printf("No. times easy part is used: %ld\n",count);

  if (solved == 1) {
    printf("Have a solution\n");
    //printSolution();
  }
  else {
    printf("Have NO solution\n");
  }

  // add results to table in file results 
  /*  
  if ((fresults = fopen("results","a")) == NULL) {
    printf("Cannot open file result\n");
  }
  fprintf(fresults,"%20s %3d %5d %5d %8ld %8ld %8ld %8ld\n",
	  cnf->name, solved, trS->nRowsUnsat, trS->nRowsSat, 
	  trS->nNodesQallsat, trS->nNodesSat, count, runtime);
  fclose(fresults);
  */
  return 0;
}
/*eject*/
//--------------------------------------------------------------------
//  long getTime ()
//
//  precondition:
//    the time variables are initialized
//  Return value:
//    the total time from first initialization of the timer to now.
//
//--------------------------------------------------------------------
long getTime () 
{
  timer.prev = time(&timer.prev);
  return (long)difftime(timer.prev,timer.start);
}
//--------------------------------------------------------------------
//  int initTimer ()
//
//  description:
//    initialize the time variables
//  postcondition:
//    time.start = current time
//    time.last  = current time
//  Return value:
//    1
//
//--------------------------------------------------------------------
int initTimer ()
{
  timer.start = time(&timer.start);
  timer.prev = timer.start;

  return 1;
}
//--------------------------------------------------------------------
//  int printSolution ()
//
//  description:
//    Print the truth values of the q variables
//  Return value:
//    1
//
//--------------------------------------------------------------------
int printSolution () 
{
  int var;

  for (var=1; var<=vrs->nQ; var++) {
    printf("%10s %3d\n",vrs->name[var], vrs->val[1][var]);
  }

  return 1;
}
//----------------------     qallsat.c end     -----------------------

