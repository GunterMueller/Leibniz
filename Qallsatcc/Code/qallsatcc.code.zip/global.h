#ifndef GLOBAL_H
#define GLOBAL_H

FILE *finput;

struct CNF *cnf;
struct Rows *rwsR;
struct Rows *rwsS;
struct Cols *clsR;
struct Cols *clsS;
struct Vars *vrs;

struct TreeSearch *trS;
struct Tree *tree;
struct Set *unitLit;
struct Set *qLit;

int newRow[MAX_ROW_LEN+2];
int newRowSave[MAX_ROW_LEN+2];

// variables range calculations
struct Range *range;

// flag for various usage
// flag is reset to 0 after use
int *litFlg;

// read input
int readComment;
int readC;

struct Timer timer;

long count;

int testFlg;
#endif
