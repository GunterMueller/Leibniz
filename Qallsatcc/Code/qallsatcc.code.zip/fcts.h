#ifndef FCTS_H
#define FCTS_H

//--------------------------------------------------------------------
//
//   Qallsat functions
//
//-------------------------------------------------------------------
int  printSolution () ;
long getTime ();
int  initTimer ();

//--------------------------------------------------------------------
//
//   Formula functions
//
//--------------------------------------------------------------------
//  read input formula from file
int readFormula (char*);
int readPrbName ();
int readRows (struct Rows*, char*);
int readVars (char*);
int getVarIdx (char *);
int genCols (struct Rows*, struct Cols*);
int nextWord (char*);
int nextWordSetup ();
int lowercase (char*);

// print structure content
int printVars (struct Vars*);
int printRows (struct Rows*);
int printCols (struct Cols*);

// modify variable value
int fixAsgnIn (struct Rows*, struct Cols*, int);
int freeVar (int);
int freeVarIn (struct Rows*, struct Cols*, int);

int delVarIn (struct Rows*, struct Cols*, int);
int restoreVarIn (struct Rows*, struct Cols*, int);

// add clauses
int addRow (int*, struct Rows*, struct Cols*);
int addToRows (int*, struct Rows*);
int addToCols (int, int*, struct Cols*, struct Rows*);

int resizeCols (struct Cols*, int s);
int regenCols (struct Rows*, struct Cols*);
int resizeRows (struct Rows*, int);
int rearrangeRows (struct Rows*, int);

// delete clauses
int delRow (int, struct Rows*, struct Cols*);
int delFromCols (int, struct Rows*, struct Cols*);
int delFromRows (int, struct Rows*, struct Cols*);

int decompose (struct Rows*, struct Cols*);

// solve SAT problem
int solve (struct Rows*, struct Cols*);

// solve rangeSAT problem
int computeRange (struct Rows* rws, struct Cols* cls);
int rangeSat (struct Rows* rws, struct Cols* cls);

//--------------------------------------------------------------------
//
//   Tree functions
//
//--------------------------------------------------------------------
int initSearch ();
int getAsgnQallsat (struct Assignment*);
int getAsgnSat (struct Rows*, struct Cols*, struct Assignment*);
int addToTree (struct Assignment);

int learnUnsat (int*, struct Rows*, struct Cols*);
int learnSat (int*, struct Rows*, struct Cols*);
int tryValues (struct Rows*, struct Cols*, int);
int backtrack (int*);
int backtrackIn (int*, struct Rows*, struct Cols*);

int printTreeSearch (struct TreeSearch*);
int printTree (struct Tree*);
int printSet (struct Set*);

int setupSolve (struct Rows *);
int resetSolve (struct Rows*, struct Cols*);

int rangeSat (struct Rows*, struct Cols*);
int computeRangeAll (struct Rows*, struct Cols*);
int computeRangePart (struct Rows*, struct Cols*);
#endif
