#ifndef MACROS_H
#define MACROS_H


#define Free    0
#define False  -1
#define True    1
#define Del    10

#define MAX_ROW_LEN     25
#define MAX_ROW_LEN_ACT 25

#endif
