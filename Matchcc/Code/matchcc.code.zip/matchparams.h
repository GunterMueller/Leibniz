/* first record of matchparams.h *****/

/******************* Includes **********************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <math.h>
#include <time.h>

/******************* Input Maximums ****************************/
#define MAX_ATTRIBUTE 1000   /* 300 */
#define MAX_CLASS 10         /* max classes for targets */
#define MAX_TIME_POINT 20    /* max number of time points */
#define MAXLEN 15000	       /* length of buffer for file line */ 
#define MAX_RECORD 6000
#define MAX_RECORD_HUGE 22000
#define MAX_TARGET MAX_ATTRIBUTE
#define MAX_ID 256
#define MAX_DIRECTORY 256
#define MAX_ENTRY 256
#define MAX_INTERVAL 10
#define MAX_NUM 15  /* max digits of numerical record entry */
#define MAX_INEQUALITY 50 /* max number of inequalities for */
                          /* a polyhedron */
#define MAX_REGRESS_REC  2000 /* max number of regression records */
#define MAX_REGRESS_VAR  100 /* max number of regression variables */
#define MAX_REGRESS_FUNC 100 /* max number of regression functions */
/******************* Test File Record Types ********************/
#define A 1
#define B 2
#define SKIP 10
#define ATTRIBUTE 11
#define DATA 12
#define RECORD 13
#define ENDATA 14

#define FALSE 0
#define TRUE 1
#define ACTIVE 1
#define DELETE 2
#define DISCARD 3
#define TARGET 4
#define INFTY 999999999.0
#define NEGINFINITY -999999999.0
#define QUESTION_MARK 909090909
#define EPSILON 0.0001
#define REGRESSION_ERROR_THRESHOLD 0.7
/*eject*/
/******************* Substitution Functions *********************/
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))
#define CLOSE_TO_ONE 0.9999
#define roundDownToInt(x) ((x) >=0?(int)((x)):(int)((x)-CLOSE_TO_ONE))
#define roundUpToInt(x) ((x) >=0?(int)((x)+CLOSE_TO_ONE):(int)((x)))
/****************************************************************/
/* Global Arrays and Variables */
double trainVector[MAX_RECORD+1][MAX_ATTRIBUTE+1];
int numTrainVectors;

double testVector[MAX_ATTRIBUTE+1];
int numTestVectors;

double solutionVector[MAX_ATTRIBUTE+1];
double differenceVector[MAX_ATTRIBUTE+1];
double distance[MAX_RECORD+1];
double distanceThreshold;

double reflectVector[MAX_ATTRIBUTE+1];
double reflectDoubleVector[MAX_ATTRIBUTE+1];
double distanceReflect[MAX_RECORD+1];

int numVariables;
int numActiveVariables; /* number of ACTIVE variables */
int numDeleteVariables; /* number of DELETE variables */
int statusVariable[MAX_ATTRIBUTE+1]; /* = ACTIVE: active */
                                     /* = DELETE: deleted */
                                     /* = DISCARD: discarded */
int activeIndex[MAX_ATTRIBUTE+1];
/* activeIndex[i] = j means: variable j is the ith active variable */
/*      i = 1,.., numActiveVariables; j = 1, ..,snumVariables */
int deleteIndex[MAX_ATTRIBUTE+1];
/* deleteIndex[i] = j means: variable j is the ith delete variable */
/*      i = 1,.., numDeleteVariables; j = 1, .., numVariables */

/* flag for use of regression */
int useRegressionFlag; /* = TRUE: use regression; = FALSE: do not */

char percent[2];
/*eject*/
/* data structures for regression */

/* input of regression() */
int numRegressRecords; /* number of records */
int numRegressVariables; /* number of regression variables */
int numRegressFunctions; /* number of functions to be estimated */
 
double Amatrix[MAX_REGRESS_REC+1][MAX_REGRESS_VAR+2];
       /* given data; row = record; column = variable */
double Dmatrix[MAX_REGRESS_REC+1][MAX_REGRESS_FUNC+1];
       /* given data; row = record; column = function */

/* intermediate arrays used only by regression() */
double Bmatrix[MAX_REGRESS_VAR+1][MAX_REGRESS_VAR+1];
         /* = Amatrix^t * Amatrix */
double Binverse[MAX_REGRESS_VAR+1][MAX_REGRESS_VAR+1];
         /* = inverse of Bmatrix */
double Dupdated[MAX_REGRESS_VAR+1][MAX_REGRESS_FUNC+1];
         /* = Amatrix^t * Dmatrix */

/* output of regression() */
double Wmatrix[MAX_REGRESS_VAR+1][MAX_REGRESS_FUNC+1];
      /* estimating coefficients; row = variable; column = function */
      /* = Binverse * Dupdated */
/*eject*/
/****************************************************************/
/* Global Input and Output files */
FILE *trainmstfile;
FILE *testatsfile;
FILE *matchatsmstfile;
FILE *matcherrorfile;
FILE *matchlearnfile;
FILE *matchsolutionfile;
FILE *averageerrorfile;

char trainmst_filename[MAX_ID];
char testats_filename[MAX_ID];
char matchatsmst_filename[MAX_ID];
char matcherror_filename[MAX_ID];
char matchlearn_filename[MAX_ID];
char matchsolution_filename[MAX_ID];
char averageerror_filename[MAX_ID];
/****************************************************************/
/* routines */

/* matchcc.c */
double distance2vectors(double *x, double *y, int type);
void record2vector(char *rec, double *x);
void openfiles();
void writeline(FILE *output_file, char line[]);
void writevector(FILE *output_file, double *vector, 
                 int firstj, int lastj);

/* regression.c */
void regression();

/* last record of matchparams.h *****/


