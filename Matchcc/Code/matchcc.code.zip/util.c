/* Utility routines */
#include "matchparams.h"
#include "features.h"
/***************************************************************
 *
 * subroutines in this file:
 *   double distance2vectors(double *x, double *y, int type)
 *   void record2vector(char *rec, double *x)
 *   void record2vector(char *rec, double *x)
 *   void openfiles()
 *   void writeline(FILE *output_file, char line[])
 *   void writevector(FILE *output_file, double *vector, 
 *               int firstj, int lastj)
 ****************************************************************/
/*eject*/
/*eject*/
/************************************************************
 *   distance2vectors(): compute distance between two
 *   vectors using entries of specified type
 ************************************************************/
double distance2vectors(double *x, double *y, int type) {

  int j;
  double dist;

/* Obsolete: Euclidean distance */
/*  dist = 0.0;
  for (j=1; j<=numVariables; j++) {
     if (statusVariable[j] == type) {
       dist += pow((x[j]-y[j]),2);
     }
  }
  dist = sqrt(dist);
*/

/* L-infinity distance */
  dist = 0.0;
  for (j=1; j<=numVariables; j++) {
     if (statusVariable[j] == type) {
       dist = max(dist,fabs(x[j]-y[j]));
     }
  }

  return dist;

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  record2vector(): convert record to numerical vector x
* --------------------------------------------------------
***************************************************************/
void record2vector(char *rec, double *x) {

  int j;
  char *buffer;
  char saveRec[MAXLEN];

  /* copy record rec into saveRec since strtok modifies string */
  strcpy(saveRec,rec);
  
  buffer = strtok(saveRec," \t\n");
  if (buffer == NULL) {
    fprintf(stderr,"matchcc: Unexpected train.mst record\n");
    exit(1);
  }
  x[1] = (double) atof(buffer);

  for (j=2; j<=numVariables; j++) {
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL) {
      fprintf(stderr,"matchcc: Unexpected end of train.mst record\n");
      exit(1);
    }
    x[j] = (double) atof(buffer);
  } /* end for j */

   /* verify that end of record has been reached */
   buffer = strtok(NULL," \t\n");
   if (buffer != NULL) {
     fprintf(stderr,
          "matchcc: train.mst record has too many entries\n");
     exit(1);
   }

  return;

}
/*eject*/
/*********************************************************
 *  openfiles
 * 
 *  purpose:  opens input and output files
 *            files are declared as global variables
 *********************************************************/
void openfiles()
{

  if ((trainmstfile = fopen(trainmst_filename, "r")) == NULL) {
    fprintf(stderr, 
            "matchcc: Cannot open trainmst_filename = %s\n", 
            trainmst_filename);
    exit(1);
  }
  if ((testatsfile = fopen(testats_filename, "r")) == NULL) {
    fprintf(stderr, 
            "matchcc: Cannot open testats_filename = %s\n", 
             testats_filename);
    exit(1);
  }
  if ((matchatsmstfile = fopen(matchatsmst_filename, "w")) == NULL) {
    fprintf(stderr, 
            "matchcc: Cannot open matchatsmst_filename = %s\n", 
             matchatsmst_filename);
    exit(1); 
  } 
  if ((matcherrorfile = fopen(matcherror_filename, "w")) == NULL) {
    fprintf(stderr, 
            "matchcc: Cannot open matcherror_filename = %s\n", 
            matcherror_filename);
    exit(1); 
  }
  if ((matchlearnfile = fopen(matchlearn_filename, "w")) == NULL) {
    fprintf(stderr, 
            "matchcc: Cannot open matchlearn_filename = %s\n", 
            matchlearn_filename);
    exit(1); 
  }    
  if ((matchsolutionfile = 
       fopen(matchsolution_filename, "w")) == NULL) {
    fprintf(stderr, 
            "matchcc: Cannot open matchsolution_filename = %s\n", 
            matchsolution_filename);
    exit(1); 
  } 
  if ((averageerrorfile = 
       fopen(averageerror_filename, "w")) == NULL) {
    fprintf(stderr, 
            "matchcc: Cannot open averageerror_filename = %s\n", 
            averageerror_filename);
    exit(1); 
  }  
  return;

}
/*eject*/
/*********************************************************
 *  writeline
 * 
 *  purpose:  prints line of text to a file
 *            
 *********************************************************/
void writeline(FILE *output_file, char line[])
{
  fprintf(output_file, "%s", line);
}
/*eject*/
/*********************************************************
 *  writevector
 * 
 *  purpose:  prints double vector of length n as integers
 *            on one line, with tab spacing
 *            
 *********************************************************/
void writevector(FILE *output_file, double *vector, 
                 int firstj, int lastj)
{
  int iv, j;

  for (j=firstj; j<=lastj; j++) {
    iv = (int)(fabs(vector[j])+0.5);
    if (vector[j] < 0) {
      iv *= -1;
    }
    fprintf(output_file, "%d\t", iv);
    /* above 5 lines replaces */
    /*fprintf(output_file, "%d\t", (int)(vector[j]+0.5));*/
  }
  fprintf(output_file, "\n");
}

/* last record of match.c****/
