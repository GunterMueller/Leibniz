/* first record of regression.c *****/
#include "matchparams.h"
#include "features.h" /* system version selection */
/**************************************************************/
/*
 * subroutines in this file:
 *   void  regression()
 */
/***************************************************************/
/*eject*/
/************************************************************
 *   regression(): do ridge regression
 *       input:  Amatrix[][]
 *               Dmatrix[][]
 *       output: Wmatrix[][]
 *       for details, see matchparams.h    
 ************************************************************/
void regression() {

  int i, j, k, m;

  double pivot, ridgeBias;

  ridgeBias = 0.05;

  /* define Dupdated = Amatrix^t * Dmatrix */
  for (k=1; k<=numRegressFunctions; k++ ) {
    for (i=1; i<=numRegressVariables; i++) {
      Dupdated[i][k] = 0.0;
      for (j=1; j<=numRegressRecords; j++) {
        Dupdated[i][k] += Amatrix[j][i] * Dmatrix[j][k];
      }
    }
  }

  /* define Bmatrix = Amatrix^t * Amatrix */
  for (i=1; i<=numRegressVariables; i++) {
    for (j=1; j<=numRegressVariables; j++) {
      Bmatrix[i][j] = 0.0;
      for (m=1; m<=numRegressRecords; m++) {
        Bmatrix[i][j] += Amatrix[m][i] * Amatrix[m][j];
      }
    }
  }
/*eject*/
  /* compute Binverse using in-place method */

  /* initialize Binverse */
  for (i=1; i<=numRegressVariables; i++) {
    for (j=1; j<=numRegressVariables; j++) {
      Binverse[i][j] = Bmatrix[i][j];      
    }
  }

  /* compute inverse in place */  
  for (k=1;k<=numRegressVariables;k++) {
    if (k == 2) {
      /* after first pivot, each new entry Binverse'[i][i], i >= 2,
       * has become, in terms of the original matrix entries,
       * =  Binverse[i][i] - 
       *      (Binverse[i][1]*Binverse[1][i]/Binverse[1][1])
       * =  sum of squared x_i values - 
       *      n * (estimated mean for x_i)^2
       * =  n * estimated variance for x_i
       * we increase the Binverse'[i][i] for ridge regression
       * by a factor > 1 
       * this reduces coefficients for slope and curve according
       * ridge regression theory and assures that the coefficients
       * have correct values
       * if  Binverse'[i][i] = 0:
       *    have a constant column in Amatrix
       *    introduce appropriate value using lambda
       *    to achieve det != 0
       */
      for (i=2; i<=numRegressVariables; i++) {
        if (Binverse[i][i] !=0) {
          Binverse[i][i] *= (1+ridgeBias);
        } else {
          Binverse[i][i] = ridgeBias * (double)numRegressVariables;
        }
      }
    }
    pivot = Binverse[k][k];

    /* if pivot element is too small, stop */
    if ( fabs(pivot) < 1.0e-10) {
     /* obsolete: */
       /* Binverse[k][k] = 1; */
       /* pivot = Binverse[k][k]; */
     fprintf(stderr,
      "regression: Error: pivot element too small\n");
      exit(1);
    }
    /* if pivot element is too large, stop */
    if (pivot > 1.e200) {
      fprintf(stderr,
      "regression: Error: pivot element too large\n");
      exit(1);
    }
    Binverse[k][k] = 1;
    for (j=1;j<=numRegressVariables;j++) {
      Binverse[k][j] = Binverse[k][j]/pivot;
    }
    for (i=1;i<=numRegressVariables;i++) {
      if (i != k) {
        pivot = Binverse[i][k];
        Binverse[i][k] = 0;
        for (j=1;j<=numRegressVariables;j++) {
          Binverse[i][j] = Binverse[i][j] - pivot*Binverse[k][j];
        }
      }
    }
  }

 /* define Wmatrix = Binverse * Dupdated */
 /*                = matrix with coefficients of functions */
  for (k=1; k<=numRegressFunctions; k++) {
    for (i=1; i<=numRegressVariables; i++) {
      Wmatrix[i][k] = 0.0;
      for (j=1; j<=numRegressVariables; j++) {
        Wmatrix[i][k] += Binverse[i][j] * Dupdated[j][k];
      }
    }
  }

  return;

}
