#include "matchparams.h"
#include "features.h"

/*
 *   Leibniz System: Lsqcc System
 *   Copyright 2015 by Leibniz Company
 *   Plano, Texas, U.S.A.
***********************************************************
 * Program matchcc
 *
 * Caution: All data are required to be nonnegative integers.
 *          Good accuracy is achieved if the integers are in the
 *          range 0 - 10^6
 *
 * For each record v in input test.ats file, 
 * either: 
 *   find records w in input train.mst file 
 *   that are best possible matches of v using
 *   L-infinity distance of the values of non-DELETE attributes.
 *   Then estimate values of the DELETE attributes of test records
 *   from those of train records.
 * or:
 *   use ridge regression to estimate DELETE values of test records
 *   from ACTIVE and DELETE values of the training records.
 *
 *  Caution: DELETE attributes that have a comment portion 
 *           containing the word DISCARD are disregarded.
 *  Example record: x DELETE * DISCARD
 *                  Attribute x is ignored
 *  Caution: if regression is used, then file match.ats.mst has
 *           "REGRESS" as first entry instead of distance to closest
 *           training vector
 *
 *   train.mst = training data file (input)
 *   test.mst  = testing data file  (input)
 *               note: test file may also be in .ats format,
 *                     with commented-out attributes
 *   match.ats.mst = matching results file (output)
 *   match.error = matching error file (output)
 *   match.test = extended test record file, 
 *                with distance (output)
 *   match.solution = extended solution record file, 
 *                    with distance (output)
 *   average.error = average error as fraction of range of values
 *                  (output)
 *
 *   From the command line:
 *
 *   ./match train.mst test.mst match.ats.mst match.error \
 *                     match.test match.solution average.error
 */
/*eject*/
/* main function */
int main(int argc, char *argv[])
{
  char lineread[MAXLEN] = {'\0'};
  int  flag, i, j, k, n, nmatch, recordType;

  int  minidx, minidxref;
  double mindist, mindistref;
  double del, delepssum, delsquaresum, eps, lambda;
  double avgdiff, maxdiff, totdiff, totdiffsum;

  mindistref = 0.0; /* to suppress compiler warning */
  mindist = 0.0;    /* to suppress compiler warning */

  strcpy(percent,"%");

  recordType = 0;
  numTrainVectors = 0;
  numTestVectors = 0;
  numVariables = 0;
  numActiveVariables = 0;
  numDeleteVariables = 0;
  statusVariable[0] = DISCARD;

 if (argc != 8) {
    fprintf(stderr,"Calling Sequence for matchcc:  ");
    fprintf(stderr,"matchcc train.mst test.mst match.result ");
    fprintf(stderr,"match.error match.learn match.solution ");
    fprintf(stderr,"average.error\n");
    exit(1);
  }
  strcpy(trainmst_filename, argv[1]);
  strcpy(testats_filename, argv[2]);
  strcpy(matchatsmst_filename, argv[3]);
  strcpy(matcherror_filename, argv[4]);
  strcpy(matchlearn_filename, argv[5]);
  strcpy(matchsolution_filename, argv[6]);
  strcpy(averageerror_filename, argv[7]);

  /* DEBUG: comment out above two sections and activate code below */
  /* strcpy(trainmst_filename, 
     "small.train.mst");
  strcpy(testats_filename, "small.test.mst");
  strcpy(matchatsmst_filename, "match.result");
  strcpy(matcherror_filename, "match.error");
  strcpy(matchlearn_filename, "match.learn"); 
  strcpy(matchsolution_filename, "match.solution");
  strcpy(averageerror_filename, "average.error"); */
/*eject*/
  openfiles();

  /* store train.mst records in trainVector[][] */
  while (fgets(lineread, MAXLEN, trainmstfile) != NULL) {
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0')) {
      continue;
    }
    if (strncmp(lineread,"ATTRIBUTES",10) == 0) {
      writeline(matchatsmstfile,lineread);
      writeline(matchlearnfile,lineread);
      writeline(matchsolutionfile,lineread);
      writeline(matchlearnfile,"MaxError TARGETCASES_1_20_20\n");
      writeline(matchsolutionfile,"MaxError DELETE * DISCARD\n");
      continue;
    }
    if (strncmp(lineread,"ENDATA",6) == 0) {
      if (recordType != DATA) {
        fprintf(stderr,
          "matchcc: Missing DATA record in input %s file\n",
          trainmst_filename);
        exit(1);
      } else {
        recordType = ENDATA;
        break;
      }
    }
    if (strncmp(lineread,"DATA",4) == 0) {
      if (recordType != 0) {
        fprintf(stderr,"matchcc: Input records out of order\n");
        exit(1);
      } else {
        writeline(matchatsmstfile,lineread);
        writeline(matchlearnfile,lineread);
        writeline(matchsolutionfile,lineread);
        recordType = DATA;
        continue;
      }
    }
/*eject*/
    if (recordType == 0) {
      numVariables++;
      statusVariable[numVariables] = ACTIVE;
      for (i=1; i<strlen(lineread); i++) {
        if (strncmp(&lineread[i],"DELETE",6) == 0) {
          statusVariable[numVariables] = DELETE;
        }
        /* treat TARGET case like DELETE for matching */
        if (strncmp(&lineread[i],"TARGET",5) == 0) {
          statusVariable[numVariables] = DELETE;
        }
        if (strncmp(&lineread[i],"DISCARD",7) == 0) {
          statusVariable[numVariables] = DISCARD;
          break;
        }
      }

      if (statusVariable[numVariables] == ACTIVE) {
        numActiveVariables++;
        activeIndex[numActiveVariables] = numVariables;
      } else if (statusVariable[numVariables] == DELETE) {
        numDeleteVariables++;
        deleteIndex[numDeleteVariables] = numVariables;
      }
 
      writeline(matchatsmstfile,lineread);
      /* replace 'TARGET' by 'DELETE' for match.test line */
      for (i=1; i<strlen(lineread); i++) {
        if (strncmp(&lineread[i],"TARGET",5) == 0) {
          strcpy (&lineread[i],"DELETE\n");
          break;
        }
      }
      writeline(matchlearnfile,lineread);
      writeline(matchsolutionfile,lineread);
      continue;
    }
/*eject*/
    if (recordType == DATA) {
      /* store train.mst record */
      numTrainVectors++;
      record2vector(lineread, trainVector[numTrainVectors]);
      trainVector[numTrainVectors][0] = 0.0;
      continue;
    }
    fprintf(stderr,"matchcc: Input file in error\n");
    exit(1);   
  }
  if (recordType != ENDATA) {
    fprintf(stderr,"matchcc: Missing ENDATA record in %s file\n",
            trainmst_filename);
    exit(1);
  }

  /* regression disabled Oct 18, 2011 */
  /* if number of train records is at least three times the */
  /* number of active variables, then use regression to estimate */ 
  /* entries for DELETE variables */

  /* if (numTrainVectors >= 3*numActiveVariables+1) { */
    /* assures that there are more records then variables in */
    /* regression formulation with constant, linear terms, */
    /* and quadratic terms representing the active variables */
  /*  useRegressionFlag = TRUE;
  } else { */
    useRegressionFlag = FALSE;
  /* } */

  /* check array limits */
  if (numTrainVectors > MAX_REGRESS_REC) {
    fprintf(stderr,"MAX_REGRESS_REC = %d must be increased to %d\n",
                    MAX_REGRESS_REC, numTrainVectors);
    exit(1);
  }
  if (2*numActiveVariables+1 > MAX_REGRESS_VAR) {
    fprintf(stderr,
      "Case 1: MAX_REGRESS_VAR = %d must be increased to %d\n",
                    MAX_REGRESS_VAR, 2*numActiveVariables+1);
    exit(1);
  }
  if (numDeleteVariables > MAX_REGRESS_VAR) {
    fprintf(stderr,
      "Case 2:MAX_REGRESS_VAR = %d must be increased to %d\n",
                    MAX_REGRESS_VAR, numDeleteVariables);
    exit(1);
  }

  if (useRegressionFlag == TRUE) {

    /* define Amatrix and Dmatrix */
    for (i=1; i<=numTrainVectors; i++) {
      Amatrix[i][1] = 1.0; /* for the constant of the function */
                           /* computed by regression() */
      for (j=1; j<=numActiveVariables; j++) {
        Amatrix[i][j+1] = 
           trainVector[i][activeIndex[j]]; /* linear term */
        Amatrix[i][j+numActiveVariables+1] = 
           pow(trainVector[i][activeIndex[j]],2); /* quadratic term */
      }
      for (k=1; k<=numDeleteVariables; k++) {
        Dmatrix[i][k] = trainVector[i][deleteIndex[k]];
      }
    }
    /* define counts for regression */
    numRegressRecords = numTrainVectors;
    numRegressVariables = 2*numActiveVariables + 1;
    numRegressFunctions = numDeleteVariables;

    /* compute Wmatrix = coefficients of estimating functions */
    /* for DELETE variable values */
    regression();

  } /* end if useRegressionFlag == TRUE */
/*eject*/
  /* process test.ats file records */
  totdiffsum = 0.0;
  recordType = 0;
  while (fgets(lineread, MAXLEN, testatsfile) != NULL) {
    if ((lineread[0] == '\n') ||
        (lineread[0] == '\0')) {
      continue;
    }
    if (strncmp(lineread,"ENDATA",6) == 0) {
      if (recordType != DATA) {
        fprintf(stderr,
                "matchcc: Missing DATA record in input %s file\n",
                testats_filename);
        exit(1);
      } else {
        writeline(matchatsmstfile,lineread);
        writeline(matchlearnfile,lineread);
        writeline(matchsolutionfile,lineread);
        recordType = ENDATA;
        break;
      }
    }
    if ((strncmp(lineread,"*DATA",5) == 0) ||
        (strncmp(lineread,"DATA",4) == 0)) {
      if (recordType != 0) {
        fprintf(stderr,"matchcc: Input records out of order\n");
        exit(1);
      } else {
        recordType = DATA;
        continue;
      }
    }
    if (recordType == 0) {
      continue;
    }
/*eject*/
    if (recordType == DATA) {
      numTestVectors++;
      /* convert record to vector */
      record2vector(lineread,testVector);
      testVector[0] = 0.0;
      solutionVector[0] = 0.0;
      /* initialize solution vector */
      for (j=1; j<=numVariables; j++) {
        if ((statusVariable[j] == ACTIVE) ||
            (statusVariable[j] == DISCARD)) {
          solutionVector[j] = testVector[j];
        } else {
          solutionVector[j] = 0.0; 
        }
      }

      /* compute values for DELETE variables by regression or */
      /* convex combination of neighbors */
      if (useRegressionFlag == TRUE) {
        /* estimate DELETE entries of test vector using regression
         * function of Wmatrix
         * store resulting estimates in solutionVector, together
         * with values for ACTIVE variables 
         * have following relationships
         *   numRegressRecords = numTrainVectors;
         *   numRegressVariables = numActiveVariables + 1;
         *   numRegressFunctions = numDeleteVariables; 
         */
        solutionVector[0] = 0;
        for (i=1; i<=numActiveVariables; i++) {
          solutionVector[activeIndex[i]] = 
             testVector[activeIndex[i]];
        }
        for (k=1; k<=numDeleteVariables; k++) {
          solutionVector[deleteIndex[k]] = Wmatrix[1][k];
          for (j=1; j<=numActiveVariables; j++) {
            solutionVector[deleteIndex[k]] +=   /* linear term */
                 Wmatrix[j+1][k] * testVector[activeIndex[j]];
            solutionVector[deleteIndex[k]] +=   /* quadratic term */
                 Wmatrix[j+numActiveVariables+1][k] * 
                    pow(testVector[activeIndex[j]],2);
          }
        }
/*eject*/
      /* use convex combination of points */
      } else {
        /* find matching records in trainVector[][] */
        distance[1] = 
           distance2vectors(testVector,trainVector[1],ACTIVE);
        mindist = distance[1];
        minidx = 1;
        for (n=2; n<=numTrainVectors; n++) {
          distance[n] = distance2vectors(testVector,
                                         trainVector[n],ACTIVE);
          if (mindist > distance[n]) {
            mindist = distance[n];
            minidx = n;
          }       
        }
        /* increase mindist by 1.0 */
        mindist += 1.0;
        /* have mindist and minidx */

        /* solution vector DELETE values = convex combination of */
        /* minidx point and a second point that is on other side */
        /* of test point; the second point is a training point */
        /* closest to a reflected point called reflectVector */
        /* determined from the minidx point and the testing vector */
        /* the candidate training points must be within mindist */
        /* distance of a second reflected point called */
        /* reflectDoubleVector that lies beyond reflectVector */
        /* and is twice as far from the testing point as */
        /* reflectVector */
        for (j=1; j<=numVariables; j++) {
          if (statusVariable[j] == ACTIVE) {
            reflectVector[j] = 
                 2*testVector[j] - trainVector[minidx][j];
            reflectDoubleVector[j] = 3*testVector[j] - 
                                     2*trainVector[minidx][j];
          }
        }
/*eject*/
        /* find training vector closest to reflectVector */
        /* and within mindist of reflectDoubleVector */
        if (distance2vectors(reflectDoubleVector, 
                             trainVector[1],ACTIVE) <= mindist) {   
          distanceReflect[1] = 
            distance2vectors(reflectVector,trainVector[1],ACTIVE);
          mindistref = distanceReflect[1];
          minidxref = 1;
        } else {
          minidxref = 0;
        }
        for (n=2; n<=numTrainVectors; n++) {
          if (distance2vectors(reflectDoubleVector, 
                             trainVector[n],ACTIVE) <= mindist) {
            distanceReflect[n] = distance2vectors(reflectVector,
                                         trainVector[n],ACTIVE);
            if ((minidxref == 0) || 
                (mindistref > distanceReflect[n])) {
              mindistref = distanceReflect[n];
              minidxref = n;
            }
          }      
        }
/*eject*/
        /* if minidxref = 0, no training point is close enough */
        /* to reflectDoubleVector to be used as second training */
        /* point, and minidxref is set equal to minidx */
        if (minidxref == 0) {
          minidxref = minidx;
        }

        /* below, flag = TRUE means minidx and minidxref have same */
        /* ACTIVE entries */
        flag = TRUE;     
        for (j=1; j<=numVariables; j++) {
          if ((statusVariable[j] == ACTIVE) &&
              (fabs(trainVector[minidx][j] - 
                    trainVector[minidxref][j]) > 0.5)) {
            flag = FALSE;
            break;
          }
        }

        /* if minidx and minidxref have same ACTIVE entries, then */
        /* DELETE entries of solution vector are the average of */
        /* all training vectors within distance mindist */
        if (flag == TRUE) {
          nmatch = 0;
          for (n=1; n<=numTrainVectors; n++) {
            if (distance[n] <= mindist) {
              nmatch++;
              for (j=1; j<=numVariables; j++) {      
                if (statusVariable[j] == DELETE) {
                  solutionVector[j] += trainVector[n][j];
                }
              } /* end for j */
            } /* end if distance[n] <= mindist */
          } /* end for n */
          if (nmatch == 0) {
           fprintf(stderr,"matchcc: Error: nmatch must be nonzero\n");
           exit(1);           
          }
          for (j=1; j<=numVariables; j++) {
            if (statusVariable[j] == DELETE) {
              solutionVector[j] /= (double)nmatch;
            }
          }
/*eject*/
        } else {
          /* minidx and minidxref have distinct ACTIVE entries */
          /* find point closest to testing vector on the */
          /* line going through the two training vectors */
          /* minidx and minidxref, using ACTIVE entries only */
         delepssum = 0.0;
         delsquaresum = 0.0;
         for (j=1; j<=numVariables; j++) {
            if (statusVariable[j] == ACTIVE) {
              del = trainVector[minidxref][j] - 
                       trainVector[minidx][j];
              eps = testVector[j] - trainVector[minidx][j];
              delepssum += del * eps;
              delsquaresum += del * del;
            }
          }
          if (delsquaresum < 0.5) {
            fprintf(stderr,
              "matchcc: Error: delta square sum must be >= 1.0\n");
            exit(1);
          }
          lambda = delepssum/delsquaresum;
          if (lambda < 0.0 || lambda > 1.0) {
            lambda = 0.0; /* use minidx point only */
          }
          /* closest point = (1-lambda)*(trainVector[minidx][j] + */
          /*                 lambda*trainVector[minidxref][j] */
          for (j=1; j<=numVariables; j++) {
            if (statusVariable[j] == DELETE) {
              solutionVector[j] = 
                   (1-lambda)*(trainVector[minidx][j]) +
                   lambda*trainVector[minidxref][j];
            }
          }       
        } /* end if flag == TRUE, else */

      } /* end if useRegressionFlag == TRUE, else */
/*eject*/
      /* write vectors into match.ats.mst file */
      fprintf(matchatsmstfile, "Test = %d\n", numTestVectors);
      if (useRegressionFlag == TRUE) {
        fprintf(matcherrorfile,"REGRESS\t");
      } else {
        fprintf(matcherrorfile,"%d\t", (int)mindist);
      }
      /* test vector */
      writevector(matchatsmstfile, testVector, 1, numVariables);
      /* solution vector */
      writevector(matchatsmstfile, solutionVector, 1, numVariables);
      /* difference vector; only considers DELETE attributes */
      totdiff = 0.0;
      maxdiff = 0.0;
      for (j=1 ;j<=numVariables; j++) {
        if (statusVariable[j] != DELETE) {
          differenceVector[j] = 0;
        } else {
          differenceVector[j] = 
                (double)((int)(testVector[j]+0.5)-
                         (int)(solutionVector[j]+0.5));
          /* above line replaces line below */
          /* differenceVector[j] = 
                testVector[j] - solutionVector[j]; */
          if (differenceVector[j] < 0.0) {
            totdiff -= differenceVector[j];
            if (maxdiff < -differenceVector[j]) {
              maxdiff = -differenceVector[j];
            }
          } else {
            totdiff += differenceVector[j];
            if (maxdiff < differenceVector[j]) {
              maxdiff = differenceVector[j];
            }
          }
        }
      }
/*eject*/
      totdiffsum += totdiff;
      writevector(matchatsmstfile, differenceVector, 1, numVariables);
      /* extended solution vector */
      /* regression case: define distance = 0 */
      /* else: distance = max error distance */
      if (useRegressionFlag == TRUE) {
        solutionVector[0] = 0;
      } else {
        solutionVector[0] = maxdiff;
      }
      writevector(matchsolutionfile, solutionVector, 0, numVariables);
      /* extended test vector */
      /* regression case: define distance = 0 */
      /* else: distance = max error distance */
      if (useRegressionFlag == TRUE) {
        testVector[0] = 0;
      } else {
        testVector[0] = maxdiff;
      }
      writevector(matchlearnfile, testVector, 0, numVariables); 
      /* accuracy */
      fprintf(matchatsmstfile,
      "Max Absolute Difference = %d   Sum Absolute Difference = %d\n", 
          (int)maxdiff, (int)totdiff);
      fprintf(matchatsmstfile, "\n");
      fprintf(matcherrorfile,"%d\n",(int)maxdiff);
      continue;            
    } /* end if recordType == DATA */  

    fprintf(stderr,"matchcc: Input file in error\n");
    exit(1);   
  }
/*eject*/
  if (recordType != ENDATA) {
    fprintf(stderr,
            "matchcc: Missing ENDATA record in %s file\n",
            testats_filename);
    exit(1);
  }
  fprintf(matchatsmstfile,
      "\nTotal of Absolute Differences = %g\n", totdiffsum);
  /* above line replaces */
  /* fprintf(matchatsmstfile,"\nTotal Difference Sum = %d * 10^6\n",
                          (int)(totdiffsum/1000000.0)); */
  avgdiff = totdiffsum/( ((double)numDeleteVariables) *
                            ((double)numTestVectors) );
  fprintf(matchatsmstfile,
     "Average Difference per estimated value = %f \n",
     avgdiff);
  fprintf(matchatsmstfile,
     "as percentage of 10^6 (= max allowed value) = %f%s\n",
    100.0*avgdiff/1000000.0,percent);
  fprintf(averageerrorfile,
     "Average Error = %f\n",
     avgdiff/1000000.0);
  fclose(trainmstfile);
  fclose(testatsfile);
  fclose(matchatsmstfile);
  fclose(matcherrorfile);
  fclose(matchlearnfile);
  fclose(matchsolutionfile);
  fclose(averageerrorfile);

  return 0;
}
/***** last record of matchcc.c ***************/
