/* first record of util.c *****/
#include "subcc.h"
#include "features.h" /* system version selection */
/**************************************************************/
/*
 * subroutines in this file:
 *   void  constructSubccdetail()
 *   void  closeFile(FILE* file);
 *   FILE* openFile(char* name, char* mode)
 *   FILE* openFilePrefix(char* extension, char* mode)
 *   FILE* openFileSubccdetail(char* name, char* mode)
 *   void  removeSubccdetail()
 *   void  showTargetSteps(char *message)
 *   int   stringCompare(const char *a, const char *b, int n)
 *   void  suberror(char *m1,char *m2, char *m3)
 */
/***************************************************************/
/*eject*/
/************************************************************
 *   constructSubccdetail(): construct Subcc detail directory
 ************************************************************/

void  constructSubccdetail() {

  char cmnd[MAXLEN];
  char subccdetail[MAX_DIRECTORY+MAX_ID];

  FILE *out;

/*  
 *  gParams.subccdetaildir contains a terminating '/'
 *  to be consistent with Leibniz System convention
 */

  strcpy(subccdetail,gParams.subccdetaildir);

#ifdef UNIX

  sprintf(cmnd,"test -d %s",subccdetail);
    
    if( system(cmnd)  == 0 ) {    
/*
 * directory exists already, clean it
 * after introduction of fake file TMPlsq76xi2uy3
 * so that rm command does not cause error message
 * for empty directory
 */
      out = openFileSubccdetail("TMPlsq76xi2uy3TMPlsq76xi2uy3","w");
      closeFile(out); 
      sprintf(cmnd,"rm  %s*",subccdetail);
      system(cmnd);
    } else {
/*
 * directory does not exist, create it
 */
      sprintf(cmnd,"mkdir  %s",subccdetail);
      system(cmnd);
    }

#endif /*UNIX specification */

#ifdef WINDOWS

/* remove '\\' of directory specification */
  subccdetail[strlen[subccdetail]-1] = '\0';
  sprintf(cmnd, "IF EXIST %s. (del /f /q %s\\*) ELSE mkdir %s.",
		  subccdetail, subccdetail, subccdetail);
  system(cmnd);

  #endif /* WINDOWS specification */

  return;
}
/*eject*/
/***************************************************************/
void closeFile(FILE* file) 
{
  fclose(file);
  gNumOpenFiles--;
  return; 
}
/***************************************************************/
FILE* openFile(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,"Error opening %s \n for %s. Stop.\n",
                  name, mode);
          suberror(message,"openFile","101");
	}

        gNumOpenFiles++;	
	return out;
}
/****************************************************************/
FILE* openFilePrefix(char* extension, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,gParams.directory);
	strcat(file,gParams.prefix);
	strcat(file,extension);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,
            "Error opening %s \n for %s. Stop.\n", file, mode);
	  suberror(message,"openFilePrefix","101");
	}
	
        gNumOpenFiles++;	
	return out;
}
/****************************************************************/
FILE* openFileSubccdetail(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,gParams.subccdetaildir);
	strcat(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,
              "Error opening %s \n for %s. Stop.\n", file, mode);
          suberror(message,"openFileSubccdetail","101");
	}
	
        gNumOpenFiles++;	
	return out;
}	
/*eject*/
/****************************************************
 * removeSubccdetail(): remove Subcc detail directory 
 ****************************************************/
void removeSubccdetail() {

  char cmnd[MAXLEN];
  char subccdetail[MAX_DIRECTORY+MAX_ID];

/*  
 *  gParams.subccdetaildir contains a terminating '/'
 *  to be consistent with Leibniz System convention
 */

  strcpy(subccdetail,gParams.subccdetaildir);

#ifdef UNIX  

  sprintf(cmnd,"rm %s*",subccdetail);
  system(cmnd);
  
  sprintf(cmnd,"rmdir %s",subccdetail);
  system(cmnd);

#endif /* UNIX specification */

#ifdef WINDOWS

/*
 * rd /s /q subccdetail
 */
  sprintf(cmnd, "rd /s /q %s", subccdetail);
  system(cmnd);

#endif /* WINDOWS specification */

  return;
}
/*eject*/
/****************************************************
 * showTargetSteps(): show target processing steps 
 ****************************************************/
void showTargetSteps(char *message) {

  if (gShowTargetSteps == TRUE) {
    printf("%s",message);
  }
  fprintf(errfil,"%s",message);

  return;
}
/*eject*/
/***************************************************************
* stringCompare(): convert to upper case then compare
****************************************************************/
int stringCompare(const char *a, const char *b, int n)
{
	int i;
	char aPrime[MAX_ID] = {'\0'};

	/* Convert "a" to upper case */
	for (i=0;i<n;i++)
	{

		if (a[i] >=  97 && a[i] <= 122)
			aPrime[i] = a[i] - 32;
		else
			aPrime[i] = a[i];
	}

	return strncmp(aPrime, b, n);

}
/*eject*/
/***************************************************************
*  suberror(): subcc system error termination 
****************************************************************/
void suberror(char *m1,char *m2, char *m3) {
/*
 */
  printf("%s\nStop\n",m1);
  fprintf(errfil,"%s\nStop\n",m1);

  printf("\n*******SUBCC SYSTEM ERROR*******\n");
  printf("ERROR IN %s  code %s\n",m2,m3);
  printf("**********************************\n");
  printf("For details, see error file subcc.err\n");
/*
 */
  fprintf(errfil,"\n*******SUBCC SYSTEM ERROR*******\n");
  fprintf(errfil,"ERROR IN %s  code %s\n",m2,m3);
  fprintf(errfil,"**********************************\n");
  exit(1);

}
/* last record of util.c *******/

















