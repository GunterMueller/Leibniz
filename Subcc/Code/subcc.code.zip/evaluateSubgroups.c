/* first record of evaluateSubgroups.c*******/
#include "subcc.h"
/***************************************************************/
/*
 * subroutines in this file: 
 *   void evaluateSubgroups(int atsmstcase);
 *   void addTgtInfo(int tgt, int stage);
 *   void clauseSignificance();
 *   void getClauses(int tgt, int stage);
 *   void getLiteralsAndRules(int tgt, int stage);
 *   void getVotes(int tgt, int stage);
 *   void outputRules(int atsmstcase);
 *   void outputSubgroups(FILE *subgroupResults);
 *   float significance(float prob, int numRecords, int numTrue);
 *   void valuesNormDistr();   
 *     
 */
/***************************************************************
 * evaluateSubgroups(): evaluates 4total votes for targets in
 *    targets.reducedList.ats or .mst file depending on atsmstcase
 *    outputs results in subgroup.results.ats or .mst
 ***************************************************************/
void evaluateSubgroups(int atsmstcase) {

  int tgt, stage;
  char name[MAXLEN];
  char currentTarget[MAX_ID];

  char fileRec[MAXLEN];

  FILE *targetsReducedList;
  FILE *subgroupResults;

  strcpy(currentTarget,"");

  /* open targets.reducedList.mst or .ats file */
  if (atsmstcase == MASTER) {
    sprintf(name,"targets.reducedList%s",gFileExt.mst);
  } else {
    sprintf(name,"targets.reducedList%s",gFileExt.ats);
  }
  targetsReducedList = 
    openFileSubccdetail(name,"r");

  /* open subgroup.results.mst or .ats file */
  if (atsmstcase == MASTER) {
    sprintf(name,"subgroup.results%s",gFileExt.mst);
  } else {
    sprintf(name,"subgroup.results%s",gFileExt.ats);
  }
  subgroupResults = 
    openFileSubccdetail(name,"w");

  /* compute values of normal distribution */
  valuesNormDistr();  

  while (fgets(fileRec,MAXLEN,targetsReducedList) != 0) {/*while #1*/
    /* read target index and stage */
    sscanf(fileRec,"%d%d",&tgt, &stage);

    /* get literals and associated rule inequalities 
     * of 4total cut file
     * output:
     *   numLiteralRule
     *   literal[]
     *     .literal
     *     .rule
     */
    getLiteralsAndRules(tgt,stage);
     
    /* get vote information
     * output:
     *   Aclause[] and Bclause[]
     *     .numClass
     *     .numOppositeClass
     *     .numTrueClass
     *     .numTrueOppositeClass
     *     .ARPprobability
     *   Aformula and Bformula
     *     .numClass
     *     .numOppositeClass
     *     .numTrueClass
     *     .numTrueOppositeClass
     *     .numclause
     */
    getVotes(tgt,stage);

    /* get clauses from sep file and match up literals of clauses
     * with literals/rules of literalRule[]
     * output:
     *   Aformula and Bformula
     *     .numClause
     *     .clause[][]
     *   numVariable
     *   variable[]
     *   Aclause[] and Bclause[]
     *     .numLiteral
     *     .literal[]
     *     .rule[]
     */
    getClauses(tgt,stage);

    /* compute significance of Amin and Bmin clauses
     * output:
     *   Aclause[] and Bclause[]
     *     .significanceClass
     *     .significanceOppositeClass
     *     .significanceOverall
     */
    clauseSignificance();

    /* add target information to each 
     *  clause Aclause[] and Bclause[]
     *    .target
     *    .tgt
     *    .stage
     *    .tgtVersion
     *    .tgtTypeClass
     *    .tgtTypeOppositeClass
     *    .tgtRuleClass
     *    .tgtRuleOppositeClass
     */
    addTgtInfo(tgt,stage);

    /* at this point, have available:
     *   Aclause[].<alldata>, Bclause[].<alldata>
     *   Aformula.<alldata>, Bformula.<alldata>
     *   numVariable, variable[]
     *   numLiteralRule, literalRule[].<alldata>
     */

    /* output rules corresponding to Amin and Bmin
     * of 4total case to 4total sep file 
     */
    outputRules(atsmstcase);

    /* output Aclause[] and Bclause[] */
    /* if this is a new target name, add a blank line */
    if ((strcmp(currentTarget,"") != 0) &&
        (strcmp(currentTarget,Aclause[1].target) != 0)) {
      fprintf(subgroupResults,"\n");
    }
    strcpy(currentTarget,Aclause[1].target);
    outputSubgroups(subgroupResults);

  } /* end while # 1 */

  closeFile(targetsReducedList);
  closeFile(subgroupResults);

  return;
}
/*eject*/
/************************************************
 * addTgtInfo(int tgt, int stage):
 * Add target information to Aclause[] and Bclause[]
 * For rules of cutpoints and intervals for
 * gTgtVersion[tgt] value, see subcc.h
 *
 * Output:
 *  Aclause[] and Bclause[]
 *    .target
 *    .tgt
 *    .stage
 *    .tgtVersion
 *    .tgtTypeClass
 *    .tgtTypeOppositeClass
 *    .tgtRuleClass
 *    .tgtRuleOppositeClass
 */
void addTgtInfo(int tgt, int stage){

  int i;

  /* Aclause[] target information */

  for (i=1; i<=Aformula.numClause; i++) { /* for i #1 */
    strcpy(Aclause[i].target,gTarget[tgt]);
    Aclause[i].tgt = tgt;
    Aclause[i].stage = stage;
    Aclause[i].tgtVersion = gTgtVersion[tgt];
    if (Aclause[i].tgtVersion == 1) {
      strcpy(Aclause[i].tgtTypeClass,"low");
      strcpy(Aclause[i].tgtTypeOppositeClass,"high");
      sprintf(Aclause[i].tgtRuleClass,
              "(%s < %f)",
              gTarget[tgt],gUncertainTgtLow[tgt][1]);
      sprintf(Aclause[i].tgtRuleOppositeClass,
              "(%s > %f)",
              gTarget[tgt],gUncertainTgtHigh[tgt][1]);
    } else if (Aclause[i].tgtVersion == 2) {
      strcpy(Aclause[i].tgtTypeClass,"lowhigh");
      strcpy(Aclause[i].tgtTypeOppositeClass,"middle");
      sprintf(Aclause[i].tgtRuleClass,
              "(%s < %f || %s > %f)",
              gTarget[tgt],gUncertainTgtLow[tgt][1],
              gTarget[tgt],gUncertainTgtHigh[tgt][2]);
      sprintf(Aclause[i].tgtRuleOppositeClass,
              "(%s > %f && %s < %f)",
              gTarget[tgt],gUncertainTgtHigh[tgt][1],
              gTarget[tgt],gUncertainTgtLow[tgt][2]);      
    } else {
      suberror("Target version must be = 1 or 2",
               "addTgtInfo", "103");
    }
    
  } /* end for i #1 */

  for (i=1; i<=Bformula.numClause; i++) { /* for i #2 */
    strcpy(Bclause[i].target,gTarget[tgt]);
    Bclause[i].tgt = tgt;
    Bclause[i].stage = stage;
    Bclause[i].tgtVersion = gTgtVersion[tgt];
    if (Bclause[i].tgtVersion == 1) {
      strcpy(Bclause[i].tgtTypeClass,"high");
      strcpy(Bclause[i].tgtTypeOppositeClass,"low");
      sprintf(Bclause[i].tgtRuleClass,
              "(%s > %f)",
              gTarget[tgt],gUncertainTgtHigh[tgt][1]);
      sprintf(Bclause[i].tgtRuleOppositeClass,
              "(%s < %f)",
              gTarget[tgt],gUncertainTgtLow[tgt][1]);
    } else if (Bclause[i].tgtVersion == 2) {
      strcpy(Bclause[i].tgtTypeClass,"middle");
      strcpy(Bclause[i].tgtTypeOppositeClass,"lowhigh");
      sprintf(Bclause[i].tgtRuleClass,
              "(%s > %f && %s < %f)",
              gTarget[tgt],gUncertainTgtHigh[tgt][1],
              gTarget[tgt],gUncertainTgtLow[tgt][2]);
      sprintf(Bclause[i].tgtRuleOppositeClass,
              "(%s < %f || %s > %f)",
              gTarget[tgt],gUncertainTgtLow[tgt][1],
              gTarget[tgt],gUncertainTgtHigh[tgt][2]);      
    } else {
      suberror("Target version must be = 1 or 2",
               "addTgtInfo", "203");
    }
    
  } /* end for i */

  return;
}
/*eject*/
/************************************************
 * void clauseSignificance(): 
 * compute significance of Amax/Bmax or Amin/Bmin clauses
 *
 * input:
 *   Aclause[] and Bclause[]
 *     .numClass
 *     .numOppositeClass
 *     .numTrueClass
 *     .numTrueOppositeClass

 * output:
 *   Aclause[] and Bclause[]
 *     .significanceClass
 *     .significanceOppositeClass
 *     .significanceOverall
 * 
 ************************************************/
void clauseSignificance() {

  float p;

  int i;

  /* sensitivity = fraction correct on class
   * specificity = fraction correct on opposite class
   */ 

  /* Bmax or Bmin clauses */ 

  /* decision uses the following:
   *   for Class: ARP significance
   *   for Opposite Class: average of specificity and correctness
   *       within group defined as (# True in class)/(total # True)
   */
  for (i=1; i<= Bformula.numClause; i++) {
    /* two choices for ARP probability
     * choice 1: use estimate taken from vot file
     *           and stored in Bclause[i].ARPprobability
     */
    p = Bclause[i].ARPprobability;
    /* choice 2: direct estimate from current votes */
    /* p = ((float)Bclause[i].numTrueClass + 
         (float)Bclause[i].numTrueOppositeClass) /
        ((float)Bclause[i].numClass +  
         (float)Bclause[i].numOppositeClass); */
    Bclause[i].significanceClass =
      significance(p,
                   Bclause[i].numClass,
                   Bclause[i].numTrueClass);
    /* significanceOppositeClass: initialize with specificity */
    Bclause[i].significanceOppositeClass = 1.0 -
      (float) Bclause[i].numTrueOppositeClass/
      (float) Bclause[i].numOppositeClass;
    /* add correctness within group */
    /* = (# True in class)/(total # True) */
    /* if (total # True) = 0, then define */
    /*     Bclause[i].significanceOppositeClass = 0.0 */
    if ((Bclause[i].numTrueClass + 
         Bclause[i].numTrueOppositeClass) > 0) {    
      Bclause[i].significanceOppositeClass +=
        (float) Bclause[i].numTrueClass/
        ((float) Bclause[i].numTrueClass +
         (float) Bclause[i].numTrueOppositeClass);
    } else {
      Bclause[i].significanceOppositeClass = 0.0;
    }
    /* divide by 2.0 to get average */
    Bclause[i].significanceOppositeClass /= 2.0;
    /* significanceOverall depends on significance measure */
    if (gParams.significanceMeasure == UNUSUALNESS) {
      Bclause[i].significanceOverall = 
        Bclause[i].significanceClass;
    } else if (gParams.significanceMeasure == ACCURACY) {
      Bclause[i].significanceOverall =
        Bclause[i].significanceOppositeClass; 
    } else if (gParams.significanceMeasure == BOTH) { 
      Bclause[i].significanceOverall = 
        (Bclause[i].significanceClass + 
         Bclause[i].significanceOppositeClass)/2.0;
    } else {
      suberror("Unknown significance measure",
               "clauseSignificance","101");
    }
  } /* end for i */

  /* Amax or Amin clauses */

  /* decision uses the following:
   *   for Class: ARP significance
   *   for Opposite Class: average of specificity and correctness
   *       within group defined as (# True in class)/(total # True)
   */
  for (i=1; i<= Aformula.numClause; i++) {
    /* two choices for ARP probability
     * choice 1: estimate from vot file for clause,
     * is stored in Aclause[i].ARPprobability
     */
    p = Aclause[i].ARPprobability;
    /* choice 2: direct estimate from current votes */
    /* p = ((float)Aclause[i].numTrueClass + 
         (float)Aclause[i].numTrueOppositeClass) /
        ((float)Aclause[i].numClass +  
         (float)Aclause[i].numOppositeClass); */
    Aclause[i].significanceClass =
      significance(p,
                   Aclause[i].numClass,
                   Aclause[i].numTrueClass);
    /* significanceOppositeClass: initialize with specificity */
    Aclause[i].significanceOppositeClass = 1.0 -
      (float) Aclause[i].numTrueOppositeClass/
      (float) Aclause[i].numOppositeClass;
    /* add correctness within group */
    /* = (# True in class)/(total # True) */
    /* if (total # True) = 0, then define */
    /*     Aclause[i].significanceOppositeClass = 0.0 */
    if ((Aclause[i].numTrueClass + 
         Aclause[i].numTrueOppositeClass) > 0) {     
      Aclause[i].significanceOppositeClass +=
        (float) Aclause[i].numTrueClass/
        ((float) Aclause[i].numTrueClass +
         (float) Aclause[i].numTrueOppositeClass);
    } else {
      Aclause[i].significanceOppositeClass = 0.0;
    }
    /* divide by 2.0 to get average */
    Aclause[i].significanceOppositeClass /= 2.0;
    /* significanceOverall depends on significance measure */
    if (gParams.significanceMeasure == UNUSUALNESS) {
      Aclause[i].significanceOverall = 
        Aclause[i].significanceClass;
    } else if (gParams.significanceMeasure == ACCURACY) {
      Aclause[i].significanceOverall =
        Aclause[i].significanceOppositeClass; 
    } else if (gParams.significanceMeasure == BOTH) { 
      Aclause[i].significanceOverall = 
        (Aclause[i].significanceClass + 
         Aclause[i].significanceOppositeClass)/2.0;
    }  else {
      suberror("Unknown significance measure",
               "clauseSignificance","102");
    }
  } /* end for i */

  return;
}
/*eject*/
/***********************************************
 * getClauses(int tgt, int stage): for target tgt
 * and stage, get clauses of Amax/Bmax or Amin/Bmin 
 * and rules for literals
 *
 * input:
 *   numLiteralRule
 *   literalRule[]
 *     .literal
 *     .rule
 *
 * output:
 *   Aformula and Bformula
 *     .numClause (used for consistency check)
 *     .clause[][]
 *   numVariable
 *   variable[]
 *   Aclause[] and Bclause[]
 *     .numLiteral
 *     .literal[]
 *     .rule[]
 *
 ************************************************/
 
void getClauses(int tgt, int stage) {

  int flag, i, j, k, m, nA, nB;

  char name [MAX_ID];

  /* store Aformula and Bformula.numClause for consistency check */
  nA = Aformula.numClause;
  nB = Bformula.numClause;

  /* get from sep file of target tgt and stage:
   *     Aformula and Bformula
   *        .numClause
   *        .clause[][]
   *     numVariable
   *     variable[]
   */
  getFormulas(tgt,stage);

  /* Aformula and Bformula.numClause obtained in getFormulas() */
  /* must match their values prior to the getFormulas() call */
  if ((nA != Aformula.numClause) ||
      (nB != Bformula.numClause)) {
    suberror("Inconsistent number of Clauses in A or B formula",
             "getClauses","101");
  }

  /* transfer clause data to Aclause[] and Bclause[] and
   * match up with rules of literals/rules list
   */
  for (i=1; i<=Bformula.numClause; i++) {
    Bclause[i].numLiteral = Bformula.clause[i][0];
    for (j=1; j<=Bformula.clause[i][0]; j++) {
      m = Bformula.clause[i][j];
      if (m > 0) {
        sprintf(name,"%s",variable[m]);
      } else {
        sprintf(name,"-%s",variable[-m]);
      }
      /* find name in literals/rules list */
      flag = 0;
      for (k=1; k<= numLiteralRule; k++) {
        if (strcmp(name,literalRule[k].literal) == 0) {
          flag = 1;
          strcpy(Bclause[i].literal[j],name);
          strcpy(Bclause[i].rule[j],literalRule[k].rule);
          break;
        }
      }
      if (flag == 0) {
        suberror(
         "Literal stored in name is not in literalRule[]",
         "getClauses","301");
      }
    }
  }
  
  for (i=1; i<=Aformula.numClause; i++) {
    Aclause[i].numLiteral = Aformula.clause[i][0];
    for (j=1; j<=Aformula.clause[i][0]; j++) {
      m = Aformula.clause[i][j];
      if (m > 0) {
        sprintf(name,"%s",variable[m]);
      } else {
        sprintf(name,"-%s",variable[-m]);
      }
      /* find name in literals/rules list */
      flag = 0;
      for (k=1; k<= numLiteralRule; k++) {
        if (strcmp(name,literalRule[k].literal) == 0) {
          flag = 1;
          strcpy(Aclause[i].literal[j],name);
          strcpy(Aclause[i].rule[j],literalRule[k].rule);
          break;
        }
      }
      if (flag == 0) {
        suberror(
          "Literal stored in name is not in literalRule[]",
          "getClauses","401");
      }
    }
  } 
  
  return;
} 
/*eject*/
/****************************************************
 * getLiteralsAndRules(int tgt, int stage): 
 * for target tgt and stage, get list of literals and
 * corresponding inequality rules used in the 4total formulas
 *
 * output:
 *   numLiteralRule
 *   literal[]
 *     .literal
 *     .rule
 ****************************************************/
void getLiteralsAndRules(int tgt, int stage) {

  int flag;

  char *buffer;
  char name[MAX_DIRECTORY+MAX_ID]; 
  char fileRec[MAXLEN];
  
  FILE *cutfil;

  sprintf(name,"%d.%d.%s.4total%s", 
          tgt, stage, gTarget[tgt],gFileExt.cut);
  cutfil = openFileSubccdetail(name,"r");
 
  /* read .cut file */
  flag = 0;
  while (fgets(fileRec,MAXLEN,cutfil) != 0) { /* while #1 */
    if (strncmp(fileRec,"LITERALS AND RULES",18) == 0) {
      flag = 1;
      break;
    }
  } /* end while #1 */

  if  (flag == 0) {
    suberror("Unexpected end of cut file in getLiteralsAndRules",
             "getLiteralsAndRules","101");
  }

  /* read literals and rules */
  numLiteralRule = 0;
  while (fgets(fileRec,MAXLEN,cutfil) != 0) { /* while #2 */

    buffer = strtok(fileRec," \t");

    if (strncmp(buffer,"ENDATA",6) == 0) {
      closeFile(cutfil);
      return;
    }

    numLiteralRule++;
    strcpy(literalRule[numLiteralRule].literal,buffer);

    buffer = strtok(NULL,"\n");
    if (strncmp(buffer,"DELETE",6) == 0) {
      numLiteralRule--;
      continue;
    } else {
      strcpy(literalRule[numLiteralRule].rule,buffer);
    }
    
  } /* end while #2 */

}
/*eject*/
/******************************************
 * getVotes(int tgt, int stage): for target tgt 
 * and stage, get for each clause of 4total formulas
 * Amax/Bmax or Amin/Bmin applied to rts, rtsA, rtsB:
 * - ARPprobability from vot file
 * - True count for class from votA and votB files
 * - True count for opposite class from votA and votB files
 * Also store:
 * - total count for class
 * - total count for opposite class
 *
 * output:
 *   Aclause[] and Bclause[]
 *     .numClass
 *     .numOppositeClass
 *     .numTrueClass
 *     .numTrueOppositeClass
 *     .ARPprobability
 *   Aformula and Bformula
 *     .numClass
 *     .numOppositeClass
 *     .numTrueClass
 *     .numTrueOppositeClass
 *     .numclause
 *
 ******************************************/ 
void getVotes(int tgt, int stage) {

  int i, k, n;
  float g;
  char fileRec[MAXLEN];
  char name[MAX_ID];
  char AformulaLabel[MAX_ID];
  char BformulaLabel[MAX_ID];

  FILE *votfil;
  FILE *votfilA; 
  FILE *votfilB;

  /* initialize AformulaLabel and BformulaLabel */
  if (gParams.defSizeSubgroup == DEFMAX) {
    strcpy(AformulaLabel,"Formula 4");
    strcpy(BformulaLabel,"Formula 2");
  } else if (gParams.defSizeSubgroup == DEFMIN) {
    strcpy(AformulaLabel,"Formula 3");
    strcpy(BformulaLabel,"Formula 1");
  } else {
    suberror("Error of defSizeSubgroup value",
             "getVotes","51");
  }

  /* open vot, votA, votB files */
  sprintf(name,"%d.%d.%s.4total%s",
          tgt, stage, gTarget[tgt], gFileExt.vot);
  votfil = openFileSubccdetail(name,"r");
  sprintf(name,"%d.%d.%s.4total%s",
          tgt, stage, gTarget[tgt], gFileExt.votA);
  votfilA = openFileSubccdetail(name,"r");

  sprintf(name,"%d.%d.%s.4total%s",
          tgt, stage, gTarget[tgt], gFileExt.votB);
  votfilB = openFileSubccdetail(name,"r");

  /* obtain vote information from three vote files */

  /* total number of records */
  while (fgets(fileRec,MAXLEN,votfil) != 0) {
    if (strncmp(fileRec,"Number of records =",19) == 0) {
      sscanf(fileRec,"Number of records = %d",&numRec.total);
      break;
    }
  }

  /* number of A records */
  while (fgets(fileRec,MAXLEN,votfilA) != 0) {
    if (strncmp(fileRec,"Number of records =",19) == 0) {
      sscanf(fileRec,"Number of records = %d",&numRec.A);
      break;
    }
  }

  /* number of B records */
  while (fgets(fileRec,MAXLEN,votfilB) != 0) {
    if (strncmp(fileRec,"Number of records =",19) == 0) {
      sscanf(fileRec,"Number of records = %d",&numRec.B);
      break;
    }
  }

  /* store number of records in Aformula and Bformula */
  /* inititalize numTrue counts for both formulas     */
  Aformula.numClass = numRec.A;
  Aformula.numOppositeClass = numRec.B;
  Aformula.numTrueClass = 0;
  Aformula.numTrueOppositeClass = 0;
  Bformula.numClass = numRec.B;
  Bformula.numOppositeClass = numRec.A;
  Bformula.numTrueClass = 0;
  Bformula.numTrueOppositeClass = 0;

  /* ARP Probability, numClass, numOppositeClass */
  /* for Bmax/Bmin clauses */
  while (fgets(fileRec,MAXLEN,votfil) != 0) {
    if (strncmp(fileRec,BformulaLabel,9) == 0) {
      sscanf(fileRec,"Formula %d B %d",&k,&Bformula.numClause);
      if (Bformula.numClause >= MAX_CLAUSE) {
        suberror("MAX_CLAUSE is too small",
                 "getVotes","91");
      }
      /* skip the "Clause" record */
      fgets(fileRec,MAXLEN,votfil);
      if (strncmp(fileRec,"Clause",6) != 0) {
        suberror("'Clause' record missing in vot file",
                 "getVotes","103");
      }
      /* get ARP probability and store record counts */
      for (i=1; i<=Bformula.numClause; i++) {
        if (fgets(fileRec,MAXLEN,votfil) == 0) {
          suberror("clause record missing in vot file",
                 "getVotes","104");
        }
        sscanf(fileRec,"%d%f",
	       &n,&Bclause[i].ARPprobability); /* n is dummy */
        Bclause[i].numClass = numRec.B;
        Bclause[i].numOppositeClass = numRec.A;
      }
      break;
    }
  }

  /* ARP Probability, numClass, numOppositeClass */
  /*  for Amax/Amin clauses */
  while (fgets(fileRec,MAXLEN,votfil) != 0) {
    if (strncmp(fileRec,AformulaLabel,9) == 0) {
      sscanf(fileRec,"Formula %d A %d",&k,&Aformula.numClause);
      if (Aformula.numClause >= MAX_CLAUSE) {
        suberror("MAX_CLAUSE is too small",
                 "getVotes","95");
      }
      /* skip the "Clause" record */
      fgets(fileRec,MAXLEN,votfil);
      if (strncmp(fileRec,"Clause",6) != 0) {
        suberror("'Clause' record missing in vot file",
                 "getVotes","105");
      }
      /* get ARP probability and store record counts */
      for (i=1; i<=Aformula.numClause; i++) {
        if (fgets(fileRec,MAXLEN,votfil) == 0) {
          suberror("clause record missing in vot file",
                 "getVotes","106");
        }
        sscanf(fileRec,"%d%f",
               &n,&Aclause[i].ARPprobability); /* n is dummy */
        Aclause[i].numClass = numRec.A;
        Aclause[i].numOppositeClass = numRec.B;
      }
      break;
    }
  }

  /* True counts on class A for Amax/Bmax or Amin/Bmin clauses */

  /* updating of Aformula.numTruexxx and Bformula.numTruexxx
   * below relies on the fact that each True case is counted
   * only once, that is, for the clause with smallest index 
   * having value True
   */  

  /* True count for Bmax or Bmin clauses on class A */
  while (fgets(fileRec,MAXLEN,votfilA) != 0) {
    if (strncmp(fileRec,BformulaLabel,9) == 0) {
      sscanf(fileRec,"Formula %d B %d",&k,&n);
      if (n != Bformula.numClause) {
        suberror("Inconsistency of vot and votA files",
                 "getVotes","201");
      }
      /* skip the "Clause" record */
      fgets(fileRec,MAXLEN,votfilA);
      if (strncmp(fileRec,"Clause",6) != 0) {
        suberror("'Clause' record missing in votA file",
                 "getVotes","203");
      }
      /* get true count */
      for (i=1; i<=Bformula.numClause; i++) {
        if (fgets(fileRec,MAXLEN,votfilA) == 0) {
          suberror("clause record missing in votA file",
                 "getVotes","204");
        }
        sscanf(fileRec,"%d%f%d",
	       &n,&g,&Bclause[i].numTrueOppositeClass); 
               /* n, g are dummy variables */
        Bformula.numTrueOppositeClass +=
          Bclause[i].numTrueOppositeClass;
      }
      break;
    }
  }

  /* True count for Amax or Amin clauses on class A */
  while (fgets(fileRec,MAXLEN,votfilA) != 0) {
    if (strncmp(fileRec,AformulaLabel,9) == 0) {
      sscanf(fileRec,"Formula %d A %d",&k,&n);
      if (n != Aformula.numClause) { 
        suberror("Inconsistency of vot and votA files",
                 "getVotes","202");
      }
      /* skip the "Clause" record */
      fgets(fileRec,MAXLEN,votfilA);
      if (strncmp(fileRec,"Clause",6) != 0) {
        suberror("Clause' record missing in votA file",
                 "getVotes","205");
      }
      /* get true count */
      for (i=1; i<=Aformula.numClause; i++) {
        if (fgets(fileRec,MAXLEN,votfilA) == 0) {
          suberror("clause record missing in votA file",
                 "getVotes","206");
        }
        sscanf(fileRec,"%d%f%d",
	       &n,&g,&Aclause[i].numTrueClass); 
               /* n, g are dummy variables */
        Aformula.numTrueClass +=
          Aclause[i].numTrueClass;
      }
      break;
    }
  }

  /* True counts on class B for Amax/Bmax or Amin/Bmin clauses */

  /* True count for Bmax or Bmin clauses on class B */
  while (fgets(fileRec,MAXLEN,votfilB) != 0) {
    if (strncmp(fileRec,BformulaLabel,9) == 0) {
      sscanf(fileRec,"Formula %d B %d",&k,&n);
      if (n != Bformula.numClause) {
        suberror("Inconsistency of vot and votB files",
                 "getVotes","301");
      }
      /* skip the "Clause" record */
      fgets(fileRec,MAXLEN,votfilB);
      if (strncmp(fileRec,"Clause",6) != 0) {
        suberror("'Clause' record missing in votB file",
                 "getVotes","303");
      }
      /* get true count */
      for (i=1; i<=Bformula.numClause; i++) {
        if (fgets(fileRec,MAXLEN,votfilB) == 0) {
          suberror("clause record missing in votB file",
                 "getVotes","304");
        }
        sscanf(fileRec,"%d%f%d",
	       &n,&g,&Bclause[i].numTrueClass); 
               /* n, g are dummy variables */
        Bformula.numTrueClass +=
          Bclause[i].numTrueClass;
      }
      break;
    }
  }

  /* True count for Amax or Amin clauses on class B */
  while (fgets(fileRec,MAXLEN,votfilB) != 0) {
    if (strncmp(fileRec,AformulaLabel,9) == 0) {
      sscanf(fileRec,"Formula %d A %d",&k,&n);
      if (n != Aformula.numClause) { 
        suberror("Inconsistency of vot and votB files",
                 "getVotes","302");
      }
      /* skip the "Clause" record */
      fgets(fileRec,MAXLEN,votfilB);
      if (strncmp(fileRec,"Clause",6) != 0) {
        suberror("'Clause' record missing in votB file",
                 "getVotes","305");
      }
      /* get true count */
      for (i=1; i<=Aformula.numClause; i++) {
        if (fgets(fileRec,MAXLEN,votfilB) == 0) {
          suberror("clause record missing in votB file",
                 "getVotes","306");
        }
        sscanf(fileRec,"%d%f%d",
	       &n,&g,&Aclause[i].numTrueOppositeClass); 
               /* n, g are dummy variables */
               /* n, g are dummy variables */
        Aformula.numTrueOppositeClass +=
          Aclause[i].numTrueOppositeClass;
      }
      break;
    }
  }

  closeFile(votfil);
  closeFile(votfilA);
  closeFile(votfilB);
 
  return;   
}
/*eject*/
/***********************************************************
 * outputRules(): for atsmstcase, output rules 
 * corresponding to Amax/Bmax or Amin/Bmin of 
 * 4total case to 4total sep file
 ***********************************************************/
void outputRules(int atsmstcase) {

  int i, j;
  int clauseDim, vcDim;
  float rSens, rSpec;

  char *buffer;
  char name[MAXLEN]={'\0'};
  char formulaType[MAX_ID];
  char fullRule[MAXLEN];
  char percent[]="%";
  FILE *sepfil;

  /* initialize formulaType */
  if (gParams.defSizeSubgroup == DEFMAX) {
    strcpy(formulaType,"max");
  } else if (gParams.defSizeSubgroup == DEFMIN) {
    strcpy(formulaType,"min");
  } else {
    suberror("Error of defSizeSubgroup value",
             "outputRules","51");
  }

  if (Bclause[1].stage >= 1) {
    /* get list[] data for current tgt, stage, target case */
    getListRules(Bclause[1].tgt,Bclause[1].stage,Bclause[1].target);
  }

  sprintf(name,"%d.%d.%s.4total%s",
          Bclause[1].tgt,
          Bclause[1].stage, 
          Bclause[1].target, 
          gFileExt.sep);

  sepfil = openFileSubccdetail(name,"a");

  if (atsmstcase == MASTER) {
    fprintf(sepfil,"\n\nMASTER ");
  } else {
    fprintf(sepfil,"\n\nALTERNATE ");
  }
  fprintf(sepfil,"RULE SETS FOR TARGET %d STAGE %d %s\n\n",
          Bclause[1].tgt,
          Bclause[1].stage, 
          Bclause[1].target);

  /* rules produced by the Bmax or Bmin clauses */
  fprintf(sepfil,"B%s rules explaining '%s' versus '%s':\n",
          formulaType,
          Bclause[1].tgtTypeClass, 
          Bclause[1].tgtTypeOppositeClass);

  fprintf(sepfil,
          "  '%s' definition:\t%s\n",
          Bclause[1].tgtTypeClass, 
          Bclause[1].tgtRuleClass);

  fprintf(sepfil,
          "  '%s' definition:\t%s\n\n",
          Bclause[1].tgtTypeOppositeClass, 
          Bclause[1].tgtRuleOppositeClass);

  fprintf(sepfil,
          "  %d rule(s) produced by %d B%s clause(s)\n",
          Bformula.numClause, 
          Bformula.numClause,
          formulaType);

  fprintf(sepfil,
          "  if at least one of the rules applies, declare '%s'\n",
          Bclause[1].tgtTypeClass);
  fprintf(sepfil,"  otherwise declare '%s'\n\n",
          Bclause[1].tgtTypeOppositeClass);

  vcDim = 0; /* estimate of VC dimension of Bmax or Bmin formula */

  for (i=1; i<=Bformula.numClause; i++) {
    fprintf(sepfil,"  rule %d has %d term(s):\n",
            i, Bclause[i].numLiteral);
    for (j=1; j<=Bclause[i].numLiteral; j++) {
      strcpy(name,Bclause[i].rule[j]);
      buffer = strtok(name,"( \t");
      if (strncmp(buffer,"EXPANSION_VARIABLE",
          strlen("EXPANSION_VARIABLE")) != 0) {
        fprintf(sepfil,"\t\t%s",Bclause[i].rule[j]);
        vcDim++;
      } else {
        /* make full rule */
        if (Bclause[i].stage == 0) {
          suberror("Unexpected stage = 0 case",
                   "outputRules","101");
        }        
        makeFullRule(buffer,fullRule,&clauseDim);      
        fprintf(sepfil,"%s",fullRule);
        vcDim += clauseDim;      
      } 
      if (j < Bclause[i].numLiteral) {
        fprintf(sepfil," &\n");
      } else {
        fprintf(sepfil,"\n\n");
      }
    } /* end for j */

  } /* end for i */

/* coverage of rule sets corresponding to Bmax or Bmin clauses */
  fprintf(sepfil,
          "  Coverage for '%s' target values (= sensitivity):\n", 
          Bclause[1].tgtTypeClass);

  rSens = 100.0*(float) Bformula.numTrueClass/
            (float) Bformula.numClass;

  fprintf(sepfil,
          "    %d out of %d '%s' records correctly identified\n",
          Bformula.numTrueClass, 
          Bformula.numClass,
          Bclause[1].tgtTypeClass);
  fprintf(sepfil,"      (= %.1f%s)\n\n",
          rSens,percent);

  fprintf(sepfil,
          "  Coverage for '%s' target values (= specificity):\n", 
          Bclause[1].tgtTypeOppositeClass);

  rSpec = 100.0*(1.0-(float) Bformula.numTrueOppositeClass/
	     (float) Bformula.numOppositeClass);

  fprintf(sepfil,
	  "    %d out of %d '%s' records correctly identified\n",
          Bformula.numOppositeClass -
            Bformula.numTrueOppositeClass, 
          Bformula.numOppositeClass,
          Bclause[1].tgtTypeOppositeClass);
  fprintf(sepfil,"      (= %.1f%s)\n\n",
          rSpec,percent);

  fprintf(sepfil,"  Total for B%s  = %.1f%s\n",
          formulaType,rSens+rSpec,percent);
  fprintf(sepfil,"  Unweighted average for B%s  = %.1f%s\n",
          formulaType,(rSens+rSpec)/2.0,percent);
  fprintf(sepfil,"  VC dim estimate = %d\n\n",vcDim);

  fprintf(sepfil,"\n");

  /* rules produced by the Amax or Amin clauses */
  fprintf(sepfil,"A%s rules explaining '%s' versus '%s':\n",
          formulaType,
          Aclause[1].tgtTypeClass, 
          Aclause[1].tgtTypeOppositeClass);

  fprintf(sepfil,
          "  '%s' definition:\t%s\n",
          Aclause[1].tgtTypeClass, 
          Aclause[1].tgtRuleClass);

  fprintf(sepfil,
          "  '%s' definition:\t%s\n\n",
          Aclause[1].tgtTypeOppositeClass, 
          Aclause[1].tgtRuleOppositeClass);

  fprintf(sepfil,
          "  %d rule(s) produced by %d A%s clause(s)\n",
          Aformula.numClause, 
	  Aformula.numClause,
          formulaType);

  fprintf(sepfil,
          "  if at least one of the rules applies, declare '%s'\n",
          Aclause[1].tgtTypeClass);
  fprintf(sepfil,"  otherwise declare '%s'\n\n",
          Aclause[1].tgtTypeOppositeClass);

  vcDim = 0; /* estimate of VC dimension of Amax or Amin formula */

  for (i=1; i<=Aformula.numClause; i++) {
    fprintf(sepfil,"  rule %d has %d term(s):\n",
            i, Aclause[i].numLiteral);
    for (j=1; j<=Aclause[i].numLiteral; j++) {
      strcpy(name,Aclause[i].rule[j]);
      buffer = strtok(name,"( \t");
      if (strncmp(buffer,"EXPANSION_VARIABLE",
          strlen("EXPANSION_VARIABLE")) != 0) {
        fprintf(sepfil,"\t\t%s",Aclause[i].rule[j]);
        vcDim++;
      } else {
        /* make full rule */
        if (Aclause[i].stage == 0) {
          suberror("Unexpected stage = 0 case",
                   "outputRules","201");
        }
        makeFullRule(buffer,fullRule,&clauseDim);    
        fprintf(sepfil,"%s",fullRule);
        vcDim += clauseDim;      
      } 
      if (j < Aclause[i].numLiteral) {
        fprintf(sepfil," &\n");
      } else {
        fprintf(sepfil,"\n\n");
      }
    } /* end for j */

  } /* end for i */

  /* coverage of rule sets corresponding to Amax or Amin clauses */
  fprintf(sepfil,
          "  Coverage for '%s' target values (= sensitivity):\n", 
          Aclause[1].tgtTypeClass);

  rSens = 100.0*(float) Aformula.numTrueClass/
            (float) Aformula.numClass;

  fprintf(sepfil,
          "    %d out of %d '%s' records correctly identified\n",
          Aformula.numTrueClass, 
          Aformula.numClass,
          Aclause[1].tgtTypeClass);
  fprintf(sepfil,"      (= %.1f%s)\n\n",
          rSens,percent);

  fprintf(sepfil,
          "  Coverage for '%s' target values (= specificity):\n", 
          Aclause[1].tgtTypeOppositeClass);

  rSpec = 100.0*(1.0-(float) Aformula.numTrueOppositeClass/
	     (float) Aformula.numOppositeClass);

  fprintf(sepfil,
	  "    %d out of %d '%s' records correctly identified\n",
          Aformula.numOppositeClass -
            Aformula.numTrueOppositeClass, 
          Aformula.numOppositeClass,
          Aclause[1].tgtTypeOppositeClass);
  fprintf(sepfil,"      (= %.1f%s)\n\n",
          rSpec,percent);

  fprintf(sepfil,"  Total for A%s  = %.1f%s\n",
          formulaType,rSens+rSpec,percent);
  fprintf(sepfil,"  Unweighted average for A%s  = %.1f%s\n",
          formulaType,(rSens+rSpec)/2.0,percent);
  fprintf(sepfil,"  VC dim estimate = %d\n\n",vcDim);

  fprintf(sepfil,"ENDATA");
  closeFile(sepfil);
 
} /* end outputRules() */ 
/*eject*/
/***********************************************************
 * outputSubgroups():
 * Output Aclause[] and Bclause[] as subgroups
 *        Aformula and Bformula as overall explanation
 */
void outputSubgroups(FILE *subgroupResults) {

  int i, j;

  /* output Aclause[].<all data> */
  for (i=1; i<=Aformula.numClause; i++) {  /* for i #1 */
    fprintf(subgroupResults,"%d %d %d %d %f %f %f %f %d\n",
            Aclause[i].numClass,
            Aclause[i].numOppositeClass,
            Aclause[i].numTrueClass,
            Aclause[i].numTrueOppositeClass,
            Aclause[i].ARPprobability,
            Aclause[i].significanceClass,
            Aclause[i].significanceOppositeClass,
            Aclause[i].significanceOverall,
            Aclause[i].numLiteral);
    for (j=1; j<=Aclause[i].numLiteral; j++) { 
      fprintf(subgroupResults,"%s\n",Aclause[i].literal[j]);
      fprintf(subgroupResults,"%s\n",Aclause[i].rule[j]);
    }
    fprintf(subgroupResults,"%s %d %d %d %s %s\n",
            Aclause[i].target,
            Aclause[i].tgt,
            Aclause[i].stage,
            Aclause[i].tgtVersion,
            Aclause[i].tgtTypeClass,
            Aclause[i].tgtTypeOppositeClass);
    fprintf(subgroupResults,"%s\n",Aclause[i].tgtRuleClass);
    fprintf(subgroupResults,"%s\n",Aclause[i].tgtRuleOppositeClass);
  } /* end for i #1 */

  /* output Bclause[].<all data> */
  for (i=1; i<=Bformula.numClause; i++) {  /* for i #2 */
    fprintf(subgroupResults,"%d %d %d %d %f %f %f %f %d\n",
            Bclause[i].numClass,
            Bclause[i].numOppositeClass,
            Bclause[i].numTrueClass,
            Bclause[i].numTrueOppositeClass,
            Bclause[i].ARPprobability,
            Bclause[i].significanceClass,
            Bclause[i].significanceOppositeClass,
            Bclause[i].significanceOverall,
            Bclause[i].numLiteral);
    for (j=1; j<=Bclause[i].numLiteral; j++) { 
      fprintf(subgroupResults,"%s\n",Bclause[i].literal[j]);
      fprintf(subgroupResults,"%s\n",Bclause[i].rule[j]);
    }
    fprintf(subgroupResults,"%s %d %d %d %s %s\n",
            Bclause[i].target,
            Bclause[i].tgt,
            Bclause[i].stage,
            Bclause[i].tgtVersion,
            Bclause[i].tgtTypeClass,
            Bclause[i].tgtTypeOppositeClass);
    fprintf(subgroupResults,"%s\n",Bclause[i].tgtRuleClass);
    fprintf(subgroupResults,"%s\n",Bclause[i].tgtRuleOppositeClass);
  } /* end for i #2 */

  return;
}
/*eject*/
/***********************************************************
 * significance(float prob, int numRecords, int count):
 * For a binomial random variable X defined
 * by parameters prob and numRecords, computes P[X <= count] 
 * approximately with normal distribution
 ***********************************************************/
float significance(float prob, int numRecords, int count) {

  double imp, mu, p, sigma, sigma2, zvalue;
  int zi;

  p = (double) prob;
      
  if(p > 0.99)
    {
      //Lower to avoid division by very small sigma value below
      p=.99;
    }

  if(p < 0.01)
    {
      //Increase to avoid division by very small sigma value below
      p=.01;
    }

  mu = (double)numRecords * p;
  sigma2 = (double)numRecords * p * (1-p);
  
  sigma = sqrt(sigma2);
  zvalue = 
    ((double)count - mu)/sigma;
  if (zvalue > 4.0) 
    {
      zvalue = 4.0;
    } 
  else if (zvalue < -4.0) 
    {
      zvalue = -4.0;
    }
  /*
   *  compute normal distr. prob. corresponding to zvalue,
   *  which estimates the probability that the clause is
   *  important
   */
  if (zvalue >= 0) 
    {
      zi = 10.0*(zvalue+0.05);
      imp = (double)normDistr[zi];
    } 
  else 
    {
      zi = 10.0*(-zvalue+0.05);
      imp = (double)(1.0 - normDistr[zi]);
    }
  
  return (float) imp;

}
/*eject*/
/**********************************************************
 * valuesNormDistr(): computes values of the 
 * normal distribution with mean = 0 and sigma = 1
 * for positive values
 * the values are stored as normDist[zi], which is the
 * distribution value for the z value = (float)zi /10.0,
 * for 0 <= zi <= 41 
 */
void valuesNormDistr(){
  int i;
  float y,ym1,sum;

  for (i=1;i<=41;i++) {
    y = (float)i / 10.0;
    ym1 = ((float)i - 1.0)/ 10.0;
    normDistr[i] = 0.1 * (1.0/sqrt(2.0*3.14159)) *
      (exp(-.5*y*y)+exp(-.5*ym1*ym1))/2.0;
  }

/* 
 *  Add up area values and normalize
 */
  sum = 0.0;
  for (i=1;i<=41;i++) {
    sum += normDistr[i];
  }

/* 
 *  normalize to total of 0.5 
 */
  for (i=1;i<=41;i++) {
    normDistr[i] *= 0.5/sum;
  }
/* 
 *  compute distribution values 
 */
  normDistr[0] = 0.5;
  for (i=1;i<=41;i++) {
    normDistr[i] += normDistr[i-1];
  } 

}
/* last record of evaluateSubgroups.c*******/
