/* first record of subcc.c *****/
/*
 *   Leibniz System: Subcc System
 *   Copyright 2008 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * ===================================================
 * Subcc System - Callable Subgroup Version subcc
 * ===================================================
 *
 *  caution: 
 *   - parameters must have been obtained 
 *     (see readParamsFile() for required information)
 *   - errfil must have been opened (see subccmain() program)
 *   - errfil must be closed after execution of subcc
 *  caution: these conditions are not checked by the program 
 * -----------------------------------------------------------
 *  Leibniz programs used:
 *  Cutcc: cutcc
 *  Lsqcc: lsqcc
 *  Prpcc: master2masterABTarget
 *         masterAB2trainABtestAB
 *         fileAB2test
 * -----------------------------------------------------------
 */
#include "subcc.h"
/***********************************************************/         
int subcc() {

  double keepsig;

  char name[MAXLEN];

  keepsig = 0.0; /* to suppress compiler warning */

  /* initialize errorflag */
  errorflag = 0;

  /* initialize gNumOpenFiles */
  gNumOpenFiles = 0;

  /* test size of parameters */
  if (MAXLEN <= MAX_DIRECTORY + 2*MAX_ID) {
    /* error, MAXLEN must be > MAX_DIRECTORY + 2*MAX_ID */
    /* must change values in subcc.h */
    suberror("MAXLEN must be > MAX_DIRECTORY + 2*MAX_ID",
             "subcc", "103");
  }

  /* construct Subccdetail directory */
  showTargetSteps("Construct Subccdetail directory\n\n");
  constructSubccdetail();

  /* if 'new tgt' option, create target file */
  if ((gSelectTargetFile == NEWTGT) ||
      (gSelectTargetFile == TGTONLY)){
    showTargetSteps("Create target file\n\n");
    /* read .mst file */
    /* output .tgt file */
    /* close .mst, .tgt files */
    createTargets();
    sprintf(name,"Output in file %s%s%s\n\n",
	    gParams.directory, gParams.prefix, gFileExt.tgt);
    showTargetSteps(name);
  }

  /* if 'tgt only' option, stop */
  if (gSelectTargetFile == TGTONLY) {
    return errorflag;
  }

  /* find subgroups for the targets of .tgt file */
  showTargetSteps("Find subgroups for targets\n");
  findMstSubgroups();

  /* evaluate 4total votes for targets of targets.reducedList.mst */
  showTargetSteps("\nEvaluate subgroups\n");
  evaluateSubgroups(MASTER);

  /* if there is .ats file, temporarily define */
  /* significance threshold to be 0.0 */
  /* and thus accept all subgroups */
  if (gSelectTestFile == ALTERNATE) {
    keepsig = gParams.subgroupThreshold;
    gParams.subgroupThreshold = 0.0;
  } 

  /* select subgroups for .mst.sub file */
  showTargetSteps("Select subgroups\n");
  selectSubgroups(MASTER);

  /* if gSelectTestFile == ALTERNATE, use formulas derived */
  /* from .mst file to find subgroups evaluated via .ats file */
  if (gSelectTestFile == ALTERNATE) { 

    /* restore significance threshold */
    gParams.subgroupThreshold = keepsig;

    /* find subgroups for the targets of the */ 
    /* targets.reducedList.mst file, using the .ats data */
    showTargetSteps("\n\nFind subgroups for targets for .ats file\n");
    findAtsSubgroups();

    /* evaluate 4total votes for targets of targets.reducedList.ats */
    showTargetSteps("\nEvaluate subgroups for .ats file\n");
    evaluateSubgroups(ALTERNATE);

    /* select subgroups for .ats.sub file */
    showTargetSteps("Select subgroups\n");
    selectSubgroups(ALTERNATE);
  }

  if (gSelectTestFile == MASTER) {  
    sprintf(name,"Output in file %s%s%s%s\n\n",
            gParams.directory, gParams.prefix,
            gFileExt.mst,gFileExt.sub);
    showTargetSteps(name);
  } else {
    sprintf(name,"Output in files %s%s%s%s\n",
            gParams.directory, gParams.prefix,
            gFileExt.mst,gFileExt.sub);
    showTargetSteps(name);
    sprintf(name,"                %s%s%s%s\n\n",
            gParams.directory, gParams.prefix,
            gFileExt.ats,gFileExt.sub);
    showTargetSteps(name);
  }

  /* if 'keep subcc details directory' is not 
   * specified in lsqccparams.dat, then remove
   * subcc detail directory
   */
  if (gKeepSubccdetail == FALSE) {
    showTargetSteps("Remove Subccdetail directory\n\n");
    removeSubccdetail();
  }

  if (gNumOpenFiles != 0) {
    suberror("mismatch of opened/closed files","subcc","901");
  }
    
  return errorflag;
	
}

/***********************************************************/	

/* last record of subcc.c *******/


