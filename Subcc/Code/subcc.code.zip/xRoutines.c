/* first record of xRoutines.c *****/
#include "subcc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *
 * X routines for cutcc:
 *   Xcutcc40partial
 *   Xcutcc4total
 *   Xcutcc4totalA
 *   Xcutcc4totalB
 *
 * X routines for lsqcc and tstcc:
 *   Xlsqcc40partial
 *   Xlsqcc4total
 *   Xlsqcc4totalA
 *   Xlsqcc4totalB
 *   Xtstcc4total
 *   Xtstcc4totalA
 *   Xtstcc4totalB
 *
 * X routines for prpcc programs:
 *   Xconcatenate
 *   XfileAB2test40partial
 *   XfileAB2test4total
 *   XalternateTest2testABTarget
 *   Xmaster2masterABTarget
 *   XsortMaster
 *   XsplitMaster
 *     
 */
/**************************************************************/
/*eject*/
/************************************************/
/****************X Routines *********************/
/************************************************/

/************************************************/
/****************Cutcc Routines******************/
/************************************************/
int Xcutcc40partial(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sCutcc/Code/cutcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sCutcc\\Code\\cutcc ",
          gParams.leibnizpath);
#endif

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.40partial", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);  
  strcat(cmnd,addcmnd); /* lsqccparams file */
  if (guse40partialExtra == TRUE) {
    sprintf(addcmnd,".extra");  
    strcat(cmnd,addcmnd); /* extra extension */
  }

  return system(cmnd);

}
/*eject*/
/************************************************/
int Xcutcc4total(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sCutcc/Code/cutcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sCutcc\\Code\\cutcc ",
          gParams.leibnizpath);
#endif

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.4total", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);
  strcat(cmnd,addcmnd); /* lsqccparams file */

  return system(cmnd);

}
/*eject*/
/************************************************/
int Xcutcc4totalA(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sCutcc/Code/cutcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sCutcc\\Code\\cutcc ",
          gParams.leibnizpath);
#endif

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.4totalA", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);
  strcat(cmnd,addcmnd); /* lsqccparams file */

  return system(cmnd);

}
/*eject*/
/************************************************/
int Xcutcc4totalB(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sCutcc/Code/cutcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sCutcc\\Code\\cutcc ",
          gParams.leibnizpath);
#endif

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.4totalB", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);
  strcat(cmnd,addcmnd); /* lsqccparams file */

  return system(cmnd);

}
/*eject*/
/************************************************/
/****************Lsqcc Routines******************/
/************************************************/
int Xlsqcc40partial(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sLsqcc/Code/lsqcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sLsqcc\\Code\\lsqcc ",
          gParams.leibnizpath);
#endif

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.40partial", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);
  strcat(cmnd,addcmnd); /* lsqccparams file */
  if (guse40partialExtra == TRUE) {
    sprintf(addcmnd,".extra");  
    strcat(cmnd,addcmnd); /* extra extension */
  }

  return system(cmnd);

}
/*eject*/
/************************************************/
int Xlsqcc4total(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sLsqcc/Code/lsqcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sLsqcc\\Code\\lsqcc ",
          gParams.leibnizpath);
#endif

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.4total", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);
  strcat(cmnd,addcmnd); /* lsqccparams file */

  return system(cmnd);

}
/*eject*/
/************************************************/
int Xtstcc4total(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sLsqcc/Code/tstcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sLsqcc\\Code\\tstcc ",
          gParams.leibnizpath);
#endif

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.4total", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);
  strcat(cmnd,addcmnd); /* lsqccparams file */

  return system(cmnd);

}
/*eject*/
/************************************************/
int Xtstcc4totalA(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sLsqcc/Code/tstcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sLsqcc\\Code\\tstcc ",
          gParams.leibnizpath);
#endif

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.4totalA", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);
  strcat(cmnd,addcmnd); /* lsqccparams file */

  return system(cmnd);

}
/*eject*/
/************************************************/
int Xtstcc4totalB(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sLsqcc/Code/tstcc ",
          gParams.leibnizpath);
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sLsqcc\\Code\\tstcc ",
          gParams.leibnizpath);
#endif 

  sprintf(addcmnd,"%s%d.%d.%s.lsqccparams.4totalB", 
          gParams.subccdetaildir, tgt, stage, gTarget[tgt]);
  strcat(cmnd,addcmnd); /* lsqccparams file */

  return system(cmnd);

}
/*eject*/
/************************************************/
/****************Prpcc Routines******************/
/************************************************/
/************************************************/
/* fileAB2test for 40partial case */
int XfileAB2test40partial(int tgt, int stage) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sPrpcc/Code/fileAB2test ",
	  gParams.leibnizpath); /* fileAB2test */
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sPrpcc\\Code\\fileAB2test ",
	  gParams.leibnizpath); /* fileAB2test */
#endif

  sprintf(addcmnd,"%s%d.%d.%s.40partial%s ",
          gParams.subccdetaildir, tgt, stage,
          gTarget[tgt], gFileExt.rtr);
  strcat(cmnd,addcmnd); /* 40partial.rtr file */

  sprintf(addcmnd,"%soutput.rtsA ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* output.rtsA file, not used */

  sprintf(addcmnd,"%soutput.rtsB ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* output.rtsB file, not used */

  sprintf(addcmnd,"%s%d.%d.%s.40partial%s ",
          gParams.subccdetaildir, tgt, stage,
          gTarget[tgt], gFileExt.rtsEqrtr);
  strcat(cmnd,addcmnd); /* 40partial.rtsEqrtr file */

  if (system(cmnd) != 0) {
    suberror("Error","XfileAB2test40partial","101");
  }
  return 0;
  
}
/*eject*/
/************************************************/
/* fileAB2test for 4total case */
int     XfileAB2test4total(int tgt, int stage, char *name) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sPrpcc/Code/fileAB2test ",
	  gParams.leibnizpath); /* fileAB2test */
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sPrpcc\\Code\\fileAB2test ",
	  gParams.leibnizpath); /* fileAB2test */
#endif 

  strcat(cmnd,name); /* 40partial.rtr or 4total.testAB file */

  sprintf(addcmnd," %s%d.%d.%s.4total%s ",
          gParams.subccdetaildir, tgt, stage,
          gTarget[tgt], gFileExt.rtsA);
  strcat(cmnd,addcmnd); /* 4total.rtsA file */

  sprintf(addcmnd,"%s%d.%d.%s.4total%s ",
          gParams.subccdetaildir, tgt, stage,
          gTarget[tgt], gFileExt.rtsB);
  strcat(cmnd,addcmnd); /* 4total.rtsB file */

  sprintf(addcmnd,"%s%d.%d.%s.4total%s ",
          gParams.subccdetaildir, tgt, stage,
          gTarget[tgt], gFileExt.rts);
  strcat(cmnd,addcmnd); /* 4total.rts file */

  if (system(cmnd) != 0) {
    suberror("Error","XfileAB2test4total","101");
  }
  return 0;

}
/*eject*/
/************************************************/
/* alternate test to testAB for target tgt */
int XalternateTest2testABTarget(int tgt, int stage){

  int n;

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

  sprintf(cmnd,"%s ",gParams.master2masterABprogram); 
  /* master2masterABTarget */

  sprintf(addcmnd,"%s%d.%d.%s%s ",
          gParams.subccdetaildir, tgt, stage,
          gParams.prefix, gFileExt.ats);
  strcat(cmnd,addcmnd); /* .ats file */

  sprintf(addcmnd,"%sattributes.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* attributes.mspl file */

  sprintf(addcmnd,"%ssetA.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setA.mspl file */

  sprintf(addcmnd,"%ssetB.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setB.mspl file */

  sprintf(addcmnd,"%s ",
          gTarget[tgt]);
  strcat(cmnd,addcmnd); /* target name */

  sprintf(addcmnd,"%d ",
          gTgtVersion[tgt]);
  strcat(cmnd,addcmnd); /* numIntervals of target tgt */
/*eject*/

  for (n=1;n<=gTgtVersion[tgt];n++) {
    sprintf(addcmnd,"%f %f ",
            gUncertainTgtLow[tgt][n],
            gUncertainTgtHigh[tgt][n]);
    strcat(cmnd,addcmnd); /* low and high interval values */
  }

  if (system(cmnd) != 0) {
    suberror("Error","XalternateTest2testABTarget","101");
  }
  /* concatenate attributes.mspl, setA.mspl, setB.mspl
   * to 4total.testAB file
   */

#ifdef UNIX
  sprintf(cmnd,"cat ");

  sprintf(addcmnd,"%sattributes.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* attributes.mspl file */

  sprintf(addcmnd,"%ssetA.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setA.mspl file */

  sprintf(addcmnd,"%ssetB.mspl >",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setB.mspl file */

#endif

#ifdef WINDOWS
  sprintf(cmnd,"copy /b ");

  sprintf(addcmnd,"%sattributes.mspl+",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* attributes.mspl file */

  sprintf(addcmnd,"%ssetA.mspl+",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setA.mspl file */

  sprintf(addcmnd,"%ssetB.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setB.mspl file */

#endif

  sprintf(addcmnd,"%s%d.%d.%s.4total.testAB ",
          gParams.subccdetaildir, tgt, stage,
          gTarget[tgt]);
  strcat(cmnd,addcmnd); /* 4total.testAB file */

  if (system(cmnd) != 0) {
    suberror("Error","XalternateTest2testABTarget","201");
  }
  return 0; 

}
/*eject*/
/************************************************/
/* master to masterAB for target tgt */
/* masterAB is stored as 40partial.rtr */
int Xmaster2masterABTarget(int tgt, int stage){

  int n;

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

  sprintf(cmnd,"%s ",gParams.master2masterABprogram); 
  /* master2masterABTarget */

  sprintf(addcmnd,"%s%d.%d.%s%s ",
          gParams.subccdetaildir, tgt, stage,
          gParams.prefix, gFileExt.mst);
  strcat(cmnd,addcmnd); /* .mst file */

  sprintf(addcmnd,"%sattributes.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* attributes.mspl file */

  sprintf(addcmnd,"%ssetA.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setA.mspl file */

  sprintf(addcmnd,"%ssetB.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setB.mspl file */

  sprintf(addcmnd,"%s ",
          gTarget[tgt]);
  strcat(cmnd,addcmnd); /* target name */

  sprintf(addcmnd,"%d ",
          gTgtVersion[tgt]);
  strcat(cmnd,addcmnd); /* numIntervals of target tgt */

  for (n=1;n<=gTgtVersion[tgt];n++) {
    sprintf(addcmnd,"%f %f ",
            gUncertainTgtLow[tgt][n],
            gUncertainTgtHigh[tgt][n]);
    strcat(cmnd,addcmnd); /* low and high interval values */
  }

  if (system(cmnd) != 0) {
    suberror("Error","Xmaster2masterABTarget","101");
  }

  /* concatenate attributes.mspl, setA.mspl, setB.mspl
   * to masterAB file
   */

#ifdef UNIX
  sprintf(cmnd,"cat ");

  sprintf(addcmnd,"%sattributes.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* attributes.mspl file */

  sprintf(addcmnd,"%ssetA.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setA.mspl file */

  sprintf(addcmnd,"%ssetB.mspl >",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setB.mspl file */

#endif

#ifdef WINDOWS
  sprintf(cmnd,"copy /b ");

  sprintf(addcmnd,"%sattributes.mspl+",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* attributes.mspl file */

  sprintf(addcmnd,"%ssetA.mspl+",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setA.mspl file */

  sprintf(addcmnd,"%ssetB.mspl ",
          gParams.subccdetaildir);
  strcat(cmnd,addcmnd); /* setB.mspl file */

#endif

  sprintf(addcmnd,"%s%d.%d.%s.40partial%s ",
          gParams.subccdetaildir, tgt, stage,
          gTarget[tgt], gFileExt.rtr);
  strcat(cmnd,addcmnd); /* 40partial.rtr file */

  if (system(cmnd) != 0) {
    suberror("Error","Xmaster2masterABTarget","201");
  }
  return 0;

}
/*eject*/
/************************************************/
/* sort input master according to target attribute values */
int XsortMaster(int tgt){

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sPrpcc/Code/master2subdnfmaster ",
	  gParams.leibnizpath); /* master2subdnfmaster */
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sPrpcc\\Code\\master2subdnfmaster ",
	  gParams.leibnizpath); /* master2subdnfmaster */
#endif

  sprintf(addcmnd,"%s%s%s %s%s.sorted%s ",
                  gParams.directory,
                  gParams.prefix,
                  gFileExt.mst,
                  gParams.subccdetaildir,
                  gTarget[tgt],
                  gFileExt.mst); /* input and output files */
  strcat(cmnd,addcmnd);

  sprintf(addcmnd,"-sort %s low2high ",
                  gTarget[tgt]); /* sort option */
  strcat(cmnd,addcmnd);

  sprintf(addcmnd,
        "-nodisplay input parameters "); /* nodisplay option */       
  strcat(cmnd,addcmnd);

  if (system(cmnd) != 0) {
    suberror("Error","XsortMaster","101");
  }
  return 0;
}
/*eject*/
/************************************************/
/* split master sorted according to target attribute values */
/* into training and test file */
int XsplitMaster(int tgt){

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

#ifdef UNIX
  sprintf(cmnd,"%sPrpcc/Code/master2trainmsttestats ",
	  gParams.leibnizpath); /* master2trainmsttestats */
#endif

#ifdef WINDOWS
  sprintf(cmnd,"%sPrpcc\\Code\\master2subdnfmaster ",
	  gParams.leibnizpath); /* master2subdnfmaster */
#endif

  sprintf(addcmnd,"%s%s.sorted%s %s%s.split%s %s%s.split%s %d ",
                  gParams.subccdetaildir,
                  gTarget[tgt],
                  gFileExt.mst,
                  gParams.subccdetaildir,
                  gTarget[tgt],
                  gFileExt.mst,
                  gParams.subccdetaildir,
                  gTarget[tgt],
                  gFileExt.ats,
                  gParams.sortSplitRatio); /* input, output files */
                                           /* split ratio */
  strcat(cmnd,addcmnd);

  if (system(cmnd) != 0) {
    suberror("Error","XsplitMaster","101");
  }
  return 0;
}
/* last record of xRoutines.c *****/

