/* first record of findSubgroups.c *****/
#include "subcc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   void findAtsSubgroups()
 *   void findMstSubgroups()
 *     void createLsqccParamsFiles(int tgt, int stage)
 *     int  defineDataFiles(int tgt, int stage);
 *     void getListRules(int tgt, int stage, char *tgtname);
 *     void initializeDataFiles(int tgt,int stage);
 *     int  train40partial2train4total(int tgt, int stage)
 *
 * -----------------------------------------------------------
 *  Xroutines used: see xRoutines.c
 * -----------------------------------------------------------
 *  Leibniz program used:
 *  Cutcc: cutcc
 *  Lsqcc: lsqcc, tstcc
 *  Prpcc: master2masterABTarget
 *         masterAB2trainABtestAB
 *         fileAB2test
 * -----------------------------------------------------------
 *
 *  Subccdetail Directory File Names:
 *
 *  tgt =   index of target
 *  stage = stage number
 *  xxx =   target name
 *  ext =   extension
 *
 *  lsqccparams files:
 *
 *    tgt.stage.xxx.lsqccparams.40partial
 *    tgt.stage.xxx.lsqccparams.4total
 *    tgt.stage.xxx.lsqccparams.4totalA
 *    tgt.stage.xxx.lsqccparams.4totalB
 *
 * data files:
 *
 *   file name = tgt.stage.xxx.40partial.ext (40 formulas)
 *             = tgt.stage.xxx.4total.ext    (4 formulas)
 *               where .ext is the appropriate extension
 ***************************************************************
 */
/*eject*/
/***************************************************************
 * findAtsSubgroups(): finds subgroups for the targets of
 * the targets.reducedList.mst file, using the .ats data
 * input: alternate file .ats
 *        targets.reducedList.mst
 * CAUTION: the routine changes the test results
 *          of .vot, .votA, .votB files previously computed 
 *          via .mst file and now via .ats file
 ***************************************************************/
void findAtsSubgroups() {

  int i, tgt, stage;
  char fileRec[MAXLEN];
  char name[MAXLEN];

  FILE *targetsReducedListMst;
  FILE *targetsReducedListAts;

  /* open targets.reducedList.mst and .ats files */
  sprintf(name,"targets.reducedList%s",gFileExt.mst);
  targetsReducedListMst = openFileSubccdetail(name,"r");
  sprintf(name,"targets.reducedList%s",gFileExt.ats);
  targetsReducedListAts = openFileSubccdetail(name,"w");

  while (fgets(fileRec,MAXLEN,targetsReducedListMst)!=0){/*while #1*/
    /* read target index and stage */
    sscanf(fileRec,"%d%d",&tgt, &stage);

    sprintf(name,"\n%s target %d stage %d testing\n",
            gTarget[tgt],tgt,stage);
    showTargetSteps(name);

    /* derive 4total.testAB file from ats file */
    XalternateTest2testABTarget(tgt,stage);

    /* convert 4total.testAB file to */
    /* 4total test files rts, rtsA, rtsB */
    sprintf(name,"%s%d.%d.%s.4total.testAB",
            gParams.subccdetaildir, tgt, 
            stage, gTarget[tgt]);
    XfileAB2test4total(tgt,stage,name);

    /* cutcc 4total case */
    showTargetSteps("Discretization 4total case\n");
    if (Xcutcc4total(tgt,stage) != 0) {
      showTargetSteps("Early termination for this target/stage\n");
      continue;
    }

    /* tstcc 4total case with the formulas computed earlier */
    /* by findMstSubgroups() */
    showTargetSteps("Testing 4 formulas\n");
    if (Xtstcc4total(tgt,stage) != 0) {
      showTargetSteps("Early termination for this target/stage\n");
      continue;
    }

    /* cutcc 4total A case */
    showTargetSteps("Discretization 4total A case\n");
    if (Xcutcc4totalA(tgt,stage) != 0) {
      showTargetSteps("Early termination for this target/stage\n");
      continue;
    }

    /* tstcc 4total A case */
    showTargetSteps("Testing A case\n");
    if (Xtstcc4totalA(tgt,stage) != 0) {
      showTargetSteps("Early termination for this target/stage\n");
      continue;
    }

    /* cutcc 4total B case */
    showTargetSteps("Discretization 4total B case\n");
    if (Xcutcc4totalB(tgt,stage) != 0) {
      showTargetSteps("Early termination for this target/stage\n");
      continue;
    }

    /* tstcc 4total B case */
    showTargetSteps("Testing B case\n");
    if (Xtstcc4totalB(tgt,stage) != 0) {
      showTargetSteps("Early termination for this target/stage\n");
      continue; 
    }

    /* record case in targets.reducedList.ats file */
    showTargetSteps("Record case in targets.reducedList.ats file\n");
    fprintf(targetsReducedListAts, "%d %d %s %d", 
            tgt, stage, gTarget[tgt],gTgtVersion[tgt]);
    for (i=1; i<=gTgtVersion[tgt]; i++) {
      fprintf(targetsReducedListAts, " [ %f , %f ]", 
              gUncertainTgtLow[tgt][i],
              gUncertainTgtHigh[tgt][i] );
    }
    fprintf(targetsReducedListAts,"\n"); 
  } /* end while #1 */

  /* close targetsReducedList.mst and .ats files */
  closeFile(targetsReducedListMst);
  closeFile(targetsReducedListAts);

  return;

} /* end findAtsSubgroups */
/*eject*/
/***************************************************************
 * findMstSubgroups(): find subgroups for the targets of
 * the .tgt file using data of the .mst file
 * input:  master file .mst
 * output: target.ReducedList.mst file
 ***************************************************************/
void findMstSubgroups() {

  int i, tgt, stage;
  float saveAttImpThresh;
  char name[MAXLEN];

  FILE *targetsReducedListMst;

  /* save extra options */
  saveAttImpThresh = gParams.attributeImportanceThreshold;

  /* load target file */
  loadTargetFile();  

  /* open targets.reducedList.mst file */
  sprintf(name,"targets.reducedList%s",gFileExt.mst);
  targetsReducedListMst = openFileSubccdetail(name,"w");

  for (tgt=1; tgt<=gNumTargets; tgt++) {  /* for tgt */

    /* restore extra options for each target tgt */
    gParams.attributeImportanceThreshold = saveAttImpThresh;
    guse40partialExtra = FALSE;

    for (stage=0; stage<=gParams.maxExpansion; stage++){/*for stage*/

      sprintf(name,"\n%s target %d stage %d\n",
              gTarget[tgt],tgt,stage);
      showTargetSteps(name);

      /* define data files
       * if stage >= 1 and master file or alternate test file
       * cannot be defined, break off stage computation
       */
      if (defineDataFiles(tgt,stage) != 0) {
        if (stage == 0) {
          suberror("Unexpected failure of data files definition",
                   "findMstSubgroups","101");
        }
        showTargetSteps("Cannot define new attributes\n");
        showTargetSteps("Early termination for this target/stage\n");
        break;
      }

      /* create lsqccparams files for tgt and stage case */
      createLsqccParamsFiles(tgt,stage);

      /* determine masterAB from master */
      /* masterAB is stored as 40partial.rtr */
      /* uses CLASS options to deleted other target attributes */
      /* in same CLASS set */
      Xmaster2masterABTarget(tgt,stage);

      /* convert 40partial.rtr (= masterAB) to test file rtsEqrtr */
      XfileAB2test40partial(tgt,stage);

      /* convert 40partial.rtr (= masterAB) file to */
      /* 4total test files rts, rtsA, rtsB */
        sprintf(name,"%s%d.%d.%s.40partial%s",
                gParams.subccdetaildir, tgt, 
                stage, gTarget[tgt], gFileExt.rtr);
      XfileAB2test4total(tgt,stage,name);

    zzextra:;

      /* cutcc for 40partial case */
      showTargetSteps("Discretization 40partial case\n");
      if (Xcutcc40partial(tgt,stage) != 0) {
        showTargetSteps("Early termination for this target/stage\n");
        break;
      }

      /* lsqcc for 40partial case */
      showTargetSteps("Learning 40 formulas\n");
      if (Xlsqcc40partial(tgt,stage) != 0) {
        showTargetSteps("Early termination for this target/stage\n");
        break;
      }

      /* evaluate 40partial vote file, reduce
       * 40partial.rtr to 4total.rtr
       */

      showTargetSteps("Evaluate attributes\n");
      if (train40partial2train4total(tgt,stage) != 0) {
        /* there are no important attributes */
        if ((stage == 0) && (guse40partialExtra == FALSE)) {
          /* have stage == 0 and first pass with regular options */
          /* try extra options */
          showTargetSteps(
              "No attributes selected, repeat with extra options\n");
          /* extra options applicable to subcc
           * MUST be specified here AND in
           * createLsqccParamsFiles(int tgt, int stage)
           */ 
          gParams.attributeImportanceThreshold = 0.0;
          /* end options */
          guse40partialExtra = TRUE;
          /* repeat 40 partial with extra options */
          goto zzextra;
        } else {
          showTargetSteps(
              "Early termination for this target/stage\n");
          break;
        }
      }

      /* cutcc 4total case */
      showTargetSteps("Discretization 4total case\n");
      if (Xcutcc4total(tgt,stage) != 0) {
        showTargetSteps("Early termination for this target/stage\n");
        break;
      }

      /* lsqcc 4total case */
      showTargetSteps("Learning 4 formulas\n");
      if (Xlsqcc4total(tgt,stage) != 0) {
        showTargetSteps("Early termination for this target/stage\n");
        break;
      }

      /* cutcc 4total A case */
      showTargetSteps("Discretization 4total A case\n");
      if (Xcutcc4totalA(tgt,stage) != 0) {
        showTargetSteps("Early termination for this target/stage\n");
        break;
      }

      /* tstcc 4total A case */
      showTargetSteps("Testing A case\n");
      if (Xtstcc4totalA(tgt,stage) != 0) {
        showTargetSteps("Early termination for this target/stage\n");
        break;
      }

      /* cutcc 4total B case */
      showTargetSteps("Discretization 4total B case\n");
      if (Xcutcc4totalB(tgt,stage) != 0) {
        showTargetSteps("Early termination for this target/stage\n");
        break;
      }

      /* tstcc 4total B case */
      showTargetSteps("Testing B case\n");
      if (Xtstcc4totalB(tgt,stage) != 0) {
        showTargetSteps("Early termination for this target/stage\n");
        break; 
      }

      /* record case in targets.reducedList.mst file */
      showTargetSteps("Record case in targets.reducedList.mst file\n");
      fprintf(targetsReducedListMst, "%d %d %s %d", 
              tgt, stage, gTarget[tgt],gTgtVersion[tgt]);
      for (i=1; i<=gTgtVersion[tgt]; i++) {
        fprintf(targetsReducedListMst, " [ %f , %f ]", 
                gUncertainTgtLow[tgt][i],
                gUncertainTgtHigh[tgt][i] );
      }
      fprintf(targetsReducedListMst,"\n"); 
    } /* end for stage */
  } /* end for tgt */

  /* restore original options */
  gParams.attributeImportanceThreshold = saveAttImpThresh;

  /* close targetsReducedList file */
  closeFile(targetsReducedListMst);

  return;

} /* end findMstSubgroups */
/*eject*/
/***************************************************************
 * createLsqccParamsFiles(int tgt, int stage): 
 * create all lsqccparams files for the specified 
 * target tgt and stage
 ***************************************************************/
void createLsqccParamsFiles(int tgt, int stage) {
  char fileRec[MAXLEN] = {'\0'};
  char name[MAXLEN] = {'\0'};

  FILE *subccParams;
  FILE *out40partial;
  FILE *out40partialextra;
  FILE *out4total;
  FILE *out4totalA;
  FILE *out4totalB;

  /* open lsqccparams file and the four out files */
  subccParams = openFile(lsqccparamsname,"r");
  sprintf(name,"%d.%d.%s.lsqccparams.40partial", 
          tgt,stage,gTarget[tgt]);
  out40partial = openFileSubccdetail(name,"w");
  sprintf(name,"%d.%d.%s.lsqccparams.40partial.extra", 
          tgt,stage,gTarget[tgt]);
  out40partialextra = openFileSubccdetail(name,"w");
  sprintf(name,"%d.%d.%s.lsqccparams.4total",
          tgt,stage,gTarget[tgt]);
  out4total = openFileSubccdetail(name,"w");
  sprintf(name,"%d.%d.%s.lsqccparams.4totalA",
          tgt,stage,gTarget[tgt]);
  out4totalA = openFileSubccdetail(name,"w");
  sprintf(name,"%d.%d.%s.lsqccparams.4totalB",
          tgt,stage,gTarget[tgt]);
  out4totalB = openFileSubccdetail(name,"w");

  while (fgets(fileRec,MAXLEN,subccParams) != 0) {  /* while*/
    sscanf(fileRec,"%s",name);
    if ((stringCompare(name,"ENDATA",6) == 0) ||
        (stringCompare(name,"ENDDATA",7) == 0)) { /* if ENDATA */
      /* have copied all lines of lsqccparams file except
       * for ENDATA statement
       * complete files by adding statements
       */

      /*************begin allcc section*************/
      sprintf(name,"begin allcc");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /* file name without extension */
      sprintf(name,
	      "file name without extension = %d.%d.%s.40partial",
              tgt,stage,gTarget[tgt]);
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      sprintf(name,
	      "file name without extension = %d.%d.%s.4total",
              tgt,stage,gTarget[tgt]);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /* training/testing directory */
      sprintf(name,
	      "training/testing directory = %s",
              gParams.subccdetaildir);
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /*************begin lsqcc section*************/
      sprintf(name,"begin lsqcc");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /* do logic training */
      /* needed only for out40partial(extra) and out4total */
      sprintf(name,"do logic training");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);

      /* number/type of separations  */
      sprintf(name,
      "number/type of separations (4 total, 40 partial) = ");
      fprintf(out40partial,"%s",name);
      fprintf(out40partialextra,"%s",name);
      fprintf(out4total,"%s",name);
      fprintf(out4totalA,"%s",name);
      fprintf(out4totalB,"%s",name);
      fprintf(out40partial,"40 partial\n");
      fprintf(out40partialextra,"40 partial\n");
      fprintf(out4total,"4 total\n");
      fprintf(out4totalA,"4 total\n");
      fprintf(out4totalB,"4 total\n");

      /* delete option for nested A/B records */
      /* needed only for out40partial(extra) and out4total */
      sprintf(name,
      "nestedness delete option (not allowed, least cost, all) = ");
      strcat(name,"least cost");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);

      /* Fraction of A population/(A population + B population) */
      /* needed only for out40partial(extra) and out4total */
      /* begin deleted March, 2008 */
      /* sprintf(name,"fraction A population (0.xx) = 0.5");
         fprintf(out40partial,"%s\n",name);
         fprintf(out40partialextra,"%s\n",name);
         fprintf(out4total,"%s\n",name); */
      /* end delete */

      /* Costs of type A and type B errors */
      /* needed only for out40partial(extra) and out4total */
      /* begin deleted March, 2008 */
      /* sprintf(name,"cost type A error = 1.0");
         fprintf(out40partial,"%s\n",name);
         fprintf(out40partialextra,"%s\n",name);
         fprintf(out4total,"%s\n",name);
         sprintf(name,"cost type B error = 1.0");
         fprintf(out40partial,"%s\n",name);
         fprintf(out40partialextra,"%s\n",name);
         fprintf(out4total,"%s\n",name); */
      /* end delete */

      /* do logic testing */
      sprintf(name,"do logic testing");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /*************begin cutcc section*************/
      sprintf(name,"begin cutcc");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /* do training transformation */
      sprintf(name,
         "do training transformation (new,old,skip) = new");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      sprintf(name,
         "do training transformation (new,old,skip) = skip");
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /* max cuts = 2 if stage >= 1 */
      if (stage >= 1) {
        sprintf(name,"max cuts = 2");
        fprintf(out40partial,"%s\n",name);
        fprintf(out40partialextra,"%s\n",name);
        fprintf(out4total,"%s\n",name);
      }

      /* do testing transformation */
      sprintf(name,"do testing transformation");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /* degree of separation */
      /* needed only for out40partial(extra) and out4total */ 
      /* deleted April 17, 2008 to allow external control */
      /* sprintf(name,
           "degree of separation (effective, perfect) = effective");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name); */

      /*************begin allcc section*************/
      sprintf(name,"begin allcc");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /* assignment of .rtsEqrtr, .rtsA, .rtsB, .votA, .votB files */
      sprintf(name,
        "rational testing file extension (default: rts) = %s",
	      &gFileExt.rtsEqrtr[1]); /* address shift due to "." */
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      sprintf(name,
        "rational testing file extension (default: rts) = %s",
        &gFileExt.rtsA[1]); /* address shift due to "." */
      fprintf(out4totalA,"%s\n",name);
      sprintf(name,
        "vote file extension (default: vot) = %s",
        &gFileExt.votA[1]); /* address shift due to "." */
      fprintf(out4totalA,"%s\n",name);
      sprintf(name,
        "rational testing file extension (default: rts) = %s",
        &gFileExt.rtsB[1]); /* address shift due to "." */
      fprintf(out4totalB,"%s\n",name);
      sprintf(name,
        "vote file extension (default: vot) = %s",
        &gFileExt.votB[1]); /* address shift due to "." */
      fprintf(out4totalB,"%s\n",name);

      /* begin options for 40partialextra case */

      /* extra options not applying to subcc itself are
       * specified here and NOT in findMstSubgroups()
       */
      /*************begin cutcc section*************/
      sprintf(name,"begin cutcc");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      sprintf(name,"min cuts = 0");
      fprintf(out40partialextra,"%s\n",name);

      /* extra options applying to subcc itself MUST
       * be specified here AND in findMstSubgroups()
       */
      /*************begin subcc section*************/
      sprintf(name,"begin subcc");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name); 
      sprintf(name,"attribute importance threshold = 0.0");
      fprintf(out40partialextra,"%s\n",name);

      /* end options for 40partialextra case */

      /* ENDATA */
      sprintf(name,"ENDATA");
      fprintf(out40partial,"%s\n",name);
      fprintf(out40partialextra,"%s\n",name);
      fprintf(out4total,"%s\n",name);
      fprintf(out4totalA,"%s\n",name);
      fprintf(out4totalB,"%s\n",name);

      /* done with all output files */
      closeFile(subccParams);
      closeFile(out40partial);
      closeFile(out40partialextra);
      closeFile(out4total);
      closeFile(out4totalA);
      closeFile(out4totalB);
      return;
    }

    /* write fileRec into out files */
    fprintf(out40partial,"%s",fileRec);
    fprintf(out40partialextra,"%s",fileRec);
    fprintf(out4total,"%s",fileRec);
    fprintf(out4totalA,"%s",fileRec);
    fprintf(out4totalB,"%s",fileRec);
    
  } /* end while */

  suberror("Missing ENDATA record in lsqccparams.dat",
           "createLsqccParamsFiles", "101");

} /* end createLsqccParamsFiles */
/*eject*/
/************************************************
 * defineDataFiles(int tgt, int stage):
 * define the following data files for current stage:
 *    master file
 *    if alternate test option is specified:
 *      alternate test file
 * if stage >= 1: train40partial2train4total() has
 *   defined in stage-1 iteration
 *     sorted[].name
 *             .importance
 *     numSorted
 ************************************************/
int defineDataFiles(int tgt, int stage) {

  int flag, i, j, k, m, n, maxnew; 
  int pstage;

  double fac;
 
  char fileRec[MAXLEN];
  char name[MAXLEN];
  char *buffer;

  FILE *rulfil;
  FILE *oldmstfil;
  FILE *newmstfil;
  FILE *oldatsfil;
  FILE *newatsfil;

  if (stage == 0) {
    initializeDataFiles(tgt,stage);
    return 0;
  }

  pstage = stage - 1; /* previous stage */

  /* know stage >= 1 */

  /* optional call of getFormulas() currently commented out
   * the call gets the clauses of the Amin and Bmin
   * formulas, to be used for control during the construction 
   * of expansion variables below.
   *
   * get from sep file of target tgt and pstage:
   *   Aformula and Bformula
   *     .numClause
   *     .clause[][]
   *   numVariable
   *   variable[]
   */
  /*   getFormulas(tgt,pstage); */
  
  /* read cut file of 40partial pstage to get
   *   list[].name      attribute name
   *   list[].type      attribute type
   *   sorted[].type    attribute type
   *   sorted[].factor  expansion factor
   * define list2sorted[] and sorted2list
   */
  getCutListSorted(tgt,pstage);
 
  /* if stage == 1: define
   *   list[].numTerm
   *         .index[]
   *         .coefficient[]
   * if stage >= 2: read entire list[] data from file
   *  <tgt>.<pstage>.<target>.rul
   */
  if (stage == 1) {
    for (j=1; j<=numList; j++) {
      list[j].numTerm = 1;
      list[j].index[1] = j;
      list[j].coefficient[1] = 1.0;
      list[j].index[2] = j;
      list[j].coefficient[2] = 0.0;
    }
  } else {
    /* get list[] data for tgt, pstage, target name from rul file */
    getListRules(tgt,pstage,gTarget[tgt]);    
  }

/*eject*/ 
  /* define additional attributes */
  newNum = numList;
  /* maxnew = max number of new attributes */

  if (stage == 1) {
    maxnew = 2;
  } else {
    maxnew = 6;
  }
  for (i=2; i<=numSorted; i++) { /* for i */
    if (sorted[i].importance == 0.0) {
      continue;
    }
    for (k=1; k<i; k++) { /* for k */
      if (sorted[k].importance == 0.0) {
        continue;
      }
      if ((strcmp(sorted[i].type,sorted[k].type) == 0) &&
          (strcmp(sorted[i].type,"SET") != 0)) { /* if "SET" */
        if (newNum + 2 > MAX_ATTRIBUTE) {
          suberror("MAX_ATTRIBUTE too small",
                   "defineDataFiles","901");
        }
        /* check if the pair i, k has already produced
         * an expansion variable 
         */
        flag = 0;
        for (n=1; n<=numList; n++) {
          if (list[n].numTerm == 2) {
            if (((list[n].index[1] == sorted2list[i]) &&
                 (list[n].index[2] == sorted2list[k])) ||
                ((list[n].index[1] == sorted2list[k]) &&
                 (list[n].index[2] == sorted2list[i]))) {
              flag = 1;
              break;
            } 	    
          }          
        } /* for n */
        if (flag == 1) {
          continue;
        }
        /* create two new attributes */
        for (m=1; m<=2; m++) {
          if (m == 1) {
            fac = 1.0;
          } else {
            fac = -1.0;
          }
          sprintf(list[newNum+m].name,
                  "EXPANSION_VARIABLE_%d_%d_%d",
                  tgt,stage,newNum+m);
          /* expansion variables is of same type as */
          /* sorted[i] and sorted[k] */
          strcpy(list[newNum+m].type,sorted[i].type);
          list[newNum+m].numTerm = 2;
          list[newNum+m].index[1] = sorted2list[i];  
          list[newNum+m].index[2] = sorted2list[k];
          if (sorted[i].factor < sorted[k].factor) {
            list[newNum+m].coefficient[2] = 1.0;
            list[newNum+m].coefficient[1] = 
              fac * sorted[k].factor/sorted[i].factor;
          } else {
            list[newNum+m].coefficient[2] = 
              fac * sorted[i].factor/sorted[k].factor;
            list[newNum+m].coefficient[1] = 1.0;
          }
        } /* end for m */
        newNum += 2;
        if (newNum-numList >= maxnew) {
          goto zz01; /* allows up to maxnew expansion variables */
        }
      } /* end if "SET" */
    } /* end for k */
  } /* end for i */

  zz01:;  
  if (newNum == numList) { /* there are no new attributes */
    return 1;
  }
/*eject*/ 
  /* store list[] in rul file for stage */
  sprintf(name,"%d.%d.%s%s",
          tgt,stage,gTarget[tgt],gFileExt.rul);
  rulfil = openFileSubccdetail(name,"w");
  fprintf(rulfil,"RULES\n");

  for (j=1; j<=newNum; j++) {
    fprintf(rulfil,"%s\t%s\t%d\t%d\t%lf\t%d\t%lf\n",
            list[j].name,
            list[j].type,
            list[j].numTerm,
            list[j].index[1],
            list[j].coefficient[1],
            list[j].index[2],
            list[j].coefficient[2]);
  }
  fprintf(rulfil,"ENDATA");
  closeFile(rulfil);

/*eject*/ 
  /* define mst file for stage using
   *   mst file of pstage
   *   sorted[].importance values
   *   newly defined attributes of list[]
   * if alternate test option is specified:
   *   define ats file for stage analogously  
   */
  sprintf(name,"%d.%d.%s%s",
          tgt,pstage,gParams.prefix,gFileExt.mst);
  oldmstfil = openFileSubccdetail(name,"r");
  sprintf(name,"%d.%d.%s%s",
          tgt,stage,gParams.prefix,gFileExt.mst);
  newmstfil = openFileSubccdetail(name,"w");
  sprintf(name,"%d.%d.%s%s",
          tgt,stage,gParams.prefix,gFileExt.ats);
  newatsfil = openFileSubccdetail(name,"w");

  flag = 0;
  while (fgets(fileRec,MAXLEN,oldmstfil) != 0) {
    if (strncmp(fileRec,"ATTRIBUTES",10) == 0){
      flag = 1;
      break;
    }
  }  
  if (flag == 0) { 
    suberror("Missing ATTRIBUTES record in mst file",
             "defineDataFiles","1001");
  }
  fprintf(newmstfil,"ATTRIBUTES\n");
  if (gSelectTestFile == ALTERNATE) {
    fprintf(newatsfil,"ATTRIBUTES\n");
  }

/*eject*/
  /* process attributes of old mst file for new mst and ats files */ 
  for (j=1; j<=numList; j++) { /* for j #1 */
    if (fgets(fileRec,MAXLEN,oldmstfil) == 0) {
      suberror("Error reading attributes in mst file",
               "defineDataFiles","1101");
    }
    if (strncmp(fileRec,"DATA",4) == 0) {
      suberror("Unexpected DATA record in mst file",
               "defineDataFiles","1201");
    }

    if ((list2sorted[j] == 0) ||
        (sorted[list2sorted[j]].importance < 0.01)) {
      /* delete attribute due to low importance value */
      buffer = strtok(fileRec," \t\n");
      fprintf(newmstfil,
             "%s DELETE * deleted earlier or during expansion\n", 
             buffer);
      if (gSelectTestFile == ALTERNATE) {
        fprintf(newatsfil,
               "%s DELETE * deleted earlier or during expansion\n", 
               buffer);
      }
    } else {
      fprintf(newmstfil,"%s",fileRec);
      if (gSelectTestFile == ALTERNATE) {
        fprintf(newatsfil,"%s",fileRec);
      }
    }   
  } /* end for j #1 */
  
  /* add new attributes to new mst and ats files */
  for (j=numList+1; j<=newNum; j++) { /* for j #2 */
    fprintf(newmstfil,"%s ",list[j].name);
    if (gSelectTestFile == ALTERNATE) {
      fprintf(newatsfil,"%s ",list[j].name);
    }
    if (strcmp(list[j].type,"UNCERTAIN") == 0) {
      fprintf(newmstfil,"UNCERTAIN\n");
      if (gSelectTestFile == ALTERNATE) {
        fprintf(newatsfil,"UNCERTAIN\n");
      }
    } else {
      fprintf(newmstfil,"\n");
      if (gSelectTestFile == ALTERNATE) {
        fprintf(newatsfil,"\n");
      }
    }
  } /* end for j #2 */

/*eject*/
  /* next record of mst file must be DATA,
   * since blank and commented-out records
   * have been removed when input mst file was
   * copied into subcc detail directory
   */
  if ((fgets(fileRec,MAXLEN,oldmstfil) == 0) ||
      (strncmp(fileRec,"DATA",4) != 0)) {
    suberror("Missing DATA record in mst file",
             "defineDataFiles","1301");
  }
  fprintf(newmstfil,"DATA\n");
  if (gSelectTestFile == ALTERNATE) {
    fprintf(newatsfil,"DATA\n");      
  }  

  /* process mst data records */
  flag = 0;
  while(fgets(fileRec,MAXLEN,oldmstfil) != 0) { /* while #10 */
    if (strncmp(fileRec,"ENDATA",6) == 0){
      flag = 1;
      break;
    }
    expandRecord(newmstfil,fileRec);
  } /* while #10 */

  if (flag == 0) {
    suberror("Missing ENDATA record in mst file",
             "defineDataFiles","1501");
  }
  fprintf(newmstfil,"ENDATA\n");


  if (gSelectTestFile == ALTERNATE) {

    /* insert data of input ats file into new ats file */   
    sprintf(name,"%d.%d.%s%s",
                 tgt,pstage,gParams.prefix,gFileExt.ats);
    oldatsfil = openFileSubccdetail(name,"r");

    /* read input ats file up to DATA record */
    flag = 0;
    while(fgets(fileRec,MAXLEN,oldatsfil) != 0) { /* while #11 */
      if (strncmp(fileRec,"DATA",4) == 0){
        flag = 1;
        break;
      }
    } /* while #11 */
    if (flag == 0) {
      suberror("Missing DATA record in ats file",
               "defineDataFiles","1601");
    }

    /* process ats data records */
    flag = 0;
    while(fgets(fileRec,MAXLEN,oldatsfil) != 0) { /* while #12 */
      if (strncmp(fileRec,"ENDATA",6) == 0){
        flag = 1;
        break;
      }
      expandRecord(newatsfil,fileRec);
    } /* while #12 */
    if (flag == 0) {
      suberror("Missing ENDATA record in ats file",
               "defineDataFiles","1701");
    }
    fprintf(newatsfil,"ENDATA\n");

    closeFile(oldatsfil);
  }

  closeFile(oldmstfil);
  closeFile(newmstfil);
  closeFile(newatsfil);

  return 0;

} /* end defineDataFiles */
/*eject*/
/************************************************
 * expandRecord(FILE *out,char *filerec):
 * enlarge filerec data record by values of expansion
 * variables and write new record to out file
 ************************************************/
void expandRecord(FILE *out, char *fileRec) {

  int j, k, known[MAX_ATTRIBUTE];

  double a[MAX_ATTRIBUTE];

  char name[MAXLEN];
  char *buffer;


  /* in fileRec, replace '\n' by '\t' */
  /* write revised fileRec to out file */
  fileRec[strlen(fileRec)-1] = '\t';
  fprintf(out,"%s",fileRec);

  /* add new data to record */
  /* first get existing entries */
  for (j=1; j<=numList; j++) { /* for j */
    if (j == 1) {
      buffer = strtok(fileRec," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }
    if (buffer == NULL) {
      sprintf(name,
        "Unexpected short record in mst or ats file, contains\n\n %s\n\n",
        fileRec);
      suberror(name,"expandRecord","101");
    }
    if (buffer[0] == '?') {
      known[j] = 0;
    } else {
      known[j] = 1;
      a[j] = (double) atof(buffer);
    }
  } /* end for j */

  /* write new record entries to out file */
  for (k=numList+1; k<=newNum; k++) { /* for k */
    if (list[k].numTerm == 1) {
      suberror("Error in definition of new attribute",
               "expandRecord","201");
    }
    if ((known[list[k].index[1]] == 0) ||
        (known[list[k].index[2]] == 0)) {
      fprintf(out,"?\t");
    } else {
      a[k] = list[k].coefficient[1] * 
             a[list[k].index[1]] + 
             list[k].coefficient[2] * 
             a[list[k].index[2]];
      fprintf(out,"%lf\t",a[k]); 
    }
  } /* end for k */
  fprintf(out,"\n");

  return;
   
}
 
/*eject*/
/************************************************
 * initializeDataFiles(int tgt, int stage):
 * initializes the data files in subcc detail directory
 * input in user directory:
 *   master file mst
 *   if alternate test option is specified and sortSplitRatio = 0:
 *     alternate test file ats, has only test records and ENDATA
 *     plus any number of blank or comment lines
 * output in subcc detail directory, for specified
 * target and stage = 0:
 *   master file mst
 *   if alternate test option is specified:
 *     alternate test file ats, but with same format as master file 
 * program eliminates blank and commented-out lines
 * CAUTION: 1. Program is always called with stage = 0
 *          2. If sortSplitRatio > 0, then alternate test option
 *             has been specified regardless of specification in
 *             lsqccparams.dat
 *          3. alternate test file output has master file format,
 *             that is, with ATTRIBUTES section and DATA statement.
 ************************************************/
void initializeDataFiles(int tgt, int stage) {

  int flag;

  char fileRec[MAXLEN];
  char name[MAXLEN];

  FILE *mstfil;
  FILE *newmstfil;
  FILE *atsfil;
  FILE *newatsfil;

  if (gParams.sortSplitRatio == 0) {
    /* use input .mst file and, if applicable, .ats file */
    sprintf(name,"%s%s%s", 
            gParams.directory, 
            gParams.prefix, 
            gFileExt.mst);
    mstfil = openFile(name,"r");
  } else {
    /* sort input .mst according to target attribute values */
    /* split sorted .mst file into training .mst and testing */
    /* .ats files */
    /* sort and split only if target name has not yet occurred */
    /* case tgt = 1: createTargetData() has defined gTarget[0] */
    /* (= gTarget[tgt-1]) to be the empty string */
    if (strcmp(gTarget[tgt-1],gTarget[tgt]) != 0) {
      XsortMaster(tgt);
      XsplitMaster(tgt);
    }
    /* open sorted split files */
    sprintf(name,"%s.split%s", 
            gTarget[tgt], 
            gFileExt.mst);
    mstfil = openFileSubccdetail(name,"r"); 
  } /* end if gParams.sortSplitRatio == 0, else */

  /* open output files */
  sprintf(name,"%d.%d.%s%s",
         tgt,
         stage, 
         gParams.prefix, 
         gFileExt.mst);
  newmstfil = openFileSubccdetail(name,"w");
  sprintf(name,"%d.%d.%s%s",
          tgt,
          stage, 
          gParams.prefix, 
          gFileExt.ats);
  newatsfil = openFileSubccdetail(name,"w");  
/*eject*/
  flag = 0;

  while(fgets(fileRec,MAXLEN,mstfil) != 0) {
    /* skip blank and commented-out records */
    if ((fileRec[0] == '\n') || 
        (fileRec[0] == '*')) {
      continue;
    }
    /* copy record into output mst file
     * if alternate test file option selected, also
     * also copy into output ats file, up to
     * and including DATA record
     */
    fprintf(newmstfil,"%s",fileRec);
    if ((gSelectTestFile == ALTERNATE) &&
        (flag == 0)) {
      fprintf(newatsfil,"%s",fileRec);
      sscanf(fileRec,"%s",name);
      if (strncmp(name,"DATA",4) == 0) {
        flag = 1;
      }
    }
  }
/*eject*/
  if (gSelectTestFile == ALTERNATE) {
    /* caution: sortSplitRatio > 0 => gSelectTestFile == ALTERNATE */
    if (gParams.sortSplitRatio > 0) {  
      sprintf(name,"%s.split%s", 
              gTarget[tgt], 
              gFileExt.ats);
      atsfil = openFileSubccdetail(name,"r");
    } else {
      sprintf(name,"%s%s%s", 
              gParams.directory, 
              gParams.prefix, 
              gFileExt.ats);
      atsfil = openFile(name,"r");
    }  
    /* copy data from input ats file into output ats file */
    while(fgets(fileRec,MAXLEN,atsfil) != 0) {
      /* skip blank and commented-out records */
      if ((fileRec[0] == '\n') || 
          (fileRec[0] == '*')) {
        continue;
      }
      /* check for inappropriate records */
      if (strncmp(fileRec,"ATTRIBUTES",10) == 0) {
        suberror("'ATTRIBUTES' record not allowed in ats file",
	         "initializeDataFiles","201"); 
      }
      if (strncmp(fileRec,"DATA",4) == 0) {
        suberror("'DATA' record not allowed in ats file",
	         "initializeDataFiles","202"); 
      }  
      fprintf(newatsfil,"%s",fileRec);
    }
    closeFile(atsfil);
  }

  closeFile(mstfil);
  closeFile(newmstfil);
  closeFile(newatsfil);

  return;

} /* end initializeDataFiles */
/*eject*/
/************************************************
 * reduce train 40partial file to train 4total file
 * by deleting all unimportant attributes
 * the output includes for i = 1, 2, ..., numSorted:
 *   sorted[i].name
 *            .importance
 ************************************************/
int train40partial2train4total(int tgt, int stage) {

  char control[MAX_ID];
  char *buffer;
  char name[MAXLEN];
  char fileRec[MAXLEN];
  char fileRecSave[MAXLEN];
  char message[MAXLEN];
  int flag, i, j, m, natt;

  FILE *vote40partial;
  FILE *train40partial;
  FILE *train4total;

  /* open 40partial vote file */
  sprintf(name,"%d.%d.%s.40partial%s",
          tgt,stage,gTarget[tgt],gFileExt.vot);
  vote40partial = openFileSubccdetail(name,"r");

  /* open train 40partial rtr file */
  sprintf(name,"%d.%d.%s.40partial%s",
          tgt,stage,gTarget[tgt],gFileExt.rtr);
  train40partial = openFileSubccdetail(name,"r");

  /* open train 4total rtr file */
  sprintf(name,"%d.%d.%s.4total%s",
          tgt,stage,gTarget[tgt],gFileExt.rtr);
  train4total = openFileSubccdetail(name,"w");

  /* from 40 partial.vot file, get sorted[].name and .importance
   * in decreasing order. This information is used in
   * the next stage to delete unimportant attributes and thus 
   * convert train 40partial rtr file to train 4total rtr file
   */
  /* natt = number of important attributes */
  natt = 0;
  numSorted = 0;
  strcpy(control,"initial");

  while (fgets(fileRec,MAXLEN,vote40partial) != 0) { /* while #1 */

    /* control = "initial" */  
    if (strcmp(control,"initial") == 0) {
      if (strncmp(fileRec,"Significance of Literals",24) == 0) {
        strcpy(control,"Significance of Literals");
        continue;
      }
    }

    /* control = "Significance of Literals" */
    if (strcmp(control,"Significance of Literals") == 0) {
      if (strncmp(fileRec,"Literal",7) == 0) {
        strcpy(control,"Literal");
        continue;
      }
    }

    /* control = "Literal" */
    if (strcmp(control,"Literal") == 0) {
      /* get attribute and importance factor */
      buffer = strtok(fileRec, " \t\n");
      if ((buffer == NULL) || (buffer[0] == '\n')) {
        break;
      }

      /* replace last underscore of attribute by '\0'
       * the underscore was produced by the discretization,
       * and its replacement by string termination symbol
       * eliminates the discretization index from the attribute
       */
      flag = 0;
      m = strlen(buffer);
      for (j=m-1; j>=1; j--) {
        if (buffer[j] == '_') {
          buffer[j] = '\0';
         flag = 1;
          break;
        }
      }
      if (flag == 0) { /* error, attribute name does not have
                        * underscore produced by discretization
                        */
        sprintf(message,
        "Underscore of discretization missing from attribute = %s\n",
        buffer);
        suberror(message,"train40partial2train4total","401");
      }

      /* check if attribute is already listed */
      flag = 0;
      for (i=1; i<=numSorted; i++) {
        if (strcmp(sorted[i].name,buffer) == 0) {
          flag = 1;
          break;
        }
      }
      if (flag == 0) {
        numSorted++;
        strcpy(sorted[numSorted].name,buffer);
        buffer = strtok(NULL, " \t\n");
        /* buffer has "+" or "-" */
        if ((buffer[0] != '+') && (buffer[0] != '-')) {
          suberror("Record missing + or -",
                   "train40partial2train4total","302");
        }
        buffer = strtok(NULL, " \t\n");
        /* buffer has significance value */
        if (buffer == NULL) {
          suberror("Missing significance value",
                     "train40partial2train4total","303");
        }
        sorted[numSorted].importance = (float) atof(buffer);
        if ((sorted[numSorted].importance >=
             gParams.attributeImportanceThreshold) &&
            (numSorted <= gParams.maxAttributesUsed)) {
           natt = numSorted;
        }
      }          
    }
  } /* end while #1 */

   /* if no important attributes found, return 1 */
  if (natt == 0) {
    closeFile(vote40partial);
    closeFile(train40partial);
    closeFile(train4total);
    return 1;
  }

  /* use list of important attributes to
   * reduce attribute list of 40partial rtr file and
   * get 4total rtr file
   */
  strcpy(control,"ATTRIBUTES");
  while (fgets(fileRec,MAXLEN,train40partial) != 0) { /* while #2 */
    if (strcmp(control,"ATTRIBUTES") == 0) {
      buffer = strtok(fileRec," \t\n");
      if (buffer != NULL) {
        if (stringCompare(buffer,"ATTRIBUTES",10) == 0) {
          fprintf(train4total,"ATTRIBUTES\n");
          strcpy(control,"processATTRIBUTES");
          continue;
        }
      }
    }

    /* control = "processATTRIBUTES" */
    if (strcmp(control,"processATTRIBUTES") == 0) {
      strcpy(fileRecSave,fileRec);
      buffer = strtok(fileRec, " \t\n");
      if (buffer != NULL) { 
        if (stringCompare(buffer,"BEGIN",5) == 0) {
          fprintf(train4total,"%s",fileRecSave);
          strcpy(control,"restOfFile");
          continue;
        }
        /* check if attribute is important */
        flag = 0;
        for (i=1; i<= natt; i++) {
          if (strcmp(buffer,sorted[i].name) == 0) {
            flag = 1;
            break;
          }
        }
        if (flag == 0) {
          /* delete unimportant attribute */
          fprintf(train4total,
          "%s DELETE * deleted earlier or during 4total reduction\n",
          buffer);           
        } else {
          fprintf(train4total,"%s",fileRecSave);
        }
      }
      continue;
    }

    /* control must be = "restOfFile" */
    if (strcmp(control,"restOfFile") != 0) {
      suberror("Control error, must have 'restOfFile' case",
             "train40partial2train4total","501");          
    }

    fprintf(train4total,"%s",fileRec); 

  } /* end while #2 */

  /* check for correct termination */
  if (strcmp(control,"restOfFile") != 0) {
    sprintf(message,
       "Incorrect control = '%s' termination\n",control);
    suberror(message,"train40partial2train4total","601");
  }
     
  closeFile(vote40partial);
  closeFile(train40partial);
  closeFile(train4total);

  return 0; 

}

/* last record of findSubgroups.c *****/
