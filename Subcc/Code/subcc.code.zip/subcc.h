/* first record of subcc.h *****/

/******************* Includes ***********************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <math.h>
#include <time.h>

/******************* Substitution Functions *********************/
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))

/******************* Input Maximums ****************************/
#define MAX_ATTRIBUTE 600   /* 300 */
#define MAX_CLAUSE 20       /* 100 */
#define MAX_CUT 100
#define MAXLEN 5000         /* length of buffer for file line */
                            /* must be > MAX_DIRECTORY + 2*MAX_ID */ 
#define MAX_RECORD 2500
#define MAX_RECORD_ASCII 15*MAX_RECORD /* record stored as ascii */
#define MAX_ENTRY 256
#define MAX_ID 256
#define MAX_DIRECTORY 256
#define MAX_TARGET MAX_ATTRIBUTE*MAX_CUT 
                          /* max number of target cases*/
#define MAX_SIG_CLAUSE 10 /* max number of significant A or B clauses
                           * for given target with given cut
                           */
#define MAX_SUBGROUP MAX_CUT*MAX_SIG_CLAUSE
#define MAX_TARGETCUT 10 /* must be >= 3, recommended 8-10        */
#define MIN_ENDFREQUENCY 3 /* must be >= 3, is min number         */
                           /* of data points from lowest or       */
                           /* highest value that cannot bracket   */
                           /* a target cutpoint or interval bound */
#define MAX_TGTVERSION 2   /* largest value of gTgtVersion[tgt]   */
/*eject*/
/*************** Attribute and Record Types *******************/
#define ATTRIBUTE 3
#define DELETE 5
#define SET 8
#define UNCERTAIN 9
#define TARGET  11
#define LOW     12
#define HIGH    13
#define ALL     14
#define LOWHIGH 15
#define VERYLOW     16
#define VERYHIGH    17
#define CASES  18
#define INTERVAL 19
#define NEWTGT 21
#define OLDTGT 22
#define TGTONLY 23
#define ALTERNATE 31
#define MASTER 32
#define DEFMAX 40
#define DEFMIN 41 

/****************** Miscellaneous Constants ****************/
#define POS 1
#define NEG 2
#define FALSE 0
#define TRUE 1
#define INFTY 999999999.0
#define NEGINFINITY -999999999.0
#define EPSILON 0.0001

/******************* Decision Constants *********************/
#define UNUSUALNESS 1
#define ACCURACY 2
#define BOTH 12

/************************************************************/
/*eject*/
/******************* Custom Data Types **********************/
/* parameters */
struct {
  char  prefix[MAX_ID];
  char  directory[MAX_DIRECTORY];
  char  leibnizpath[MAX_DIRECTORY];
  char  subccdetaildir[MAX_DIRECTORY+MAX_ID];
  char  master2masterABprogram[MAX_DIRECTORY+MAX_ID];
  float attributeImportanceThreshold;
  int   maxAttributesUsed;
  int   significanceMeasure;
  float subgroupThreshold;
  int   maxExpansion;
  int   defSizeSubgroup;
  int   sortSplitRatio;
} typedef SubccParams;

/* file extensions */
struct {
  char mst[32];
  char mstAB[32];
  char rtr[32];
  char rts[32];
  char rtsA[32];
  char rtsB[32];
  char rtsEqrtr[32];
  char ats[32];
  char rul[32];
  char cut[32];
  char sep[32];
  char sub[32];
  char tgt[32];
  char vot[32];
  char votA[32];
  char votB[32];
} typedef FileExtensions;

/* formula data */
struct{
  int numClass;
  int numOppositeClass;
  int numTrueClass;
  int numTrueOppositeClass;
  int numClause; /* number of clauses in formula */
  int clause[MAX_CLAUSE+1][MAX_ATTRIBUTE+1]; 
  /* clause[i][j] = +- index of jth literal in clause i */ 
  /* clause[i][0] = number of literals in clause i */
} typedef FormulaData;
/*eject*/
/* sorted attributes for expansion process */
/* for interpretation, see 'Attribute information' section below */
struct{
  char   name[MAX_ID];
  char   type[MAX_ID];
  float  importance;
  double factor;
} typedef SortedAttributes;

/* list of attributes for expansion process */
/* for interpretation, see 'Attribute information' section below */
struct{
  char   name[MAX_ID];
  char   type[MAX_ID];
  int numTerm;
  int index[3];
  double coefficient[3]; 
} typedef ListAttributes;
/*eject*/
/* subgroup data = clause and target data */
struct {
  int keepFlag;
  int numClass;
  int numOppositeClass;
  int numTrueClass;
  int numTrueOppositeClass;
  float ARPprobability;
  float significanceClass;
  float significanceOppositeClass;
  float significanceOverall;
  int numLiteral;
  char literal[MAX_ATTRIBUTE+1][MAX_ID];
  char rule[MAX_ATTRIBUTE+1][MAX_ID];
  char target[MAX_ID];            /* target name */
  int tgt;                        /* target index */
  int stage;                      /* stage index */
  int tgtVersion;                 /* number of target intervals */
                                  /* = 1 or 2 */
                                  /* if 1: type = low, high */
                                  /* if 2: type = lowhigh, middle */
  int tgtRange; 
  /* range of cutpoints for target
   * = CASES
   *
   * Example:
   *
   * TARGETCASES_x_y_z
   *
   *   x = low index of cutpoints used
   *   y = high index of cutpoints used
   *   z = max number of cutpoints initially considered
   *
   *   for each cutpoint:
   *     A = low values (below cutpoint)
   *     B = high values (above cutpoint)
   *
   * = INTERVAL
   *
   * Example:
   *
   * TARGETINTERVAL_x_y_z
   *
   *   x = low index of cutpoints used
   *   y = high index of cutpoints used
   *   z = max number of cutpoints initially considered
   *
   *   for each cutpoint:
   *     A = low values (below cutpoint)
   *     B = high values (above cutpoint)
   *   for each pair of cutpoints:
   *     A = set of low or high values
   *     B = set of middle values
   *
   * = SET      
   * 
   * Example:
   * 
   * TARGETSET_x_y_z
   *
   *   x = low index of cutpoints used
   *   y = high index of cutpoints used
   *   z = max number of cutpoints initially considered
   *   
   *   for each cutpoint:
   *     A = set of low values
   *     B = set of high values
   *   for each pair of adjacent cutpoints:
   *     A = set of low or high values
   *     B = set of middle values 
   *
   * all options below became obsolete Sept 2009
   *
   * the initial number of cutpoints is equal to MAX_TARGETCUT
   * of subcc.h or is given by an appended '_z', where z is the
   * number of cutpoints  
   * = ALL     all cutpoints  
   *            A = set of low values  
   *            B = set of high values  
   * = LOW     all cutpoints <= median value
   *            A = set of low values   
   *            B = set of high values
   * = VERYLOW  20% smallest cutpoints of all cutpoints
   *            A = set of low values   
   *            B = set of high values  
   * = HIGH    all cutpoints >= median value  
   *            A = set of low values   
   *            B = set of high values
   * = VERYHIGH 20% highest cutpoints of all cutpoints
   *            A = set of low values   
   *            B = set of high values   
   * = LOWHIGH: (1) all cutpoints  
   *                 A = set of low values  
   *                 B = set of high values 
   *            (2) all pairs of cutpoints where 
   *                one cutpoints <= median value,
   *                second cutpoint >= median value
   *                 A = set of low or high values
   *                 B = set of middle values
   */
  char tgtTypeClass[MAX_ID];         /* target type of class */
  char tgtTypeOppositeClass[MAX_ID]; /* target type opposite class */
  char tgtRuleClass[MAX_ID];         /* target rule of class */
  char tgtRuleOppositeClass[MAX_ID]; /* target rule opposite class */
} typedef ClauseData;
/*eject*/
/* literals and rules */
struct {
  char literal[MAX_ID];
  char rule[MAX_ID];
} typedef LitRule;

/* class counts */
struct {
  int A;
  int B;
  int total;
} typedef ClassCount;

/* cutpoint and uncertainty interval data */
  struct{
    int leftIndex;              /* index i of targetData[i] to     */
                                /*   left of cutpoint              */
    double cutValue;            /* value of cutpoint               */
    double leftUncertainValue;  /* left value, uncertain interval  */
    double rightUncertainValue; /* right value, uncertain interval */
  } typedef CutData;

/* target data used in extractTargetData() */
  struct{
    float data[MAX_RECORD][MAX_ATTRIBUTE];
    int valueKnown[MAX_RECORD][MAX_ATTRIBUTE];
  } typedef Target;
  Target target;
/*eject*/
/******************* Global Variables ***********************/
char lsqccparamsname[MAX_ID];

/* number of attributes, records, targets */
int gNumAttributes;
int gNumRecords;
int gNumTargets; /* number of target patterns */
int gNumTargetVariables; /* number of target variables */

/* display and control */
int gNumOpenFiles;
int gShowSteps;
int gShowTargetSteps;
int gOutputVariations;
int gKeepSubccdetail;
int gSelectTargetFile;
int gSelectTestFile;
int guse40partialExtra;

/* control/path parameters */
SubccParams gParams;
 
/* file extensions */
FileExtensions gFileExt;

/* error file */
FILE* errfil;

/* error flag for entire process */
/*  = 0: no errors */
int errorflag;

/* total number of subgroups in .sub output file */
int numSubgroup;
/*eject*/
/**************** Attribute information *******************/
SortedAttributes sorted[MAX_ATTRIBUTE+1];
int numSorted;
/* interpretation; i = index of attribute
 * sorted[i].name        name of attribute i
 *          .type        type of attribute i (= NUM, SET, UNCERTAIN)
 *          .importance  importance of attribute i
 *          .factor      scaling factor for attribute i in expansion
 *                       see file algorithm.txt for use of factor
 */

ListAttributes list[MAX_ATTRIBUTE+1]; 
int numList;
/* interpretation: j = index of attribute
 * list[j].name          name of attribute j
 *        .type          type of attribute j (= NUM, SET, UNCERTAIN)
 *        .numTerm       number of terms in expansion formula (= 1,2)
 * for k = 1, 2:
 *        .index[k]       attribute index of term k in expansion
 *        .coefficient[k] coefficient of term k in expansion
 */
int newNum; /* new number of attributes due to expansion */

int sorted2list[MAX_ATTRIBUTE+1];/*=index of sorted[i].name in list[]*/
int list2sorted[MAX_ATTRIBUTE+1];/*=index of list[j].name in sorted[]*/
                    /* if list[j].name does not occur in sorted[], */
                    /* then list2sorted[j] = 0                     */
/*eject*/
/**************** Target information **********************/
char  gTarget[MAX_TARGET+1][MAX_ID];  /* target name  */
int   gTgtRange[MAX_TARGET+1];
/* range of cutpoints for target
 * = CASES
 *
 * Example:
 *
 * TARGETCASES_x_y_z
 *
 *   x = low index of cutpoints used
 *   y = high index of cutpoints used
 *   z = max number of cutpoints initially considered
 *
 *   for each cutpoint:
 *     A = low values (below cutpoint)
 *     B = high values (above cutpoint)
 *
 * = INTERVAL
 *
 * Example:
 *
 * TARGETINTERVAL_x_y_z
 *
 *   x = low index of cutpoints used
 *   y = high index of cutpoints used
 *   z = max number of cutpoints initially considered
 *
 *   for each cutpoint:
 *     A = low values (below cutpoint)
 *     B = high values (above cutpoint)
 *   for each pair of cutpoints:
 *     A = set of low or high values
 *     B = set of middle values
 *
 * = SET
 *
 * Example:
 *
 * TARGETSET_x_y_z
 *
 *   x = low index of cutpoints used
 *   y = high index of cutpoints used
 *   z = max number of cutpoints initially considered
 *   
 *   for all cutpoints:
 *     A = set of low values
 *     B = set of high values
 *   for each pair of adjacent cutpoints:
 *     A = set of low or high values
 *     B = set of middle values  
 *
 * all options below became obsolete Sept 2009
 *
 * the initial number of cutpoints is equal to MAX_TARGETCUT
 * of subcc.h or is given by an appended '_z', where z is the
 * number of cutpoints     
 * = ALL     all cutpoints  
 *            A = set of low values  
 *            B = set of high values  
 * = LOW     all cutpoints <= median value
 *            A = set of low values   
 *            B = set of high values
 * = VERYLOW  20% smallest cutpoints of all cutpoints
 *            A = set of low values   
 *            B = set of high values   
 * = HIGH    all cutpoints >= median value  
 *            A = set of low values   
 *            B = set of high values
 * = VERYHIGH 20% highest cutpoints of all cutpoints
 *            A = set of low values   
 *            B = set of high values   
 * = LOWHIGH: (1) all cutpoints  
 *                 A = set of low values  
 *                 B = set of high values 
 *            (2) all pairs of cutpoints where 
 *                one cutpoints <= median value,
 *                second cutpoint >= median value
 *                 A = set of low or high values
 *                 B = set of middle values  
 */
int   gTgtVersion[MAX_TARGET+1];  /* target version   */
/* Uncertainty information of targets
 * Interpretation for target j in ATTRIBUTES section of .mst file
 *
 *   gTgtVersion[j] = 1:
 *     there is one cutpoint and interval
 *     boundary points of interval:
 *       gUncertainTgtLow[j][1],gUncertainTgtHigh[j][1]
 *     set A: value < gUncertainTgtLow[j][1]    "low"
 *     set B: value < gUncertainTgtHigh[j][1]   "high"
 *
 *   gTgtVersion[j] = 2:
 *     there are two cutpoints and intervals
 *     boundary points of intervals:
 *       gUncertainTgtLow[j][1],gUncertainTgtHigh[j][1]
 *       gUncertainTgtLow[tgt][2],gUncertainTgtHigh[j][2]
 *     set A: value < gUncertainTgtLow[j][1] ||
 *            value > gUncertainTgtHigh[j][2] "lowhigh"
 *     set B: value > gUncertainTgtHigh[j][1] &&
 *            value < gUncertainTgtLow[j][2] "middle" 
 * CAUTION: If largest possible gTgtVersion[j] value is k, then
 *          MAX_TGTVERSION must be specified as k
 */

float gUncertainTgtLow[MAX_TARGET+1][MAX_TGTVERSION+1];
float gUncertainTgtHigh[MAX_TARGET+1][MAX_TGTVERSION+1];

int gMaxTgtCuts[MAX_TARGET+1];
/*   gMaxTgtCuts[j] = max number of target cuts for target j
 *                    in ATTRIBUTES section of .mst file
 */

int gLowTgtCuts[MAX_TARGET+1];
/*   gLowTgtCuts[j] = low index of target cuts for target j
 *                    in ATTRIBUTES section of .mst file
 */

int gHighTgtCuts[MAX_TARGET+1];
/*   gHighTgtCuts[j] = high index of target cuts for target j
 *                    in ATTRIBUTES section of .mst file
 */


/*eject*/
/* Arrays for variables, formulas, clauses, literals, rules */
ClassCount numRec;  /* record counts for classes of target tgt */

ClauseData Aclause[MAX_CLAUSE+1];/* clauses of formula A, target tgt */
ClauseData Bclause[MAX_CLAUSE+1];/* clauses of formula B, target tgt */
ClauseData subgroup[MAX_SUBGROUP+1];

FormulaData Aformula; /* formula A, target tgt */
FormulaData Bformula; /* formula B, target tgt */

char variable[MAX_TARGET+1][MAX_ID]; 
/* variables (= attributes) occurring with target tgt */
int numVariable; /* number of variables in variable[] */

LitRule literalRule[2*MAX_TARGET+1];
/* literals and associated rules, arising from the variables
listed in variable[], associated with A and B of target tgt */
int numLiteralRule; /* number of literals/rules in literalRule[] */

/* values of normal distribution */
float normDistr[50];

/*eject*/
/******************** Subroutines **************************/

int  subcc();

/************* createTargets.c **************/
void bubbleSort(double *targetData,int targetDataSize);
void createTargets();
void defineUncertainty(double *targetData, int *frequency,
                       int targetDatasize, int totalCount,
                       int targetRange, CutData *cut, 
                       int numTargetcuts, int maxTargetcuts);
void extractTargetData();
void makeCutpoints(double *targetData, int targetDataSize,
                   CutData *cut, int *numTargetCuts, 
                   int maxTargetCuts);
void outputTargetCases(FILE *tgtfil, char *targetName, 
                       int targetRange, CutData *cut,
                       int numTargetCuts, int initNumTargetcuts);
void processTargets();
void reduceCutpoints(int *frequency, int targetDataSize,
                     int targetRange, CutData *cut, 
                     int *numTargetCuts,
                     int lowTargetCuts, int highTargetCuts);
void reduceMultipleEntries(double *targetData, int *frequency,
                           int *targetDataSize);

/*********** evaluateSubgroups.c ************/
void evaluateSubgroups(int atsmstcase);
void addTgtInfo(int tgt, int stage);
void clauseSignificance();
void getClauses(int tgt, int stage);
void getVotes(int tgt, int stage);
void getLiteralsAndRules(int tgt, int stage);
void outputRules(int atsmstcase);
void outputSubgroups(FILE *subgroupResults);
float significance(float prob, int numRecords, int numTrue);
void valuesNormDistr();

/*********** findSubgroups.c *********/
void findAtsSubgroups();
void findMstSubgroups();
void createLsqccParamsFiles();
int  defineDataFiles(int tgt, int stage);
void expandRecord(FILE *out, char *fileRec);
void initializeDataFiles(int tgt, int stage);
int  train40partial2train4total(int tgt, int stage);

/************** readFiles.c *************/
void getCutListSorted(int tgt, int stage);
void getFormulas(int tgt, int stage);
void getListRules(int tgt,int stage,char *target);
void loadTargetFile();
void lowerCase(char *ch);
int  parse_param(char *lhs, char *rhs, char *record, 
                 FILE *params);
void readTargetLine(char fileRec[],int *ai); 
void readParamsFile();
void shiftLeft(char fileRec[]);

/*********** selectSubgroups.c *********/
void selectSubgroups(int atsmstcase);
int  compareSubgroups(int i, int k);
int  getNextTargetSubset(FILE *subgroupResults,int *n);
void makeFullRule(char *name, char *fullRule, int *clauseDim);
void outputSelectedSubgroup(int atsmstcase,FILE *subfil,int i);
/*eject*/
/************** util.c *************/
void  constructSubccdetail();

void closeFile(FILE* file);
FILE* openFile(char* name, char* mode);
FILE* openFilePrefix(char* extension, char* mode);
FILE* openFileSubccdetail(char* name, char* mode);

void  removeSubccdetail();
void  showTargetSteps(char *message);
int   stringCompare(const char *a, const char *b, int n);
void  suberror(char *m1,char *m2,char *m3);

void  varToCutValues(int ai, int var, float *cutValue1, 
                    float *cutValue2);
void  varToTgtValues(int ai, int var, float *cutValue1, 
                    float *cutValue2);
/*********** xRoutines.c ***********/
int Xcutcc40partial(int tgt, int stage);
int Xcutcc4total(int tgt, int stage);
int Xcutcc4totalA(int tgt, int stage);
int Xcutcc4totalB(int tgt, int stage);
int Xlsqcc40partial(int tg, int staget);
int Xlsqcc4total(int tgt, int stage);
int Xtstcc4total(int tgt, int stage);
int Xtstcc4totalA(int tgt, int stage);
int Xtstcc4totalB(int tgt, int stage);

int Xconcatenate(int tgt, int stage);
int XfileAB2test40partial(int tgt, int stage);
int XfileAB2test4total(int tgt, int stage, char *name);
int Xlsqcc40partial(int tgt, int stage);
int Xlsqcc4total(int tgt, int stage);
int XalternateTest2testABTarget(int tgt, int stage);
int Xmaster2masterABTarget(int tgt, int stage);
int XuseParams40partialExtra(int tgt, int stage);
int XsortMaster(int tgt);
int XsplitMaster(int tgt);

/* last record of subcc.h *******/
