/* first record of selectSubgroups.c *****/
#include "subcc.h"
/***************************************************************/ 
/*
 * subroutines in this file:
 *   void selectSubgroups(int atsmstcase)
 *   int  compareSubgroups(int i, int k)
 *   void makeFullRule(char *name, char *fullRule, int *clauseDim);
 *   void getListRules(int i);
 *   int  getNextTargetSubset(FILE *subgroupResults, int *n)
 *   void outputSelectedSubgroup(int astmstcase,FILE *subfil,int i)
 */  
/***************************************************************
 * select subgroups with significance >= threshold
 * eliminate duplicate cases where logic representation
 * is identical, and retain one representative subgroup
 * with largest significance
 ***************************************************************/
void selectSubgroups(int atsmstcase) {

  int flag, i, index, k, n, var;

  char name[MAXLEN];

  FILE *subgroupResults;
  FILE *subfil;

  /* open subgroup.results.mst or .ats file */
  if (atsmstcase == MASTER) {
    sprintf(name,"subgroup.results%s",gFileExt.mst);
  } else {
    sprintf(name,"subgroup.results%s",gFileExt.ats);
  }
  subgroupResults = 
    openFileSubccdetail(name,"r");

  /* open .mst.sub or .ats.sub file */
  if ( atsmstcase == MASTER) {
  sprintf(name,"%s%s%s%s",
           gParams.directory, gParams.prefix,
           gFileExt.mst,gFileExt.sub);
  } else {
  sprintf(name,"%s%s%s%s",
           gParams.directory, gParams.prefix,
           gFileExt.ats,gFileExt.sub);
  }  
  subfil = 
    openFile(name,"w");
  /* if master file is used as test file, add caution
   * statement at beginning of sub file
   */
  if (atsmstcase == MASTER) {
    fprintf(subfil,
       "CAUTION: Master file is used as test file.\n");
    fprintf(subfil,
       "         Do NOT use output for statistical\n");
    fprintf(subfil,
       "         validation of factors or formulas.\n\n");
  } else {
    fprintf(subfil,
       "NOTE: Alternate test file is used for testing.\n");
    fprintf(subfil,
       "      Output may be used for validation of\n");
    fprintf(subfil,
       "      factors and formulas.\n\n");
  }

  if (gParams.defSizeSubgroup == DEFMAX) {
    fprintf(subfil,
	    "Subgroup definitions are of MAX size\n");
  } else if (gParams.defSizeSubgroup == DEFMIN) {
    fprintf(subfil,
	    "Subgroup definitions are of MIN size\n");
  } else {
    suberror("Error of defSizeSubgroup value",
             "selectSubgroups","101");  
  }

  if (gParams.significanceMeasure == UNUSUALNESS) {
    fprintf(subfil,
	"Significance measure = unusualness\n\n");
  } else if (gParams.significanceMeasure == ACCURACY) {
    fprintf(subfil,
	"Significance measure = accuracy\n\n");
  } else if (gParams.significanceMeasure == BOTH) {
    fprintf(subfil,
	"Significance measure = both unusualness and accuracy\n\n");
  } else {
    suberror("Unknown significance measure",
             "selectSubgroups","102");  
  }  
  fprintf(subfil,
          "*****************************************\n\n");

  numSubgroup = 0;
  flag = 1;
  while (flag > 0) { /* while flag > 0 */

    flag = getNextTargetSubset(subgroupResults,&n);
    if (n == 0) { /* no subgroup of this subset satisfies */
                  /* significance threshold */
      continue;
    }

    /* subgroup is stored in subgroup[] */
    /* delete dominated subgroups */
    for (i=1; i<n; i++) { /* for i #1 */

      if (subgroup[i].keepFlag == FALSE) {
        continue;
      }

      for (k=i+1; k<=n; k++) { /* for k #1 */
        if (subgroup[k].keepFlag == FALSE) {
          continue;
        } 
        index = compareSubgroups(i,k);
        /* action is based on index
         * index = i: delete subgroup i
         *       = k: delete subgroup k
         *       = 0: subgroups i and k differ, no action
         */
        if (index == 0) {
          continue;
        }
        if (index == i) {
          subgroup[i].keepFlag = FALSE;
          break;
        } else {
          subgroup[k].keepFlag = FALSE;
        }
      } /* end for k #1 */
    } /* end for i # 1 */

    /* output selected subgroups */
    for (i=1; i<=n; i++) { /* for i #2 */

      if (subgroup[i].keepFlag == FALSE) {
        continue;
      }
      numSubgroup++;
      outputSelectedSubgroup(atsmstcase,subfil,i);

      /* output dominated variations of subgroup i */
      var = 0;
      fprintf(subfil,"\n");
      for (k=1; k<=n; k++) { /* for k #2 */

        if ((subgroup[k].keepFlag == TRUE) ||
            (compareSubgroups(i,k) == 0)) {
          continue;
        }

        if (var == 0) {
          fprintf(subfil,"VARIATIONS OF ABOVE CASE\n\n");
          if (gOutputVariations == FALSE) {
            fprintf(subfil,"Target\tStage\n ");
          } else {
            fprintf(subfil,"\n");
          }
          var = 1;
        }

        if (gOutputVariations == FALSE) {
          fprintf(subfil,"%4d\t%3d\n ",
                  subgroup[k].tgt, subgroup[k].stage);
        } else {
          numSubgroup++;
          outputSelectedSubgroup(atsmstcase,subfil,k);
          fprintf(subfil,"\n");
        }

      } /* end for k #2 */
      fprintf(subfil,"*********************************");

      fprintf(subfil,"*********************************\n\n");
    } /* end for i # 2*/


  } /* end while flag > 0 */

  fprintf(subfil,"ENDATA");

  closeFile(subgroupResults);
  closeFile(subfil);

  return;  
}
/*eject*/
/***************************************************************
 * compareSubgroups(int i, int k): compare subgroups i and k
 * if they are different, return 0
 * if subgroups i and k have the same logic representation:
 *   if subgroup i is at most as significant as subgroup k,
 *   return i; else return k
 ***************************************************************/
int compareSubgroups(int i, int k) {

  /* consider two cases different if they have
   * different tgtTypeClass, tgt, stage, or tgtVersion
   */
  if ((strcmp(subgroup[i].tgtTypeClass,
	      subgroup[k].tgtTypeClass) != 0) ||
      (subgroup[i].tgt != subgroup[k].tgt) ||
      (subgroup[i].stage != subgroup[k].stage) ||
      (subgroup[i].tgtVersion != subgroup[k].tgtVersion)) {
    return 0;
  }
  /* return the one with lower significance value */
  if (subgroup[i].significanceOverall <=
      subgroup[k].significanceOverall) {
    return i;
  } else {
    return k;
  }

  /* obsolete code, removed April 18, 2008
   * considers two cases different if they have
   * different tgtTypeClass or nonmatching literals
   */
  /* int j;

  if ((strcmp(subgroup[i].tgtTypeClass,
	     subgroup[k].tgtTypeClass) != 0) ||
      (subgroup[i].numLiteral != subgroup[k].numLiteral)) {
    return 0;
  }
    
  for (j=1; j<=subgroup[i].numLiteral; j++) {
    if (strcmp(subgroup[i].literal[j],
               subgroup[k].literal[j]) != 0) {
      return 0;
    }
  }
  */

}
/*eject*/
/***************************************************************
 * getNextTargetSubset(FILE *subgroupResults, int *n):
 * get all subgroups for one target name 
 ***************************************************************/
int getNextTargetSubset(FILE *subgroupResults, int *n) {

  int i, j;

  char fileRec[MAXLEN];
  char *buffer;

  for (i=1; i<=MAX_SUBGROUP; i++) { /* for i */

    if (fgets(fileRec,MAXLEN,subgroupResults) == 0) {
      /* have reached end of file */
      *n = i-1;
      return 0;
    }

    if (fileRec[0] == '\n') {
      /* have reached end of records with same target name */
      *n = i-1;
      return 1;
    }

    /* process next target case */
    subgroup[i].keepFlag = TRUE;

    sscanf(fileRec,"%d %d %d %d %f %f %f %f %d",
            &subgroup[i].numClass,
            &subgroup[i].numOppositeClass,
            &subgroup[i].numTrueClass,
            &subgroup[i].numTrueOppositeClass,
            &subgroup[i].ARPprobability,
            &subgroup[i].significanceClass,
            &subgroup[i].significanceOppositeClass,
            &subgroup[i].significanceOverall,
            &subgroup[i].numLiteral);

    for (j=1; j<=subgroup[i].numLiteral; j++) { /* for j #1 */

      if (fgets(fileRec,MAXLEN,subgroupResults) == 0) {
        suberror("Unexpected end of subgroupResults file",
                 "getNextTargetSubset","101");
      }
      sscanf(fileRec,"%s",subgroup[i].literal[j]);

      if (fgets(fileRec,MAXLEN,subgroupResults) == 0) {

        suberror("Unexpected end of subgroupResults file",
                 "getNextTargetSubset","201");
      }
      buffer = strtok(fileRec,"\n");
      strcpy(subgroup[i].rule[j],buffer);
    } /* end for j #1 */

    if (fgets(fileRec,MAXLEN,subgroupResults) == 0) {
      suberror("Unexpected end of subgroupResults file",
               "getNextTargetSubset","301");
    }
    sscanf(fileRec,"%s %d %d %d %s %s",
             subgroup[i].target,
            &subgroup[i].tgt,
            &subgroup[i].stage,
            &subgroup[i].tgtVersion,
             subgroup[i].tgtTypeClass,
             subgroup[i].tgtTypeOppositeClass);

    if (fgets(fileRec,MAXLEN,subgroupResults) == 0) {
      suberror("Unexpected end of subgroupResults file",
               "getNextTargetSubset","401");
    }
    buffer = strtok(fileRec,"\n");
      strcpy(subgroup[i].tgtRuleClass,buffer);

    if (fgets(fileRec,MAXLEN,subgroupResults) == 0) {
      suberror("Unexpected end of subgroupResults file",
               "getNextTargetSubset","501");
    }
    buffer = strtok(fileRec,"\n");
    strcpy(subgroup[i].tgtRuleOppositeClass,buffer);

    /* evaluate significance of subgroup */
    if (subgroup[i].significanceOverall < 
         gParams.subgroupThreshold) {
      i--;
      continue;
    }

  } /* end for i */
/*eject*/
  /* MAX_SUBGROUP is too small */
  suberror("MAX_SUBGROUP is too small",
           "getNextTargetSubset","901");

  return -1; /* to suppress compiler warning */
}
/*eject*/
/***************************************************************
 * makeFullRule(char *buffer, char *fullRule, int *clauseDimt): 
 * use list[] data to make full rule for added attribute 
 * in terms of original attributes
 * input:  buffer     rule for expansion variable
 * output: fullRule   statement for printing 
 *                      except that final '\n' is not included
 *         clauseDimt clause dimension (= VC dimension of clause 
 *                    defined by fullRule
 ***************************************************************/
void makeFullRule(char *buffer, char *fullRule, int *clauseDimt) {

  int clauseDim;
  int flag, j, k, m;
  
  char addRule[MAXLEN];
  char ineq[MAX_ID];
 
  double a[MAX_ATTRIBUTE];/* a[k], k >= 1:  coefficient       */
                          /* a[0]:          rhs of inequality */
  double scale = 1.0; /* to suppress compiler warning */

  clauseDim = 0;

  /* get index k of variable name and initialize a[k] = 1.0 */
  flag = 0;
  for (k=1; k<=numList; k++) {
    if (strcmp(buffer,list[k].name) == 0) {
      a[k] = 1.0;
      flag = 1;
      break;
    }
    a[k] = 0.0;
  }
  if (flag == 0) {
    suberror("Inconsisten list[] data",
             "makeFullRule","101");
  }

  /* get inequality type */
  buffer = strtok(NULL," \t");
  if (buffer == NULL) {
    suberror("Missing inequality sign",
             "makeFullRule","151");
  }
  strcpy(ineq,buffer);

  /* get rhs value and store in a[0] */
  buffer = strtok(NULL," \t)");
  if (buffer == NULL) {
    suberror("Missing rhs value",
             "makeFullRule","152");
  }
  a[0] = (double) atof(buffer);  

  /* compute equivalent coefficients for original variables */
  flag = 0;
  for (j=k; j>=1; j--) { /* for k #1 */
    if (list[j].numTerm == 1) {
      flag = 1;
      break;
    }
    if (a[j] == 0.0) {
      continue;
    }
    /* attribute j has two terms and a[j] != 0 */
    for (m=1; m<=2; m++) {
      a[list[j].index[m]] += list[j].coefficient[m] * a[j];
    }
  } /* end for k #1 */
  if (flag == 0) {
    suberror("Inconsisten list[] data",
             "makeFullRule","201");
  }

  /* for k >= 1, scale a[k] values so that the smallest absolute */
  /* coefficient is equal to 1.0 */
  /* first, get scale factor scale */
  flag = 0;
  for (k=1; k<=j; k++) { /* for k #2 */
    if (a[k] != 0.0) {
      if (flag == 0) {
        scale = fabs(a[k]);
        flag = 1;
      } else {
        if (scale > fabs(a[k])) {
          scale = fabs(a[k]);
        }
      }
    }
  } /* end for k #2 */
  if (flag == 0) {
    suberror("All zero coefficients",
             "makeFullRule","301");
  }

  /* second, scale a[k] values and a[0] */
  for (k=0; k<=j; k++) { /* for k #3 */
    if (a[k] != 0.0) {
      a[k] /= scale;
    }    
  } /* end for k #3 */

 
  /* have: a[k], k >= 1: scaled coefficients */
  /*       a[0]:         scaled rhs */
  /* insert coefficients into fullRule */
  flag = 0;
  for (k=1; k<=j; k++) { /* for k #4 */
    if  (a[k] == 0.0) {
      continue;
    } else if (a[k] > 0.0) {
      if (flag == 0) {
        sprintf(fullRule,"\t\t( ");
        flag = 1;
      } else {
        strcat(fullRule, "\n\t\t +");
      }
      sprintf(addRule,"%lf %s", a[k], list[k].name);
      strcat(fullRule,addRule);
      clauseDim++;
    } else {
      if (flag == 0) {
        sprintf(fullRule,"\t\t( -");
        flag = 1;
      } else {
        strcat(fullRule, "\n\t\t -");
      }
      sprintf(addRule,"%lf %s", -a[k], list[k].name);
      strcat(fullRule,addRule);
      clauseDim++;
    }
  } /* end for k #4 */
  if (flag == 0) {
    suberror("All zero coefficients",
             "makeFullRule","401");
  }
  
  /* insert rhs value into fullRule */
  sprintf(addRule," %s %lf )",ineq,a[0]);
  strcat(fullRule,addRule);

  /* if clauseDim >= 2, add +1 to get VC dimension of clause */
  if (clauseDim >= 2) {
    clauseDim++;
  }

  /* June 2008: replaced above obsolete computation of clauseDim
   *  obsolete rule: clauseDim = 1 if inequality with k = 1 variables
   *                           = k+1 otherwise
   * new rule, based on VC dim for inequality b^t\cdot z >  \alpha
   *           with constant vector b and varying \alpha
   *                 clauseDim = 1
   */
  clauseDim = 1;

  *clauseDimt = clauseDim; /* transfer value for return */
  return;

} /* end makeFullRule */
/*eject*/
/***************************************************************
 * outputSelectedSubgroup(): for atsmstcase, output subgroup i 
 * to .sub file
 ***************************************************************/
void outputSelectedSubgroup(int atsmstcase,FILE *subfil,int i) {

  int clauseDim, vcDim;
  int flag, j;

  float rSens, rSpec;

  char *buffer;
  char name[MAXLEN]={'\0'};
  char fileRec[MAXLEN];
  char fullRule[MAXLEN];
  char message[MAXLEN];
  char percent[]="%";

  FILE *sepfil;

  if (subgroup[i].stage > 0) {
    getListRules(subgroup[i].tgt,subgroup[i].stage,
                 subgroup[i].target);
  }

  fprintf(subfil,
          "SUBGROUP %d significance = %f\n\n",
          numSubgroup, subgroup[i].significanceOverall);

  fprintf(subfil,
          "TARGET %d STAGE %d  '%s' versus '%s'\n\nATTRIBUTE %s\n",
          subgroup[i].tgt,
          subgroup[i].stage,
          subgroup[i].tgtTypeClass,
          subgroup[i].tgtTypeOppositeClass, 
          subgroup[i].target);
   

  fprintf(subfil,
          "  '%s' definition:\t%s\n", 
          subgroup[i].tgtTypeClass, subgroup[i].tgtRuleClass);

  fprintf(subfil,
          "  '%s' definition:\t%s\n\n", 
          subgroup[i].tgtTypeOppositeClass, 
          subgroup[i].tgtRuleOppositeClass);
/*eject*/
  /* target factors */

  fprintf(subfil,"  Factors:\n");

  if (subgroup[i].numLiteral == 1) {
    fprintf(subfil,"    %d factor implies '%s':\n",
            subgroup[i].numLiteral, subgroup[i].tgtTypeClass);
  } else {
    fprintf(subfil,"    %d factors jointly imply '%s':\n",
            subgroup[i].numLiteral, subgroup[i].tgtTypeClass);
  }

  vcDim = 0;

  for (j=1; j<=subgroup[i].numLiteral; j++) {
    strcpy(name,subgroup[i].rule[j]);
    buffer = strtok(name,"( \t");
    if (strncmp(buffer,"EXPANSION_VARIABLE",
                strlen("EXPANSION_VARIABLE")) != 0) {
      fprintf(subfil,"\t\t%s",subgroup[i].rule[j]);
      vcDim++;
    } else {
      /* make full rule */
      makeFullRule(buffer,fullRule,&clauseDim);      
      fprintf(subfil,"%s",fullRule);
      vcDim += clauseDim;      
    }
    if (j < subgroup[i].numLiteral) {
      fprintf(subfil," &\n");
    } else {
      fprintf(subfil,"\n\n");
    }
  }
/*eject*/
  fprintf(subfil,
          "    Coverage for '%s' target values (= sensitivity):\n", 
          subgroup[i].tgtTypeClass);

  rSens = 100.0*(float) subgroup[i].numTrueClass/
            (float) subgroup[i].numClass;

  fprintf(subfil,
          "      %d out of %d '%s' records correctly identified\n",
          subgroup[i].numTrueClass, 
          subgroup[i].numClass,
          subgroup[i].tgtTypeClass);
  fprintf(subfil,"      (= %.1f%s)\n\n",
          rSens,percent);

  fprintf(subfil,
     "    Coverage for '%s' target values (= specificity):\n", 
     subgroup[i].tgtTypeOppositeClass);

  rSpec = 100.0*(1.0-(float) subgroup[i].numTrueOppositeClass/
	     (float) subgroup[i].numOppositeClass);

  fprintf(subfil,
	  "      %d out of %d '%s' records correctly identified\n",
          subgroup[i].numOppositeClass -
            subgroup[i].numTrueOppositeClass, 
          subgroup[i].numOppositeClass,
          subgroup[i].tgtTypeOppositeClass);
  fprintf(subfil,"      (= %.1f%s)\n\n",
          rSpec,percent);

  fprintf(subfil,"  Total for factors  = %.1f%s\n",
          rSens+rSpec,percent);
  fprintf(subfil,"  Unweighted average for factors  = %.1f%s\n",
          (rSens+rSpec)/2.0,percent);
  fprintf(subfil,"  VC dim estimate = %d\n\n",vcDim);
/*eject*/
  /* rule sets associated with target tgt and stage */

  sprintf(name,"%d.%d.%s.4total%s",
          subgroup[i].tgt,
          subgroup[i].stage, 
          subgroup[i].target, 
          gFileExt.sep);

  sepfil = openFileSubccdetail(name,"r");
  
  flag = 0;
  while (fgets(fileRec,MAXLEN,sepfil) != 0) {
    if (atsmstcase == MASTER) {
      if(strncmp(fileRec,"MASTER RULE SETS FOR TARGET",27) == 0) {
      flag = 1;
      break;
      }
    } else { /* ALTERNATE case */
      if(strncmp(fileRec,"ALTERNATE RULE SETS FOR TARGET",30) == 0) {
      flag = 1;
      break;
      }
    }
  }
  if (flag == 0) {
    sprintf(message,"Reading error in file %s\n",name);
    suberror(message,"outputSelectedSubgroup","301");
  }

  flag = 0;
  while (fgets(fileRec,MAXLEN,sepfil) != 0) {
    if (strncmp(fileRec,"ENDATA",6) == 0) {
      flag = 1;
      break;
    }
    fprintf(subfil,"%s",fileRec);
  }  
  if (flag == 0) {
    sprintf(message,"Reading error in file %s\n",name);
    suberror(message,"outputSelectedSubgroup","401");
  }

  fprintf(subfil,"\n");

  closeFile(sepfil);

  return;
}
/***************************************************************/
/* last record of selectSubgroups.c *****/
