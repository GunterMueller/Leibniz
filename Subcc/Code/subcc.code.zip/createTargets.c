/* first record of createTargets.c*******/
#include "subcc.h"
/***************************************************************/
/*
 * subroutines in this file:
 *   void createTargets(FILE *mstfil);
 *   void bubbleSort(double *a, int n);
 *   void defineUncertainty(double *a, int *freq, int size, 
 *                          int total, int range, CutData *cut, 
 *                          int nc, int maxc);
 *   void extractTargetData();
 *   void makeCutpoints(double *a, int size, CutData *cut, int *nct,
 *                      int maxc);
 *   void outputTargetCases(FILE *out, char *name, int range,
 *                          CutData *cut, int nc, int initc);
 *   void processTargets();
 *   void reduceCutpoints(int *freq, int size, int range,
 *                        CutData *cut, int *nct, 
 *                        int lowct, int highct);
 *   void reduceMultipleEntries(double *a, int *freq, int *nt);
 */
/*eject*/
/***************************************************************
 * createTargets(FILE *mstfil): creates targets from mst file
 *   outputs target data in tgt file
 *   input:  mst file
 *   output: targets.initialData
 ***************************************************************/
void createTargets() {

  /* extract target data from mst file */
  extractTargetData();

  /* process targets */
  processTargets();

  return;

} /* end of createTargets */
/*eject*/
/***************************************************************
 * bubbleSort(double *a, int n):
 *   input:  a[] array with n entries
 *   output: a[] with entries sorted in increasing order
 ***************************************************************/
void bubbleSort(double *a, int n) {

  int flag, i, k;
  double b;

  for (k=n-1; k>=1; k--) {

    flag = 0;

    for (i=1; i<=k; i++) {
      if (a[i] > a[i+1]) {
        b = a[i];
        a[i] = a[i+1];
        a[i+1] = b;
        flag = 1;
      }
    } /* end for i */

    if (flag == 0) {
      return;
    }
 
  } /* end for k */

  return;

} /* end bubbleSort */
/*eject*/
/***************************************************************
 * defineUncertainty(double *a, int *freq, int size, int total,
 *                   int range, CutData *cut, int nc, int maxc):
 *   define uncertainty values from a[] and freq[] values
 *   input:  a[]    values
 *           freq[] frequency of occurrence of a[] values 
 *           size   number of a[] values
 *           total  total number of values, including multiplicities
 *           range  target range
 *           nc     number of cutpoints
 *           maxc   max number of cutpoints
 *   output: cut[].leftUncertaintyValue low uncertainty value
 *           cut[].rightUncertaintyValue high uncertainty value
 ***************************************************************/
void defineUncertainty(double *a, int *freq, int size, int total,
                       int range, CutData *cut, int nc, int maxc) {

  int i, halfDistinctWidth,j,leftDistinctPoints,rightDistinctPoints;
  /* int halfWidth,leftPoints,rightPoints; for old rule, not used */
  double b, c;

  /* uncertainty width via count of all points, old rule, not used */
  /* b = (double) total;
   * c = log(b)/log(2.0);
   * c /= 2.0;
   * halfWidth = c;
   * if (halfWidth <= 0) {
   *   halfWidth = 1;
   * } */

  /* uncertainty width via count of all distinct points */
  b = (double) size;
  c = max(log(b)/log(2.0),size/(1+nc));
  /* c = log(b)/log(2.0); obsolete, replaced Nov 12, 2009 */
  c /= 2.0;
  halfDistinctWidth = c;
  if (halfDistinctWidth < 1) {
    halfDistinctWidth = 1;
  }

  /* small data or SET case: interval = [c,c] where c = cut value */
  if ((size <= maxc) || (range == SET)) {
    for (j=1; j<=nc;j++) {
      cut[j].leftUncertainValue = cut[j].cutValue;
      cut[j].rightUncertainValue = cut[j].cutValue;
    }
    return;
  }

  /* all other cases */
  for (j=1; j<=nc; j++) {
    /* left uncertainty value for cut[j] */
    cut[j].leftUncertainValue = cut[j].cutValue;
    /* leftPoints = 0; old rule, not used */
    leftDistinctPoints = 0;
    for (i=cut[j].leftIndex; i>=MIN_ENDFREQUENCY+1; i--) {
      /* leftPoints += freq[i];  old rule, not used */
      leftDistinctPoints++;
      /* if (number of distinct point to left of cut <= 
       *     halfDistinctWidth) 
       * then move left endpoint of uncertainty interval one step
       * to the left
       */	      
      if (leftDistinctPoints <= halfDistinctWidth) {
      /* if (leftPoints <= halfWidth) {  old rule, not used */
        cut[j].leftUncertainValue = (a[i-1]+a[i])/2.0;
      } else {
        break;
      }
    }
    /* right uncertainty value for cut[j] */
    /* rightPoints = 0; old rule, not used */
    rightDistinctPoints = 0;
    cut[j].rightUncertainValue = cut[j].cutValue;
    for (i=cut[j].leftIndex+1; i<=size-MIN_ENDFREQUENCY; i++) {
      /* rightPoints += freq[i]; old rule, not used */
      rightDistinctPoints++;
      /*  if (number of distinct point to right of cut <= 
       *       halfDistinctWidth)
       * then move right endpoint of uncertainty interval one step
       * to the right
       */	      
      if (rightDistinctPoints <= halfDistinctWidth) {
      /*  if (rightPoints <= halfWidth) { old rule, not used */
        cut[j].rightUncertainValue = (a[i]+a[i+1])/2.0;
      } else {
        break;
      }
    }
  } /* end for j */

} /* end defineUncertainty */
/*eject*/
/***************************************************************
 * extractTargetData(): extract target data from data of mst file
 ***************************************************************/
void extractTargetData() {

  int flag, j, m, n, nrec;

  int att2tgt[MAX_ATTRIBUTE];
  /* att2tgt[j] = 0: attribute j is not a target */
  /*            = k>0: attribute j is target k */
  /* data[][] and valueKnown[][] listed below replaced by */
  /* target.data[][] and target.valueKnown[][] Apr 27, 2015 */
  /*  float data[MAX_RECORD][MAX_ATTRIBUTE];  */
  /*  int valueKnown[MAX_RECORD][MAX_ATTRIBUTE]; */

  char control[MAX_ID];
  char fileRec[MAXLEN];
  char message[MAXLEN];
  char *buffer;

  FILE *mstfil;
  FILE *out;

  mstfil = openFilePrefix(gFileExt.mst,"r");
  out = openFileSubccdetail("targets.initialData","w");

  /* define gTarget[0] to be empty string */
  gTarget[0][0] = '\0';

  nrec = 0; /* record count of file */

  strcpy(control,"ATTRIBUTES");

  /* read ATTRIBUTES record */
  while (fgets(fileRec,MAXLEN,mstfil) != 0) { /* while #1 */
    nrec++;
    buffer = strtok(fileRec," \t\n");
    if (stringCompare(buffer,"ATTRIBUTES",10) == 0) {
      strcpy(control,"TARGET");
      break;
    }
  } /* end while #1 */
  if (strcmp(control,"ATTRIBUTES") == 0) {
    suberror("ATTRIBUTES record missing in mst file",
             "extractTargets","101");
  }
/*eject*/
  /* read attributes and retain target names */
  gNumAttributes = 0;
  gNumTargetVariables = 0;

  while (fgets(fileRec,MAXLEN,mstfil) != 0) { /* while #2 */
  nrec++;
    if ((fileRec[0] == '*')||
        (fileRec[0] == '\n')) { /* commented-out or blank line */
      continue;
    }
    buffer = strtok(fileRec," \t\n");
    if (strncmp(buffer,"DATA",4) == 0) {
      strcpy(control,"DATA");
      break;
    }

    gNumAttributes++;
    if (gNumAttributes >= MAX_ATTRIBUTE) {
      suberror("MAX_ATTRIBUTE is too small",
               "extractTargetData","251");
    }

    /* tentatively store target name */
    gNumTargetVariables++;
    strcpy(gTarget[gNumTargetVariables],buffer);

    /* skip over CLASS options */
    buffer = strtok(NULL," \t\n");
    if (buffer != NULL) {
      while (strncmp(buffer,"CLASS",5) == 0) {
        buffer = strtok(NULL," \t\n");
        if (buffer == NULL) {
          break;
        }
      }
    }

    /* decide if attribute is a target */

    if ((buffer == NULL) || 
        ((buffer != NULL) && (strncmp(buffer,"TARGET",6) != 0))){ 
      /* attribute is not a target */
      att2tgt[gNumAttributes] = 0;
      gNumTargetVariables--;
      continue;
    }
    /* attribute is a target */
    att2tgt[gNumAttributes] = gNumTargetVariables;
/*eject*/
    /* initialize max number of target cutpoints */
    gMaxTgtCuts[gNumTargetVariables] = MAX_TARGETCUT;

    /* check for parameters in buffer using '_' */
    flag = 0;

    for (j=strlen(buffer)-1; j>= 6; j--) {
      if (buffer[j] == '_') {
        /* j is position of rightmost underscore in buffer */
        if (j == strlen(buffer)-1) {
          sprintf(message,
       "Error: incorrect TARGET specification of attribute %s",
                  gTarget[gNumTargetVariables]);
          suberror(message,"extractTargetData","271");
        }
        flag++;
        if (flag == 1) {
        /* read max number of cutpoints */
          gMaxTgtCuts[gNumTargetVariables] = (int) atoi(&buffer[j+1]);
          if (gMaxTgtCuts[gNumTargetVariables] < 3 || 
              gMaxTgtCuts[gNumTargetVariables] > MAX_CUT) {
            sprintf(message,
            "Error: max number of cutpoints = %d for target attribute %s is outside allowed range [3,%d]",
                    gMaxTgtCuts[gNumTargetVariables], 
                    gTarget[gNumTargetVariables],
                    MAX_CUT);
            suberror(message,"extractTargetData","272");
          }
        } else if (flag == 2) {
          /* read high index */
          gHighTgtCuts[gNumTargetVariables] = (int) atoi(&buffer[j+1]);
          if ((gHighTgtCuts[gNumTargetVariables] <= 0) || 
              (gHighTgtCuts[gNumTargetVariables] > 
                gMaxTgtCuts[gNumTargetVariables])) {
            sprintf(message,
            "Error: high index of cutpoints = %d for target attribute %s is outside allowed range [1,%d]",
                    gHighTgtCuts[gNumTargetVariables], 
                    gTarget[gNumTargetVariables],
                    gMaxTgtCuts[gNumTargetVariables]);
            suberror(message,"extractTargetData","273");           
          }
        } else if (flag == 3) {
          /* read low index */
          gLowTgtCuts[gNumTargetVariables] = (int) atoi(&buffer[j+1]);
          if ((gLowTgtCuts[gNumTargetVariables] <= 0) || 
              (gLowTgtCuts[gNumTargetVariables] > 
                gHighTgtCuts[gNumTargetVariables])) {
            sprintf(message,
            "Error: low index of cutpoints = %d for target attribute %s is outside allowed range [1,%d]",
                    gLowTgtCuts[gNumTargetVariables], 
                    gTarget[gNumTargetVariables],
                    gHighTgtCuts[gNumTargetVariables]);
            suberror(message,"extractTargetData","274");           
          }
        } else {
            sprintf(message,
            "Error: too many parameters for target attribute %s",
                    gTarget[gNumTargetVariables]);
            suberror(message,"extractTargetData","282");
        }
        /* replace underscore by end-of-string */
        buffer[j] = '\0';      
      } /* end if buffer[j] == '_' */
    } /* end for j */

    /* use default values for low and high if not specified */
    if (flag <= 1) {
      gLowTgtCuts[gNumTargetVariables] = 1;
      gHighTgtCuts[gNumTargetVariables] = 
                 gMaxTgtCuts[gNumTargetVariables];   
    }

    /* error check that flag can only be = 0, 1, 3 */
    if ((flag!=0) && (flag!=1) && (flag!=3)) {
      sprintf(message,
        "Error: can only have 0, 1, or 3 parameters for attribute %s",
        gTarget[gNumTargetVariables]);
      suberror(message,"extractTargetData","283");           
    }  
    /* error check that flag == 3 occurs with TARGETCASES, */
    /* TARGETINTERVAL, or TARGETSET */
    if ((flag != 3) && ((strcmp(buffer,"TARGETCASES") == 0) ||
                        (strcmp(buffer,"TARGETINTERVAL") == 0) ||
                        (strcmp(buffer,"TARGETSET") == 0))) {
      sprintf(message,
      "Error: must provide three target parameters for attribute %s with specified TARGETCASES, TARGETINTERVAL, or TARGETSET option",
             gTarget[gNumTargetVariables]);
      suberror(message,"extractTargetData","284");           
    }
/*eject*/
    if (strcmp(buffer,"TARGETCASES") == 0) {
      /* CASES case */
      gTgtRange[gNumTargetVariables] = CASES;
    } else if (strcmp(buffer,"TARGETINTERVAL") == 0) {
      /* INTERVAL case */
      gTgtRange[gNumTargetVariables] = INTERVAL;
    } else if (strcmp(buffer,"TARGETSET") == 0) {    
      /* SET case */
      gTgtRange[gNumTargetVariables] = SET;
    /* OBSOLETE cases: replaced Sept 2009 */   
    } else if (strcmp(buffer,"TARGET") == 0) { 
      /* ALL case */
      gTgtRange[gNumTargetVariables] = ALL;
    } else if ((strcmp(buffer,"TARGETLO") == 0) ||
               (strcmp(buffer,"TARGETLOW") == 0)) { 
      /* LOW case */
      gTgtRange[gNumTargetVariables] = LOW;
      gHighTgtCuts[gNumTargetVariables] = 
         0.50*((float)gMaxTgtCuts[gNumTargetVariables]) + 0.5;
    } else if ((strcmp(buffer,"TARGETVLO") == 0) ||
               (strcmp(buffer,"TARGETVERYLOW") == 0)) { 
      /* VERYLOW case */
      gTgtRange[gNumTargetVariables] = VERYLOW;
      gHighTgtCuts[gNumTargetVariables] = 
         0.20*((float)gMaxTgtCuts[gNumTargetVariables]) + 0.5;
    } else if ((strcmp(buffer,"TARGETHI") == 0) ||
               (strcmp(buffer,"TARGETHIGH") == 0)) {
      /* HIGH case */
      gTgtRange[gNumTargetVariables] = HIGH;
      gLowTgtCuts[gNumTargetVariables] = 
         0.50*((float)gMaxTgtCuts[gNumTargetVariables]);
    } else if ((strcmp(buffer,"TARGETVHI") == 0) ||
               (strcmp(buffer,"TARGETVERYHIGH") == 0)) 
               {
      /* VERYHIGH case */
      gTgtRange[gNumTargetVariables] = VERYHIGH;
      gLowTgtCuts[gNumTargetVariables] = 
         0.80*((float)gMaxTgtCuts[gNumTargetVariables]);
    } else if ((strcmp(buffer,"TARGETLOHI") == 0) ||
               (strcmp(buffer,"TARGETLOWHIGH") == 0)) {
      /* LOWHIGH case */
      gTgtRange[gNumTargetVariables] = LOWHIGH;
    } else {
      /* error */
      sprintf(message,
        "Unknown TARGET option %s for attribute %s",
        buffer, gTarget[gNumTargetVariables]);
      suberror(message,"extractTargetData","291");
    }

  } /* end while #2 */
/*eject*/
  if (strcmp(control,"DATA") != 0) {
    suberror("DATA record missing in mst file",
             "extractTargets","301");
  }

  /* check if at least one target specified */
  if (gNumTargetVariables == 0) {
    suberror("No attribute has TARGET option specified in mst file",
             "extractTargets","401");    
  }

  /* read data records and retain target information */
  gNumRecords = 0;

  while (fgets(fileRec,MAXLEN,mstfil) != 0) { /* while #3 */
  nrec++;
    if ((fileRec[0] == '*')||
        (fileRec[0] == '\n')) { /* commented-out or blank line */
      continue;
    }
    gNumRecords++;
    if (gNumRecords >= MAX_RECORD) {
      suberror("MAX_RECORD is too small",
               "extractTargetData","431");
    }

    for (j=1; j<=gNumAttributes; j++) {

      if (j == 1) { /* if j == 1 */
        buffer = strtok(fileRec," \t\n");
        if (stringCompare(buffer,"ENDATA",6) == 0) {
          gNumRecords--;
          strcpy(control,"ENDATA");
          goto zz100;
        }
        if (buffer == NULL ) {
          sprintf(message,
                  "Record number %d is blank in %s file\nStop\n",
                  nrec, gFileExt.mst);
          suberror(message,"extractTargets","451"); 
        }
        if (buffer[0] == '*') { /* record commented out */
          gNumRecords--;
          break;
        }
        if (gNumRecords >= MAX_RECORD) {
          suberror("MAX_RECORD is too small",
                   "extractTargets","461");
        }
      } else { /* end if j == 1, begin else */
        buffer = strtok(NULL," \t\n");
        if (buffer == NULL) { /* unexpected early end of record */
          sprintf(message,
           "Record number %d has only %d entries in %s file\nStop\n",
           nrec,j-1, gFileExt.mst);
          suberror(message,"extractTargets","501");  
        }
      } /* end else */

      /* if this is a target case, store value */
      if (att2tgt[j] > 0) {
        if (strcmp(buffer,"?") != 0) { /* value is known */
          target.valueKnown[gNumRecords][att2tgt[j]] = TRUE; 
          target.data[gNumRecords][att2tgt[j]] = (float) atof(buffer);
        } else { /* value is not known */
          target.valueKnown[gNumRecords][att2tgt[j]] = FALSE; 
          target.data[gNumRecords][att2tgt[j]] = 0.0;
        }
      }
   
    } /* end for j */
  
  } /* end while #3 */
/*eject*/
 zz100:;

  /* output target data to file targets.initialData */
  for (j=1; j<=gNumTargetVariables; j++) { /* begin j */

    /* determine number of values for target j */
    m = 0;
    for (n=1; n<=gNumRecords; n++) {
      if (target.valueKnown[n][j] == TRUE) {
        m++;
      }
    }

    if (m == 0) {
      if (gShowTargetSteps == TRUE) {
        printf(
               "Warning: Attribute %s has only unknown values\n",
               gTarget[j]);
        printf(
               "in %s input file\n\n",gFileExt.mst);
      }
      fprintf(errfil,
              "Warning: Attribute %s has only unknown values\n",
              gTarget[j]);
      fprintf(errfil,
              "in %s input file\n\n",gFileExt.mst);
      continue;
    }

    fprintf(out,"%s\t%d\t%d\t%d\t%d\t%d\t",gTarget[j],gTgtRange[j],
            gMaxTgtCuts[j],gLowTgtCuts[j],gHighTgtCuts[j],m);

    for (n=1; n<=gNumRecords; n++) {
      if (target.valueKnown[n][j] == TRUE) {
        fprintf(out,"%f\t",target.data[n][j]);
      }
    }
    fprintf(out,"\n");

  } /* end for j */

  fprintf(out,"ENDATA");

  closeFile(mstfil);
  closeFile(out);

  return; 

} /* end of extractTargetData */
/*eject*/
/***************************************************************
 * makeCutpoints(double *a, int size, Cutdata *cut, int *nct, 
 *               int maxc):
 *   input:  a[] array
 *           size number of a[] entries
 *           maxc max number of cutpoints
 *   output: cut[].cutValue values of cutpoints
 *           cut[].leftIndex left index of a[] preceding cutpoint
 *           *nct number of cutpoints
 ***************************************************************/
void makeCutpoints(double *a, int size, CutData *cut, int *nct,
                   int maxc) {

  int i, nc;
  int gp, group[MAX_RECORD];
  double b, delta = 0.0; /* to suppress compiler warning */ 

  /* small targetData case */

  if (size <= maxc) {

    for (i=1; i<=size-1; i++) {
      cut[i].cutValue = (a[i] + a[i+1])/2.0;
      cut[i].leftIndex = i;
    }
    *nct = size-1;

    return;
  }

  /* have >= maxc + 1 a[i] values */
  for (i=1; i<=size-1; i++) {
    b = (double) maxc * (double) i / (double)  size; 
    group[i] = (int) b;
  }

  /* for each set of indices with same group value,
   * place a cutpoint between a[i] and a[i+1] where
   * the gap a[i+1]-a[i] is maximum
   */

  nc = 0;
  gp = -1;

  for (i=1; i<=size-1; i++) {
    if (gp != group[i]) {
      nc++;
      cut[nc].cutValue = (a[i] + a[i+1])/2.0;
      cut[nc].leftIndex = i;
      delta = a[i+1] - a[i];
      gp = group[i];
    } else {
      if (a[i+1]-a[i] > delta) {
        delta = a[i+1]-a[i];
        cut[nc].cutValue = (a[i]+a[i+1])/2.0;
        cut[nc].leftIndex = i;
      } else if ((a[i+1]-a[i] == delta) &&
                     (group[i] == 0)) {
        cut[nc].leftIndex = i;
      }
    }     
  } /* end for i */

  if (nc > maxc) {
    suberror("error, nc > maxc should not occur",
             "makeCutpoints","101");
  }

  *nct = nc;

  return;

} /* end makeCutpoints */
/*eject*/
/***************************************************************
 * outputTargetCases(FILE *out, char *name, CutData *cut, 
 *                   int nc, int initc):
 *  output the target information to tgt file
 ***************************************************************/
void outputTargetCases(FILE *out, char *name, int range, 
                       CutData *cut, int nc, int initc) {

  int j, k, m;
  char percent[2];

  strcpy(percent,"%");

  /* targets defined by one interval */
  for (j=1; j<=nc; j++) {
    fprintf(out,"%s 1 [ %f , %f ]  * %d %s\n",name,
             (float) cut[j].leftUncertainValue,
             (float) cut[j].rightUncertainValue,
             (100*j)/initc,percent);     
  }

  /* targets defined by two intervals: options INTERVAL and SET */
  /* INTERVAL case: define all possible pairs */
  if (range == INTERVAL) {
    m = 0;
    for (j=1; j<=nc-1; j++) {
      for (k=j+1; k<=nc; k++) {
        if (cut[j].rightUncertainValue < 
            cut[k].leftUncertainValue) {
          fprintf(out,"%s 2 [ %f , %f ] [ %f , %f ]  * %d %s\n",
                 name,
                 (float) cut[j].leftUncertainValue,
                 (float) cut[j].rightUncertainValue,
                 (float) cut[k].leftUncertainValue,
                 (float) cut[k].rightUncertainValue,
                 (100*j)/initc,percent);       
        }
      }
    }
  /* SET case: create pairs bracketing one value */
  } else if (range == SET) {
    for (j=1; j<=nc-1; j++) {
      fprintf(out,"%s 2 [ %f , %f ] [ %f , %f ]  * %d %s\n",name,
             (float) cut[j].leftUncertainValue,
             (float) cut[j].rightUncertainValue,
             (float) cut[j+1].leftUncertainValue,
             (float) cut[j+1].rightUncertainValue,
             (100*j)/initc,percent); 
    }
  }

  return;

} /* end outputTargetCases */
/*eject*/
/***************************************************************
 * processTargets(): process targets using data of
 *   targets.initialData  file
 ***************************************************************/
void processTargets() {

  char fileRec[MAX_RECORD_ASCII];
  char *buffer;
  int  i;

  char targetName[MAX_ID]; /* name of target attribute */
  int  targetRange;        /* target range                 
                            * = CASES    counts: low,high,max
                            * = INTERVAL counts: low,high,max
                            * = SET      counts: low,high,max
                            *
                            * OBSOLETE options, replaced Sep 2009: 
                            *
                            * = ALL  all cutpoints
                            * = LOW  low cutpoints
                            * = VERYLOW 20% smallest cutpoints
                            *   of all cutpoints
                            * = HIGH high cutpoints
                            * = VERYHIGH 20% highest cutpoints
                            *   of all cutpoints
                            * = LOWHIGH all cutpoints plus
                            *   cutpoint pairs for lowhigh
                            *   versus middle
                            */   
  int  targetDataSize;     /* number of target values */
  double targetData[MAX_RECORD]; /* array holding target values */
  int totalCount;          /* total number of target values
                            *   initially, targetDataSize =
                            *   totalCount; but once multiples
                            *   of the same value have been
                            *   removed, then the two numbers
                            *   differ 
                            */

  int frequency[MAX_RECORD]; /* frequency[i] = frequency of
                              * value targetData[i] in the
                              * original target data
                              */
  /* cutpoint and uncertainty interval data */
  CutData cut[MAX_CUT+1];
  int initNumTargetCuts, numTargetCuts;
  int maxTargetCuts, lowTargetCuts, highTargetCuts;

  FILE *inpfil;
  FILE *tgtfil;

  /* open targets.initialData file */
  inpfil = openFileSubccdetail("targets.initialData","r");

  /* open target file tgt */
  tgtfil = openFilePrefix(gFileExt.tgt,"w");

  fprintf(tgtfil,"TARGETS\n");

  while (fgets(fileRec,MAX_RECORD_ASCII,inpfil) != 0) {/* while #1 */

    /* target name or ENDATA */
    buffer = strtok(fileRec," \t\n");
    if (buffer == NULL ) {
      suberror("Unexpected end of record",
               "processTargets","101");
    }
    if (stringCompare(buffer,"ENDATA",6) == 0) {
      break;
    }
    strcpy(targetName,buffer);

    /* target range */
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL ) {
      suberror("Unexpected end of record",
               "processTargets","102");
    }
    targetRange = (int) atoi(buffer);

    /* max target cuts */
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL ) {
      suberror("Unexpected end of record",
               "processTargets","103");
    }
    maxTargetCuts = (int) atoi(buffer);

    /* low index of cutpoints */
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL ) {
      suberror("Unexpected end of record",
               "processTargets","104");
    }
    lowTargetCuts = (int) atoi(buffer);

    /* high index of cutpoints */
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL ) {
      suberror("Unexpected end of record",
               "processTargets","105");
    }
    highTargetCuts = (int) atoi(buffer);

    /* number of data points for target */
    buffer = strtok(NULL," \t\n");
    if (buffer == NULL ) {
      suberror("Unexpected end of record",
               "processTargets","106");
    }
    targetDataSize = (int) atoi(buffer);
    /* must have >= 6 values for cuts to exist */
    if (targetDataSize <= 5) {
      /* skip this case */
      continue;
    }

    totalCount = targetDataSize;

    /* target data */
    for (i=1; i<=targetDataSize; i++) {
      buffer = strtok(NULL," \t\n");
      if (buffer == NULL ) {
        suberror("Unexpected end of record",
                 "processTargets","107");
      }
      targetData[i] = (double) atof(buffer);
    }
/*eject*/
    /* sort data */
    bubbleSort(targetData,targetDataSize);

    /* reduce data to unique values */
    reduceMultipleEntries(targetData, frequency,
                          &targetDataSize);
    /* must have >= 2 distinct target values for cuts to exist */
    if (targetDataSize <= 1) {
      /* skip this case */
      continue;
    }

    /* make cutpoints */
    makeCutpoints(targetData, targetDataSize, cut, &numTargetCuts,
                  maxTargetCuts);
    /* must have >= 1 cuts */
    if (numTargetCuts <= 0) {
      /* skip this case */
      continue;
    }

    /* save numTargetCuts as initNumTargetCuts */
    initNumTargetCuts = numTargetCuts;

    /* reduce cutpoints by eliminating cutpoints too close to */
    /* lowest or highest target value */
    /* select cutpoints according to specified target option */
    reduceCutpoints(frequency, targetDataSize, targetRange,
                    cut, &numTargetCuts, 
                    lowTargetCuts, highTargetCuts);
    /* must have >= 1 cuts */
    if (numTargetCuts <= 0) {
      /* skip this case */
      continue;
    }

    /* define uncertainty intervals from cutpoints */
    defineUncertainty(targetData, frequency, targetDataSize, 
                      totalCount, targetRange, cut, numTargetCuts,
                      maxTargetCuts);

    /* output target cases */
    outputTargetCases(tgtfil, targetName, targetRange, cut,
                      numTargetCuts, initNumTargetCuts);
                  
  } /* end while #1 */

  fprintf(tgtfil,"ENDATA");

  closeFile(inpfil);
  closeFile(tgtfil);

  return;    

}/* end of processTargets */
/*eject*/
/***************************************************************
 * reduceCutpoints(*freq, int size, int range
 *                 Cutdata *cut, int *nct, int lowct, int highct):
 *     reduce cutpoints by eliminating cutpoints too close to
 *     lowest or highest target value
 *     select cutpoints according to specified target option
 *   input:  freq[] frequencies of a[] array
 *           size number of values in a[] array
 *           cut[].cutValue value of cutpoint
 *           cut[].leftIndex index of a[] to left of cutpoint
 *           *nct number of cutpoints
 *   output: reduced cutpoint list so that 
 *           (1) cutpoints too close to lowest or highest a[] values
 *               have been eliminated
 *           (2) cutpoints correspond to specified target
 *               option 
 ***************************************************************/
void reduceCutpoints(int *freq, int size, int range, 
                     CutData *cut, int *nct, int lowct, int highct) {

  int count, i, j, nc;

  nc = *nct;

  /* cuts near lowest value */
  count = 0;
  for (i=1; i<=size; i++) {
    count += freq[i];
    if (count < MIN_ENDFREQUENCY) {
      if (cut[1].leftIndex == i) {
        /* eliminate first cut */
        for (j=1; j<= nc-1; j++) {
          cut[j].cutValue = cut[j+1].cutValue;
          cut[j].leftIndex = cut[j+1].leftIndex;
        }
        nc--;
      }
    } else {
      break;
    }
  }

/* cuts near highest value */
  count = 0;
  for (i=size; i>=1; i--) {
    count += freq[i];
    if (count < MIN_ENDFREQUENCY) {
      if (cut[nc].leftIndex == i-1) {
        /* eliminate last cut */
        nc--;
      }
    } else {
      break;
    }
  }

  /* error check */
  if (nc < *nct - 2*(MIN_ENDFREQUENCY-1)) {
    /* error, reduction may eliminate at most */
    /* 2*(MIN_ENDFREQUENCY-1) cutpoints */
    suberror(
      "error, nc < *nct - 2*(MIN_ENDFREQUENCY-1) should not occur",
      "reduceCutpoints","101");
  }

  /* keep cutpoints according to lowct, highct */
  if (highct > nc) {
    highct = nc;
  }
  if (lowct > nc) {
    lowct = nc;
  }
  if (lowct == 1) {
    nc = highct;
  } else {
    /* shift cutpoints */
    nc = highct - lowct +1;
    for (j=1; j<=nc; j++) {
        cut[j].cutValue = cut[j+lowct-1].cutValue;
        cut[j].leftIndex= cut[j+lowct-1].leftIndex;
    } 
  }

  *nct = nc;

  return;

} /* end reduceCutpoints */
/*eject*/
/***************************************************************
 * reduceMultipleEntries(double *a, int *freq, int *nt):
 *   reduce multiple entries in a[] array and record multiple
 *   occurrences in freq[] array. Reduce *nt to number
 *   of distinct data values.
 *   input: a[] array 
 *          *nt = number of entries in a[]
 ***************************************************************/
void reduceMultipleEntries(double *a, int *freq, int *nt) {
 
  int i, nred, n;

  n = *nt;

  if (n <= 1) {
    return;
  }

  freq[1] = 1;
  nred = 1;

  for (i=2; i<=n; i++) {
    if (a[i] == a[i-1] ) {
      freq[nred]++;
    } else {
      nred++;
      freq[nred] = 1;
      a[nred] = a[i];
    }
  }

  /*DEBUG Begin*/ 
  /* printf("\n****************************\n");
  printf("\nTotal number of targets  = %d\n",n);
  printf("\nNumber of unique targets = %d\n",nred); */
  /*DEBUG End*/ 

  *nt = nred;
  return;

} /* end reduceMultipleEntries */

/* last record of createTargets.c*******/ 
