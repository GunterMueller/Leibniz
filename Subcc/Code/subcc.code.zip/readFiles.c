/* first record of readFiles.c *****/
#include "subcc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   void getCutListSorted(int tgt, int pstage)
 *   void getFormulas(int tgt, int stage)
 *   void getListRules(int tgt, int stage, char *tgtname)
 *   void loadTargetFile()
 *   void lowerCase(char *ch)
 *   int  parse_param(char *lhs, char *rhs, char *record, 
 *                   FILE *params)
 *   void readTargetLine(char fileRec[])
 *   void readParamsFile()
 *   void shiftLeft(char fileRec[])  
 */  
/*eject*/
/******************************************************
 * getCutListSorted(int tgt, int stage):
 *  read cut file of 40partial stage to get
 *   list[].name      attribute name
 *   list[].type      attribute type
 *   sorted[].type    attribute type
 *   sorted[].factor  expansion factor
 * define list2sorted[] and sorted2list
 ******************************************************/
void getCutListSorted(int tgt, int stage) {

  int flag, flag2, i, j;

  char fileRec[MAXLEN];
  char name[MAXLEN];
  char *buffer;

  FILE *cutfil;

  /* initialize sorted[i].type   = empty string */
  /*                     .factor = -1.0         */
  for (i=1; i<=numSorted; i++) {
    strcpy(sorted[i].type,"");
    sorted[i].factor = -1.0;
  } 

  /* open cut file */
  sprintf(name,"%d.%d.%s.40partial%s",
          tgt,stage,gTarget[tgt],gFileExt.cut);
  cutfil = openFileSubccdetail(name,"r");

  /* read up to '*attribute type count' record */
  flag = 0;
  while(fgets(fileRec,MAXLEN,cutfil) != 0) { /* while #1 */
    if (strncmp(fileRec,"*attribute type count",21) == 0) {
      flag = 1;
      break;
    }
  } /* end while #1 */
  if (flag == 0) {
    suberror("Missing '*attribute type count' in cut file",
             "getCutListSorted","101");
  }

  /* process name and type of attributes */
  numList = 0;
  flag = 0;
  while(fgets(fileRec,MAXLEN,cutfil) != 0) { /* while #2 */
    if (strncmp(fileRec,"ENDATA",6) == 0) {
      flag = 1;
      break;
    }

    /* process attribute */
    numList++;
    buffer = strtok(fileRec," \t");
    strcpy(list[numList].name,buffer);
    buffer = strtok(NULL," \t\n");
    strcpy(list[numList].type,buffer);

    /* search for attribute in sorted[].name */
    flag2 = 0;
    for (i=1; i<=numSorted; i++) {
      if (strcmp(list[numList].name,sorted[i].name) == 0) {
        list2sorted[numList] = i;
        sorted2list[i] = numList;
        strcpy(sorted[i].type,list[numList].type);
        flag2 = 1; 
        break;
      }      
    }
    if (flag2 == 0) { /* attribute is not in sorted[].name */
      list2sorted[numList] = 0;
    }    
  } /* end while #2 */
  if (flag == 0) {
    suberror("Missing ENDATA record in cut file",
             "getCutListSorted","201");
  }

/*eject*/ 
  /* read cut file up to SCALING FACTORS section */
  flag = 0;
  while(fgets(fileRec,MAXLEN,cutfil) != 0) { /* while #3 */
    if (strncmp(fileRec,"SCALING FACTORS",15) == 0) {
      flag = 1;
      break;
    }
  } /* end while #3 */
  if (flag == 0) {
    suberror("Missing SCALING FACTORS record in cut file",
             "getCutListSorted","301");
  }

  /* get scaling factors from cut file */
  for (j=1; j<=numList; j++) {
    if (fgets(fileRec,MAXLEN,cutfil) == 0) { 
      suberror("Unexpected end of cut file",
               "getCutListSorted","401");      
    }
    i = list2sorted[j];
    if (i >= 1) {
      if (strcmp(sorted[i].type,"SET") != 0) {
        buffer = strtok(fileRec," \t\n");
        /* buffer has attribute name, skip */
        buffer = strtok(NULL," \t\n");
        if (atof(buffer) == 0) {
          suberror("Conversion error","getCutListSorted","451");
        }
        sorted[i].factor = (double) atof(buffer);
      }
    }
  }
/*eject*/
  closeFile(cutfil);
  
/* consistency check of scaling factors */
  for (i=1; i<= numSorted; i++) {
    if ((strcmp(sorted[i].type,"SET") != 0) &&
        (sorted[i].factor <= 0.0)) {
      suberror("Inconsistent scaling factors",
               "getCutListSorted","501");  
    }
  }

  return;

} /* end getCutListSorted */
/*eject*/
/******************************************************
 * getFormulas(int tgt, int stage):
 * get from sep file of target tgt and stage:
 *     Aformula and Bformula
 *        .numClause
 *        .clause[][]
 *     numVariable
 *     variable[]
 ******************************************************/
void getFormulas(int tgt, int stage) {

  int i, j, k;

  char *buffer;
  char name [MAX_ID];
  char AformulaLabel[MAX_ID];
  char BformulaLabel[MAX_ID];

  char fileRec[MAXLEN];

  FILE *sepfil;

  /* initialize AformulaLabel and BformulaLabel */
  if (gParams.defSizeSubgroup == DEFMAX) {
    strcpy(AformulaLabel,"Formula 4");
    strcpy(BformulaLabel,"Formula 2");
  } else if (gParams.defSizeSubgroup == DEFMIN) {
    strcpy(AformulaLabel,"Formula 3");
    strcpy(BformulaLabel,"Formula 1");
  } else {
    suberror("Error of defSizeSubgroup value",
             "getFormulas","51");
  }

  /* open sep file */
  sprintf(name,"%d.%d.%s.4total%s",
          tgt, stage, gTarget[tgt],gFileExt.sep);
  sepfil = openFileSubccdetail(name,"r");

  /* process "4 formulas with ..." */
  fgets(fileRec,MAXLEN,sepfil);
  sscanf(fileRec,"4 formulas with %d",&numVariable);

  if (numVariable >= MAX_ATTRIBUTE) {
    suberror("MAX_ATTRIBUTE is too small",
             "getClauses","91");
  }

  /* advance to "Variables" */
  while (fgets(fileRec,MAXLEN,sepfil) != 0) {;
    if  (strncmp(fileRec,"Variables",9) == 0) {
      break;
    }
  }

  /* get names of variables */
  for (i=1; i<=numVariable; i++) {
    fgets(fileRec,MAXLEN,sepfil);
    sscanf(fileRec,"%s",variable[i]);
  }

  /* advance to "Formula k B", k = 1 or 2 */
  while (fgets(fileRec,MAXLEN,sepfil) != 0) {;
    if  (strncmp(fileRec,BformulaLabel,9) == 0) {
      sscanf(fileRec,"Formula %d B %d",&k,&Bformula.numClause);
      break;
    }
  }

  /* skip over "clause" */
  fgets(fileRec,MAXLEN,sepfil);
  if (strncmp(fileRec,"clause",6) != 0) {
    suberror("'clause' record missing in sep fil",
             "getClauses","103");
  }

  /* the clause indices may run over a number of lines 
   * use strtok to process the lines until entire clause
   * is read
   */
  for (i=1; i<=Bformula.numClause; i++) {
    /* read first line of clause */
    fgets(fileRec,MAXLEN,sepfil);
    buffer =strtok(fileRec," \t\n"); /* clause number, skip this */
    buffer =strtok(NULL," \t\n");/* number of literals in clause i */
    sscanf(buffer,"%d",&Bformula.clause[i][0]);
    if (Bformula.clause[i][0] >= MAX_ATTRIBUTE) {
      suberror("MAX_ATTRIBUTE is too small",
                 "getClauses","95");
    }
    for (j=1; j<=Bformula.clause[i][0]; j++) {
      buffer =strtok(NULL," \t\n");
      if (buffer == NULL) { /* end of line, read another line */
        fgets(fileRec,MAXLEN,sepfil);
        buffer =strtok(fileRec," \t\n");
      }
      Bformula.clause[i][j] = (int) atoi(buffer);
    }
    /* check that entire line has been processed */
    buffer = strtok(NULL," \t\n");
    if (buffer != NULL) {
      suberror(
       "Clause i has > Bformula.clause[i][0] literals",
       "getClauses","109");
    }
  }

  /* advance to "Formula k A", k = 3 or 4 */
  while (fgets(fileRec,MAXLEN,sepfil) != 0) {;
    if  (strncmp(fileRec,AformulaLabel,9) == 0) {
      sscanf(fileRec,"Formula %d A %d",&k,&Aformula.numClause);
      break;
    }
  }

  /* skip over "clause" */
  fgets(fileRec,MAXLEN,sepfil);
  if (strncmp(fileRec,"clause",6) != 0) {
    suberror("'clause' record missing in sep file",
             "getClauses","203");
  }

  /* the clause indices may run over a number of lines 
   * use strtok to process the lines until entire clause
   * is read
   */
  for (i=1; i<=Aformula.numClause; i++) {
    /* read first line of clause */
    fgets(fileRec,MAXLEN,sepfil);
    buffer =strtok(fileRec," \t\n"); /* clause number, skip this */
    buffer =strtok(NULL," \t\n");/* number of literals in clause i */
    sscanf(buffer,"%d",&Aformula.clause[i][0]);
    if (Aformula.clause[i][0] >= MAX_ATTRIBUTE) {
      suberror("MAX_ATTRIBUTE is too small",
                 "getClauses","97");
    }
    for (j=1; j<=Aformula.clause[i][0]; j++) {
      buffer =strtok(NULL," \t\n");
      if (buffer == NULL) { /* end of line, read another line */
        fgets(fileRec,MAXLEN,sepfil);
        buffer =strtok(fileRec," \t\n");
      }
      Aformula.clause[i][j] = (int) atoi(buffer);
    }
    /* check that entire line has been processed */
    buffer = strtok(NULL," \t\n");
    if (buffer != NULL) {
      suberror(
        "Clause i has > Aformula.clause[i][0] literals",
        "getClauses","209");
    }        
  }

  closeFile(sepfil);

} /* end of getFormulas */
/*eject*/
/***************************************************************
 * getListRules(int tgt, inst stage, char *tgtname): 
 * get rules of file <tgt>.<stage>.<tgtname>.rul file
 * and place the rules into list[] structure
 ***************************************************************/
void getListRules(int tgt, int stage, char *target) {

  char name[MAXLEN];
  char fileRec[MAXLEN];

  FILE *rulfil;

  sprintf(name,"%d.%d.%s%s", tgt, stage, target,gFileExt.rul);
  rulfil = openFileSubccdetail(name,"r");

  if (fgets(fileRec,MAXLEN,rulfil) == 0) {
    suberror("Unexpected end of rul file",
             "getListRules","101");
  }
  if (strncmp(fileRec,"RULES",5) != 0) {
    suberror("Missing RULES record in rul file",
             "getListRules","101");
  }

  numList = 0;
  while(fgets(fileRec,MAXLEN,rulfil) != 0) { /* while */
    if (strncmp(fileRec,"ENDATA",6) == 0) {
      closeFile(rulfil);
      return;
    }

    numList++;
    sscanf(fileRec,"%s%s%d%d%lf%d%lf",
            list[numList].name,
            list[numList].type,
           &list[numList].numTerm,
           &list[numList].index[1],
           &list[numList].coefficient[1],
           &list[numList].index[2],
           &list[numList].coefficient[2]);
  } /* end while*/
    suberror("Missing ENDATA record in rul file",
             "getListRules","201");

} /* end getListRules */
/*eject*/
/*************************************************************
* Read target file
**************************************************************/
void loadTargetFile()
{
	FILE *tgtfil; 
	char fileRec[MAXLEN] = {'\0'};
	int endataCheckFlag = 0;
	int tgt = 0;
	
	tgtfil = openFilePrefix(gFileExt.tgt, "r");
        gNumTargets = 0;
	
	/* Loop at file of input records */
    while (fgets(fileRec, MAXLEN, tgtfil) != NULL) {
		
	/* Shift the line left (remove whitespace at beginning) */
	shiftLeft(fileRec);

	if ((stringCompare(fileRec, "TARGETS", 7) == 0) ||
            (strncmp(fileRec, "*", 1) == 0) ||
	    (strncmp(fileRec, "\n", 1) == 0) ||
	    (strncmp(fileRec, "\r", 1)	== 0))
	{
	  continue;
	}
	else if (stringCompare(fileRec, "ENDATA", 6) == 0 ||
		 stringCompare(fileRec, "ENDDATA", 7) == 0) {
	   endataCheckFlag = TRUE;
	   break;
	}
	else 
	{
	   /* Read in the tgt line */
	  readTargetLine(fileRec,&tgt);
	}

    }

      if (!endataCheckFlag) {
	suberror("Missing ENDATA record in tgt file",
		 "loadTargetFile","101");
		
    }
		
      closeFile(tgtfil);

}
/*eject*/
/**************************************************************/
void lowerCase(char *ch)
{
	if (*ch >= 65 && *ch <= 90)
		*ch += 32;
}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  parse_param(): parse parameters
* --------------------------------------------------------
***************************************************************/
int parse_param(char *lhs, char *rhs, char *record, FILE *params) {
  char     str[128+1], ch;
  int      i, ix, l=0, r=0, nz;
  int      right = 0;
 
  if (feof(params)) {
    return(0);
  }
  fgets(str, 126, params);
  while (str[0] == '*') {
    if (feof(params)) {
      return(0);
    }
    fgets(str, 126, params);
  }  
/*
 *  change all string characters 
 *  with ascii code 1-31 or 127-254 by blanks
 */
  nz = strlen(str);
  for(i=0; i<=nz-1; i++)  {
    ix = (int)str[i];
    if (((ix>=1)&&
        (ix<=31))||
        ((ix>=127)&&
        (ix<=254))) {
      str[i] = ' ';
    }
  }
/*
 *  introduce carriage return character and,
 *  if necessary, new end of string character
 */
  if (str[nz-1] == ' ') {
    str[nz-1] = '\n';
  } else {
    str[nz] = '\n';
    str[nz+1] = '\0';
    nz++;
  }  
  
  strcpy(record, str);
  for (i = 0; i <= nz-1; i++) {
    ch = str[i];
    switch (ch) {
      case ' ':
                break;  
      case '=':
                right = 1;
                break;
      case '\n':
                break;
      default:
				if (right) {
				 rhs[r++] = ch;
               } else {
				 lowerCase(&ch);
                 lhs[l++] = ch;
               }
    }
  }
  lhs[l] = '\0';
  rhs[r] = '\0';  
  return(1);
}
/*eject*/
/**************************************************************
* readTargetLine(char fileRec[], int* tgtt): read one line
*   of tgt file
***************************************************************/
void readTargetLine(char fileRec[], int* tgtt) {
  char *buffer; 
  char message[MAXLEN];
  char nameHold[MAX_ID];
  int n;
  int tgt;

  tgt = *tgtt;

  /* Read in target name */
  buffer = strtok(fileRec, " \t\n");
  if (buffer == NULL) {
    suberror("Missing target name in tgt file",
             "readTargetLine","100");
  }
  strcpy(nameHold, buffer);

  if (tgt >= MAX_TARGET) {
    suberror("MAX_TARGET is too small",
             "readTargetLine","91");
  }

  strcpy(gTarget[++tgt], nameHold);
  gNumTargets++;
	
  /* Get the number of intervals for this target */
  buffer = strtok(NULL, " \t\n");
  if (buffer == NULL) {
    sprintf(message,
      "Number of target intervals missing in tgt file for target %s",
      gTarget[tgt]);
    suberror(message,"readTargetLine","103");
  }
  gTgtVersion[tgt] = atoi(buffer);

  if ((gTgtVersion[tgt] < 1) || (gTgtVersion[tgt] > 2)) {
    sprintf(message,
    "Incorrect number of intervals (= %d) in tgt file for target %s",
    gTgtVersion[tgt],gTarget[tgt]);
    suberror(message,"readTargetLine","104");	  
  }

  /* Read in the target intervals */
  for (n=1; n <= gTgtVersion[tgt]; n++){ /* n loop */     
	  
    /* low value of interval */
    buffer = strtok(NULL, " \t\n[,]");
    if (buffer == NULL) { 
      sprintf(message,
      "Uncertainty interval value missing in tgt file for target %s",
      gTarget[tgt]);
      suberror(message,"readTargetLine","201");
    }
    gUncertainTgtLow[tgt][n] = (float) atof(buffer);

    /* high value of interval */
    buffer = strtok(NULL, " \t\n[,]");
    if (buffer == NULL) { 
      sprintf(message,
      "Uncertainty interval value missing in tgt file for target %s",
      gTarget[tgt]);
      suberror(message,"readTargetLine","202");  
    }
    gUncertainTgtHigh[tgt][n] = (float) atof(buffer);

  }

  /* check values for consistency */
  if (gUncertainTgtLow[tgt][1] > gUncertainTgtHigh[tgt][1]) {
    sprintf(message,
    "Inconsistent values in tgt file for target %s, first interval",
    gTarget[tgt]);
    suberror(message,"readTargetLine","301");    
  }
  if (gTgtVersion[tgt] == 2) {
    if (gUncertainTgtLow[tgt][2] > gUncertainTgtHigh[tgt][2]) {
    sprintf(message,
    "Inconsistent values in tgt file for target %s, second interval",
    gTarget[tgt]);
    suberror(message,"readTargetLine","302"); 
    }
    if (gUncertainTgtHigh[tgt][1] > gUncertainTgtLow[tgt][2]) {
      sprintf(message,
           "Inconsistent 1st/2nd interval in tgt file for target %s",
           gTarget[tgt]);
      suberror(message,"readTargetLine","303");
    } 
  }

  *tgtt = tgt;
  return;

}
/*eject*/
/**************************************************************/
void readParamsFile()
{
  FILE *subccParams;
  char record[MAXLEN] = {'\0'};
  char lhs[MAXLEN], rhs[MAXLEN];
  char message[MAXLEN];
  int cv[20] = {FALSE};
  int beginReadFlag;

  char globalversion[5];
	
  subccParams = openFile(lsqccparamsname, "r");

  /* Set default values */
  strcpy(gFileExt.cut, ".cut");
  strcpy(gFileExt.mst, ".mst");
  strcpy(gFileExt.mstAB, ".mstAB");
  strcpy(gFileExt.rtr, ".rtr");
  strcpy(gFileExt.rts, ".rts");
  strcpy(gFileExt.rtsA, ".rtsA");
  strcpy(gFileExt.rtsB, ".rtsB");
  strcpy(gFileExt.rtsEqrtr, ".rtsEqrtr");
  strcpy(gFileExt.ats, ".ats");
  strcpy(gFileExt.sep, ".sep");
  strcpy(gFileExt.sub, ".sub");
  strcpy(gFileExt.tgt, ".tgt");
  strcpy(gFileExt.vot, ".vot");
  strcpy(gFileExt.votA, ".votA");
  strcpy(gFileExt.votB, ".votB");
  gSelectTargetFile = NEWTGT;
  gSelectTestFile = ALTERNATE;
  gShowSteps = FALSE;
  gShowTargetSteps = FALSE;
  gOutputVariations = FALSE;
  gKeepSubccdetail = FALSE;
  gParams.attributeImportanceThreshold = 0.55;
  gParams.maxAttributesUsed = 3;
  gParams.subgroupThreshold = 0.80;
  gParams.maxExpansion = 0;
  gParams.master2masterABprogram[0] = '\0';
  gParams.defSizeSubgroup = DEFMIN;
  gParams.sortSplitRatio = 0;

  /* Set beginReadFlag */
  beginReadFlag = TRUE;

/*eject*/	
  /* Loop at the file and look for tokens */
  while (parse_param(lhs, rhs, record, subccParams)) {
    /*
     * caution: parse_param() converts lhs to lower case
     *          this affects the tests below
     */
		
    /* Show steps on screen */
    if (strcmp(lhs,"showstepsonscreen") == 0) {
      gShowSteps = TRUE;
      gShowTargetSteps = TRUE;
      printf("\n");
      printf("show steps on screen\n\n");
      printf("                    Leibniz System\n");
      printf("                    subcc Program\n");
#include "../../GlobalVersion/globalversion.h"
      printf("                     Version %s\n",globalversion);
      printf("        Copyright 2001-2011 by Leibniz Company\n");
      printf("                 Plano, Texas, U.S.A.\n\n");
      continue;
    }

    /* "ENDATA" */
    if (strcmp(lhs, "endata") == 0 ||
      strcmp(lhs, "enddata") == 0) {
      cv[11] = TRUE;
      if (gShowSteps == TRUE ) {
        printf("\n**************************************\n\n");
      }
      break;
    }

    /* check for "begin...cc" specification */
    if ((strncmp(lhs,"begin",5) == 0) &&
        (strncmp(&lhs[strlen(lhs)-2],"cc",2) == 0)) {
      beginReadFlag = FALSE;
      if ((strcmp(lhs,"beginsubcc") == 0) ||
          (strcmp(lhs,"beginallcc") == 0)) {
        beginReadFlag = TRUE;
      }
      continue;
    }
    if (beginReadFlag == FALSE) {
      continue;
    }

/*eject*/		

    /*  "file name without extension = " */
    if (strcmp(lhs,"filenamewithoutextension") == 0) {
      strcpy(gParams.prefix,rhs);
      cv[1] = TRUE;
      if (gShowSteps == TRUE) {
        printf("file name without extension = %s\n",
               gParams.prefix);
      }
     continue;
    }

    /* "training/testing directory = " */
    if (strcmp(lhs,"training/testingdirectory") == 0) {
      strcpy(gParams.directory,rhs);
      cv[2] = TRUE;
      if (gShowSteps == TRUE) {
        printf("training/testing directory = %s\n",
               gParams.directory);
      }
      continue;
    }

    /* "Leibniz directory = " */
    if (strcmp(lhs,"leibnizdirectory") == 0) {
      strcpy(gParams.leibnizpath,rhs);
      cv[3] = TRUE;
      if (gShowSteps == TRUE) {
        printf("Leibniz directory = %s\n",
               gParams.leibnizpath);
      }
      continue;
    }
/*eject*/

    /*  "cutpoint file extension           (default: cut)   = " */
    if (strcmp(lhs, "cutpointfileextension(default:cut)") == 0) {
      strcpy(gFileExt.cut,".");
      strcat(gFileExt.cut,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "cutpoint file extension           (default: cut)   = %s\n",
          rhs);
      }
      continue;
    }

    /*  "distribution file extension       (default: dis)   = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,
        "distributionfileextension(default:dis)") == 0) {
      continue;
    }

    /*  "executable file extension         (default: exe)  = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,"executablefileextension(default:exe)") == 0) {
      continue;
    }

    /*  "minimization file extension       (default: min)  = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,"minimizationfileextension(default:min)") == 0){
      continue;
    }

    /*  "master file extension             (default: mst)   = " */
    if (strcmp(lhs, "masterfileextension(default:mst)") == 0) {
      strcpy(gFileExt.mst,".");
      strcat(gFileExt.mst,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "master file extension             (default: mst)   = %s\n",
          rhs);
      }
      continue;
    }
/*eject*/

    /*  "master AB file extension          (default: mstAB) = " */
    if (strcmp(lhs, "masterabfileextension(default:mstab)") == 0) {
      strcpy(gFileExt.mstAB,".");
      strcat(gFileExt.mstAB,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "master AB file extension          (default: mstAB) = %s\n",
          rhs);
      }
      continue;
    }

    /*  "optimal record file extension     (default: opt)   = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,
        "optimalrecordfileextension(default:opt)") == 0) {
      continue;
    }

    /*  "pyrpred file extension            (default: prd)   = " */
    if (strcmp(lhs, "pyrpredfileextension(default:prd)") == 0) {
    /*  note: not used by subcc, hence no action here */
      continue;
    }

    /*  "partial data file extension       (default: ptl)   = " */
    if (strcmp(lhs,
        "partialdatafileextension(default:ptl)") == 0) {
    /*  note: not used by subcc, hence no action here */
      continue;
    }
/*eject*/

    /*  "pyramid file extension            (default: pyr)   = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,
        "pyramidfileextension(default:pyr)") == 0) {
      continue;
    }

    /*  "rational training file extension  (default: rtr)   = " */
    if (strcmp(lhs,
             "rationaltrainingfileextension(default:rtr)") == 0) {
      strcpy(gFileExt.rtr,".");
      strcat(gFileExt.rtr,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational training file extension  (default: rtr)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "rational testing file extension  (default: rts)    = " */
    if (strcmp(lhs,
             "rationaltestingfileextension(default:rts)") == 0) {
      strcpy(gFileExt.rts,".");
      strcat(gFileExt.rts,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational testing file extension   (default: rts)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "rational testing A file extension (default: rtsA)  = " */
    if (strcmp(lhs,
             "rationaltestingafileextension(default:rtsa)") == 0) {
      strcpy(gFileExt.rtsA,".");
      strcat(gFileExt.rtsA,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational testing A file extension (default: rtsA)  = %s\n",
        rhs);
      }
      continue;
    }
/*eject*/

   /*  "rational testing B file extension (default: rtsB)  = " */
    if (strcmp(lhs,
             "rationaltestingbfileextension(default:rtsb)") == 0) {
      strcpy(gFileExt.rtsB,".");
      strcat(gFileExt.rtsB,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational testing B file extension (default: rtsB)  = %s\n",
        rhs);
      }
      continue;
    }

   /* "rational testEqtrain file ext.    (default: rtsEqrtr) = " */
    if (strcmp(lhs,
       "rationaltesteqtrainfileext.(default:rtseqrtr)") == 0) {
      strcpy(gFileExt.rtsEqrtr,".");
      strcat(gFileExt.rtsEqrtr,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
      "rational testEqtrain file ext.    (default: rtsEqrtr) = %s\n",
        rhs);
      }
      continue;
    }

   /*  "alternate testing file            (default: ats)     = " */
    if (strcmp(lhs,
             "alternatetestingfile(default:ats)") == 0) {
      strcpy(gFileExt.ats,".");
      strcat(gFileExt.ats,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
       "alternate testing file            (default: ats)   = %s\n", 
        rhs);
      }
      continue;
    }
/*eject*/
    /*  "rule file extension               (default: rul)   = " */
    if (strcmp(lhs,
        "rulefileextension(default:rul)") == 0) {
      strcpy(gFileExt.rul,".");
      strcat(gFileExt.rul,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rule file extension               (default: rul)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "separation file extension         (default: sep)   = " */
    if (strcmp(lhs,
        "separationfileextension(default:sep)") == 0) {
      strcpy(gFileExt.sep,".");
      strcat(gFileExt.sep,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "separation file extension         (default: sep)   = %s\n",
        rhs);
      }
      continue;
    }
/*eject*/
    /*  "subgroup file extension           (default: sub)   = " */
    if (strcmp(lhs,
        "subgroupfileextension(default:sub)") == 0) {
      strcpy(gFileExt.sub,".");
      strcat(gFileExt.sub,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "subgroup file extension           (default: sub)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "target file extension             (default: tgt)   = " */
    if (strcmp(lhs,
        "targetfileextension(default:tgt)") == 0) {
      strcpy(gFileExt.tgt,".");
      strcat(gFileExt.tgt,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "target file extension             (default: tgt)   = %s\n",
        rhs);
      }
      continue;
    }
				
    /*  "logic training file extension     (default: trn)   = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,
      "logictrainingfileextension(default:trn)") == 0) {
      continue;
    }

    /*  "logic testing file extension      (default: tst)   = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,
      "logictestingfileextension(default:tst)") == 0) {
      continue;
    }

    /*  "visualization file extension      (default: vis)   = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,
       "visualizationfileextension(default:vis)") == 0) {
      continue;
    }
/*eject*/

    /*  "vote file extension               (default: vot)   = " */
    if (strcmp(lhs,
        "votefileextension(default:vot)") == 0) {
      strcpy(gFileExt.vot,".");
      strcat(gFileExt.vot,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "vot file extension                (default: vot)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "vote A file extension             (default: votA)  = " */
    if (strcmp(lhs,
        "voteafileextension(default:vota)") == 0) {
      strcpy(gFileExt.votA,".");
      strcat(gFileExt.votA,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "vote A file extension             (default: votA)  = %s\n",
        rhs);
      }
      continue;
    }

    /*  "vote B file extension             (default: votB)  = " */
    if (strcmp(lhs,
        "votebfileextension(default:votb)") == 0) {
      strcpy(gFileExt.votB,".");
      strcat(gFileExt.votB,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "vot B file extension              (default: votB)  = %s\n",
        rhs);
      }
      continue;
    }
/*eject*/

    /* "missing entries (absent, unavailable) = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs, 
        "missingentries(absent,unavailable)") == 0) {
      continue; 
    }
/*eject*/

    /* "Subcc detail directory = " */
    if (strcmp(lhs,"subccdetaildirectory") == 0) {
      strcpy(gParams.subccdetaildir,rhs);
      cv[4] = TRUE;
      if (gShowSteps == TRUE) {
        printf("Subcc detail directory = %s\n",
               gParams.subccdetaildir);
      }
      continue;
    }

    /* "show target processing steps" */
    if (strcmp(lhs, "showtargetprocessingsteps") == 0) {
      gShowTargetSteps = TRUE;
      continue;
    }

    /* "output variations of subgroups" */
    if (strcmp(lhs, "outputvariationsofsubgroups") == 0) {
      gOutputVariations = TRUE;
      continue;
    }

    /* "keep subcc detail directory" */
    if (strcmp(lhs, "keepsubccdetaildirectory") == 0) {
      gKeepSubccdetail = TRUE; 
      continue;
    }

   /* "attribute importance threshold = " */
   if (strcmp(lhs, "attributeimportancethreshold") == 0) {
     if (gShowSteps == TRUE ) {
       printf("attribute importance threshold = %s\n", rhs);\
     }
     if (rhs != NULL) {
       gParams.attributeImportanceThreshold  = (float) atof(rhs);
     }
     continue;
   }

   /* "max number of attributes used = " */
   if (strcmp(lhs, "maxnumberofattributesused") == 0) {
     if (gShowSteps == TRUE ) {
       printf("max number of attributes used = %s\n", rhs);\
     }
     if (rhs != NULL) {
       gParams.maxAttributesUsed  = (int) atoi(rhs);
     }
     continue;
   }

   /* "significance measure (unusualness, accuracy, both) = "  */
   if (strcmp(lhs,
       "significancemeasure(unusualness,accuracy,both)") == 0) { 
      if (gShowSteps == TRUE ) {
      printf(
       "significance measure (unusualness, accuracy, both) = %s\n",
         rhs);        
      }
      cv[9] = TRUE;
      if (strcmp(rhs,"unusualness") == 0) {
        gParams.significanceMeasure = UNUSUALNESS;
        continue;
      } else if (strcmp(rhs,"accuracy") == 0) {
        gParams.significanceMeasure = ACCURACY;
        continue;
      } else if (strcmp(rhs,"both") == 0) {
        gParams.significanceMeasure = BOTH;
        continue;
      }
    /*
     *  if none of the above rhs case applies, output is
     *  generated below that the record cannot be interpreted
     */ 
    }


   /* "subgroup selection threshold = " */
   if (strcmp(lhs, "subgroupselectionthreshold") == 0) {
     if (gShowSteps == TRUE ) {
       printf("subgroup selection threshold = %s\n", rhs);\
     }
     if (rhs != NULL) {
       gParams.subgroupThreshold  = (float) atof(rhs);
     }
     continue;
   }

   /* "max number of expansions = " */
   if (strcmp(lhs, "maxnumberofexpansions") == 0) {
     if (gShowSteps == TRUE ) {
       printf("max number of expansions = %s\n", rhs);\
     }
     if (rhs != NULL) {
       gParams.maxExpansion  = (int) atoi(rhs);
     }
     continue;
   }

   /* "compute subgroups (new tgt, old tgt, tgt only) = "  */
   if (strcmp(lhs,
       "computesubgroups(newtgt,oldtgt,tgtonly)") == 0) { 
      if (gShowSteps == TRUE ) {
      printf(
         "compute subgroups (new tgt, old tgt, tgt only) = %s\n",
         rhs);        
      }
      cv[5] = TRUE;
      if (strcmp(rhs,"newtgt") == 0) {
        gSelectTargetFile = NEWTGT;
        continue;
      } else if (strcmp(rhs,"oldtgt") == 0) {
        gSelectTargetFile = OLDTGT;
        continue;
      } else if (strcmp(rhs,"tgtonly") == 0) {
        gSelectTargetFile = TGTONLY;
        continue;
      }
    /*
     *  if none of the above rhs case applies, output is
     *  generated below that the record cannot be interpreted
     */ 
    }

   /* "master to masterAB program = "  */
   if (strcmp(lhs,
       "mastertomasterabprogram") == 0) { 
      if (gShowSteps == TRUE ) {
      printf(
         "master to masterAB program = %s\n",
         rhs);        
      }
      cv[6] = TRUE;
      if (strcmp(rhs,"") != 0) {
        strcpy(gParams.master2masterABprogram,rhs);
        continue;
      } else {
        suberror("Missing rhs for 'master to masterAB program ='",
                 "readParamsFile","301");
      } 
    }

    /* "use (master, alternate) testing file            = "  */
    if (strcmp(lhs,
       "use(master,alternate)testingfile") == 0) { 
      if (gShowSteps == TRUE ) {
      printf(
         "use (master, alternate) testing file          = %s\n",
         rhs);        
      }
      cv[7] = TRUE;
      if (strcmp(rhs,"master") == 0) {
        gSelectTestFile = MASTER;
        continue;
      } else if (strcmp(rhs,"alternate") == 0) {
        gSelectTestFile = ALTERNATE;
        continue;
      }
    /*
     *  if none of the above rhs case applies, output is
     *  generated below that the record cannot be interpreted
     */ 
    }

    /* "sort and split with ats/mst ratio (0, 1, 2, ...) = " */
    if (strcmp(lhs,"sortandsplitwithats/mstratio(0,1,2,...)") == 0) {
      if (gShowSteps == TRUE ) {
        printf(
         "sort and split with ats/mst ratio (0, 1, 2, ...) = %s\n", 
         rhs);\
      }
      if (rhs != NULL) {
        gParams.sortSplitRatio  = (int) atoi(rhs);
      }
      continue;
    }
/*eject*/
    /* "size of subgroup definitions (max,min)          = "  */
    if (strcmp(lhs,
       "sizeofsubgroupdefinitions(max,min)") == 0) { 
      if (gShowSteps == TRUE ) {
      printf(
         "size of subgroup definitions (max,min)        = %s\n",
         rhs);        
      }
      cv[8] = TRUE;
      if (strcmp(rhs,"max") == 0) {
        gParams.defSizeSubgroup = DEFMAX;
        continue;
      } else if (strcmp(rhs,"min") == 0) {
        gParams.defSizeSubgroup = DEFMIN;
        continue;
      }
    /*
     *  if none of the above rhs case applies, output is
     *  generated below that the record cannot be interpreted
     */ 
    }
/*eject*/
    /*  "output (all, representative) subgroups = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,"output(all,representative)subgroups") == 0){
      continue;
    }

    /* "keep suballcc detail directory" */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs, "keepsuballccdetaildirectory") == 0) {
      continue;
    }

    /* "Suballcc detail directory = " */
    /*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,"suballccdetaildirectory") == 0) {
      continue;
    }
/*eject*/
    /* line cannot be interpreted */
    printf(
    "\nRecord in file lsqccparams.dat cannot be interpreted:\n\n");
    printf(" %s \n", record);
    printf("Please correct lsqccparams.dat file\n");
    printf("and execute subcc again\n");
    fprintf(errfil, 
    "\nRecord in file lsqccparams.dat cannot be interpreted:\n\n");
    fprintf(errfil, " %s \n", record);
    fprintf(errfil, "Please correct lsqccparams.dat file\n");
    fprintf(errfil,	"and execute subcc again\n");
    suberror("Error","readParamsFile", "501");

  } /* end of while */
/*eject*/
  /* if sort and split option has been specified, enforce use */
  /* of alternate testing file option */
  if (gParams.sortSplitRatio > 0) {
    gSelectTestFile = ALTERNATE;
    cv[7] = TRUE;
  }
/*eject*/
  /* confirm that all the information was entered */
  if(cv[1]==FALSE) {
    sprintf(message,
   "Filename without extension is not specified in lsqccparams.dat");
    suberror(message,"readParamsFile", "101");
  }

  if(cv[2]==FALSE) {
    suberror(
    "Training/testing directory is not specified in lsqccparams.dat",
    "readParamsFile", "102");
  }


  if(cv[3]==FALSE) {
    suberror("Leibniz directory is not specified in lsqccparams.dat",
             "readParamsFile", "103");
  }

  if(cv[4]==FALSE) {
    suberror(
        "Subcc detail directory is not specified in lsqccparams.dat",
        "readParamsFile", "104");
  }

  if (cv[5]==FALSE) {    
    suberror(
      "Compute subgroup option is not specified in lsqccparams.dat",
      "readParamsFile", "105");
  }

  if (cv[6]==FALSE) {
    /* master2masterABprogram has not been specified */ 
    /* define standard Leibniz/Prpcc/Code version */
#ifdef UNIX
    sprintf(gParams.master2masterABprogram,
            "%sPrpcc/Code/master2masterABTarget ",
	    gParams.leibnizpath);
#endif
#ifdef WINDOWS
    sprintf(gParams.master2masterABprogram,
            "%sPrpcc\\Code\\master2masterABTarget ",
	    gParams.leibnizpath);
#endif
  }

  if (cv[7]==FALSE) {    
    suberror(
      "Testing file option is not specified in lsqccparams.dat",
      "readParamsFile", "107");
  }

  if (cv[8]==FALSE) {    
    suberror(
      "Size of subgroup option is not specified in lsqccparams.dat",
      "readParamsFile", "108");
  }

  if (cv[9]==FALSE) {    
    suberror(
      "Significance measure is not specified in lsqccparams.dat",
      "readParamsFile", "109");
  }

  if (cv[11]==FALSE){
    suberror("Missing ENDATA record in lsqccparams.dat", 
             "readParamsFile","111");
  }

  closeFile(subccParams);
  return;
		
}
/*eject*/
/*************************************************************
*	Shift the line left
*   Ascii 32 = space, 9 = tab
**************************************************************/
void shiftLeft(char fileRec[]) {

  while(fileRec[0] == 32 || fileRec[0] == 9) {
    strcpy(fileRec, fileRec+1);
  }

  return;
}

/* last record of readFiles.c *******/
