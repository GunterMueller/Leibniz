/****************************************************************/
/* activate exactly one of the statements below  */
#undef  DENCON  /* dencon */
#undef  DENPAR  /* denpar */
#undef  GENCC   /* gencc */
#undef  MULTICC /* multicc */
#undef  NOMAD   /* nomad */ 
#undef  NSGA    /* nsga  */
#define SEQPEN  /* seqpen */
/****************************************************************/
