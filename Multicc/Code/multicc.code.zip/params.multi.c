/* Nomad routines for parameter files */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *   void addFinalPop2output(FILE *outputfil)
 *   void defineMultiParams(FILE *outputfil)
 *   int getFinalPopEvaluationCount()
 ****************************************************************/
/*eject*/
/**************************************************************
 * void addFinalPop2outputMulti(FILE *outputfil):
 *   add final_pop.out file to specified output file
 *   retain evaluation count
 *   update haveSolution
 **************************************************************/
int addFinalPop2outputMulti(FILE *outputfil) {

  int j, p1, p2, p3, p4, savenobj;
  double obj[MAX_OBJ], xreal[MAX_VARIABLE], constr[MAX_CONSTRAINT],
         constr_violation;

  char lineread[MAXLEN]; 
  char tok[MAX_ENTRY][MAX_ENTRY];
  int  ntok;

  char finalfile[MAX_ENTRY];
  FILE *finalfil;

  savenobj = nobj;     /* save nobj value */
  nobj = nobjEvaluate; /* needed for function evaluation below */

  strcpy(finalfile,"final_pop.out");
  finalfil = openFile(finalfile,"r");

  /* initialize single objective value used for convergence test */
  singleObjective.new = INF;
/*eject*/
  while (fgets(lineread,MAXLEN,finalfil) != NULL) {
    /* check for header record with evaluation count */
    if (strncmp(lineread,"# of objectives",15) == 0) {
      sscanf(lineread,
      "# of objectives = %d , # of constraints = %d , # of real_var = %d , constr_violation , rank , crowding_distance , # of evaluations = %d",
              &p1, &p2, &p3, &p4);
      fprintf(outputfil,
       "\n# of objectives = %d , # of constraints = %d , # of real_var = %d , constr_violation , rank , crowding_distance , # of evaluations = %d",nobj,p2,p3,p4);
      fprintf(outputfil,
         "\n# records: skip %d entries",nobj+p2);
    } else if (strncmp(lineread,"# infeasible case:",18) == 0) {
      /* have infeasibility record, copy to output file */
      fprintf(outputfil,"%s",lineread);
    } else if ((lineread[0] == '#') || (lineread[0] == '\n')){
      /* have comment record, skip */
/*eject*/
    } else {
    /* have data record */
  
      /* get record tokens */
      tokenize(lineread);

     /* save tokens since evaluation steps below may damage them */
     /* prior to final use in this routine */
      for (j=0; j<nTokens; j++) {
        strcpy(tok[j],token[j]);
      }
      ntok = nTokens;

      /* get constr_violation; write warning if solution infeasible */
      /* numerical value may be incorrect, but '= 0.0' holds for */
      /* feasible case, and '< 0' for infeasible case */
      constr_violation = atof(tok[p1+p2+p3]);
      if (constr_violation < 0) {
        fprintf(outputfil,"\n# infeasible solution");
      } else {
        fprintf(outputfil,"\n# feasible solution");
      }

      /* if single objective case and and we have first record of */
      /* final_pop.out, and if that record is feasible according */
      /* to constr_violation, then update haveSolution and */
      /* singleObjective.new using that record */

      if ((p1 == 1) && 
          (constr_violation == 0.0) &&
          (singleObjective.new == INF)) {
        haveSolution = TRUE;
        singleObjective.new = atof(tok[0]);
      }
/*eject*/  
      if ((p1 == nobj) && (constr_violation == 0.0)) {

        /* sufficient condition that record has nobj correct obj */
        /* values, and correct constr and constr_violation */
        /* output entire record using tok[], */
        /*  with obj converted to external */
        fprintf(outputfil,"\n");
        for (j=0; j<ntok; j++) {
          if (j < nobj) {
            if (strcmp(objective[j].direction,"min") == 0) {
              fprintf(outputfil,"%s\t",tok[j]);
            } else { /* max case: flip sign */
              if (tok[j][0] == '-') {
                fprintf(outputfil,"%s\t",&tok[j][1]);
              } else {
                fprintf(outputfil,"-%s\t",tok[j]);
              }
            }
          } else {
            fprintf(outputfil,"%s\t",tok[j]);
          }
        } 
      
      } else {
        /* obj or constr values may not be correct */
        /* evaluate x vector to get nobj obj values and constr */
        /* get xreal values */
        for (j=0; j<p3; j++) {
          xreal[j] = atof(tok[p1+p2+j]);
        }
        /* evaluate xreal */
        if (strcmp(gOption.input,"NOINPUTFILE") != 0) {
          queryBlackBox(problemName,xreal,obj,constr);
        } else {
          test_problem (TRUE, problemName, xreal, 
                      obj, constr);
          /* first parameter usage:
           *   TRUE: compute obj, constr values
           *   FALSE: define nreal, nbin, nobj, ncon,
           *                 min_realvar[], max_realvar[]
           */
        }
/*eject*/
        fprintf(outputfil,"\n");
        /* nobj external obj values */
        for (j=0; j<nobj; j++) {
          if (strcmp(objective[j].direction,"min") == 0) {
            fprintf(outputfil,"%g\t",obj[j]);
          } else { /* max case: flip sign */
            fprintf(outputfil,"%g\t",-obj[j]);
          }
        }
        /* constr */
        for (j=0; j<ncon; j++) {
          fprintf(outputfil,"%g\t",constr[j]);
        }
        /* write tokens of xreal */
        for (j=0; j<nreal; j++) {
          fprintf(outputfil,"%s  ",tok[p1+p2+j]);
        }
       /* constr_violation */
        constr_violation = 0.0;
        for (j=0; j<ncon; j++) {
          if (constr[j] < 0.0) {
            constr_violation += constr[j];
          }
        }
        fprintf(outputfil,"%g\t",constr_violation);
        /* write remaining tokens for rank and crowding_distance */
        for (j=p1+p2+p3+1; j<ntok; j++) {
          fprintf(outputfil,"%s\t",tok[j]);
        }
        fprintf(outputfil,"\n");

      } /* end if p1 == nobj ..., else */ 
    } /* end if strncmp(lineread, else if lineread[0] == '#', else */
  } /* end while */

  closeFile(finalfil);

  /* restore nobj value */
  nobj = savenobj;

  return p4;

}
/*eject*/
/**************************************************************
 * void defineMultiParams(FILE *outputfil):
 * first step of definition of multi params file
 * caution: utilizes input min/max_realvar[] bounds
 *          thus must make sure that the routine is called before the
 *          max_realvar[] bounds are changed for integer variables
 **************************************************************/
void defineMultiParams(FILE *outputfil) {

  int i, j;

  if (strcmp(gOption.params,"NOPARAMSFILE") != 0) {
    /* modify and use paramsData[] */
    for (i=0; i<nParamsData; i++) {
      if (strncmp(paramsData[i],"# input for problem",19) == 0) {
        fprintf(outputfil,"# input for problem %s.multi\n",
                          problemName);
      } else {
        fprintf(outputfil,"%s\n",paramsData[i]);
      }
    }
  } else {
    /* construct file */
    fprintf(outputfil,"# input for problem %s",
                      problemName);
    fprintf(outputfil,"\n# total number of variables = %d",nreal);
    fprintf(outputfil,"\n# number of integer variables = %d",nint);
    fprintf(outputfil,"\n# number of objectives = %d",nobjEvaluate);
    fprintf(outputfil,"\n# number of constraints = %d",ncon);
    for (i=0; i<nobjEvaluate; i++) {
      fprintf(outputfil,"\n# objective: obj%d min",i+1);
    }
    for (i=0; i<ncon; i++) {
      fprintf(outputfil,"\n# constraint: condition%d >= 0",i+1);
    }
    for (j=0; j<nreal; j++) {
      fprintf(outputfil,"\n# param: var%d %g %g ",
                        j+1, min_realvar[j],max_realvar[j]);
    }
    fprintf(outputfil,"\n# endformat");
  } /* end if strcmp(gOption.input,"NOINPUTFILE") != 0, else */

  return;

}
/*eject*/
/* OBSOLETE, eliminated from use March 26, 2013 */
/**************************************************************
 * int getFinalPopEvaluationCount():
 *   return evaluation count of final_pop.out
 **************************************************************/
int getFinalPopEvaluationCount() {

  int p1, p2, p3, p4;
  char lineread[MAXLEN];
  char finalfile[MAX_ENTRY];
  FILE *finalfil;

  strcpy(finalfile,"final_pop.out");
  finalfil = openFile(finalfile,"r");

  while (fgets(lineread,MAXLEN,finalfil) != NULL) {
    /* check for header record with evaluation count */
    if (strncmp(lineread,"# of objectives",15) == 0) {
      sscanf(lineread,
      "# of objectives = %d , # of constraints = %d , # of real_var = %d , constr_violation , rank , crowding_distance , # of evaluations = %d",
              &p1, &p2, &p3, &p4);
      closeFile(finalfil);
      return p4; 
    }

  } /* end while */

  printf("\n getFinalPopEvaluationCount: missing header record");
  exit(1);

}
/*********last record of params.multi.c *******************/
