/* storage and retrieval of solutions and associated values */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "dencon.h"
/**************************************************************
 *
 * subroutines in this file:
 *    void predict_cont();
 *    void predict_dense()
 *    double storeAllz(int ielle,double *z)
 *    double storeAllzdelta(int ielle,double *z)
 *    void transfer2plin()
 **************************************************************/
/*eject*/
/**************************************************************
 *   void predict_cont(double *x,double *f_,double *d,
 *                 double *alfa_,double alfa_d,
 *                 double *z1,double *fz1_,
 *                 double *z2,double *fz2_,
 *                 double *z,double *fz_, 
 *                 int *num_fal_)
 **************************************************************/
void predict_cont(double *x,double *f_,double *d,
                  double *alfa_,double *alfa_d,
                  double *z1,double *fz1_,
                  double *z2,double *fz2_,
                  double *z,double *fz_, 
                  int *num_fal_) {

  /* transfer variables */
  double f, alfa, fz1, fz2, fz;
  int num_fal;

  /* local variables */
  int i,j, n;
  int ifront,ielle;
  double alfaex, gamma;
  double delta,delta1,fpar,fzdelta,violzdelta;


  /* define n */
  n = nreal;

  /* transfer in */
  f = *f_;
  alfa = *alfa_;
  fz1 = *fz1_;
  fz2 = *fz2_;
  fz = *fz_;
  num_fal = *num_fal_;
/*eject*/
  gamma = 1.e-6;   
  delta = 0.5;
  delta1 = 0.5;

  i_corr_fall = 0;
  ifront = 0;
  j = i_corr;

  if (iprint >= 1) {
    printf("\n variabile continua  j = %d    d[j] = %g alfa = %g",
           j, d[j], alfa_d[j]);
    fflush(stdout);
  }


  if (fabs(alfa_d[j]) <= 1.e-3*min(1.0,alfa_max)) {
    alfa = 0.0;
    if (iprint >= 1) {
       printf("\n alfa piccolo");
       printf("\n alfa_d[j] = %g    alfamax = %g",
              alfa_d[j], alfa_max);
       fflush(stdout);
    }
    goto transfer_out;
  }
/*eject*/     
  for (ielle=1; ielle<=2; ielle++) {

    if (d[j] > 0.0) {

      if ((alfa_d[j]-(ub[j]-x[j])) < -1.e-6) {                 
          alfa = max(1.e-24,alfa_d[j]);
      } else {
        alfa = ub[j]-x[j];
        ifront = 1;
        if (iprint >= 1) {
          printf("\n punto espan. sulla front. *");
          fflush(stdout);
        }
      }

    } else {

      if ((alfa_d[j]-(x[j]-lb[j])) < -1.e-6) {
        alfa = max(1.e-24,alfa_d[j]);
      } else {
        alfa = x[j]-lb[j];
        ifront = 1;
        if (iprint >= 1) {
          printf("\n punto espan. sulla front. *");
          fflush(stdout);
        }
      }

    }
/*eject*/
    if(fabs(alfa) <= 1.e-3*min(1.0,alfa_max)) {
  
      d[j] = -d[j];
      i_corr_fall++;
      ifront=0;

      if(iprint >= 1) {
        printf("\n direzione opposta per alfa piccolo");
        printf("\n j = %d    d[j] = %g", j, d[j]);
        printf("\n alfa = %g    alfamax = %g", alfa, alfa_max);
        fflush(stdout);
      }
      alfa = 0.0;

      /* Parallel begin */
      if (ielle == plin.ielle) {
        /* no additional points can be computed for plin.ielle */
        break;
      } else {
        continue;
      }
      /* Parallel end */

    }

    alfaex = alfa;

    z[j] = x[j] + alfa*d[j]; 
/*eject*/
    /* Parallel begin */
    fz = storeAllz(ielle,z);
         /* computes fictitious fz = INF or -INF */
         /* also defines obj = fz, constr[] = 0, viol = 0 */
    /* Parallel end */

    if (ielle == 1) {
      for (i=1; i<=n; i++) {
        z1[i] = z[i];
      }
      fz1 = fz;
    } else {
      for (i=1; i<=n; i++) {
        z2[i] = z[i];
      }
      fz2 = fz;
    }
/*eject*/
    violz=viol;
    if (iprint >= 1) {
      printf("\n fz = %g   alfa = %g", fz, alfa);
      fflush(stdout);
    }
    if (iprint >= 2) {
      for (i=1; i<=n; i++) {
        printf("\n z[%d] = %g",i,z[i]);
        fflush(stdout);
      }
    }

    fpar = f - gamma*alfa*alfa;
    if (fz < fpar) {
      /* line below added Oct 25, 2013, to correct omission */
      i_corr_fall++;
/*eject*/
      while (1) { /* while #1 */

        if((ifront == 1)) {
          if(iprint >= 1) {
            printf(
              "\n accetta punto sulla frontiera fz = %g   alfa = %g",
              fz, alfa);
            fflush(stdout);
          }
          alfa_d[j] = delta * alfa;
          goto transfer_out;
        }

        if (d[j] > 0.0) {
              
          if (alfa/delta1-(ub[j]-x[j]) < -1.e-6) {
            alfaex = alfa/delta1;
          } else {
            alfaex = ub[j] - x[j];
            ifront = 1;
            if(iprint >= 1) {
             printf("\n punto espan. sulla front.");
             fflush(stdout);
            }
          }
/*eject*/
        } else {

          if(alfa/delta1-(x[j]-lb[j]) < -1.e-6) {
            alfaex = alfa/delta1;
          } else {
            alfaex = x[j]-lb[j];
            ifront = 1;
            if(iprint >= 1) {
             printf("\n punto espan. sulla front.");
             fflush(stdout);
            }
          }

        }
             
        z[j] = x[j] + alfaex*d[j]; 
/*eject*/
        /* Parallel begin */
        fzdelta = storeAllzdelta(ielle,z);
          /* computes fictitious fzdelta = INF or -INF */
          /* also defines obj = fzdelta, constr[] = 0, viol = 0 */
        /* Parallel end */

        violzdelta = viol;

        if(iprint >= 1) {
          printf("\n  fzex = %g  alfaex = %g",fzdelta, alfaex);
          fflush(stdout);  
        }
        if(iprint >= 2) {
          for (i=1; i<=n; i++) {
            printf("\n z[%d] = %g",i,z[i]);
            fflush(stdout);
          }
        }
/*eject*/
        fpar = f - gamma*alfaex*alfaex;

        if (fzdelta < fpar) {

          fz = fzdelta;
          violz = violzdelta;
          alfa = alfaex;

        } else {               

          alfa_d[j] = delta*alfa;
          if(iprint >= 1) {
            printf("\n accetta punto fz = %g   alfa = %g", fz, alfa);
            fflush(stdout);
          }
          goto transfer_out;
        }

      } /* end while #1 */
/*eject*/
    } else {      

      d[j] = -d[j];
      ifront = 0;

      if(iprint >= 1) {
        printf("\n direzione opposta");
        printf("\n j = %d    d[j] = %g",j, d[j]);
        fflush(stdout);
      }

    }            
  } /* end for ielle=1 */

  if (i_corr_fall != 2) {
    alfa_d[j] = delta * alfa_d[j];
  }

  alfa = 0.0;

  if (iprint >= 1) {
    printf("\n fallimento direzione");
    fflush(stdout);
  }
/*eject*/
transfer_out:;
  *f_ = f;
  *alfa_ = alfa;
  *fz1_ = fz1;
  *fz2_ = fz2;
  *fz_ = fz;

  return;

}
/*eject*/
/**************************************************************
 *   void predict_dense(double *x,double *f_,double *d,
 *                   double *alfa_,double *alfa_d_,
 *                   double *z1,double *fz1_,
 *                   double *z2,double *fz2_,
 *                   double *z,double *fz_, 
 *                   int *num_fal_)
 **************************************************************/
void predict_dense(double *x,double *f_,double *d,
                   double *alfa_,double *alfa_d_,
                   double *z1,double *fz1_,
                   double *z2,double *fz2_,
                   double *z,double *fz_,
                   int *num_fal_) {
  /* caution: alfa_d here is a scalar, not a vector */
  /* transfer variables */
  double f, alfa, alfa_d, fz1, fz2, fz;
  int num_fal;

  /* local variables */
  int i, n;
  int ifront,ielle;
  double alfaex, gamma;
  double delta,delta1,fpar,fzdelta,violzdelta;


  /* define n */
  n = nreal;

  /* transfer in */
  f = *f_;
  alfa = *alfa_;
  fz1 = *fz1_;
  fz2 = *fz2_;
  fz = *fz_;
  num_fal = *num_fal_;
  alfa_d = *alfa_d_;
/*eject*/
  gamma = 1.e-6;    

  delta = 0.5;
  delta1 = 0.5;

  i_corr_fall = 0;

  ifront = 0;
 
  if (iprint >= 1) {
    printf("\n direzione halton, alfa = %g",alfa_d);
    fflush(stdout);
  }
/*eject*/
  for (ielle=1; ielle<=2; ielle++) {

    alfa = alfa_d;
    alfaex = alfa;
    for (i=1; i<=n; i++) {
      z[i] = x[i] + alfa*d[i];
    }
    for (i=1; i<=n; i++) {
      z[i] = max(lb[i],min(ub[i],z[i]));
    }
   
    /* Parallel begin */
    fz = storeAllz(ielle,z);
         /* computes fictitious fz = INF or -INF */
         /* also defines obj = fz, constr[] = 0, viol = 0 */
    /* Parallel end */

    if (ielle == 1) {
      for (i=1; i<=n; i++) {
        z1[i]  = z[i];
      }
        fz1 = fz;
    } else {
      for (i=1; i<=n; i++) {
        z2[i]  = z[i];
      } 
      fz2 = fz;
    }

    violz = viol;
/*eject*/
    if (iprint >= 1) {
      printf("\n fz = %g   alfa = %g",fz, alfa);
      fflush(stdout);
    }
    if (iprint >= 2) {
      for (i=1;i<=n; i++) {
        printf("\n z[%d] = %g",i, z[i]);
        fflush(stdout);
      }
    }

    fpar = f - gamma*alfa*alfa;

    if (fz < fpar) {
      /* line below added Oct 25, 2013, to correct omission */
      i_corr_fall++; 
/*eject*/
      while (1) {

        alfaex = alfa/delta1;

        for (i=1; i<=n; i++) {          
          z[i] = x[i] + alfaex*d[i];          
          z[i] = max(lb[i],min(ub[i],z[i]));
        }    
         
        /* Parallel begin */
        fzdelta = storeAllzdelta(ielle,z);
          /* computes fictitious fzdelta = INF or -INF */
          /* also defines obj = fzdelta, constr[] = 0, viol = 0 */
        /* Parallel end */
/*eject*/
        violzdelta = viol;

        if (iprint >= 1) {
          printf("\n fzex = %g  alfaex = %g",fzdelta,alfaex);
          fflush(stdout);  
        }
        if(iprint >= 2) {
          for (i=1; i<=n; i++) {
            printf("\n z[%d] = %g",i, z[i]);
            fflush(stdout);
          } 
        }

        fpar = f - gamma*alfaex*alfaex;

        if (fzdelta < fpar) {

          fz = fzdelta;
          violz = violzdelta;
          alfa = alfaex;

        } else {               
          alfa_d = alfa;
          if (iprint >= 1) {
            printf("\n denso: accetta punto fz = %g   alfa = %g",
                   fz, alfa);
            fflush(stdout);
          }
          goto transfer_out;
        }

      }  /* end while (1) */
/*eject*/
    } else {      

      for (i=1; i<=n; i++) {
        d[i] = -d[i];
      }
      ifront = 0;

      if (iprint >= 1) {
        printf("\n denso:  direzione opposta");
      }

    }  
        
  } /* end for ielle=1 */     

  alfa_d = delta*alfa_d;
  alfa=0.0;

  if (iprint >= 1) {
    printf("\n denso: fallimento direzione");
    fflush(stdout);
  }
/*eject*/
transfer_out:;
  /* transfer out */
  *f_ = f;
  *alfa_ = alfa;
  *fz1_ = fz1;
  *fz2_ = fz2;
  *fz_ = fz;
  *alfa_d_ = alfa_d;

  return;

}
/*eject*/
/**************************************************************
 *   double storeAllz(int ielle,double *z)
 *       compute fictitious fz = INF or -INF depending on ielle
 *               and plin.ielle
 *               define obj = fz, constr[] = 0, viol = o
 **************************************************************/
double storeAllz(int ielle,double *z) {

  int i, n;

  double fz;

  n = nreal;

  if (plin.ielle == 1) {
    if (ielle == 1) {
      plin.nAllz[ielle] += 2;
      vector2vector(z,plin.allz[plin.nAllz[ielle]],n);
      fz = -INF;
    } else { /* ielle = 2 */
      printf("\nstoreAllz: ielle = %d and ",ielle);
      printf("\n plin.ielle = %d must not happen",plin.ielle);
      exit(1);
    } 
/*eject*/    
  } else { /* plin.ielle = 2 */
    if (ielle == 1) {
      fz = INF;
    } else { /* ielle = 2 */
      plin.nAllz[ielle] += 2;
      vector2vector(z,plin.allz[plin.nAllz[ielle]],n);
      if (plin.nAllz[ielle] >= MAX_LINESEARCH) {
        printf("\nnstoreAllzdelta: plin.nAllz[%d] = %d",
               ielle,plin.nAllz[ielle]);
        printf(" should not exceed MAX_LINESEARCH = %d",
               MAX_LINESEARCH);
        exit(1);
      } 
      if (plin.nAllz[ielle] <= MAX_LINESEARCH-4) { 
        fz = -INF;
      } else {
        fz = INF;
      }      
    }
  }
  obj = fz;
  for (i=1; i<=ncon; i++) {
        constr[i] = 0;
  }
  viol = 0.0;

  return fz;

}
/*eject*/
/**************************************************************
 *   double storeAllzdelta(int ielle,double *z)
 *       compute fictitious fzdelta = INF or -INF depending on ielle
 *               define obj = fzdelta, constr[] = 0, viol = o
 **************************************************************/
double storeAllzdelta(int ielle,double *z) {

  int i, n;

  double fzdelta;

  n = nreal;

  if (ielle != plin.ielle) {
    printf("\nstoreAllzdelta: ielle = %d != ",ielle);
    printf("plin.ielle = %d must not happen",plin.ielle);
    exit(1);
  }
  plin.nAllz[ielle] += 2;
  vector2vector(z,plin.allz[plin.nAllz[ielle]],n);
  if (plin.nAllz[ielle] >= MAX_LINESEARCH) {
    printf("\nnstoreAllzdelta: plin.nAllz[%d] = %d",
           ielle,plin.nAllz[ielle]);
    printf(" should not exceed MAX_LINESEARCH = %d",MAX_LINESEARCH);
    exit(1);
  } 
/*eject*/
  if (plin.nAllz[ielle] <= MAX_LINESEARCH-4) { 
    fzdelta = -INF;
  } else {
    fzdelta = INF;
  }
  obj = fzdelta;
  for (i=1; i<=ncon; i++) {
    constr[i] = 0;
  }
  viol = 0.0;

  return fzdelta;

}
/*eject*/
/**************************************************************
 *   void transfer2plin(double *x,double *f_,double *d,
 *                 double *alfa_,double alfa_d,
 *                 double *z1,double *fz1_,
 *                 double *z2,double *fz2_,
 *                 double *z,double *fz_, 
 *                 int *num_fal_)
 *        transfer linesearch variables to plin environment
 **************************************************************/
void transfer2plin(double *x,double *f_,double *d,
                  double *alfa_,double *alfa_d,
                  double *z1,double *fz1_,
                  double *z2,double *fz2_,
                  double *z,double *fz_, 
                  int *num_fal_) {

  /* transfer variables */
  double f, alfa, fz1, fz2, fz;
  int num_fal;

  /* local variables */
  int n;

  /* define n */
  n = nreal;

  /* transfer in */
  f = *f_;
  alfa = *alfa_;
  fz1 = *fz1_;
  fz2 = *fz2_;
  fz = *fz_;
  num_fal = *num_fal_;
/*eject*/
  /* transfer linesearch variables to plin environment */
  vector2vector(x,plin.x,n);
  plin.f = f;
  vector2vector(d,plin.d,n);
  plin.alfa = alfa;
  vector2vector(alfa_d,plin.alfa_d,n);
  vector2vector(z,plin.z,n);
  vector2vector(z1,plin.z1,n);
  vector2vector(z2,plin.z2,n);
  plin.fz = fz;
  plin.fz1 = fz1;      
  plin.fz2 = fz2;
  plin.num_fal = num_fal;


  return;

}
/********** last record of denconPredict.c ***********/
