/****************************************************************/
/* activate exactly one of the statements below  */
#undef  DENCON  /* dencon */
#define DENPAR  /* denpar */
#undef  GENCC   /* gencc */
#undef  MULTICC /* multicc */
#undef  NOMAD   /* nomad */ 
#undef  NSGA    /* nsga  */
#undef  SEQPEN  /* seqpen */
/****************************************************************/
