/* user control of multicc via file multicontrol.conx */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"

/************************************************************
 *  subroutines in this file:
 *     int main program for multicontrol
 ************************************************************/
/*eject*/ 
int main (int argc, char **argv) {

  int i;
  char cmnd[MAX_ENTRY];

  char multicontrolfile[MAX_ENTRY] = "/dev/shm/multicontrol.conx";
  /* caution: multicontrolfile name must be consistent with the */
  /*          definition in multicc.c */
  FILE *multicontrolfil;

  if (argc == 1) {
    /* there is no instruction */
    /* delete multicontrolfile if present */
    if ((multicontrolfil = fopen(multicontrolfile,"r")) != NULL) {
      fclose(multicontrolfil);
      sprintf(cmnd,"rm %s",multicontrolfile);
      system(cmnd);
    }
    return 0;
  }

  /* instruction is present */
  /* write instruction into multicontrolfile */
  multicontrolfil = fopen(multicontrolfile,"w");
  for (i=1; i<argc; i++) {
    fprintf(multicontrolfil,"%s ",argv[i]);
  }
  fprintf(multicontrolfil,"\n");
  fclose(multicontrolfil);

  return 0;

}
/************ last record of multicontrol.c *********/
