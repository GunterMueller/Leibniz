/* begin stringoperation.lb.c */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"
/************************************************************
 *  subroutines in this file:
 *     int tokenize(char *lineread)
 ************************************************************/
/*eject*/
/**************************************************************
 * int tokenize(char *lineread): extract up to MAX_ENTRY
 * non-white-space strings from lineread[]
 * stops with error if a string has length >= MAX_ENTRY 
 * place strings into token[][];
 * defines nTokens = number of extracted tokens
 * process does not change lineread[]
 **************************************************************/
int tokenize(char *lineread) {

  int i, j;
  char saveread[MAXLEN];
  char *buffer;

  strcpy(saveread,lineread);

  /* strip off carriage return and whitespace */
  /* at end of the line */
  i = strlen(lineread) - 1;
  while (lineread[i]>=1 && lineread[i]<=32) {
    lineread[i] = '\0';
    i--;
  }

  for (j=0; j<MAX_ENTRY; j++) {

    if (j == 0) {  
      buffer = strtok(saveread," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }

    if (buffer == NULL) {
      break;
    }

    if (strlen(buffer) >= MAX_ENTRY) {
      printf(
      "\n tokenize: lineread = %s contains too-large\n", lineread);
      printf(
      "\n token = %s with strlen >= %d \n", buffer, MAX_ENTRY);
      exit(1);
    }

    strcpy(token[j],buffer);

  } /* end for j */

  nTokens = j;

  return nTokens;

}
/********* last record of stringoperation.lb.c ******************/
