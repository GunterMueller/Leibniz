/* utility routines */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "dencon.h"
/**************************************************************
 *
 * subroutines in this file:
 *       void extract_parallelCandidate(int idx, double *x, 
 *          double *func, double *ob, double *const, double *vio)
 *       double relative_distance(double *v1, double *v2, int nsize)
 *       int same_parallelCandidate(double *v1, int idx, int nsize) 
 *       int same_vector(double *v1, double *v2, int nsize)
 *       void vector2parallelCandidate(double *v1, int idx, 
 *                                     int nsize) 
 *       void vector2vector(double *v1, double *v2, int nsize) 
 *       void xplusdir2z(double *x, double coeff, double *dir, 
 *                       double *z, int nsize)
 **************************************************************/
/*eject*/
/**************************************************************
 *   void extract_parallelCandidate(int idx, double *x, double *func_,
 *                        double *ob_, double *const, double *vio_):
 *       extracts x[], *ob_, const[] from parallelCandidate[idx]
 *       computes *func_, vio_*
 *
 *       also defines global obj = *ob
 *                           constr[] = con[]
 *                           viol = *vio_
 *       caution: all vector indices are i = 1, ...
 *                 index shift for parallelCandidate[]    
 **************************************************************/
void extract_parallelCandidate(int idx, double *x, double *func_,
                     double *ob_, double *con, double *vio_)  {

  int i;

  double func, ob, vio;

  /* no transfer-in needed */

  /* extract/compute from parallelCandidate[idx]: */
  /*    x[], func, ob, con[], vio */
  for (i=1; i<=nreal; i++) {
    x[i] = parallelCandidate[idx].xvalue[i-1];
  }
  ob = parallelCandidate[idx].obj[0];  
  func = ob;
  vio = 0.0;
  for (i=1; i<=ncon; i++) {
    con[i] = parallelCandidate[idx].constr[i-1];
    func += max(0.0,con[i])/eps[i];
    vio = max(vio,con[i]);
  }

  /* update global obj, constr[], viol */
  obj = ob;
  for (i=1; i<=ncon; i++) {
      constr[i] = con[i];
  }
  viol = vio;

  /* transfer out */
  *func_ = func;
  *ob_ = ob;
  *vio_ = vio;
  
  return;

}
/*eject*/
/**************************************************************
 *   double relative_distance(double *v1, double *v2, int nsize)
 *      relative distance between vectors v1[] and v2[] of 
 *          length nsize using Fortran index convention          
 **************************************************************/
double relative_distance(double *v1, double *v2, int nsize) {

  int i;

  double dis, fac, ratio;
 
  dis = 0.0;
  fac = 0.0;
  for (i=1; i<=nsize; i++) { 
    dis += pow(v1[i]-v2[i],2);
    fac += pow(v1[i],2);
  }

  ratio = sqrt(dis)/(1.0 + sqrt(fac));  

  return ratio;

}
/*eject*/
/**************************************************************
 *   int same_parallelCandidate(double *v1, int idx, int nsize):
 *      compare v1[] and parallelCandidate[idx].xvalue[] 
 *      output: TRUE: v1[] and parallelCandidate[idx].xvalue[]
 *                    are identical
 *              FALSE: else
 *   caution: v1[] indices are i = 1, ..., nsize 
 *            index shift for parallelCandidate[]     
 **************************************************************/
int same_parallelCandidate(double *v1, int idx, int nsize) {

  int i;

  for (i=1; i<=nsize; i++) {
    if (v1[i] != parallelCandidate[idx].xvalue[i-1]) {
      return FALSE;
    }
  }

  return TRUE;

}
/*eject*/
/**************************************************************
 *   int same_vector(double *v1, double *v2, nsize):
 *      compare v1[] and v[] of length nsize 
 *      output: TRUE: v1[] and v2[] are identical
 *              FALSE: else
 *   caution: v1[] and v2[] indices are i = 1, ..., nsize     
 **************************************************************/
int same_vector(double *v1, double *v2, int nsize) {

  int i;

  for (i=1; i<=nsize; i++) {
    if (v1[i] != v2[i]) {
      return FALSE;
    }
  }

  return TRUE;

}
/*eject*/
/**************************************************************
 *   void vector2parallelCandidate(double *v1, int idx, int nsize):
 *      copy vector v1[] of length nsize into 
 *           parallelCandidate[idx].point
 *   caution: v1[] indices are i = 1, ..., nsize 
 *            index shift for parallelCandidate[]           
 **************************************************************/
void vector2parallelCandidate(double *v1, int idx, int nsize) {

  int i;

  for (i=1; i<=nsize; i++) {
    parallelCandidate[idx].xvalue[i-1] = v1[i];
  }

  return;

}
/*eject*/
/**************************************************************
 *   void vector2vector(double *v1, double *v2, nsize): copy
 *      vector v1[] of length nsize into vector v2[]
 *   caution: v1[] and v2[] indices are i = 1, ..., nsize 
           
 **************************************************************/
void vector2vector(double *v1, double *v2, int nsize) {

  int i;

  for (i=1; i<=nsize; i++) {
    v2[i] = v1[i];
  }

  return;

}
/**************************************************************
 *       void xplusdir2z(double *x, double coeff, double *dir, 
 *                       double *z, int nsize)
 **************************************************************/
void xplusdir2z(double *x, double coeff, double *dir, 
                double *z, int nsize){
  int i;
  
  for (i=1; i<=nsize; i++){
    z[i] = x[i] + coeff*dir[i];
  }
}
/************* last record of denparUtil.c ********/
