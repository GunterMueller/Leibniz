/********************* constants ***********************/
#define OBJMAXVALUE 1.0e+07
#define MAX_XSTORE 100
#define LARGEPRIME 3581 /* = 501st prime */
#define MAX_TRIAL 50

/* types of directions */
#define COORD 1
#define DIAG 2
#define DENSE 3
#define MAX_TYPDIR DENSE /* value = last direction type */

/* variables, arrays, and routines for denpar */
/******************** variables ************************/
int nf_max;
int num_funct, num_funct_diff, num_funct_old;
int num_iter, num_iter_diff, num_iter_old;
int num_round;

int index_halton;
int probe_depth;
int type_direction;

int iprint, istop;
double alfa_max, alfa_stop;
double gamma, delta, zeta;
double obj;
double viol;
double bestobj, maxobj;
/*eject*/
/********************* arrays **************************/
double xreal[MAX_VARIABLE+1];
double lb[MAX_VARIABLE+1];
double ub[MAX_VARIABLE+1];
double eps[MAX_CONSTRAINT+1];
double constr[MAX_CONSTRAINT+1];

double direction_matrix[MAX_VARIABLE+1][MAX_VARIABLE+1];
double H[MAX_VARIABLE+1][MAX_VARIABLE+1];

double bestconstr[MAX_CONSTRAINT+1];
double bestxreal[MAX_VARIABLE+1];

double alfa_store[MAX_TYPDIR+1][MAX_VARIABLE+1];
double alfa_max_store[MAX_TYPDIR+1];
/*eject*/
/*************** storage of x vectors *******************/
struct{
  double xreal[MAX_VARIABLE+1];
  double obj;
  double constr[MAX_CONSTRAINT+1];
  double constr_violation;
} typedef Xstore;

Xstore xstore[MAX_XSTORE+1];
int nXstores; /* total number of x vectors stored */
int pointXstore; /* pointer to recently used storage location */
/*eject*/
 /*************** storage of solutions *******************/
struct {
  double point[MAX_VARIABLE+1]; /* trial solution z */
                                /* z = x + alfa*direction */
  double alfa;                 /* alfa used for z */
  double constr[MAX_CONSTRAINT+1]; /* constr[] for z */
  double direction[MAX_VARIABLE+1]; /* direction of trial */
                                    /* includes +/-1 factor */
  double factor;                /* factor of trial */
  double function;              /* function value for z */
  double obj;                   /* obj value for z */
  int pcandidx;                 /* index of parallelCandidate[] */
                                /* with solution values */
                                /* = -1 if paralleCandidate[] */
                                /*         has no such values */
  int success;                  /* TRUE: z beats incumbent x */
                                /* FALSE: z does not beat incumbent */
  double viol;                  /* viol value for z */
} typedef TrialResult; /* one trial of linesearch */

struct{
  double alfa[MAX_TRIAL+1];
  double factor[MAX_TRIAL+1];
} typedef SelectAlfaFactor;

struct{
 TrialResult trial[MAX_TRIAL+1]; /* trial[i] = results of ith trial */
 int decided_factor;           /* factor applied to direction */
 int done_flag;                /* TRUE: done for this case */
 int idx;                      /* index of trial satisfying */ 
                               /* convergence condition */
 int nselect;                  /* number of points to be selected */
 int ntrial;                   /* number of trials */
 double alfa_init;             /* initial alfa */
 double alfa_d_scalar;         /* final alfa_d produced by */
                               /* linesearch for given direction */
 SelectAlfaFactor select;      /* structure for selected alfa[] and */
                               /* factor[] */
} typedef TrialsWithDirection;

TrialsWithDirection all_search[MAX_VARIABLE+1]; 
/* next page has explanation of entries */
/*eject*/
/*
 * for case i:
 * all_search[i].decided_factor = factor applied to direction
 *                                (0.0 means not yet decided)
 * all_search[i].done_flag = TRUE if done
 * all_search[i].idx = index of trial satisfying 
 *                     convergence condition
 * all_search[i].nselect = number of points to be selected
 * all_search[i].ntrial = number of trial points
 * all_search[i].alfa_init = initial alfa
 * all_search[i].alfa_d_scalar = final alfa_d
 *
 * for case i, point j:
 * all_search[i].select.alfa[j] = alfa selected
 * all_search[i].select.factor[j] = factor selected
 *
 * for case i, trial j:
 * all_search[i].trial[j].point[1....n] = point produced
 * all_search[i].trial[j].alfa = 
 *        alfa applied to direction to obtain point 
 * all_search[i].trial[j].constr[1....ncon] = constraint values 
 * all_search[i].trial[j].direction[1...n] = direction, 
 *        includes +/-1 factor
 * all_search[i].trial[j].factor = factor
 * all_search[i].trial[j].function = 
 *        function value associated with point
 * all_search[i].trial[j].obj = objective function
 * all_search[i].trial[j].pcandidx = index of parallelCandidate[]
 *                                   with solution values
 *                                 = -1 if paralleCandidate[]
 *                                         has no such values
 * all_search[i].trial[j].success = 
 *        0 (no improvement) or 
 *        1 (improvement)
 * all_search[i].trial[j].viol = total violation 
 */
/*eject*/
struct {
  double point[MAX_VARIABLE+1]; /* trial solution z */
                                /* z = x + alfa*direction */
  double alfa;                  /* alfa used for z */
  double alfa_d_scalar;         /* final alfa_d produced by */
                                /* linesearch for given direction */
  double direction[MAX_VARIABLE+1]; /* direction of linesearch */
                                    /* includes +/-1 factor */
  double function;              /* function value for z */
  double success;               /* TRUE: z beats incumbent x */
  /* caution: values below valid only if success = TRUE */
  double constr[MAX_CONSTRAINT+1]; /* constr[] for z */
  double obj;                   /* obj value for z */
  double viol;                  /* viol value for z */
} typedef BestResult; /* one trial of linesearch */
BestResult best_search[MAX_VARIABLE+1]; /* best_search[i] = */
                                        /* results for direction i */
double best_search_globalmin;
/*eject*/
struct {
  double point[MAX_VARIABLE+1]; /* current solution */
  int evaluated;        /* TRUE: function, constr[], obj, viol */
                        /*       contain correct values for point[] */
                        /* FALSE: point[] not yet evaluated */
  /* caution: values below valid only if evaluated = TRUE */
  double function;              /* function value */
  double constr[MAX_CONSTRAINT+1]; /* constr[] */
  double obj;                   /* obj value */
  double viol;                  /* viol value */
} typedef CurrentSolution; /* retained solution */
CurrentSolution current_solution; /* initial solution or convex */
                      /* combination of best_search[] solutions */
struct {
  int begin;              /* starting index i of active directions */
  int end;                /* last index i of active directions */
  int size;               /* number of a active directions */
  int progress;           /* TRUE: improved solution was found */
                          /*       during current iteration */
} typedef Restriction; /* restriction of directions */
Restriction restriction; 
                                 
/* output files created by output_history() */
char outputfile1[MAX_ENTRY];
char outputfile2[MAX_ENTRY];
FILE *output1;
FILE *output2;
FILE *fid;

/* all routines are included in sample.lb.c */

/************* last record of denpar.h **********/
