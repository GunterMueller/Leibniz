/* definition of problems */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"

/************************************************************
 *  subroutines in this file:
 *    void queryBlackBox(char *name, double *xreal, 
 *                          double *obj, double *constr)
 *    void readOutbox(char *name, double *xreal, 
 *                    double *obj, double *constr);
 *    void writeInbox(char *name, double *xreal, 
 *                    double *obj, double *constr);
 ************************************************************/
/*eject*/
/*************************************************************
 * void queryBlackBox(char *name, double *xreal, 
 *                    double *obj, double *constr)
 *      evaluate given xreal vector for all corners defined
 *      by state[], using inbox/outbox files for black box
 *      return final obj and constr values
 *************************************************************/
void queryBlackBox(char *name, double *xreal, 
                   double *obj, double *constr) {

  char cmnd[MAX_ENTRY];

  /* write inbox for black box */
  /* initialize outbox file */
  writeInbox(name,xreal,obj,constr);

  /* query black box */
  sprintf(cmnd,"%s %s %s/%s %s/%s",
               gOption.blackbox,
               name,
               gOption.tempdir,gOption.inbox,
               gOption.tempdir,gOption.outbox);
  if (system(cmnd) != 0) {
    printf(
    "\n queryBlackBox: program %s failed", cmnd);
    exit(1);
  }

  /* read outbox file produced by black box */
  /* define obj[] and constr[] so that they follow gencc/nsga */
  /* convention, where obj is minimized and constraints >= 0 */
  readOutbox(name,xreal,obj,constr);

  return;

}
/*eject*/
/*************************************************************
 * void readOutbox(char *name, double *xreal, 
 *                double *obj, double *constr)
 *      read outbox file produced by black box
 *      if outbox has more than one line: interpret as
 *        produced by corners, and retain worst case
 *************************************************************/
void readOutbox(char *name, double *xreal, 
                double *obj, double *constr) {

  int i, j;

  double x;

  char lineread[MAXLEN];

  char outboxfile[MAX_ENTRY];
  FILE *outboxfil;

  sprintf(outboxfile,"%s/%s",gOption.tempdir,gOption.outbox);

  /* initialize objective and constraint values */
  for (j=0; j<nobj; j++) {
    if (strcmp(objective[j].direction,"min") == 0) {
      objective[j].value = -INF;
    } else {
      objective[j].value = INF;
    }
  }
  for (j=0; j<ncon; j++) {
    if (strcmp(constraint[j].inequality,"<=") == 0) {
      constraint[j].value = -INF;
    } else {
      constraint[j].value = INF;
    }
  }
/*eject*/
  /* read outbox file and place obj and constraint values into */
  /* objective[] and constraint[] structures using external */
  /* definitions for objective direction and constraint type */
  if ((outboxfil = fopen(outboxfile,"r")) == NULL) {
    printf("\n readOutbox: cannot open completed output file %s",
           outboxfile);
    exit(1);
  }

  /* read 'WARNING', or obtain obj and constr values */
  while (fgets(lineread,MAXLEN,outboxfil) != NULL) { /* while #2 */

    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0'; 
      i--;
    }
    /* skip over empty or '#" lines */
    if ((lineread[0] == '\0') || (lineread[0] == '#')) {
      continue;
    }
    if (strncmp(lineread,"WARNING",7) == 0) {
      /* black box failed */
      printf("\n queryBlackBox: black box failed, generation = %d",
             generationCount);
      exit(1);
    }

    /* have nonempty, noncomment line with obj and constr values */
    evaluationCount++;
    tokenize(lineread);
    if (nTokens < nobj+ncon+nreal) {
      printf("\n queryBlackBox: lineread = %s has %d <",
             lineread, nTokens);
      printf(" nobj+ncon+nreal = %d+%d+%d = %d entries",
             nobj, ncon, nreal, nobj+ncon+nreal);
      exit(1);
    }
/*eject*/
    /* update objective values based on obj direction */
    for (j=0; j<nobj; j++) {
      x = atof(token[j]);
      if (strcmp(objective[j].direction,"min") == 0) {
          objective[j].value = 
             max(objective[j].value,x);
      } else {
          objective[j].value = 
             min(objective[j].value,x);
      }
    }     

    /* update constraint values based on inequality type */
    for (j=0; j<ncon; j++) {
      x = atof(token[j+nobj]);
      if (strcmp(constraint[j].inequality,"<=") == 0) {
          constraint[j].value = 
             max(constraint[j].value,x);
      } else {
          constraint[j].value = 
             min(constraint[j].value,x);
      }
    }

  } /* end while #2*/

  fclose(outboxfil);
/*eject*/
  /* define obj[] and constr[] from objective[] and constraint[] */
  /* structures so that obj[] and constr[] follow gencc/nsga */
  /* convention, where obj is minimized and constraints >= 0 */
  for (j=0; j<nobj; j++) {
    if (strcmp(objective[j].direction,"min") == 0) {
      obj[j] = objective[j].value;
    } else {
      obj[j] = -objective[j].value;
    }
  }
  for (j=0; j<ncon; j++) {
    if (strcmp(constraint[j].inequality,"<=") == 0) {
      constr[j] = constraint[j].rhs - constraint[j].value;
    } else {
      constr[j] = -constraint[j].rhs + constraint[j].value;
    }
    /* declare constr[j] within constrTolerance[j] as feasible */
    if ((constr[j] < 0) && (constr[j] >= -constrTolerance[j])) {
      constr[j] = 0;
    }
  }

  return;

}
/*eject*/
/*************************************************************
 * void writeInbox(char *name, double *xreal, 
 *                double *obj, double *constr)
 *      write inbox file for black box
 *************************************************************/
void writeInbox(char *name, double *xreal, 
                double *obj, double *constr) {

  int j, k;

  char inboxfile[MAX_ENTRY];
  char outboxfile[MAX_ENTRY];
  FILE *inboxfil;
  FILE *outboxfil;

  sprintf(inboxfile,"%s/%s", gOption.tempdir,gOption.inbox);
  sprintf(outboxfile,"%s/%s",gOption.tempdir,gOption.outbox);
/*eject*/
  /* construct inbox file */
  if ((inboxfil = fopen(inboxfile,"w")) == NULL) {
    printf("\n writeInbox: cannot open input file %s",
         inboxfile);
    exit(1);
  }
  if ((outboxfil = fopen(outboxfile,"w")) == NULL) {
    printf("\n writeInbox: cannot open initial output file %s",
           outboxfile);
    exit(1);
  } 
  /* write warning message on outbox file */
  fprintf(outboxfil,"WARNING no results in this file");
  fclose(outboxfil);
/*eject*/
  if (nCorners == 0) { 
    /* there are no corners */
    for (j=0; j<nreal; j++) {
      fprintf(inboxfil,"%g\t",xreal[j]);
    }
    fprintf(inboxfil,"\n");
  } else { 
    /* for each corner case, write a record with xreal vector */
    /* and the corner string */
    for (k=0; k<nCorners; k++) {
      for (j=0; j<nreal; j++) {
        fprintf(inboxfil,"%g\t",xreal[j]);
      }
      fprintf(inboxfil," %s\n",corner[k]);
    }
  } /* end if nCorners == 0, else */

  fclose(inboxfil);

  return;

}
/********* last record of queryblackbox.lb.c **********/
