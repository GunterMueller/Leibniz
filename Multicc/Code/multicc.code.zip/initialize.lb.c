/* Data initialization routines */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"

/* CAUTION: All arrays are used with starting index = 0 */
/* in agreement with NSGA-II code */

/***************************************************************
 *
 * subroutines in this file:
 *   void initialize_pop (population *pop)
 *   void initialize_one_pop (population *pop)
 *   void initialize_ind (individual *ind)  
 *   void initializeGradCon()
 ***************************************************************/
/*eject*/
/* top routine for creating initial population */
/* via kmeans++ selection */

void initialize_pop (population *pop) {

  int minpick, maxpick;

  /* check that MAX_POP is large enough */
  if (popsize > MAX_POP) {
    printf(
    "\n Must increase MAX_POP = %d in sample.lb.h to %d, case 1\n",
           MAX_POP, popsize);
    exit(1);
  }

  /* check that variables are not binary */
  if (nbin != 0) {
    printf("\n Current version does not handle binary vectors\n");
    exit(1);
  }

  /* initialize counts and arrays */
  generationCount = 1;
  evaluationCount = 0;
  stalledGenerationCount = 0;
  gNumOpenFiles = 0;
  nCandidates = 0;
  nParentCandidates = 0;
  nPriorCandidates = 0;
  curPriorCandidate = 0;
  initPop.nAccept = 0;
  initPop.nReject = 0;
  initPop.nTotal = 0;
/*eject*/
  if (nInputCandidates > popsize) {
    /* too many input candidates */
    printf("\n initialize_pop: nInputCandidates = %d > popsize = %d",
           nInputCandidates, popsize);
    exit(1);
  }
  if (nInputCandidates > 0) {
    /* inputCandidate[] has already been evaluated */
    /* and keepFlag = TRUE; there are no infeasible, dominated, */
    /* duplicated cases */

    /* place inputCandidate[] into candidate[] */
    someCandidate2candidate(inputCandidate, nInputCandidates,
                            &nCandidates);
/*eject*/
    /* at this point, all candidate[] have obj, constr values, */
    /* and keepFlag = TRUE */

    /* increase popsize approximately by nInputCandidates */
    popsize += 4*((nInputCandidates+3)/4);
  /* check that MAX_POP is large enough */
  if (popsize > MAX_POP) {
    printf(
    "\n Must increase MAX_POP = %d in sample.lb.h to %d, case 2\n",
           MAX_POP, popsize);
    exit(1);
  }
    /* adjust minSampleSize for nsga */
    if (strcmp(methodName,"nsga") == 0) { 
      minSampleSize = popsize;
    }
    /* adjust sampleSize */
    sampleSize = popsize; /* used for first generation */

  } /* end if nInputCandidates > 0 */
/*eject*/
  /* define curPopsize */
  curPopsize = popsize;
  /* obtain one population, store in candidate[] */

  /* randomly generate one population */
  initialize_one_pop (pop);

  /* nProcessors > 0: evaluate population and add to candidate
   * else: add population to candidate
   * both cases involve rounding of xvalue[] for nint cases
   * and the added candidate[] have keepFlag = FALSE
   */
  evaluate_parallelPop2candidate(pop);
  /* nCandidates now is = total number of candidates
   * caution: if nProcessors > 0: all candidate[] have been evaluated
   *                and have correct obj, constr, and
   *                constr_violation, regardless of
   *                keepflag value
   *          else: keepFlag = TRUE: case evaluated
   *                         = FALSE: case no evaluated
   * these facts are used in subsequent kmeans() execution
   */
/*eject*/
  /* select and evaluate popsize cases for initial population from */
  /* candidate[], using kmeans++ */
  minpick = popsize - nInputCandidates;
  maxpick = popsize - nInputCandidates;
  if (minpick > 0) {
    pickCount = kmeans(pop,minpick, maxpick);
  } else {
    pickCount = 0;
  }
  /* add the selected candidate[] cases, which have keepFlag = TRUE,
   * to priorCandidate[], which is a circular file
   * regardless of nProcessor value, all such candidate[] cases
   * have been evaluated, either 
   *   prior to kmeans() (case: nProcessors > 0), or
   *   during kmeans() (case: nProcessors = 0) 
   */
  candidateTrue2priorCandidate();

  /* store the selected candidates, with keepFlag = TRUE, */
  /* in population pop */
  /* redefine curPopsize so it is correct for population */
  candidateTrue2population(pop);

  if ((curPopsize != popsize) || (nTrueKeepFlag != popsize)) {
    printf("\nSelected %d candidates instead of required %d\n",
           curPopsize, popsize);
    exit(1);
  }

  return;

}
/*eject*/
/****************************************************
 * initialize_one_pop (population *pop): initialize one 
 *        population randomly
 ****************************************************/
void initialize_one_pop (population *pop) {

  int i, j;

  j = 0; /* DEBUG */
  for (i=0; i<curPopsize; i++) {
    initialize_ind (&(pop->ind[i]));
    j++; /* DEBUG */
  }

  return;

}
/*eject*/
/****************************************************
 * initialize_ind (individual *ind): initialize an individual
 * randomly
 ****************************************************/
void initialize_ind (individual *ind) {

  int i, j, k;

  if (nreal!=0) {
    for (i=0; i<=MAX_INITIALTRIAL; i++) {

      for (j=0; j<nreal; j++) {
        ind->xreal[j] = rndreal (min_realvar[j], max_realvar[j]);
      }
      /* apply filters except if i = MAX_INITIALTRIAL, where */
      /* the case is unconditionally accepted */
      if (i < MAX_INITIALTRIAL) {
        /* check decideAcceptance() */
        if (decideAcceptance(ind->xreal) == TRUE) {
          /* xreal passes acceptance test of decideAcceptance(), */
          /* which uses accept/rejectCandidate[] if singleminout */
          /* is specified */ 
          break;
        }
      }
    } /* end for i */
  }

  if (nbin!=0) {
    for (j=0; j<nbin; j++) {
      for (k=0; k<nbits[j]; k++) {
        if (randomperc() <= 0.5) {
          ind->gene[j][k] = 0;
        } else {
        ind->gene[j][k] = 1;
        }
      }
    }
  }

  return;

}

/******last record of initialize.lb.c *********************/
