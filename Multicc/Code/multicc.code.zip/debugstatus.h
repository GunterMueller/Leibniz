# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "denpar.h" 

