/* Routine for evaluating population members  */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"
/************************************************************
 *  subroutines in this file:
 *       void evaluate_pop (population *pop)
 *       void estimateObjConstr()
 *       void evaluate_candidate(population *pop)
 *       void evaluate_one_pop (population *pop)
 *       void evaluate_ind (individual *ind)
 *       void evaluate_parallelPop2Candidate(population *pop)
 *       int  finalObjConstr(population *pop)
 *       void getCandidateMinMax()
 *       void getObjConstrFromPrior()
 *       void getPopulationMinMax(population *pop)
 *       void getPriorCandidateMinMax()
 *       void reduceAboveObjBoundCandidate()
 *       int  reduceInfeasibleDominatedDuplicateCandidate()
 *       int  testFeasibleSolution(population *pop)
 ************************************************************/
/*eject*/
/*************************************************************
 * evaluate_pop (population *pop): evaluate objective function 
 *      values and constraints for a population 
 *************************************************************/
void evaluate_pop (population *pop) {

  int minpick, maxpick, n;

  /* define curPopsize */
  curPopsize = popsize;
  nCandidates = 0;

  /* nProcessors > 0: evaluate population and add to candidate */
  /* else:            add population to candidate[] */
  /* both cases involve rounding of xvalue[] for nint cases */
  evaluate_parallelPop2candidate(pop);
   /* keepFlag = FALSE for all candidate[]
   * caution: if nProcessors > 0: all candidate[] have been evaluated
   *                              and have correct obj, constr, and
   *                              constr_violation
   *          else: candidate[] not yet evaluated
   *          these facts are used below, see kmeans()
   *          gencc: see usage in kmenas()
   *          nsga: see directly below
   */
/*eject*/
  /* evaluate candidate[] depending on method: nsga or gencc */

  if (strcmp(methodName,"nsga") == 0) {

    /* method: nsga */
    if (nProcessors > 0) { 
      /* parallel processing: from above step, */
      /* have already obj and constr values */
      /* so need only change keepFlag to TRUE */
      for (n=0; n<nCandidates; n++) {
        candidate[n].keepFlag = TRUE;
      } 
    } else { 
      /* sequential processing */
      evaluate_one_pop(pop);
      nCandidates = 0;
      population2candidate(pop,&nCandidates,TRUE); 
    }

    /* save feasible, undominated candidate[] in priorCandidate[] */
    candidateTrue2priorCandidate();
/*eject*/
  } else { 
  /* method: gencc */

    minpick = sampleSize;
    maxpick = popsize;
    pickCount = kmeans(pop, minpick, maxpick);

    if (pickCount <= 0) {
      printf("\n Could not pick any candidate[], wich implies ");
      printf("that all candidate[] occur in priorCandidate[]");
    } else {
      /* save feasible, undominated candidate[] in priorCandidate[] 
       * all such candidate[] cases have been evaluated, either 
       *   prior to kmeans() (case: nProcessors > 0), or
       *   during kmeans() (case: nProcessors = 0) 
       */
      candidateTrue2priorCandidate();
    } /* end if pickCount <= 0, else */

    /* determine min/max for priorCandidate[].obj[] and */
    /* priorCandidate[].constr[] */
    getPriorCandidateMinMax();

    /* estimate obj and constr values for candidate[] with */
    /* keepFlag = FALSE using priorCandidate[], and change keepFlag */
    /* to TRUE */
    /* update nTrueKeepFlag, nFalseKeepFlag */
    estimateObjConstr();

  } /* end if strcmp(methodName,"nsga") == 0, else */
/*eject*/
  /* transfer all candidate[], which do have keepFlag = TRUE, */
  /* to population */
  candidateTrue2population(pop);

  /* check counts */
  if (curPopsize != popsize) {
    printf(
     "\nCandidate count %d is not equal to required population %d\n",
           curPopsize, popsize);
    exit(1);
  }

  return;

}
/*eject*/
/*************************************************************
 * void estimateObjConstr(): estimate obj and constr values
 *      for candidate[] with keepFlag = FALSE using nearest
 *      neighbor in priorCandidate[]
 *************************************************************/
void estimateObjConstr() {

  int i, j, minidx, n;
  double delta, distsqd, mindistsqd;

    nEstimates = 0;

    for (n=0; n<nCandidates; n++) {

    /* skip keepFlag = TRUE case */
      if (candidate[n].keepFlag == TRUE) {
        continue;
      }

      nEstimates++;
      mindistsqd= INF;
      minidx = -1;
      for (i=0; i<nPriorCandidates; i++) {
        distsqd = distanceSquared2vectors(candidate[n].xvalue,
                                           priorCandidate[i].xvalue,  
                                           min_realvar,
                                           max_realvar,
                                           nreal);
        if (distsqd < mindistsqd) {
          minidx = i;
          mindistsqd = distsqd;
          if (mindistsqd == 0.0) {
            nEstimates--;
            break;
          }
        }
      } /* end for i */

      if (minidx < 0) {
        printf(
            "\nError: Min distance prior candidate does not exist\n");
        printf(
            "       for candidate[%d]\n",n);
        exit(1);
      }

      /* use priorCandidate[minidx] obj and constr function values */
      for (j=0; j<nobj; j++) {
        candidate[n].obj[j] = priorCandidate[minidx].obj[j];
        /* adjust obj value if xvalues are different */
        /* for candidate[n] and priorCandidate[minidx] */
        if (mindistsqd > 0) { /* xvalues are distinct */
          delta = 0.1 * (maxvalue.obj[j]-minvalue.obj[j]);
          candidate[n].obj[j] += delta;
        } 
      } /* end for j */
      candidate[n].constr_violation = 0.0;
      for (j=0; j<ncon; j++) {
        candidate[n].constr[j] = priorCandidate[minidx].constr[j];
        if (priorCandidate[minidx].constr[j] < 0.0) {
          /* adjust constr value if xvalues are different */
          /* for candidate[n] and priorCandidate[minidx] */
          if (mindistsqd > 0) { /* xvalues are distinct */
            delta = 0.1 * (maxvalue.constr[j]-minvalue.constr[j]);
            candidate[n].constr[j] -= delta;
          }
        }
        if (candidate[n].constr[j] < 0) {
          candidate[n].constr_violation += candidate[n].constr[j];
        }
      } /* end for j */
      candidate[n].keepFlag = TRUE;
      candidate[n].distanceSquared = 
              priorCandidate[minidx].distanceSquared;
      
    } /* end for n */

    nTrueKeepFlag = nCandidates;
    nFalseKeepFlag = 0;

    return;

}
/*eject*/
/*************************************************************
 * void evaluate_candidate(population *pop): 
 *        evaluate all candidate[] with keepFlag = FALSE
 *        to obtain obj and constr values
 *        assign keepFlag = TRUE to evaluated cases
 *        uses population pop in evaluation process
 *************************************************************/
void evaluate_candidate(population *pop) {

  int n;

  for (n=0; n<nCandidates; n++) {
    if (candidate[n].keepFlag == FALSE) {
      /* transfer candidate[n] to population */
      candidateSingle2population(pop, n);

      /* evaluate population, which has curPopsize = 1 */
      evaluate_one_pop (pop);

      /* insert obj and constr values of population into
       * candidate[n]
       * assign keepFlag = TRUE
       *        distanceSquared = INF */
      population2candidateSingle(pop, n);
    }
  }

  return;

}
/*eject*/
/*************************************************************
 * void evaluate_one_pop (population *pop): evaluate objective 
 *        function values and constraints for population of size
 *         curPopsize 
 *************************************************************/
void evaluate_one_pop (population *pop) {

  int i;

    for (i=0; i<curPopsize; i++) {
      evaluate_ind (&(pop->ind[i]));
    }

    return;

}
/*eject*/
/*************************************************************
 * void evaluate_ind (individual *ind): evaluate objective 
 *        function values and constraints for an individual
 *************************************************************/
void evaluate_ind (individual *ind) {

  int j, juse;

  juse = 0; /* to suppress compiler warning */

  /* use nobjEvaluate for evaluation of xvalue */
  nobj = nobjEvaluate;

  /* compute obj and constr values */
  if (strcmp(gOption.input,"NOINPUTFILE") != 0) {
    queryBlackBox(problemName,ind->xreal,ind->obj,ind->constr);
  } else {
    test_problem (TRUE, problemName, ind->xreal, 
                    ind->obj, ind->constr);
    /* first parameter usage:
     *   TRUE: compute obj, constr values
     *   FALSE: define nreal, nbin, nobj, ncon,
     *                 min_realvar[], max_realvar[]
     */
  }
/*eject*/
  if ((gOption.objrange == TRUE) && (nobjSolve == 1)) {
    /* compute weighted sum of objs */
    /* for single function minimization */
    /* find index juse of single function */
    for (j=0; j<nobj; j++) {
      if (objFactor[j] != 0.0) {
        juse = j;
        break;
      }  
    }
    /* compute weighted sum for positive objrange values */
    /* large factor WEIGHTED_SUM_FACTOR gives weight to obj[j], */
    /* j != juse, so that effectively all such obj[j] are first */
    /* minimized, and then obj[juse] is minimized */
    if (objRange[juse] > 0.0) {
      for (j=0; j<nobj; j++) {
        if ((j != juse) && (objRange[j] > 0.0)) {
          ind->obj[juse] += WEIGHTED_SUM_FACTOR * 
                            (objRange[juse]/objRange[j]) * 
                            ind->obj[j];
        }  
      }
    }
  }
/*eject*/
  /* if obj factors are used, apply them to obj[] */
  /* and eliminate cases with factor = 0 */
  if (gOption.objfactor == TRUE) {
    juse = 0;
    for (j=0; j<nobj; j++) {
      if (objFactor[j] != 0.0) {
        ind->obj[juse] = ind->obj[j] * objFactor[j];
        juse++;
      }
    }
    if (juse != nobjSolve) {
      printf("\n evaluate_ind: nobj = %d != juse = %d", nobj, juse);
      exit(1);
    }
  }

  /* restore nobj = nobjSolve for solution process */
  nobj = nobjSolve;


  /* compute constraint violation */
  if ((ncon==0) || (gOption.ignoreconstraint == TRUE)) {
    ind->constr_violation = 0.0;
  } else {
    ind->constr_violation = 0.0;
    for (j=0; j<ncon; j++) {
      if (ind->constr[j]<0.0) {
        ind->constr_violation += ind->constr[j];
      }
    }
  }

  return;

}
/*eject*/
/*************************************************************
 * void evaluate_parallelPop2candidate(population *pop): 
 *   if nProcessores > 0: evaluate population via parallelCandidate[]
 *       - copy population into parallelCandidate[], including 
 *             rounding of xvalue[]
 *       - evaluate parallelCandidate[]
 *       - add parallelCandidate to candidate[]  
 *   else: transfer population into candidate[] without any
 *         evaluation
 *   both cases: round xreal[] of population array for the
 *        nint cases before transfer
 *   caution: results of population are added to candidate[],
 *            so nCandidates must be correctly initialized
 *            before this routine is called       
 *************************************************************/
void evaluate_parallelPop2candidate(population *pop) {

  if (nProcessors > 0) {

    /* evaluate population via parallelCandidate[]:
     *   copy population into parallelCandidate[], including
     *         rounding of xvalue[]
     *   evaluate parallelCandidate[]
     *   add parallelCandidate to candidate[]
     */
    population2parallelCandidate(pop,FALSE);
    evaluate_parallelCandidate(methodName,FALSE);
    someCandidate2candidate(parallelCandidate,
                            nParallelCandidates,&nCandidates);
  } else { 
    /* add records from population to candidate[] */
    /* includes rounding of xvalue[] */
    population2candidate(pop, &nCandidates, FALSE);
  }   
/*eject*/
  /* nCandidates now is = total number of candidates
   * caution: if nProcessors > 0: all candidate[] have been evaluated
   *                              and have correct obj, constr, and
   *                              constr_violation, regardless
   *                              of keepFlag value
   *          else: if candidate flag = TRUE:  evaluated
   *                                  = FALSE: not yet evaluated
   * these facts must be considered in subsequent execution
   */

  return;

}
/*eject*/
/*************************************************************
 * int finalObjConstr(population *pop): insert correct obj
 *     and constr values into final population
 * return: TRUE if there are feasible individuals
 *         FALSE if all individuals are infeasible
 *************************************************************/
int finalObjConstr(population *pop) {

  int flag, j, n;

  /* store population in candidate[] with keepFlag = TRUE, which */
  /* here means that correctness of obj and constr values has not */
  /* been checked */
  nCandidates = 0;
  curPopsize = popsize;
  population2candidate(pop, &nCandidates, TRUE);

  /* get obj and constr values from priorCandidate[] if  */
  /* candidate[].xvalue[] occurs in priorCandidate[] */
  /* define nFalseKeepFlag and nTrueKeepFlag */
  getObjConstrFromPrior();
/*eject*/
  if (nTrueKeepFlag > 0) {

    /* transfer selected candidates, which have keepFlag = TRUE */
    /* and thus must be evaluated, to population */
    candidateTrue2population(pop);

    if (nProcessors > 0) {
      /* copy population to parallelCandidate[] */
      population2parallelCandidate(pop,FALSE);
      /* evaluate parallelCandidate[] */
      evaluate_parallelCandidate("nsga",TRUE);
      /* copy parallelCandidate to candidate[] with keepFlag = TRUE */
      parallelCandidate2candidateTrue();
    } else {
      /* evaluate population with size = curPopsize */
      evaluate_one_pop (pop);
      /* insert obj and constr values of population into candidate[] */
      /* cases with keepFlag = TRUE */
      population2candidateTrue(pop);
    }

  } /* end if nTrueKeepFlag > 0 */

  /* store final step evaluation count */
  finalStepEvaluationCount = nTrueKeepFlag;

  /* add priorCandidate[] to candidate[] */
  someCandidate2candidate(priorCandidate, 
                          nPriorCandidates,
                          &nCandidates);
/*eject*/
  /* reduce candidate[] by enforcing objGoalInitial[] and */
  /* objBoundInitial[] */
  for (n=0; n<nCandidates; n++) {
    candidate[n].keepFlag = TRUE;
    for (j=0; j<nobj; j++) {
      if ((candidate[n].obj[j] < objGoalInitial[j]) ||
          (candidate[n].obj[j] > objBoundInitial[j])) {
        candidate[n].keepFlag = FALSE;
        break;
      } 
    }
  }
  candidateTrue2someCandidate(priorCandidate,&nPriorCandidates);
  nCandidates = 0;
  someCandidate2candidate(priorCandidate, 
                          nPriorCandidates,
                          &nCandidates);
  /* at this point, all candidate[] have keepFlag = TRUE */

  /* eliminate infeasible, dominated, duplicate candidates */
  /* flag = TRUE if there are feasible candidate[] */
  /*        FALSE if all candidate[] are infeasible */
  flag = reduceInfeasibleDominatedDuplicateCandidate(); 
   
  /* move candidate[] with keepFlag = TRUE to population */
  candidateTrue2population(pop);
  popsize = curPopsize;
  /* caution: popsize may not be a multiple of 4 */

  return flag;

}
/*eject*/
/*************************************************************
 * void getCandidateMinMax(): determine min/max for obj, constr, 
 *                            xvalue, of candidate[]
 *************************************************************/
void getCandidateMinMax() {

  int j, n;

  for (j=0; j<nobj; j++) {
    candidateMinvalue.obj[j] = INF;
    candidateMaxvalue.obj[j] = -INF;
    for (n=0; n<nCandidates; n++) {
      candidateMinvalue.obj[j] = 
         min(candidateMinvalue.obj[j],candidate[n].obj[j]);
      candidateMaxvalue.obj[j] = 
         max(candidateMaxvalue.obj[j],candidate[n].obj[j]);
    }
  }

  for (j=0; j<ncon; j++) {
    candidateMinvalue.constr[j] = INF;
    candidateMaxvalue.constr[j] = -INF;    
    for (n=0; n<nCandidates; n++) {
      candidateMinvalue.constr[j] = 
         min(candidateMinvalue.constr[j],candidate[n].constr[j]);
      candidateMaxvalue.constr[j] = 
         max(candidateMaxvalue.constr[j],candidate[n].constr[j]);
      
    }
  }
/*eject*/
  /* nsga/gencc: constr_violation <= 0 */
  /* hence max constr_violation value is closest to feasibility */
  candidateMaxvalue.constr_violation = -INF;
  for (n=0; n<nCandidates; n++) {
     candidateMaxvalue.constr_violation  = 
        max(candidate[n].constr_violation,    
            candidateMaxvalue.constr_violation);
  }

  for (j=0; j<nreal; j++) {
    candidateMinvalue.xvalue[j] = INF;
    candidateMaxvalue.xvalue[j] = -INF;
    for (n=0; n<nCandidates; n++) {
      candidateMinvalue.xvalue[j] = 
         min(candidateMinvalue.xvalue[j],candidate[n].xvalue[j]);
      candidateMaxvalue.xvalue[j] = 
         max(candidateMaxvalue.xvalue[j],candidate[n].xvalue[j]);
    }
  }

  return;

}
/*eject*/
/*************************************************************
 * void getObjConstrFromPrior(): get obj and constr values 
 *     from priorCandidate[] if candidate[].xvalue[] occurs 
 *     in priorCandidate[]
 *     input:  candidate[n].keepFlag = TRUE for all n
 *     output: candidate[n].keepFlag 
 *                  = FALSE if correct obj[] and constr[] have been
 *                             obtained from priorCandidate[]
 *                  = TRUE if obj/constr must be determined
 *              nFalseKeepFlag and nTrueKeepFlag
 *************************************************************/
void getObjConstrFromPrior() {

  int flag, j, m, n;

  nTrueKeepFlag = nCandidates;
  nFalseKeepFlag = 0;

  for (n=0; n<nCandidates; n++) {

    for (m=0; m<nPriorCandidates; m++) {

      flag = TRUE;
      for (j=0; j<nreal; j++) {
        if (candidate[n].xvalue[j] != priorCandidate[m].xvalue[j]) {
          flag = FALSE;
          break;
        }
      } /* end for j */

      if (flag == TRUE) {
        /* candidate[n].xvalue[] = priorCandidate[m].xvalue[] */
        /* insert obj and constr values of priorCandidate[m] */
        /* into candidate[n] */
        for (j=0; j<nobj; j++) {
          candidate[n].obj[j] = priorCandidate[m].obj[j];
        }
        for (j=0; j<ncon; j++) {
          candidate[n].constr[j] = priorCandidate[m].constr[j];
        }
        candidate[n].constr_violation = 
             priorCandidate[m].constr_violation;
        candidate[n].keepFlag = FALSE;
        nTrueKeepFlag--;
        nFalseKeepFlag++;    
        break;        
      } /* end if flag == TRUE */

    } /* end for m */

  } /* end for n */

  return;

}
/*eject*/
/*************************************************************
 * void getPopulationMinMax(population *pop): determine min/max
 *      of obj[] and constr[] of a population
 *************************************************************/
void getPopulationMinMax(population *pop) {

  int i, j;

  individual *indd;

  for (j=0; j<nobj; j++) {
    minvalue.obj[j] = INF;
    maxvalue.obj[j] = -INF;
    for (i=0; i<popsize; i++) {
      indd = &(pop->ind[i]);
      minvalue.obj[j] = 
         min(minvalue.obj[j],indd->obj[j]);
      maxvalue.obj[j] = 
         max(maxvalue.obj[j],indd->obj[j]);
    }
  }

  for (j=0; j<ncon; j++) {
    minvalue.constr[j] = INF;
    maxvalue.constr[j] = -INF;
    for (i=0; i<popsize; i++) {
      indd = &(pop->ind[i]);
      minvalue.constr[j] = 
         min(minvalue.constr[j],indd->constr[j]);
      maxvalue.constr[j] = 
         max(maxvalue.constr[j],indd->constr[j]);
    }
  }

  /* nsga/gencc: constr_violation <= 0 */
  /* hence max constr_violation value is closest to feasibility */
  maxvalue.constr_violation = -INF;
  for (i=0; i<popsize; i++) {
    indd = &(pop->ind[i]);
    maxvalue.constr_violation = 
       max(maxvalue.constr_violation,indd->constr_violation);
    }

  return;

}
/*eject*/
/*************************************************************
 * void getPriorCandidateMinMax(): determine min/max for
 *      priorCandidate[].obj[] and priorCandidate[].constr[]
 *************************************************************/
void getPriorCandidateMinMax() {

  int j, n;

  for (j=0; j<nobj; j++) {

    minvalue.obj[j] = INF;
    maxvalue.obj[j] = -INF;
    for (n=nPriorCandidates-1; n>=0; n--) {
      if ((priorCandidate[n].generation >= 
           generationCount - popsize) ||
          (minvalue.obj[j] == maxvalue.obj[j])) {
        minvalue.obj[j] = 
           min(minvalue.obj[j],priorCandidate[n].obj[j]);
        maxvalue.obj[j] = 
           max(maxvalue.obj[j],priorCandidate[n].obj[j]);
      }
    }
  } /* end for j */    
/*eject*/
  for (j=0; j<ncon; j++) {

    minvalue.constr[j] = INF;
    maxvalue.constr[j] = -INF;
    for (n=nPriorCandidates-1; n>=0; n--) {
      if ((priorCandidate[n].generation >= 
           generationCount - popsize) ||
          (minvalue.constr[j] == maxvalue.constr[j])) {
        minvalue.constr[j] = 
           min(minvalue.constr[j],priorCandidate[n].constr[j]);
        maxvalue.constr[j] = 
           max(maxvalue.constr[j],priorCandidate[n].constr[j]);
      }
    }

  } /* end for j */

  return;

}
/*eject*/
/*************************************************************
 * void reduceAboveObjBoundCandidate()
 *  input: candidate[] will all values
 *  output: keepflag = FALSE if candidate has obj[j] > objBound[j]
 *                              for at least one j
 *  all other keeFlag TRUE/FALSE values are not affected
 *************************************************************/
void reduceAboveObjBoundCandidate() {

  int j, n;

  for (n=0; n<nCandidates; n++) {
    for (j=0; j<nobj; j++) {
      if (candidate[n].obj[j] > objBound[j]) {
        candidate[n].keepFlag = FALSE;
        break;
      }
    } 
  }

  return;

}
/*eject*/
/*************************************************************
 * reduceInfeasibleDominatedDuplicateCandidate(): 
 *   if there are are feasible candidates, eliminate all infeasible, 
 *      dominated, duplicate candidates 
 *   if all candidates are infeasible, eliminate all candidates
 *      except for one with max constr_violation value
 *   input: candidate[] with all values
 *   output: keepFlag = TRUE if candidate is kept
 *                    = FALSE if candidate is eliminated
 *   returns: TRUE if there is at least one feasible candidate
 *            FALSE if there are only infeasible candidates
 *************************************************************/
int reduceInfeasibleDominatedDuplicateCandidate() {

  int flag, nflag,j, n;
  double maxinf; /* max infeasible constr_violation value */
  int ninf; /* = index of candidate[] with maxinf value */
            /*      if all candidates are infeasible */
            /* = -1 if there is a feasible candidate */

  /* candidate[] is assumed to have correct obj and constr values, */
  /* including constr_violation */

  /* define all keepFlag = TRUE */
  for (n=0; n<nCandidates; n++) {
    candidate[n].keepFlag = TRUE; 
  }
/*eject*/
  /* check if there is a feasible solution */
  /* if not, select infeasible solution with constr_violation */
  /* closest to 0 */
  nTrueKeepFlag = nCandidates;
  nFalseKeepFlag = 0;
  ninf = 0;
  maxinf = -INF;
  for (n=0; n<nCandidates; n++) {
    if (candidate[n].constr_violation < 0) {
      candidate[n].keepFlag = FALSE;
      nTrueKeepFlag--;
      nFalseKeepFlag++; 
      if ((ninf != -1) &&(maxinf < candidate[n].constr_violation)) {
        maxinf = candidate[n].constr_violation;
        ninf = n;
      }
    } else {
      ninf = -1;
    }
  }
  if (ninf != -1) {
    /* there are only infeasible candidate[] */
    /* select candidate[ninf] */
    candidate[ninf].keepFlag = TRUE;
    nTrueKeepFlag = 1;
    nFalseKeepFlag = nCandidates-1;
    return FALSE;
  }
/*eject*/
  /* eliminate dominated cases */
  for (n=0; n<nCandidates; n++) {
    if (candidate[n].keepFlag == FALSE) {
      continue;
    }
    /* check if candidate[n] is dominated by another candidate[i] */
    for (nflag=0; nflag<nCandidates; nflag++) {
      if ((nflag == n) || (candidate[nflag].keepFlag == FALSE)) {
        continue;
      }
      flag = TRUE;
      for (j=0; j<nobj; j++) {
        if (candidate[n].obj[j] < candidate[nflag].obj[j]) {
          /* candidate[n] is not dominated by candidate[nflag] */
          flag = FALSE;
          break;
        }
      }
      if (flag == TRUE) {
        /* candidate[n] is dominated by candidate[nflag] */
        candidate[n].keepFlag = FALSE;
        nTrueKeepFlag--;
        nFalseKeepFlag++;
        break;  
      }
    } /* end for nflag */
  } /* end for n */ 
/*eject*/
  /* eliminate duplicate candidate[] */
  for (n=0; n<nCandidates-1; n++) {
    if (candidate[n].keepFlag == FALSE) {
      continue;
    }
    for (nflag=n+1; nflag<nCandidates; nflag++) {
      if (candidate[nflag].keepFlag == FALSE) {
        continue;
      }
      flag = TRUE;
      for (j=0; j<nreal; j++) {
        if (candidate[n].xvalue[j] != candidate[nflag].xvalue[j]) {
          flag = FALSE;
          break;
        }
      }
      if (flag == TRUE) {
        candidate[n].keepFlag = FALSE;
        nTrueKeepFlag--;
        nFalseKeepFlag++; 
        break;        
      }
    } /* end for nflag */
  } /* end for n */

  return TRUE;

}
/*eject*/
/*************************************************************
 * testFeasibleSolution(population *pop):
 *   return TRUE if population pop has a feasible solution
 *          FALSE else
 *************************************************************/
int testFeasibleSolution(population *pop) {

  int i;
  
  individual *indd;

  for (i=0; i<curPopsize; i++) {
    indd = &(pop->ind[i]);
    if (indd->constr_violation == 0.0) {
      return TRUE;
    }
  }

  return FALSE;

}
/*********last record of eval.lb.c *******************/
