/* kmeans routines */
# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *       int kmeans(population *pop, int minpick, int maxpick)
 *       int dominate(double *xobj, double xconstr_violation,
                      double *yobj, double yconstr_violation)
 **************************************************************/
/*eject*/
/**************************************************************
 *   int kmeans(population *pop, int minpick, int maxpick): 
 *                select at least minpick and at most maxpick
 *                records from candidate[]
 *                using kmeans++ algorithm and priorCandidate[]
 *                input: candidate[n].keepFlag = FALSE means
 *                       not yet selected
 *                       caution: if nProcessors > 0: all candidate[]
 *                                have already been evaluated
 *                                else: candidate[n].keepFlag = FALSE
 *                                means not yet evaluated
 *                output:candidate[n].keepFlag = TRUE means
 *                       candidate[n] has been selected and evaluated
 **************************************************************/
int kmeans(population *pop, int minpick, int maxpick) {

  int dominateflag, progressflag, flag, i, ip, n, nselect;

  double distsqd, partialsum, squaresum, thresh;

  if (minpick > maxpick) {
    printf("\nkmeans: minpick = %d > maxpick = %d\n",
           minpick, maxpick);
    exit(1);
  }

  if (minpick < 1 || maxpick > nCandidates) {
    printf("\nkmeans: cannot select between minpick = %d and ", 
           minpick);
    printf("n         maxpick = %d cases out of %d candidates\n",
           maxpick,nCandidates);
    exit(1);
  }

  /* if generationCount = 1 and nInputCandidates > 0, */
  /* update min distances of candidate[] using inputCandidate[] */
  /* note: inputCandidate[] has been copied into candidate[] */
/*eject*/
  if ((generationCount == 1) && (nInputCandidates > 0)) {

    for (n=0; n<nCandidates; n++) {
      for (i=0; i<nInputCandidates; i++) {
        /* get squared distance of scaled vectors */
        distsqd =  distanceSquared2vectors(candidate[n].xvalue,
                                           inputCandidate[i].xvalue,  
                                           min_realvar,
                                           max_realvar,
                                           nreal);
        candidate[n].distanceSquared = 
           min(candidate[n].distanceSquared,distsqd);
      } /* end for i */
    } /* end for n */

}
/*eject*/
  /* update min distances of candidate[] using priorCandidate[] */
  /* note: nPriorCandidates > 0 implies generationCount > 1 */

  if (nPriorCandidates > 0) {

    for (n=0; n<nCandidates; n++) {
      for (i=0; i<nPriorCandidates; i++) {
        /* get squared distance of scaled vectors */
        distsqd =  distanceSquared2vectors(candidate[n].xvalue,
                                           priorCandidate[i].xvalue,  
                                           min_realvar,
                                           max_realvar,
                                           nreal);
        candidate[n].distanceSquared = 
           min(candidate[n].distanceSquared,distsqd);
      } /* end for i */
      /* test for correct input keepFlag value */
      if (candidate[n].keepFlag == TRUE) {
        printf("\nError: input candidate[%d].keepFlag = TRUE\n",n);
        exit(1);     
      }
    } /* end for n */

  } /* end if nPriorCandidate > 0 */
/*eject*/
  /* initialize squaresum */
  squaresum = 0.0;
  for (n=0; n<nCandidates; n++) {
    if (candidate[n].keepFlag == FALSE) {
      squaresum += candidate[n].distanceSquared;
    } 
  } /* end for n */

  progressflag = 0; /* = k means that k progress cases have */
                    /*     been identified */

  for (ip=0; ip<maxpick; ip++) {

    /* define threshold randomly */
    thresh = squaresum * randomperc();
/*eject*/
    /* select next population record from candidate list */
    /* using kmeans++ rule */
    flag = FALSE;
    partialsum = 0.0;

    for (n=0; n<nCandidates; n++) {
      if ((candidate[n].keepFlag == FALSE) &&
          (candidate[n].distanceSquared > 0.0)) {
        partialsum += candidate[n].distanceSquared;
        if (partialsum >= thresh) {
          nselect = n;
          candidate[nselect].keepFlag = TRUE;
          flag = TRUE;
          break;
        }
      }
    } /* for n */
/*eject*/
    if (flag == TRUE) {

      if (nProcessors > 0) {
        /* candidate[nselect] has already been evaluated */
        /* assign keepFlag = TRUE and distanceSquared = INF */
        candidate[nselect].keepFlag = TRUE;
        candidate[nselect].distanceSquared = INF;
      } else {
        /* must evaluate candidate[nselect] */
        /* transfer candidate[nselect] to population */
        candidateSingle2population(pop, nselect);

        /* evaluate population, which has curPopsize = 1 */
        evaluate_one_pop (pop);

        /* insert obj and constr values of population into
         * candidate[nselect]
         * assign keepFlag = TRUE
         *        distanceSquared = INF */
        population2candidateSingle(pop, nselect);
      }
/*eject*/
      /* if progressflag < PROGRESS_MIN, check progress:
       * if candidate[nselect] is dominated by some 
       *   parentCandidate[], then selected case does not
       *   provide progress; hence do not change progressflag
       * else increment progressflag by 1
       */
      if ((nParentCandidates > 0) && 
          (progressflag < PROGRESS_MIN)) {       
        dominateflag = FALSE;
        for (n=0; n<nParentCandidates; n++) {
          dominateflag = dominate(parentCandidate[n].obj, 
                              parentCandidate[n].constr_violation,
                              candidate[nselect].obj, 
                              candidate[nselect].constr_violation);
          if (dominateflag == TRUE) {
            break; /* parentCandidate[nselect] is dominated by */
                   /* candidate[n] */
          }
        } /* end for n */
        if (dominateflag == FALSE) {
          progressflag++;
        }
      } /* end if nParentCandidates > 0 */
/*eject*/
      /* update candidate distances and squaresum using */
      /* most recently selected population record */
      squaresum = 0.0;
      for (n=0; n<nCandidates; n++) {
        if (candidate[n].keepFlag == FALSE) {
          distsqd =  distanceSquared2vectors(candidate[n].xvalue,
                                           candidate[nselect].xvalue,  
                                           min_realvar,
                                           max_realvar,
                                           nreal);
          candidate[n].distanceSquared = 
             min(candidate[n].distanceSquared,distsqd);
          squaresum += candidate[n].distanceSquared;       
        }
      } /* for n */
    } else {
      /* all candidate[] with keepFlag == FALSE have */
      /* candidate[].distanceSquared == 0.0 and hence */
      /* occur in priorCandidate[] */
      /* thus, cannot pick a candidate[] */ 
      break;
    } /* end if flag == TRUE, else */   

    if ((progressflag >= PROGRESS_MIN) && (ip >= minpick-1)) { 
      /* have at least PROGRESS_MIN undominated cases and */
      /* have selected at least mpick cases */
      break;
    }
  } /* for ip */

  /* update stalled generation count */
  if (progressflag <= 0) {
    stalledGenerationCount++;
  } else {
    stalledGenerationCount = 0;
  }
/*eject*/
  /* compute nFalseKeepFlag, nTrueKeepFlag */
  nFalseKeepFlag = 0;
  nTrueKeepFlag = 0;
  for (n=0; n<nCandidates; n++) {
    if (candidate[n].keepFlag == FALSE) {
      nFalseKeepFlag ++;
    } else {
      nTrueKeepFlag ++;
    }
  } /* end for n */
 
  return nTrueKeepFlag;

}
/*eject*/
/**************************************************************
 * int dominate(double *xobj, double xconstr_violation,
 *          double *yobj, double yconstr_violation):
 * input: xobj[], xconstr_violation,
 *        yobj[], yconstr_violation
 *        of candidates x and y
 * returns: TRUE if x dominates y
 *          FALSE if x does not dominate y
 **************************************************************/
int dominate(double *xobj, double xconstr_violation,
              double *yobj, double yconstr_violation) {

  int j;

  if (yconstr_violation < 0) {
    if (xconstr_violation < yconstr_violation) {
      return FALSE;
    } else if (xconstr_violation > yconstr_violation) {
      return TRUE;
    }
  }

  /* yconstr_violation = 0 or xconstr_violation = yconstr_violation */
  for (j=0; j<nobj; j++) {
    if (xobj[j] > yobj[j]) {
      return FALSE;
    }
  }

  return TRUE;

}
/**********last record of kmeans.lb.c ****************/
