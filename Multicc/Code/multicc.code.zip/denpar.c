/* routines solving problem */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "denpar.h" 
/**************************************************************
 *
 * subroutines in this file:
 *       void denpar()
 *       void denparsolution(char *label)
 *       void output_progress()
 *       void teststop()
 **************************************************************/
/*eject*/
/**************************************************************
 *   void denpar(): main solution subroutine        
 **************************************************************/
void denpar() {

  int n, i, k, r;
  int progress_flag;
  int have_feasibility;
  int flag;

  double alfa_d[MAX_VARIABLE+1];
  double compound_d[MAX_VARIABLE+1];

  int start;
/*eject*/

  /********************
   *  INITIALIZATION  *
   ********************/

  /* initialization to suppress compiler warning */
  obj = 0.0;

  /* define n */
  n = nreal;

  istop = 0;

  index_halton = 19;
  /* alternate choice: index_halton = LARGEPRIME*19; */
  /* then use update:  index_halton += LARGEPRIME;   */

  /* type_direction indicates type of directions used  
   * type_direction =
   *  COORD: coordinate directions
   *  DIAG:  directions orthogonal to the diagonal direction of
   *         first quadrant
   *  DENSE: directions orthogonal to a pseudo-random
   *         halton or sobol direction
   */
  type_direction = COORD;
/*eject*/ 

  /* initialize direction_matrix[][] */
  initialize_directions();
 
  /* initialize alfa_d[] = tentative stepsizes, and alfa_max */
  /* store values in alfa_store[] and alfa_max_store[] */
  initialize_alfa_d(alfa_d);

  /* initialize restriction values */
  restriction.begin = 1;
/*eject*/
  /* check that current_solution has been evaluated */
  if (current_solution.evaluated != TRUE) {
    printf(
      "\n denpar: current_solution.point[] has not been evaluated");
    exit(1);
  }

  /* initialize have_feasibility */
  if (viol > 0.0) {
    have_feasibility = FALSE;
  } else {
    have_feasibility = TRUE;
  }

  /* check current_solution.constr[] and update eps[] as required */
  /* also check validity of and update current_solution */
  if (update_eps() == TRUE) {
    /* eps[] has been changed */ 
    if ((iprint >= 1) && (iprint <= 9)) {
      printf("\n revise eps[], viol = %g",current_solution.viol);
      for (i=1; i<=ncon; i++) {
        printf("\n eps[%d] = %g", i, eps[i]);
      }         
    }
  }

  if ((iprint >= 2) && (iprint <= 9)) {
    printf("\n ----------------------------------");
    printf("\n f_init = %g",current_solution.function);
    for (i=1; i<=n; i++) {
      printf("\n x_init[%d] = %g",i,current_solution.point[i]);
    }
    fflush(stdout); 
  }
/*eject*/
  /***************
   *  MAIN LOOP  *
   ***************/
  while (1) { /* while #1 */

    /* DEBUG begin */
    if (num_funct == 505) {
      i = 1;
    } 
    /* DEBUG end */

    if (restriction.begin == 1) {

      /* start another iteration */
      /*    initialize restriction.progress */ 
      restriction.progress = FALSE;

      /*    increment iteration count */   
      num_iter++;

      /* stopping conditions: alfa_max below bound, or evaluation  */
      /*                      count above limit */
      teststop();

      if (istop >= 1) {
        return;
      }

      /* output progress */
      output_progress();
    }   
/*eject*/
    /* define restriction.size and restriction.end */

    /* the value of restriction.size can be changed to any */
    /* positive number at any point of the program */
    /* the new value is used next to define restriction.end */
    /* and nowhere else */
    /* definitions of restriction.size for debugging: */
    /* restriction.size = min(nProcessors,n); */
    /* restriction.size = n/2; */

    if (nProcessors == 0) {
      restriction.size = 1;
    } else {
      r = n - restriction.begin + 1; 
            /* r = variables left to process */
      if (r < nProcessors) {
        /* less than nProcessors left */
        restriction.size = r;
      } else if (r%nProcessors == 0) {
        /* r is multiple of nProcessors */
        restriction.size = nProcessors;
      } else {
        /* more than nProcessors are left, and */
        /* r is not multiple of nProcessors */
        /* the formula below assures that restriction.size will not */
        /* go down when the remaining variables are processed */
        restriction.size = r / (r/nProcessors + 1);
      }
    }

    /* never change the next definitions */
    restriction.size = min(restriction.size,n-restriction.begin+1);
    restriction.end = restriction.begin+restriction.size-1;
/*eject*/ 
    /* initialize search */
    for (i=1; i<=n; i++){
      all_search[i].done_flag = FALSE;
      all_search[i].idx = -1;
      all_search[i].nselect = 0;
      all_search[i].ntrial = 0;
      all_search[i].alfa_init = alfa_d[i];
      all_search[i].decided_factor = 0.0;
      best_search[i].success = UNDECIDED;
    }
    start = restriction.begin; /* start for parallel evaluation */
/*eject*/ 
    while (1) { /* while #2 */

      /* uses current_solution.point[] */
      /* current_solution may or may not be evaluated as */
      /* indicated by current_solution.evaluated = TRUE/FALSE */

      /* define nselect values */
      define_nselect(&start);

      /* select all_search[].alfa[] */
      /* processes only cases with nselect > 0 */
      select_alfa();

      /* define all_search[].trial[].direction[] 
       *        all_search[].trial[].point[]
       *        all_search[i].trial[k].factor
       *        all_search[i].trial[k].alfa
       * processes only cases with nselect > 0 */
      define_trial_point();

      if (nProcessors == 0) {
        /* evaluated just one case */
        /* must be of type all_search[].trial[] since */
        /* current_solution has already been evaluated; */
        /* see denparmain() and also denpar() lines after */
        /* next_point() call */
        /* the all_search[i].trial[k] point has indices as follows */
        i = restriction.begin;
        k = all_search[i].ntrial+1;      
        evaluate_one_point(i,k);
      } else {
        /* have nProcessors >= 1 */
        /* evaluate all_search[].trial[].point[] */
        /* processes only the cases with nselect > 0 */
        /* if needed, evaluate current_solution.point[] */
        evaluate_all_points();
      }
/*eject*/
      /* decide all_search[].factor if enough information available */
      /* decide all_search[].done_flag if +1.0/-1.0*direction is */
      /* unsuccessful */
      /* processes only cases with nselect > 0 */
      decide_factor();

      /* update all_search[].done_flag */
      /*        all_search[].ntrial */
      /* processes only cases with nselect > 0 */
      update_done_flag();

/* DEBUG begin */
      /* debugstatus("status.txt"); */
/* DEBUG end */

      /* update best_search */
      update_best_search();

      /* decide termination */
      if (decide_termination() == TRUE) {
        break;
      }

    } /* end while #2 */
/*eject*/
    /* current_solution is now evaluated and has correct point[], */
    /* function, obj, constr[], viol of preceding restriction */
    /* iteration */

    /* update alfa_d[] and alfa_max */
    /* using best_search[].alfa_d_scalar */
    update_alfa_d(alfa_d);
/*eject*/
    progress_flag = compute_progress();
    /* progress_flag = TRUE if search successful, FALSE else */
    if ((iprint >= 1) && (iprint <= 9)) {
      printf("\n progress flag = %d",progress_flag);
      fflush(stdout);
    }

    if (iprint == 10) {
      printf("\n\n ***** iteration = %d restriction.begin = %d *****",
             num_iter, restriction.begin);
      printf("\n A point x[1] = %g x[2] = %g ", 
             current_solution.point[1],current_solution.point[2]);
      printf("\n alfa_d[1] = %g alfa_d[2] = %g ", 
             alfa_d[1],alfa_d[2]);
      printf("\n dir[1][1] = %g dir[1][2] = %g ", 
             direction_matrix[1][1],direction_matrix[1][2]);
      printf("\n dir[2][1] = %g dir[2][2] = %g ", 
             direction_matrix[2][1],direction_matrix[2][2]);
      printf("\n *** type_direction = %d", type_direction);
      printf("\n *** progress_flag = %d", progress_flag);
      fflush(stdout);
    }

    /* retain current alfa_d[] in alfa_store[type_direction][] */
    vector2vector(alfa_d,alfa_store[type_direction],n);
    alfa_max_store[type_direction] = alfa_max; 
/*eject*/
    if (progress_flag == TRUE) {
      /* search was successful */

      /* have progress for this restriction iteration */
      restriction.progress = TRUE;

     if (restriction.end == n) {
        /* all restriction iterations have been done */

        /* output history */
        output_history();

        if ((iprint >= 1) && (iprint <= 9)) {  
          printf("\n better point");
          fflush(stdout);
        }

        /* check current_solution.constr[] and update eps[] */
        /* as required */
        /* also check validity of and update current_solution */   
        if (update_eps() == TRUE) {
          /* eps[] has been changed */
          if ((iprint >= 1) && (iprint <= 9)) {
            printf("\n revise eps[], viol = %g",
                   current_solution.viol);
            for (i=1; i<=ncon; i++) {
              printf("\n eps[%d] = %g", i, eps[i]);
            }         
          }
        }
        /* if feasibility achieved for first time, reset alfa_d[] */
        if ((ncon > 0) && (current_solution.viol == 0.0) && 
          (have_feasibility == FALSE)) {
          have_feasibility = TRUE;
          initialize_alfa_d(alfa_d);
        }

      } /* end if restriction.end == n */
/*eject*/
      /* if convex combination of best_search[] results can be
       *         computed due to significant alfa coefficients:
       *   define current_solution.point[] = convex combination of
       *         best_search[] results of linesearches
       *         does not update function, obj, constr[], viol of
       *         current_solution
       *         hence current_solution.evaluated is reset to FALSE
       * else 
       *   define current_solution.point[] to be current solution
       *         current_solution has correct function, obj, 
       *         constr[], viol 
       *         hence current_solution.evaluated remains TRUE
       */  
      next_point();

      if (iprint == 10) {
        printf("\n B point x[1] = %g x[2] = %g ", 
               current_solution.point[1],current_solution.point[2]);
        printf("\n alfa_d[1] = %g alfa_d[2] = %g ", 
               alfa_d[1],alfa_d[2]);
        printf("\n dir[1][1] = %g dir[1][2] = %g ", 
               direction_matrix[1][1],direction_matrix[1][2]);
        printf("\n dir[2][1] = %g dir[2][2] = %g ", 
               direction_matrix[2][1],direction_matrix[2][2]);
        fflush(stdout);
      }

      /* if nProcessors <= 1: evaluate current_solution.point[] */
      /*                      if necessary */
      /* else: evaluate during next restriction iteration */
      if (nProcessors <= 1) {
        computeXcurrent_solution();
      }
  
      /* continue with given direction_matrix[][] and alfa_d[] */
/*eject*/       
    } else {
      /* linesearch was not successful */
      if ((iprint >= 1) && (iprint <= 9)) {
        printf("\n alfamax = %g type_direction = %d",
               alfa_max,type_direction);
      }
      if ((iprint >= 1) && (iprint <= 9)) {
        printf("\n no or slow progress");
        fflush(stdout);
      }
/*eject*/
      flag = FALSE;
      for (i=1; i<=MAX_TYPDIR; i++) {
        if (alfa_max_store[i] > alfa_stop) {
          flag = TRUE;
          break;
        }
      }

      /* if flag = TRUE && 
       *    have last restriction iteration &&
       *    no restriction iteration produced progress:
       *    change method and select new directions
       *  else: 
       *    continue with current direction_matrix[][], alfa_d[]
       */ 
      if ((flag == TRUE) &&
          (restriction.end == n) &&
          (restriction.progress == FALSE)) {
        /* change method and define new type_direction */
        /* modifies type_direction, index_halton */
        /* defines compound_d[] for computation of new */
        /*         direction_matrix[][] */
        next_type_direction(alfa_d, compound_d);
        if ((iprint >= 1) && (iprint <= 9)) {
          printf("\n change type_direction to %d",type_direction);
          fflush(stdout);
       }

        /* compute next direction_matrix[][] using compound_d[] */
        next_direction_matrix(compound_d);

        /* assign values of alfa_store[type_direction][] and */
        /* alfa_max_store[type_direction] to alfa_d[] and alfa_max */
        next_alfa_d(type_direction,alfa_d);
      }
/*eject*/
      if (iprint == 10) {
        printf("\n Z point x[1] = %g x[2] = %g ", 
               current_solution.point[1],current_solution.point[2]);
        printf("\n alfa_d[1] = %g alfa_d[2] = %g ", 
               alfa_d[1],alfa_d[2]);
        printf("\n dir[1][1] = %g dir[1][2] = %g ", 
               direction_matrix[1][1],direction_matrix[1][2]);
        printf("\n dir[2][1] = %g dir[2][2] = %g ", 
               direction_matrix[2][1],direction_matrix[2][2]);
        printf("\n *** new type_direction = %d", type_direction);
        fflush(stdout);
      }

    } /* end if (progress_flag == TRUE), else */

    /* update restriction.begin */
    restriction.begin = restriction.end + 1;
    if (restriction.begin > n) {
      restriction.begin = 1;
    }

  } /* end while #1 */

  return;

}
/*eject*/
/**************************************************************
 *   void denparsolution(char *label): display
 *   obj, xreal[], constr[], eps[], viol
 *   under the heading given by label string
 **************************************************************/
void denparsolution(char *label) {

  int i;

  printf("\n------------------------");
  printf("\n---- %s values ----",label);
  printf("\n------------------------");
  /* obj */
  printf("\nobj = %g\n",obj);
  /* xreal[] */
  for (i=1; i<=nreal; i++) {
    printf("\nxreal[%d] = %g",i,xreal[i]);
  }
  printf("\n");
  /* constr[] and eps[] */
  for (i=1; i<=ncon; i++) {
    printf("\nconstr[%d] = %g\teps[%d] = %g",
           i,constr[i],i,eps[i]);
  }
  printf("\n");
  /* viol */
  if (viol == 0.0) {
    printf("\nsolution is feasible");
  } else {
    printf("\nsolution is infeasible");
  }
  printf("\ntotal violation value            = %g",viol);
/*eject*/
/* num_iter and num_funct */
  if (strcmp(label,"final") == 0) {
    printf("\nnumber of iterations             = %d",num_iter);
    printf("\nnumber of obj/constr evaluations = %d",num_funct);
    printf("\nnumber of obj/constr eval cycles = %d",cycle.sum);
    printf("\nalfa_max                         = %g",alfa_max);
    printf("\nzeta                             = %g",zeta);
    printf("\nnumber of processors             = %d",nProcessors);
    printf("\navg proc usage = evals/cycles    = %f",
           (double)num_funct/(double)cycle.sum);
  } 
  printf("\n------------------------");
  printf("\n");
  fflush(stdout);

  return;

}
/*eject*/
/**************************************************************
 *   void output_progress(): output progress of iterations
 **************************************************************/
void output_progress() {

  int i, n;

  n = nreal;

  if (num_iter%2 == 0) {
    printf(
    "\n num_funct = %3d cycle = %2d iter = %d obj = %g viol = %g alfamax = %g",
           num_funct,cycle.sum,num_iter,
           current_solution.obj,current_solution.viol,alfa_max);
  }
  if ((iprint >= 1) && (iprint <= 9)) {
    printf("\n ---------------------------------------------");
    printf(
    "\n iter = %d num_funct = %d cycle = %2d f = %g viol = %g alfa_max = %g",
     num_iter,num_funct,cycle.sum,
     current_solution.function,current_solution.viol,alfa_max);
     fflush(stdout);
  }
  if ((iprint >= 2) && (iprint <= 9)) {
    for (i=1; i<=n; i++) {
      printf("\n point[%d] = %g",i,current_solution.point[i]);
    }
    fflush(stdout);
  }

  return;

}
/*eject*/
/**************************************************************
 *   void teststop(): evaluate stopping criteria          
 **************************************************************/
void teststop() {

  int i, n;
  double amax;

  n = nreal;

  istop = 0;

  /* amax small */
  amax = alfa_max_store[1];
  for (i=2; i<=MAX_TYPDIR; i++) {
    amax = max(amax,alfa_max_store[i]);
  }

  if (amax <= alfa_stop) {
    istop = 1;
  }

  /* max number of function evaluations */
  if (num_funct > nf_max) {
    istop = 2;
  }

  /* max number of cycle evaluations */
  if (cycle.sum > cycle.max) {
    istop = 3;
  }

  return;

}
/********* last record of denpar.c **********/
