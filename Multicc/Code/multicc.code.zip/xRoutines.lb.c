/* first record of xRoutines.lb.c *****/
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *   int Xexecute(char *cmnd)
 *   int Xnomad()
 *
 **************************************************************/
/*eject*/
/*************************************************************** 
*  Xexecute(char *cmnd): execute cmnd
***************************************************************/
int Xexecute(char *cmnd) {

  return(system(cmnd));

}
/*eject*/
/*************************************************************** 
*  Xmulticontrol(char *instruction, char *filename): 
*     evaluate instruction
***************************************************************/
int Xmulticontrol(char *instruction, char *filename) {

  int flag; /* = TRUE: instruction is in file */
            /*   FALSE; there is no file,or file does not */
            /*          have instruction */
  int i;
  char cmnd[MAX_ENTRY];
  char lineread[MAXLEN];
  FILE *fil;

  /* parse instruction into token[] and save in callArg[] */
  tokenize(instruction);
  for (i=0; i<nTokens; i++) {
    strcpy(callArg[i],token[i]);
  }
  nCallArgs = nTokens;

  /* check  file */
  if ((fil = fopen(filename,"r")) != NULL) {
    /* file exists */
    lineread[0] = '\0';
    /* get first record */
    if (fgets(lineread,MAXLEN,fil) == NULL) {
      strcpy(lineread,"");
    }
    /* parse lineread */
    tokenize(lineread);
    flag = TRUE;
    if (nTokens == 0 ) {
      flag = FALSE;
    } else { /* nTokens > 0 */
      if (nTokens != nCallArgs) {
        flag = FALSE;
      } else { /* nTokens = nCallArgs > 0 */
        for  (i=0; i<nTokens; i++) {
          if (strcmp(callArg[i],token[i]) != 0) {
            flag = FALSE;
            break;
          }
        }
      } /* if nTokens != nCallArgs, else */
    } /* if nTokens == 0, else */
    /* close fil and remove file */
    fclose(fil);
    /* if instruction is in file, remove file */
    if (flag == TRUE) {
      sprintf(cmnd,"rm %s",filename);
      if (system(cmnd) != 0) {
        printf(
           "\n Xmulticontrol: cannot remove existing file %s",
           filename);
        exit(1);
      }
    }
  } else { /* file does not exist */
    flag = FALSE;     
  } /* if fil = fopen(filename,"r") != NULL, else */

  return flag;

}
/*eject*/
/*************************************************************** 
*  Xnomad(): execute nomad program
***************************************************************/
int Xnomad() {

  char cmnd[MAXLEN];
  char addcmnd[MAX_ENTRY];

  sprintf(cmnd,
          "%snomad nomad.params ",
          gOption.nomadpath);
  if (gOption.printdetail <= 1) {
    sprintf(addcmnd,
          " > /dev/null ");
    strcat(cmnd,addcmnd);
  }  

  return(system(cmnd));

}

/* last record of xRoutines.lb.c *******/
