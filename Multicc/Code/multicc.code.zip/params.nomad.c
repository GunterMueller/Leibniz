/* Nomad routines for parameter files */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *   void convertNomadOutput2finalPopOut()
 *   void defineTransferNomadParams();
 *   void defineNomadParams()
 ****************************************************************/
/*eject*/
/**************************************************************
 * void convertNomadOutput2finalPopOut():
 * convert output stat.nomad.txt and output.nomad.txt
 * to final_pop.out
 **************************************************************/
void convertNomadOutput2finalPopOut() {

  int i, j, warningflag; 

  double obj[MAX_OBJ], constr[MAX_CONSTRAINT], xreal[MAX_VARIABLE];
  double constr_violation;

  char lineread[MAXLEN], saveread[MAXLEN];

  char finalpopfile[MAX_ENTRY];
  char outputfile[MAX_ENTRY];
  char statfile[MAX_ENTRY];

  FILE *finalpopfil;
  FILE *outputfil;
  FILE *statfil;

  /* define file names */
  sprintf(finalpopfile,"final_pop.out");
  sprintf(outputfile,"output.nomad.%d.txt",gOption.seednomad);
  sprintf(statfile,"stat.nomad.%d.txt",gOption.seednomad);

  /* open files */
  finalpopfil = openFile(finalpopfile,"w");
  outputfil = openFile(outputfile,"r");
  statfil = openFile(statfile,"r");
/*eject*/
  warningflag = FALSE;
  j = 0;

  /* read output file */
  while (fgets(lineread,MAXLEN,outputfil) != NULL) { /* while #1 */
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty lines or warning line */
    if (lineread[0] == '\0') {
      continue;
    }

    /* if "warning ..." line, set warning flag, skip processing */
    /* of line, and do not count line */
    if (strncmp(lineread,"warning",7) == 0) {
      warningflag = TRUE;
      continue;
    }

    if (tokenize(lineread) != 1) {
      printf(
        "\n convertNomadOutput2finalPopOut: output record = %s ",
        lineread);
      printf(
        "\n has %d strings, but should have only one string", 
        nTokens);
      exit(1);
    } 
/*eject*/
    /* test relies on fact that first two lines of file */
    /* are the seed and an internal nomad integer whose role */
    /* is not clear */
    if (j == nreal+2) {
      printf(
        "\n convertNomadOutput2finalPopOut: too many records ");
      printf(
        "\n in %s file; should have %d records", 
        outputfile, nreal+2);
      exit(1);
    }

    if (j >= 2) {
      xreal[j-2] = atof(token[0]);
    }
    j++;

  } /* end while #1 */

  if (warningflag == TRUE) {
    printf(
      "\n warning: no feasible solution found");
    printf(
      "\n          best infeasible solution in file final_pop.out\n");
  } else {
    printf("\n at least one feasible solution found");   
    printf("\n best feasible solution in file final_pop.out\n");
  }

  if (j != nreal+2) {
    printf(
      "\n convertNomadOutput2finalPopOut: %d data records in %s file",
      j, outputfile);
    printf(
      "\n        but should have nreal+2 = %d records", nreal+2);
    printf(
      "\n        counts do not include any 'warning' record");
    exit(1);
  }
/*eject*/
  /* read stat file */
  while (fgets(lineread,MAXLEN,statfil) != NULL) { /* while #2 */
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty lines */
    if (lineread[0] == '\0') {
      continue;
    }
    /* have nonempty line; save record */
    strcpy(saveread,lineread);
  } /* end while #2 */
  
  /* saveread is last nonempty record of file */
/*eject*/
  /* process saveread record depending on warning flag */
  if (warningflag == TRUE) {
    if (strncmp(saveread,"no feasible solution has",24) != 0) {
      printf(
      "\n convertNomadOutput2finalPopOut(): have line '%s'",
      saveread);
       printf("\n but expected 'no feasible solution has ..'");    
    } else {
      sscanf(saveread,"no feasible solution has been found in %d",
                      &evaluationCount);
    }
    /* since obj and constr values are recomputed later */
    /* during transfer to problem.params.multi file, */
    /* define tokens for obj using arbitrary value 0.0 */
    for (j=0; j<nobj; j++) {
      sprintf(token[j+1],"0.0");
    }
    /* define tokens for constr using arbitrary value 1.0, */
    /* which is infeasible for nomad */    
    for (j=0; j<ncon; j++) {
     sprintf(token[j+1+nobj],"1.0");
    }
    nTokens = 1 + nobj + ncon;
  } else {
    /* get tokens of saveread */
    if (tokenize(saveread) != (1 + nobj + ncon)) {
      printf(
        "\n convertNomadOutput2finalPopOut: output record = %s ",
        saveread);
      printf(
        "\n has %d strings, but should have %d strings", 
        nTokens,1 + nobj + ncon);
      exit(1);
    }
    /* evaluation count */
    evaluationCount = atoi(token[0]);
  }
/*eject*/
  /* remaining steps are same for feasible and infeasible case */
  /* get obj and constr from token[j], j>=1 */

  /* objective values */
  for (j=0; j<nobj; j++) {
    obj[j] = atof(token[j+1]);
  }

  /* constraint values */
  /* caution: nomad has constraint <= 0 for feasibility */
  /*               gencc/nsga has constraint >= 0 for feasibility */
  /*  hence change sign of constraint values */
  for (j=0; j<ncon; j++) {
    constr[j] = -atof(token[j+1+nobj]);
  }

  /* compute constraint violation */
  constr_violation = 0.0;
  for (j=0; j<ncon; j++) {
    if (constr[j] < 0) {
      constr_violation += constr[j];
    }
  }
/*eject*/
  /* write final_pop.out file */
  fprintf(finalpopfil,
    "# This file contains the data of final population\n");
  fprintf(finalpopfil,
"# of objectives = %d , # of constraints = %d , # of real_var = %d , constr_violation , rank , crowding_distance , # of evaluations = %d\n",
      nobj,ncon,nreal,evaluationCount);

  for (j=0; j<nobjSolve; j++) {
    fprintf(finalpopfil,"%g ",obj[j]);
  }

  for (j=0; j<ncon; j++) {
    fprintf(finalpopfil,"%g ",constr[j]);
  }

  for (j=0; j<nreal; j++) {
    fprintf(finalpopfil,"%g ",xreal[j]);
  }

  fprintf(finalpopfil,"%g ",constr_violation); 

  /* rank */
  fprintf(finalpopfil,"1 ");

  /* crowding distance */
  fprintf(finalpopfil,"1.000000e+14 "); 

  fprintf(finalpopfil,"\n"); 

  closeFile(finalpopfil);
  closeFile(outputfil);
  closeFile(statfil);

  return;

}
/*eject*/
/**************************************************************
 * void defineTransferNomadParams(char *name):
 * define parameter file for nomad execution
 **************************************************************/
void defineTransferNomadParams() {

  int j;

  char paramsfile[MAX_ENTRY];

  FILE *paramsfil;

  sprintf(paramsfile,"transfer.nomad.params");
  if ((paramsfil = fopen(paramsfile,"w")) == NULL) {
    printf(
    "\n defineTransferNomadParams: cannot open parameter file %s",
        paramsfile);
    exit(1);
  }

  /* basic parameters */
  fprintf(paramsfil,
"problemName = %s , nreal = %d , nint = %d , nobjEvaluate = %d , nobjSolve = %d , ncon = %d , nCorners = %d , objfactor = %d , objrange = %d , stopcriterion = %s , input = %s , initsol = %s , output = %s , params = %s , singleminout = %d\n",
   problemName, nreal, nint, nobjEvaluate, nobjSolve, 
   ncon, nCorners, gOption.objfactor, gOption.objrange, 
   gOption.stopcriterion, gOption.input, gOption.initsol,
   gOption.output, gOption.params, gOption.singleminout);

  fprintf(paramsfil,
"blackbox = %s , inbox = %s , outbox = %s , processor = %s , maxproctime = %d , leibnizpath = %s , nomadpath = %s , tempdir = %s , ignoreconstraint = %d , nObjFactors = %d \n", 
   gOption.blackbox, gOption.inbox, gOption.outbox, 
   gOption.processor, gOption.maxproctime,
   gOption.leibnizpath, gOption.nomadpath, gOption.tempdir,
   gOption.ignoreconstraint, nObjFactors);
/*eject*/
  /* obj factors and ranges */
  for (j=0; j<nobjEvaluate; j++) {
    fprintf(paramsfil,"%f  %f\n", objFactor[j], objRange[j]);
  }
  /* constraint tolerances */
  for (j=0; j<ncon; j++) {
    fprintf(paramsfil,"%f \n", constrTolerance[j]);
  }  

  fclose(paramsfil);

  return;

}  
/*eject*/
/**************************************************************
 * void defineNomadParams():
 * define parameter file for nomad execution
 * input: inputCandidate[].xvalue[], is used for X0 options 
 **************************************************************/
void defineNomadParams() {

  int i, j;

  char paramsfile[MAX_ENTRY];

  FILE *paramsfil;

  sprintf(paramsfile,"nomad.params");
  if ((paramsfil = fopen(paramsfile,"w")) == NULL) {
    printf("\n defineNomadParams: cannot open parameter file %s",
           paramsfile);
    exit(1);
  }

  /* DEBUG: detailed screen output */
  /* fprintf(paramsfil,
    "DISPLAY_DEGREE FULL_DISPLAY\n"); */

  /* DIMENSION of solution vector */
  fprintf(paramsfil,
    "DIMENSION %d\n", nreal);

  /* BB_EXE blackbox */
  /* caution: if path is specified, must be complete and */
  /* cannot use '~' to indicate home directory; quotes and '$' */
  /* indicate command is to be used without adding './' */
  fprintf(paramsfil,
    "BB_EXE \"$%s/transfer.nomad.exe\"\n",gOption.tempdir);
/*eject*/
  /* BB_INPUT_TYPE */
  fprintf(paramsfil,
    "BB_INPUT_TYPE ( ");
  for (j=0; j<nint; j++) {
    fprintf(paramsfil,
      "I "); /* integer variable */
  }
  for (j=nint; j<nreal; j++) {
    fprintf(paramsfil,
      "R "); /* real variable */
  }
  fprintf(paramsfil,")\n");

  /* options required for use of blackbox output file */
  /* do not change the next three options */
  fprintf(paramsfil,
    "BB_INPUT_INCLUDE_SEED yes\n");
  fprintf(paramsfil,
    "BB_INPUT_INCLUDE_TAG yes\n");
  fprintf(paramsfil,
    "BB_REDIRECTION no\n");

  /* BB_OUTPUT_TYPE */
  fprintf(paramsfil,
    "BB_OUTPUT_TYPE ");
  for (j=0; j<nobj; j++) {
    fprintf(paramsfil,
      "OBJ "); /* objective function */
  }
  for (j=0; j<ncon; j++) {
    fprintf(paramsfil,
      "PB "); /* constraint, gradually enforced */
              /* use PB or PEB */
  }
  fprintf(paramsfil,"\n");

  /* BB_MAX_BLOCK_SIZE */
  fprintf(paramsfil,
    "BB_MAX_BLOCK_SIZE %d\n",max(1,nProcessors));
/*eject*/
  /* LOWER_BOUND */
  fprintf(paramsfil,
    "LOWER_BOUND ( ");
  for (j=0; j<nreal; j++) {
    fprintf(paramsfil,
      "%g ",min_realvar[j]); /* lower bound */
  }
  fprintf(paramsfil,")\n");  

  /* UPPER_BOUND */
  fprintf(paramsfil,
    "UPPER_BOUND ( ");
  for (j=0; j<nreal; j++) {
    fprintf(paramsfil,
      "%g ",max_realvar[j]); /* upper bound */
  }
  fprintf(paramsfil,")\n"); 

  /* LH_SEARCH */
  fprintf(paramsfil,
    "LH_SEARCH 5 5\n");

  /* SEED enforces identical run start */
  fprintf(paramsfil,
    "SEED %d\n", gOption.seednomad);
/*eject*/
  /* MIN_POLL_SIZE and MIN_MESH_SIZE for termination */
  fprintf(paramsfil,
    "MIN_POLL_SIZE r%f\n", gOption.finalmesh);
  fprintf(paramsfil,
    "MIN_MESH_SIZE r%f\n", gOption.finalmesh);

  /* MAX_BB_EVAL for limiting run evaluations */
  fprintf(paramsfil,   
    "MAX_BB_EVAL %d\n", maxEvaluationCount);

  /* TMP_DIR temporary directory */
  fprintf(paramsfil,
    "TMP_DIR %s\n",gOption.tempdir);

  /* STATS_FILE and SOLUTION_FILE output */
  fprintf(paramsfil,  
    "STATS_FILE stat.nomad.txt BBE BBO\n");
  fprintf(paramsfil,  
    "SOLUTION_FILE output.nomad.txt\n");

  /* F_TARGET for goal if specified */
  if (gOption.objgoal == TRUE) {
    fprintf(paramsfil,  
      "F_TARGET %f\n",objGoal[0]);
  }  
/*eject*/
  /* advanced options */

  /* VNS_SEARCH for problems with multiple local minima */
  fprintf(paramsfil,  
    "VNS_SEARCH 0.75\n");
  
  /* SNAP_TO_BOUNDS: disable */
  fprintf(paramsfil,  
    "SNAP_TO_BOUNDS 0\n");

  /* DIRECTION_TYPE: use orthoMADS */
  fprintf(paramsfil,
    "DIRECTION_TYPE ORTHO 2N\n");
    /* "DIRECTION_TYPE ORTHO N+1 NEG\n");*/ /* maybe good */
    /* "DIRECTION_TYPE ORTHO N+1 QUAD\n");*/ /* maybe not reliable */
    /* evaluation based on sin_10 */

  /* INITIAL_MESH_SIZE: default r0.1, may try coarser r0.5 */
  fprintf(paramsfil,
    "INITIAL_MESH_SIZE r%f\n",gOption.initialmesh);

  /* stopcriterion = feasible */
  if (strcmp(gOption.stopcriterion,"feasible") == 0) {
    fprintf(paramsfil,
      "STOP_IF_FEASIBLE yes\n");
  }
/*eject*/
  /* X0 option: use inputCandidate[] */
  for (i=0; i<nInputCandidates; i++) {
    fprintf(paramsfil,
      "X0 ( ");
    for (j=0; j<nreal; j++) {
      fprintf(paramsfil,
        "%g ",inputCandidate[i].xvalue[j]);
    }  
      fprintf(paramsfil,
        ")\n");
  }

  /* DISABLE MODELS:  disables models, results in more evaluations */
  /* may or may not result in better solution on difficult problems */
  /* fprintf(paramsfil,
      "DISABLE MODELS\n"); */

  /* display degree 3 for detailed on-screen log of run */
  /* fprintf(paramsfil,
    "DISPLAY_DEGREE 3\n"); */

  /* Caution: if tolerance for constraint violation is changed, */
  /* must also change constr_violation rule in gencc/nsga */
  /* since otherwise feasible nomad points are infeasible */
  /* in gencc and nsga */
  /* fprintf(paramsfil,
    "H_MIN 0.01\n"); */

  /* detailed screen output begin */
  /* fprintf(paramsfil,
    "DISPLAY_ALL_EVAL yes\n");
  fprintf(paramsfil,
    "DISPLAY_STATS BBE ( SOL ) BBO\n"); */
  /* detailed screen output end */

  /* for version 3.7.0 only */
  /* ANISOTROPIC option disabled */
  /* fprintf(paramsfil,  
    "ANISOTROPIC_MESH 0\n"); */
  /*  MESH_UPDATE_BASIS reduced */
  /* fprintf(paramsfil,  
    "MESH_UPDATE_BASIS 2\n"); */

  fclose(paramsfil); 

  return;

}
/*********last record of params.nomad.c *******************/
