/* routines initializing and evaluating problem */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "dencon.h"

/***************************************************************
 *
 * subroutines in this file:
 *       void   convertDenconOutput2finalPopOut();
 *       void   denconbounds()
 *       void   denconstart(double *x)
 **************************************************************/
/*eject*/
/**************************************************************
 *   void convertDenconOutput2finalPopOut(): convert dencon 
 *     output to final_pop.out
 *   caution: constraint violation output follows nsga/gencc rule,
 *            which is sum of violations, and not dencon rule,
 *            which is max of violations
 *   uses or modifies: nreal, ncon, obj, constr, xreal, num_iter      
 **************************************************************/
void convertDenconOutput2finalPopOut(){

  int j;
  double constr_violation;

  char finalpopfile[MAX_ENTRY];
  FILE *finalpopfil;

  /* define file name */
  sprintf(finalpopfile,"final_pop.out");

  /* open files */
  finalpopfil = openFile(finalpopfile,"w");

  if (nobj != 1) {
    printf("\n convertDenconOutput2finalPopOut: nobj = %d != 1",
           nobj);
    exit(1);
  }

  /* write final_pop.out file */
  fprintf(finalpopfil,
    "# This file contains the data of final population\n");
  fprintf(finalpopfil,
"# of objectives = %d , # of constraints = %d , # of real_var = %d , constr_violation , rank , crowding_distance , # of evaluations = %d\n",
      nobj,ncon,nreal,num_funct);
/*eject*/
  fprintf(finalpopfil,"%g ",obj);

  /* constr values were computed according to dencon rule */ 
  /* of g() <= 0; but for final_pop.out use gencc/nsga rule */
  /* of g() >= 0; hence use constr below with '-' sign */
  /* caution: index shift required */ 
  for (j=1; j<=ncon; j++) {
    fprintf(finalpopfil,"%g ",-constr[j]);
  }

  /* caution: index shift required */
  for (j=1; j<=nreal; j++) {
    fprintf(finalpopfil,"%g ",xreal[j]);
  }

  /* compute constr_violation using nsga/gencc rule, which */
  /* specifies violation = sum of violations */
  /* caution: index shift required */
  constr_violation = 0.0;
  for (j=1; j<=ncon; j++) {
    if (-constr[j] < 0) {
      constr_violation += -constr[j];
    } 
  }
  fprintf(finalpopfil,"%g ",constr_violation);

   /* rank */
  fprintf(finalpopfil,"1 ");

  /* crowding distance */
  fprintf(finalpopfil,"1.000000e+14 "); 

  fprintf(finalpopfil,"\n"); 

  closeFile(finalpopfil);

  return;

}
/*eject*/
/**************************************************************
 *   void denconbounds(): defines lb and ub bounds for given problem
 *   uses or modifies: nreal,lb,ub
 **************************************************************/
void denconbounds() {

  int j;

  /* caution: index shift required */
  for (j=1; j<=nreal; j++) {
    lb[j] = min_realvar[j-1];
    ub[j] = max_realvar[j-1];
  }

  return;

}
/*eject*/
/**************************************************************
 *   void denconstart(double *x): defines initial vector x
 *   uses or modifies: nreal
 **************************************************************/
void denconstart(double *x) {

  int j;

  /* caution: index shift required */
  if (nInputCandidates > 0) {
    /* use inputCandidate[0].xvalue as starting point */
    for (j=1; j<=nreal; j++) {
      x[j] = inputCandidate[0].xvalue[j-1];
    }
  } else {
    /* choose midpoint between bounds */
    for (j=1; j<=nreal; j++) {
        x[j] = (max_realvar[j-1]+min_realvar[j-1])/2.0;
    }
  }

  return;

}
/***************** last record of denconProblem.c ****************/
