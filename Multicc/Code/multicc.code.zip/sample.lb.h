/* arrays and routines for multicc */

/* define constants */
#define MAXLEN 15000
#define MAX_ENTRY 256
#define MAX_DIRECTORY 256
#define MAX_ARG 50 /* max number of call arguments */

#define MAX_OBJ 10
#define MAX_CONSTRAINT 15
#define MAX_CORNER 50
#define MAX_INITIALTRIAL 1000 /* max number of trials */
        /* to find initially an individual satisfying all linear */
        /* inequalities */

#define MIN_POP 4
#define MAX_POP 200
#define POPSIZE_MULTIOBJ_GENCC 40
#define POPSIZE_MULTIOBJ_NSGA  40
#define POPSIZE_SINGLEOBJ 40
#define MAX_TEST 2 /* number of test points (= OLD, NEW) */
#define MAX_VARIABLE 50
#define MAX_PRIOR 6000
        /* max number of priorCandidate[] */ 
#define MAX_CANDIDATE MAX_PRIOR+MAX_POP 
        /* max number of candidate[] */
#define MAX_BUCKET 20 /* max number of buckets for distribution */
                      /* analysis in convergence decision */
                      /* DEBUG values was 10 */
#define MAX_PROC 128  /* max number of processors for */
                      /* parallel evaluation */
#define MAX_PROCFILE 20 /* max number of user files needed */
                        /* by any processor */                  
/*eject*/
/* for each population: */
#define SAMPLE_MIN   1 /* min evaluated sample size */
#define PROGRESS_MIN 1 /* min number of progress cases */
#define STALLEDGENERATION_MAX 10 /* max number of */
                                 /* stalled generations */
 
#define MAX_PARAMSDATA 200 /* max number of lines in params file */

/* convergence criteria */
#define MAX_DOMINANCETESTSEQ 8 /* previous value was 8 */ 
                      /* max dominance test sequences */ 

#define FUNCTION_PRECISION 1.0e-06
#define CONSTRAINT_PRECISION 1.0e-06
#define WEIGHTED_SUM_FACTOR 1.0e+03
                      /* factor for weighted sum in objRange[] use */
                      /* for weight of obj[j] vs obj[juse] */
#define MAX_REPEATEDDISTRIBUTION 10 /* previous value was 5 */
                      /* max number of distribution repetitions */
#define FALSE 0 
#define TRUE 1
#define UNDECIDED -1
#define OBJFLAG 10
#define CONSTRFLAG 11
#define XVALUEFLAG 12

#define OLD 0
#define NEW 1

#define SEEDNSGA   0.5 /* seed for nsga */
#define SEEDNOMAD   17 /* seed for nomad */

/* time constants expressed in nanoseconds */
#define HALFSECOND  500*1000*1000 /* 0.5 sec */
#define TENTHSECOND 100*1000*1000 /* 0.1 sec */

/*************** Substitution Functions *******************/
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))
/*************** Circular Indexing ************************/
/* #define circ(j) (((j-1)%nreal)+1) */ /* simplest example */
#define circ(j) (((j)<=(restriction.end)) ? (j) : (restriction.begin))
/*eject*/
/*************validity check of code ***********/
/* all steps of validity check are preceded by */
/* a comment including the words "validity check" */
/* day, month, year when codes expires and becomes inoperable */
/* enter last date for which code is to be valid */
/* after that date, the code fails to operate correctly */
#define EXPIREDAY    31  
#define EXPIREMONTH  12  
#define EXPIREYEAR 2099 
#define MFAC  37 /* month factor, must be >= 31 */
#define YFAC 629 /* year factor, must be >= MONTHFACTOR * 12 */
#define TOTALDATE  EXPIREDAY+MFAC*EXPIREMONTH+YFAC*EXPIREYEAR
int validityFlag; /* = TRUE:  code is still valid */
                  /* = FALSE: code has expired */
int totalDate;

/***** time variables *****/
time_t startTime, stopTime;
struct tm *locTime;
int elapsedTime;
/***** global version number *****/
char globalversion[5];
/*eject*/
/******************* Data Structures *********************/
/* path of Leibniz/Multicc/Code directory */
char leibnizPath[MAXLEN];
/* path of Nomad code directory */
char nomadPath[MAXLEN];

/* call arguments */
char callArg[MAX_ARG][MAX_ENTRY];
int nCallArgs;

/* tokens obtained from records */
char token[MAX_ENTRY][MAX_ENTRY];
int nTokens;

char percent[2];

/* CAUTION: All arrays are used with starting index = 0 */
/* in agreement with NSGA-II code */

/* number of consecutive xreal[] that must take on integer values, */
/* starting with index 0 for the first such variable */
int nint;
/*eject*/
/* current population size */
int curPopsize;

/* sample size, min sample size */
int sampleSize, minSampleSize;

/* generation, function, file counts; problem and method name */
int generationCount; /* current generation */
int evaluationCount; /* cumulative evaluation count of candidate[] */
int finalStepEvaluationCount;
int maxEvaluationCount; /* max number of evaluations */
int paretoSetSize; /* desired size of Pareto set */
int stalledGenerationCount; /* number of stalled generations */
int pickCount; /* number of candidate[] picked for evaluation */
               /* for current generation */
int gNumOpenFiles;
char problemName[MAX_ENTRY]; /* problem name, given on command line */
char methodName[MAX_ENTRY]; /* = 'gencc', 'multicc", 'nomad','nsga' */
int haveSolution; /* have at least one feasible solution available */
                  /* during single obj min phases */
/*eject*/
/* command and addition to command */
char addcmnd[MAX_ENTRY], cmnd[MAXLEN]; 
/* files used by multicc, dencon, nomad, seqpen */
char filename[MAX_ENTRY];
FILE *fil;
char singleminoutfile[MAX_ENTRY];
FILE *singleminoutfil;
char statnomadfile[MAX_ENTRY];
FILE *statnomadfil;
char multiparamsfile[MAX_ENTRY];
FILE *multiparamsfil;
char multifinalfile[MAX_ENTRY];
FILE *multifinalfil;
FILE *testfil;
char multiallfeasiblefile[MAX_ENTRY];
FILE *multiallfeasiblefil;
char multicontrolfile[MAX_ENTRY];

/* cycle evaluation counts */
/* used independently by multicc and denpar */
struct {
/* used by multicc eval.xxx and cycle.xxx */
  int multiObj;
  int singleObj[MAX_OBJ];
  int total;
/* used by denpar cycle.xxx */
  int diff;
  int max;
  int old;
  int sum;
} typedef EvalCycleCount;
EvalCycleCount eval;
EvalCycleCount cycle;
/*eject*/
/* options */
struct {
  /* basic options */
  char input[MAX_ENTRY];      /* original input file */
  char initsol[MAX_ENTRY];    /* initial solution file */
  char output[MAX_ENTRY];     /* final output file */
  char blackbox[MAX_ENTRY];   /* = "NOBLACKBOX" if no black box */
  char inbox[MAX_ENTRY];      /* input file of black box */
  char outbox[MAX_ENTRY];     /* input file of black box */
  char params[MAX_ENTRY];     /* params file */
  char processor[MAX_ENTRY];  /* processor file */
  char leibnizpath[MAX_ENTRY];/* leibniz multicc code path */
  char nomadpath[MAX_ENTRY];  /* nomad bin path */
  char tempdir[MAX_ENTRY];    /* temporary directory */
                              /* used for blackbox calls */
  int singleminout;           /* = TRUE: store all single min evals */
                              /*     in file <problem>.singleminout */
                              /* = FALSE: else */
/*eject*/
  /* advanced options */
  double accuracy;
  char sequenceminone[MAX_ARG][MAX_ENTRY]; /* sequence of */
         /* single obj minimization programs to be executed */
  int  nsequenceminone ; /* number of programs in minonesequence */
  char stopcriterion[MAX_ENTRY]; /* stop criterion for gencc, nsga */
    /* = 'feasible' or 'optimal'; caution: do not use with multicc */
  char minall[MAX_ENTRY]; /* multiobjective minimization program */
  int maxeval; /* max number of evaluations, any program */
  int maxiter; /* max number of iterations in multicc for single */
               /* obj minimization; one iteration means */
               /* execution of one program */
  int maxitereval; /* max number of evaluations for one iteration */
                   /* of single obj minimization in multicc */
  int maxfirstitereval; /* max number of evaluations for first */
              /* iteration of single obj minimization in multicc */
              /* = 0: there is no special evaluation limit */
              /*      for the first iteration */
              /* > 0: enforce the value as evaluation limit */
              /*      for the first iteration */
              /* application: first iteration computes start point */
                   /* of single obj minimization in multicc */
  int minsingleonly;/* = TRUE: minimization of single objs only */
                    /* = FALSE: minimization single and multi obj */
  int minallonly;   /* = TRUE: minimization of all objs only */
                    /* = FALSE: minimization single and multi obj */
  int ignoreconstraint; /* = TRUE: ignore all constraints computed */
                        /*         by black box */
    /* caution: -ignoreconstraint overrides -gradualconstraint */
    /*          and -scaleconstraint */
                        /* = FALSE: all constraints are active */
  int gradualconstraint; /* = n: gradually enforce constraints */
                         /*      computed by black box over n */
                         /*      populations; multicc, gencc, */
                         /*      nsga only */ 
                         /* = 0: all constraints fully enforced */
                         /*      at all times */
    /* caution: -gradualconstraint overrides -scaleconstraint */
  int scaleconstraint; /* = TRUE: scale constraints */
                       /* = FALSE: do not scale constraints */
/*eject*/
  int objfactor;       /* = TRUE: objFactor[] are specified */
                       /* = FALSE: use default objFactor[] */
  int objtolerance;    /* = TRUE: objTolerance[] are specified */
                       /* = FALSE: use default objTolerance[] */
  int constrtolerance; /* = TRUE: constrTolerance[] are specified */
                       /* = FALSE: use default constrTolerance[] */
  int objgoal;         /* = TRUE: objGoal[] are specified */
                       /* = FALSE: use default objGoal[] */
  int objbound;        /* = TRUE: objBound[] are specified */
                       /* = FALSE: use default objBound[] */
  int objrange;        /* = TRUE: objRange[] are specified */
                       /* = FALSE:  use default objRange[]*/
  int cutout;          /* = TRUE: use initsol file and objBound[] */
                       /*         to prepare for minall execution */
                       /* = FALSE: standard use of initsol file */
  int dynamiclimit;    /* = TRUE: do dynamic limit reductions */
                       /* = FALSE: no dynamic limit reductions */     
  int convergetesteval;/* = min number of evaluations */
                       /*   between convergence tests */
  int paretosize;      /* population size */
  int plotdetail;      /* = 0: do not plot multi obj run */
                       /* = 1: plot final multi obj result */
                       /* = 2: plot all steps of multi obj run */
  int printdetail;     /* = 0: no printf screen output */
                       /* = 1: printf multicc summary info */
                       /* = 2: printf all screen output */
  int slowmotion;      /* = TRUE: run nsga in slo mo */
                       /* = FALSE: run nsga in normal speed */
  double seednsga;     /* seed for nsga; 0.0 < fraction < 1.0 */
  int    seednomad;    /* seed for nomad; integer > 0 */
  double initialmesh;  /* INITIAL_MESH for nomad */
  double finalmesh;    /* MIN_POLL_SIZE and MIN_MESH_SIZE for nomad */
  int    maxproctime;  /* max time (sec) allowed for a processor */
  int denconcoordinate;/* dencon coordinate search flag */
                       /* = TRUE: dencon uses coordinate directions */
                       /*         only and NOT diag or dense */
                       /*         directions */
                       /* = FALSE: dencon uses coordinate, diag, */
                       /*         and dense directions */
} typedef OptionFlag;
OptionFlag gOption;
/*eject*/
  /* single obj values */
struct {
  double old;
  double new;
} typedef SingleObjective;
SingleObjective singleObjective;

  /* processors and list of files needed by processors */
struct {
  char machine[MAX_ENTRY];
  char path[MAX_ENTRY];  
} typedef Processordef;
Processordef processor[MAX_PROC]; 
int nProcessors;
char procFile[MAX_PROCFILE][MAX_ENTRY];
int nProcFiles;

/* 0/1 factors internally applied to obj functions */
/* effectively selects subset of objs to be minimized */
double objFactor[MAX_OBJ];
int nObjFactors;

/* tolerances of obj values */
double objTolerance[MAX_OBJ];
int nObjTolerances;

/* tolerances of constr values */
double constrTolerance[MAX_CONSTRAINT];
int nConstrTolerances;

/* goals of obj functions */
/* caution: goal value is for internal min representation */
/* if obj is <= goal, then can stop optimization */
/* default: objGoal[j] = -infinity */
double objGoal[MAX_OBJ];
double objGoalInitial[MAX_OBJ];
int nObjGoals;

/* bounds of objective functions */
/* caution: bound value is for internal min representation */
/* obj must be <= bound */
/* default: objGoal[j] = infinity */
double objBound[MAX_OBJ];
double objBoundInitial[MAX_OBJ];
int nObjBounds;
/*eject*/
/* ranges of objective functions */
/* used to compute weighted sums of functions during */
/* single function minimization */
/* if objRange[j] = 0: obj j is ignored in weighting process */
/* default: objRange[j] = 0; for all j */
double objRange[MAX_OBJ];
int nObjRanges;

/* obj counts before and after reduction */
/* based on objFactor[j] = 0.0 cases */
int nobjEvaluate; /* nobj before reduction; is input nobj and used  */
                  /* later only when xvalue cases are evaluated */
                  /* in evaluation_ind() */ 
int nobjSolve; /* nobj after reduction; is used for solution */
               /* process and output except for evaluation_ind() */

/* convergence control: distribution of obj values in buckets */
int distributionBucket[MAX_OBJ][MAX_BUCKET];
    /* distributionBucket[j][i] = TRUE if some candidate[n].obj[j] */
    /*                                 is in bucket i */
    /*                          = FAlSE otherwise */
int openBucketFlag; 
    /* = TRUE: at least once had open bucket in testDistribution() */
    /* = FALSE; never had an open bucket */
int repeatedDistributionCount; /* number of times the current */
                               /* distribution has been repeated */
/*eject*/
/* sample points */
struct {
  double distanceSquared;
  int keepFlag;    /* = TRUE: record is kept */
                   /* = FALSE: record usage undecided */
  double obj[MAX_OBJ];   /* objective function values */
  double constr[MAX_CONSTRAINT];  /* constraint values */
  double xvalue[MAX_VARIABLE];  /* variable values */
  double constr_violation; /* total violation_of_constraints value */
                    /* constraints >= 0 for feasibility */
  int generation; /* generation count when case was created */
} typedef SampleRecord;

SampleRecord candidate[MAX_CANDIDATE];
int nCandidates; /* candidate records */
int nFalseKeepFlag; /* candidate records with keepFlag = FALSE */
int nTrueKeepFlag;  /* candidate records with keepFlag = TRUE */
int nEstimates; /* number of candidate[] with estimated obj[] */

SampleRecord inputCandidate[MAX_PRIOR];
int nInputCandidates; /* input candidate records */

SampleRecord parentCandidate[MAX_POP];
int nParentCandidates; /* parent candidate records */

SampleRecord parallelCandidate[MAX_PROC]; 
int nParallelCandidates;
      /* candidate records to be evaluated in parallel */

SampleRecord priorCandidate[MAX_PRIOR];
int nPriorCandidates;
      /* prior candidates to be used in training */
      /* view as circular file with at most MAX_PRIOR records */
int curPriorCandidate; /* index of priorCand[] record where next */
                       /* candidate is to be stored */

SampleRecord referenceCandidate[MAX_PRIOR];
int nReferenceCandidates;
    /* reference candidates used for convergence test */
    /* contains priorCandidate[] of most recent convergence test */
/* arrays based on referenceCandidate[] */
double deltaValue[MAX_OBJ]; /* max-min of current solution */
double volumeGap[MAX_OBJ]; /* acceptable accuracy range */
double referenceMax[MAX_OBJ]; /* reference value */
/*eject*/
/* accept/reject candidates for nsga initialization process */
SampleRecord acceptCandidate[MAX_PRIOR];
int nAcceptCandidates;
SampleRecord rejectCandidate[MAX_PRIOR];
int nRejectCandidates;

struct {
int nAccept;
int nReject;
int nTotal;
} typedef AcceptReject;
AcceptReject initPop;
/*eject*/
/* min and max of obj, constr, xvalue, accepted obj */
struct{
  double obj[MAX_OBJ];       
  double constr[MAX_CONSTRAINT];
  double xvalue[MAX_VARIABLE];
  double constr_violation;
  double acceptObj[MAX_OBJ];
} typedef minmaxValue;

minmaxValue minvalue;
minmaxValue maxvalue;

minmaxValue candidateMinvalue;
minmaxValue candidateMaxvalue;

minmaxValue previousCandidateMinvalue;
minmaxValue previousCandidateMaxvalue;

/* parameter data */
char paramsData[MAX_PARAMSDATA][MAXLEN];
int nParamsData;

/* objectives */
struct {
  char name[MAX_ENTRY];
  char direction[MAX_ENTRY];
  double value;
} typedef ObjectiveData;
ObjectiveData objective[MAX_OBJ];

/* constraints */
struct {
  char name[MAX_ENTRY];
  char inequality[MAX_ENTRY];
  double rhs;
  double value;
} typedef ConstraintData;
ConstraintData constraint[MAX_CONSTRAINT];
/*eject*/
/* gradual enforcement of constraints */
struct{
  int iteration; /* current interation count of enforcement */
                 /* 0 <= iteration <= gOption.gradualconstraint */
  double factor; 
   /* = current factor used in enforcement
    *   enforce j if constr[j] < factor * maxviol[j]
    * if gOption.gradualconstraint > 0:   
    *   factor = 1 - iteration/gOption.gradualconstraint 
    * else 
    *    factor = 0.0
    */
  double maxviolation[MAX_CONSTRAINT]; 
    /* maxviolation[j] = max violation of constr j by a population */
  double scale[MAX_CONSTRAINT]; 
    /* scale[j] = scale factor applied to constr j */
    /*     scale[] makes constraints equally significant */
    /*     and is determined once, using initial maxviolation[] */

  double threshold[MAX_CONSTRAINT];
   /* threshold[j] = threshold below which constr j is enforced */
} typedef GradualConstraint;
GradualConstraint gradCon;
/*eject*/
/* corners */
char corner[MAX_CORNER][MAX_ENTRY];
int nCorners;

/* variable names */
char name_realvar[MAX_VARIABLE][MAX_ENTRY];

/* counts triggering convergence test */
int convergeTestEval; /* frequency with which convergence is */
                      /* checked; next convergence test is */
                      /* performed when at least the specified */
                      /* number of evaluations have been done */
                      /* if convergence test is to avoided */
                      /*    entirely: set value >= max number */
                      /*    of evaluations */
int testEvaluationCount; /* evaluation count at most recent */
                         /* convergence test */
double convergenceAccuracy;
int convergenceFlag;
int numberDominanceTestSequence;
    /* numberDominanceTestSequence%2 = 0: most recently had a */
    /*                                    dominance test */
    /*                               = 1: most recently had a min */
    /*                                    or max obj reduction */
    /* numberDominanceTestSequence/2 = number of uninterrupted */
    /*                                 dominance sequences */
double actualAccuracy;

/*eject*/
/************ math library **********/
double pow(double,double);
double sqrt(double x);

/* routines */

/* main programs */
/* multicc.c */          /* gencc, multicc, nsga, nomad execution */

/* blackbox.nomad.c */
void evaluateNomadVector(); 
void readTransferNomadParams();

/* beginParam.c */
void beginParam();
void callArguments();
void createParamsFromInput();
void defineParameters();
void displayOptions();
void listOptions();

/* cycleCount.c */
void beginCycleCount(int k);
void increaseCycleCount(int k);
int readCycleCount();

/* eliminated Nov, 2011 */
/* doMatch.lb.c */
/* void doMatch();
void defineMatchInput();
double integerValue2realValue(int typeflag, int index, int ivalue);
int realValue2integerValue(int typeflag, int index, double rvalue);
void solution2candidate(); */

/* decideConvergence.lb.c */
int decideConvergence(population *pop);
int testDistribution();
int testDominance();
/*eject*/
/************ dencon routines ***********/

/* denconmain.c */
int denconmain();

/* dencon.c */
void dencon(double *x);
void denconsolution(char *label);
void denconstop();

/* denconLinesearch.c */
void linesearchbox_cont(double *x,double *f_,double *d,
                        double *alfa_,double *alfa_d,
                        double *z1,double *fz1_,
                        double *z2,double *fz2_,
                        double *z,double *fz,
                        int *num_fal_);
void linesearchbox_dense(double *x,double *f_,double *d,
                         double *alfa_,double *alfa_d_,
                         double *z1,double *fz1_,
                         double *z2,double *fz2_,
                         double *z,double *fz_, 
                         int *num_fal_);

/* denconPredict.c */
void predict_cont(double *x,double *f_,double *d,
                  double *alfa_,double *alfa_d,
                  double *z1,double *fz1_,
                  double *z2,double *fz2_,
                  double *z,double *fz_, 
                  int *num_fal_);
void predict_dense(double *x,double *f_,double *d,
                   double *alfa_,double *alfa_d_,
                   double *z1,double *fz1_,
                   double *z2,double *fz2_,
                   double *z,double *fz_, 
                   int *num_fal_);
double storeAllz(int ielle,double *z);
double storeAllzdelta(int ielle,double *z);
void transfer2plin(double *x,double *f_,double *d,
                  double *alfa_,double *alfa_d,
                  double *z1,double *fz1_,
                  double *z2,double *fz2_,
                  double *z,double *fz_, 
                  int *num_fal_);
/*eject*/
/* denparProblem.c */
void   convertDenconOutput2finalPopOut();
void   denconbounds();
void   denconstart(double *x);

/* denconUtil.c */
void   extract_parallelCandidate(int idx, double *x,  
                                 double *func_, double *ob_, 
                                 double *con, double *vio_);
double relative_distance(double *v1, double *v2, int nsize);
int    same_parallelCandidate(double *v1, int idx, int nsize);
int    same_vector(double *v1, double *v2, int nsize);
void   vector2parallelCandidate(double *v1, int idx, int nsize);
void   vector2vector(double *v1, double *v2, int nsize);
void   xplusdir2z(double *x, double coeff, double *dir, 
                double *z, int nsize);

/* denconXstore.c */
double computeXvalues(double *x);
double evaluateOnSameProcessor(double *x);
double evaluateZ(double *z);
double evaluateZandAllz(double *z, int ielle);
int memberXstore(double *x);
void moveupXstore(int k);
double queryXstore(double *x);
void retainXstore(double *x);

/* halton.c */
void halton(int index,double *xx);
void gen_base(double *d1);
void gram_schmidt();

/************ denpar routines ***********/

/* denparmain.c */
int denparmain();

/* denpar.c */
void   denpar();
void   denparsolution(char *label);
void   output_progress();
void   teststop();
/*eject*/
/* denparProblem.c */
void   convertDenparOutput2finalPopOut();
void   denparbounds();
void   denparstart(double *x);
double evaluateDenparVector(double *x);
/*eject*/
/* denparSearch.c */
int compute_progress();
void initialize_alfa_d(double *alfa_d);
void initialize_directions();
void next_alfa_d(int typ_dir,double *alfa_d);
void next_direction_matrix(double *d);
void next_point();
void next_type_direction(double *alfa_d, double *d);

/* denparSelect.c */
void decide_factor();
int  decide_termination();
void define_trial_point();
void define_nselect(int *start);
void evaluate_all_points();
void evaluate_one_point(int i, int k);
void select_alfa();
void update_alfa_d(double *alfa_d);
void update_best_search();
void update_done_flag();

/* denparXstore.c */
void   computeXcurrent_solution();
double computeX(double *x, int *lookup);
void   output_history();
void   retainX(double *x);
int    update_eps();

/* debugstate.c */
void debugstatus(char *debugfile);

/*
 * denpar uses dencon routines of the following files:
 * denconUtil.c:
 *   extract_parallelCandidate(int idx, double *x, 
 *          double *func, double *ob, double *const, double *vio)
 *   same_parallelCandidate(double *v1, int idx, int nsize) 
 *   same_vector(double *v1, double *v2, int nsize)
 *   vector2parallelCandidate(double *v1, int idx, 
 *                                 int nsize) 
 *   vector2vector(double *v1, double *v2, int nsize)
 *   xplusdir2z(double *x, double coeff, double *dir, 
 *                       double *z, int nsize)
 *
 * halton.c:
 *   halton(int index,double *xx);
 *   gen_base(double *d1);
 *   gram_schmidt();
 */
/***************************************/
/*eject*/
/* eval.lb.c */
void evaluate_pop (population *pop);
void estimateObjConstr();
void evaluate_candidate();
void evaluate_one_pop (population *pop);
void evaluate_ind (individual *ind);
void evaluate_parallelPop2candidate(population *pop);
int  finalObjConstr(population *pop);
void getCandidateMinMax();
void getObjConstrFromPrior();
void getPopulationMinMax(population *pop);
void getPriorCandidateMinMax();
void reduceAboveObjBoundCandidate();
int  reduceInfeasibleDominatedDuplicateCandidate();
int  testFeasibleSolution(population *pop);

/* eval.parallel.c */
void evaluate_parallelCandidate(char *method, int kflag);
void parallelQueryBlackbox();
void parallelReadOutbox(int p, int *begin, int *size);
void parallelTest_problem();
void parallelWriteInOutbox(int *begin, int *size);

/* increasePopulation.lb.c */
void increasePopulation(population *pop, int nincr);

/* kmeans.lb.c */
int kmeans(population *pop, int minpick, int maxpick);
int dominate(double *xobj, double xconstr_violation,
             double *yobj, double yconstr_violation);

/* licenseStatement.c */
void licenseStatement(char* global,char *date);

/* linearinequality.c */
double checkLinearInequality(double *x, int n);

/* initialize.lb.c */
/* note: initialize_pop() and initialize_ind() defined in global.h */
void initialize_one_pop (population *pop);

/* modifyconstraint.c */
void modifyConstr(population *pop);
void enforceobj(population *pop);
void defineGradConScale(population *pop);
void ignoreConstr(population *pop);
void scaleConstr(population *pop);
void weakenConstr(population *pop);

/*eject*/
/* params.multi.c */
int addFinalPop2outputMulti(FILE *outputfil);
void defineMultiParams(FILE *outputfil);
int getFinalPopEvaluationCount();

/* params.nomad.c */
void convertNomadOutput2finalPopOut();
void defineTransferNomadParams();
void defineNomadParams();

/* problemdef.lb.c */
void test_problem (int FunctionFlag, char *name, double *xreal, 
                   double *obj, double *constr);

/* queryblackbox.lb.c */
void queryBlackBox(char *name, double *xreal, 
                   double *obj, double *constr);
void readOutbox(char *name, double *xreal, 
                   double *obj, double *constr);
void writeInbox(char *name, double *xreal, 
                   double *obj, double *constr);

/* random.lb.c: currently not used */
double myRand();        /* 0.0-1.0 random number */
void mySrand2();        /* initialize sedd array */
void myMainSrand1();    /* initialize main seed */
void myPartialSrand5(); /* initialize partial seed array */
                        /* by resetting the 5 region seeds */

/* readParams.lb.c */
void readParams(char *name, int printflag);
void initsol2inputCandidate(char *filename);
void lineread2inputCandidate(char *lineread, char *saveread,
                             int nskip);
void readProcessor();
void writeProcessor();
/*eject*/
/************ seqpen routines ***********/

/* seqpenmain.c */
int seqpenmain();

/* seqpen.c */
void   seqpen();
void   displaysolution(char *label);
double funct(double *x);
void   linesearchbox();
void   seqpenstop();

/* seqpenproblem.c */
void   convertSeqpenOutput2finalPopOut();
double evaluateSeqpenVector(double *x);
void   fconstr(double *x);
double fobj(double *x);
void   setbounds();
void   setdim();
void   startp(double *x);

/*****************************************/
/*eject*/
/* singleminout.c */
int decideAcceptance(double *x);
void prepareAcceptRejectCandidate();
void singleminoutfile2candidate();

/* stringoperation.lb.c */
int tokenize(char *lineread);

/* util.lb.c */
void candidateSingle2population(population *pop, int nselect);
void candidateTrue2population(population *pop);
void candidateTrue2priorCandidate();
void candidateTrue2someCandidate(SampleRecord *someCandidate,
                                 int *nSomeCandidates);
double distanceSquared2vectors(double *x, double *y, 
                        double *low, double *high, int nvar);
void eliminateTrue();
void closeFile(FILE* file);
FILE* openFile(char* name, char* mode);
void outputStats(population *pop);
void parallelCandidate2candidateTrue();
void population2candidate(population *pop, int *next, int kflag);
void population2candidateSingle(population *pop, int nselect);
void population2candidateTrue(population *pop);
void population2parallelCandidate(population *pop, int kflag);
void population2parentCandidate(population *pop, int *next, int kflag);
double roundDownToInt(double x);
double roundUpToInt(double x);
void someCandidate2candidate(SampleRecord *someCandidate,
                             int nSomeCandidates, int *next);
void someCandidate2otherCandidate(SampleRecord *someCandidate,
                                  int nSomeCandidates,
                                  SampleRecord *otherCandidate,
                                  int *nOtherCandidates);
void singleminout2singleminoutCandidate();
void starttime();
void stoptime();
/************** xRoutines.lb.c ***************/
int Xexecute(char *cmnd);
int Xmulticontrol(char *instruction, char *filename);
int Xnomad();

/* last record of sample.lb.h *****************/

