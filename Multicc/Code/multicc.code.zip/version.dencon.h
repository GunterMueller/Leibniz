/****************************************************************/
/* activate exactly one of the statements below  */
#define DENCON  /* dencon */
#undef  DENPAR  /* denpar */
#undef  GENCC   /* gencc */
#undef  MULTICC /* multicc */
#undef  NOMAD   /* nomad */ 
#undef  NSGA    /* nsga  */
#undef  SEQPEN  /* seqpen */
/****************************************************************/
