/* quad2 black box example for testing multicc */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"

#define MAX_STATE 5
/*eject*/
int main (int argc, char **argv) 
{

  int i, j;

  int nreal, ncon, nobj, nstates;

  double xreal[MAX_VARIABLE];
  double obj[MAX_OBJ];

  char lineread[MAXLEN];

  char name[MAX_ENTRY];
  char inboxfile[MAX_ENTRY];
  char outboxfile[MAX_ENTRY];

  FILE *inboxfil;
  FILE *outboxfil;

  if (argc != 4) {
    printf(
      "\n Usage: quad2.blackbox problemName inboxfile outboxfile\n");
    exit(1);
  }

  strcpy(name,argv[1]);
  strcpy(inboxfile,argv[2]);
  strcpy(outboxfile,argv[3]);

  /* DEBUG: comment out the eight lines above and */
  /*         activate the three lines below */
  /* strcpy(name,"optim");
  strcpy(inboxfile,"optim.inbox");
  strcpy(outboxfile,"optim.outbox"); */

  inboxfil = fopen(inboxfile,"r");
  outboxfil = fopen(outboxfile,"w");

/******** section below must be modified for specific case ********/
  /* initialization of counts */
  /* the values for nreal, nobj, and ncon values must agree with */
  /* the corresponding values in the input file */
  /* note: nstates cannot be determined from the inbox file */
  /*       indeed, nstates is not supplied to multicc */  
  nreal = 5;   /* total number of variables */
  nint = 0;    /* number of integer variables */
  nobj = 2;    /* number of objectives */
  ncon = 0;    /* number of constraints */
  nstates = 0; /* number of states */
/******************************************************************/

  /* read records with xreal[] and corner string */
  /* convert corner string to state values */
  while (fgets(lineread,MAXLEN,inboxfil) != NULL) { /* while #2 */
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty or '#' lines */
    if ((lineread[0] == '\0') || (lineread[0] == '#')) {
      continue;
    }

    tokenize(lineread);
    /* xreal[] values */
    for (j=0; j<nreal; j++) {
      xreal[j] = atof(token[j]);
    }

/******** section below must be modified for specific case ********/
    /* specify obj and constr values */
    obj[0] = 0.0;
    obj[1] = 0.0;
    for (i=0; i<nreal; i++) {
      obj[0] += pow(xreal[i]+0.2,2.0);
      obj[1] += pow(xreal[i]-0.2,2.0);      
    }

 
/******************************************************************/

    /* write obj values into outbox file */
    for (j=0; j<nobj; j++) {
      fprintf(outboxfil,"%g\t",obj[j]);
    }
    for (j=0; j<nreal; j++) {
      fprintf(outboxfil,"%g\t",xreal[j]);
    }
    fprintf(outboxfil,"\n");

  } /* end while #2 */

  fclose(inboxfil);
  fclose(outboxfil);

  return 0;

}
/********* last record of optim.c *********/
