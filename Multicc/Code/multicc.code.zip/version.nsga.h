/****************************************************************/
/* activate exactly one of the five statements below  */
#undef  DENCON  /* dencon */
#undef  DENPAR  /* denpar */
#undef  GENCC   /* gencc */
#undef  MULTICC /* multicc */
#undef  NOMAD   /* nomad */ 
#define NSGA    /* nsga  */
#undef  SEQPEN  /* seqpen */
/****************************************************************/
