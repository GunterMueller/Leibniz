#!/usr/local/bin/python3
import os
class DummyPython:
    ''' Used for create dummy outbox file using dummy.inbox file.
    
        if we give n designerVariables than it will generate n-1 objectives and
        constraints
    '''
    # to check wthere filePath exist if not then use 
    # pwd dummy.inbox file
    filetext =[]
    filePath = '/dev/shm/dummy/dummy.inbox'
    if os.path.exists(filePath):
                filePath=filePath
    else :
        print('\n----------------------')
        print('\nWARNING ')
        print('\n----------------------')
        print(filePath+ ' does not exist so we use  '+\
              'from present directory this file: dummy.inbox')
        filePath = 'dummy.inbox'
    inboxFile = open(filePath)
    # to check wthere the directory is exist then create file 
    # in pwd dummy.outbox
    directoryPath = '/dev/shm/dummy/'
    if os.path.exists(directoryPath):
        filePath1='/dev/shm/dummy/dummy.outbox'
    else :
        print('\n----------------------')
        print('\nWARNING ')
        print('\n----------------------')
        print(directoryPath+ ' does not exist so we write   '+\
              'in present directory directory this file: dummy.outbox')
        filePath1 = 'dummy.outbox'

    outboxFile = open(filePath1,'w')
    dummyDesignerVariableList =[]
    dummyConstraintList = []
    dummyObjectiveList = []
    # print('\n----------------------')
    # print('reading inbox file')
    # print('\n----------------------')
    # read dummy.inbox file
    for line in inboxFile:
        # remove whitespace from the beginning and end 
        line = line.strip()
        #to split file
        words = line.split()
        var1=float(words[0])
        var2=float(words[1])
        var3=float(words[2])
    dummyDesignerVariableList.append(var1)
    dummyDesignerVariableList.append(var2)
    dummyDesignerVariableList.append(var3)
    # for constraint  subtract two consecutive designerVariable value
    constraint1 = var1-var2
    constraint2 = var2-var3
    dummyConstraintList.append(constraint1)
    dummyConstraintList.append(constraint2)
    # for objective  add two consecutive designerVariable value
    objective1 = var1+var2
    objective2 = var2+var3     
    dummyObjectiveList.append(objective1)
    dummyObjectiveList.append(objective2)
    #write objective in outbox file
    for dummyObjecitve in dummyObjectiveList:
        filetext.append(str(dummyObjecitve))
    #write constraint  in outbox file
    for dummyConstraint in dummyConstraintList:
        filetext.append(str(dummyConstraint))
    for dummyDesignerVariable in dummyDesignerVariableList:
        filetext.append(str(dummyDesignerVariable))
    # print('\n----------------------')
    # print('writing into outbox file ')    
    # print('\n----------------------')
    for text in filetext:
        outboxFile.write(text+' ')
    #close both file
    
    inboxFile.close()
    outboxFile.close()
    # print('\n----------------------')
    # print('closing both the files')
    # print('\n----------------------')
        
if __name__=="__main__":
    DummyPython()
