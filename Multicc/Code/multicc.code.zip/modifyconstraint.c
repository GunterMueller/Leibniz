/* Data initialization routines */
# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"

/* CAUTION: All arrays are used with starting index = 0 */
/* in agreement with NSGA-II code */

/***************************************************************
 *
 * subroutines in this file:
 *   void modifyConstr(population *pop)
 *   void enforceobj(population *pop)
 *   void gradConScale(population *pop)
 *   void ignoreConstr(population *pop)
 *   void scaleConstr(population *pop)
 *   void weakenConstr(population *pop)
 *
 ***************************************************************/
/*eject*/
/****************************************************
 * modifyConstr: modify constr_violation according to options
 *               -ignoreConstr, -changeConstr, -scaleConstr   
 ****************************************************/
void modifyConstr(population *pop) {

  /* modify constr_violation for pop under constraint options */
  /*     -ignoreconstraint, gradualconstraint, -scaleconstraint */
  /*     changes are done for constr_violation only */
  /*     constr[] values are not affected */
  if (gOption.ignoreconstraint == TRUE) {
    /* set constr_violation to 0 for pop */
    ignoreConstr(pop);
  } else if (gOption.gradualconstraint > 0) {
    /* weaken constr_violation of pop */
    weakenConstr(pop);
  } else if (gOption.scaleconstraint == TRUE) {
    /* scale constr */
    /* compute constr_violation for pop using scaled constr */
    scaleConstr(pop);
  }

  /* enforce obj options */
  if ((gOption.objgoal == TRUE)   ||
      (gOption.objbound == TRUE)) {
    enforceobj(pop);
  }

  return;

}
/*eject*/
/****************************************************
 * enforceobj(population *pop):
 *     for each individual of population pop: 
 *     enforce goals and bounds on objs by increasing
 *     constr_violation  
 ****************************************************/
void enforceobj(population *pop) {

  int i, j;

  individual *indd;


  for (i=0; i<popsize; i++) {
    indd = &(pop->ind[i]);
    /* compute constraint violation due to constraints */
    /* using standard nsga formula */
    indd->constr_violation = 0.0;
    for (j=0; j<ncon; j++) {
      if (indd->constr[j] < 0) {
        indd->constr_violation += 
          indd->constr[j];
      }
    }

    /* add 2*(violation of obj goals) if obj < goal */
    for (j=0; j<nobj; j++) {
      if ((indd->obj[j] - objGoal[j]) < 0) {
        indd->constr_violation += 2.0*(indd->obj[j] - objGoal[j]);
      }
    }

    /* add 2*(violation of obj bounds) if bound < obj */
    for (j=0; j<nobj; j++) {
      if ((objBound[j] - indd->obj[j]) < 0) {
        indd->constr_violation += 2.0*(objBound[j] - indd->obj[j]);
      }
    }
  }

  return;

}
/*eject*/
/****************************************************
 * defineGradConScale(population *pop): 
 *    define gradCon scale[] using pop 
 ****************************************************/
void defineGradConScale(population *pop) {

  int i, j;

  individual *indd;

  /* maxviolation[] */
  for (j=0; j<ncon; j++) {
    gradCon.maxviolation[j] = 0.0;
    for (i=0; i<popsize; i++) {
      indd = &(pop->ind[i]);   
      gradCon.maxviolation[j] = 
        min(indd->constr[j],gradCon.maxviolation[j]);
    }
  } 

  /* scale[] = -1.0/gradCon.maxviolation[j] in nontrivial case */
  for (j=0; j<ncon; j++) {
    if (gradCon.maxviolation[j] >= 0) {
      gradCon.scale[j] = 1.0;
    } else {
      gradCon.scale[j] = -1.0/gradCon.maxviolation[j];
    }
  }
 
  return;

} 
/*eject*/
/****************************************************
 * ignoreConstr: set constr_violation to 0 for pop
 *    
 ****************************************************/
void ignoreConstr(population *pop) {

  int i;

  individual *indd;

  for (i=0; i<popsize; i++) {
      indd = &(pop->ind[i]); 
      indd->constr_violation = 0.0;  
  }  

  return; 

}

/*eject*/
/****************************************************
 * scaleConstr: scale constraint_violation for pop
 *     input:  gradCon scale[]
 *     output: constr_violation for pop 
 ****************************************************/
void scaleConstr(population *pop) {

  int i, j;

  individual *indd;

  for (i=0; i<popsize; i++) {
    indd = &(pop->ind[i]);
    indd->constr_violation = 0.0;
    for (j=0; j<ncon; j++) {
      if (indd->constr[j] < 0) {
        indd->constr_violation += 
          indd->constr[j] * gradCon.scale[j];
      }
    }  
  }  

  return; 

}
/*eject*/
/****************************************************
 * weakenConstr: weaken constraint_violation of pop
 *     input:  gradCon iteration and scale[]
 *     output: constr_violation for pop
 ****************************************************/
void weakenConstr(population *pop) {

  int i, j;

  individual *indd;

  if (gradCon.iteration < gOption.gradualconstraint) {
    /* factor = 1 - iteration/gOption.gradualconstraint */
    gradCon.factor = 
    1.0-((double)gradCon.iteration)/
        ((double)gOption.gradualconstraint);
  } else {
    gradCon.factor = 0.0;
  }
 
  /* maxviolation[] for constr[j] */
  for (j=0; j<ncon; j++) {
    gradCon.maxviolation[j] = 0.0;
    for (i=0; i<popsize; i++) {
      indd = &(pop->ind[i]);
      gradCon.maxviolation[j] = 
          min(indd->constr[j],gradCon.maxviolation[j]);
    }
  }
/*eject*/
  /* threshold[] */
   for (j=0; j<ncon; j++) {
     gradCon.threshold[j] = 
         gradCon.factor * gradCon.maxviolation[j];
  } 

  /* constr_violation */
  for (i=0; i<popsize; i++) {
    indd = &(pop->ind[i]);
    indd->constr_violation = 0.0;
    for (j=0; j<ncon; j++) {
      if (indd->constr[j] < gradCon.threshold[j]) {
        indd->constr_violation += 
          gradCon.scale[j]*indd->constr[j];
      }
    }
  }

  return;

}
/******** last record of modifyconstraint.c ********/
