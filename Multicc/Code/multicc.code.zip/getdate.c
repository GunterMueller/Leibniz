/* getdate(): get date and place into versiondate.h */
# include <stdio.h>
# include <string.h>
# include <time.h>

#define MAXLEN 15000
#define MAX_ENTRY 256

int main (int argc, char **argv)
{

  time_t timeNow;
  char timeString[MAXLEN];

  char versionfile[MAX_ENTRY];
  FILE *versionfil;

  strcpy(versionfile,"versiondate.h");
  versionfil = fopen(versionfile,"w");

  timeNow = time(NULL);
  strftime(timeString,MAXLEN,"%b %d %Y",localtime(&timeNow));

  fprintf(versionfil,"    strcpy(versiondate,\"Compiled: %s\");\n",
          timeString);
  fclose(versionfil);

  return 0;

}
/********** last record of getdate.c *************/
