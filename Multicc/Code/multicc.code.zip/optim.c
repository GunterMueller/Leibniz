/* optim black box example for testing multicc */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"
/*eject*/
int main (int argc, char **argv) 
{

  int i, j;

  int nreal, ncon, nobj;

  double xreal[MAX_VARIABLE];
  double obj[MAX_OBJ];
  double constr[MAX_CONSTRAINT];

  char lineread[MAXLEN];

  char name[MAX_ENTRY];
  char inboxfile[MAX_ENTRY];
  char outboxfile[MAX_ENTRY];

  FILE *inboxfil;
  FILE *outboxfil;

  if (argc != 4) {
    printf(
      "\n Usage: optim.blackbox problemName inboxfile outboxfile\n");
    exit(1);
  }

  strcpy(name,argv[1]);
  strcpy(inboxfile,argv[2]);
  strcpy(outboxfile,argv[3]);

  /* DEBUG: comment out the eight lines above and */
  /*         activate the three lines below */
  /* strcpy(name,"optim");
  strcpy(inboxfile,"optim.inbox");
  strcpy(outboxfile,"optim.outbox.temp"); */

  inboxfil = fopen(inboxfile,"r");
  outboxfil = fopen(outboxfile,"w");

/******** section below must be modified for specific case ********/
  /* initialization of counts */
  /* the values for nreal, nobj, and ncon values must agree with */
  /* the corresponding values in the input file */
  nreal = 5;   /* total number of variables */
  nint = 0;    /* number of integer variables */
  nobj = 3;    /* number of objectives */
  ncon = 3;    /* number of constraints */
/******************************************************************/

  /* read records with xreal[] */
  while (fgets(lineread,MAXLEN,inboxfil) != NULL) { /* while #2 */
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty or '#' lines */
    if ((lineread[0] == '\0') || (lineread[0] == '#')) {
      continue;
    }

    tokenize(lineread);
    /* xreal[] values */
    for (j=0; j<nreal; j++) {
      xreal[j] = atof(token[j]);
    }

/******** section below must be modified for specific case ********/
    /* specify obj and constr values */
    obj[0] = xreal[0] + xreal[1];
    obj[1] = xreal[1] + xreal[2];
    obj[2] = xreal[3] + xreal[4];

    constr[0] = xreal[0] - xreal[1];
    constr[1] = xreal[2] + xreal[3] - xreal[4];
    constr[2] = xreal[3] - xreal[4];
/******************************************************************/

    /* write obj and constr values into outbox file */
    for (j=0; j<nobj; j++) {
      fprintf(outboxfil,"%g\t",obj[j]);
    }
    for (j=0; j<ncon; j++) {
      fprintf(outboxfil,"%g\t",constr[j]);
    }
    for (j=0; j<nreal; j++) {
      fprintf(outboxfil,"%g\t",xreal[j]);
    }
    fprintf(outboxfil,"\n");

  } /* end while #2 */

  fclose(inboxfil);
  fclose(outboxfil);

  return 0;

}
/********* last record of optim.c *********/
