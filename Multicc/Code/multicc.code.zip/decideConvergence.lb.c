/********* first record of decideConvergence.lb.c */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *   int decideConvergence()
 *   int testDistribution()
 *   int testDominance()
 ****************************************************************/
/*eject*/
/**************************************************************
 * int decideConvergence(): decide convergence based on
 *   - change of obj[] min/max values
 *   - distribution of obj[] values (use only if nobj >= 2)
 *   - domination of (candidate[]+volumeGap), with keepFlag = TRUE, 
 *       by priorCandidate[]
 **************************************************************/
int decideConvergence(population *pop) {

  int i, j, flag;

  /* get min/max values of candidate[] */
  getCandidateMinMax();

  if (generationCount == 2) {

    /* initialize testEvaluationCount, referenceCandidate[] */
    testEvaluationCount = evaluationCount;
    /* store population in candidate[] with keepFlag = TRUE */
    nCandidates = 0;
    curPopsize = popsize;
    population2candidate(pop, &nCandidates, TRUE);

    /* retain candidateMinvalue.obj[], 
     *        candidateMaxvalue.obj[]
     * as
     *        previousCandidateMinvalue.obj[]
     *        previousCandidateMaxvalue.obj[]
     */
    for (j=0; j<nobj; j++) {
      previousCandidateMinvalue.obj[j] = candidateMinvalue.obj[j];
      previousCandidateMaxvalue.obj[j] = candidateMaxvalue.obj[j];
    }

    /* retain max constr violation value */
    previousCandidateMaxvalue.constr_violation = 
       candidateMaxvalue.constr_violation;
/*eject*/
    /* store priorCandidate[] in referenceCandidate[] */
    someCandidate2otherCandidate(priorCandidate,
                                 nPriorCandidates,
                                 referenceCandidate, 
                                 &nReferenceCandidates);
    /* initialize distributionBucket[][] and related count */
    for (j=0; j<nobj; j++) {
      for (i=0; i<MAX_BUCKET; i++) {
        distributionBucket[j][i] = FALSE;
      }
    }
    repeatedDistributionCount = 0;
    /* initialize actualAccuracy */
    actualAccuracy = 1.0;
    /* initialize number of dominance test sequences */
    numberDominanceTestSequence = 0;

    return FALSE;
  }

  /* have generationCount > 2 */

  /* decide convergence for infeasible case */

  if (candidateMaxvalue.constr_violation < 0) {
    /* all candidates are infeasible */
    /* compare previous and current max constr violation */
    if (previousCandidateMaxvalue.constr_violation <
        candidateMaxvalue.constr_violation) {
      /* have improvement toward feasibility */
      /* update previousCandidateMaxvalue.constr_violation */
      previousCandidateMaxvalue.constr_violation = 
          candidateMaxvalue.constr_violation;
      numberDominanceTestSequence = 0;
    }  else {
      /* no improvement toward feasibility */
      numberDominanceTestSequence++;
    }
    return FALSE; /* implies that termination under infeasible */
                  /* is decided by numberDominanceTestSequence */
  }
/*eject*/
  /* decide convergence for feasible case */

  /* define default flag values depending on nobj */
  if (nobj == 1) {
    flag = TRUE;
  } else {
    flag = FALSE;
  }

  if (testEvaluationCount+convergeTestEval <= evaluationCount) {

    /* store population in candidate[] with keepFlag = TRUE */
    nCandidates = 0;
    curPopsize = popsize;
    population2candidate(pop, &nCandidates, TRUE);
    /* get min/max obj values of candidate[] */
    getCandidateMinMax();
    /* check if the min/max values are unchanged */
    flag = TRUE; /* means that values are unchanged */
    for (j=0; j<nobj; j++) {
      /* check if min has decreased or max has decreased  */
      /* or min violates goal or max violates bound */
      if ((previousCandidateMinvalue.obj[j] > 
           candidateMinvalue.obj[j]+objTolerance[j])||
          (previousCandidateMaxvalue.obj[j] > 
           candidateMaxvalue.obj[j]+objTolerance[j])||
          (objGoal[j]  > candidateMinvalue.obj[j])  ||
          (objBound[j] < candidateMaxvalue.obj[j])) { 
        flag = FALSE;
        if (nobj >= 2) {
          /* since min or max value has decreased or */
          /* min violates goal or max violates bound */
          /* reset distributionBucket[][] */
          for (j=0; j<nobj; j++) {
            for (i=0; i<MAX_BUCKET; i++) {
              distributionBucket[j][i] = FALSE;
            }
          }
          repeatedDistributionCount = 0;
          if (numberDominanceTestSequence%2 == 0) {
            numberDominanceTestSequence++;
          }
        }
        break;
      }
    }
    if (gOption.printdetail == 2) {
      printf("\n   min/max change flag = %d",flag);
    }
/*eject*/
    /* if nobj >= 2: test distribution and domination */
    /* check if distribution of obj[] values is acceptable */
    if (nobj >= 2) {
      if (flag == TRUE) {
        flag = testDistribution();
        if (gOption.printdetail == 2) {
          printf("\n   distribution flag   = %d",flag);
        }
      }
      /* test domination of (candidate[]+volumeGap), */
      /* with keepFlag = TRUE, by referenceCandidate[] */
      if (flag == TRUE) {
        flag = testDominance();
        if (gOption.printdetail == 2) {
          printf("\n   dominance flag      = %d",flag);
          printf("\n   accuracy            = %f",actualAccuracy);
          printf("   (required = %f)",convergenceAccuracy);
        }
        if (numberDominanceTestSequence%2 == 1) {
          numberDominanceTestSequence++;
        }
      }
    }

    /*
     * retain candidateMinvalue.obj[], 
     *        candidateMaxvalue.obj[]
     * as
     *        previousCandidateMinvalue.obj[]
     *        previousCandidateMaxvalue.obj[]
     */
    for (j=0; j<nobj; j++) {
      previousCandidateMinvalue.obj[j] = candidateMinvalue.obj[j];
      previousCandidateMaxvalue.obj[j] = candidateMaxvalue.obj[j];
    }
    /* update testEvaluationCount */
    testEvaluationCount = evaluationCount;
    /* store priorCandidate[] in referenceCandidate[] */
    someCandidate2otherCandidate(priorCandidate,
                                 nPriorCandidates,
                                 referenceCandidate, 
                                 &nReferenceCandidates);
  } /* end if testEvaluationCount+testInterval <= evaluationCount */
  if (gOption.printdetail == 2) {
    printf("\n   convergence flag    = %d",flag);
  }

  return flag;

}
/*eject*/
/**************************************************************
 * int testDistribution(): check if distribution of obj[]
 *    in buckets defined via obj[] max/min values is acceptable
 *    'acceptable': (1) if distribution has not changed from last
 *                      most recent check, and 
 *                  (2) for some j, all buckets are used
 *    if distribution has not changed and gOption.dynamicbound >= 1: 
 *       tighten obj bounds
 *    output: TRUE if distribution is acceptable
 *            FALSE otherwise
 * note: nobj > 1 holds
 **************************************************************/
int testDistribution() {

  int bfull, bopen, i, inflag, j, n, nb;
  int flag; /* = TRUE if distribution has not been improved */
    /*         = FALSE otherwise */
  double width[MAX_BUCKET]; /* bucket width */ 

  nb = MAX_BUCKET;
  flag = TRUE;

  /* check if distribution has changed */

  /* define bucket width */
  for (j=0; j<nobj; j++) {
    /* width[j] of buckets for obj j */
    width[j] = (candidateMaxvalue.obj[j] - 
             candidateMinvalue.obj[j])/
            ((double)nb);
  }
/*eject*/
  for (n=0; n<nPriorCandidates; n++) {

    /* check whether priorCandidate[n].obj[] values are in */
    /* intervals defined by candidateMinvalue.obj[] and */
    /* candidateMaxvalue.obj[] */
    inflag = TRUE;
    for (j=0; j<nobj; j++) {
      if ((priorCandidate[n].obj[j] < candidateMinvalue.obj[j]) ||
          (priorCandidate[n].obj[j] > candidateMaxvalue.obj[j])) {
        inflag = FALSE;
        break;
      }
    }
    if (inflag == FALSE) {
      /* priorCandidate[n] is outside at least one interval */
      /* skip priorCandidate[n] */
      continue;
    }
/*eject*/
    /* compute indices of buckets containing */
    /* priorCandidate[n].obj[] */
    for (j=0; j<nobj; j++) {
      /* compute bucket index */
      if (width[j] > 0) {  
        i = (priorCandidate[n].obj[j]-candidateMinvalue.obj[j])/
            width[j];
        i = min (i,nb-1); /* covers max value case */
      } else {
        i = 0;
      }
      if (i < 0) {
        printf("\n testdistribution: inconsistent obj values");
        exit(1);
      }
      if (distributionBucket[j][i] == FALSE) {
        /* distribution has changed, hence do not accept */
        flag = FALSE;
        distributionBucket[j][i] = TRUE;
        repeatedDistributionCount = 0;
      }
    } /* end for j */

  } /* end for n */
/*eject*/
  if (flag == TRUE) {
    /* distribution has not changed */

    if (gOption.dynamiclimit == TRUE) {
      /* check if first two and last two buckets are covered */
      bfull = TRUE;
      for (j=0; j<nobj; j++) {
        if ((distributionBucket[j][0] == FALSE) || 
            (distributionBucket[j][1] == FALSE) ||
            (distributionBucket[j][nb-2] == FALSE) ||
            (distributionBucket[j][nb-1] == FALSE)) {
          bfull = FALSE;
          break;
        }
      }
      /* check if there is an open bucket in-between */
      for (i=2; i<nb-2; i++) {
        bopen = TRUE;
        for  (j=0; j<nobj; j++) {
          if (distributionBucket[j][i] == TRUE) {
            bopen = FALSE;
            break;
          }
        }                             
        if (bopen == TRUE) {
          openBucketFlag = TRUE;
          break;
        }
      }        

      if ((bfull == TRUE) && (openBucketFlag == TRUE)) {
        /* end buckets are full, at some time had an in-between */
        /* bucket */  
        /* increase each objGoal[j] by width[j]/2 to remove half */
        /* of first bucket for each obj, and effectively also half */
        /* of last bucket */
        for (j=0; j<nobj; j++) {
          if ((candidateMinvalue.obj[j]+width[j]) < objBound[j]) {
            objGoal[j] = candidateMinvalue.obj[j]+width[j]/2;
          }
        }
      }         
    }
/*eject*/
    /* if same distribution has been seen for at least 
     *   MAX_REPEATEDDISTRIBUTION times or if, for some j, 
     *   all buckets are used: 
     *   accept 
     */
    repeatedDistributionCount++;
    if (repeatedDistributionCount >= MAX_REPEATEDDISTRIBUTION) {
     flag = TRUE;
    } else {
      for (j=0; j<nobj; j++) {
        flag = TRUE;
        for (i=0; i<nb; i++) {
          if (distributionBucket[j][i] == FALSE) {
            flag = FALSE;
            break;
          }
        }
        if (flag == TRUE) {
          break;
        }
      } /* end for j */
    } /* end if repeatedDistributionCount >= .. , else */    
  }  /* end if flag == TRUE */

  return flag;

}
/*eject*/
/**************************************************************
 * int testDominance(): determine min actualAccuracy so 
 *    that each (candidate[n].obj[j]+deltaValue[j]*actualAccuracy) 
 *    with keepFlag = TRUE is dominated by some
 *    referenceCandidate[i].obj[j].
 *    output: TRUE if actualAccuracy <= convergenceAccuracy
 *            FALSE otherwise
 **************************************************************/
int testDominance() {

  int i, j, n;

  double objfactor, reffactor;

  reffactor = 0.0; /* to suppress compiler warning */

  for (j=0; j<nobj; j++) {
    deltaValue[j] = max(candidateMaxvalue.obj[j]-
                        candidateMinvalue.obj[j],EPS);
    volumeGap[j] = deltaValue[j] * convergenceAccuracy;
    /* referenceMax[] is not used, but keep line below since */
    /* it is part of convergence data */
    referenceMax[j] = candidateMaxvalue.obj[j] + volumeGap[j];
  } /* end for j */
/*eject*/
  actualAccuracy = 0.0;
  /* compute min actualAccuracy so that for each n,
   * (candidate[n].obj[j]+deltaValue[j]*actualAccuracy) 
   * with keepFlag = TRUE is dominated for some i by
   * referenceCandidate[i].obj[j].
   */
  for (n=0; n<nCandidates; n++) {
    if (candidate[n].keepFlag == TRUE) {
      reffactor = 1.0;
      for (i=0; i<nReferenceCandidates; i++) {
        objfactor = 0.0;
        for (j=0; j<nobj; j++) {
          objfactor = max(objfactor,
            (referenceCandidate[i].obj[j]-candidate[n].obj[j])/
            deltaValue[j]);
        }
        reffactor = min(reffactor,objfactor);
        if (reffactor == 0.0) {
          /* cannot improve on reffactor accuracy value */
          break;
        }
      } /* end for i */     
    }
    actualAccuracy = max(actualAccuracy,reffactor);
  } /* end for n */

  /* output TRUE if actualAccuracy <= convergenceAccuracy */
  if (actualAccuracy <= convergenceAccuracy) {
    return TRUE;
  } else {
    return FALSE;
  }

}
/********* last record of decideConvergence.lb.c */
