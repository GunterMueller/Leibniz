/* begin stringoperation.lb.c */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"
/************************************************************
 *  subroutines in this file:
 *   void candidateTrue2priorCandidate()
 *   void candidateTrue2someCandidate(SampleRecord *someCandidate,
 *                                    int *nSomeCandidates);
 *   void parallelCandidate2candidateTrue();
 *   void someCandidate2candidate(SampleRecord *someCandidate,
 *                                int nSomeCandidates, int *next)
 *   void someCandidate2otherCandidate(SampleRecord *someCandidate,
 *                                     int nSomeCandidates,
 *                                     SampleRecord *otherCandidate,
 *                                     int *nOtherCandidates)
 ****************************************************************/
/*eject*/
/**************************************************************
 * candidateTrue2priorCandidate(): add feasible, undominated
 *   candidate[] records with keepFlag = TRUE to priorCandidate[]
 *  input:  candidate[]
 *          priorCandidate[] feasible, undominated records
 *  output: priorCandidate[] enlarged by candidate[] records
 *            with keepFlag = TRUE such that  new priorCandidate[]
 *            has feasible, undominated records
 *  caution: process may result in duplicate records in
 *           priorCandidate[] 
 **************************************************************/
void candidateTrue2priorCandidate() {

  int j, n, ncand, np;
  int betterct;/* # of times candidate[n].obj[] is better than */
               /*    priorCandidate[np].obj[] */
  int worsect; /* # of times candidate[n].obj[] is worse than */
               /*    priorCandidate[np].obj[] */
  int addflag; /* = TRUE:  store candidate[n] in priorCandidate[] */
               /* = FALSE: do not store candidate[n] */

  ncand = curPriorCandidate;

  for (n=0; n<nCandidates; n++) {

    if (candidate[n].keepFlag == TRUE) {
      /* check feasibility of candidate */
      /* use constr[] since constr_violation may have been */
      /* modified to handle objGoal[] or objBound[] */
      addflag = TRUE;
      for (j=0; j<ncon; j++) {
        if (candidate[n].constr[j] < 0) {
          /* infeasible */
          addflag = FALSE;
          break;
        }
      }      
      if (addflag == FALSE) {
        /* skip infeasible case */
        continue;
      }
      /* if candidate[n] beats a priorCandidate[] case, replace */
      /*    all such cases by candidate[n]; */
      /* if candidate[n] is beaten by some priorCandidate[np], */
      /*    skip candidate[n] */
      /* else add candidate[n] to priorCandidate[] */
      for (np=0; np<nPriorCandidates; np++) {
        betterct = 0;
        worsect = 0;
        for (j=0; j<nobj; j++) {
          if (candidate[n].obj[j] <= priorCandidate[np].obj[j]) {
            /* candidate[n].obj[j] beats priorCandidate[np].obj[j] */
            betterct++;           
          }
          if (candidate[n].obj[j] >= priorCandidate[np].obj[j]) {
            /* candidate[n].obj[j] does not beat */
            /* priorCandidate[np].obj[j] */
            worsect++;
          }
        }
        if (worsect == nobj) {
          /* candidate[n] is worse than or equal to */
          /* priorCandidate[np]; skip candidate[n] */
          addflag = FALSE;
          break;          
        } else if (betterct == nobj) {
          addflag = FALSE;
          /* candidate[n] beats priorCandidate[np] */
          /* insert candidate[n] into priorCandidate[np] */
          for (j=0; j<nobj; j++) {
            priorCandidate[np].obj[j] = candidate[n].obj[j];
          }
          for (j=0; j<ncon; j++) {
            priorCandidate[np].constr[j] = candidate[n].constr[j];
          }
          for (j=0; j<nreal; j++) {
            priorCandidate[np].xvalue[j] = candidate[n].xvalue[j]; 
          }
          priorCandidate[np].constr_violation = 
                  candidate[n].constr_violation;
          priorCandidate[np].keepFlag = 
                  candidate[n].keepFlag;
          priorCandidate[np].distanceSquared = 
                  candidate[n].distanceSquared;
          priorCandidate[np].generation = generationCount; 

        } /* end if worsect == nobj, else */
      } /* end for np */
/*eject*/
      if (addflag == FALSE) {
        continue;
      }
      /* add candidate[n] to priorCandidate[] */     
      for (j=0; j<nobj; j++) {
        priorCandidate[ncand].obj[j] = candidate[n].obj[j];
      }
      for (j=0; j<ncon; j++) {
        priorCandidate[ncand].constr[j] = candidate[n].constr[j];
      }
      for (j=0; j<nreal; j++) {
        priorCandidate[ncand].xvalue[j] = candidate[n].xvalue[j]; 
      }
      priorCandidate[ncand].constr_violation = 
              candidate[n].constr_violation;
      priorCandidate[ncand].keepFlag = 
              candidate[n].keepFlag;
      priorCandidate[ncand].distanceSquared = 
              candidate[n].distanceSquared;
      priorCandidate[ncand].generation = generationCount;   
      ncand++;

      /* update ncand and nPriorCandidate */
      if (ncand == MAX_PRIOR) {
        /* priorCandidate[] is circular file */
        /* when number of priorCandidate[] reaches MAX_PRIOR, */
        /* the next storage is in 0 position of array */
        ncand = 0;
        nPriorCandidates = MAX_PRIOR;
      } else {
        /* update nPriorCandidate */
        if (nPriorCandidates < MAX_PRIOR) {
          nPriorCandidates = ncand;
        }
      }

    } /* end if candidate[n].keepFlag == TRUE */

  } /* end for n */

  /* update curPriorCandidate */
  curPriorCandidate = ncand;

  return;

}
/*eject*/
/**************************************************************
 * candidateTrue2someCandidate(): copy candidate[] records
 * with keepFlag = TRUE to someCandidate[]
 **************************************************************/
void candidateTrue2someCandidate(SampleRecord *someCandidate,
                                  int *nSomeCandidates) {

  int i, j, n;

  i = 0;

  for (n=0; n<nCandidates; n++) {

    if (candidate[n].keepFlag == TRUE) {

      for (j=0; j<nobj; j++) {
        someCandidate[i].obj[j] = candidate[n].obj[j];
      }
      for (j=0; j<ncon; j++) {
        someCandidate[i].constr[j] = candidate[n].constr[j];
      }
      for (j=0; j<nreal; j++) {
        someCandidate[i].xvalue[j] = candidate[n].xvalue[j]; 
      }
      someCandidate[i].constr_violation = 
              candidate[n].constr_violation;
      someCandidate[i].keepFlag = 
              candidate[n].keepFlag;
      someCandidate[i].distanceSquared = 
              candidate[n].distanceSquared;
      someCandidate[i].generation = 
              generationCount;

      i++;

    } /* end if candidate[n].keepFlag == TRUE */

  } /* end for n */

  /* update someCandidate */
  *nSomeCandidates = i;

  return;

}
/*eject*/
/**************************************************************
 * parallelCandidate2candidateTrue(p): 
 *                from parallelCandidate[], get
 *                 - obj[
 *                 - constr[]
 *                 -constr-violation
 *                insert these values into the
 *                candidate[] cases with keepFlag = TRUE
 **************************************************************/
void parallelCandidate2candidateTrue() {

  int i, j, n;

    /* store parallelCandidate[] in candidate[] records */
    /* with keepFlag = TRUE */
    i = 0;

    for (n=0; n<nCandidates; n++) {

      if (candidate[n].keepFlag == TRUE) {
        /* insert obj, constr, constr_violation */
        /* of parallelCandidate[i] into candidate[n] */
        for (j=0; j<nobj; j++) {
          candidate[n].obj[j] = parallelCandidate[i].obj[j];
        }
        for (j=0; j<ncon; j++) {
          candidate[n].constr[j] = parallelCandidate[i].constr[j];
        }
        candidate[n].constr_violation = 
             parallelCandidate[i].constr_violation;
        candidate[n].distanceSquared = INF;
        i++;
      }

    } /* end for n */

    /* check that all cases were transferred */
    if (i != nParallelCandidates) {
      printf("\nError: nParallelCandidates %d ",nParallelCandidates);
      printf("not equal to TRUE candidate[] cases %d\n",i);
      exit(1);
    }

  return;

}
/*eject*/
/**************************************************************
 * someCandidate2candidate(SampleRecord *someCandidate,
                           int nSomeCandidates, int *next): 
 *                add someCandidate[] to candidate[], begin
 *                storage at candidate[*next]
 **************************************************************/
void someCandidate2candidate(SampleRecord *someCandidate,
                             int nSomeCandidates, int *next) {

  int j, n, ncand;

  ncand = *next;

  for (n=0; n<nSomeCandidates; n++) {
    
    for (j=0; j<nobj; j++) {
      candidate[ncand].obj[j] = someCandidate[n].obj[j];
    }
    for (j=0; j<ncon; j++) {
      candidate[ncand].constr[j] = someCandidate[n].constr[j];
    }
    for (j=0; j<nreal; j++) {
      candidate[ncand].xvalue[j] = someCandidate[n].xvalue[j]; 
    }
    candidate[ncand].constr_violation = 
            someCandidate[n].constr_violation;
    candidate[ncand].keepFlag = 
            someCandidate[n].keepFlag;
    candidate[ncand].distanceSquared = 
            someCandidate[n].distanceSquared;
    candidate[ncand].generation = 
            someCandidate[n].generation;   
    ncand++;

  } /* end for n */  

  *next = ncand;

  return;

}
/*eject*/
/**************************************************************
 * someCandidate2otherCandidate(SampleRecord *someCandidate,
 *                              int nSomeCandidates,
 *                              SampleRecord *otherCandidate,
 *                              int *nOtherCandidates)
 *    copy someCandidate[] to otherCandidate[]
 **************************************************************/
void someCandidate2otherCandidate(SampleRecord *someCandidate,
                                  int nSomeCandidates,
                                  SampleRecord *otherCandidate,
                                  int *nOtherCandidates) {

  int j, n;

  for (n=0; n<nSomeCandidates; n++) {
    
    for (j=0; j<nobj; j++) {
      otherCandidate[n].obj[j] = someCandidate[n].obj[j];
    }
    for (j=0; j<ncon; j++) {
      otherCandidate[n].constr[j] = someCandidate[n].constr[j];
    }
    for (j=0; j<nreal; j++) {
      otherCandidate[n].xvalue[j] = someCandidate[n].xvalue[j]; 
    }
    otherCandidate[n].constr_violation = 
            someCandidate[n].constr_violation;
    otherCandidate[n].keepFlag = 
            someCandidate[n].keepFlag;
    otherCandidate[n].distanceSquared = 
            someCandidate[n].distanceSquared;
    otherCandidate[n].generation = 
            someCandidate[n].generation;

  } /* end for n */

  *nOtherCandidates = nSomeCandidates;

  return;

}
/********* last record of candidate2candidate.c ******************/
