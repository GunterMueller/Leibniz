/********************* constants ***********************/
#define OBJMAXVALUE 1.0e+07
#define MAX_LINESEARCH 100 /* max number of points of +d[] and -d[] */
                          /* linesearches */
#define MAX_XSTORE 4*MAX_VARIABLE + MAX_LINESEARCH + 1
#define LARGEPRIME 3581 /* = 501st prime */
 /******************** variables ************************/
  int nf_max, num_iter, num_funct;
  int iprint, istop, icoordonly;
  int i_corr, i_corr_fall;

  double alfa_max, alfa_stop;
  double obj;
  double viol, violz, violiniz;
  double violvalue; /* same as viol, used only in displaysolution() */
  double bestobj, maxobj;
 /********************* arrays **************************/
  double xreal[MAX_VARIABLE+1];
  double lb[MAX_VARIABLE+1];
  double ub[MAX_VARIABLE+1];
  double eps[MAX_CONSTRAINT+1];
  double epsiniz[MAX_CONSTRAINT+1];
  double constr[MAX_CONSTRAINT+1];

  double xfstop[MAX_VARIABLE+1][2*MAX_VARIABLE+1+1];
  double direzioni[MAX_VARIABLE+1][MAX_VARIABLE+1];
  double H[MAX_VARIABLE+1][MAX_VARIABLE+1];

  double bestconstr[MAX_CONSTRAINT+1];
  double bestxreal[MAX_VARIABLE+1];
 /*************** storage of x vectors *******************/
struct {
  double xreal[MAX_VARIABLE+1];
  double obj;
  double constr[MAX_CONSTRAINT+1];
  double constr_violation;
} typedef Xstore;

/* prediction of linesearch values */
struct {
  double x[MAX_VARIABLE+1];
  double f;
  double d[MAX_VARIABLE+1];
  double alfa;
  double alfa_d[MAX_VARIABLE+1];
  double z[MAX_VARIABLE+1];
  double z1[MAX_VARIABLE+1];  
  double z2[MAX_VARIABLE+1];
  double fz;
  double fz1;
  double fz2;
  int num_fal;
  int ielle; /* selected ielle value */
  double allz[MAX_LINESEARCH+1][MAX_VARIABLE+1];
  int nAllz[3]; /* nAllz[k] = index of last used position */
      /* in allz[][] during linesearch with ielle = k; k = 1, 2 */
  int nCheckz[3]; /* allz[nCheckz[k]][] is z[] vector currently */
      /* processed by linesearch with ielle = k; k = 1, 2 */
} typedef PredictLinesearch;
PredictLinesearch plin;

Xstore xstore[MAX_XSTORE+1];
int nXstores; /* total number of x vectors stored */
int pointXstore; /* pointer to recently used storage location */
int priorXstore; /* pointer prior to linesearch */

/* all routines are included in sample.lb.c */

/************* last record of dencon.h **********/
