/* first record of beginParam.c */
/***************************************************************
 *
 * subroutines in this file:
 *   void beginParam();
 *   void callArguments()
 *   void createParamsFromInput()
 *   void defineParameters() 
 *   void displayOptions  display options with selected values 
 *   void listOptions     list options without any values
 ***************************************************************/
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"

time_t timeNow;
char timeString[MAXLEN];

/*eject*/
/***************************************************************
 *  beginParam(): process command arguments and define parameters
 *   
 **************************************************************/
void beginParam() {

  int flag, p;

  /* interpret call arguments and use default options as needed */    
  callArguments();

  /* if there is input file and no params file: define */
  /*     params file from input file */
  /* define parameters by reading params file or calling */
  /* test_problem(FALSE,problemName,...) */
  /* finalize all parameters */
  /* if tempdir does not exist, mkdir the directory */
  /* for processor[p].machine = 'home': If processor[p].path */
  /*                  does not exist, mkdir this directory */
  /* copy params file into tempdir for black box calls */
  defineParameters();

  /* read and write/copy all processor-related files */
  readProcessor();
  if (strcmp(gOption.input,"NOINPUTFILE") != 0) {
    /* skip writeProcessor since evaluation */
    /* will be by parallelTest_problem() */
    writeProcessor();
    /* caution message for directories of processors != home */
    for (p=0; p<nProcessors; p++) {
      if (strcmp(processor[p].machine,"home") != 0) {
        flag = TRUE;
        printf("\n Caution: it is assumed that directory %s",
               processor[p].path);
        printf("\n          exists on processor %s",
               processor[p].machine);
      }
    }
    /* pause to display caution message for a moment */
    if (flag == TRUE) {
      sleep(1);
    } 
  }  
/*eject*/
  /* have all parameters; lower and upper bounds, including */
  /* allocation of arrays for bounds; stored files for each */
  /* processor */

  /* all steps of validity check are preceded by */
  /* a comment including the words "validity check" */
  /* step 2 of validity check: compare timeNow with */
  /* expiration date and define validityFlag = TRUE/FALSE */
  strftime(timeString,MAXLEN,"%d %m %Y",localtime(&timeNow));
  tokenize(timeString);
  if (nTokens != 3) {
    printf("\n displayOptions: error time string = %s",timeString);
    exit(1);
  }
  if ((atoi(token[0]) +
      MFAC*atoi(token[1]) +
      YFAC*atoi(token[2])) > totalDate) {
    validityFlag = FALSE;
  } else {
    validityFlag = TRUE;
  }

  return;

}
/*eject*/
/**************************************************************
 *   void callArguments():  interpret call arguments
 **************************************************************/
void callArguments() {

  int i;

  /* all steps of validity check are preceded by */
  /* a comment including the words "validity check" */
  /* step 1 of validity check: get current timeNow */
  timeNow = time(NULL);
  validityFlag = FALSE; /* assures that multicc fails if test at */
                        /* end of displayOptions() is removed */
  totalDate = TOTALDATE;

  if (nCallArgs<2) {
    printf("\n Usage: ./program problem_name <options>");
    listOptions();
    exit(1);
  }
/*eject*/
  /* problem name */
  strcpy(problemName,callArg[1]);

  /* default values for options */
  /* basic options */
  sprintf(gOption.input,   "%s.input",problemName);
  /* uncomment next line if input default = no input file */
  /* sprintf(gOption.input,   "NOINPUTFILE"); */
  sprintf(gOption.initsol, "NOINITSOLFILE");
  sprintf(gOption.output,  "%s.output",problemName);
  sprintf(gOption.blackbox,"./%s.blackbox",problemName);
  sprintf(gOption.inbox,   "%s.inbox",problemName);
  sprintf(gOption.outbox,  "%s.outbox",problemName); 
  sprintf(gOption.params,  "NOPARAMSFILE");
  sprintf(gOption.processor,  "NOPROCFILE");
  sprintf(gOption.leibnizpath,"~/Leibniz/Multicc/Code/");

  sprintf(gOption.nomadpath,"~/Leibniz/Nomad/NOMAD/bin/");

  sprintf(gOption.tempdir,"/dev/shm/%s/",problemName);
  gOption.singleminout = FALSE;
  /* advanced options */
  gOption.accuracy = 0.001; /* use 0.01 for low accuracy */
/*eject*/
  /* standard sequence; assumes single processor */
  /* denpar is possibly preferred to dencon for */
  /* when number of processors is much larger than twice */
  /* the number of variables. In that case use */
  /* option "-sequenceminone nsga nomad denpar" */
  gOption.nsequenceminone = 3;
  strcpy(gOption.sequenceminone[0],"nsga");
  strcpy(gOption.sequenceminone[1],"nomad");
  strcpy(gOption.sequenceminone[2],"dencon");

  /* begin: short sequence for easy problems */
  /* activate or comment out, as needed */
  /* gOption.nsequenceminone = 2; */
  /* end: short sequence for easy problems */ 
  sprintf(gOption.stopcriterion,"feasible");
  sprintf(gOption.minall,"nsga");
  gOption.maxeval = 50000; 
  gOption.maxiter = 2; /* must be >= 1 */
  gOption.maxitereval = 1000;
  gOption.maxfirstitereval = 0; /* means that there is no special */
                       /* limit on evaluations of first iteration */
  gOption.minsingleonly = FALSE;
  gOption.minallonly = FALSE;
  gOption.ignoreconstraint = FALSE;
  gOption.gradualconstraint = 0;
  gOption.scaleconstraint = FALSE; 
  gOption.objfactor = FALSE;
  gOption.objtolerance = FALSE;
  gOption.constrtolerance = FALSE;
  gOption.objgoal = FALSE;
  gOption.objbound = FALSE;
  gOption.objrange = FALSE;
  gOption.cutout = FALSE;
/*eject*/
  gOption.dynamiclimit = FALSE;
  gOption.convergetesteval = -1; /* means not yet specified */
  gOption.paretosize = FALSE; /* = 0 */
  gOption.plotdetail = 2;
  gOption.printdetail = 2;
  gOption.slowmotion = FALSE;
  gOption.seednsga  = SEEDNSGA;
  gOption.seednomad = SEEDNOMAD;
  gOption.initialmesh = 0.5;
  gOption.finalmesh = 0.005;
  gOption.maxproctime = 10;
  gOption.denconcoordinate = FALSE;

  /* process options */
  for (i=2; i<=nCallArgs-1; i++) {
  /* basic options */
    if (strcmp(callArg[i],"-input") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing input file name */
        printf("\n Option -input: missing input name\n");
        exit(1);
      }
      strcpy(gOption.input,callArg[i]);
    } else if (strcmp(callArg[i],"-initsol") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing initial solution file name */
        printf("\n Option -input: missing initial solution name\n");
        exit(1);
      }
      strcpy(gOption.initsol,callArg[i]);
    } else if (strcmp(callArg[i],"-output") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing output file name */
        printf("\n Option -output: missing output name\n");
        exit(1);
      }
      strcpy(gOption.output,callArg[i]);
    } else if (strcmp(callArg[i],"-blackbox") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing black box program name */
        printf("\n Option -blackbock: missing black box name\n");
        exit(1);
      }
      strcpy(gOption.blackbox,callArg[i]);
/*eject*/
    } else if (strcmp(callArg[i],"-inbox") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing inbox file name */
        printf("\n Option -inbox: missing inbox name\n");
        exit(1);
      }
      strcpy(gOption.inbox,callArg[i]);
    } else if (strcmp(callArg[i],"-outbox") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing outbox file name */
        printf("\n Option -outbox: missing outbox name\n");
        exit(1);
      }
      strcpy(gOption.outbox,callArg[i]);
    } else if (strcmp(callArg[i],"-params") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing paramsfile name */
        printf("\n Option -params: missing filename\n");
        exit(1);
      }
      strcpy(gOption.params,callArg[i]);
    } else if (strcmp(callArg[i],"-processor") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing processor file name */
        printf("\n Option -processor: missing filename\n");
        exit(1);
      }
      strcpy(gOption.processor,callArg[i]);
/*eject*/
    } else if (strcmp(callArg[i],"-leibnizpath") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing leibnizpath name */
        printf("\n Option -leibnizpath: missing path name\n");
        exit(1);
      }
      strcpy(gOption.leibnizpath,callArg[i]);
    } else if (strcmp(callArg[i],"-nomadpath") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing nomadpath name */
        printf("\n Option -nomadpath: missing path name\n");
        exit(1);
      }
      strcpy(gOption.nomadpath,callArg[i]);
    } else if (strcmp(callArg[i],"-tempdir") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing tmp directory name */
        printf("\n Option -tempdir: missing directory name\n");
        exit(1);
      }
      strcpy(gOption.tempdir,callArg[i]);
    } else if (strcmp(callArg[i],"-singleminout") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing singleminout value */
        printf(
          "\n Option -singleminout: missing value\n");
        exit(1);
      }
      gOption.singleminout = atoi(callArg[i]);
      if ((gOption.singleminout != 0) && 
          (gOption.singleminout != 1)) {
        printf(
        "\n Option -singleminout: value n = %d must be 0 or 1",
        gOption.singleminout);
        exit(1);
      } 
/*eject*/
    /* advanced options */
    } else if (strcmp(callArg[i],"-accuracy") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing accuracy value */
        printf(
          "\n Option -accuracy: missing value\n");
        exit(1);
      }
      gOption.accuracy = atof(callArg[i]);
      if ((gOption.accuracy <= 0) || (gOption.accuracy >= 1.0)) {
        printf(
         "\n Option -accuracy: value f = %f must be 0.0 < f < 1.0",
         gOption.accuracy);
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-sequenceminone") == 0) {
      gOption.nsequenceminone = 0;
      while (1) {
        i++;
        if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
          /* end of program sequence */
          i--;
          break;
        }
        /* check that program selection is valid */
        if ((strcmp(callArg[i],"gencc") != 0) &&
            (strcmp(callArg[i],"dencon") != 0) &&
            (strcmp(callArg[i],"denpar") != 0) &&
            (strcmp(callArg[i],"nsga") != 0) &&
            (strcmp(callArg[i],"nomad") != 0) &&
            (strcmp(callArg[i],"seqpen") != 0)) {
          printf("\n Option -sequenceminone specifies %s,\n but must",
                 callArg[i]);
          printf(" be dencon, depar, gencc, nsga, nomad, or seqpen");
          exit(1);
        }
        strcpy(gOption.sequenceminone[gOption.nsequenceminone],
               callArg[i]);
        gOption.nsequenceminone++;
      } /* end while (1) */
      if (gOption.nsequenceminone <= 1) {
        printf(
      "\n Option -sequenceminone: no or 1 program is specified, but");
        printf(
      "\n                         must have at least 2 programs\n");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-maxeval") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing maxeval value */
        printf(
          "\n Option -maxeval: missing value\n");
        exit(1);
      }
      gOption.maxeval = atoi(callArg[i]);
      if (gOption.maxeval <= 0) {
        printf(
        "\n Option -maxeval: value n = %d must be > 0",
        gOption.maxeval);
        exit(1);
      }
    } else if (strcmp(callArg[i],"-maxiter") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing maxiter value */
        printf(
          "\n Option -maxiter: missing value\n");
        exit(1);
      }
      gOption.maxiter = atoi(callArg[i]);
      if (gOption.maxiter <= 0) {
        printf(
        "\n Option -maxiter: value n = %d must be > 0",
        gOption.maxiter);
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-maxitereval") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing maxitereval value */
        printf(
          "\n Option -maxitereval: missing value\n");
        exit(1);
      }
      gOption.maxitereval = atoi(callArg[i]);
      if (gOption.maxitereval <= 0) {
        printf(
        "\n Option -maxitereval: value n = %d must be > 0",
        gOption.maxitereval);
        exit(1);
      }

    } else if (strcmp(callArg[i],"-maxfirstitereval") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing maxfirstitereval value */
        printf(
          "\n Option -maxfirstitereval: missing value\n");
        exit(1);
      }
      gOption.maxfirstitereval = atoi(callArg[i]);
      if (gOption.maxfirstitereval < 0) {
        printf(
        "\n Option -maxfirstitereval: value n = %d must be >= 0",
        gOption.maxfirstitereval);
        exit(1);
      }

    } else if (strcmp(callArg[i],"-stopcriterion") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing stop criterion */
        printf("\n Option -stopcriterion: missing criterion\n");
        exit(1);
      }
      if ((strcmp(callArg[i],"feasible") != 0) &&
          (strcmp(callArg[i],"optimal") != 0)) {
        printf(
        "\n Option -stopcriterion: criterion must be 'feasible' or ");
        printf(
        "\n   'optimal', but is = %s", callArg[i]);
        exit(1);
      }
      strcpy(gOption.stopcriterion,callArg[i]);
/*eject*/
    } else if (strcmp(callArg[i],"-minall") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing minimization program name */
        printf("\n Option -minall: missing program name\n");
        exit(1);
      }
      strcpy(gOption.minall,callArg[i]);
      /* check that program selection is valid */
      if ((strcmp(gOption.minall,"gencc") != 0) &&
          (strcmp(gOption.minall,"nsga") != 0)) {
        printf("\n Option -minall: unknown program name = %s\n",
               gOption.minall);
        printf("\n must specify 'gencc' or 'nsga'");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-minsingleonly") == 0) {
      gOption.minsingleonly = TRUE;
    } else if (strcmp(callArg[i],"-minallonly") == 0) {
      gOption.minallonly = TRUE;
    } else if (strcmp(callArg[i],"-ignoreconstraint") == 0) {
      gOption.ignoreconstraint = TRUE;
    } else if (strcmp(callArg[i],"-gradualconstraint") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing gradualconstraint value */
        printf(
          "\n Option -gradualconstraint: missing value\n");
        exit(1);
      }
      gOption.gradualconstraint = atoi(callArg[i]);
      if (gOption.gradualconstraint <= 0) {
        printf(
        "\n Option -gradualconstraint: value must be > 0");
        exit(1);
      }
    } else if (strcmp(callArg[i],"-scaleconstraint") == 0) {
      gOption.scaleconstraint = TRUE;
/*eject*/
    } else if (strcmp(callArg[i],"-objfactor") == 0) {
      gOption.objfactor = TRUE;
      nObjFactors = 0;
      while (1) {
        i++;
        if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
          /* have end of options or next option */
          i--;
          break;
        }
        if (nObjFactors >= MAX_OBJ) {
          printf(
          "\n Option -objfactor: more than MAX_OBJ = %d factors\n",
          MAX_OBJ);
          exit(1);
        }
        objFactor[nObjFactors] = atof(callArg[i]);
        if ((objFactor[nObjFactors] != 0) && 
            (objFactor[nObjFactors] != 1)) {
          printf(
          "\n input error: -objfactor = %g, but must be 0 or 1",
             objFactor[nObjFactors]);
          exit(1);
        }
        nObjFactors++;
      } /* end while (1) */
      if (nObjFactors <= 0) {
        printf(
        "\n input error: -objfactor option requires nobj factors");
        printf(
        "\n              but none is listed after '-objfactor'\n");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-objtolerance") == 0) {
      gOption.objtolerance = TRUE;
      nObjTolerances = 0;
      while (1) {
        i++;
        if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
          /* have end of options or next option */
          i--;
          break;
        }
        if (nObjTolerances >= MAX_OBJ) {
          printf(
      "\n Option -objtolerance: more than MAX_OBJ = %d tolerances\n",
          MAX_OBJ);
          exit(1);
        }
        objTolerance[nObjTolerances] = atof(callArg[i]);
        nObjTolerances++;
      } /* end while (1) */
      if (nObjTolerances <= 0) {
        printf(
    "\n input error: -objtolerance option requires nobj tolerances");
        printf(
        "\n              but none is listed after '-objtolerance'\n");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-constrtolerance") == 0) {
      gOption.constrtolerance = TRUE;
      nConstrTolerances = 0;
      while (1) {
        i++;
        if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
          /* have end of options or next option */
          i--;
          break;
        }
        if (nConstrTolerances >= MAX_CONSTRAINT) {
          printf(
      "\n Option -constrtolerance: more than MAX_CONSTRAINT = %d", 
          MAX_CONSTRAINT);
          printf(" tolerances\n");
          exit(1);
        }
        constrTolerance[nConstrTolerances] = atof(callArg[i]);
        nConstrTolerances++;
      } /* end while (1) */
      if (nConstrTolerances <= 0) {
        printf(
  "\n input error: -constrtolerance option requires ncon tolerances");
        printf(
  "\n              but none is listed after '-constrtolerance'\n");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-objgoal") == 0) {
      gOption.objgoal = TRUE;
      nObjGoals = 0;
      while (1) {
        i++;
        if ((i > nCallArgs-1) || 
            ((callArg[i][0] == '-') && (callArg[i][1]>=65))) {
          /* have end of options or next option; cannot just */
          /* test for next '-' since goal < 0 is possible */
          i--;
          break;
        }
        if (nObjGoals >= MAX_OBJ) {
          printf(
          "\n Option -objgoal: more than MAX_OBJ = %d goals\n",
          MAX_OBJ);
          exit(1);
        }
        objGoal[nObjGoals] = atof(callArg[i]);
        nObjGoals++;
      } /* end while (1) */
      if (nObjGoals <= 0) {
        printf(
        "\n input error: -objgoal option requires nobj goals");
        printf(
        "\n              but none is listed after '-objgoal'\n");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-objbound") == 0) {
      gOption.objbound = TRUE;
      nObjBounds = 0;
      while (1) {
        i++;
        if ((i > nCallArgs-1) || 
            ((callArg[i][0] == '-') && (callArg[i][1]>=65))) {
          /* have end of options or next option; cannot just */
          /* test for next '-' since bound < 0 is possible */
          i--;
          break;
        }
        if (nObjBounds >= MAX_OBJ) {
          printf(
          "\n Option -objbound: more than MAX_OBJ = %d bounds\n",
          MAX_OBJ);
          exit(1);
        }
        objBound[nObjBounds] = atof(callArg[i]);
        nObjBounds++;
      } /* end while (1) */
      if (nObjBounds <= 0) {
        printf(
        "\n input error: -objbound option requires nobj bounds");
        printf(
        "\n              but none is listed after '-objbound'\n");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-objrange") == 0) {
      gOption.objrange = TRUE;
      nObjRanges = 0;
      while (1) {
        i++;
        if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
          /* have end of options or next option */
          i--;
          break;
        }
        if (nObjRanges >= MAX_OBJ) {
          printf(
          "\n Option -objrange: more than MAX_OBJ = %d ranges\n",
          MAX_OBJ);
          exit(1);
        }
        objRange[nObjRanges] = atof(callArg[i]);
        nObjRanges++;
      } /* end while (1) */
      if (nObjRanges <= 0) {
        printf(
        "\n input error: -objrange option requires nobj ranges");
        printf(
        "\n              but none is listed after '-objrange'\n");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-cutout") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing cutout value */
        printf(
          "\n Option -cutout: missing value\n");
        exit(1);
      }
      gOption.cutout = atoi(callArg[i]);
      if ((gOption.cutout != 0) && 
          (gOption.cutout != 1)) {
        printf(
        "\n Option -cutout: value n = %d must be 0 or 1",
        gOption.cutout);
        exit(1);
      } 
    } else if (strcmp(callArg[i],"-dynamiclimit") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing dynamiclimit value */
        printf(
          "\n Option -dynamiclimit: missing value\n");
        exit(1);
      }
      gOption.dynamiclimit = atoi(callArg[i]);
      if ((gOption.dynamiclimit != 0) && 
          (gOption.dynamiclimit != 1)) {
        printf(
        "\n Option -dynamiclimit: value n = %d must be 0 or 1",
        gOption.dynamiclimit);
        exit(1);
      }
    } else if (strcmp(callArg[i],"-convergetesteval") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing convergetesteval value */
        printf(
          "\n Option -convergetesteval: missing value\n");
        exit(1);
      }
      gOption.convergetesteval = atoi(callArg[i]);
      if (gOption.convergetesteval <= 0) {
        printf(
        "\n Option -convergetesteval: value n = %d must be >= 1",
        gOption.convergetesteval);
        exit(1);
      }  
/*eject*/
    } else if (strcmp(callArg[i],"-paretosize") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing paretosize value */
        printf(
          "\n Option -paretosize: missing value\n");
        exit(1);
      }
      gOption.paretosize = atoi(callArg[i]);
      if (gOption.paretosize <= 0) {
        printf(
          "\n Option -paretosize: value %d must be > 0",
          gOption.paretosize);
        exit(1);
      }
    } else if (strcmp(callArg[i],"-plotdetail") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing plotdetail value */
        printf(
          "\n Option -plotdetail: missing value\n");
        exit(1);
      }
      gOption.plotdetail = atoi(callArg[i]);
      if (gOption.plotdetail > 2) {
        printf(
          "\n Option -plotdetail: value %d must be 0, 1, or 2",
          gOption.plotdetail);
        exit(1);
      }
    } else if (strcmp(callArg[i],"-printdetail") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing printdetail value */
        printf(
          "\n Option -printdetail: missing value\n");
        exit(1);
      }
      gOption.printdetail = atoi(callArg[i]);
      if (gOption.printdetail > 2) {
        printf(
          "\n Option -printdetail: value %d must be 0, 1, or 2",
          gOption.printdetail);
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-slowmotion") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing slowmotion value */
        printf(
          "\n Option -slowmotion: missing value\n");
        exit(1);
      }
      gOption.slowmotion = atoi(callArg[i]);
      if ((gOption.slowmotion < 0) || (gOption.slowmotion > 1)) {
        printf(
          "\n Option -slowmotion: value %d must be 0 or 1",
          gOption.slowmotion);
        exit(1);
      }
    } else if (strcmp(callArg[i],"-seednsga") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing seednsga value */
        printf(
          "\n Option -seednsga: missing value\n");
        exit(1);
      }
      gOption.seednsga = atof(callArg[i]);
      if ((gOption.seednsga <= 0.0) || 
          (gOption.seednsga >= 1.0)) {
        printf(
        "\n Option -seednsga: value f must be 0.0 < f < 1.0");
        exit(1);
      }
    } else if (strcmp(callArg[i],"-seednomad") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing seednomad value */
        printf(
          "\n Option -seednomad: missing value\n");
        exit(1);
      }
      gOption.seednomad = atoi(callArg[i]);
      if (gOption.seednomad <= 0) {
        printf(
        "\n Option -seednomad: value must be n > 0");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-initialmesh") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing initialmesh value */
        printf(
          "\n Option -initialmesh: missing value\n");
        exit(1);
      }
      gOption.initialmesh = atof(callArg[i]);
      if (gOption.initialmesh <= 0) {
        printf(
        "\n Option -initialmesh: value must be f > 0");
        exit(1);
      }
    } else if (strcmp(callArg[i],"-finalmesh") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing finalmesh value */
        printf(
          "\n Option -finalmesh: missing value\n");
        exit(1);
      }
      gOption.finalmesh = atof(callArg[i]);
      if (gOption.finalmesh <= 0) {
        printf(
        "\n Option -finalmesh: value must be f > 0");
        exit(1);
      }
/*eject*/
    } else if (strcmp(callArg[i],"-maxproctime") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing maxproctime value */
        printf(
          "\n Option -maxproctime: missing value\n");
        exit(1);
      }
      gOption.maxproctime = atoi(callArg[i]);
      if (gOption.maxproctime <= 0) {
        printf(
        "\n Option -maxproctime: value must be > 0\n");
        exit(1);
      }
    } else if (strcmp(callArg[i],"-denconcoordinate") == 0) {
      i++;
      if ((i > nCallArgs-1) || (callArg[i][0] == '-')) {
        /* missing denconcoordinate value */
        printf(
          "\n Option -denconcoordinate: missing value\n");
        exit(1);
      }
      gOption.denconcoordinate = atoi(callArg[i]);
      if ((gOption.denconcoordinate != 0) &&
          (gOption.denconcoordinate != 1)) {
        printf(
        "\n Option -denconcoordinate: value must be = 0 or 1\n");
        exit(1);
      }
/*eject*/
    } else {
              /* unknown program option */
      printf("\n unknown program option = %s\n",
             callArg[i]);
      listOptions();
      exit(1);
    }
  }

  return;

}
/*eject*/
/**************************************************************
 *   void createParamsFromInput(): create params file from
 *                                 input file
 **************************************************************/
void createParamsFromInput() {

  int i; 

  char lineread[MAXLEN];

  char inputfile[MAX_ENTRY];
  char paramsfile[MAX_ENTRY];

  FILE *paramsfil;
  FILE *inputfil;

  /* redefine params file name */
  sprintf(gOption.params,"%s.params",problemName);

  /* define file names */
  sprintf(inputfile,"%s",gOption.input);
  sprintf(paramsfile,"%s",gOption.params);

  /* open files */
  inputfil = openFile(inputfile,"r");
  paramsfil = openFile(paramsfile,"w");
 
  while (fgets(lineread,MAXLEN,inputfil) != NULL) { /* while #1 */
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty and comments lines */
    if ((lineread[0] == '\0') || (strncmp(lineread,"##",2) == 0)) {
      continue;
    }
    if (lineread[0] == '#') { 
      /* write line into params file */
      fprintf(paramsfil,"%s\n",lineread);
    }
    if (strncmp(lineread,"# endformat",11) == 0) {
      /* have obtained all parameter records */
      break;
    }
  }

  /* close files */
  closeFile(inputfil);
  closeFile(paramsfil);

  return;

}
/*eject*/
/**************************************************************
 *   void defineParameters():  
 *      if there is input file and no params file: define
 *      params file from input file
 *      define parameters by reading params file or calling
 *      test_problem(FALSE,problemName,...)
 *      finalize all parameters
 *      if tempdir does not exist, mkdir this directory
 *      copy params file into tempdir for black box calls
 **************************************************************/
void defineParameters() {

  int flag, j, juse, n;

  /* dummy definition for test_problem() call */
  double testx;

  char cmnd[MAX_ENTRY];

  /* initial random number */
  seed = gOption.seednsga;

  if (seed<=0.0 || seed>=1.0)
  {
    printf(
     "\n Seed value f is wrong, must be 0.0 < f < 1.0 \n");
    exit(1);
  }

  /* define nInputCandidates = 0, nCorners = 0 */
  nInputCandidates = 0;
  nCorners = 0;

  /* if input file exists and no params file, define params file */
  /* from input file */
  if ((strcmp(gOption.params,"NOPARAMSFILE") == 0) &&
      (strcmp(gOption.input,"NOINPUTFILE") != 0)) {
    createParamsFromInput();
  }
/*eject*/
  /* determine problem parameters, allocation max/min bounds */

  /* define nreal, nint, nobj, ncon, min_realvar[], max_realvar[] */
  /* and input candidate records, if any */
  /* includes allocation of min_realvar[], max_realvar[] */

  if (strcmp(gOption.params,"NOPARAMSFILE") != 0) {
    /* get nreal, nint, nobj, ncon, min_realvar[], max_realvar[], 
     *     nCorners, corner[], objjective[].direction, constraint[],
     *      and input records from params file
     * printf parameter file records only for multicc */
    if (strcmp(methodName,"multicc") == 0) {
      flag = TRUE;
    } else {
      flag = FALSE;
    }
    readParams(gOption.params,flag);
  } else {
    test_problem (FALSE, problemName, &testx, &testx, &testx);
       /* functionFlag = FALSE: define
        * nreal, nint, nobj, ncon, min_realvar[], max_realvar[] */
       /* objective[].direction = "min" */
     for (j=0; j<nobj; j++) {
       sprintf(objective[j].direction,"min");
     }
  }
/*eject*/
  if (gOption.objfactor == TRUE) {
    /* factors are used for obj functions */
    /* check that number of factors matches number of objs */
    if (nObjFactors != nobj) {
      printf(
      "\n input error: nobj = %d != number of obj factors = %d",
      nobj, nObjFactors);
      printf(
      "\n              following '-objfactor' option");
      exit(1);
    }
  } else {
    /* define default factors, but */
    /* do not change gOption.objfactor */
    nObjFactors = nobj;
    for (j=0; j<nobj; j++) {
      objFactor[j] = 1.0;
    }
  }
/*eject*/
  if (gOption.objtolerance == TRUE) {
    /* tolerances have been specified in call arguments */
    /* check that number of tolerances matches number of objs */
    if (nObjTolerances != nobj) {
      printf(
      "\n input error: nobj = %d != number of obj tolerances = %d",
      nobj, nObjTolerances);
      printf(
      "\n              following '-objtolerance' option");
      exit(1);
    }
  } else {
    /* assign nobj to nObjTolerances, but */
    /* do not change gOption.objtolerance */
    /* caution: default tolerance values have */
    /* already been assigned during readParams() */
    nObjTolerances = nobj;
  }

  if (gOption.constrtolerance == TRUE) {
    /* tolerances have been specified in call arguments */
    /* check that number of tolerances matches number of */
    /* constraints */
    if (nConstrTolerances != ncon) {
      printf(
  "\n input error: ncon = %d != number of constraint tolerances = %d",
      nobj, nConstrTolerances);
      printf(
      "\n              following '-constrtolerance' option");
      exit(1);
    }
  } else {
    /* assign ncon to nConstrTolerances, but */
    /* do not change gOption.constrtolerance */
    /* caution: default tolerance values have */
    /* already been assigned during readParams() */
    nConstrTolerances = ncon;
  }
/*eject*/
  if (gOption.objgoal == TRUE) {
    /* goals have been specified in call arguments */
    /* check that number of goals matches number of objs */
    /* if "max" direction of obj, scale goal */
    /* assign default goal values */
    if (nObjGoals != nobj) {
      printf(
      "\n input error: nobj = %d != number of obj goals = %d",
      nobj, nObjGoals);
      printf(
      "\n              following '-objgoal' option");
      exit(1);
    }
    /* if obj direction is "max", scale goal */
    for (j=0; j<nobj; j++) {
      if (strcmp(objective[j].direction,"max") == 0) {
        objGoal[j] *= -1.0;
      }
    }
  } else {
    /* define default goals, but */
    /* do not change gOption.objgoal */
    nObjGoals = nobj;
    for (j=0; j<nobj; j++) {
      objGoal[j] = -INF;
    }
  }
  /* retain objGoal[] in objGoalInitial[] */
  for (j=0; j<nobj; j++) {
    objGoalInitial[j] = objGoal[j];
  }
/*eject*/
  if (gOption.objbound == TRUE) {
    /* bounds have been specified in call arguments */
    /* check that number of bounds matches number of objs */
    /* if "max" direction of obj, scale bound */
    /* assign default bound values */
    if (nObjBounds != nobj) {
      printf(
      "\n input error: nobj = %d != number of obj bounds = %d",
      nobj, nObjBounds);
      printf(
      "\n              following '-objbound' option");
      exit(1);
    }
    /* if obj direction if "max", scale bound */
    for (j=0; j<nobj; j++) {
      if (strcmp(objective[j].direction,"max") == 0) {
        objBound[j] *= -1.0;
      }
    }
  } else {
    /* define default bounds, but */
    /* do not change gOption.objbound */
    nObjBounds = nobj;
    for (j=0; j<nobj; j++) {
      objBound[j] = INF;
    }
  }
  /* retain objBound[] in objBoundInitial[] */
  for (j=0; j<nobj; j++) {
    objBoundInitial[j] = objBound[j];
  }
/*eject*/
  if (gOption.objrange == TRUE) {
    /* ranges have been specified in call arguments */
    /* check that number of ranges matches number of objs */
    if (nObjRanges != nobj) {
      printf(
      "\n input error: nobj = %d != number of obj ranges = %d",
      nobj, nObjRanges);
      printf(
      "\n              following '-objrange' option");
      exit(1);
    }
  } else {
    /* define default ranges, but */
    /* do not change gOption.objrange */
    nObjRanges = nobj;
    for (j=0; j<nobj; j++) {
      objRange[j] = 0.0;
    }
  }

  if (gOption.cutout == TRUE) {
    if (strcmp(gOption.params,"NOPARAMSFILE") == 0) {
      printf(
      "\n input error: cutout option requires parameter file ");
      printf(
      "\n but have default params file name = %s",gOption.params);
      printf("\n use params option to specify file name");
      exit(1);
    }
    if (strcmp(gOption.initsol,"NOINITSOLFILE") == 0) {
      printf(
      "\n input error: cutout option requires initsol file ");
      printf(
      "\n but have default initsol file name = %s",gOption.initsol);
      printf("\n use initsol option to specify file name");
      exit(1);
    }
    if (gOption.objbound == FALSE) {
      printf(
      "\n input error: cutout option requires obj bounds");
      printf("\n use objbound option to specify appropriate bounds");
      exit(1);
    }
  }

  if (gOption.dynamiclimit == TRUE) {
    /* activate objgoal option since goals will be */
    /* dynamically changed */
    gOption.objgoal = TRUE;
  }
/*eject*/
  /* at this point, all goal and bound values are for min case */
  /* check that goals <= bounds */
  for (j=0; j<nobj; j++) {
    if (objGoal[j] > objBound[j]) {
     printf(
      "\n input error: objGoal[%d] = %g >= objBound[%d] = %g",
          j,objGoal[j],j,objBound[j]);
     printf(
      "\n note: values have been scaled by -1 if 'max' case");
      exit(1);
    }
  }

  /* define nbin = 0 to disable binary case, which is not */
  /* covered in gencc and handled instead via nint */
  nbin = 0;
/*eject*/
  /* test validity of parameters */
  if (nreal > MAX_VARIABLE) {
    printf("\n MAX_VARIABLE = %d must be >= nreal = %d",
           MAX_VARIABLE, nreal);
    printf("\n make change in sample.lb.h, compile, run again\n");
    exit(1);
  }
  if (nint > nreal) {
    printf("\n input error: nint = %d exceeds nreal = %d",
           nint, nreal);
    printf("\n make change in problemdef.c or params file\n");
    printf("\n compile problemdef.c if applicable, run again\n");
    exit(1);
  }
  if (nobj > MAX_OBJ) {
    printf("\n MAX_OBJ = %d must be >= nobj = %d",
           MAX_OBJ, nobj);
    printf("\n make change in sample.lb.h, compile, run again\n");
    exit(1);
  }
  if (ncon > MAX_CONSTRAINT) {
    printf("\n MAX_CONSTRAINT = %d must be >= ncon = %d",
           MAX_CONSTRAINT, ncon);
    printf("\n make change in sample.lb.h, compile, run again\n");
    exit(1);
  }
  if (nCorners > MAX_CORNER) {
    printf("\n MAX_CORNER = %d must be >= nCorners = %d",
           MAX_CORNER, nCorners);
    printf("\n make change in sample.lb.h, compile, run again\n");
    exit(1);
  }
  if (gOption.initialmesh <= gOption.finalmesh) {
    printf("\n initialmesh = %g <= finalmesh = %g, but must be >",
           gOption.initialmesh, gOption.finalmesh);
    exit(1);
  }
/*eject*/
  /* up to this point, nobj = nobjEvaluate */

  /* reduce nobj by 1 for each objFactor[j] = 0.0 */
  /* these cases will be projected out when function */
  /* values are computed in evaluate_ind() */
  /* define nobjEvaluate and nobjSolve */
  nobjEvaluate = nobj;
  if (gOption.objfactor == TRUE) {
    for (j=0; j<nObjFactors; j++) {
      if (objFactor[j] == 0.0) {
        nobj--;
      }
    }
    if (nobj <= 0) {
      printf("\n input error: all obj factors = 0.0\n");
      exit(1);
    }
  }

  nobjSolve = nobj;
/*eject*/
  /* if objFactor = TRUE:
   * adjust inputCandidate[], objTolerance[], objGoal[], objBound[] 
   * so that values are correct for the reduced nobj = nobjSolve 
   */
  if (gOption.objfactor == TRUE) {
    /* reduction of inputCandidate[] */
    for (n=0; n<nInputCandidates; n++) {
      juse = 0;
      for (j=0; j<nobjEvaluate; j++) {
        if (objFactor[j] != 0) {
          inputCandidate[n].obj[juse] = 
               inputCandidate[n].obj[j] * objFactor[j];
          juse++;
        }
      }
      if (juse != nobjSolve) {
        printf("\n defineParameters: nobjSolve = %d != juse = %d", 
               nobjSolve, juse);
        exit(1);
      }      
    } /* end for n */
    /* reduction of objTolerance[], */
    /* objGoal[], objGoalInitial[], */
    /* objBound[], objBoundInitial[]*/
    juse = 0;
    for (j=0; j<nobjEvaluate; j++) {
      if (objFactor[j] != 0) {
        objTolerance[juse] = objTolerance[j];
        objGoal[juse] = objGoal[j];
        objGoalInitial[juse] = objGoalInitial[j];
        objBound[juse] = objBound[j];
        objBoundInitial[juse] = objBoundInitial[j];
        juse++;
      }
    }
    if (juse != nobjSolve) {
      printf("\n defineParameters: nobjSolve = %d != juse = %d", 
             nobjSolve, juse);
      exit(1);
    }
    nObjTolerances = nobjSolve;
    nObjGoals = nobjSolve;
    nObjBounds = nobjSolve;
  } /* end if gOption.objfactor == TRUE */
/*eject*/
  /* define parameters from options common to gencc, nomad, nsga */
  maxEvaluationCount = gOption.maxeval;

  /* initialize evaluation count */
  evaluationCount = 0;

  /* test if directory gOption.tempdir exists */
  /* if not, create that directory */
  sprintf(cmnd,"test -d %s",gOption.tempdir);
  if( system(cmnd)  != 0 ) {
    /* directory does not exist, create it */
    sprintf(cmnd,"mkdir -p %s",gOption.tempdir);
    system(cmnd);       
  }

  /* if params file exists, copy it into gOption.tempdir, */
  /* to be used for black box calls */
  if (strcmp(gOption.input,"NOINPUTFILE") != 0)  {
    sprintf(cmnd,"cp %s %s%s",gOption.params, 
                              gOption.tempdir, 
                              gOption.params);  
    system(cmnd);
  }

  return;

}
/*eject*/
/**************************************************************
 *   void displayOptions():  display call options 
 *                           with selected values
 **************************************************************/
void displayOptions() {

  int j;

  printf("\n Problem name = %s\n",problemName);

  printf("\n Basic Options:");
  printf("\n gOption.input = %s",
         gOption.input);
  printf("\n gOption.initsol = %s",
         gOption.initsol);
  printf("\n gOption.output = %s",
         gOption.output);
  printf("\n gOption.blackbox = %s",
         gOption.blackbox);
  printf("\n gOption.inbox = %s",
         gOption.inbox);
  printf("\n gOption.outbox = %s",
         gOption.outbox);
  printf("\n gOption.params = %s",
         gOption.params);
  printf("\n gOption.processor = %s",
         gOption.processor);
  printf("\n gOption.leibnizpath = %s",
         gOption.leibnizpath);
  printf("\n gOption.nomadpath = %s",
         gOption.nomadpath);
  printf("\n gOption.tempdir = %s",
         gOption.tempdir);
  printf("\n gOption.singleminout = %d",
         gOption.singleminout);
/*eject*/
  printf("\n Advanced Options:");
  printf("\n gOption.accuracy = %f",
         gOption.accuracy);
  printf("\n Program sequence for single obj minimization");
  for (j=0; j<gOption.nsequenceminone; j++) {
    printf("\n   gOption.sequenceminone[%d] = %s",
            j, gOption.sequenceminone[j]);
  }
  printf("\n gOption.stopcriterion = %s ",
         gOption.stopcriterion);
  printf("\n gOption.minall  = %s",
         gOption.minall);
  printf("\n gOption.maxeval = %d",
         gOption.maxeval);
  printf("\n gOption.maxiter = %d",
         gOption.maxiter);
  printf("\n gOption.maxitereval = %d",
         gOption.maxitereval);
  printf("\n gOption.maxfirstitereval = %d",
         gOption.maxfirstitereval);
  printf("\n gOption.minsingleonly  = %d",
         gOption.minsingleonly);
  printf("\n gOption.minallonly  = %d",
         gOption.minallonly);
  printf("\n gOption.ignoreconstraint  = %d",
         gOption.ignoreconstraint);
  printf("\n gOption.gradualconstraint  = %d",
         gOption.gradualconstraint);
  printf("\n gOption.scaleconstraint  = %d",
         gOption.scaleconstraint);
/*eject*/
  printf("\n gOption.objfactor = %d",
         gOption.objfactor);
  printf("\n nObjFactors = %d",
         nObjFactors);
  for (j=0; j< nObjFactors; j++) {
    printf("\n   objFactor[%d] = %f",j, objFactor[j]);
  }
  printf("\n gOption.objtolerance = %d",
         gOption.objtolerance);
  printf("\n nObjTolerances = %d (unused tolerances omitted)",
         nObjTolerances);
  for (j=0; j< nObjTolerances; j++) {
    printf("\n   objTolerance[%d] = %g",
         j, objTolerance[j]);
  }
  printf("\n gOption.constrtolerance = %d",
         gOption.constrtolerance);
  printf("\n nConstrTolerances = %d",
         nConstrTolerances);
  for (j=0; j< nConstrTolerances; j++) {
    printf("\n   constrTolerance[%d] = %g",
         j, constrTolerance[j]);
  }
  printf("\n gOption.objgoal = %d",
         gOption.objgoal);
  printf("\n nObjGoals = %d (unused goals omitted)",
         nObjGoals);
  for (j=0; j< nObjGoals; j++) {
    printf("\n   objGoal[%d] = %g ('min' version)",
         j, objGoal[j]);
  }
  printf("\n gOption.objbound = %d",
         gOption.objbound);
  printf("\n nObjBounds = %d (unused bounds omitted)",
         nObjBounds);
  for (j=0; j< nObjBounds; j++) {
    printf("\n   objBound[%d] = %g ('min' version)",
           j, objBound[j]);
  }
/*eject*/
  printf("\n gOption.objrange = %d",
         gOption.objrange);
  printf("\n nObjRanges = %d (all objs)",
         nObjRanges);
  for (j=0; j< nObjRanges; j++) {
    printf("\n   objRange[%d] = %g",
           j, objRange[j]);
  }
  printf("\n gOption.cutout = %d",
         gOption.cutout);
  printf("\n gOption.dynamiclimit = %d",
         gOption.dynamiclimit);
  printf("\n gOption.convergetesteval = %d",
         gOption.convergetesteval);
  printf("\n gOption.paretosize = %d",
         gOption.paretosize);
  printf("\n gOption.plotdetail = %d",
         gOption.plotdetail);
  printf("\n gOption.printdetail = %d",
         gOption.printdetail);
  printf("\n gOption.slowmotion = %d",
         gOption.slowmotion);
  printf("\n gOption.seednsga = %f",
         gOption.seednsga);
  printf("\n gOption.seednomad = %d",
         gOption.seednomad);
  printf("\n gOption.initialmesh = %g",
         gOption.initialmesh);
  printf("\n gOption.finalmesh = %g",
         gOption.finalmesh);
  printf("\n gOption.maxproctime = %d",
         gOption.maxproctime);
  printf("\n");

  return;

}
/*eject*/
/**************************************************************
 *   void listOptions():  list options without any values
 **************************************************************/
void listOptions() {

  printf(
  "\n Basic Options:");
  printf(
  "\n -input <name>: input file");
  printf(
  "\n -initsol <name>: initial solution file");
  printf(
  "\n -output <name>: final output file");
  printf(
  "\n -blackbox <blackbox_program>: black box for function evals");
  printf(
  "\n -inbox <name>: input file of black box for function evals");
  printf(
  "\n -outbox <name>: output file of black box for function evals");
  printf(
  "\n -params <name>: file with problem parameters");
  printf(
  "\n -processor <name>: file with processors");
  printf(
  "\n -leibnizpath <name>: leibniz multicc code path = name");
  printf(
  "\n -nomadpath <name>: nomad bin path = name");
  printf(
  "\n -tempdir <name>: temporary directory = name");
  printf("\n -singleminout <n>: ");
  printf("n = 0: do not keep single min evaluations");
  printf("\n                     ");
  printf("  = 1: store such evaluations in <problem>.singleminout");
/*eject*/
  printf(
  "\n Advanced Options:");
  printf(
  "\n -accuracy <f>: convergence accuracy = f; 0.0 < f < 1.0");
  printf(
  "\n -sequenceminone <p1> ... <pk>: sequence of single obj ");
  printf(
  "\n                 minimization programs is p1 ... pk where");
  printf(
  "\n                 pi = dencon, gencc, nsga, nomad, or seqpen");
  printf(
  "\n -stopcriterion <criterion>: stop criterion for gencc, nsga");
  printf(
  "\n   = 'feasible' or 'optimal'; caution: do not use with multicc");
  printf(
  "\n -minall <name>: multi obj min program = name");
  printf(
  "\n                 used by multicc; default: nsga");
  printf(
  "\n                 available programs: gencc, nsga");
  printf(
  "\n -maxeval <n>: max number of evaluations = n");
  printf(
  "\n -maxiter <n>: max number of multicc single obj iterations = n");
  printf(
  "\n -maxitereval <n>: max number of evaluations in ");
  printf(
  "\n                 one multicc single obj iteration = n");
  printf(
  "\n -maxfirstitereval <n>: max number of evaluations in ");
  printf(
  "\n                 first multicc single obj iteration = n");
  printf(
  "\n                 n = 0 means there is no such special limit");
  printf(
  "\n -minsingleonly: minimize single objs, and stop");
  printf(
  "\n -minallonly: minimize all objs only");
  printf(
  "\n -ignoreconstraint: ignore black box constraints");
  printf(
  "\n -gradualconstraint <n>: gradually enforce black box");
  printf(
  "\n -scaleconstraint: scale black box constraints");
  printf(
  "\n                  constraints in n iterations");
  printf(
  "\n                  multicc, gencc, and nsga only");
/*eject*/
  printf(
  "\n -plotdetail <n>: n = 0: do not plot results");
  printf(
  "\n                    = 1: plot final result");
  printf(
  "\n                    = 2: plot all results");
  printf(
  "\n -printdetail <n>: n = 0: no screen output");
  printf(
  "\n                     = 1: screen output of summary");
  printf(
  "\n                     = 2: screen output of all steps");
  printf(
  "\n -slowmotion <n>: n = 0: crystallization with regular speed");
  printf(
  "\n                    = 1: crystallization in slow motion");
  printf(
  "\n -objfactor <f1 f2 ..fnobj>: 0/1 factors for obj functions");
  printf(
  "\n -objtolerance <f1 f2 ..fnobj>: tolerances for obj functions");
  printf(
  "\n -constrtolerance <f1 f2 ..fncon>: tolerances for constraints");
  printf(
  "\n                overrides constraint tolerances of input file");
  printf(
  "\n -objgoal <f1 f2 ..fnobj>: goals for obj functions");
  printf(
  "\n       goal = lowest ('min' case) or highest ('max' case)");
  printf(
  "\n              function value of interest");
  printf(
  "\n -objbound <f1 f2 ..fnobj>: bounds for obj functions");
  printf(
  "\n       bound = highest ('min' case) or lowest ('max' case)");
  printf(
  "\n               function value of interest");
  printf(
  "\n -objrange <f1 f2 ..fnobj>: ranges for obj functions");
  printf(
  "\n       use fi in weighted sum in single function minimization");
  printf(
  "\n       fi = 0.0 (default): ignore obj j for weighted sum");
/*eject*/
  printf(
  "\n       option applies only to multicc, gencc, and nsga");
  printf(
  "\n -cutout <n>: cutout flag; n = 0 or 1");
  printf(
  "\n              use initsol file and bounds for obj functions");
  printf(
  "\n              to prepare for minall execution");
  printf(
  "\n -dynamiclimit <n>: dynamic limit flag; n = 0 or 1");
  printf(
  "\n -convergetesteval <n>: dynamic limit flag; n >= 1");
  printf(
  "\n -paretosize <n>: pareto set size desired to be >= n");
  printf(
  "\n -seednsga <f>: rational random seed for nsga; 0.0 < f < 1.0");
  printf(
  "\n -seednomad <n>: integer random seed for nomad; n > 0");
  printf(
  "\n -initialmesh <f>: INITIAL_MESH for nomad; f > 0.0");
  printf(
  "\n -finalmesh <f>: MIN_MESH and MIN_POLL for nomad; f > 0.0");
  printf(
  "\n -maxproctime <n>: max time (sec) allowed for a processor");
  printf("\n");

  return;

}
/********** last record of beginParam.c *******************/
