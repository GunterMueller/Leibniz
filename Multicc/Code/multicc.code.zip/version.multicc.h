/****************************************************************/
/* activate exactly one of the statements below  */
#undef  DENCON  /* dencon */
#undef  DENPAR  /* denpar */
#undef  GENCC   /* gencc */
#define MULTICC /* multicc */
#undef  NOMAD   /* nomad */ 
#undef  NSGA    /* nsga  */
#undef  SEQPEN  /* seqpen */
/****************************************************************/
