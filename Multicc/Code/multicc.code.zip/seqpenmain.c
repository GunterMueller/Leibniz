/* seqpen top routine */
/***************************************************************
 *   Seqpen: Sequential Penalty Derivative-free Method for Nonlinear
 *   Constrained Optimization
 *
 *   This is an implementation in C of the algorithm described in
 *       G. Liuzzi, S. Lucidi, M. Sciandrone. Sequential Penalty 
 *       Derivative-free Methods for Nonlinear Constrained 
 *       Optimization, SIAM Journal on Optimization,
 *       20 (2010) 2614-2635.
 *   Copyright (C) K. Truemper
 *
 *   A Fortran90 implementation by G.Liuzzi, S.Lucidi, M.Sciandrone
 *   called SDPEN is available on the website 
 *   http://www.dis.uniroma1.it/~lucidi/DFL
 *
 *   This program is free software: You can redistribute it and/or 
 *   modify it under the terms of the GNU General Public License as 
 *   published by the Free Software Foundation, either version 3 of 
 *   the License, or (at your option) any later version.
 *
 *   For details of the GNU General Public License, see
 *   <http://www.gnu.org/licenses/>.
 *
 *   We do not make any representation or warranty, 
 *   expressed or implied, as to the condition,
 *   merchantability, title, design, operation, or fitness 
 *   of Seqpen for a particular purpose.
 *
 *   We do not assume responsibility for any errors, 
 *   including mechanics or logic, in the operation 
 *   or use of Seqpen, and have no liability whatsoever 
 *   for any loss or damages suffered by any user as a result of 
 *   Seqpen.
 * 
 *   In particular, in no event shall we be liable
 *   for special, incidental, consequential, or
 *   tort damages, even if we have been advised of 
 *   the possibility of such damages.
 *
 **************************************************************/
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "seqpen.h"
/*eject*/
int seqpenmain() {
	
  int i;

  double finiz, violiniz; 

  /* allocate arrays; for activation, see seqpen.h */
  /* caution: all arrays are used starting with index = 1 */
  /* hence all dimensions are increased by 1 */
  /* alfa_d =  (double *)malloc((nreal+1)*sizeof(double));
  dir =     (double *)malloc((nreal+1)*sizeof(double));
  fstop =   (double *)malloc((nreal+1)*sizeof(double));

  lb =      (double *)malloc((nreal+1)*sizeof(double));
  ub =      (double *)malloc((nreal+1)*sizeof(double));
  xreal =   (double *)malloc((nreal+1)*sizeof(double));
  zvec =    (double *)malloc((nreal+1)*sizeof(double));

  eps =     (double *)malloc((ncon+1)*sizeof(double));
  epsiniz = (double *)malloc((ncon+1)*sizeof(double));
  constr =  (double *)malloc((ncon+1)*sizeof(double)); */

  /* begin added 4/30/2013 */
  /* bestxreal =   (double *)malloc((nreal+1)*sizeof(double));
  bestconstr =  (double *)malloc((ncon+1)*sizeof(double)); */
  /* end added 4/30/2013 */ 

  /* define bounds lb and ub */
  setbounds();

  /* define starting xreal vector */
  startp(xreal);
/*eject*/
  /* initialize counts */
  num_funct = 0; 
  num_iter = 0;

  /* obj and constr for xreal using evaluateSeqpenVector() */
  obj = evaluateSeqpenVector(xreal);

  /* initialize eps using constr */
  for (i=1; i<=ncon; i++) {
    if (constr[i] < 1.0) {
      eps[i] = 1.e-3;
    } else {
      eps[i] = 1.e-1;
    }
  }

  /* compute violvalue according to seqpen rule */
  violvalue = 0.0;
  for (i=1; i<=ncon; i++) {
    violvalue = max(violvalue,constr[i]);
  }  

  /* display initial solution */
  displaysolution("initial");
/*eject*/
  /* initialize variables */

  if (ncon > 0) {
    maxobj = OBJMAXVALUE;
    /* constant was selected by testing that double precision
     * considers (1.0e+07 + 1/1.0e+07) different from  
     * (1.0e+07 + 2/1.0e+07)
     * this assures sufficient sensitivity when (obj+penalty) terms 
     * are compared 
     */
  } else {
    maxobj = OBJMAXVALUE * OBJMAXVALUE;
    /* select maxobj sufficiently large */
  }
  bestobj = maxobj;

  finiz = obj;
  violiniz = violvalue;

  alfa_stop = 1.e-4;
  nf_max = maxEvaluationCount;
  iprint = 0; /* = 0 if no iteration output */
              /* = 1 or 2 if iteration output */

  /* solve problem */
  printf("\nstart seqpen");
  seqpen();
  printf("\ntermination condition: ");
  if (istop == 1) {
    printf("convergence\n");
  } else if (istop == 2) {
    printf("max number of evaluations\n");
  } else if (istop == 3) {
    printf("goal satisfied, solution obj = %g <= goal = %g",
           obj,objGoal[0]);
  } else {
    printf(" seqpen: error, unknown termination code = %d",istop);
    exit(1);
  }
  printf("\ntotal number of evaluations = %d\n",num_funct);

  if (nProcessors > 0) {
    /* TEMPORARY CODE: cycle count = num_funct until parallel */
    /* processing is implemented */
    beginCycleCount(num_funct);
    printf(
    "\nWARNING: parallel processing has not been implemented");
    printf("\ncycle count of parallel evaluations = %d",num_funct);
    printf("\n");
  }
/*eject*/
  if (bestobj != maxobj) {
    /* have a feasible solution */
    printf("\nseqpen solution is feasible");
    /* transfer bestobj, bestconstr, bestxreal values to */
    /* obj, constr, xreal */
    obj = bestobj;
    violvalue = 0.0;
    for (i=1; i<=ncon; i++) {
      constr[i] = bestconstr[i];
      /* compute violvalue according to seqpen rule */
      violvalue = max(violvalue,constr[i]);
    }    
    if (violvalue != 0) {
      printf(
        "\n seqpenmain: inconsistent bestobj = %g and violvalue = %g",
        bestobj,violvalue);
      exit(1);
    }
    for (i=1; i<=nreal; i++) {
      xreal[i] = bestxreal[i];
    }  
    /* display final solution */
    displaysolution("final");

    /* write final_pop.out file */
    convertSeqpenOutput2finalPopOut();
    printf("\n best feasible solution(s) in final_pop.out\n");
  } else {
    /* seqpen did not find a feasible solution */
    printf("\n warning: no feasible solution found");
    printf("\n          no output file final_pop.out\n");
  }
/*eject*/
  /* free arrays; for activation, see seqpen.h */
  /*free(alfa_d);
  free(dir);
  free(fstop);

  free(lb);
  free(ub);
  free(xreal);
  free(zvec);

  free(eps);
  free(epsiniz);
  free(constr);*/

  /* begin added 4/30/2013 */
  /* free(bestxreal);
  free(bestconstr); */
  /* end added 4/30/2013 */

  /* return value below is based on following consideration: */
  /* if there is no feasible solution, then any solution produced */
  /* by seqpen can be useless, and hence is ignored */
  /* accordingly, if not feasible solution, declare failure */	
  if (bestobj != maxobj) {
    return 0;
  } else {
    return 1;
  } 

}
/************ last record of seqpenmain.c **************/
