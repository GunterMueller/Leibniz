/* denpar top routine */
/***************************************************************
 *   Denpar: Linesearch-based Derivative-free Approach for Nonsmooth
 *   Constrained Optimization, parallelized version
 *
 *   This is an parallelized implementation in C of the DFNcon
 *   algorithm described in
 *       G. Fasano, G. Liuzzi, S. Lucidi, F. Rinaldi. A Linesearch-
 *       based Derivative-free Approach for Nonsmooth Optimization
 *       modified for parallel processing
 *   Copyright (C) G. Liuzzi, K. Truemper (independent copyright
 *                 holders)
 *
 *   A single-processor Fortran90 implementation by G. Fasano,
 *   G.Liuzzi, S.Lucidi, F. Rinaldi called DFN is available on the
 *   website http://www.dis.uniroma1.it/~lucidi/DFL
 *
 *   A single-processor C implementation by K. Truemper called
 *   Dencon is available from the same website.
 *
 *   This program is free software: You can redistribute it and/or 
 *   modify it under the terms of the GNU General Public License as 
 *   published by the Free Software Foundation, either version 3 of 
 *   the License, or (at your option) any later version.
 *
 *   For details of the GNU General Public License, see
 *   <http://www.gnu.org/licenses/>.
 *
 *   We do not make any representation or warranty, 
 *   expressed or implied, as to the condition,
 *   merchantability, title, design, operation, or fitness 
 *   of Denpar for a particular purpose.
 *
 *   We do not assume responsibility for any errors, 
 *   including mechanics or logic, in the operation 
 *   or use of Denpar, and have no liability whatsoever 
 *   for any loss or damages suffered by any user as a result of 
 *   Denpar.
 * 
 *   In particular, in no event shall we be liable
 *   for special, incidental, consequential, or
 *   tort damages, even if we have been advised of 
 *   the possibility of such damages. 
 *
 **************************************************************/
/*eject*/
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "denpar.h"
/*eject*/
int denparmain() {

  int i;

  /* initialize arrays */

  /* define bounds lb and ub */
  denparbounds();

  /* define starting xreal[] */
  /* if nInputCandidates = 0, define xreal[] using bounds */
  /* by simple formula that avoids midpoints of bounds */
  denparstart(xreal);

/* starting xreal for maxl*/
/*  for(i= 1;i<=10;i++) xreal[i] =  (double)i;
  for(i=11;i<=20;i++) xreal[i] = -(double)i; */

/* starting xreal for elattar*/
/*  xreal[1] =  2.0;
  xreal[2] =  2.0;
  xreal[3] =  7.0;
  xreal[4] =  0.0;
  xreal[5] = -2.0;
  xreal[6] =  1.0; */

  /* initialize counts */ 
  num_funct = 0; 
  num_iter = 0;
  num_round = 1;
  cycle.sum = 0;
  nXstores = 0;

  num_funct_old = 0; 
  num_iter_old = 0;
  cycle.old = 0;
/*eject*/
  /* evaluate initial solution xreal[] */

  if (ncon > 0) {
    maxobj = OBJMAXVALUE;
    /* constant was selected by testing that double precision
     * considers (1.0e+07 + 1/1.0e+07) different from  
     * (1.0e+07 + 2/1.0e+07)
     * this assures sufficient sensitivity when (obj+penalty) terms 
     * are compared 
     */
  } else {
    maxobj = OBJMAXVALUE * OBJMAXVALUE;
    /* select maxobj sufficiently large */
  }
  bestobj = maxobj;

  /* temporary definition of eps[] for evaluation */
  /* of current_solution.point; is replaced immediately afterward */
  /* by values based on constr[] */
  for (i=1; i<=ncon; i++) {
    eps[i] = 1.0;
  }

  /* store xreal[] in current_solution.point[] */
  vector2vector(xreal,current_solution.point,nreal);

  /* evaluate [] current_solution.point[] */
  current_solution.evaluated = FALSE;
  computeXcurrent_solution(); 
  /* also computes obj, constr[], viol */
  /* stores in current_solution, plus */
  /* function = obj + penalty terms, and evaluated = TRUE */

  /* define correct eps penalty parameters using constr[] */
  for (i=1; i<=ncon; i++) {
    if (constr[i] < 1.0) {
      eps[i] = 1.e-3;
    } else {
      eps[i] = 1.e-1;
    }
  }

  /* recompute function value for new eps[] */
  current_solution.function = obj;
  for (i=1; i<=ncon; i++) {
    current_solution.function += max(0.0,constr[i])/eps[i];
  }
/*eject*/
  /* display initial solution */
  denparsolution("initial");

  /* computational parameters */
  /* do NOT change the values of gamma, delta, zeta, probe_depth */
  gamma = 1.0e-6;
  delta = 0.5;
  zeta = 1.0e-5; /* original 1.0e-5 */
  probe_depth = 16;
  /* check array dimensions */
  if (probe_depth > MAX_TRIAL) {
    printf("\n denparmain: probe_depth = %d > %d = MAX_TRIAL",
           probe_depth,MAX_TRIAL);
    exit(1);
  }
/*eject*/
  /* stopping criteria */

  /* stopping condition for alfa */
  alfa_stop = 1.0e-4;

  /* limits on evaluation and cycle counts */
  nf_max = maxEvaluationCount;
  cycle.max = maxEvaluationCount;

  /* screen display control */
  iprint = 0; /* = 0 if no iteration output */
               /* = 1 or 2 or 3 if iteration output */
               /* = 10 if output of A, B, Z points */
/*eject*/
  /* solve problem */
  printf("\nstart denpar");
  denpar();
/*eject*/
  printf("\nTermination condition: ");
  if (istop == 1) {
    printf("convergence\n");
  } else if (istop == 2) {
    printf("max number of evaluations\n");
  } else if (istop == 3) {
    printf("max number of evaluation cycles\n");
  } else {
    printf(" denparmain: error, unknown termination code = %d",istop);
    exit(1);
  }
  printf("\ntotal number of evaluations = %d",num_funct);
  printf("\ntotal number of cycles      = %d\n",cycle.sum);

  if (nProcessors > 0) {
    /* store cycle.sum */
    beginCycleCount(cycle.sum);
  }
/*eject*/
  if (bestobj != maxobj) {
    /* have a feasible solution */
    printf("\ndenpar solution is feasible");
    /* transfer bestobj, bestconstr, bestxreal values to */
    /* obj, constr, xreal */
    obj = bestobj;
    viol = 0.0;
    for (i=1; i<=ncon; i++) {
      constr[i] = bestconstr[i];
      /* compute viol according to denpar rule */
      viol = max(viol,constr[i]);
    }    
    if (viol != 0) {
      printf(
        "\n denparmain: inconsistent bestobj = %g and viol = %g",
        bestobj,viol);
      exit(1);
    }
    for (i=1; i<=nreal; i++) {
      xreal[i] = bestxreal[i];
    }  
    /* display final solution */
    denparsolution("final");

    /* write final_pop.out file */
    convertDenparOutput2finalPopOut();
    printf("\n best feasible solution(s) in final_pop.out\n");
  } else {
    /* denpar did not find a feasible solution */
    printf("\n warning: no feasible solution found");
    printf("\n          no output file final_pop.out\n");
  }
/*eject*/
  /* return value below is based on following consideration: */
  /* if there is no feasible solution, then any solution produced */
  /* by denpar is useless, and hence is ignored */
  /* accordingly, if not feasible solution, declare failure */	
  if (bestobj != maxobj) {
    return 0;
  } else {
    return 1;
  }

}
/************ last record of denparmain.c **************/
