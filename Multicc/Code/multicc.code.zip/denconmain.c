/* dencon top routine */
/***************************************************************
 *   Dencon: Parallelized Linesearch-based Derivative-free Approach
 *           for Nonsmooth Constrained Optimization
 *
 *   This is a parallelized implementation in C of the DFNcon 
     algorithm described in
 *       G. Fasano, G. Liuzzi, S. Lucidi, F. Rinaldi. A Linesearch-
 *       based Derivative-free Approach for Nonsmooth Optimization
 *   Copyright (C) G. Liuzzi, K. Truemper (independent copyright
 *                 holders)
 *
 *   A Fortran90 implementation by G.Liuzzi, S.Lucidi, M.Sciandrone
 *   called DFN is available on the website 
 *   http://www.dis.uniroma1.it/~lucidi/DFL
 *
 *   This program is free software: You can redistribute it and/or 
 *   modify it under the terms of the GNU General Public License as 
 *   published by the Free Software Foundation, either version 3 of 
 *   the License, or (at your option) any later version.
 *
 *   For details of the GNU General Public License, see
 *   <http://www.gnu.org/licenses/>.
 *
 *   We do not make any representation or warranty, 
 *   expressed or implied, as to the condition,
 *   merchantability, title, design, operation, or fitness 
 *   of Dencon for a particular purpose.
 *
 *   We do not assume responsibility for any errors, 
 *   including mechanics or logic, in the operation 
 *   or use of Dencon, and have no liability whatsoever 
 *   for any loss or damages suffered by any user as a result of 
 *   Dencon.
 * 
 *   In particular, in no event shall we be liable
 *   for special, incidental, consequential, or
 *   tort damages, even if we have been advised of 
 *   the possibility of such damages.
 *
 **************************************************************/
/*eject*/
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "dencon.h"

int denconmain() {
	
  int i, n;
  double fz, objiniz;

  n = nreal;

  /* initialize arrays */

  /* define bounds lb and ub */
  denconbounds();

  /* define starting xreal vector */
  denconstart(xreal);

  /* initialize counts */
  num_funct = 0; 
  num_iter = 0;
  cycle.sum = 0;
  nXstores = 0;

  /* control of directions */
  /* icoordonly = TRUE: use coordinate directions only */
  /*                    effectively, dencon becomes program seqpen */
  /*            = FALSE: use coord, diag, and dense directions */
  icoordonly = gOption.denconcoordinate;

  /* Parallel begin */
  /* limits on evaluation and cycle counts */
  nf_max = maxEvaluationCount;
  cycle.max = maxEvaluationCount;
  /* Parallel end */
/*eject*/
  if (ncon > 0) {
    maxobj = OBJMAXVALUE;
    /* constant was selected by testing that double precision
     * considers (1.0e+07 + 1/1.0e+07) different from  
     * (1.0e+07 + 2/1.0e+07)
     * this assures sufficient sensitivity when (obj+penalty) terms 
     * are compared 
     */
  } else {
    maxobj = OBJMAXVALUE * OBJMAXVALUE;
    /* select maxobj sufficiently large */
  }
  bestobj = maxobj;

  /* compute obj, constr[], viol for xreal */
  /* define temporary eps for evaluateZ(), which uses eps[] */
  /* to compute fz; the fz value is ignored here */
  for (i=1; i<=ncon; i++) {
    eps[i] = 1.e-1;
  } 

  /* evaluate xreal using above temporary eps[] */
  /* ignore fz since eps[] not yet correct */
  fz = evaluateZ(xreal);
     /* also computes obj, constr[], viol */
  /* fill xstore[] with this solution */
  for (i=2; i<=MAX_XSTORE; i++) {
    retainXstore(xreal);
  }
  if (nXstores != MAX_XSTORE) {
    printf("\ndenconmain: xstore[] must be completely filled ");
    exit(1);
  }
/*eject*/
  /* choice of starting penalty parameter values */

  /* define correct initial eps using constr[] */
  for (i=1; i<=ncon; i++) {
    if (constr[i] < 1.0) {
      eps[i] = 1.e-3;
    } else {
      eps[i] = 1.e-1;
    }
  } 

  /* display initial solution */
  violvalue = viol;
  denconsolution("initial");

  /* initialize variables */

  for (i=1; i<=ncon; i++) {
    epsiniz[i] = eps[i];
  }
  objiniz = obj;
  violiniz = viol;

  alfa_stop = 1.e-4;
  iprint = 0; /* = 0 if no iteration output */
              /* = 1 or 2 if iteration output */
/*eject*/
  /* solve problem */
  printf("\nstart dencon");
  dencon(xreal);
  printf("\ntermination condition: ");
  if (istop == 1) {
    printf("convergence\n");
  } else if (istop == 2) {
    printf("max number of evaluations\n");
  } else if (istop == 3) {
    printf("goal satisfied, solution obj = %g <= goal = %g",
           obj,objGoal[0]);
  } else {
    printf(" dencon: error, unknown termination code = %d",istop);
    exit(1);
  }
  printf("\ntotal number of evaluations = %d\n",num_funct);
  if (nProcessors >= 2) {
    printf("\ntotal number of cycles with %d processors = %d\n",
           nProcessors, cycle.sum);
  }
/*eject*/
  if (bestobj != maxobj) {
    /* have a feasible solution */
    printf("\ndencon solution is feasible");
    /* transfer bestobj, bestconstr, bestxreal values to */
    /* obj, constr, xreal */
    obj = bestobj;
    viol = 0.0;
    for (i=1; i<=ncon; i++) {
      constr[i] = bestconstr[i];
      /* compute viol according to dencon rule */
      viol = max(viol,constr[i]);
    }    
    if (viol != 0) {
      printf(
        "\n denconmain: inconsistent bestobj = %g and viol = %g",
        bestobj,viol);
      exit(1);
    }
    for (i=1; i<=nreal; i++) {
      xreal[i] = bestxreal[i];
    }  
    /* display final solution */
    violvalue = viol;
    denconsolution("final");

    /* write final_pop.out file */
    convertSeqpenOutput2finalPopOut();
    printf("\n best feasible solution(s) in final_pop.out\n");
  } else {
    /* dencon did not find a feasible solution */
    printf("\n warning: no feasible solution found");
    printf("\n          no output file final_pop.out\n");
  }
/*eject*/
  /* return value below is based on following consideration: */
  /* if there is no feasible solution, then any solution produced */
  /* by seqpen can be useless, and hence is ignored */
  /* accordingly, if not feasible solution, declare failure */	
  if (bestobj != maxobj) {
    return 0;
  } else {
    return 1;
  } 

}
/************ last record of denconmain.c **************/
