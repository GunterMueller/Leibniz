/* first record of licenseStatement.c */
/***************************************************************
 *
 * subroutines in this file:
 *   void licenseStatement()
 ***************************************************************/
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"

/*eject*/
/**************************************************************
 *   void licenseStatement(char *versiondate):  prints licenses 
 *      used by multicc; versiondate has version defined by date
 **************************************************************/
void licenseStatement(char *globalversion, char *versiondate) {

  printf("\n          Leibniz System: Multicc Module");

  /* print version defined by date */
  printf("\n                Version: %s",globalversion);
  printf("\n                %s",versiondate);

  printf("\n         Copyright 2015 by Leibniz Company");
  printf("\n                Plano, Texas, U.S.A.");
  printf("\n");

  if (gOption.printdetail == 1) {
    return;
  }

  printf("\n Some programs of the multicc system ");
  printf("use the following:\n");
  printf("\n I. Parts of NOMAD Blackbox Optimization System, used ");
  printf("in program nomad");
  printf("\n    Used under GNU Lesser General Public License ");
  printf("(LGPL), version 3");
  printf("\n See http://www.gnu.org/licenses/lgpl.html for ");
  printf("license statement");
  printf("\n Created by");
  printf("\n Mark A. Abramson     - The Boeing Company");
  printf("\n Charles Audet        - Ecole Polytechnique de Montreal");
  printf("\n John E. Dennis, Jr.  - Rice University");
  printf("\n Sebastien Le Digabel - Ecole Polytechnique de Montreal");
  printf("\n Christophe Tribes    - Ecole Polytechnique de Montreal");
  printf("\n Project funded in part by AFOSR and Exxon Mobil");
  printf("\n For details about NOMAD ");
  printf("\n see http://www.gerad.ca/nomad/Project/Home.html");

  printf("\n References:");
  printf("\n 1. Abramson, M.A., Audet C., Couture G., Dennis, ");
  printf("J. E. Jr.,\n    Le Digabel, S., and Tribes, C.,");
  printf("'The NOMAD project,'\n    software available at "); 
  printf("http://www.gerad.ca/nomad.");
  printf("\n 2. Le Digabel, S., 'Algorithm 909: NOMAD: Nonlinear ");
  printf("Optimization with the \n");
  printf("    MADS algorithm,' ");
  printf("ACM Transactions on Mathematical Software,");
  printf(" 37 (2011) 1-15.\n");
  printf("\n II. Parts of NSGA-II source code, used in ");
  printf("programs gencc and nsga");
  printf("\n     Used under license granted by K. Deb.");
  printf("\n Reference:");
  printf("\n 1. Deb, K., Pratap. A, Agarwal, S., and Meyarivan, T.,");
  printf("\n    'A fast and elitist multi-objective genetic ");
  printf("algorithm: NSGA-II'");
  printf("\n    IEEE Transaction on Evolutionary Computation, "); 
  printf("6 (2002) 181-197.\n");
  printf("\n III. C code derived from SPDEN FORTRAN program, used ");
  printf("in program seqpen");
  printf("\n      Derivation under license granted by ");
  printf(" G. Liuzzi, S. Lucidi, and M. Sciandrone.");
  printf("\n Reference:");
  printf("\n 1. Liuzzi, G., Lucidi, S., and Sciandrone, M.,");
  printf("'Sequential Penalty\n    Derivative-free Methods for ");
  printf("Nonlinear Constrained Optimization,'\n    SIAM Journal ");
  printf("on Optimization, 20 (2010) 2614-2635.\n");
  printf("\n IV. C code derived from cs-dfn FORTRAN program, used ");
  printf("in program dencon");
  printf("\n     Derivation under license granted by ");
  printf("\n G. Fasano, G. Liuzzi, S. Lucidi, and F. Rinaldi.");
  printf("\n Reference:");
  printf("\n 1. Fasano, G., Liuzzi, G., Lucidi, S., and ");
  printf("Rinaldi, F.,");
  printf("\n 'A Linesearch-based Derivative-free Approach for ");
  printf("Nonsmooth\n Optimization' ");
  printf("\n");

  return;
}
/* last record of licenseStatement.c */
