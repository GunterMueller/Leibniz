/* routines for search */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "denpar.h"
/**************************************************************
 *
 * subroutines in this file:
 *       void decide_factor()
 *       int  decide_termination()
 *       void define_nselect(int *start)
 *       void define_trial_point(double *x)
 *       void evaluate_all_point()
 *       void evaluate_one_point(int i, int k)
 *       void select_alfa()
 *       void update_alfa_d(double *alfa_d)
 *       void update_best_search()
 *       void update_done_flag()
 **************************************************************/
/*eject*/
/**************************************************************
 *   void decide_factor(): decide factor if now possible
 *                         decide done_flag if +1.0/-1.0*direction
 *                             is not successful
 **************************************************************/
void decide_factor(){

  int i, n;

  n = nreal;

  for (i=restriction.begin; i<=restriction.end; i++){
    if (all_search[i].nselect == 0) {
      continue;
    }
    if (all_search[i].decided_factor == 0.0) {

      if (all_search[i].trial[1].success == TRUE) {
        /* 1.0*direction is successful */
        all_search[i].decided_factor = 1.0;
        continue;
      }

      /* have all_search[i].trial[1].success == FALSE */
      if ((all_search[i].ntrial + all_search[i].nselect) >= 2) {
        if (all_search[i].trial[2].success == TRUE) {
          /* -1.0*direction is successful */   
          all_search[i].decided_factor = -1.0;
        } else {
          /* +1.0/-1.0*direction is not successful */
          all_search[i].done_flag = TRUE;
          all_search[i].nselect = 0;
          all_search[i].ntrial = 0;
        }

      } /* end if all_search[i].ntrial + ... */
    } /* end if all_search[i].decided_factor == 0.0 */
  } /* end for i */

  return;
}
/*eject*/
/**************************************************************
 *   int decide_termination(): decide termination
 **************************************************************/
int decide_termination(){
  int i, n;

  n = nreal;

  for (i=restriction.begin; i<=restriction.end; i++){
    if (best_search[i].success == UNDECIDED) {
      return FALSE;
    }    
  }

  return TRUE;
}
/*eject*/
/**************************************************************
 *   void define_nselect(int *start): define nselect values          
 **************************************************************/
void define_nselect(int *start_){

  int i, j, k, n, nproc;
  int excess, height, start, width;

  n = nreal;

  /* transfer in */
  start = *start_;

  nproc = max(1,nProcessors);
  if (current_solution.evaluated == FALSE) {
    /* reserve one processor for evaluation */
    /* of current_solution.point[] */
    nproc--;
  }

  if (nproc == 0) {
    for (i=1; i<=n; i++){
      all_search[i].nselect = 0;
    }

    /* transfer out not needed */
    return;
   
  }
/*eject*/
  /* nproc >= 1 */

  width = 0;
  for (i=restriction.begin; i<=restriction.end; i++){
    if (all_search[i].done_flag == FALSE){
      width++;
    }
  }
  height = nproc/width;
  excess = nproc%width;
  j = start;
  k = 1;
  for (i=restriction.begin; i<=restriction.end; i++){
    if (all_search[j].done_flag == FALSE) {
      all_search[j].nselect = height;
      if (k <= excess) {
        all_search[j].nselect++;
      }
      k++;
      all_search[j].nselect = min(all_search[j].nselect,
                         MAX_TRIAL-all_search[j].ntrial);
    } else {
      all_search[j].nselect = 0;
    }
    j = circ(j+1);
    if (k == excess+1) {
      start = j;
    }
  }

  /* transfer out */
  *start_ = start;

  return;
}
/*eject*/
/**************************************************************
 *   void define_trial_point(): 
 *          define all_search[].trial[].direction[] 
 *                 all_search[].trial[].point[]
 *                 all_search[i].trial[k].factor
 *                 all_search[i].trial[k].alfa
 **************************************************************/
void define_trial_point(){

  int i, ii, j, k, n;
  double alfa, fac, d[MAX_VARIABLE+1];

  n = nreal;

  for (i=restriction.begin; i<=restriction.end; i++){
    if (all_search[i].nselect == 0) {
      continue;
    }
    for (j=1; j<=all_search[i].nselect; j++) {
      alfa = all_search[i].select.alfa[j];
      fac = all_search[i].select.factor[j];
      k = all_search[i].ntrial+j;
      for (ii=1; ii<=n; ii++) {
        d[ii] = direction_matrix[ii][i];
      }
      xplusdir2z(current_solution.point,
                 alfa*fac,
                 d,
                 all_search[i].trial[k].point,
                 n);
      for (ii=1; ii<=n; ii++) {
        /* project point[] onto box of bounds */
        all_search[i].trial[k].point[ii] = 
           max(lb[ii],min(ub[ii],all_search[i].trial[k].point[ii]));
        /* direction[] */
        all_search[i].trial[k].direction[ii] = 
                        fac*direction_matrix[ii][i]; 
      }
      /* factor */
      all_search[i].trial[k].factor = fac;
      /* alfa */
      all_search[i].trial[k].alfa = alfa;
    }
  }

  return;
}
/*eject*/
/**************************************************************
 *   void evaluate_all_points(): 
 *        assumes nProcessors > 0
 *        evaluate all_search[].trial[].point[], and also
 *                 current_solution.point if not already evaluated 
 *        evaluation is done via parallelCandidates[] and 
 *                  evaluate_parallelCandidate()
 *        retain solutions in xstore[]
 *
 *   caution: parallelCandidates[] arrays have 0 as starting index
 *            thus, index shifts are required in all transfers
 *            into or out of parallelCandidate[] arrays
 **************************************************************/
void evaluate_all_points(){

  int flag, i, j, k, n, nc;
  int lookup, nlook;
  double alfa;

  n = nreal;

  nlook = 0; /* number of cases looked up */

  nParallelCandidates = 0;
/*eject*/
  /* case 1: evaluate current_solution is not already evaluated */
  /*         this can happen only if nProcessors > 1, due to */
  /*         rule in denpar(); see lines after next_point() call */
  if (current_solution.evaluated == FALSE) {

    if (nProcessors <= 1) {
      printf("\n evaluate_all_points: nProcessors = %d, ",
             nProcessors);
      printf("but must be > 1");
      exit(1);
    }

    current_solution.function = 
        computeX(current_solution.point,&lookup);

    if (lookup == TRUE) {
      nlook++;
      /* computeX() has computed obj, constr[], viol */
      /* store these results */
      current_solution.obj = obj;
      vector2vector(constr,current_solution.constr,ncon);
      current_solution.viol = viol;
      current_solution.evaluated = TRUE;
    } else {   
      /* store point in parallelCandidate[].xvalue[] */
      if (nParallelCandidates >= MAX_PROC) {
        printf("\n evaluate_all_points: ");
        printf("MAX_PROC = %d is too small",MAX_PROC);
        exit(1);
      }
      vector2parallelCandidate(current_solution.point,
                               nParallelCandidates,n);
      parallelCandidate[nParallelCandidates].keepFlag = FALSE;
      nParallelCandidates++;
    }

  }
/*eject*/
  /* case 2: for each i: */
  /*         evaluate all_search[i].nselect trial points */
  for (i=restriction.begin; i<=restriction.end; i++){  /* for i #1 */
    for (j=1; j<=all_search[i].nselect; j++) {
      k = all_search[i].ntrial + j;
      /* compute values */
      all_search[i].trial[k].function = 
           computeX(all_search[i].trial[k].point, &lookup);
           /* also computes obj, constr[], viol */
      if (lookup == TRUE) {
        nlook++;
        /* store looked-up values in all_search[i].trial[k] */
        all_search[i].trial[k].obj = obj;
        vector2vector(constr,all_search[i].trial[k].constr,ncon);
        all_search[i].trial[k].viol = viol;
        /* set pcandidx = -1 to indicate that evaluation process */
        /* involving parallelCandidate[] is not used */
        all_search[i].trial[k].pcandidx = -1;
/*eject*/
      } else {
        /* point does not exist in xstore[] */
        /* check if all_search[i].trial[k].point[] is in */
        /* parallelCandidate[] */
        flag = FALSE;
        for (nc=0; nc<nParallelCandidates; nc++) {
          if (same_parallelCandidate(all_search[i].trial[k].point,
                                     nc,n) == TRUE) {
            /* all_search[i].trial[k].point exists already in */
            /* parallelCandidate[], so effectively this is a */
            /* lookup case */
            /* store nc index in pcandix */
            lookup++;
            all_search[i].trial[k].pcandidx = nc;
            flag = TRUE;
            break;
          }
        }
        if (flag == FALSE) {
          /* all_search[i].trial[k].point[] is not in */
          /* parallelCandidate[] */
          /* hence store in parallelCandidate[] */
          if (nParallelCandidates >= MAX_PROC) {
            printf("\n evaluate_all_points: ");
            printf("MAX_PROC = %d is too small",MAX_PROC);
            exit(1);
          }
          vector2parallelCandidate(all_search[i].trial[k].point,
                                   nParallelCandidates,n);
          parallelCandidate[nParallelCandidates].keepFlag = FALSE;
          all_search[i].trial[k].pcandidx = nParallelCandidates;
          nParallelCandidates++;
        } /* end if flag == FALSE */
      } /* end if lookup == TRUE || nProcessors <= 1, else */ 
    } /* end for j */
  } /* end for i #1 */
/*eject*/
  if (nParallelCandidates > 0) {

    /* evaluate parallelCandidate[] */
    evaluate_parallelCandidate("denpar", TRUE);
    num_funct += nParallelCandidates;
    cycle.sum++;

    if (current_solution.evaluated == FALSE) {
      /* extract current_solution from parallelCandidate[0] */
      extract_parallelCandidate(0,
                                current_solution.point,
                                &current_solution.function,
                                &current_solution.obj,
                                current_solution.constr,
                                &current_solution.viol);
      current_solution.evaluated = TRUE;
      /* also computes obj, constr[], viol */
      /* store solution */
      retainX(current_solution.point);
    }
/*eject*/
    /* extract all_search[].trial[] from parallelCandidate[] */
    for (i=restriction.begin; i<=restriction.end; i++) {
      for (j=1; j<=all_search[i].nselect; j++) {
        k = all_search[i].ntrial + j; 
        if (all_search[i].trial[k].pcandidx >= 0) {
          if (all_search[i].trial[k].pcandidx > nParallelCandidates) {
            printf("\n evaluate_all_points: pcandidx  = %d must ",
                   all_search[i].trial[k].pcandidx);
            printf("\nbe < nParallelCandidates = %d",
                   nParallelCandidates);
            exit(1);
          }
          extract_parallelCandidate(all_search[i].trial[k].pcandidx,
                                    all_search[i].trial[k].point,
                                    &all_search[i].trial[k].function,
                                    &all_search[i].trial[k].obj,
                                    all_search[i].trial[k].constr,
                                    &all_search[i].trial[k].viol);
          /* also computes obj, constr[], viol */
          /* store solution */
          retainX(all_search[i].trial[k].point);
        }
      }
    } 

  } /* end if nParallelCandidates > 0 */
/*eject*/
  if ((iprint >= 3) && (iprint <= 9)) {
    printf(
      "\n evaluate_all_points: cycle.sum = %d ncomp = %d nlook = %d",
          cycle.sum,nParallelCandidates,nlook);
    fflush(stdout);
  }

  /* check validity of current_solution */
  if (current_solution.evaluated == FALSE) {
    printf("\n evaluate_all_points: current_solution not evaluated");
    exit(1);
  }

  /* decide success */
  for (i=restriction.begin; i<=restriction.end; i++){  /* for i #2 */
    for (j=1; j<=all_search[i].nselect; j++) {
      k = all_search[i].ntrial + j;
      alfa = all_search[i].trial[k].alfa; 
      if (all_search[i].trial[k].function < 
          current_solution.function - gamma*pow(alfa,2)) {
        all_search[i].trial[k].success = TRUE;
      } else {
        all_search[i].trial[k].success = FALSE;
      }
      if ((iprint >= 1) && (iprint <= 9)) {
        printf(
  "\n evaluate_all_point: i = %d k = %d succ = %d fz = %g alfa = %g",
              i,k,all_search[i].trial[k].success,
              all_search[i].trial[k].function,alfa);
        fflush(stdout);
      }
    }
  }  /* end for i #2 */

  return;
}
/*eject*/
/**************************************************************
 *   void evaluate_one_point(int i, int k): 
 *        assumes nProcessors = 0
 *        evaluate one all_search[i].trial[k].point
 **************************************************************/
void evaluate_one_point(int i, int k) {

  int n;
  int lookup;
  double alfa;

  n = nreal;

  /* current_solution must already be evaluated */
  /* see denparmain() and also denpar() lines after */
  /* next_point() call */
  if (current_solution.evaluated == FALSE) {
    printf("\n evaluate_one_point: current_solution not evaluated");
    exit(1);
  }

  /* compute values */
  /* retain values in xstore[] */
  all_search[i].trial[k].function = 
       computeX(all_search[i].trial[k].point, &lookup);
       /* also computes obj, constr[], viol */
  /* store results */
  all_search[i].trial[k].obj = obj;
  vector2vector(constr,all_search[i].trial[k].constr,ncon);
  all_search[i].trial[k].viol = viol;

  if ((iprint >= 3) && (iprint <= 9)) {
    printf(
      "\n evaluate_one_point: cycle.sum = %d", cycle.sum);
    fflush(stdout);
  }
/*eject*/
  /* decide success */
  alfa = all_search[i].trial[k].alfa; 
  if (all_search[i].trial[k].function < 
      current_solution.function - gamma*pow(alfa,2)) {
    all_search[i].trial[k].success = TRUE;
  } else {
    all_search[i].trial[k].success = FALSE;
  }
  if ((iprint >= 1) && (iprint <= 9)) {
    printf(
   "\n evaluate_point: i = %d k = %d succ = %d fz = %g alfa = %g",
          i,k,all_search[i].trial[k].success,
          all_search[i].trial[k].function,alfa);
    fflush(stdout);
  }

  return;

}
/*eject*/
/**************************************************************
 *   void select_alfa(): select alfa[]          
 **************************************************************/
void select_alfa(){

  int i, j, n, ns;
  double alfa, fac;

  n = nreal;

  for (i=restriction.begin; i<=restriction.end; i++){
    if (all_search[i].nselect == 0) {
      continue;
    }
    ns = 0;
    if (all_search[i].decided_factor == 0.0) {
      /* must have all_search[i].ntrial = 0 or 1 */
      if (all_search[i].ntrial == 0) {
        ns++;
        all_search[i].select.alfa[ns] = all_search[i].alfa_init;
        all_search[i].select.factor[ns] = 1.0;
      }
      if (ns < all_search[i].nselect) {
        ns++;
        all_search[i].select.alfa[ns] = all_search[i].alfa_init;
        all_search[i].select.factor[ns] = -1.0;
      }

      alfa = all_search[i].alfa_init;
      fac = 1.0;
/*eject*/
      while (ns < all_search[i].nselect) {
        /* if fac = 1.0, increase alfa */
        if (fac == 1.0) {
          alfa /= delta;
        }
        ns++;
        all_search[i].select.alfa[ns] = alfa;
        all_search[i].select.factor[ns] = fac;
        fac = -fac;
      }
    } else {
      /* search factor has been decided */
      /* determine alfa from trial with largest index */
      /* for which factor = decided_factor */
      alfa = 0.0;
      for (j=1; j<=all_search[i].ntrial; j++) {
        if (all_search[i].trial[j].factor == 
            all_search[i].decided_factor) {
          alfa = all_search[i].trial[j].alfa;
        }
      }
      if (alfa == 0.0) {
        printf(
           "\n select_alfa: error, alfa = 0.0 should be nonzero");
        exit(1);
      }
      fac = all_search[i].decided_factor;
      while (ns < all_search[i].nselect) {
        alfa /= delta;
        ns++;
        all_search[i].select.alfa[ns] = alfa;
        all_search[i].select.factor[ns] = fac;
      }
    }
  }

  return;
}
/*eject*/
/**************************************************************
 *   void update_alfa_d(double *alfa_d): 
 *           update alfa_d and alfa_max 
 *                  using best_search[].alfa_d_scalar         
 **************************************************************/
void update_alfa_d(double *alfa_d) {
 
  int i, n;

  n = nreal;

  alfa_max = -INF;

  for (i=restriction.begin; i<=restriction.end; i++) {
    alfa_d[i] = max(best_search[i].alfa_d_scalar,alfa_stop/1.0e6);
  }

   for (i=1; i<=n; i++) {
    alfa_max = max(alfa_max,alfa_d[i]);
  } 

  return;
}
/*eject*/
/**************************************************************
 *   void update_best_search(): update best_search[]
 **************************************************************/
void update_best_search() {

  int i, j, n;

  n = nreal;

  for (i=restriction.begin; i<=restriction.end; i++){

    if ((best_search[i].success != UNDECIDED) || 
        (all_search[i].done_flag == FALSE)) {
      /* best_search[i] case has been decided or
       * all_search[i] case is not done yet 
       */
      continue;
    }

    if (all_search[i].ntrial == 0) {
      /* unsuccessfull case */
      best_search[i].success = FALSE;
      best_search[i].alfa_d_scalar = delta*all_search[i].alfa_init;
      continue;
    }

    if (all_search[i].idx <= 0) {
      printf("\n update_best_search: all_search[i].idx = %d <= 0\n",
            all_search[i].idx);
      exit(1);
    }
    /* idx is index of trial with best results  */
    j = all_search[i].idx;

    /* check for significant change in solution vector */
    if (relative_distance(all_search[i].trial[j].point,
                          current_solution.point,n) < zeta) {
      /* change is too small, declare success = FALSE */
      best_search[i].success = FALSE;
      best_search[i].alfa_d_scalar = delta*all_search[i].alfa_init;
      continue;
    }
/*eject*/
    /* have success case with significant change */
    /* update best_search[i] using all_search[i].trial[j] */
    /* alfa */
    best_search[i].alfa = 
            all_search[i].trial[j].alfa;
    /* function */
    best_search[i].function = all_search[i].trial[j].function;
    /* obj */
    best_search[i].obj = all_search[i].trial[j].obj;
    /* viol */
    best_search[i].viol = all_search[i].trial[j].viol;
    /* direction */
    vector2vector(all_search[i].trial[j].direction,
            best_search[i].direction,n);
    /* point */
    vector2vector(all_search[i].trial[j].point,
            best_search[i].point,n);
    /* constr */
    vector2vector(all_search[i].trial[j].constr,
            best_search[i].constr,ncon);
    /* success */
    best_search[i].success = TRUE;
    /* alfa_d_scalar */
    best_search[i].alfa_d_scalar = all_search[i].alfa_d_scalar;

  }

  return;
}
/*eject*/
/**************************************************************
 *   void update_done_flag(): update all_search[].done_flag,
 *           all_search[].ntrial, all_search[].alfa_d_scalar
 **************************************************************/
void update_done_flag() {
 
  int i, j, k, lim, m, mink, n, nidx;
  int idx[MAX_TRIAL+1];
  double fac, minf;

  n = nreal;

  for (i=restriction.begin; i<=restriction.end; i++){

    /* if nselect = 0, no new results can possibly be derived */
    /* hence, that case can be skipped */
    /* since done_flag = TRUE implies nselect = 0, */
    /* all cases with done_flag = TRUE are skipped */  
    if (all_search[i].nselect == 0) {
      continue;
    }

    /* update ntrial */
    all_search[i].ntrial += all_search[i].nselect;

    /* if factor not yet decided, no further action needed */
    if (all_search[i].decided_factor == 0.0) {
      continue;
    }
/*eject*/
    /* initialize lim, which is total number of cases with */
    /* decided_factor value that need to be checked, */
    /* to probe_depth */
    lim = probe_depth;

    /* find indices with correct factor */
    fac = all_search[i].decided_factor;
    nidx = 0;
    for (j=1; j<=all_search[i].ntrial; j++) {
      if(all_search[i].trial[j].factor == fac) {
        nidx++;
        idx[nidx] = j;
        if ((nidx >= 2) &&
            (same_vector(all_search[i].trial[idx[nidx]].point,
                         all_search[i].trial[idx[nidx-1]].point,n))) {
          /* point idx[nidx] is same as point idx[nidx-1] */
          /* this implies that each additional point idx[nidx+m], */
          /* m = 1, 2, ... is also converted by projection to */
          /* point idx[nidx-1] */
          /* accordingly, reduce lim to nidx-1 */
          lim = min(lim,nidx-1);         
          break;
        }
      }
    }
    if (nidx == 0) {
      printf("\n update_done_flag: error, nidx = 0\n");
      exit(1);
    }
    if ((iprint >= 3) && (iprint <= 9)) {
      printf("\n update_done_flag: i = %d nidx = %d ntrial = %d",
                    i,nidx,all_search[i].ntrial);
      fflush(stdout);
    }
    if (nidx == 1) {
      continue;
    }
/*eject*/
    /* search for success index  */
    for (k=1; k<=nidx; k++) {
      if (k == lim) {
        /* limit case */
        all_search[i].done_flag = TRUE;
        /* select best of the idx[] cases up to lim */
        minf = all_search[i].trial[idx[1]].function;
        mink = 1;
        for (m=2; m<=k; m++) {
          if (all_search[i].trial[idx[m]].function < minf) {
            minf = all_search[i].trial[idx[m]].function;
            mink = m;
          }
        }
        all_search[i].idx = idx[mink];
        /* retain alfa of trial idx[k] as alfa_d_scalar */
        all_search[i].alfa_d_scalar = 
            all_search[i].trial[idx[k]].alfa;

        if ((iprint >= 3) && (iprint <= 9)) {
          printf("\n update_done_flag: success final index TRUE %d",
                       all_search[i].trial[idx[k]].success);
          fflush(stdout);
        }
        break;
      }
      if (k == nidx) {
        /* not done yet, so done_flag remains FALSE */
        break;
      }
/*eject*/
      /* intermediate case with k < nidx and k < lim */
      /* check for success transition from TRUE to FALSE */

      if ((all_search[i].trial[idx[k]].success == TRUE) &&
          (all_search[i].trial[idx[k+1]].success == FALSE)) {
        all_search[i].done_flag = TRUE;
        /* select best of the idx[] cases up to k */
        minf = all_search[i].trial[idx[1]].function;
        mink = 1;
        for (m=2; m<=k; m++) {
          if (all_search[i].trial[idx[m]].function <= minf) {
            minf = all_search[i].trial[idx[m]].function;
            mink = m;
          }
        }
        all_search[i].idx = idx[mink];
        /* retain alfa of trial idx[k] as alfa_d_scalar */
        all_search[i].alfa_d_scalar = 
              all_search[i].trial[idx[k]].alfa;

        if ((iprint >= 3) && (iprint <= 9)) {
          printf(
             "\n update_done_flag: success index TRUE %d FALSE %d",
             idx[k],idx[k+1]);
          fflush(stdout);
        }
        break;
      }
    } /* end for k */ 
  } /* end for i */
  
  return;
}
/***** last record of denparSearch.c *****/
