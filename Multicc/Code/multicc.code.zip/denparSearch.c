/* routines for search */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "denpar.h"
/**************************************************************
 *
 * subroutines in this file:
 *       int compute_progress()
 *       void initialize_alfa_d(double *alfa_d)
 *       void initialize_directions()
 *       void next_alfa_d(double *alfa_d)
 *       void next_direction_matrix(double *d)
 *       void next_point(double *x, double *f)
 *       int  next_type_direction(double *alfa_d, double *d_dense)
 **************************************************************/
/*eject*/
/**************************************************************
 *   int compute_progress()
 *     check for significant improvement    
 **************************************************************/
int compute_progress() {

  int flag, i, n;

  n = nreal;

  flag = FALSE; /* = FALSE means none of the directions can */
                /*         be used to reduce the obj function */

  /* check for significant improvement */
  for (i=restriction.begin; i<=restriction.end; i++) {
    if ((best_search[i].success == TRUE) && 
        (best_search[i].alfa >= alfa_stop)) {
      flag = TRUE;
      break;
    }
  }

  return flag;

}
/*eject*/
/**************************************************************
 *   void initialize_alfa_d(double *alfa_d): 
 *          initialize alfa_d[]
 *          initialize alfa_max
 *          store values in alfa_store[] and alfa_max_store[]
 **************************************************************/
void initialize_alfa_d(double *alfa_d) {

  int i, n;

  n = nreal;

  alfa_max = -INF;
  for (i=1; i<=n; i++) {
    /*alfa_d[i] = max(1.e-3,min(1.0,fabs(x[i])));*/
    alfa_d[i] = 1.e-3;
    alfa_max = max(alfa_max,alfa_d[i]);
    if ((iprint >= 1) && (iprint <= 9)) {
      printf("\n alfainiz[%d] = %g",i,alfa_d[i]);
      fflush(stdout);
    }
  }

  /* COORD */
  vector2vector(alfa_d,alfa_store[COORD],n);
  alfa_max_store[COORD] = alfa_max;
  /* DIAG */
  vector2vector(alfa_d,alfa_store[DIAG],n);
  alfa_max_store[DIAG] = alfa_max;
  /* DENSE */
  alfa_store[DENSE][1] = 0.0;
  for (i=1; i<=n; i++) {
    alfa_store[DENSE][1] += alfa_d[i];
  }
  alfa_store[DENSE][1] /= (double)n;
  for (i=2; i<=n; i++) {
    alfa_store[DENSE][i] = alfa_store[DENSE][1];
  }
  alfa_max_store[DENSE] = alfa_store[DENSE][1];
  
  return;

}
/*eject*/
/**************************************************************
 *   void initialize_directions()
 *          initialize direction_matrix[][]
 **************************************************************/
void initialize_directions() {

  int n, i, j;

  n = nreal;

  /* initialize direction_matrix[][] as identity matrix */
  for (i=1; i<=n; i++) {
    for (j=1; j<=n; j++) {
      direction_matrix[i][j] = 0.0;
    }
    direction_matrix[i][i] = 1.0;
  }

  return;
}
/*eject*/
/**************************************************************
 *   void next_alfa_d(int typ_dir, double *alfa_d)
 *     revise alfa_d[] and alfa_max for direction type typ_dir   
 **************************************************************/
void next_alfa_d(int typ_dir, double *alfa_d) {

  int i, n;

  n = nreal;

  if ((typ_dir == COORD) || (typ_dir == DIAG)) {

    /* restore from alfa_store[typ_dir][] */
    vector2vector(alfa_store[typ_dir],alfa_d,n);
    /* restore alfa_max to alfa_max_store[typ_dir][] */
    alfa_max = alfa_max_store[typ_dir];

  } else if (typ_dir == DENSE) {

      /* average alfa values stored for DENSE */
      if (typ_dir == DENSE) {
        alfa_d[1] = 0.0;
        for(i=1;i<=n;i++) {
          alfa_d[1] += alfa_store[typ_dir][i];
        }       
        alfa_d[1] /= (double)n;
        for(i=2;i<=n;i++) {
          alfa_d[i] = alfa_d[1];
        }
        alfa_max = alfa_d[1];
      }

  } else {
    printf("\n next_alfa: unknown direction type = %d",
           typ_dir);
    exit(1);
  }

  return;

}
/*eject*/
/**************************************************************
 *   void next_direction_matrix(double *d)
 *     get next direction_matrix[][] using direction d[]
 **************************************************************/
void next_direction_matrix(double *d) {

  int i, n;

  n = nreal;

  /* define H[][] matrix from d vector */
  gen_base(d);

  /* perform Gram-Schmidt orthogonalization on H[][] */
  gram_schmidt();

  /* copy H[][] into direction_matrix[][] */
  for (i=1; i<=n; i++) {
    vector2vector(H[i],direction_matrix[i],n);
  }  

  return;

}
/*eject*/
/**************************************************************
 *   void next_point()
 *       if convex combination of best_search[] results can be
 *               computed due to significant alfa coefficients:
 *         define current_solution.point[] = convex combination of
 *               best_search[] results of linesearches
 *         does not update f, obj, constr[], viol of current_solution
 *         hence current_solution.evaluated is reset to FALSE
 *       else 
 *         define current_solution.point[] to be current solution
 *         current_solution has correct function, obj, 
 *         constr[], viol
 *         hence current_solution.evaluated remains TRUE       
 **************************************************************/
void next_point() {

  int i, j, n;
  double sum;

  n = nreal;

  /* check validity of current_solution */
  if (current_solution.evaluated == FALSE) {
    printf("\n next_point: current_solution not evaluated");
    exit(1);
  }
/*eject*/
  /* point[] = convex combination of best_search[] results */

  /* compute sum for convex combination */
  sum = 0.0;
  for (j=restriction.begin; j<=restriction.end; j++) {
    if (best_search[j].success == TRUE) {
      sum += 1.0;
    }
  }

  /* define convex combination */

  /* initialize current_solution.point[] */
  for (i=1; i<=n; i++) {
    current_solution.point[i] = 0.0;
  }

  /* point[] = convex combination of relevant */
  /*           best_search[].point[] */

  for (j=restriction.begin; j<=restriction.end; j++) {
    if (best_search[j].success == TRUE) {
      for (i=1; i<=n; i++) {
        current_solution.point[i] += (1/sum) * 
                                     best_search[j].point[i];
      }
    }
  }
  current_solution.evaluated = FALSE;

  return;

}
/*eject*/
/**************************************************************
 *   void next_type_direction(double *alfa_d, double *d_dense)
 *     change type_direction
 *     select and another orthonormal basis
 *     typ_dir has current type_direction; possible values are
 *     COORD, DIAG, DENSE
 *     defines vector d[] for construction of the new basis
 **************************************************************/
void next_type_direction(double *alfa_d, double *d) {

  int i, j, n; 
  int new_dir;

  n = nreal;
/*eject*/
  
  new_dir = 0;
  j = type_direction;
  /* next type_direction with alfa_max > alfa_stop */
  for (i=2; i<=MAX_TYPDIR+1; i++) {
    j++;
    if (j > MAX_TYPDIR) {
      j = 1;
    }
    if (alfa_max_store[j] > alfa_stop) {
      new_dir = j;
      break;
    }
  }

  if (new_dir == 0) {
    printf("\n next_type_direction: error, new_dir = %d",new_dir);
    exit(1);
  }

  switch ( new_dir ) {
    case COORD:
      d[1] = 1.0;
      for (i=2; i<=n; i++) {
        d[i] = 0.0;
      }
      break;
    case DIAG:
      for (i=1; i<=n; i++) {
        d[i] = -1.0;
      }
      break;
    case DENSE:
      index_halton++;
      /*index_halton +=LARGEPRIME; update of alternate choice */
      halton(index_halton,d);
      break;
  }

  num_round++; 

  /* store new type_direction */
  type_direction = new_dir;

  return;

}
/************* last record of denparSearch.c ********/
