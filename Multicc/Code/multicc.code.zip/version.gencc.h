/****************************************************************/
/* activate exactly one of the statements below  */
#undef  DENCON  /* dencon */
#undef  DENPAR  /* denpar */
#define GENCC   /* gencc */
#undef  MULTICC /* multicc */
#undef  NOMAD   /* nomad */ 
#undef  NSGA    /* nsga  */
#undef  SEQPEN  /* seqpen */
/****************************************************************/
