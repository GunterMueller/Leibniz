/* debug status program for denpar as part of multicc package */
# include "debugstatus.h"/**************************************************************
 *  void debugstatus(char *debugfile):
 *     - place this routine into any program
 *     - use debugger to stop after this routine
 *     - file <debugfile> contains the output of this routine      
 **************************************************************/
void debugstatus(char *debugfile) {

  int i, j, k, n;

  FILE *dfil;

  n = nreal;

  dfil = fopen(debugfile,"w");

  /* begin: define output for debugfile */

  for (i=1; i<=n; i++) {
    fprintf(dfil,"** i = %2d ** done_flag = %d ** idx = %d *******\n", 
          i, all_search[i].done_flag, all_search[i].idx);
    for (k=1; k<=all_search[i].ntrial; k++) {
      fprintf(dfil,"k =%2d  obj = %6.2f  point =",
                   k,  all_search[i].trial[k].obj);
      for (j=1; j<=n; j++) {
        fprintf(dfil,"  %6.2f",all_search[i].trial[k].point[j]);
      }
      fprintf(dfil, " factor = %3.1f", all_search[i].trial[k].factor);
      fprintf(dfil, " success = %d", all_search[i].trial[k].success);
      fprintf(dfil,"\n");
    }
    fprintf(dfil,"\n");    
  }
  /* end: define output for debugfile */

  fclose(dfil);

  return;

}
/***** lat record of debugstatus.c *************/
