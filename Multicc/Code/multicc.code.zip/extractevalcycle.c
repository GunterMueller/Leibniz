/* run multicc test cases */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

/************************************************************
 *  subroutines in this file:
 *    int main program for extractevalcycle
 *       execution: extractevalcycle 
 *                             <logoneprocfile>
 *                             <logparallelfile> 
 *                             <outputfile>
 *                             <headfile>
 *                             <tailfile>
 *                             <processors>
 *                             <method>
 * 
 *  purpose: evaluates efficiency of single processor versus
 *           parallel processor execution using the exactly same
 *           set of problems
 *           
 *  details:
 *
 *    logoneprocfile  = log file of single-processor run
 *    logparallelfile = log file of parallel processor run
 *    outputfile      = output file with table in LaTex format
 *    headfile        = header file in LaTeX format
 *    tailfile        = tail file inf LaTeX format
 *    processors      = number of parallel processors
 *    method          = solution method
 *
 *    cat headfile outputfile tailfile
 *       produces complete LaTex table
 *
 *  - assumes execution for finding an initial solution is done and
 *    requires REDUCE_EVAL evaluations that are not counted in the
 *    evaluation process
 *  - allows up to n < MAX_VAR variables for each problem of
 *    the problem set. For each n, a separate ratio of
 *    efficiency is computed, plus an overall ratio
 *  - discards all problems where the number of evaluations
 *    exceeds MAX_EVAL for single proc or parallel case
 *    for each n, the total number of problems and the number
 *    of discarded cases, is computed
 *  - each problem name is of the form <xxx>_n where n is the number
 *    of variables
 *  - the input logoneprocfile and logparallelfile must be log files
 *    of exactly the same problem set
 *                  
 ************************************************************/
/*eject*/ 
#define MAXLEN 15000
#define MAX_ENTRY 256
#define TRUE 1
#define FALSE 0

#define INFF 1.0e+100

#define MAX_ONEPROC_EVAL 50000
#define MAX_PARALLEL_EVAL 50000
#define REDUCE_EVAL 500
#define MAX_VAR 500

/********* global variables ********/
/* for each count: index = 0 means total of all entries */
/* cycle, evaluation, deletion, total counts */

int oneproceval[MAX_VAR+1],
    parallelcycle[MAX_VAR+1], 
    paralleleval[MAX_VAR+1];
double oneprocratio[MAX_VAR+1],
       parallelratio[MAX_VAR+1];
double totalratio;
int oneeval, parcycle, pareval;
int recdelete[MAX_VAR+1], rectotal[MAX_VAR+1];
/* method, problem names */
char method[MAX_ENTRY], prob[MAX_ENTRY], problem[MAX_ENTRY];
/* number of processors and variables */
int nproc, nvar;
/* reading file lines */
char lineread[MAXLEN];
/* tokens obtained from records */
char token[MAX_ENTRY][MAX_ENTRY];
int nTokens;

/********* subroutines ********/
int tokenize(char *lineread);
/*eject*/
/*********** main program **********/

int main (int argc, char **argv) {

  int i, j;
  char percent[2];

  char logoneprocfile[MAX_ENTRY], 
       logparallelfile[MAX_ENTRY], 
       outputfile[MAX_ENTRY],
       headfile[MAX_ENTRY],
       tailfile[MAX_ENTRY];
  char temponeprocfile[MAX_ENTRY],
       tempparallelfile[MAX_ENTRY];

  FILE *logoneprocfil;
  FILE *logparallelfil;
  FILE *outputfil;
  FILE *headfil;
  FILE *tailfil;

  FILE *temponeprocfil;
  FILE *tempparallelfil;
/*eject*/

  if (argc != 8) {
    printf("\n Usage: ./extractevalcycle <logoneprocfile> ");
    printf("\n                           <logparallelfile> ");
    printf("\n                           <outputfile>");
    printf("\n                           <headfile>");
    printf("\n                           <tailfile>");
    printf("\n                           <processors>");
    printf("\n                           <method>\n");
    exit(1);
  }
  strcpy(logoneprocfile,argv[1]);
  strcpy(logparallelfile,argv[2]);
  strcpy(outputfile,argv[3]);
  strcpy(headfile,argv[4]);
  strcpy(tailfile,argv[5]);
  nproc = atoi(argv[6]);
  strcpy(method,argv[7]);

  /* DEBUG begin: comment out above code involving argc */
  /*              and activate below */
/*
  strcpy(logoneprocfile,"logoneproctestfile");
  strcpy(logparallelfile,"log64proctestfile");
  strcpy(outputfile,"exoutputfile");
  strcpy(headfile,"exheadfile");
  strcpy(tailfile,"extailfile");
  nproc = 64;
  strcpy(method,"METHOD");
*/
  /* DEBUG end */

  /* initialization */
  strcpy(percent,"%");

  strcpy(temponeprocfile,"oneproc234567qwerty");
  strcpy(tempparallelfile,"parallel234567qwerty");

  for (i=1; i<=MAX_VAR; i++) {
    parallelcycle[i] = 0;
    paralleleval[i] = 0;
    oneproceval[i] = 0;  
    recdelete[i] = 0;
    rectotal[i] = 0;
  }
/*eject*/
  /* open logoneprocfile */
  if ((logoneprocfil = fopen(logoneprocfile,"r")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
            logoneprocfile);
     exit(1);
  }
  /* open logparallelfile */
  if ((logparallelfil = fopen(logparallelfile,"r")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
            logparallelfile);
     exit(1);
  }
  /* open outputfile */
  if ((outputfil = fopen(outputfile,"w")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
            outputfile);
     exit(1);
  }
  /* open headfile */
  if ((headfil = fopen(headfile,"w")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
            headfile);
     exit(1);
  }
  /* open tailfile */
  if ((tailfil = fopen(tailfile,"w")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
            tailfile);
     exit(1);
  }
  /* open temporary files */
  if ((temponeprocfil = fopen(temponeprocfile,"w")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
            temponeprocfile);
     exit(1);
  }  
  if ((tempparallelfil = fopen(tempparallelfile,"w")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
             tempparallelfile);
     exit(1);
  } 
/*eject*/
  /* create temponeprocfile */
  while (fgets(lineread,MAXLEN,logoneprocfil) != NULL) { 
    /* search for " caution: minimization" */
    if ((strncmp(lineread,"       phase 1 =",16) == 0) ||
        (strncmp(lineread," output in ",11) == 0)) {
      fprintf(temponeprocfil,"%s",lineread);
    }
  }
  fprintf(temponeprocfil,"ENDATA\n");
  fclose(temponeprocfil);
  /* create tempparallelfile */
  while (fgets(lineread,MAXLEN,logparallelfil) != NULL) { 
    /* search for " caution: minimization" */
    if ((strncmp(lineread,"       phase 1 =",16) == 0) ||
        (strncmp(lineread," output in ",11) == 0)) { 
      fprintf(tempparallelfil,"%s",lineread);
    }
  }
  fprintf(tempparallelfil,"ENDATA\n");
  fclose(tempparallelfil); 

  /* reopen temporary files */
  if ((temponeprocfil = fopen(temponeprocfile,"r")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
            temponeprocfile);
     exit(1);
  }  
  if ((tempparallelfil = fopen(tempparallelfile,"r")) == NULL) {
     printf("\n extractevalcycle: cannot open file %s\n",
             tempparallelfile);
     exit(1);
  }
/*eject*/
  /* process records of temporary files, each time reading */
  /* two records from either file */ 
  while (fgets(lineread,MAXLEN,temponeprocfil) != NULL) { 
                                                   /* while #1 */
    if (strncmp(lineread,"ENDATA",6) == 0) {
      /* have reached end of temponeprocfile */
      /* check that end of tempparallelfile is also reached */
      if (fgets(lineread,MAXLEN,tempparallelfil) == NULL) {
        printf("\n extractevalcyle: #1 unexpected end of file %s\n",
               temponeprocfile);
        exit(1);      
      }
      if (strncmp(lineread,"ENDATA",6) == 0) {
        break;
      } else {
        printf("\n extractevalcyle: #1 files %s and %s differ\n",
               temponeprocfile, tempparallelfile);
        exit(1);      
      }
    }
    /* get evaluation count */
    sscanf(lineread," phase 1 = %d",&oneeval);

    if (fgets(lineread,MAXLEN,temponeprocfil) == NULL) {
      printf("\n extractevalcyle: #2 unexpected end of file %s\n",
             temponeprocfile);
      exit(1);      
    }
    /* get problem name */
    sscanf(lineread," output in %s",problem);
    /* eliminate ".params.multi" extension */
    i = strlen(problem);
    j = strlen(".params.multi");
    problem[i-j] = '\0';
   
    if (fgets(lineread,MAXLEN,tempparallelfil) == NULL) { 
      printf("\n extractevalcyle: #3 unexpected end of file %s\n",
               tempparallelfile);
        exit(1);      
    }
    /* get evaluation and cycle count */
    sscanf(lineread," phase 1 = %d %d",
                    &pareval, &parcycle);
             
    if (fgets(lineread,MAXLEN,tempparallelfil) == NULL) {
      printf("\n extractevalcyle: #3 unexpected end of file %s\n",
             tempparallelfile);
      exit(1);      
    }
    /* get problem name */
    sscanf(lineread," output in %s",prob);
    /* eliminate ".params.multi" extension */
    i = strlen(prob);
    j = strlen(".params.multi");
    prob[i-j] = '\0';
 
    /* check that prob[] and problem[] are identical */
    if (strcmp(prob, problem) != 0) {
      printf(
        "\n extractevalcycle: differing problem names %s and %s\n",
        prob, problem);
      exit(1);
    }
/*eject*/
    /* update counts */

    /* get number of variables from problem[] */
    for (i=strlen(problem)-1; i>=0; i--) {
      if (problem[i] == '_') {
        problem[i] = ' ';
        break;
      }
    }
    sscanf(problem,"%s %d", lineread, &nvar);

    /* increment rectotal */
    rectotal[nvar]++;
    rectotal[0]++;

    /* reduce evaluations by REDUCE_EVAL */
    oneeval -= REDUCE_EVAL;
    pareval -= REDUCE_EVAL;

    /* ignore case if too many evaluations */
    if ((oneeval >= MAX_ONEPROC_EVAL) ||
        (pareval >= MAX_PARALLEL_EVAL)) {
      /* increment recdelete */
      recdelete[nvar]++;
      recdelete[0]++;
      continue;
    }

    /* update parallelcycle[], paralleleval[], oneproceval[] */
    parallelcycle[nvar] += parcycle;
    parallelcycle[0] += parcycle;
    paralleleval[nvar] += pareval;
    paralleleval[0] += pareval;
    oneproceval[nvar] += oneeval;
    oneproceval[0] += oneeval;

  } /* end while #1 */

  if (strncmp(lineread,"ENDATA",6) != 0) {
    printf(
       "\n extractevalcycle: improper termination of while #1\n");
  }

  fclose(temponeprocfil);
  fclose(tempparallelfil);

  /* output statistics */

  fprintf(headfil,
    "\\begin{tabular}{|c|c|c|c|c|c|c|c|c|}\\hline\n");
  /* cases, single proc., parallel proc., efficiency */
  fprintf(headfil,"vars. & \\multicolumn{3}{|c|}{cases} & ");
  fprintf(headfil,"single proc. & ");
  fprintf(headfil,"\\multicolumn{2}{|c|}{parallel proc.} & ");
  fprintf(headfil,"\\multicolumn{2}{|c|}{efficiency} ");
  fprintf(headfil,"  \\\\\\hline\n");
  /* $n$, total $T$, used $U$, $U/T$, evals. $S$, */
  /* evals. $P$, cycs. $C$, $S/(nvar*C)$ , $P/(nar*C)$ */
  fprintf(headfil,"$n$ & $t$ total & $u$ used & $u/t$ & ");
  fprintf(headfil," $s$ evals. & $p$ evals. & ");
  fprintf(headfil," $c$ cycs. & $s/(%d\\cdot c)$ & $p/(%d*c)$ ",
                    nproc,nproc);
  fprintf(headfil,"  \\\\\\hline\n");
  fprintf(headfil,"\\hline\n");

  fprintf(outputfil,"\\multicolumn{9}{|c|}{%s} ",method);
  fprintf(outputfil,"  \\\\\\hline\n");
  for (i=0; i<=MAX_VAR; i++) {
    if (oneproceval[i] == 0) {
      /* no problem with i variables occurred */
      continue;
    }
    if (i == 0) {
      fprintf(outputfil,"all & ");
    } else {
      fprintf(outputfil," $%d$ & ",i);
    }
    fprintf(outputfil,
      "%d & %d & %d\\%s & %d & %d & %d & %d\\%s & %d\\%s ",
      rectotal[i], rectotal[i]-recdelete[i], 
      (100*(rectotal[i]-recdelete[i])+rectotal[i]/2)/
         rectotal[i], percent,
      oneproceval[i], paralleleval[i], parallelcycle[i],
      (100*oneproceval[i]+(nproc*parallelcycle[i])/2)/
         (nproc*parallelcycle[i]), percent,
      (100*paralleleval[i]+(nproc*parallelcycle[i])/2)/
         (nproc*parallelcycle[i]), percent );
    fprintf(outputfil,"  \\\\\\hline\n"); 
  }
  fprintf(outputfil,"\\hline\n");
  fprintf(tailfil,"\\end{tabular}\n");

  fclose(outputfil);
  fclose(headfil);
  fclose(tailfil);
  
  return 0;

}
/*eject*/
/**************************************************************
 * int tokenize(char *lineread): extract up to MAX_ENTRY
 * non-white-space strings from lineread[]
 * stops with error if a string has length >= MAX_ENTRY 
 * place strings into token[][];
 * defines nTokens = number of extracted tokens
 * process does not change lineread[]
 **************************************************************/
int tokenize(char *lineread) {

  int i, j;
  char saveread[MAXLEN];
  char *buffer;

  strcpy(saveread,lineread);

  /* strip off carriage return and whitespace */
  /* at end of the line */
  i = strlen(lineread) - 1;
  while (lineread[i]>=1 && lineread[i]<=32) {
    lineread[i] = '\0';
    i--;
  }
/*eject*/
  for (j=0; j<MAX_ENTRY; j++) {

    if (j == 0) {  
      buffer = strtok(saveread," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }

    if (buffer == NULL) {
      break;
    }

    if (strlen(buffer) >= MAX_ENTRY) {
      printf(
      "\n tokenize: lineread = %s contains too-large\n", lineread);
      printf(
      "\n token = %s with strlen >= %d \n", buffer, MAX_ENTRY);
      exit(1);
    }

    strcpy(token[j],buffer);

  } /* end for j */

  nTokens = j;

  return nTokens;

}

/*************** last record of extractevalcycle.c *****************/
