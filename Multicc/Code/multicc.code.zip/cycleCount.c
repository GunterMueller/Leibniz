/* Routine for counting cycles of parallel processors  */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"
/************************************************************
 *  subroutines in this file:
 *       void beginCycleCount(int k)
 *       void increaseCycleCount(int k)
 *       int  readCycleCount()
 ************************************************************/
/*eject*/
/*************************************************************
 *  void beginCycleCount(int k):
 *      initialize cycleCount file in gOption.tempdir with value k
 *************************************************************/
void beginCycleCount(int k) {

  char cyclefile[MAX_ENTRY];
  FILE *cyclefil;

  sprintf(cyclefile,"%s/%s.cycleCount",gOption.tempdir,problemName);
  if ((cyclefil = fopen(cyclefile,"w")) == NULL) {
    printf("\n beginCycleCount: cannot open cycle file %s", cyclefile);
    exit(1);
  }

  fprintf(cyclefil,"%d",k);
  fclose(cyclefil);

  return;

  }
/*eject*/
/*************************************************************
 *  void increaseCycleCount(int k):
 *      increase cycle count in cycleCount file by k
 *************************************************************/
void increaseCycleCount(int k) {

  int n;

  char cyclefile[MAX_ENTRY];
  FILE *cyclefil;

  sprintf(cyclefile,"%s/%s.cycleCount",gOption.tempdir,problemName);
  if ((cyclefil = fopen(cyclefile,"r")) == NULL) {
    printf("\n readCycleCount: case 1, cannot open cycle file %s", 
           cyclefile);
    exit(1);
  }

  fscanf(cyclefil,"%d",&n);
  fclose(cyclefil);

  if ((cyclefil = fopen(cyclefile,"w")) == NULL) {
    printf("\n readCycleCount: case 2, cannot open cycle file %s", 
           cyclefile);
    exit(1);
  }

  fprintf(cyclefil,"%d",n+k);
  fclose(cyclefil);

return;

}
/*eject*/
/*************************************************************
 *  void readCycleCount():
 *      read cycle count of cycleCount file
 *************************************************************/
int readCycleCount() {

  int n;

  char cyclefile[MAX_ENTRY];
  FILE *cyclefil;

  sprintf(cyclefile,"%s/%s.cycleCount",gOption.tempdir,problemName);
  if ((cyclefil = fopen(cyclefile,"r")) == NULL) {
    printf("\n readCycleCount: cannot open cycle file %s", cyclefile);
    exit(1);
  }

  fscanf(cyclefil,"%d",&n);
  fclose(cyclefil);

  return n;

}

/****** last record of cycleCount.c *****************************/
