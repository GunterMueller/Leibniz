/* halton and related processes */
# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "dencon.h"
# include "primes.h"
/**************************************************************
 *
 * subroutines in this file:
 *       void halton(int index,double *xx)
 *       void gram_schmidt()
 *       void gen_base(double *d)
 **************************************************************/
/*eject*/
/**************************************************************
 *   void halton(): halton vector generator        
 **************************************************************/
void halton(int index,double *xx) {

  int i, n;
  double x[MAX_VARIABLE+1];
  int base[MAX_VARIABLE+1];

  /* variables for permutation computation */
  int jvec[1000+1], k, nseq;
  double fvec[1000+1];
  int permuteFlag = FALSE; 
        /* = TRUE: Halton with permutation; cannot use now, */
        /*         must still add permutation code below */
        /* = FALSE: Halton without permutation */


/*eject*/
  /* define n */
  n = nreal;


  if (n == 1) {
    xx[1] = 1.0;
    return;
  }

  for (i=1; i<=n; i++) {
    base[i] = primes[i];
    x[i]    = 0.0;

    /* permutation code */
    fvec[1] = 1.0/(double)base[i];
    jvec[1] = index;
    nseq = 0;
    while (1) {
      nseq++;
      jvec[nseq+1] = jvec[nseq]/base[i];
      if (jvec[nseq+1] == 0) {
        break;
      }
      fvec[nseq+1] = fvec[nseq] / (double)base[i];      
    }

    if (permuteFlag == FALSE) {
      /* Halton without permutation */
      for (k=1; k<=nseq; k++) {
        x[i] += fvec[k]*(double)(jvec[k]%base[i]);
      }
    } else {
      /* Halton with permutation */
      /* must add <permuted k> below before code can be used */
      /* for (k=1; k<=nseq; k++) {
        x[i] += fvec[k]*(double)(jvec[<permuted k>]%base[i]);
      } */
      /* warning message */ printf("\n halton: missing permutation");
                            exit(1);
    }
/*eject*/
    /* original code, replaced by permutation code above */
    /* x[i]    = 0.0;
    f       = 1.0/(double)base[i];
    j       = index;
    while (j > 0) {
       x[i] += f*(double)(j%base[i]);
       j    = j / base[i];
       f    = f / (double)base[i];
     } */ 

  } /* end for i */

  if (iprint >= 1) {
    printf("\n Halton index = %d\n       x[] = ",index);
    for (i=1; i<=n; i++) {
      printf("%4.2f ",x[i]);
    }
    printf("\n");
  }
  
  for (i=1; i<=n; i++) {
    xx[i] = x[i];
  }

  return;
}
/*eject*/
/**************************************************************
 *   void gen_base(): generate base from direction d 
 *       input: d vector
 *       output: H[][] matrix       
 **************************************************************/
void gen_base(double *d) {

  int n;
  int i, ind, j;
  double f;
 
  /* define n */
  n = nreal;

  f = -INF;
  ind = 0;
  for (i=1; i<=n; i++) {
    if (f < fabs(d[i])) {
      f = fabs(d[i]);
      ind = i;
    }
  }  

  for (i=1; i<=n; i++) {
    for (j=1; j<=n; j++) {
      if (j == 1) {
        H[i][j] = d[i];
      } else {
        H[i][j] = 0.0;
      }
    }
  }

  for (i=2; i<=ind; i++) {
    H[i-1][i] = 1.0;
  }
  for (i=ind+1; i<=n; i++) {
    H[i][i] = 1.0;
  }
/*eject*/
  /* debug */
  /* printf("\n gen_base ind = %d",ind);
  for (i=1; i<=n; i++) {
    printf("\n H[%d,.] = ",i);
    for (j=1; j<=n; j++) {
      printf("%g ",H[i][j]);
    }
  } */

  return;

}
/*eject*/
/**************************************************************
 *   void gram_schmidt(): Gram-Schmidt orthogonalization
 *     input: H[][] matrix
 *     output: revised H[][] matrix        
 **************************************************************/
void gram_schmidt() {
  int i, j, k, n;
  double proj[MAX_VARIABLE+1];  double dotij, dotj2;

  /* define n */
  n = nreal;

  for (i=2; i<=n; i++) {
    for (j=1; j<=n; j++) {
      proj[j] = 0.0;
    }

    for (j=1; j<=i-1; j++) {
      /* proj = proj + dot_product(H(:,i),H(:,j))/dot_product(H(:,j),
                H(:,j))*H(:,j) fortran formula */
      dotij = 0.0;
      dotj2 = 0.0;
      for (k=1; k<=n; k++) {
        dotij += H[k][i]*H[k][j];
        dotj2 += H[k][j]*H[k][j];
      }
      for (k=1; k<=n; k++) {
        proj[k] += dotij/dotj2 *H[k][j];
      }
    }
    for (k=1; k<=n; k++) {
      H[k][i] -= proj[k];
    }
  }
/*eject*/
  /* debug */
  /*printf("\n gram_schmidt");
  for (i=1; i<=n; i++) {
    printf("\n H[%d,.] = ",i);
    for (j=1; j<=n; j++) {
      printf("%g ",H[i][j]);
    }
  } */

  for (j=1; j<=n; j++) {
    /* H(:,j) = H(:,j)/dsqrt(dot_product(H(:,j),H(:,j))) in fortran */
    dotj2 = 0;
    for (k=1; k<=n; k++) {
        dotj2 += H[k][j]*H[k][j];
    }
    for (k=1; k<=n; k++) {
      H[k][j] /= sqrt(dotj2);
    }
  }

  return;

}
/***** last record of halton.c *********/
