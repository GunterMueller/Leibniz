/* Routine for evaluating with parallel processors  */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/wait.h>
# include <signal.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"
/************************************************************
 *  subroutines in this file:
 *       void evaluate_parallelCandidate(char *method, int kflag)
 *       void parallelQueryBlackbox()
 *       void parallelReadBlackbox(int p, int *begin, int *size)
 *       void parallelTest_problem()
 *       void parallelWriteInOutbox(int *begin, int *size)
 ************************************************************/
/*eject*/
/*************************************************************
 * evaluate_parallelCandidate(char *method, int kflag): 
 *      evaluate objective functions and constraints 
 *      for parallelCandidate[]
 *      input:  method = "dencon", "denpar", "gencc", "nsga",
 *                       "nomad", "seqpen"
 *              kflag = TRUE or FALSE, to be assigned to all
 *                      parallelCandidate[].keepflag
 *              parallelCandidate[].xalue[] vectors
 *      output: parallelCandidate[].obj[]
 *              parallelCandidate[].constr[]
 *              parallelCandidate[].keepflag = kflag
 *      caution: obj[] values are output only for j indices
 *               with objfactor[j] != 0 and are indexed by
 *               consecutive indices j = 0, 1, ...
 *               constr[] values and constr_violation values
 *               are correct for method specified in input
 *      caution: method does not process corners; they must be
 *               handled within black box
 *************************************************************/
void evaluate_parallelCandidate(char *method, int kflag) {

  int j, juse, n;

  juse = 0; /* to suppress compiler warning */

  /* use nobjEvaluate for evaluation of xvalue */
  nobj = nobjEvaluate;

  /* compute obj and constr values */
  if (strcmp(gOption.input,"NOINPUTFILE") != 0) {
    parallelQueryBlackbox();
  } else {
    parallelTest_problem();
  }
  /* have obj and constr for all parallelCandidate[] according */
  /* to nsga/gencc convention */
/*eject*/
  /* if single obj minimization, that is,  */
  /* if method != "nsga" and != "gencc", */
  /* store parallelCandidate[] in singleminout file */
  if ((strncmp(method,"nsga",4) != 0) &&
      (strncmp(method,"gencc",5) != 0) &&
      (gOption.singleminout == TRUE)) {
    fprintf(singleminoutfil,"\n## cycle");
    for (n=0; n<nParallelCandidates; n++) {
      fprintf(singleminoutfil,"\n");
      for (j=0; j<nobjEvaluate; j++) {
        fprintf(singleminoutfil,"%g ", 
                parallelCandidate[n].obj[j]);
      }
      for (j=0; j<ncon; j++) {
        fprintf(singleminoutfil,"%g ", 
                parallelCandidate[n].constr[j]);
      }
      for (j=0; j<nreal; j++) {
        fprintf(singleminoutfil,"%g ", 
                parallelCandidate[n].xvalue[j]);
      }
    }
  }
/*eject*/

  /* for each parallelCandidate[]:
   *   apply objrange weights if applicable
   *   adjust obj according to objfactor
   *   correct constr according to specified method and
   *     gOption.ignoreconstraint
   *   compute constr_violation
   */
  for (n=0; n<nParallelCandidates; n++) {
    if ((gOption.objrange == TRUE) && (nobjSolve == 1)) {
      /* compute weighted sum of objs */
      /* for single function minimization */
      /* find index juse of single function */
      for (j=0; j<nobj; j++) {
        if (objFactor[j] != 0.0) {
          juse = j;
          break;
        }  
      }
      /* compute weighted sum for positive objrange values */
      /* factor WEIGHTED_SUM_FACTOR gives weight */
      /* to obj[juse] versus obj[j] */
      if (objRange[juse] > 0.0) {
        for (j=0; j<nobj; j++) {
          if ((j != juse) && (objRange[j] > 0.0)) {
            parallelCandidate[n].obj[juse] += WEIGHTED_SUM_FACTOR *
                         (objRange[juse]/objRange[j]) * 
                         parallelCandidate[n].obj[j];
          }  
        }
      }
    }
/*eject*/
    /* if obj factors are used, apply them to obj[] */
    /* and eliminate cases with factor = 0 */
    if (gOption.objfactor == TRUE) {
      juse = 0;
      for (j=0; j<nobj; j++) {
        if (objFactor[j] != 0.0) {
          parallelCandidate[n].obj[juse] = 
          parallelCandidate[n].obj[j] * objFactor[j];
          juse++;
        }
      }
      if (juse != nobjSolve) {
        printf("\n evaluate_parallelCandidate:");
        printf(" nobjSolve = %d != juse = %d", nobjSolve, juse);
        exit(1);
      }
    }

    /* ignoreconstraint option */
    if (gOption.ignoreconstraint == TRUE) {
      for (j=0; j<ncon; j++) {
        parallelCandidate[n].constr[j] = 0.0;
      }
    }

    /* compute constraint violation */
    parallelCandidate[n].constr_violation = 0.0;
    for (j=0; j<ncon; j++) {
      if (parallelCandidate[n].constr[j]<0.0) {
        parallelCandidate[n].constr_violation += 
          parallelCandidate[n].constr[j];
      }
    }
/*eject*/
    if ((strcmp(method,"dencon") == 0) ||
        (strcmp(method,"denpar") == 0) ||
        (strcmp(method,"nomad") == 0)  ||
        (strcmp(method,"seqpen") == 0)) {
      /* dencon/denpar/nomad/seqpen assume constraints <= 0
       * while gencc/nsga assume constraints >= 0
       * hence change the sign of constraint values
       * and of constraint_violation since they were
       * computed according to the gencc/nsga convention 
       */
      for (j=0; j<ncon; j++) {
        parallelCandidate[n].constr[j] *= -1.0;
      }
      parallelCandidate[n].constr_violation *= -1.0;
    }

    /* assign keepFlag */
    parallelCandidate[n].keepFlag = kflag;

  } /* end for n */


  /* restore nobj = nobjSolve for solution process */
  nobj = nobjSolve;

  return;

}
/*eject*/
/*************************************************************
 * parallelQueryBlackbox(): 
 *      evaluate objective functions and constraints 
 *      for parallelCandidate[] using queryBlackbox()
 *************************************************************/
void parallelQueryBlackbox() {

  int flag, p, pp, terminationflag;

  pid_t pid, childpid[MAX_PROC];

  int begin[MAX_PROC];
  int size[MAX_PROC];
  /* begin[p] = first index of candidate[] handled by processor p */
  /* size[p] = number of candidate[] cases handled by processor p */

  int actflag[MAX_PROC];
  /* actflag[p] = TRUE if processor p is running */
  /*            = FALSE else */

  char procoutfile[MAX_ENTRY];
  FILE *procoutfil;
  char tempoutfile[MAX_ENTRY];        

  char cmnd[MAX_ENTRY];
  char shortcmnd[MAX_ENTRY];

  time_t tstart;

  pid_t kill(pid_t pid, int sig);

  /* define outbox file in temp dir */
  sprintf(tempoutfile,"%s/%s",
                      gOption.tempdir,
                      gOption.outbox);

  /* create inbox files in processor directories */
  /* from parallelCandidate[] cases */
  parallelWriteInOutbox(begin,size);
/*eject*/
  /* launch all processor programs */
  /* initialize actflag[] */
  for (p=0; p<nProcessors; p++) {
    actflag[p] = FALSE;
  }
  for (p=0; p<nProcessors; p++) { /* for p=0 #1 */
    if (size[p] == 0) {
      break;
    }
    if (strcmp(processor[p].machine,"home") == 0) {
      /* execute runprocess.d.sh using fork() and child process */
      if ((pid = fork()) < 0) {
        printf("\n parallelQueryBlackbox: fork() failed");
        for (pp=0; pp<p; pp++) {
          printf("\n  childpid[%d] = %d",pp,childpid[pp]);
        }
        printf("\n  childpid[%d] = %d\n",p,pid);
        exit(1);
      } else if (pid == 0) { /* for child process */
        sprintf(cmnd,"%s/runprocess.%d.sh",
                     processor[p].path, p+1);
        sprintf(shortcmnd,"runprocess.%d.sh",p+1);
        if (execl(cmnd,shortcmnd,0) == -1) {
          /* value -1 means error encountered by execl() */
          /* if value != -1, execl() has been successful */
          /* and thus has terminated child process */
          printf("\n parallelQueryBlackbox: exec(%s,%s,0) error",
                 cmnd,shortcmnd); 
          exit(1); 
        }  
      }
      childpid[p] = pid; /* store pid for waitpid() below */
/*eject*/
    } else {
      /* execute runprocess.d.sh using ssh on processor p */
      sprintf(cmnd,"ssh -q %s \"nohup %s/runprocess.%d.sh \"",
                   processor[p].machine,
                   processor[p].path, p+1);
      if (system(cmnd) != 0) {
        printf(
          "\n parallelQueryBlackbox: processor command '%s' fails",
          cmnd);
        printf(
          "\n likely cause: error in black box program, or");
        printf(
          "\n max processing time = %d (sec) was reached",
          gOption.maxproctime);
        exit(1);               
      }
    }
    actflag[p] = TRUE;
  } /* end for p=0 #1 */
/*eject*/
  /* check for termination of each processor */
  /* limit total time by gOption.maxproctime */

  /* save start time */
  tstart = time(NULL);
  while (((int)(time(NULL) - tstart) ) < gOption.maxproctime) {

    /* check each processor for termination */
    terminationflag = TRUE; /* means: all processors have stopped */
    for (p=0; p<nProcessors; p++) { /* for p=0 #2 */
      if (size[p] == 0) {
        break;
      }
      if (actflag[p] == TRUE) {
        /* try to copy outbox file to tempdir */
        if (strcmp(processor[p].machine,"home") == 0) {
          sprintf(procoutfile,"%s/%s",
                       processor[p].path,
                       gOption.outbox);
          if ((procoutfil = fopen(procoutfile,"r")) == NULL) {
            flag = FALSE; /* file does not exist, so */
                          /* processor is not yet done */
          } else {
            /* file exists, move it to tempdir */
            flag = TRUE;
            fclose(procoutfil);
            sprintf(cmnd,"mv -f %s %s",procoutfile,tempoutfile);
            if (system(cmnd) != 0) {
              printf(
            "\n parallelQueryBlackbox: cannot move existing file %s",
              procoutfile);
              exit(1);           
            }
            /* remove child process; parent does not have to */
            /* wait since we know that child process has stopped */
            waitpid(childpid[p], NULL, 0);     
          }             
/*eject*/
        } else {
          /* attempt copy with 'scp' */
          /* option -q means 'quiet', thus no screen output */
          sprintf(cmnd,"scp -q %s:%s/%s %s/%s",
                       processor[p].machine,
                       processor[p].path,
                       gOption.outbox,
                       gOption.tempdir,
                       gOption.outbox);
          if (system(cmnd) == 0) {
            flag = TRUE;
          } else {
            flag = FALSE;
          }
        } /* end if strcmp(processor[p].machine,"home") == 0, else */
        if (flag == TRUE) {
          /* outbox file exists and has been copied into tempdir */
          /* read outbox obj and constr results and place into */
          /* parallelCandidate[] */
          parallelReadOutbox(p,begin,size);
          /* remove tempoutfile as safeguard */
          sprintf(cmnd,"rm -f %s",tempoutfile);
          system(cmnd);         
          /* declare processor p to have stopped */
          actflag[p] = FALSE;
        } else {
          terminationflag = FALSE;
        }
      } /* end if actflag[p] == TRUE */
    } /* end for p=0 #2 */                
/*eject*/
    if (terminationflag == TRUE) {
      /* all processors have terminated */
      /* increase cycle count by size[0] = number of records */
      /* evaluated by processor p = 0 */
      increaseCycleCount(size[0]);
      return;
    }

    /* start another iteration to check for completion */

  } /* end while */

  /* max time has been exceeded */  
  printf("\n parallelQueryBlackbox: stop black box evaluations, ");
  printf("max proc time = %d (sec) has been exceeded; ",
         gOption.maxproctime);
  for (p=0; p<nProcessors; p++) {
    if (size[p] == 0) {
      break;
    }
    if (strcmp(processor[p].machine,"home") == 0) {
      if  (actflag[p] == TRUE) {
        /* process p is still running, kill it */
        printf(
        "\n process with pid = %d is still running, kill it now",
               childpid[p]);
        kill(childpid[p],SIGKILL);
      } else {
        /* process has terminated */
        printf(
        "\n process with pid = %d did terminate, take no action",
               childpid[p]);
      }
    }
  }
  exit(1);
}
/*eject*/
/*************************************************************
 * parallelReadOutbox(int p, int *begin, int *size): 
 *      read outbox file of processor p 
 *      in gOption.tempdir/problemName  
 *      extract obj and constr information and place into
 *      parallelCandidate[]
 *************************************************************/
void parallelReadOutbox(int p, int *begin, int *size) {

  int i, j, n;

  char lineread[MAXLEN];

  char outboxfile[MAX_ENTRY];
  FILE *outboxfil;

  sprintf(outboxfile,"%s/%s",gOption.tempdir,gOption.outbox);
/*eject*/
  /* read outbox file and place obj and constraint values into */
  /* objective[] and constraint[] structures using external */
  /* definitions for objective direction and constraint type */
  if ((outboxfil = fopen(outboxfile,"r")) == NULL) {
    printf(
    "\n parallelReadOutbox: cannot open completed output file %s",
           outboxfile);
    exit(1);
  }

  /* initialize index for parallelCandidate[] */
  n = begin[p]-1;

  /* read 'WARNING', or obtain obj and constr values */
  while (fgets(lineread,MAXLEN,outboxfil) != NULL) {

    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0'; 
      i--;
    }
    /* skip over empty or '#" lines */
    if ((lineread[0] == '\0') || (lineread[0] == '#')) {
      continue;
    }
    if (strncmp(lineread,"WARNING",7) == 0) {
      /* black box failed */
      printf(
         "\n parallelReadOutbox: black box failed, generation = %d",
         generationCount);
      exit(1);
    }
/*eject*/
    /* have nonempty, noncomment line with obj and constr values */
    /* increment index for parallelCandidate[] */
    n++;
    /* increment evaluation count */
    evaluationCount++;
    /* interpret lineread */
    tokenize(lineread);
    if (nTokens < nobj+ncon+nreal) {
      printf("\n parallelReadOutbox: lineread = %s has %d <",
             lineread, nTokens);
      printf(" nobj+ncon+nreal = %d+%d+%d = %d entries",
             nobj, ncon, nreal, nobj+ncon+nreal);
      exit(1);
    }

    /* store obj and constr values in objective[] and */
    /* constraint[] structures, which always are used for */
    /* external values */ 
    /* objective values */
    for (j=0; j<nobj; j++) {
      objective[j].value = atof(token[j]);
    }     
    /* constraint values */
    for (j=0; j<ncon; j++) {
      constraint[j].value = atof(token[j+nobj]);
    }
/*eject*/
    /* define parallelCandidate[n].obj[] and */
    /* parallelCandidate[n].constr[] */
    /* from objective[] and constraint[] */
    /* structures so that parallelCandidate[n] follows gencc/nsga */
    /* convention, where obj is minimized and constraints >= 0 */
    for (j=0; j<nobj; j++) {
      if (strcmp(objective[j].direction,"min") == 0) {
        parallelCandidate[n].obj[j] = objective[j].value;
      } else {
        parallelCandidate[n].obj[j] = -objective[j].value;
      }
    }
    for (j=0; j<ncon; j++) {
      if (strcmp(constraint[j].inequality,"<=") == 0) {
        parallelCandidate[n].constr[j] = 
              constraint[j].rhs - constraint[j].value;
      } else {
        parallelCandidate[n].constr[j] = 
              -constraint[j].rhs + constraint[j].value;
      }
      /* declare constr[j] within constrTolerance[j] as feasible */
      if ((parallelCandidate[n].constr[j] < 0) && 
          (parallelCandidate[n].constr[j] >= -constrTolerance[j])) {
        parallelCandidate[n].constr[j] = 0;
      }
    }

  } /* end while */

  if (n != begin[p]+size[p]-1) {
    printf(
      "\n parallelReadOutbox: process p = %d created outbox file ",
      p);
    printf("with %d records, ",n-begin[p]+1);
    printf("but should have size[p] = %d records",size[p]);
    exit(1);
  }

  fclose(outboxfil);

  return;

}

/*eject*/
/*************************************************************
 * parallelTest_problem(): 
 *      evaluate objective functions and constraints 
 *      for parallelCandidate[] using test_problem()
 *************************************************************/
void parallelTest_problem() {

  int n, nc;

  for (n=0; n<nParallelCandidates; n++) {
    test_problem(TRUE,problemName,
                 parallelCandidate[n].xvalue,
                 parallelCandidate[n].obj,
                 parallelCandidate[n].constr);
    /* first parameter usage:
     *   TRUE: compute obj, constr values
     *   FALSE: define nreal, nbin, nobj, ncon,
     *                 min_realvar[], max_realvar[]
     */
  }

  /* increment cycle count */
  if (nParallelCandidates%nProcessors == 0) {
    nc = nParallelCandidates/nProcessors;
  } else {
    nc = nParallelCandidates/nProcessors + 1;
  }
  increaseCycleCount(nc);

  return;

}
/*eject*/
/*************************************************************
 * parallelWriteInOutbox(int *begin, int *size): 
 *      write inbox files for processors in 
 *      gOption.tempdir/problemName and copy them into processor
 *      directories
 *      remove processor outbox file if present
 *************************************************************/
void parallelWriteInOutbox(int *begin, int *size) {

  int j, n, p;

  char cmnd[MAX_ENTRY];

  char inboxfile[MAX_ENTRY];
  char outboxfile[MAX_ENTRY];
  FILE *inboxfil;
  FILE *outboxfil;

  /* determine size[] of processor inbox files */
  /* to get even load distribution */
  /* first assign nParallelCandidates/nProcessors cases */
  /* to each processor */
  for (p=0; p<nProcessors; p++) {
    size[p] = nParallelCandidates/nProcessors;
  }
  /* then distribute remaining nParallelCandidates%nProcessors */
  /* cases among processors */
  for (p=0; p<nParallelCandidates%nProcessors; p++) {
    size[p]++;
  }
/*eject*/
  /* define begin[] */
  begin[0] = 0;
  for (p=1; p<nProcessors; p++) {
    begin[p] = begin[p-1] + size[p-1];
  }

  /* define file names */
  sprintf(inboxfile,"%s/%s", gOption.tempdir,gOption.inbox);
  sprintf(outboxfile,"%s/%s",gOption.tempdir,gOption.outbox);

  /* define outbox file with warning message */
  if ((outboxfil = fopen(outboxfile,"w")) == NULL) {
    printf(
       "\n parallelWriteInOutbox: cannot open initial outbox file %s",
       outboxfile);
    exit(1);
  } 
  fprintf(outboxfil,"WARNING no results in this file");
  fclose(outboxfil);
/*eject*/

  /* for each processor: */
  /*   create inbox file in gOption.tempdir/problemName */
  /*   move inbox and copy outbox files into processor directory */ 
  for (p=0; p<nProcessors; p++) {

    if (size[p] == 0) {
      /* have handled all cases */
      break;
    }
    /* open inbox file */
    if ((inboxfil = fopen(inboxfile,"w")) == NULL) {
      printf("\n parallelWriteInOutbox: cannot open input file %s",
             inboxfile);
      exit(1);
    }
    /* write applicable parallelCandidate[].xvalue[] cases */
   for (n=begin[p]; n<begin[p]+size[p]; n++) {    
     for (j=0; j<nreal; j++) {
        fprintf(inboxfil,"%g\t",parallelCandidate[n].xvalue[j]);
      }
      fprintf(inboxfil,"\n");
    }
    fclose(inboxfil);
/*eject*/
    /* copy inbox and move outbox files into processor directory */
    /* caution: outbox file in processor directory */
    /*          has .temp suffix */
    if (strcmp(processor[p].machine,"home") == 0) {
      /* inbox: move with 'mv' */
      sprintf(cmnd,"mv -f %s/%s %s/%s",
                   gOption.tempdir,
                   gOption.inbox,                   
                   processor[p].path,
                   gOption.inbox); 
    } else {
      /* inbox: copy with 'scp' */
      sprintf(cmnd,"scp -q %s/%s %s:%s/%s",
                   gOption.tempdir,
                   gOption.inbox,
                   processor[p].machine,
                   processor[p].path,
                   gOption.inbox);
    }
    if (system(cmnd) != 0) {
      printf(
       "\n parallelWriteInOutbox: command '%s' fails for inbox",
       cmnd);
      exit(1);               
    }
/*eject*/
    if (strcmp(processor[p].machine,"home") == 0) {
      /* outbox: copy with 'cp' */
      /* do not use 'mv' since file is used repeatedly */
      sprintf(cmnd,"cp %s/%s %s/%s.temp",
                   gOption.tempdir,
                   gOption.outbox,                   
                   processor[p].path,
                   gOption.outbox); 
    } else {
      /* outbox: copy with 'scp' */
      sprintf(cmnd,"scp -q %s/%s %s:%s/%s.temp",
                 gOption.tempdir,
                 gOption.outbox,
                 processor[p].machine,
                 processor[p].path,
                 gOption.outbox);
    }
    if (system(cmnd) != 0) {
      printf(
      "\n parallelWriteInOutbox: command %s fails for outbox, case 1",
        cmnd);
      exit(1);               
    }
/*eject*/
    /* remove outbox from processor directory if present */
    if (strcmp(processor[p].machine,"home") == 0) {
      /* use 'rm' */
      sprintf(cmnd,"rm -f %s/%s",                  
                   processor[p].path,
                   gOption.outbox); 
    } else {
      /* execute remove.sh using ssh on processor p */
      sprintf(cmnd,"ssh -q %s \"nohup %s/removebox.sh \"",
                   processor[p].machine,
                   processor[p].path);
    }
    if (system(cmnd) != 0) {
      printf(
      "\n parallelWriteInOutbox: command %s fails for outbox, case 2",
        cmnd);
      exit(1);               
    }

  } /* end for p */
 
  return;

}
/***** last record of eval.parallel.c ***********/
