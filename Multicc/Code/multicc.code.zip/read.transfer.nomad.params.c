/* define and read routines for nomad parameter file */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *   void readTransferNomadParams();
 ****************************************************************/
/*eject*/
/**************************************************************
 * void readTransferNomadParams(char *name):
 * read parameter file for nomad execution
 **************************************************************/
void readTransferNomadParams() {

  int j; 
  char lineread[MAXLEN];
  char paramsfile[MAX_ENTRY];
  
  FILE *paramsfil;

  sprintf(paramsfile,"transfer.nomad.params");
  if ((paramsfil = fopen(paramsfile,"r")) == NULL) {
    printf(
    "\n readTransferNomadParams: cannot open parameter file %s",
        paramsfile);
    exit(1);
  }

  /* basic parameters */

  if (fgets(lineread,MAXLEN,paramsfil) == NULL) {
    printf(
    "\n readTransferNomadParams: unexpected empty file %s, case 1",
      paramsfile);
    exit(1);
  }
/*eject*/
  sscanf(lineread,
"problemName = %s , nreal = %d , nint = %d , nobjEvaluate = %d , nobjSolve = %d , ncon = %d , nCorners = %d , objfactor = %d , objrange = %d , stopcriterion = %s , input = %s , initsol = %s , output = %s , params = %s , singleminout = %d ",
   problemName, &nreal, &nint, &nobjEvaluate, &nobjSolve, 
   &ncon, &nCorners, &gOption.objfactor, &gOption.objrange,
   gOption.stopcriterion, gOption.input, gOption.initsol,
   gOption.output, gOption.params, &gOption.singleminout);

  if (fgets(lineread,MAXLEN,paramsfil) == NULL) {
    printf(
    "\n readTransferNomadParams: unexpected empty file %s, case 2",
      paramsfile);
    exit(1);
  }
  sscanf(lineread,
"blackbox = %s , inbox = %s , outbox = %s , processor = %s , maxproctime = %d , leibnizpath = %s , nomadpath = %s , tempdir = %s , ignoreconstraint = %d , nObjFactors = %d ",
   gOption.blackbox, gOption.inbox, gOption.outbox, 
   gOption.processor, &gOption.maxproctime,
   gOption.leibnizpath, gOption.nomadpath, gOption.tempdir,
   &gOption.ignoreconstraint, &nObjFactors);
/*eject*/
  /* obj factors and ranges */
  for (j=0; j<nobjEvaluate; j++) {
    if (fgets(lineread,MAXLEN,paramsfil) == NULL) {
      printf(
    "\n readTransferNomadParams: unexpected end of file %s, obj %d",
      paramsfile, j);
      exit(1);
    }    
    sscanf(lineread,"%lf  %lf", &objFactor[j], &objRange[j]);
  }
  /* constraint tolerances */
  for (j=0; j<ncon; j++) {
    if (fgets(lineread,MAXLEN,paramsfil) == NULL) {
      printf("\n readTransferNomadParams: unexpected end of file %s,",
             paramsfile);
      printf(" constraint %d", j);
      exit(1);
    }    
    sscanf(lineread,"%lf", &constrTolerance[j]);
  }
  nConstrTolerances = ncon;

  /* Caution: the above tolerance values originally were
  /* defined by multicc arguments, or by the params file, */
  /* or by default values */

  /* however, no matter how the values were defined, */
  /* we must make sure that they are not overlaid */
  /* by subsequent reading of the parameter file */

  /* to this end, we set gOption.constrtolerance = TRUE here, */
  /* which is interpreted during reading of the params file as */
  /* follows: */
  /*     the constraint tolerances have been defined */
  /*     by multicc arguments and are not to be changed by values */
  /*     in the parameter file or by default values */
  gOption.constrtolerance = TRUE;

  fclose(paramsfil);

  return;

}
/*********** last record of read.transfer.nomad.params.c *********/
