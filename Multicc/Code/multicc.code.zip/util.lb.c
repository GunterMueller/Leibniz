/* Utility routines */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *   void candidateSingle2population(population *pop, int nselect)
 *   void candidateTrue2population(population *pop)
 *   double distanceSquared2vectors(double *x, double *y, 
 *                      double *low, double *high, int nvar)
 *   void eliminateTrue()
 *   void closeFile(FILE* file)
 *   FILE* openFile(char* name, char* mode) 
 *   void outputStats()
 *   void population2candidate(population *pop, int *next, int kflag)
 *   void population2candidateSingle(population *pop, int nselect)
 *   void population2candidateTrue(population *pop)
 *   void population2parallelCandidate(population *pop, int kflag) 
 *   void population2parentCandidate(population *pop,
 *                                   int *next, int kflag)
 *   double roundDownToInt(double x)
 *   double roundUpToInt(double xval)
 *   void starttime()
 *   void stoptime()
 ****************************************************************/
/*eject*/
/**************************************************************
 * candidateSingle2population(population *pop, int nselect): 
 * store candidate[nselect] in population
 **************************************************************/
void candidateSingle2population(population *pop, int nselect) {

  int i, j;

  individual *indd;

  i = 0;
  indd = &(pop->ind[i]);
  for (j=0; j<nobj; j++) {
    indd-> obj[j] = candidate[nselect].obj[j];
  }
  for (j=0; j<ncon; j++) {
    indd-> constr[j] = candidate[nselect].constr[j];
  }
  for (j=0; j<nreal; j++) {
    indd-> xreal[j] = candidate[nselect].xvalue[j];
  }
  indd-> constr_violation = candidate[nselect].constr_violation;     

  curPopsize = 1;

  return;

}
/*eject*/
/**************************************************************
 * candidateTrue2population(population *pop): store candidate[]
 * with keepFlag = TRUE in population pop
 **************************************************************/
void candidateTrue2population(population *pop) {

  int i, j, n;

  individual *indd;

  i = 0;

  for (n=0; n<nCandidates; n++) {

    if (candidate[n].keepFlag == TRUE) {
      indd = &(pop->ind[i]);
      for (j=0; j<nobj; j++) {
       indd-> obj[j] = candidate[n].obj[j];
      }
      for (j=0; j<ncon; j++) {
        indd-> constr[j] = candidate[n].constr[j];
      }
      for (j=0; j<nreal; j++) {
        indd-> xreal[j] = candidate[n].xvalue[j];
      }
      indd-> constr_violation = candidate[n].constr_violation;     
      i++;     
    }

  } /* end for n */

  curPopsize = i;

  return;

}
/*eject*/
/**************************************************************
 * distanceSquared2vectors(double *x, double *y, 
 *                         double *low, double *high, int nvar):
 * compute squared Euclidean distance between two vectors 
 * x and y, using lower and upper bounds for x and y to
 * scale these vectors into unit cube. The vectors x and y
 * have length nvar
 **************************************************************/
double distanceSquared2vectors(double *x, double *y, 
                               double *low, double *high, int nvar) {
  int j;
  double dist, width;

  dist = 0;

  for (j=0; j<nvar; j++) {
    width = high[j] - low[j];
    if (width > 0.0) {
      dist += pow((x[j]-y[j])/width,2);
    }
  }

  return dist;

}
/*eject*/

/**************************************************************
 * eliminateTrue(): eliminate from candidate[] all records with
 *                  keepFlag == TRUE
 **************************************************************/
void eliminateTrue() {

  int j, n, ncand;

  ncand = 0;

  for (n=0; n<nCandidates; n++) {

    if  (candidate[n].keepFlag == FALSE) {
      if (n > ncand) {
        for (j=0; j<nobj; j++) {
          candidate[ncand].obj[j] = candidate[n].obj[j];
        }
        for (j=0; j<ncon; j++) {
          candidate[ncand].constr[j] = candidate[n].constr[j];
        }
        for (j=0; j<nreal; j++) {
          candidate[ncand].xvalue[j] = candidate[n].xvalue[j]; 
        }
        candidate[ncand].constr_violation = 
                candidate[n].constr_violation;
        candidate[ncand].keepFlag = 
                candidate[n].keepFlag;
        candidate[ncand].distanceSquared = 
                candidate[n].distanceSquared;
      }
      ncand++;
    } /* end if candidate[n].keepFlag == FALSE */

  } /* end for n */

  nCandidates = ncand;

  if (nCandidates != nFalseKeepFlag) {
    printf("\nIn routine eliminateTrue():\n");
    printf(
       "\nenCandidates = %d is not equal to nFalseKeepFlag = %d\n",
       nCandidates, nFalseKeepFlag);
    exit(1);
  }

  return;

}
/*eject*/
/***************************************************************/
void closeFile(FILE* file) 
{
  fclose(file);
  gNumOpenFiles--;
  return; 
}
/***************************************************************/
FILE* openFile(char* name, char* mode) {

  char file[MAX_DIRECTORY];

  FILE* out;

  strcpy(file,name);
	
  out = fopen(file, mode);
  if (out == NULL) {
    printf("\nError opening file %s \n for %s. Stop.\n",
            name, mode);
    exit(1);
  }

  gNumOpenFiles++;	
  return out;

}
/*eject*/
/**************************************************************
 * outputStats(): output statistics for one generation 
 **************************************************************/
void outputStats(population *pop) {

  int i, j;

  printf("\n iter = %d",generationCount);

  for (j=0; j<nobj; j++) {
    printf("\n   obj#    = %d\tmin = %g\tmax = %g",
           j+1, minvalue.obj[j], maxvalue.obj[j]);
    printf("\n              \tgoal = %g\tbound = %g",
                objGoal[j], objBound[j]);
  }
  for (j=0; j<ncon; j++) {
    printf("\n   constr# = %d\tmin = %g\tmax = %g",
           j+1, minvalue.constr[j], maxvalue.constr[j]);
           if ((gOption.gradualconstraint > 0) ||
               (gOption.scaleconstraint == TRUE)) {
             printf("\tscale = %g", gradCon.scale[j]);
           }
  }
  printf("\n   max constraint violation value   = %g", 
         maxvalue.constr_violation);
  printf("\n   sample size                      = %d", popsize);
  printf("\n   min sample size                  = %d", sampleSize);
  printf("\n   number of sample cases evaluated = %d", pickCount);
  printf("\n   number of sample cases estimated = %d", nEstimates);
  printf("\n   total number of evaluations      = %d", 
         evaluationCount);
/*eject*/
  if (nobj >= 2) {
    printf("\n   distribution of obj values:");
    for (j=0; j<nobj; j++) {
      printf("\n     ");
      for (i=0; i<MAX_BUCKET; i++) {
        printf("%d  ", distributionBucket[j][i]);
      }
    }
  }
  printf("\n   repeated distribution count = %d",
         repeatedDistributionCount);
  printf("\n   number of dominance test sequences = %d",
         numberDominanceTestSequence/2);
  printf("\n   priorCandidate records = %d of max = %d",
         nPriorCandidates, MAX_PRIOR);
  /* constraints */
  if (gOption.gradualconstraint > 0) {
    if (gradCon.iteration < gOption.gradualconstraint) {
      printf("\n   gradual constraints: iteration %d (= %d%s)",
             gradCon.iteration, (100*gradCon.iteration)/
             gOption.gradualconstraint, percent);
    } else {
      printf("\n   gradual constraints: fully enforced");
    }
  }

  fflush(stdout);

  return;

}
/*eject*/
/**************************************************************
 * population2candidate(population *pop,int *next, int kflag): 
 *                store population pop in
 *                candidate[] starting with index *next
 *                define keepFlag = kflag
 *  caution: rounds xreal[] of population array 
 *           for the nint integer cases before transfer
 **************************************************************/
void population2candidate(population *pop, int *next, int kflag) {

  int i, j, n;

  individual *indd;

  /* store population in candidate[], beginning with index *next */
  n = *next;

  for (i=0; i<curPopsize; i++) {
    indd = &(pop->ind[i]);
    for (j=0; j<nobj; j++) {
      candidate[n].obj[j] = indd-> obj[j];
    }
    for (j=0; j<ncon; j++) {
      candidate[n].constr[j] = indd-> constr[j];
    }
    for (j=0; j<nreal; j++) {
      /* for integer variables, round down xreal[] */
      /* min is used to avoid erroneous integer value */
      /* equal to input upper bound + 1.0, which may occur */
      /* due to the redefinition of max_realvar[] in nsga() */
      if (j < nint) {
        indd-> xreal[j] = min(roundDownToInt(indd-> xreal[j]),
                              max_realvar[j]-1);
      }
      candidate[n].xvalue[j] = indd-> xreal[j];
    }
    candidate[n].constr_violation = indd-> constr_violation;
    candidate[n].keepFlag = kflag;
    candidate[n].distanceSquared = INF;
    n++;
  } /* for i */

  *next = n;

  return;

}
/*eject*/
/**************************************************************
 * population2candidateSingle(population *pop, int nselect): 
 *                store population pop, which has just one record,
 *                in candidate[nselect]
 *                assign keepFlag = TRUE
 *                       distanceSquared = INF
 **************************************************************/
void population2candidateSingle(population *pop, int nselect) {

  int i, j;

  individual *indd;

  /* store population in candidate[nselect] */
  i = 0;
  /* insert obj, constr, constr_violation of population */
  indd = &(pop->ind[i]);
  for (j=0; j<nobj; j++) {
    candidate[nselect].obj[j] = indd-> obj[j];
  }
  for (j=0; j<ncon; j++) {
    candidate[nselect].constr[j] = indd-> constr[j];
  }
  candidate[nselect].constr_violation = indd-> constr_violation;
  candidate[nselect].keepFlag = TRUE;
  candidate[nselect].distanceSquared = INF;


  return;

}
/*eject*/
/**************************************************************
 * population2candidateTrue(population *pop): 
 *                from population pop, get
 *                 - obj[
 *                 - constr[]
 *                 -constr-violation
 *                insert these values into the
 *                candidate[] cases with keepFlag = TRUE
 **************************************************************/
void population2candidateTrue(population *pop) {

  int i, j, n;

  individual *indd;

/* store population in candidate[] with keepFlag = TRUE */
    i = 0;

    for (n=0; n<nCandidates; n++) {

      if (candidate[n].keepFlag == TRUE) {
        /* insert obj, constr, constr_violation of population */
        indd = &(pop->ind[i]);
        for (j=0; j<nobj; j++) {
          candidate[n].obj[j] = indd-> obj[j];
        }
        for (j=0; j<ncon; j++) {
          candidate[n].constr[j] = indd-> constr[j];
        }
        candidate[n].constr_violation = indd-> constr_violation;
        candidate[n].distanceSquared = INF;
        i++;
      }

    } /* end for n */

    /* check that all cases were transferred */
    if (i != curPopsize) {
      printf(
     "\nError: curPopsize %d not equal to TRUE candidate[] cases %d\n",
      curPopsize, i);
      exit(1);
    }

  return;

}
/*eject*/
/**************************************************************
 * population2parallelCandidate(population *pop, int kflag): 
 *                store population pop in
 *                parallelCandidate[]
 *                define keepFlag = kflag
 *  caution: rounds xreal[] of population array 
 *           for the nint integer cases before transfer
 **************************************************************/
void population2parallelCandidate(population *pop, int kflag) {

  int i, j;

  individual *indd;

  /* copy population pop into parallelCandidate[] */
  for (i=0; i<curPopsize; i++) {
    indd = &(pop->ind[i]);
    for (j=0; j<nobj; j++) {
      parallelCandidate[i].obj[j] = indd-> obj[j];
    }
    for (j=0; j<ncon; j++) {
      parallelCandidate[i].constr[j] = indd-> constr[j];
    }
    for (j=0; j<nreal; j++) {
      /* for integer variables, round down xreal[] */
      /* min is used to avoid erroneous integer value */
      /* equal to input upper bound + 1.0, which may occur */
      /* due to the redefinition of max_realvar[] in nsga() */
      if (j < nint) {
        indd-> xreal[j] = min(roundDownToInt(indd-> xreal[j]),
                                max_realvar[j]-1);
      }
      parallelCandidate[i].xvalue[j] = indd-> xreal[j];
    }
    parallelCandidate[i].constr_violation = indd-> constr_violation;
    parallelCandidate[i].keepFlag = kflag;
    parallelCandidate[i].distanceSquared = INF;
  } /* end for i */
  nParallelCandidates = curPopsize;

  return;

}
/*eject*/
/**************************************************************
 * population2parentCandidate(population *pop,int *next, int kflag):
 *   if nobj = 1: store worst case of population in 
 *                parentCandidate[*next]
 *   if nobj > 1: store entire population pop in
 *                parentCandidate[] starting with index *next
 *                declare keepFlag = kflag
 *  caution: does not change xvalue[] of population array 
 *           for the nint integer cases
 **************************************************************/
void population2parentCandidate(population *pop, 
                                int *next, int kflag) {

  int dominateflag, i, j, n;

  individual *indd;

  /* store population in parentCandidate[], */
  /* beginning with index *next */
  /* declare keepFlag = kflag */
    n = *next;

    for (i=0; i<curPopsize; i++) {
      indd = &(pop->ind[i]);
      for (j=0; j<nobj; j++) {
        parentCandidate[n].obj[j] = indd-> obj[j];
      }
      for (j=0; j<ncon; j++) {
        parentCandidate[n].constr[j] = indd-> constr[j];
      }
      for (j=0; j<nreal; j++) {
        parentCandidate[n].xvalue[j] = indd-> xreal[j];
      }
      parentCandidate[n].constr_violation = indd-> constr_violation;
      parentCandidate[n].keepFlag = kflag;
      parentCandidate[n].distanceSquared = INF;
      n++;
    } /* for i */
/*eject*/
    if (nobj == 1) {
    /* store the worst case of parentCandidate[] in */
    /* parentCandidate[0] */
      for (i=1; i<n; i++) {
        dominateflag = dominate(parentCandidate[0].obj, 
                                parentCandidate[0].constr_violation,
                                parentCandidate[i].obj, 
                                parentCandidate[i].constr_violation);
        if (dominateflag == TRUE) {
          /* parentCandidate[0] dominates parentCandidate[i] */
          /* redefine parentCandidate[0] using parentCandidate[i] */
          for (j=0; j<nobj; j++) {
            parentCandidate[0].obj[j] = parentCandidate[i].obj[j];
          }
          for (j=0; j<ncon; j++) {
            parentCandidate[0].constr[j] = 
                parentCandidate[i].constr[j];
          }
          for (j=0; j<nreal; j++) {
            parentCandidate[0].xvalue[j] = 
                parentCandidate[i].xvalue[j];
          }
          parentCandidate[0].constr_violation = 
              parentCandidate[i].constr_violation;
        }
      } /* end for i */
      n = 1;
    } /* end if nobj == 1 */

    *next = n;

  return;

}
/*eject*/
/**************************************************************
 *  roundDownToInt(double xval):
 *                round given xval up to next integer and
 *                return as double value
 **************************************************************/
double roundDownToInt(double x) {

  int y;

  y = (int) x;

  if (x == (double) y) {
    return x;
  } 

  /* x is not integer */
  if (x >= 0.0) {
    return ((double) y);
  } else {
    return ((double) (y-1));
  }

}
/*eject*/
/**************************************************************
 *  roundUpToInt(double xval):
 *                round given xval up to next integer and
 *                return as double value
 **************************************************************/
double roundUpToInt(double x) {

  int y;

  y = (int) x;

  if (x == (double) y) {
    return x;
  } 

  /* x is not integer */
  if (x <= 0.0) {
    return ((double) y);
  } else {
    return ((double) (y+1));
  }

}
/*eject*/
/**************************************************************
 * starttime(): get and write start time
 **************************************************************/
void starttime() {

  /* get begin time */
  startTime = time (NULL);
  /* convert start time to local time */
  locTime = localtime (&startTime);    
  /* print out the date and time in standard format */
  printf("\n");
  fputs (asctime (locTime), stdout);

  return;

}
/*eject*/
/**************************************************************
 * stoptime(): get and write stop time, compute elapsed time
 **************************************************************/
void stoptime() {

  /* get stop time */
  stopTime = time (NULL);
  /* convert end time to local time */
  locTime = localtime (&stopTime);    
  /* print out the date and time in standard format */
  printf("\n");
  fputs (asctime (locTime), stdout);
  /* elapsed time */
  elapsedTime = (int)(difftime(stopTime,startTime));
  printf("multicc elapsed clock time: %d hr  %d min  %d sec\n",
         elapsedTime/3600,
         (elapsedTime - 3600*(elapsedTime/3600))/60,
         elapsedTime - 60*(elapsedTime/60));

  return;

}
/********* last record of util.lb.c ******************/
