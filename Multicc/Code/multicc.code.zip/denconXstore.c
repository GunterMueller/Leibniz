/* storage and retrieval of solutions and associated values */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "dencon.h"
/**************************************************************
 *
 * subroutines in this file:
 *       void computeXvalues(double *x)
 *       double evaluateOnSameProcessor(double *x)
 *       double evaluateZ(double *z)
 *       void evaluateZandAllz(double *z,double *fz)
 *       int memberXstore(double *x)
 *       void moveupXstore(int k)
 *       double queryXstore(double *x)
 *       double retainXstore(double *x)
 **************************************************************/
/*eject*/
/**************************************************************
 *   double computeXvalues(double *x): 
 *          compute via evaluateOnSameProcessor():
 *              obj, constr[], viol
 *          return fz = obj + penalty sum using current eps[]
 **************************************************************/
double computeXvalues(double *x) {

  int  i;
  double fz;

  obj = evaluateOnSameProcessor(x);
  /* also computes constr[], viol */

  fz = obj;
  for (i=1; i<=ncon; i++) {
    fz += max(0.0,constr[i])/eps[i];
  }

  return fz;

}
/*eject*/
/**************************************************************
 *   double evaluateOnSameProcessor(double *x): returns obj value 
 *   for given vector x, using queryBlackBox() or test_problem()
 *   assumes nProcessors = 0, so evaluation is done on the same
 *   processor running dencon
 *   caution: dencon vectors start with index = 1, while
 *            local.xreal, local.obj, local.constr follow the
 *            general multicc convection and start with index = 0
 *   uses or modifies: constr[], viol, nreal       
 **************************************************************/
double evaluateOnSameProcessor(double *x){

  struct {
    double constr[MAX_CONSTRAINT];
    double obj[MAX_OBJ];
    double xreal[MAX_VARIABLE];
  } typedef Local;
  Local local;

  int j, juse;

  juse = 0; /* to suppress compiler warning */

  /* define local.xreal from dencon x */
  /* caution: index shift required */
  for (j=1; j<=nreal; j++) {
    local.xreal[j-1] = x[j];
  }

  /* use nobjEvaluate for evaluation of xvalue */
  nobj = nobjEvaluate;
/*eject*/
  /* compute local.obj and local.constr values */
  if (strcmp(gOption.input,"NOINPUTFILE") != 0) {
    queryBlackBox(problemName,local.xreal,local.obj,local.constr);
  } else {
    test_problem (TRUE, problemName, local.xreal, 
                  local.obj, local.constr);
    /* first parameter usage:
     *   TRUE: compute local.obj, local.constr values
     *   FALSE: define nreal, nbin, nobj, ncon,
     *                 min_realvar[], max_realvar[]
     */
  }

  /* store local.obj[], local.constr[], local.xreal[] */
  /* in singleminout file */
  if (gOption.singleminout == TRUE) {
    fprintf(singleminoutfil,"\n## cycle\n");
    for (j=0; j<nobjEvaluate; j++) {
      fprintf(singleminoutfil,"%g ", local.obj[j]);
    }
    for (j=0; j<ncon; j++) {
      fprintf(singleminoutfil,"%g ", local.constr[j]);
    }
    for (j=0; j<nreal; j++) {
      fprintf(singleminoutfil,"%g ", local.xreal[j]);
    }
  }
/*eject*/
  if ((gOption.objrange == TRUE) && (nobjSolve == 1)) {
    /* compute weighted sum of objs */
    /* for single function minimization */
    /* find index juse of single function */
    for (j=0; j<nobj; j++) {
      if (objFactor[j] != 0.0) {
        juse = j;
        break;
      }  
    }
    /* compute weighted sum for positive objrange values */
    /* factor WEIGHTED_SUM_FACTOR gives weight */
    /* to obj[juse] versus obj[j] */
    if (objRange[juse] > 0.0) {
      for (j=0; j<nobj; j++) {
        if ((j != juse) && (objRange[j] > 0.0)) {
          local.obj[juse] += WEIGHTED_SUM_FACTOR * 
                       (objRange[juse]/objRange[j]) * 
                       local.obj[j];
        }  
      }
    }
  }
/*eject*/
  /* if obj factors are used, apply them to local.obj[] */
  /* and eliminate cases with factor = 0 */
  if (gOption.objfactor == TRUE) {
    juse = 0;
    for (j=0; j<nobj; j++) {
      if (objFactor[j] != 0.0) {
        local.obj[juse] = local.obj[j] * objFactor[j];
        juse++;
      }
    }
    if (juse != nobjSolve) {
      printf("\n evaluateOnSameProcessor: nobjSolve = %d != juse = %d", 
             nobjSolve, juse);
      exit(1);
    }
  }
/*eject*/
  /* caution: dencon assumes constraints <= 0  */
  /*          gencc/nsga assumes constraints >= 0 */
  /* hence change sign of local constraint values, since they were */
  /* computed according to the gencc/nsga convention */
  for (j=0; j<ncon; j++) {
    local.constr[j] *= -1.0;
  }

  /* ignoreconstraint option */
  if (gOption.ignoreconstraint == TRUE) {
    for (j=0; j<ncon; j++) {
      local.constr[j] = 0.0;
    }
  }

  /* reset nobj to nobjSolve */
  nobj = nobjSolve;

  /* define dencon constr from local.constr */
  /* caution: index shift required */
  viol = 0.0;
  for (j=1; j<=ncon; j++) {
    constr[j] = local.constr[j-1];
    viol = max(viol,constr[j]);
  }

  return local.obj[0];

}
/*eject*/
/**************************************************************
 *   double evaluateZ(double *z, int ielle)
 *     evaluate z[]
 *     returns function value of z[] and defines corresponding
 *     obj, constr[] viol        
 **************************************************************/
double evaluateZ(double *z) {

  int n;

  double fz;

  n = nreal;

  fz = queryXstore(z);
      /* if fz !-= INF, also computes obj, constr[], viol */
  if (fz != INF) {
    return fz;
  }

  if (nProcessors == 0) {
    fz = computeXvalues(z);
        /* also have obj, constr[], viol */
     /* retain xreal, obj, constr[], viol in xstore[] */
     retainXstore(z);
    num_funct++;
  } else { /* have nProcessors >= 1 */
    /* evaluate xreal[] via parallelCandidate[] in one cycle */
    nParallelCandidates = 0;
    vector2parallelCandidate(z,nParallelCandidates,n);    
    parallelCandidate[nParallelCandidates].keepFlag = FALSE;
    nParallelCandidates++;
    /* evaluate parallelCandidate[] */
    evaluate_parallelCandidate("dencon", TRUE);
    num_funct += nParallelCandidates;
    cycle.sum++;
    /* extract solution values */
    extract_parallelCandidate(0,z,&fz,
                              &obj,constr,&viol);
    /* retain xreal, obj, constr[], viol in xstore[] */
    retainXstore(z);
  }

  return fz;

}
/*eject*/
/**************************************************************
 *   double evaluateZandAllz(double *z, int ielle)
 *     evaluate z[] and subsequent vectors of plin.allz[] 
 *     returns function value of z[] and defines corresponding
 *     obj, constr[], viol
 *     assumes nProcessors >= 2        
 **************************************************************/
double evaluateZandAllz(double *z, int ielle) {

  int i, n;
  double fz, x[MAX_VARIABLE+1];

  n = nreal;
  
  /* increment vector counter */
  plin.nCheckz[ielle] += 2;
  if (plin.nCheckz[ielle] > plin.nAllz[ielle]) {
    /* z[] cannot be in allz[][], so MAX_LINESEARCH is too small */
    printf("nnevaluateZandAllz: Insufficient number ");
    printf(" %d of predicted values for ielle = %d",
           plin.nAllz[ielle],ielle);
    printf("\nIncrease MAX_LINESEARCH = %d and rerun problem",
           MAX_LINESEARCH);  
    exit(1);
  }
/*eject*/
  /* check agreement of z[] with vector of allz[] */
  /* with index = plin.nCheckz[ielle] */
  if (same_vector(z,plin.allz[plin.nCheckz[ielle]],n) == FALSE) {
    printf("\nevaluateZandAllz: for ielle = %d and ",ielle);
    printf("plin.nCheckz[ielle] = %d",plin.nCheckz[ielle]);
    printf(" z[] and plin.allz[plin.nCheckz[ielle]] disagree");
    exit(1);
  }

  /* check if z[] is in xstore[] */
  fz = queryXstore(z);
  if (fz != INF) {
    /* z[] is in xstore[] */
    /* also have obj, constr[], viol */
    return fz;
  }

  /* z[] is not in xstore[] */
  if ((plin.nCheckz[ielle] == 1) || (plin.nCheckz[ielle] == 2)) {
    /* with nProcessors >= 2, the values for the initial z[] */
    /* must have been computed prior to the linesearch */
    /* thus this case should not occur */
    printf("\nlinesearchbox_cont: values for initial z[] ");
    printf("must be in xstore[] regardless of ielle");
    printf("\nhere, ielle = %d",ielle);
    exit(1);
  }
/*eject*/
  /* evaluate z[] and subsequent vectors of plin.allz[] */
  /* via parallelCandidate[] in one cycle */
  nParallelCandidates = 0;
  for (i=plin.nCheckz[ielle]; 
       i<=plin.nAllz[ielle]; i+=2) {
    vector2parallelCandidate(plin.allz[i],
                             nParallelCandidates,n);    
    parallelCandidate[nParallelCandidates].keepFlag = FALSE;
    nParallelCandidates++;
    if (nParallelCandidates == nProcessors) {
      break;
    }
  }
  /* evaluate parallelCandidate[] */
  evaluate_parallelCandidate("dencon", TRUE);
  num_funct += nParallelCandidates;
  cycle.sum++;
  /* extract solution values in reverse order */
  /* so current case z[] occurs last; thus get for z[] the */
  /* corresponding fz, obj, constr[], viol; then stop loop */
  for (i=nParallelCandidates-1; i >=0; i--) {
    extract_parallelCandidate(i,x,&fz,
                              &obj,constr,&viol);
    /* retain x, obj, constr, viol in xstore[] */
    retainXstore(x);
  }

  return fz;

}
/*eject*/
/**************************************************************
 *   int memberXstore(double *x):
 *      if x[] is in xstore[]: return index k of x in xstore[] 
 *      else: return FALSE
 *   caution: does not define obj, constr[], viol
 **************************************************************/
int memberXstore(double *x) {

  int flag, i, k;

  for (k=1; k<=nXstores; k++) {
    flag = TRUE;
    for (i=1; i<=nreal; i++) {
      if (x[i] != xstore[k].xreal[i]) {
        flag = FALSE;
        break;
      } 
    }    
    if (flag == TRUE) {
      return k;
    }
  }

  return FALSE;

}
/*eject*/
/**************************************************************
 *   void moveupXstore(int k):
 *      increment pointXstore and move up xstore[k] to
 *      xstore[pointXstore]
 *   caution: does not define obj, constr[], viol
 **************************************************************/
void moveupXstore(int k) {

  int i, n;

  n = nreal;

  if (nXstores < MAX_XSTORE) {
    nXstores++;
    pointXstore = nXstores;
  } else {
    /* storage is full; advance pointer */
    pointXstore++;
    if (pointXstore > MAX_XSTORE) {
    /* use pointer in circular fashion */
      pointXstore = 1;
    }
  }

  if (pointXstore != k) {
    for (i=1; i<=n; i++) {
      xstore[pointXstore].xreal[i] = xstore[k].xreal[i];
    }   
    xstore[pointXstore].obj = xstore[k].obj;
    for (i=1; i<=ncon; i++) {
      xstore[pointXstore].constr[i] = xstore[k].constr[i];
    }
    xstore[pointXstore].constr_violation = 
                           xstore[k].constr_violation;
  }  

  return;

}
/*eject*/
/**************************************************************
 *   double queryXstore(double *x):
 *      if x[] is in Xstore: return fz = obj + penalty 
 *                            also define obj, constr[], viol
 *      else: return INF
 **************************************************************/
double queryXstore(double *x) {

  int i, k;
  double fz;

  /* check if x is in xstore[] */
  k = memberXstore(x); 
   
  if (k > 0) {
    /* x is vector of xstore[k] */
    obj = xstore[k].obj;
    for (i=1; i<=ncon; i++) {
      constr[i] = xstore[k].constr[i];
    }
    viol = xstore[k].constr_violation;
    /* compute fz using current eps[] values */
    fz = obj;
    for (i=1; i<=ncon; i++) {
      fz += max(0.0,constr[i])/eps[i];
    }
    return fz;
  }

  return INF;

}
/*eject*/
/**************************************************************
 *   retainXstore(double *x):
 *        retain input vector x, obj, constr, viol in xstore[]
 **************************************************************/
void retainXstore(double *x) {

  int i;

  if (nXstores < MAX_XSTORE) {
    nXstores++;
    pointXstore = nXstores;
  } else {
    /* storage is full; advance pointer */
    pointXstore++;
    if (pointXstore > MAX_XSTORE) {
    /* use pointer in circular fashion */
      pointXstore = 1;
    }
  }
  for (i=1; i<=nreal; i++) {
    xstore[pointXstore].xreal[i] = x[i];
  }
  xstore[pointXstore].obj = obj;
  for (i=1; i<=ncon; i++) {
    xstore[pointXstore].constr[i] = constr[i];
  }
  xstore[pointXstore].constr_violation = viol;

  /* update bestobj, bestconstr, bestxreal */
  if ((obj < bestobj) &&
      (viol == 0.0)) {
    /* have better feasible solution */
    bestobj = obj;
    for (i=1; i<=ncon; i++) {
      bestconstr[i] = constr[i];
    }
    for (i=1; i<=nreal; i++) {
      bestxreal[i] = x[i];
    }
  }

  return;

}
/********** last record of denconXstore.c **************/
