/* first record of multicc.c */
/*****************************************************************
 *  Leibniz System: Multicc Module
 *  Copyright 1990-2015 by Leibniz Company
 *  Plano, Texas, U.S.A.
 * 
 *  This program is free software: you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free Software
 *  Foundation, either version 3 of the License, or (at your option) any later
 *  version. The License statement is in file lgpl.txt, but can also be obtained
 *  from www.gnu.org/licenses/.
 *
 *  We do not make any representation or warranty, expressed or implied, 
 *  as to the condition, merchantability, title, design, operation, or fitness 
 *  of the program for a particular purpose.
 *
 *  We do not assume responsibility for any errors, including mechanics or logic, 
 *  in the operation or use of the program, and have no liability whatsoever 
 *  for any loss or damages suffered by any user as a result of the program.
 * 
 *  In particular, in no event shall we be liable for special, incidental, 
 *  consequential, or tort damages, even if we have been advised of the 
 *  possibility of such damages.
 *
 *  Program multicc use the following software in some programs:
 *
 *  I.   Parts of NOMAD Blackbox Optimization System, used in
 *       program nomad
 *       Available at: http://www.gerad.ca/nomad/Project/Home.html 
 *       Used under GNU Lesser General Public License (LGPL),
 *       version 3.
 *       See http://www.gnu.org/licenses/lgpl.html for license 
 *       statement.
 *
 *       References:
 *
 *       1. Abramson, M.A., Audet C., Couture G., Dennis, J.E. Jr., 
 *          Le Digabel, S., and Tribes, C., "The NOMAD project," 
 *          software available at  http://www.gerad.ca/nomad
 *
 *       2. Le Digabel, S., "Algorithm 909: NOMAD: Nonlinear 
 *          Optimization with the MADS algorithm," ACM Transactions 
 *          on Mathematical Software, 37 (2011) 1-15.
 *
 *  II.  Parts of NSGA-II source code, used in programs gencc
 *       and nsga
 *       Used under license granted by K. Deb.
 *
 *       Reference:
 *
 *       1. Deb, K., Pratap. A, Agarwal, S., and Meyarivan, T., 
 *          "A fast and elitist multi-objective genetic algorithm: 
 *          NSGA-II," IEEE Transaction on Evolutionary Computation, 
 *          6 (2002) 181-197.
 *
 *  III. C code derived from SPDEN FORTRAN program, used in 
 *      program seqpen
 *       Derivation under license granted by G. Liuzzi, S. Lucidi,
 *       and M. Sciandrone.
 *
 *       Reference:
 *
 *       1. Liuzzi, G., Lucidi, S., and Sciandrone, M.,
 *          "Sequential Penalty Derivative-free Methods for
 *          Nonlinear Constrained Optimization," SIAM Journal
 *          on Optimization, 20 (2010) 2614-2635.
 *
 *  IV.  C code derived from cs-dfn FORTRAN program, used in
 *       programs dencon and denpar
 *       Derivation under license granted by G. Fasano, G. Liuzzi,
 *       S. Lucidi, and F. Rinaldi.
 *
 *       Reference:
 *
 *       1. Fasano, G, Liuzzi, G., Lucidi, S., and Rinaldi, F.,
 *          "A Linesearch-based Derivative-free Approach for 
 *          Nonsmooth Optimization."

 *****************************************************************/
/*eject*/
/*****************************************************************
 *  Standard form of optimization problem:
 *****************************************************************
 *  dencon:     min obj; constraints <= 0
 *  nomad:      min obj; constraints <= 0
 *  seqpen:     min obj; constraints <= 0
 *  gencc/nsga: min obj; constraints >= 0
 *  multicc uses the gencc/nsga convention and converts to/from
 *  dencon/nomad/seqpen convention as needed for program input/output
 *****************************************************************/ 
/*eject*/
/*****************************************************************
 * Programs produced from this main program file:
 *
 * multicc: solves single obj min, multiobj min
 *          default execution:
 *            single obj min: phase 1: nomad
 *                            phase 2: gencc
 *            multiobj min:   phases 1-nobj: nomad; if failure, gencc
 *                            phase nobj+1: nsga
 * dencon: C version of cs-dfn for single function minimization
 * denpar: parallelized C version of cs-dfn for single function
 *         minimization
 * gencc:  NSGA-II with retained priorCandidate[], inputCandidate[],
 *         kmeans selection, function value estimation
 * nomad:  NOMAD single function minimization
 * seqpen: C version of SDPEN for single function minimization
 * nsga:   NSGA-II with retained priorCandidate[], inputCandidate[],
 *         kmeans selection
 *****************************************************************/
# include "version.h"

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"

/* multicc.h contains variables and filenames of multicc.c used by */
/*           dencon, denpar, gencc, multicc, nomad, nsga, seqpen */
/* global.h  has extern versions */
# include "multicc.h"
/*eject*/
int main (int argc, char **argv)
{

    int flag, i, isel, iter, iterlimit, j, etot;
    char lineread[MAXLEN];

    char minsingle[MAX_ENTRY]; /* name of program to be executed */
    char versiondate[MAXLEN]; /* version and date for preamble */
    int  nomaduse; /* number of times nomad has already been called */

    FILE *fpt1;
    FILE *fpt2;
    FILE *fpt3;
    FILE *fpt4;
    FILE *fpt5;
    FILE *gp;
    population *parent_pop;
    population *child_pop;
    population *mixed_pop;

    population *one_pop; /* used by nomad */

    /* get and write start time */
    starttime();

    validityFlag = FALSE; /* assures that multicc fails if test at */
                          /* end of displayOptions() is removed */
    /* redundant totalDate definition, see beginParam() */
    totalDate = TOTALDATE;

    strcpy(percent,"%");
    strcpy(multicontrolfile,"/dev/shm/multicontrol.conx");
    /* caution: multicontrolfile name must be consistent with */
    /*          definition in multicontrol.c */
/*eject*/
    /* use lineread below for debugging as follows: */
    /* define the string in lineread to be the command normally */
    /* typed on the command line for the specified program */
    /* lineread = "" means no debugging for the program */
    strcpy(versiondate,"");
#ifdef MULTICC
    strcpy(methodName,"multicc");
 /*   strcpy(lineread,"multicc zdt1 -input NOINPUTFILE -stopcriterion optimal -dynamiclimit 1 -objrange 1 1 -processor list.processor.24 -maxproctime 10 -plotdetail 1 -printdetail 2 -singleminout 1   "); */
 /*  strcpy(lineread,"multicc optim -processor optim.processor -stopcriterion optimal -params optim.params -maxproctime 10 -initsol optim.initsol -accuracy 0.0001 -constrtolerance 0.02 0.03 0.04"); */
    strcpy(lineread,"");
#endif
#ifdef DENCON
    strcpy(methodName,"dencon");
 /*   strcpy(lineread,"dencon elattar -input NOINPUTFILE -stopcriterion optimal -singleminout 1 -processor list.processor.1");*/
    strcpy(lineread,"");
#endif
#ifdef DENPAR
    strcpy(methodName,"denpar");
  /*  strcpy(lineread,"denpar optim -processor optim.processor -maxproctime 10 -stopcriterion optimal -params optim.params -objrange 1 2 3 -objfactor 1 0 0 -singleminout 1"); */
  /*  strcpy(lineread,"denpar maxl -input NOINPUTFILE -processor optim.processor -stopcriterion optimal "); */
    strcpy(lineread,"");
#endif
/*eject*/
#ifdef NOMAD
    strcpy(methodName,"nomad");
  /*  strcpy(lineread,"nomad optim -processor optim.processor -maxproctime 10 -stopcriterion optimal -params optim.params -objrange 1 2 3 -objfactor 1 0 0 -singleminout 1"); */
    strcpy(lineread,"");
#endif
#ifdef SEQPEN
    strcpy(methodName,"seqpen"); 
    strcpy(lineread,"");
#endif
#ifdef GENCC
    strcpy(methodName,"gencc");
    strcpy(lineread,"");
#endif
#ifdef NSGA
    strcpy(methodName,"nsga");
/* strcpy(lineread,"nsga "); */
/*    strcpy(lineread,"nsga optim -processor optim.processor -stopcriterion optimal -params optim.params -maxproctime 10 -objrange 1 2 3 -singleminout 1"); */
 /*  strcpy(lineread,"nsga optim -processor optim.processor -stopcriterion optimal -params optim.params -maxproctime 10 -initsol optim.final.multi -cutout 1 -objbound 20 20 20"); */
   strcpy(lineread,"");
#endif
/*eject*/
    /* use command arguments or lineread command string */
    tokenize(lineread);
    if (nTokens == 0) {
      /* lineread has an empty or white-space string */
      /* use command arguments */ 
      if (argc >= MAX_ARG) {
        printf("\n input error: too many call arguments, or ");
        printf("\nincrease MAX_ARG to >= %d",
               argc);
        exit(1);
      } 
      for (i=0; i<argc; i++) {
        strcpy(callArg[i],argv[i]);
      }
      nCallArgs = argc;
    } else {
      /* lineread has a command string */
      /* use lineread */
      for (i=0; i<nTokens; i++) {
        strcpy(callArg[i],token[i]);
      }
      nCallArgs = nTokens;
      /* write warning of debugging mode */
      printf("\n*************************************************");
      printf("\n Debugging mode: command line is ignored.");
      printf("\n Instead, the following lineread command is used:");
      printf("\n %s",lineread);
      printf("\n*************************************************\n");
    }
    fflush(stdout);
/*eject*/
    /* process command arguments and define parameters
     * includes putting data records of params and initsol
     * into inputCandidate, with inputCandidate[].keepFlag = FALSE
     *
     * all steps of validity check are preceded by
     * a comment including the words "validity check"
     * step 1 of validity check: get current timeNow
     * and check against stored date in beginParam()
     */
    beginParam();

    if ((strcmp(methodName,"multicc") == 0) && 
        (gOption.printdetail > 0)) {
      /* Leibniz header and license statement for use of software */
# include "versiondate.h" /* file has the following line of code: */
                          /* strcpy(versiondate,"Compiled: <date> ");*/
# include "../../GlobalVersion/globalversion.h" /* file has the */
                          /* following code: */
                          /* strcpy(globalversion,"<xx.x"); */
                          
      licenseStatement(globalversion,versiondate);
    }
/*eject*/
    /* display option values defined by call arguments */
    if (gOption.printdetail == 2) {
      displayOptions();
      fflush(stdout);
      sleep(1);
    }

    /* initialize haveSolution */
    if (ncon > 0) {
      haveSolution = FALSE;
    } else {
      haveSolution = TRUE;
    }

    /* parallel evaluation: initialize cycleCount file to 0 */
    if (nProcessors > 0) {
      beginCycleCount(0);
      if ((strcmp(methodName,"multicc") == 0) && 
          (gOption.printdetail >= 1)) {
        printf("\n Number of parallel processors = %d\n",nProcessors);
      }
    }

    /* multicc does not make use of inputCandidate[] */
    /* avoid evaluation by defining nInputCandidates = 0 */
    if (strcmp(methodName,"multicc") == 0) {
      nInputCandidates = 0;
    }
/*eject*/
    if (nInputCandidates > 0) {

      /* check nInputCandidates */
      if ((strcmp(methodName,"nsga") == 0) ||
         (strcmp(methodName,"gencc") == 0)) {
        if (nInputCandidates > POPSIZE_MULTIOBJ_NSGA/2) {
          printf("\n input error:");
          printf("\n number of params and initsol solution ");
          printf("cases is %d and thus exceeds %d",
                 nInputCandidates, POPSIZE_MULTIOBJ_NSGA/2);
          printf("\n number must be reduced to less than %d ",
                 POPSIZE_MULTIOBJ_NSGA/2);
          printf("for effective execution");
          printf("\n maybe forgot '-cutout 1' option? ");
          exit(1);  
        }
      }

      /* add center point of solution space; need not */
      /* check nInputCandidates value since by above code */
      /* nInputCandidates <= POPSIZE_MULTIOBJ_NSGA/2 << MAX_PRIOR */
      for (j=0; j<nreal; j++) {
        inputCandidate[nInputCandidates].xvalue[j] = 
             (min_realvar[j] + max_realvar[j])/2.0;
      }
      inputCandidate[nInputCandidates].keepFlag = FALSE;
      nInputCandidates++;
/*eject*/    
      /* evaluate and reduce inputCandidate, which currently has
       * all solutions of params and initsol files, plus center point
       * have inputCandidate[].keepFlag = FALSE, hence must evaluate
       * to get obj and constr values
       *
       * recompute obj and constr values even if under cutout option
       * since these values may come from a closely related case
       * and may not be quite correct
       */
      if (nProcessors > 0) {

        /* copy inputCandidate[] into parallelCandidate[] */
        someCandidate2otherCandidate(inputCandidate,
                                     nInputCandidates,
                                     parallelCandidate,
                                     &nParallelCandidates);
        /* evaluate parallelCandidate[] */
        evaluate_parallelCandidate("nsga",TRUE);
        /* copy parallelCandidate[] into candidate[] */
        someCandidate2otherCandidate(parallelCandidate,
                                     nParallelCandidates,
                                     candidate,
                                     &nCandidates);
        /* candidate[] is now evaluated */
/*eject*/
    } else {

     /* allocation steps for evaluation:
      * one_pop is used only to evaluate
      * inputCandidate, and then is deallocated
      * min_realvar[], max_realvar[] have already been allocated
      *
      * for allocation of one_pop population,  use
      *          nobj = nobjEvaluate
      *          popsize = MAX_CANDIDATE
      */
        nobj = nobjEvaluate;
        popsize = MAX_CANDIDATE;

        /* second of three allocation steps */
        one_pop = (population *)malloc(sizeof(population));

        /* third and final allocation step */
        /* all steps of validity check are preceded by */
        /* a comment including the words "validity check" */
        /* step 5 of validity check: if code is expired, */
        /* skip memory allocation */
        if (validityFlag == TRUE) {
          allocate_memory_pop (one_pop, popsize);
        }
        /* end of one_pop allocation */

        /* reset nobj for solution process */
        nobj = nobjSolve;
/*eject*/
        /* transfer inputCandidate[] to candidate[] */
        nCandidates = 0;
        /* place inputCandidate[] into candidate[] */
        someCandidate2candidate(inputCandidate, nInputCandidates,
                                &nCandidates);
        /* evaluate candidates with keepFlag = FALSE */
        /* after evaluation, have keepFlag = TRUE */
        evaluate_candidate(one_pop);

        /* free one_pop population */
        deallocate_memory_pop (one_pop, popsize);
        free (one_pop);

      } /* end if nProcessors > 0, else */

      /* at this point, all candidate[] have obj, constr values, */
      /* and keepFlag = TRUE */

      /* assign keepFlag = FALSE to candidates violating at least */
      /* one objBound[j] */
      reduceAboveObjBoundCandidate();
      /* transfer candidates with keepFlag = TRUE to inputCandidate */
      nInputCandidates = 0;
      candidateTrue2someCandidate(inputCandidate,&nInputCandidates);

      /* if nInputCandidates = 0, define haveSolution = FALSE and */
      /* skip reduceInfeasibleDominatedDuplicateCandidate() */
      if (nInputCandidates == 0) {
        haveSolution = FALSE;
      } else {
        /* transfer inputCandidates to candidates */
        nCandidates = 0;
        someCandidate2candidate(inputCandidate,nInputCandidates,
                              &nCandidates);

        /* all candidates have keepFlag = TRUE */

        /* eliminate infeasible, dominated, duplicate candidates */
        /* return = TRUE if there are feasible candidates */
        /*          FALSE if all candidates are infeasible */
      
        haveSolution = reduceInfeasibleDominatedDuplicateCandidate(); 

        /* put candidate[] with keepFlag = TRUE in inputCandidate[] */
        nInputCandidates = 0;
        candidateTrue2someCandidate(inputCandidate,
        &nInputCandidates);
      } /* end if nInputCandidates == 0, else */
/*eject*/
      /* at this point, inputCandidate[]  observes objBound[]
       * and has nondominated feasible solutions, or just one
       * infeasible solution, or no solution
       * caution: inputCandidate[].constr[] values follow the
       *          gencc/nsga convention and cannot be directly used
       *          by dencon, denpar, nomad, or seqpen without scaling
       *          by -1
       *          dencon, denpar, nomad, and seqpen assume
       *          constraints <= 0
       *          gencc/nsga assumes constraints >= 0
       *
       *          difficulties arising from the differing constr
       *          interpretations are avoided below by passing just
       *          inputCandidate[].xvalue vectors to dencon, denpar,
       *          nomad,and seqpen as starting vectors, and 
       *          ignoring obj and constr values
       */
    } /* end if nInputCandidates > 0 */

    if ((strcmp(methodName,"multicc") != 0) && 
        (gOption.printdetail == 2)) {
      printf(
        "\nProcessing of input, params, and initsol files done");
      printf(
        "\nNumber of retained input candidate records = %d\n",
        nInputCandidates);
      fflush(stdout);
    }
/*eject*/
    /* multicc case */
    if (strcmp(methodName,"multicc") == 0) {

      /* define multiparams file */
      if (strcmp(gOption.input,"NOINPUTFILE") != 0) {
        sprintf(multiparamsfile,"%s.multi",gOption.params);
      } else {
        sprintf(multiparamsfile,"%s.params.multi",problemName);
      }
      /* write parameter definitions into multiparams file */
      /* in subsequent writing into multiparams file */
      /* must open file with "a", write, and then close file */
      /* thus, at any point in time the file can be operated on */
      /* by any other program or subroutines */
      multiparamsfil = openFile(multiparamsfile,"w");
      defineMultiParams(multiparamsfil);
      closeFile(multiparamsfil);
      /* copy multiparams file into gOption.tempdir */
      /* to be used as params file for nomad black box calls */
      sprintf(cmnd,"cp %s %s%s",multiparamsfile, 
                                gOption.tempdir, 
                                multiparamsfile);  
      system(cmnd);

      /* start singleminout file */
      if ((gOption.singleminout == TRUE) &&
          (gOption.minallonly == FALSE)) {
        /* will carry out single function minimization */ 
        sprintf(singleminoutfile,"%s%s.singleminout",
                              gOption.tempdir, problemName);
        if ((singleminoutfil = openFile(singleminoutfile,"w")) 
             == NULL) {
          printf("\n multicc cannot open singleminout file = %s",
                  singleminoutfile);
          exit(1);
        }
        fprintf(singleminoutfil,"# multicc");
        fprintf(singleminoutfil,"\n# of objectives = %d , ",nobj);
        fprintf(singleminoutfil,"# of constraints = %d , ",ncon);
        fprintf(singleminoutfil,"# of real_var = %d",nreal);
        closeFile(singleminoutfil);
      }

      /* initialize cycle.singleObj[], eval.singleObj[j] */
      for (j=0; j<nobjEvaluate; j++) {
          cycle.singleObj[j] = 0; 
          eval.singleObj[j] = 0;      
      }
/*eject*/
      for (j=0; j<nobjEvaluate; j++) {
        if (objFactor[j] == FALSE) {
          continue;
        }
        if (gOption.minallonly == TRUE) {
          /* minimization of all objs only; hence do not execute */
          /* any iteration of single obj minimization */
          break;
        }
        /* initialize singleObjective.old, nomaduse */
        singleObjective.old = INF; /* current best value */
        nomaduse = 0; /* number of multicc calls of nomad */ 

        /* iterlimit must allow execution of all minsingle */
        /* methods of sequence regardless of maxiter value */
        iterlimit = max(gOption.maxiter,gOption.nsequenceminone-1);

        /* if there is no feasible solution, and if we have */
        /* already tried to find one, stop computation for j */
        if (haveSolution == FALSE) {
          flag = FALSE;
          for (i=0; i<j; i++) {            
            if (objFactor[j] == TRUE) {
              /* index i has already been processed; since */
              /* haveSolution == FALSE, index i did not produce */
              /* a feasible solution */
              flag = TRUE;
              break;
            }
          }
          if (flag == TRUE) {
            /* index i < j did not produce a solution, so it is */
            /* futile to process index j; hence skip that case */
            continue;
          }
        }
/*eject*/
        for (iter=0; iter<iterlimit; iter++) {

          /* decide isel */
          if (iter == 0) {
            isel = 1;
          } else if (haveSolution == FALSE) {
            /* iter = 0 has already been done and did not produce */
            /* a feasible solution */
            if (iter == 1) {
              /* try to find a feasible solution using the first
               * program of sequenceminone; hence
               * reset isel = 0 and nomaduse = 0
               * increase iterlimit by 2 since iter 0 effort produced
               * an infeasible solution and isel = 0 case needs 
               * to be done just to get a feasible solution 
               */
              isel = 0;
              nomaduse = 0;
              iterlimit+= 2;
            } else {
              /* iter = 0 and 1 did not find a feasible solution */
              /* hence give up on finding a feasible solution */
              break;
            }
/*eject*/
          } else {
            isel++;
            if (isel == gOption.nsequenceminone) {
              /* have completed one complete cycle of programs
               * use circular repetition of programs
               * if gOption.maxfirstitereval = 0, do
               *   isel = 1, 2, .., gOption.nsequenceminone - 1
               * else do
               *   isel = 2, 3, .., gOption.nsequenceminone - 1
               */
              if (gOption.maxfirstitereval == 0) {
                isel = 1;
              } else {
                isel = 2;
              }
            }                 
          } /* end if iter == 0, else */
          strcpy(minsingle,gOption.sequenceminone[isel]);

          if (gOption.printdetail > 0) {
            printf("\n**** Phase %d *** Iteration %d *** ", j+1,iter+1);
            printf("Program %s ****\n",minsingle);
            fflush(stdout);
          }
/*eject*/
          /* define cmnd for program execution */ 
          sprintf(cmnd,"%s%s %s ",gOption.leibnizpath, 
                                  minsingle, problemName);
          /* specify all parameters of multicc call */
          for (i=2; i<nCallArgs; i++) {
            sprintf(addcmnd,"%s ",callArg[i]);
            strcat(cmnd,addcmnd);
          }

          /* specify multiparams file as params file */
          sprintf(addcmnd,"-params %s ",multiparamsfile);
          strcat(cmnd,addcmnd);

          /* -objfactor */
          sprintf(addcmnd,"-objfactor ");
          strcat(cmnd,addcmnd);
          for (i=0; i<nobjEvaluate; i++) {
            if (i == j) {
              sprintf(addcmnd,"1 ");
              strcat(cmnd,addcmnd);
            } else {
              sprintf(addcmnd,"0 ");
              strcat(cmnd,addcmnd);
            }
          }

          if ((iter == 0) && (gOption.maxfirstitereval > 0)) {
            /* override maxeval using maxfirstitereval */
            /* override processor option using "NOPROCFILE" */
            sprintf(addcmnd,"-maxeval %d -processor NOPROCFILE ",
                    gOption.maxfirstitereval);
          } else {
            /* override maxeval using maxitereval */
            sprintf(addcmnd,"-maxeval %d ",gOption.maxitereval);
          }
          strcat(cmnd,addcmnd);
/*eject*/
          /* if iter = 0 or haveSolution = TRUE, enforce
           *   stopcriterion = optimal
           */
          if ((iter == 0) || (haveSolution == TRUE)) {
            sprintf(addcmnd,"-stopcriterion optimal ");
            strcat(cmnd,addcmnd);
          }
          /* if minsingle = nomad, determine initialmesh */
          if (strcmp(minsingle,"nomad") == 0) {
            nomaduse++;
            /* initialmesh = */
            /* max(gOption.initialmesh/2^nomaduse,finalmesh*100) */
            /* this reduces initialmesh but also assures */
            /* finalmesh < initialmesh */
            sprintf(addcmnd,"-initialmesh %f ",
              max(gOption.initialmesh/pow(2.0,(double)(nomaduse-1)),
                  gOption.finalmesh * 100.0));
            strcat(cmnd,addcmnd);
          }

          if (gOption.printdetail <= 1) {
           sprintf(addcmnd," > /dev/null ");
           strcat(cmnd,addcmnd);
          }

          if (gOption.printdetail > 1) { 
            printf("\n Command:\n %s\n",cmnd);
          }       
/*eject*/
          /* execute minimization program */
          if (Xexecute(cmnd) != 0) {
            /* program has failed */
            if (gOption.printdetail > 0) {
              printf(
        "\n multicc: Phase %d Iteration %d Program %s failed ***\n",
                     j+1,iter,minsingle);
            }
            multiparamsfil = openFile(multiparamsfile,"a");
            fprintf(multiparamsfil,
                "\n# phase %d iteration %d program %s failed",
                 j+1,iter,minsingle);
            closeFile(multiparamsfil);

          } else { /* minimization is completed, may have found */
            /* feasible or infeasible solution */

            /* all steps of validity check are preceded by */
            /* a comment including the words "validity check" */
            /* step 3 of validity check: if code is expired, */
            /* skip output */
            if (validityFlag == FALSE) {
              continue; /* skip output */
            }
/*eject*/  
            /* add final_pop.out to multiparams file */
            /* for function j+1, and increment evaluation count */
            /* multiparamsfile has correct obj values */
            /* update haveSolution */
            multiparamsfil = openFile(multiparamsfile,"a");
            fprintf(multiparamsfil,
                  "\n# phase %d iteration %d program %s completed",
                  j+1,iter,minsingle);
            eval.singleObj[j] += 
               addFinalPop2outputMulti(multiparamsfil);
            /* above call also updates singleObjective.new and */
            /* haveSolution */
            closeFile(multiparamsfil);
            /* parallel evaluation: retain cycle count */
            if (nProcessors > 0) {
              cycle.singleObj[j] += readCycleCount();
            }
/*eject*/
            /* termination test 1: check if obj goal achieved */
            if (singleObjective.new <= objGoal[j]) {
              /* solution satisfies obj goal, stop iterations */ 
              break;
            }
            /* termination test 2: when last program of sequence */
            /* has been executed, stop iterations if */
            /*  - no improvement beyond tolerance, or */
            /*  - only one program specified for minimization, */
            /*    not counting program for maxfirstitereval step */
            if (isel == (gOption.nsequenceminone-1)) {
              /* last program of sequence has been executed */
              if (((singleObjective.old - singleObjective.new) <= 
                 objTolerance[j]) && (haveSolution == TRUE)) {
                /* have convergence, stop iterations */
                break;
              } else if ((gOption.maxfirstitereval == 0) &&
                         (isel == 1) && (haveSolution == TRUE) &&
                         (gOption.nsequenceminone == 2)) {
                /* only one program specified for minimization */
                /* stop since repetition likely will not help */
                  break;
              } else if ((gOption.maxfirstitereval > 0) &&
                         (isel == 2) && (haveSolution == TRUE) &&
                         (gOption.nsequenceminone == 3)) {
                /* only one program specified for minimization */
                /* except for initial maxfirstitereval program */
                /* stop since repetition likely will not help */
                  break;
              } else {
                /* update single objective value */
                singleObjective.old = singleObjective.new;
              }
            } /* end if isel == (gOption.nsequenceminone-1), else.. */
          } /* if Xexecute(cmnd) != 0, else */
        } /* end for iter */
      } /* end for j */ 
/*eject*/
      if ((gOption.minsingleonly == TRUE) || (nobjSolve == 1) ||
          (haveSolution == FALSE)) {
        /* stop if demanded by minsingleonly option, or if a */
        /* single function is to be minimized, or if a feasible */
        /* solution could not found */
        if (gOption.printdetail > 0) {
          if (haveSolution == TRUE) {
            printf("\n caution: minimization of single objs only");
          } else {
            printf("\n caution: problem is infeasible");
            printf("\n          file %s has information pointing to ",
                   multiparamsfile);
            printf(
              "\n          the constraint(s) causing the problem");
          }
        }
        /* compute cycle and evaluation counts */
        if (nProcessors > 0) {
          cycle.total = 0;
        }
        eval.total = 0;
        for (j=0; j<nobjEvaluate; j++) {
          if (nProcessors > 0) {
            cycle.total += cycle.singleObj[j];
          }
          eval.total += eval.singleObj[j];
        }
        if (gOption.printdetail > 0) {
          printf("\n multicc evaluation counts");
          printf("\n                vectors  cycles");
          for (j=0; j<nobjEvaluate; j++) {
            printf("\n       phase %d = %5d",j+1,eval.singleObj[j]);
            if (nProcessors > 0) {
              printf("   %5d",cycle.singleObj[j]);
            }
          }   
          printf("\n   ___________________");
          if (nProcessors > 0) {
            printf("________");
          }
          printf("\n   total count = %5d",eval.total);
          if (nProcessors > 0) {
            printf("   %5d",cycle.total);
          }
          printf("\n output in %s \n", multiparamsfile);
        }
/*eject*/
        /* free lower and upper bounds */
        free(min_realvar);
        free(max_realvar);

        /* get and write stoptime and elapsed time */
        stoptime();

        return 0;
      }
/*eject*/
      /* minimize multiobjective case */
      if (gOption.printdetail > 0) {
        printf("\n**** Phase %d ",nobjEvaluate+1);
        printf("******************* Program %s ****\n",gOption.minall);
        fflush(stdout);
      }
      /* define cmnd */
      sprintf(cmnd,"%s%s %s ",gOption.leibnizpath, gOption.minall,
                   problemName);
      /* all parameters of multicc call */
      for (i=2; i<nCallArgs; i++) {
        sprintf(addcmnd,"%s ",callArg[i]);
        strcat(cmnd,addcmnd);
      }
      /* -paramsfile */
      sprintf(addcmnd,"-params %s ",multiparamsfile); 
      strcat(cmnd,addcmnd);

      /* enforce stopcriterion = optimal */
      /* regardless of stopcriterion specified for multicc */ 
      sprintf(addcmnd,"-stopcriterion optimal ");
      strcat(cmnd,addcmnd);

      /* define -convergetesteval option if not specified as part */
      /* of multicc call */
      if (gOption.convergetesteval <= 0) {
        /* decide convergetesteval option here */
        etot = 0;
        for (j=0; j<nobjEvaluate; j++) {
          etot += eval.singleObj[j];
        }
        sprintf(addcmnd,"-convergetesteval %d ",max(1,etot/20));
        strcat(cmnd,addcmnd);
      }

      if (gOption.printdetail <= 1) {
        sprintf(addcmnd," > /dev/null ");
        strcat(cmnd,addcmnd);
      }

      if (gOption.printdetail > 1) { 
        printf("\n Command:\n %s\n",cmnd);
      }     

      /* define multifinal file */
      sprintf(multifinalfile,"%s.final.multi",problemName);
      multifinalfil = openFile(multifinalfile,"w");
/*eject*/
      /* execute program specified by gOption.minall */
      if (Xexecute(cmnd) >= 1) {
        if  (gOption.printdetail > 0) {
          printf(
            "\n multicc: Phase %d Iteration 0 Program %s failed\n",
            nobjEvaluate+1,gOption.minall);
        }   
        fprintf(multifinalfil,
             "\n# phase %d iteration 0 method %s failed\n",
             nobjEvaluate+1,gOption.minall);
        closeFile(multifinalfil);
        exit(1);
      }

      /* all steps of validity check are preceded by */
      /* a comment including the words "validity check" */
      /* step 4 of validity check: if code is expired, */
      /* produce no output */
      if (validityFlag == FALSE) {
        return 0; /* produce no output */
      }
/*eject*/  
      /* activate code below for display of detailed */
      /* evaluation counts in multifinal file */
      /*
      fprintf(multifinalfil,
             "# multicc evaluation counts");
      for (j=0; j<nobjEvaluate; j++) {
        if (j == 0) {
          fprintf(multifinalfil,
                 "\n# phase %d = %d",
               j+1,eval.singleObj[j]);
        } else {
          fprintf(multifinalfil,
                 "\n# phase %d = %d",
                 j+1,eval.singleObj[j]);
        }
      }   
      fprintf(multifinalfil,
             "\n# phase %d = %d",nobjEvaluate+1,eval.multiObj);
      fprintf(multifinalfil,"\n");
      */
/*eject*/
      /* parallel evaluation: read cycle count */
      if (nProcessors > 0) {
        cycle.multiObj = readCycleCount();
      }
      /* add final_pop.out file to multifinal file*/
      eval.multiObj = addFinalPop2outputMulti(multifinalfil);
      /* compute cycle and evaluation counts */
      if (nProcessors > 0) {
        cycle.total = cycle.multiObj;
      }
      eval.total = eval.multiObj;
      for (j=0; j<nobjEvaluate; j++) {
        if (nProcessors > 0) {
          cycle.total += cycle.singleObj[j];
        }
        eval.total += eval.singleObj[j];
      }
/*eject*/
      /* print evaluation counts on screen and in multifinal file */
      if (gOption.printdetail > 0) {
        printf("\n multicc evaluation counts");
        printf("\n                vectors  cycles");
        for (j=0; j<nobjEvaluate; j++) {
          printf("\n       phase %d = %5d",j+1,eval.singleObj[j]);
          if (nProcessors > 0) {
            printf("   %5d",cycle.singleObj[j]);
          }
        }   
        printf("\n       phase %d = %5d",
               nobjEvaluate+1,eval.multiObj);
        if (nProcessors > 0) {
          printf("   %5d",cycle.multiObj);
        }
        printf("\n   ___________________");
        if (nProcessors > 0) {
          printf("________");
        }
        printf("\n   total count = %5d",eval.total);
        if (nProcessors > 0) {
          printf("   %5d",cycle.total);
        }
        printf("\n output in %s and %s\n\n", 
               multiparamsfile,multifinalfile);
      }
/*eject*/
      fprintf(multifinalfil,             
            "\n# multicc evaluation counts");
      fprintf(multifinalfil,
            "\n#                vectors  cycles");
      for (j=0; j<nobjEvaluate; j++) {
        fprintf(multifinalfil,
            "\n#       phase %d = %5d",j+1,eval.singleObj[j]);
        if (nProcessors > 0) {
          fprintf(multifinalfil,"   %5d",cycle.singleObj[j]);
        }
      }   
      fprintf(multifinalfil,
            "\n#       phase %d = %5d",nobjEvaluate+1,eval.multiObj);
      if (nProcessors > 0) {
        fprintf(multifinalfil,"   %5d",cycle.multiObj);
      }
      fprintf(multifinalfil,
            "\n#   ___________________");
      if (nProcessors > 0) {
        fprintf(multifinalfil,"________");
      }
      fprintf(multifinalfil,
            "\n#   total count = %5d",eval.total);
      if (nProcessors > 0) {
        fprintf(multifinalfil,"   %5d",cycle.total);
      }
      closeFile(multifinalfil);
/*eject*/      
      /* free lower and upper bounds */
      free(min_realvar);
      free(max_realvar);

      /* get and write stoptime and elapsed time */
      stoptime();

      return 0;

    } /* end if strcmp(methodName,"multicc") == 0 */
/*eject*/
/* begin dencon case */
    if (strcmp(methodName,"dencon") == 0) {

       if (nobjSolve != 1) {
        printf(
          "\n dencon can only be used for nobjSolve = 1");
        printf(
          "\n use -objfactor option to achieve this");
        exit(1);
      }

      /* delete final_pop.out if present */
      sprintf(cmnd,"rm -f final_pop.out");
      system(cmnd);

      /* open singleminout file in tempdir and print "# dencon" */
      if (gOption.singleminout == TRUE) {
        sprintf(singleminoutfile,"%s%s.singleminout",
                              gOption.tempdir, problemName);
        if ((singleminoutfil = fopen(singleminoutfile,"a")) == NULL) {
          printf("\n dencon cannot open singleminout file = %s",
                 singleminoutfile);
          exit(1);
        } 
        fprintf(singleminoutfil,"\n# dencon");   
      }

      /* execute dencon, which in turn executes queryBlackBox */
      /* and the specified blackbox */    
      flag = denconmain();
      /* flag = TRUE: have final_pop.out file with solution */
      /*        FALSE: there is no final_pop.out file */

      if (gOption.singleminout == TRUE) {
        fclose(singleminoutfil); 
      }

      /* free lower and upper bounds */
      free(min_realvar);
      free(max_realvar);

      return flag;

    } /* end if strcmp(methodName,"dencon") == 0 */
/*eject*/ 
/* begin denpar case */
    if (strcmp(methodName,"denpar") == 0) {

       if (nobjSolve != 1) {
        printf(
          "\n denpar can only be used for nobjSolve = 1");
        printf(
          "\n use -objfactor option to achieve this");
        exit(1);
      }

      /* delete final_pop.out if present */
      sprintf(cmnd,"rm -f final_pop.out");
      system(cmnd);

      /* open singleminout file in tempdir and print "# denpar" */
      if (gOption.singleminout == TRUE) {
        sprintf(singleminoutfile,"%s%s.singleminout",
                              gOption.tempdir, problemName);
        if ((singleminoutfil = fopen(singleminoutfile,"a")) == NULL) {
          printf("\n denpar cannot open singleminout file = %s",
                 singleminoutfile);
          exit(1);
        } 
        fprintf(singleminoutfil,"\n# denpar");   
      }

      /* execute denpar, which in turn executes queryBlackBox */
      /* and the specified blackbox */    
      flag = denparmain();
      /* flag = TRUE: have final_pop.out file with solution */
      /*        FALSE: there is no final_pop.out file */

      if (gOption.singleminout == TRUE) {
        fclose(singleminoutfil); 
      }

      /* free lower and upper bounds */
      free(min_realvar);
      free(max_realvar);

      return flag;

    } /* end if strcmp(methodName,"denpar") == 0 */
/*eject*/ 
    /* begin nomad case */
    if (strcmp(methodName,"nomad") == 0) {

       if (nobjSolve != 1) {
        printf(
          "\n nomad can only be used for nobjSolve = 1");
        printf(
          "\n use -objfactor option to achieve this");
        exit(1);
      }
    
      /* copy transfer.nomad.exe from Leibniz/Multicc/Code */
      /* to gOption.tempdir directory */
      sprintf(cmnd,"cp %s/transfer.nomad.exe %s",
         gOption.leibnizpath, gOption.tempdir);
      if (system(cmnd) != 0) {
        printf("\n nomad: cannot execute '%s'",cmnd);
        exit(1);
      }

      /* define statnomad file */
      sprintf(statnomadfile,"stat.nomad.%d.txt",SEEDNOMAD);
      /* remove statnomad file if present */
      sprintf(cmnd,"rm -f %s",statnomadfile);
      system(cmnd);

      /* delete final_pop.out if present */
      sprintf(cmnd,"rm -f final_pop.out");
      system(cmnd);

      /* define nomad parameter file */
      /* inputCandidate[] is used to define X0 options */
      defineNomadParams();

      /* define blackbox nomad parameter file */
      defineTransferNomadParams();

      /* start or continue singleminout file in tempdir */
      if (gOption.singleminout == TRUE) {
        sprintf(singleminoutfile,"%s%s.singleminout",
                              gOption.tempdir, problemName);
        if ((singleminoutfil = fopen(singleminoutfile,"a")) == NULL) {
          printf("\n nomad cannot open singleminout file = %s",
                  singleminoutfile);
          exit(1);
        } 
        fprintf(singleminoutfil,"\n# nomad");
        fclose(singleminoutfil); 
      }
        
/*eject*/
      /* execute nomad, which in turn executes transfer.nomad.exe, */
      /* which in turn executes queryBlackBox and the specified */
      /* blackbox */
      flag = Xnomad();
      if (flag != 0) {
        printf("\n nomad: execution error");
        printf("\n        check nomad log to diagnose error\n");
        exit(1);
      }

      /* check presence of output.nomad.txt and stat.nomad.txt */ 
      sprintf(filename,"output.nomad.%d.txt",gOption.seednomad);
      if ((fil = fopen(filename,"r")) == NULL) {
        printf("\n nomad: missing output file output.nomad.%d.txt",
               gOption.seednomad);
        printf("\n        check nomad log to diagnose error\n"); 
        exit(1);
      } else {
        fclose(fil);
      }
      sprintf(filename,"stat.nomad.%d.txt",gOption.seednomad);
      if ((fil = fopen(filename,"r")) == NULL) {
        printf("\n nomad: missing output file output.nomad.%d.txt\n",
               gOption.seednomad);
        printf("\n        check nomad log to diagnose error\n");
        exit(1);
      } else {
        fclose(fil);
      }
/*eject*/
      /* parallel evaluation: final cycle count */
      if (nProcessors > 0) {
        printf("\n parallel evaluation: cycle count = %d",
               readCycleCount());
      }

      /* convert output.nomad.txt and stat.nomad.txt */
      /* to final_pop.out */
      convertNomadOutput2finalPopOut(); 

      /* free lower and upper bounds */
      free(min_realvar);
      free(max_realvar);

      return 0;

    } /* end if strcmp(methodName,"nomad") == 0 */
/*eject*/
    /* begin seqpen case */
    if (strcmp(methodName,"seqpen") == 0) {

       if (nobjSolve != 1) {
        printf(
          "\n seqpen can only be used for nobjSolve = 1");
        printf(
          "\n use -objfactor option to achieve this");
        exit(1);
      }

      /* delete final_pop.out if present */
      sprintf(cmnd,"rm -f final_pop.out");
      system(cmnd);

      /* start or continue singleminout file in tempdir */
      if (gOption.singleminout == TRUE) {
        sprintf(singleminoutfile,"%s%s.singleminout",
                              gOption.tempdir, problemName);
        if ((singleminoutfil = fopen(singleminoutfile,"a")) == NULL) {
          printf("\n seqpen cannot open singleminout file = %s",
                 singleminoutfile);
          exit(1);
        } 
        fprintf(singleminoutfil,"\n# seqpen");
      }

      /* execute seqpen, which in turn executes queryBlackBox */
      /* and the specified blackbox */    
      flag = seqpenmain();
      /* flag = TRUE: have final_pop.out file with solution */
      /*        FALSE: there is no final_pop.out file */

      if (gOption.singleminout == TRUE) {
        closeFile(singleminoutfil); 
      }

      /* free lower and upper bounds */
      free(min_realvar);
      free(max_realvar);

      return flag;

    } /* end if strcmp(methodName,"seqpen") == 0 */
/*eject*/
    /* begin gencc/nsga case */

    /* adjust bounds for nint variables so that generation */
    /* within revised min-max interval and rounding down */
    /* produce appropriate integer values */
    /* caution: must use rounding so that new max_realvar[j] */
    /*          cannot result; see population2candidate() */
    for (j=0; j<nint; j++) {
      min_realvar[j] = roundUpToInt(min_realvar[j]);
      max_realvar[j] = roundDownToInt(max_realvar[j]) + 1.0;
    }

    if (gOption.singleminout == TRUE) {
      /* get records of singleminout file and prepare */
      /* acceptCandidate[] and rejectCandidate[] */
      /* for initialization of population */
      sprintf(singleminoutfile,"%s%s.singleminout",
                               gOption.tempdir, problemName);
      prepareAcceptRejectCandidate();
    } /* end if gOption.singleminout == TRUE */
/*eject*/
    /* allocation steps for gencc/nsga */

    /* min_realvar[], max_realvar[] have already been allocated */

    /* for allocation of populations, use */
    /*          nobj = nobjEvaluate */
    /*          popsize = MAX_CANDIDATE */
    nobj = nobjEvaluate;
    popsize = MAX_CANDIDATE;

    /* second of three allocation steps */
    parent_pop = (population *)malloc(sizeof(population));
    child_pop = (population *)malloc(sizeof(population));
    mixed_pop = (population *)malloc(sizeof(population));

    /* third and final allocation step */
    /* all steps of validity check are preceded by */
    /* a comment including the words "validity check" */
    /* step 6 of validity check: if code is expired, */
    /* skip memory allocation */
    if (validityFlag == TRUE) {
      allocate_memory_pop (parent_pop, popsize);
      allocate_memory_pop (child_pop, popsize);
      allocate_memory_pop (mixed_pop, 2*popsize);
    }

    /* for solution process, use nobj = nobjSolve */
    nobj = nobjSolve;
/*eject*/
    /* define parameters from options for gencc, nsga */

    /* redefine popsize */
    if (gOption.paretosize == FALSE) {
      if (nobj == 1) {
        popsize = POPSIZE_SINGLEOBJ;
      } else { /* nobj >= 2 */
        if (strcmp(methodName,"gencc") == 0) {  
          popsize = POPSIZE_MULTIOBJ_GENCC;
        }
        if (strcmp(methodName,"nsga") == 0) {  
          popsize = POPSIZE_MULTIOBJ_NSGA;
        }
      }
    } else {
      popsize = gOption.paretosize;
    }
    if (popsize%4 != 0) {
      popsize = 4*(popsize/4+1);
    }
    popsize = min(popsize,MAX_POP);

    /* convergence */
    convergenceAccuracy = gOption.accuracy;
    convergeTestEval = gOption.convergetesteval;
    actualAccuracy = 1.0;
    convergenceFlag = FALSE;
    openBucketFlag = FALSE;
  
    /* initialize minSampleSize, sample size */
    /* sampleSize = popsize for generation 1 */
    /*            = minSampleSize for generations >= 2 */
    if (strcmp(methodName,"gencc") == 0) {
      minSampleSize = SAMPLE_MIN;
    }
    if (strcmp(methodName,"nsga") == 0) { 
      minSampleSize = popsize;
    }
    sampleSize = popsize; /* used for first generation */
/*eject*/
    if (nbin > 0) {
      printf(
        "\n  programs gencc/nsga do not handle binary variables\n");
      exit(1);
    }  
    /* define remaining parameters */
 
    ngen = maxEvaluationCount + 1; /* value is never reached */
    pmut_real = 1.0/(double) nreal;
    if (nobj == 1) {
      pcross_real = 0.9;
      eta_c = 20;
      eta_m = 20;
    } else {
      pcross_real = 0.9;
      eta_c = 20;
      eta_m = 20;
    }

    /* initialize mutation and crossover statistics */
    nbinmut = 0;
    nrealmut = 0;
    nbincross = 0;
    nrealcross = 0;
/*eject*/
    /* open files */
    fpt1 = fopen("initial_pop.out","w");
    fpt2 = fopen("final_pop.out","w");
    fpt3 = fopen("best_pop.out","w");
    fpt4 = fopen("all_pop.out","w");
    fpt5 = fopen("params.out","w");
    fprintf(fpt1,
       "# This file contains the data of initial sample\n");
    fprintf(fpt2,
       "# This file contains the data of final sample\n");
    fprintf(fpt3,
       "# This file contains the data of final feasible sample (if found)\n");
    fprintf(fpt4,
       "# This file contains the data of all iterations\n");
    fprintf(fpt5,
       "# This file contains information about inputs as read by the program\n");
    /* multi all feasible file; has obj values correct for "min" */
    /* "max" direction */
    sprintf(multiallfeasiblefile,"%s.allfeasible.multi",problemName);
    multiallfeasiblefil = fopen(multiallfeasiblefile,"w");
/*eject*/
    /* select gnuplot display */
    choice = 0;
    if (gOption.plotdetail >= 1) {
      if (nobj == 2) {
        choice = 1;
        obj1 = 1;
        obj2 = 2;
        obj3 = -1;
      } else if (nobj == 3) {
        choice = 3;
        obj1 = 1;
        obj2 = 2;
        obj3 = 3;
        angle1 = 60;
        angle2 = 30;
      }            
    }

/*    if (choice>0)   open gp unconditionally to eliminate
    {                 compiler warning */
        gp = popen(GNUPLOT_COMMAND,"w");
        if (gp==NULL)
        {
            printf("\n Could not open a pipe to gnuplot, check the definition of GNUPLOT_COMMAND in file global.h\n");
            printf("\n Edit the string to suit your system configuration and rerun the program\n");
            exit(1);
        }
/*    } open gp uncontionally */
/*eject*/
    if (gOption.printdetail == 2) {
      printf("\n Input Values \n");
    }
    fprintf(fpt5,"\n Sample size = %d",popsize);
    fprintf(fpt5,"\n Number of iterations = %d",ngen);
    fprintf(fpt5,"\n Number of objective functions = %d",nobj);
    fprintf(fpt5,"\n Number of constraints = %d",ncon);
    fprintf(fpt5,"\n Number of real variables = %d",nreal);
    if (nreal!=0)
    {
        for (i=0; i<nreal; i++)
        {
            fprintf(fpt5,"\n Lower limit of real variable %d = %e",
                    i+1,min_realvar[i]);
            fprintf(fpt5,"\n Upper limit of real variable %d = %e",
                         i+1,max_realvar[i]);
        }
        fprintf(fpt5,
                "\n Probability of crossover of real variable = %e",
                pcross_real);
        fprintf(fpt5,
                "\n Probability of mutation of real variable = %e",
                pmut_real);
        fprintf(fpt5,"\n Distribution index for crossover = %e",eta_c);
        fprintf(fpt5,"\n Distribution index for mutation = %e",eta_m);
    }
    fprintf(fpt5,"\n Number of binary variables = %d",nbin);
/*eject*/
    if (nbin!=0)
    {
        for (i=0; i<nbin; i++)
        {
            fprintf(fpt5,
              "\n Number of bits for binary variable %d = %d",
              i+1,nbits[i]);
            fprintf(fpt5,"\n Lower limit of binary variable %d = %e",
                         i+1,min_binvar[i]);
            fprintf(fpt5,"\n Upper limit of binary variable %d = %e",
                         i+1,max_binvar[i]);
        }
        fprintf(fpt5,
               "\n Probability of crossover of binary variable = %e",
               pcross_bin);
        fprintf(fpt5,
               "\n Probability of mutation of binary variable = %e",
               pmut_bin);
    }
    fprintf(fpt5,"\n Seed for random number generator = %e",seed);
    bitlength = 0;
    if (nbin!=0)
    {
        for (i=0; i<nbin; i++)
        {
            bitlength += nbits[i];
        }
    }
/*eject*/
    fprintf(fpt1,"# of objectives = %d, # of constraints = %d, # of real_var = %d, # of bits of bin_var = %d, constr_violation, rank, crowding_distance\n",nobj,ncon,nreal,bitlength);
    /* printing of ftp2 header is delayed to end of run so that */
    /* evaluation count can be included */
    fprintf(fpt3,"# of objectives = %d, # of constraints = %d, # of real_var = %d, # of bits of bin_var = %d, constr_violation, rank, crowding_distance\n",nobj,ncon,nreal,bitlength);
    fprintf(fpt4,"# of objectives = %d, # of constraints = %d, # of real_var = %d, # of bits of bin_var = %d, constr_violation, rank, crowding_distance\n",nobj,ncon,nreal,bitlength);
    fprintf(multiallfeasiblefil,"# Feasible records of all generations\n");
    fprintf(multiallfeasiblefil,"# of objectives = %d , # of constraints = %d , # of real_var = %d , constr_violation , rank , crowding_distance\n",
    nobj,ncon,nreal);

    /* generate and process initial population */

    randomize();
    initialize_pop (parent_pop);
    if (gOption.printdetail == 2) {
      printf("\n Initialization done");
      if (gOption.singleminout == TRUE) {
      printf(
      "\n Acceptance/rejection counts of initial population sample");
      printf("\n  Accepted = %5d", initPop.nAccept);
      printf("\n  Rejected = %5d", initPop.nReject);
      printf("\n  __________________");
      printf("\n  Total    = %5d", initPop.nTotal);
      }
      printf("\n\n Perform first iteration");
    }
    decode_pop(parent_pop); /* binary case only; not used */
/*eject*/
    /* evaluate_pop (parent_pop); */ 
    /* done now in initialize_pop using kmeans() */

    /* modification of constr_violation */
    /* initialize gradCon iteration */
    gradCon.iteration = 0;
    /* define gradCon scale[] using parent_pop*/
    defineGradConScale(parent_pop);
    /* modify constr_violation of parent_pop */
    modifyConstr(parent_pop);

    assign_rank_and_crowding_distance (parent_pop);
    report_pop (parent_pop, fpt1);
    fprintf(fpt4,"# iter = %d\n",generationCount);
    report_pop(parent_pop,fpt4);
    fprintf(multiallfeasiblefil,"# iter = %d\n",generationCount);
    report_external_feasible(parent_pop,multiallfeasiblefil);

    /* output statistics for first generation */
    getPopulationMinMax(parent_pop);
    if (gOption.printdetail == 2) {
      outputStats(parent_pop);
    }

    if (gOption.plotdetail == 2) {
      /* output all plots */
      if (choice!=0)    onthefly_display (parent_pop,gp,1);
    }
    fflush(fpt1);
    fflush(fpt2);
    fflush(fpt3);
    fflush(fpt4);
    fflush(fpt5);
    fflush(multiallfeasiblefil);
    sleep(1);
/*eject*/
   for (i=2; i<=ngen; i++)
    {
        if (gOption.slowmotion == TRUE) {
          sleep(1);
        }

        generationCount = i;

        /* feasibility test */
        curPopsize = popsize;
        flag = testFeasibleSolution(parent_pop);
        if (flag == TRUE) {
          /* have a feasible solution */
          if (strcmp(gOption.stopcriterion,"feasible") == 0) {
            /* gOption.stopcriterion = feasible, done */
            break; 
          } 
        }
/*eject*/
        /* convergence test */
        flag = decideConvergence(parent_pop);

        /* evaluate convergence result */
        if (nobj == 1) {
          if (flag == FALSE) {
            convergenceFlag = FALSE;
          } else {
            convergenceFlag++;
            if (convergenceFlag >= 10) {              
              if (gradCon.iteration >= gOption.gradualconstraint) {
                break;
              }
            }
          }
        } else { /* nobj >= 2 */
          if ((flag == TRUE) || 
              ((numberDominanceTestSequence%2 == 0) &&
               (numberDominanceTestSequence >= 
                MAX_DOMINANCETESTSEQ))) {
            convergenceFlag = TRUE;
            if (gradCon.iteration >= gOption.gradualconstraint) {
              printf("\n   convergence flag = %d",flag);
              printf("\n   number Dominance Test Sequence = %d",
                      numberDominanceTestSequence);
              break;
            }
          } else {
            convergenceFlag = FALSE;
          }
        }
/*eject*/
        if (i > 2) {
          /* redefine sampleSize */
          sampleSize = minSampleSize;
        }

        /* store parent population */
        curPopsize = popsize;
        nParentCandidates = 0;
        population2parentCandidate(parent_pop, 
                                   &nParentCandidates, TRUE);
        /* define scale and modify constr_violation of parent_pop */
        /* is only needed if i>2 due to initialization step */
        if (i > 2) {
          /* define gradCon scale[] using parent_pop*/
          defineGradConScale(parent_pop);
          /* if each gradCon.scale[j] = 1, have all points feasible */
          /* or for each j, all infeasibilities are identical */
          /* for either case, enforce all constraints fully */
          if (gradCon.iteration < gOption.gradualconstraint) {
            flag = TRUE;
            for (j=0; j<ncon; j++) {
              if (gradCon.scale[j] != 1.0) {
                flag = FALSE;
                break;
              }
            }
          }         
          if (flag == TRUE) {
            gradCon.iteration = gOption.gradualconstraint;
          }
          /* modify constr_violation of parent_pop */
          modifyConstr(parent_pop);
        }

        selection (parent_pop, child_pop);
        mutation_pop (child_pop);
        decode_pop(child_pop); /* binary case only; not used */
        evaluate_pop(child_pop);

        /* modify constr_violation of child_pop */
        modifyConstr(child_pop);
        /* parent_pop and child_pop have same gradual constraints */
        /* update gradCon iteration */
        gradCon.iteration++;
/*eject*/
        merge (parent_pop, child_pop, mixed_pop);
        fill_nondominated_sort (mixed_pop, parent_pop);
        /* Comment following four lines if information for all
        generations is not desired, it will speed up the execution */
        fprintf(fpt4,"# iter = %d\n",generationCount);
        report_pop(parent_pop,fpt4);
        fflush(fpt4);
        fprintf(multiallfeasiblefil,"# iter = %d\n",generationCount);
        report_external_feasible(parent_pop,multiallfeasiblefil);
        fflush(multiallfeasiblefil);

        /* output statistics for generation */
        getPopulationMinMax(parent_pop);
        if (gOption.printdetail == 2) {
          outputStats(parent_pop);
        }
        if (gOption.plotdetail == 2) {
          /* output all plots */     
          if (choice!=0)    onthefly_display (parent_pop,gp,i);
        }
        /* check for termination: */
        /* evaluation count and stalled generation count */
        if ((evaluationCount >= maxEvaluationCount-popsize/2) ||
            (stalledGenerationCount >= STALLEDGENERATION_MAX)) {
          if (gradCon.iteration >= gOption.gradualconstraint) {
            printf("\n stalled Generation Count = %d",
                   stalledGenerationCount);
            break;
          }
        }
        /* stop if user command = "stop generation" */
        if (Xmulticontrol("stop",
                          multicontrolfile) == TRUE) {
          break;
        }

    }  /* end for i */
/*eject*/
    /* compute correct obj and constr values for final population */
    /* reduce to all feasible and undominated, or one infeasible */
    flag = finalObjConstr(parent_pop);

    /* set sampleSize = final step evaluation count for output */
    /* set pickCount = sampleSize */
    sampleSize = finalStepEvaluationCount;
    pickCount = finalStepEvaluationCount;
    nEstimates = 0;
    /* output statistics for generation */
    getPopulationMinMax(parent_pop);
    if (gOption.printdetail == 2) {
      outputStats(parent_pop); 
    }
    /* caution: changed format of original nsga final_pop.out */
    /* to simplify parsing of record */
    fprintf(fpt2,"# of objectives = %d , # of constraints = %d , # of real_var = %d , constr_violation , rank , crowding_distance , # of evaluations = %d\n",
       nobj,ncon,nreal,evaluationCount);
    report_pop(parent_pop,fpt2);

    /* use flag defined above by finalObjConstr(parent_pop) to */
    /* decide feasibility */
    if (flag == FALSE) {
      /* termination without any feasible solution */
      /* print min and max of constraints in final_pop.out  */
      /* for analysis */
      fprintf(fpt2,
     "\n# infeasible case: constraints with internal min value < 0 ");
      fprintf(fpt2,
        "likely cause the infeasibility");

      for (j=0; j<ncon; j++) {
        if (minvalue.constr[j] < 0) {
          fprintf(fpt2,
             "\n# infeasible case: constr# = %d\tmin = %g\tmax = %g",
             j+1, minvalue.constr[j], maxvalue.constr[j]);
        }
      }
    }
    
    /* display population with correct obj and constr */
    if (gOption.plotdetail == 1) {
      /* display final plot with 'Result #1' */
      if (choice!=0)    onthefly_display (parent_pop,gp,1);
    } else if (gOption.plotdetail == 2) {
      /* display final plot with 'Result #i' */
      if (choice!=0)    onthefly_display (parent_pop,gp,i);
    }
    report_feasible(parent_pop,fpt3);
/*eject*/
    if (nreal!=0)
    {
        fprintf(fpt5,"\n Number of crossover of real variable = %d",
                     nrealcross);
        fprintf(fpt5,"\n Number of mutation of real variable = %d",
                     nrealmut);
    }    nbinmut = 0;
    nrealmut = 0;
    nbincross = 0;
    nrealcross = 0;
    if (nbin!=0)
    {
        fprintf(fpt5,"\n Number of crossover of binary variable = %d",
                     nbincross);
        fprintf(fpt5,"\n Number of mutation of binary variable = %d",
                     nbinmut);
    }
    fflush(stdout);
    fflush(fpt1);
    fflush(fpt2);
    fflush(fpt3);
    fflush(fpt4);
    fflush(fpt5);
    fflush(multiallfeasiblefil);
    fclose(fpt1);
    fclose(fpt2);
    fclose(fpt3);
    fclose(fpt4);
    fclose(fpt5);
    fclose(multiallfeasiblefil);
/*eject*/
/*    if (choice!=0)  close gp unconditionally since it was opened
    {                 unconditionally to eliminate compiler warning */
        pclose(gp);
/*    } close gp unconditionally */
    if (nreal!=0)
    {
        free (min_realvar);
        free (max_realvar);
    }
    if (nbin!=0)
    {
        free (min_binvar);
        free (max_binvar);
        free (nbits);
    }

    /* use popsize = MAX_POP for deallocation */
    popsize = MAX_POP;

    deallocate_memory_pop (parent_pop, popsize);
    deallocate_memory_pop (child_pop, popsize);
    deallocate_memory_pop (mixed_pop, 2*popsize);
    free (parent_pop);
    free (child_pop);
    free (mixed_pop);
    printf("\n Routine successfully exited \n");
/*eject*/
   /* stopping criterion and reason */
    printf("\n Stopping criterion: %s solution",
           gOption.stopcriterion);

    if (convergenceFlag >= 1) {
      printf("\n convergence after %5d vector evaluations",
             evaluationCount);
      if (nProcessors > 0) {
        printf("\n                   %5d cycle evaluations",
                readCycleCount());
      }
    } else {
      if (stalledGenerationCount >= STALLEDGENERATION_MAX) {
        printf("\n stalled generation count = %d",
               stalledGenerationCount);
      } else {
        printf("\n evaluation count = %d",
             evaluationCount);
      }
    }
/*eject*/
    /* caution statement about obj output */   
    if (nobjEvaluate != nobjSolve) {
      printf(
      "\n ***Caution***: obj values in output files for the ");
      printf(
      "\n                following objective function(s) only: ");
      for (j=0; j<nobjEvaluate; j++) {
        if (objFactor[j] != 0.0) {
          printf(
      "\n                 function %d",j+1);
        }
      }
    }

    /* flag is value of above finalObjConstr(parent_pop) call */
    /* flag = TRUE if output has feasible solution(s) */
    /*      = FALSE if output has one infeasible solution */
    if (flag == TRUE) {
      printf("\n best feasible solution(s) in final_pop.out\n");
    } else {
      printf(
          "\n warning: no feasible solution found");
      printf(
          "\n          best infeasible solution in final_pop.out\n");
    }

    if (gNumOpenFiles != 0) {
      printf(
      "\ngencc Error: mismatch of opened/closed files\n");
      exit(1);
    }

    return 0;

}
/*********last record of multicc.c *******************/
