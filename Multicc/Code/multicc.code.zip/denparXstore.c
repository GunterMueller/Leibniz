/* storage and retrieval of solutions and associated values */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "denpar.h"
/**************************************************************
 *
 * subroutines in this file:
 *       void   computeXcurrent_solution()
 *       double computeX(double *x)
 *       void   retainX(double *x);
 *       void   output_history(double *x)
 *       double retrieveXstore(double *x)
 *       int update_eps()
 **************************************************************/
/*eject*/
/**************************************************************
 *   void computeXcurrent_solution(): 
 *          for vector current_solution.point:
 *          compute or look up function, obj, constr[], viol 
 *
 *          retain current_solution.point, obj, constr, 
  *             viol in xstore[]
 **************************************************************/
void computeXcurrent_solution() {

  int lookup, n;

  n = nreal;

  if (current_solution.evaluated == TRUE) {
    return;
  }

  current_solution.function = 
     computeX(current_solution.point,&lookup);

  if ((lookup == TRUE) || (nProcessors == 0)) {
    /* computeX() has computed obj, constr[], viol */
    /* store these results */

    current_solution.obj = obj;
    vector2vector(constr,current_solution.constr,ncon);
    current_solution.viol = viol;

  } else {

    /* point is not in xstore[] and nProcessors >=1 */
    /* thus, computeX() has not computed any values */
    nParallelCandidates = 0;
    vector2parallelCandidate(current_solution.point,
                             nParallelCandidates,n);
    parallelCandidate[nParallelCandidates].keepFlag = FALSE;
    nParallelCandidates++;

    /* evaluate parallelCandidate[] */
    evaluate_parallelCandidate("denpar", TRUE);
    num_funct += nParallelCandidates;
    cycle.sum++;

    /* transfer parallelCandidate[0] to current_solution */
    extract_parallelCandidate(0,
                              current_solution.point,
                              &current_solution.function,
                              &current_solution.obj,
                              current_solution.constr,
                              &current_solution.viol);
    /* also computes obj, constr[], viol */
    /* store solution */
    retainX(current_solution.point);

  } /* end if lookup == TRUE) || nProcessors == 0,  else */

  current_solution.evaluated = TRUE;

  return;  

}
/**************************************************************
 *   double computeX(double *x, int *lookup):
 *      if x[] is in xstore array: 
 *         retrieve obj, constr[] viol
 *         return fmax = obj + penalty sum using current eps[] 
 *         *lookup = TRUE
 *      else:
 *         if nProcessors > 0:
 *           *lookup = FALSE
 *           return fmax = INF
 *         else : 
 *           compute directly with evaluateDenparVector(): obj, 
 *             constr[], viol
 *           return fmax = obj + penalty sum using current eps[]
 *           *lookup = FALSE
 *           retain solution in xstore[]
 **************************************************************/
double computeX(double *x, int *lookup) {

  int flag, i, k;
  double fmax;

  for (k=1; k<=nXstores; k++) {
    flag = TRUE;
    for (i=1; i<=nreal; i++) {
      if (x[i] != xstore[k].xreal[i]) {
        flag = FALSE;
        break;
      } 
    }    
    if (flag == TRUE) {
      /* have found xstore vector matching input vector x */
      obj = xstore[k].obj;
      for (i=1; i<=ncon; i++) {
        constr[i] = xstore[k].constr[i];
      }
      viol = xstore[k].constr_violation;
      /* compute fmax using current eps[] values */
      fmax = obj;
      for (i=1; i<=ncon; i++) {
        fmax += max(0.0,constr[i])/eps[i];
      }
      *lookup = TRUE;
      return fmax;
    }
  }

  /* x is not in Xstore */

  if (nProcessors >= 1) {
    *lookup = FALSE;
    return INF;
  }

  /* have nProcessors = 0 */
  /* compute values with evaluateDenparVector() and */
  /* store in xstore[] */
  obj = evaluateDenparVector(x);
      /* also computes constr[], viol */
  num_funct++;
  cycle.sum++;

  fmax = obj;
  for (i=1; i<=ncon; i++) {
    fmax += max(0.0,constr[i])/eps[i];
  }

  /* retain vector x, obj, constr, viol in xstore[] */
  retainX(x);
  *lookup = FALSE;
  return fmax;

}
/*eject*/
/**************************************************************
 *   output_history():
 *        output history of recent iterations
 *        information available for output:
 *           current_solution: all values 
 *           current:    num_funct, num_iter, cycle.sum
 *           previous:   num_funct_old, num_iter_old, cycle.old
 *           difference: num_funct_diff, num_iter_diff, cycle.diff
 *           (difference = current - previous)
 *        updates num_funct_old, num_iter_old, cycle.old
 **************************************************************/
void output_history() {

  /* int i; */

  /* update differences */
  num_funct_diff = num_funct - num_funct_old;
  num_iter_diff = num_iter - num_iter_old;
  cycle.diff = cycle.sum - cycle.old;

  /* if output is desired, must  */
  /*  - declare output1, output2 in denpar.h */
  /*  - open output1, output2 in denparmain() */
  /*  - activate write statements below as desired */
  /*  - close output1, output2 in denparmain() */
  /* see above summary for available data */

  /* fprintf(output1,
     "\nelapsed function evals = %d", num_funct_diff); 
    fprintf(output2,"\nelapsed eval cycles = %d", cycle.diff); 
   */

  /* for (i=1;i<=cycle.diff;i++) {
    if ((current_solution.obj > 1.e+32) || 
        (current_solution.viol > 1.e-6)){
      fprintf(output1,"            NaN\n");
    } else {
      fprintf(output1,"%15.6e\n",current_solution.obj);	
    }
  } 
  */

  /* update old values */
  num_funct_old = num_funct;
  num_iter_old = num_iter;
  cycle.old = cycle.sum;

  return;

}
/*eject*/
/**************************************************************
 *   retainX(double *x):
 *        retain input vector x, obj, constr, viol in xstore[]
 *        update bestobj, bestconstr[], bestxreal[]
 **************************************************************/
void retainX(double *x) {

  int i;

  if (nXstores < MAX_XSTORE) {
    nXstores++;
    pointXstore = nXstores;
  } else {
    /* storage is full; advance pointer */
    pointXstore++;
    if (pointXstore > MAX_XSTORE) {
    /* use pointer in circular fashion */
      pointXstore = 1;
    }
  }
  for (i=1; i<=nreal; i++) {
    xstore[pointXstore].xreal[i] = x[i];
  }
  xstore[pointXstore].obj = obj;
  for (i=1; i<=ncon; i++) {
    xstore[pointXstore].constr[i] = constr[i];
  }
  xstore[pointXstore].constr_violation = viol;

  /* update bestobj, bestconstr, bestxreal */
  if ((obj < bestobj) &&
      (viol == 0.0)) {
    /* have better feasible solution */
    bestobj = obj;
    for (i=1; i<=ncon; i++) {
      bestconstr[i] = constr[i];
    }
    for (i=1; i<=nreal; i++) {
      bestxreal[i] = x[i];
    }
  }

  return;

}
/*eject*/
/**************************************************************
 *   update_eps():
 *      check current_solution.constr[] violations
 *      possibly change penalty eps[]; if so, update
 *         current_solution.function
 *      return TRUE if eps[] changed; FALSE otherwise
 **************************************************************/
int update_eps() {

  int i;
  double cambio_eps, maxeps;

  /* check validity of current_solution */
  if (current_solution.evaluated == FALSE) {
    printf("\n update_eps: current_solution not evaluated");
    exit(1);
  }

  if ((current_solution.viol <= 0.0) || (ncon <= 0)) {
    /* no action if no violation */
    return FALSE;
  }
 
  cambio_eps = FALSE;
  maxeps = -INF;
  for (i=1; i<=ncon; i++) {
    maxeps = max(maxeps,eps[i]);
  }

  if ((iprint >= 1) && (iprint <= 9)) {
    printf("\n**************************************");
    printf("\n**************************************");
  }
/*eject*/       
  /* check each constraint for violation */
  for (i=1; i<=ncon; i++)  {        
    /* heuristic test to decide if eps[i] is too big 
     * eps[i] is decreased when 
     *     (**)   current_solution.constr[i] > alfa_max/eps[i] 
     * meaning of (**): 
     * 1. the test is surely not satisfied when 
     *    current_solution.constr[i] <= 0 (i-th constr is satisfied)
     * 2. max{alfa_d}/eps[i] is sort of a measure of 
     *    stationarity. Hence (**) checks 
     *    whether the violation of the ith constraint 
     *    is greater than current measure of stationarity
     *    this means that we are possibly approaching an 
     *    infeasible stationary point
     *    in that case we decrease the penalty param 
     */
    if (eps[i]*current_solution.constr[i] > 1.0e-2*alfa_max) { 
           /* orig. factor = 1.0; alt. factor = 1.0e-2 */
      eps[i] *= 1.e-2;
      if ((iprint >= 1) && (iprint <= 9)) {
        printf("\n*********** new eps[%d] = %g *************",
               i, eps[i]);
        fflush(stdout);
      }
      cambio_eps = TRUE;
    }
  }
  if ((iprint >= 1) && (iprint <= 9)) {
    printf("\n**************************************");
    printf("\n**************************************");
  }
/*eject*/
  /* check that eps[] > 0 */
  for (i=1; i<=ncon; i++) {
    if (eps[i] <= 0) {
      printf("\n computeX: eps[%d] = %g, but must be > 0\n",
             i, eps[i]);
      exit(1);
    }
  }

  if (cambio_eps == TRUE) {
    /* recompute current_solution.function using new eps[] */
    current_solution.function = current_solution.obj;
    for (i=1; i<=ncon; i++) {
      if (eps[i] <= 0.0) {
        printf("\n denpar: error, eps[%d] = %g <= 0.0",i,eps[i]);
        exit(1);
      }
      current_solution.function += 
          max(0.0,current_solution.constr[i])/eps[i];
    }
  }

  return cambio_eps;

}
/********** last record of denparXstore.c **************/
