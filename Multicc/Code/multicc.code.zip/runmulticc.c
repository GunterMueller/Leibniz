/* run multicc test cases */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

/************************************************************
 *  subroutines in this file:
 *    int main program for runmulticc
 *       execution: runmulticc add or new 
 *                             <totaleval>
 *                             <maxitereval> 
 *                             <skipeval> 
 *                             <finalname>
 *         add: add results to existing files for algorithms
 *         new: delete any old results of existing algorithms
 *              before storing new results
 *         totaleval = total number of evaluations used
 *                     by all methods of one run
 *         maxitereval = max number of evaluations during each
 *                     iteration when a method is executed
 *                     if skipeval < 0: maxitereval applies only
 *                                      to iterations 2, 3, ...
 *         skipeval:
 *           if >= 0: all methods have maxitereval bound
 *             on number of evaluations
 *             first skipeval records are omitted from output
 *          if < 0: method 1 has (-skipvalue) as max eval count 
 *            and always uses option "-processor NOPROCFILE"
 *            methods 2, 3, ., nalgs have maxitereval bound
 *               on number of evaluations
 *            first (-skipeval) records are omitted from output
 *        final name: output  = final\ name.txt
 *
 *        execution of methods:
 *        if skipeval >= 0: methods 1, 2, .. are executed in
 *           round-robin fashion until convergence is achieved or 
 *           totaleval/maxitereval methods have been executed
 *        i skipeval < 0: first, method 1 is executed with 
 *           number of evaluations bounded by (-skipvalue)
 *           then methods 2, 3, ... are executed in
 *           round-robin fashion until convergence is achieved or 
 *           totaleval/maxitereval methods have been executed
 *                  
 *    void transferResult(char *inputfile, char *outputfile)
 ************************************************************/
/*eject*/ 
#define MAXLEN 15000
#define MAX_ENTRY 256
#define TRUE 1
#define FALSE 0

#define INFF 1.0e+100

#define MAX_ALGORITHM 20

/********* global variables ********/
/* evaluation counts */
int totaleval;
int skipeval;
int maxiter, maxitereval, maxfirstitereval;
/* final name for entire output */
char finalname[MAX_ENTRY];
/* best solution */
char bestrecord[MAXLEN];
double bestvalue;
/* tokens obtained from records */
char token[MAX_ENTRY][MAX_ENTRY];
int nTokens;

/********* subroutines ********/
int tokenize(char *lineread);
void transferResult(char *inputfile, char *outputfile, int nlimit);
/*eject*/
/*********** main program **********/

int main (int argc, char **argv) {

  int j, newflag;
  int nalgs, nprocs;

  char lineread[MAXLEN];
  char addcmnd[MAX_ENTRY], cmnd[MAXLEN];
  char oneline[MAXLEN];
  char addline[MAX_ENTRY];

  char algorithm[MAX_ALGORITHM][MAX_ENTRY], 
       problemName[MAX_ENTRY], 
       processor[MAX_ENTRY];

  char finalfile[MAX_ENTRY], 
       inputfile[MAX_ENTRY], 
       outputfile[MAX_ENTRY];

  char algorithmfile[MAX_ENTRY];
  char bestsolutionfile[MAX_ENTRY];
  char problemfile[MAX_ENTRY];
  char processorfile[MAX_ENTRY];
  FILE *algorithmfil;
  FILE *bestsolutionfil;
  FILE *problemfil;
  FILE *processorfil;
/*eject*/
  if (argc != 6) {
    printf("\n Usage: ./runmulticc 'add'/'new'  <totaleval> ");
    printf("<maxitereval> <skipeval> <finalname>\n");
    exit(1);
  }
  if (strcmp(argv[1],"new") == 0) {
    newflag = TRUE;
  } else if (strcmp(argv[1],"add") == 0) {
    newflag = FALSE;
  } else {
    printf("runmulticc: first argument is %s ", argv[1]);
    printf("but must be 'add' or 'new'");
    exit(1);
  }
  totaleval = atoi(argv[2]);
  maxitereval = atoi(argv[3]);
  skipeval = atoi(argv[4]);
  strcpy(finalname,argv[5]);

  /* DEBUG begin: comment out above code involving argc */
  /*              and activate below */
/*
  newflag = TRUE;
  totaleval = 1000;
  maxitereval = 100;
  skipeval =  -50;
  sprintf(finalname,"debug.run");
*/
  /* DEBUG end */
/*eject*/
  printf("\n Input arguments:\n   zip files: ");
  if (newflag == TRUE) {
    printf("new");
  } else {
    printf("add");
  }
  printf("\n   total evaluations = %d",totaleval);
  printf("\n   max iter evaluations = %d",maxitereval);    
  printf("\n   skip evaluations  = %d",skipeval);
  printf("\n     first |skipeval| records are omitted from output");
  printf("\n   final name        = %s",finalname); 
/*eject*/   
  /* derive skiptfirsteval from skipeval */
  /* change sign of skipeval if skipeval < 0 */
  if (skipeval >= 0) {
    maxfirstitereval = 0;
  } else {
    skipeval *= -1;
    maxfirstitereval = skipeval;
  }

  /* compute maxiter */
  /* do not round up the ratio totaleval/maxitereval to make sure */
  /* that the totaleval limit on evaluations is never exceeded */
  maxiter = totaleval/maxitereval;
  if (maxfirstitereval > 0) {
    /* increment maxiter for use of the initial method, which is    
     * limited to maxfirstitereval evaluations
     * these evaluations are not counted toward the totaleval limit
     * the initial method is not used in the round-robin process 
     */
    maxiter++;
  }

  /* define and remove <finalname>.runmulticc.zip file */
  sprintf(finalfile,"%s.runmulticc.zip",finalname);
  sprintf(cmnd,"rm -f %s",finalfile);
  if (system(cmnd) != 0) {
    printf
      ("\n runmulticc: execution of remove command %s failed #1\n",
       cmnd);
    exit(1);
  }
/*eject*/
  strcpy(algorithmfile,"runmulticc.algorithm");
  strcpy(bestsolutionfile,"runmulticc.bestsolution");
  strcpy(problemfile,"runmulticc.problem");
  strcpy(processorfile,"runmulticc.processor");

  /* open best solution file */
  if ((bestsolutionfil = fopen(bestsolutionfile,"w")) == NULL) {
     printf("\n runmulticc: cannot open file %s\n",bestsolutionfile);
     exit(1);
  }

  /* get processor instances */
  if ((processorfil = fopen(processorfile,"r")) == NULL) {
     printf("\n runmulticc: cannot open file %s\n",processorfile);
     exit(1);
  }

  while (fgets(lineread,MAXLEN,processorfil) != NULL) { /* while #1 */

    if ((lineread[0] == '\0') || 
        (lineread[0] == '#') ||
        (tokenize(lineread) == 0)) {
      continue;
    }
    /* get name of processor list */
    /* "NOPROCFILE" means that the processor running multicc */
    /* also evaluates all vectors */
    strcpy(processor,token[0]);
    if (strcmp(processor,"NOPROCFILE") == 0) {
      nprocs = 0;
    } else {
      sscanf(processor,"list.processor.%d",&nprocs);
      if (nprocs <= 0) {
        printf("\n runmulticc: list.processor.n file name %s ",
               processor);
        printf("must have n >= 1, but have n = %d",nprocs);
        exit(1);
      }
    }
/*eject*/
    /* get algorithm instances */
    if ((algorithmfil = fopen(algorithmfile,"r")) == NULL) {
       printf("\n runmulticc: cannot open file %s\n",algorithmfile);
       exit(1);
    }

    while (fgets(lineread,MAXLEN,algorithmfil) != NULL) {
                                                   /* while #2 */
      if ((lineread[0] == '\0') || 
          (lineread[0] == '#') ||
          (tokenize(lineread) == 0)) {
        continue;
      }
      if (nTokens > MAX_ALGORITHM) {
        printf("\n runmulticc: must increase MAX_ALGORITHM = %d ",
               MAX_ALGORITHM);
        printf("to at least %d",nTokens);
        exit(1);
      }
      /* store algorithms */
      for (j=0; j<nTokens; j++) {
        strcpy(algorithm[j],token[j]);
      }
      nalgs = nTokens;
      /* check that nalgs >= 2 when maxfirstitereval > 0 */
      if ((nalgs <= 1) && (maxfirstitereval > 0)) {
        printf("\n runmulticc: algorithm case = %s ",lineread);
        printf("specifies just one algorithm");
        printf("\n then input skipeval = %d < 0 ",-skipeval);
        printf("would produce not output\n");
        exit(1);
      }
/*eject*/
      /* if "new" option: remove old zip file for this */
      /* algorithm and processor combination */
      if (newflag == TRUE) {
        sprintf(cmnd,"rm -f %s.",algorithm[0]);
        for (j=1; j<nalgs; j++) {
        sprintf(addcmnd,"%s.",algorithm[j]);
        strcat(cmnd,addcmnd);   
        }
        sprintf(addcmnd,"%s.result.zip",processor);
        strcat(cmnd,addcmnd);
        if (system(cmnd) != 0) {
          printf
         ("\n runmulticc: execution of remove command %s failed #2\n",
          cmnd);
          exit(1);
        }
      }     
/*eject*/
      /* get problem instances */
      if ((problemfil = fopen(problemfile,"r")) == NULL) {
         printf("\n runmulticc: cannot open file %s\n",problemfile);
         exit(1);
      }
      while (fgets(lineread,MAXLEN,problemfil) != NULL) { 
                                                     /* while #3 */
        if ((lineread[0] == '\0') || 
            (lineread[0] == '#') ||
            (tokenize(lineread) == 0)) {
          continue;
        }       
        /* read problem name */
        strcpy(problemName,token[0]);
        /* assemble command */
        sprintf(cmnd,
           "/people/cs/k/klaus/Leibniz/Multicc/Code/multicc %s ",
           problemName);
        sprintf(addcmnd,
           "-input NOINPUTFILE -stopcriterion optimal ");
        strcat(cmnd,addcmnd);
        sprintf(addcmnd,
           "-singleminout 1 -maxiter %d -maxitereval %d ",
           maxiter, maxitereval);
        strcat(cmnd,addcmnd);
        if (maxfirstitereval > 0) {
          sprintf(addcmnd,
           "-maxfirstitereval %d ",maxfirstitereval);
          strcat(cmnd,addcmnd);
        }
        sprintf(addcmnd,
           "-sequenceminone nsga ");
        strcat(cmnd,addcmnd);
        for (j=0; j<nalgs; j++) {
          sprintf(addcmnd,"%s ",algorithm[j]);
          strcat(cmnd,addcmnd);
        }
        sprintf(addcmnd,"-processor %s ",processor);
        strcat(cmnd,addcmnd);
        sprintf(addcmnd,"-finalmesh 0.000001 ");
        strcat(cmnd,addcmnd);
/*eject*/
        /* execute command */
        if (system(cmnd) != 0) {
          printf
          ("\n runmulticc: execution of multicc command %s failed\n",
           cmnd);
          exit(1);
        }

        /* transfer output file from /dev/shm/<problemName> */
        /* to results file */

        /* define names of input and output files */
        sprintf(inputfile,"/dev/shm/%s/%s.singleminout",
                          problemName, problemName);
        sprintf(outputfile,"%s.",problemName);
        for (j=0; j<nalgs; j++) {
          sprintf(addcmnd,"%s.",algorithm[j]);
          strcat(outputfile,addcmnd);   
        }
        sprintf(addcmnd,"%s.result",processor);
        strcat(outputfile,addcmnd);

        /* transfer results from input file to output file */
        transferResult(inputfile, outputfile, 
                       totaleval+maxfirstitereval-skipeval);
/*eject*/
        /* add result file to zip files */
        /* first zip file: for case at hand */
        sprintf(cmnd,"zip ");
        for (j=0; j<nalgs; j++) {
          sprintf(addcmnd,"%s.",algorithm[j]);
          strcat(cmnd,addcmnd);   
        }
        sprintf(addcmnd,"%s.result.zip %s",processor,outputfile);
        strcat(cmnd,addcmnd);
        if (system(cmnd) != 0) {
          printf
            ("\n runmulticc: execution of zip command %s failed #1\n",
            cmnd);
          exit(1);
        }
        /* second zip file: for entire run */
        sprintf(cmnd,"zip %s ", finalfile);
        for (j=0; j<nalgs; j++) {
          sprintf(addcmnd,"%s.",algorithm[j]);
          strcat(cmnd,addcmnd);   
        }
        sprintf(addcmnd,"%s.result.zip",processor);
        strcat(cmnd,addcmnd);
        if (system(cmnd) != 0) {
          printf
            ("\n runmulticc: execution of zip command %s failed #2\n",
            cmnd);
          exit(1);
        }
/*eject*/
        /* output best solution */
        sprintf(oneline,"%s ",problemName);
        sprintf(addline,"%g ",bestvalue);
        strcat(oneline,addline);
        for (j=0; j<nalgs; j++) {
          sprintf(addline,"%s ",algorithm[j]);
          strcat(oneline,addline);
        }
        sprintf(addline,"%s ",processor);
        strcat(oneline,addline);
        /* uncomment below for optimal vector output */
        /* sprintf(addline,"%s ",bestrecord);
        strcat(oneline,addline); */
        printf("\n best value %s \n",oneline);
        fprintf(bestsolutionfil,"%s \n",oneline);     
/*eject*/
        /* remove input, output, params.multi, trajectory files */
        sprintf(cmnd,"rm -f %s", inputfile);
        if (system(cmnd) != 0) {
          printf
          ("\n runmulticc: execution of rm command %s failed #3\n",
           cmnd);
         exit(1);
        }
        sprintf(cmnd,"rm -f %s", outputfile);
        if (system(cmnd) != 0) {
          printf
          ("\n runmulticc: execution of rm command %s failed #4\n",
           cmnd);
         exit(1);
        }     
        sprintf(cmnd,"rm -f %s.params.multi", problemName);
        if (system(cmnd) != 0) {
          printf
          ("\n runmulticc: execution of rm command %s failed #5\n",
           cmnd);
         exit(1);
        }
        sprintf(cmnd,"rm -f %s.trajectory", problemName);
        if (system(cmnd) != 0) {
          printf
          ("\n runmulticc: execution of rm command %s failed #6\n",
           cmnd);
         exit(1);
        }

      } /* end while #3 */
      fclose(problemfil);

    } /* end while #2 */
    fclose(algorithmfil);

  } /* end while #1 */
  fclose(processorfil);

  fclose(bestsolutionfil);
/*eject*/
  sprintf(cmnd,"sort %s > %s.bestsolution.txt",
               bestsolutionfile, finalname);
  if (system(cmnd) != 0) {
    printf
    ("\n runmulticc: execution of sort command %s failed\n",
     cmnd);
    exit(1);
  }

  printf("\n sorted best solutions in %s.bestsolution.txt\n",
         finalname);

  /* remove *.result.zip files */
  sprintf(cmnd,"rm -f *.result.zip ");
  if (system(cmnd) != 0) {
    printf
    ("\n runmulticc: execution of rm command %s failed #7\n",
     cmnd);
   exit(1);
  }

  return 0;

}
/*eject*/
/**************************************************************
 * int tokenize(char *lineread): extract up to MAX_ENTRY
 * non-white-space strings from lineread[]
 * stops with error if a string has length >= MAX_ENTRY 
 * place strings into token[][];
 * defines nTokens = number of extracted tokens
 * process does not change lineread[]
 **************************************************************/
int tokenize(char *lineread) {

  int i, j;
  char saveread[MAXLEN];
  char *buffer;

  strcpy(saveread,lineread);

  /* strip off carriage return and whitespace */
  /* at end of the line */
  i = strlen(lineread) - 1;
  while (lineread[i]>=1 && lineread[i]<=32) {
    lineread[i] = '\0';
    i--;
  }
/*eject*/
  for (j=0; j<MAX_ENTRY; j++) {

    if (j == 0) {  
      buffer = strtok(saveread," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }

    if (buffer == NULL) {
      break;
    }

    if (strlen(buffer) >= MAX_ENTRY) {
      printf(
      "\n tokenize: lineread = %s contains too-large\n", lineread);
      printf(
      "\n token = %s with strlen >= %d \n", buffer, MAX_ENTRY);
      exit(1);
    }

    strcpy(token[j],buffer);

  } /* end for j */

  nTokens = j;

  return nTokens;

}
/*eject*/
/************************************************************
 * void transferResult(char *inputfile, char *outputfile, int nlimit)
 *    transfer input file to output file as follows:
 *    - eliminate comment '#' records
 *    - all records between successive "## cycle" records
 *      are reduced to one record
 *    - write that record into the output file unless it
 *      is dominated by the currently best record. In the latter
 *      case, write the currently best record instead.
 *    - stop if nlimit records have been written into the
 *      outputfile 
 *    - if less than total of nlimit records have been written
 *      into the output file when processing of the input file
 *      has been completed, fill in best record instances until a
 *      total of nlimit records have been placed into output file
 *
 ************************************************************/
void transferResult(char *inputfile, char *outputfile, int nlimit) {

  int i, nrec, neval;

  char lineread[MAXLEN];
  double value;
  
  FILE *inputfil;
  FILE *outputfil;

  /* open input and output files */
  if ((inputfil = fopen(inputfile,"r")) == NULL) {
     printf("\n transferResult: cannot open file %s\n",inputfile);
     exit(1);
  }
  if ((outputfil = fopen(outputfile,"w")) == NULL) {
     printf("\n transferResult: cannot open file %s\n",outputfile);
     exit(1);
  }  

  nrec = 0;
  neval = 0;
  bestvalue = INFF;
/*eject*/
  while (fgets(lineread,MAXLEN,inputfil) != NULL) { /* while #1 */
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    } 
    /* blank line, or comment '#' not equal to "## cycle" */ 
    if ((lineread[0] == '\0') || 
        ((lineread[0] == '#') && 
         (strncmp(lineread,"## cycle",8) != 0)  )) {
      continue;
    }

   /* "## cycle" line */
    if (strncmp(lineread,"## cycle",8) == 0) {
      /* have "## cycle" line */
      if (bestvalue != INFF) {
        /* line is not first "## cycle" */
        /* hence bestrecord[] is candidate for output file */
        if (neval > skipeval) {
          /* have encountered more than skipeval evaluations */
          /* write bestrecord[] into output file */
          fprintf(outputfil,"%s \n", bestrecord);
          nrec++;
          if (nrec >= nlimit) {
            break;
          }
        }
      }
    } else {
      /* have data record */
      /* update neval, bestvalue, bestrecord[] */
      neval++;
      sscanf(lineread,"%lg ", &value);
      if  (value < bestvalue) {
        bestvalue = value;
        strcpy(bestrecord,lineread);
      }
    } /* end if  (strncmp(lineread,"## cycle",8) == 0), else */  
    
  } /* end while #1 */
/*eject*/
  /* add bestrecord to get a total of nlimit records */ 
  while (nrec < nlimit) {
    fprintf(outputfil,"%s \n", bestrecord);
    nrec++;
  }

  fclose(inputfil);
  fclose(outputfil);

  return;

}
/*************** last record of runmulticc.c *****************/
