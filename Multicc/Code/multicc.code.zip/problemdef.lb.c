/* definition of problems */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"

/************************************************************
 *  subroutines in this file:
 *    void test_problem (int functionFlag, char *name, 
 *                       double *xreal, double *obj, double *constr)
 ************************************************************/
/*eject*/
/****************************************************************
 * test_problem (int functionFlag, char *name, double *xreal, 
 *                 double *obj, double *constr)
 *
 * functionFlag = TRUE: compute obj values
 *              = FALSE: define nreal, nint, nobj, ncon,
 *                         min_realvar[], max_realvar[]
 * Problem Name List
 *
 *  problems with at least one constraint:
 *  nobj = 2, ncon = 1: quad2con, ctp2-ctp7
 *  nobj = 2, ncon = 2: bnh, srn, tnk, ctp1, ctp8
 *  nobj = 3, ncon = 1: quad3con
 *
 *  nontrivial constrained cases when one objective function is used
 *  the cases labeled "hard" are relatively hard, but not really tough
 *  problem obj#  opt.value
 *  ctp2     2       0.294
 *  ctp3     2       0.536
 *  ctp7     1       0
 *  srn      2       -217.7
 *  tnk      2       0.006      * hard
 *  ctp1     2       0.549      * hard
 *  ctp8     1       0          * hard
 *  ctp8     2       1.40       * hard   
 *
 * from Giampaolo Liuzzi:
 *  elattar n = 6 variables,  nobj = 1, ncon = 0
 *  maxl_n  n >= 1 variables, nobj = 1, ncon = 0
 *
 * from http://www.norg.uminho.pt/aivaz/pswarm/%d",&nreal);
 * are stored in /people/cs/k/klaus/Leibniz/Gencc/Problems/Bounds
 *  gw_n (Griewank)
 *  mgw_n (Modified Griewank) CANNOT be solved by NSGA
 *  nf3_n (Neumaier 3) n >= 2 variables
 *  rb_n (Rosenbrock) n>=2 variables
 *  rg_n (Rastrigin) n >= 2 variables
 *  sin_n (Sinusoidal) n >= 2 variables
 *  st_9 
 *  xor
 *  zkv_n n>=2 variables
 *
 * Problems based on pairs of
 *   maxl_n, nf3_n, rg_n, sin_n, zkv_n, allowing n >= 1 variables.
 *   bounds have been adjusted to eliminate coincidence of optimal
 *   solutions
 *
 *   use defobj to specify obj case to be evaluated
 *   cases defobj = 0, 1 require objRange[0] > 0, objRange[1] > 0
 *                                   
 *   defobj = 0: define nobj = 1
 *               define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
 *                               (factor[0]/factor[1]) * obj[1]
 *               input command must omit -objRange option
 *          = 1: define nobj = 1
 *               define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
 *                                (factor[1]/factor[0]) * obj[0]
 *               input command must omit -objRange option
 *          = 2: define nobj = 2
 *               do not change obj[0], obj[1]
 *               input command must include option 
 *                     -objRange factor[0] factor[1]
 *
 * maxl.nf3_defobj_n
 * maxl.rg_defobj_n
 * maxl.sin_defobj_n
 * maxl.zkv_defobj_n  (for n = 20, is same as maxzkv)
 * nf3.rg_defobj_n
 * nf3.sin_defobj_n
 * nf3.zkv_defobj_n
 * rg.sin_defobj_n
 * rg.zkv_defobj_n
 * sin.zkv_defobj_n
 *
 * 
 *  problem with two difficult objs:
 *  maxzkv derived from maxl and zkv_20 above, is used in
 *  paper on seeding; is same as maxl.zkv_20
 *
 *
 * from http://www-optima.amp.i.kyoto-u.ac.jp/member/student/hedar/Hedar_files/TestGO_files/Page364.htm
 * has constrained and unconstrained problems
 *  branin
 *  hartman_3
 *  hartman_6
 *
 *
 * quadratic minimization, unconstrained except for quad2con cases
 *  quad_n      quadratic minimization, n>=2 variables
 *  quadint_n_m quad_n, with m variables integer, m <= n >= 2
 *  quadmax_n_m quad_n, for m variables want max, m <= n >= 2
 *  quad2_n_d   2 quad_n functions, shifted by +d and -d, n>= 2
 *  quad2con_n_d   2 quad_n functions, shifted by +d and -d, n>= 2
 *                 1 linear constraint near 0 
 *  quad3_n_d   3 quad_n functions, shifted by 0, +d, -d, n>= 2
 *  quad3con_n_d   3 quad_n functions, shifted by 0, +d, -d, n>= 2
 *                 1 linear constraint near 0
 *
 *
 *  from: K. Sindhya, K. Deb, K. Miettinen, "Improving convergence
 *  of evolutionary multi-objective optimization with local search:
 *  a concurrent-hybrid algorithm
 *  WRP (Water Resource Planning)
 *    2 variables
 *    3 objective functions
 *    lower and upper bounds
 *  WELD (Welded Beam Design) 
 *    CAUTION: has formulation error, is infeasible
 *             is a good test for handling of infeasibility
 *    4 variables
 *    2 objective functions
 *    4 constraints
 *    lower and upper bounds 
 *
 *
 * problems supplied with NSGA-II
 *  sch1
 *  sch2
 *  fon
 *  kur
 *  pol
 *  vnt
 *  zdt1
 *  zdt2
 *  zdt3
 *  zdt4
 *  zdt5
 *  zdt6
 *  bnh
 *  osy
 *  srn
 *  tnk
 *  ctp1
 *  ctp2
 *  ctp3
 *  ctp4
 *  ctp5
 *  ctp6
 *  ctp7
 *  ctp8
 *  dltz1
 *
 ****************************************************************/
void test_problem (int functionFlag, char *name, double *xreal, 
                   double *obj, double *constr) {

  int defobj;
  double factor[2];

  int i, j, k, m, n;
  double a, b, c, d, e, f, g, h, ell, pc, tt;
  double tau, tau1, tau2, sigma;
  double u, v, w[61], p1, p2, p3, pl[61], z; 
  double x[MAX_VARIABLE+1]; 
  double A[5][7], C[5], P[5][7], s, sm, y;
  double H[MAX_VARIABLE+1][MAX_VARIABLE+1];

  double app[103];
  double yy[52], t[52];

  if (functionFlag == TRUE) {
    evaluationCount++;
  }

  /* Test problem elattar
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1,2
    
    Global minimum: x* = ?
                    f(x*) < 4.0
    */

  if (strncmp(name,"elattar",7) == 0)

  {    
    if (functionFlag == FALSE) {
     nreal = 6;
     nint = 0;
     nobj = 1;
     ncon = 0;
     min_realvar = (double *)malloc(nreal*sizeof(double));
     max_realvar = (double *)malloc(nreal*sizeof(double));
     for (j=0; j<nreal; j++) {
       min_realvar[j] = -100;
       max_realvar[j] =  100;
     }
     return;       
    } 
    n = nreal;
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1]; 
    }   
    for (i=1; i<=51; i++) {
      t[i] = ((double)(i) - 1.0) / 10.0;
      yy[i] = exp(t[i])/2.0 - exp(-2.0*t[i]);
      yy[i] += exp(-3.0*t[i])/2.0;
      yy[i] += 1.5*exp(-1.5*t[i])*sin(7.0*t[i]);
      yy[i] += exp(-2.5*t[i])*sin(5.0*t[i]);
      app[i] = x[1]*exp(-x[2]*t[i])*cos(x[3]*t[i] + x[4]);
      app[i] += x[5]*exp(-x[6]*t[i]) - yy[i];
    }
    for(i=52; i<=102; i++) {
      app[i] = -app[i-51];
    }
    obj[0] = app[1];
    for (i=2; i<=102; i++) {
      obj[0] = max(obj[0],app[i]);
    }  
    return;
  }

  /* Test problem maxl_n
    # of real variables = n
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −50 ≤ xj ≤ 100, j = 1,2
    
    Global minimum: x* = 0
                    f(x*) = 0
    */

  if (strncmp(name,"maxl_",5) == 0)

  {    
    if (functionFlag == FALSE) {
     sscanf(name,"maxl_%d",&nreal);
     nint = 0;
     nobj = 1;
     ncon = 0;
     min_realvar = (double *)malloc(nreal*sizeof(double));
     max_realvar = (double *)malloc(nreal*sizeof(double));
     for (j=0; j<nreal; j++) {
       min_realvar[j] = -50;
       max_realvar[j] = 100;
     }
     return;       
    }
    sscanf(name,"maxl_%d",&n);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    } 
    f = 0.0;
    for(i=1; i<=n; i++) {
      f = max(f,fabs(x[i]));
    }
    obj[0] = f;
    return;
  }

   /* Test problem gw_n
    # of real variables = n
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −600 ≤ xj ≤ 600, j = 1, ..., 10
    
    Global minimum: x* = 0
                    f(x*) = 0
    */

  if (strncmp(name,"gw_",3) == 0)

  {    
    if (functionFlag == FALSE) {
     sscanf(name,"gw_%d",&nreal);
     nint = 0;
     nobj = 1;
     ncon = 0;
     min_realvar = (double *)malloc(nreal*sizeof(double));
     max_realvar = (double *)malloc(nreal*sizeof(double));
     for (j=0; j<nreal; j++) {
       min_realvar[j] = -600;
       max_realvar[j] =  600;
     }
     return;       
    } 
    sscanf(name,"gw_%d",&n);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1]; 
    }   
    obj[0] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += x[i]*x[i];
    }
    obj[0] /= 4000.0;
    obj[0] += 1.0;
    a = 1.0;
    for (i=1; i<=n; i++) {
      a *= cos(x[i]/sqrt((double) i));
    }   
    obj[0] -= a;   
    return;
  }

   /* Test problem mgw_n
    # of real variables = n
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −10 ≤ xj ≤ 10, j = 1, ..., 10
    
    Global minimum: x* = 0
                    f(x*) = 0
    */

  if (strncmp(name,"mgw_",4) == 0)

  {    
    if (functionFlag == FALSE) {
     sscanf(name,"mgw_%d",&nreal);
     nint = 0;
     nobj = 1;
     ncon = 0;
     min_realvar = (double *)malloc(nreal*sizeof(double));
     max_realvar = (double *)malloc(nreal*sizeof(double));
     for (j=0; j<nreal; j++) {
       min_realvar[j] = -10;
       max_realvar[j] =  10;
     }
     return;       
    } 
    sscanf(name,"mgw_%d",&n);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }

    for (i=1; i<=n; i++) {
      for (j=1; j<=n; j++) {
        if (i<=n/2) {
          H[i][j] = 1;
        } else {
          if (j<=n/2) {
            H[i][j] = 1/sqrt(2);
          } else {
            H[i][j] = -1/sqrt(2);
          }
        }
      }
    }
   
    obj[0] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += pow(x[i],2);
    }
    obj[0] /= 4000.0;
    

    for (i=1; i<=n; i++) {
      a = 0;
      for (j=1; j<=n; j++) {
        a += H[i][j]*x[j];
      }
      obj[0] -= log10(2+cos(a)); 
    }   

    obj[0] += ((double)n)*log10(3);
     
    return;
  }

  /* Test problem nf3_n
    # of real variables = n
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −n^2 ≤ xj ≤ n^2 , j = 1, 2
    
    Global minimum: x* = (?)
                    f(x*) = ?
    */

  if (strncmp(name,"nf3_",4) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"nf3_%d",&nreal);
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -pow((double)nreal,2);
        max_realvar[j] =  pow((double)nreal,2);
      }
      return;       
    }
    sscanf(name,"nf3_%d",&n);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }   
    obj[0] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += pow(x[i]-1,2);
    }
    for (i=2; i<=n; i++) {
      obj[0] -= x[i]*x[i-1];
    }
    return;
  }


  /* Test problem rb_n
    # of real variables = n
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −30 ≤ xj ≤ 30 , j = 1, 2
    
    Global minimum: x* = (1,1,...,1)
                    f(x*) = 0
    */

  if (strncmp(name,"rb_",3) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"rb_%d",&nreal);
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -30;
        max_realvar[j] = 30;
      }
      return;       
    }
    sscanf(name,"rb_%d",&n);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }   
    obj[0] = 0.0;
    for (i=1; i<=n-1; i++) {
      obj[0] += 100*pow(x[i+1]-x[i]*x[i],2) + pow(x[i]-1,2);
    }
    return;
  }

  /* Test problem rg_n (formulation of "Self-Adaptive .." 
                        by Deb, Karthik, Okabe)
    # of real variables = n
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −5.12 ≤ xj ≤ 5.12 , j = 1, 2
    
    Global minimum: x* = (0,0,...,0)
                    f(x*) = 0
    */

  if (strncmp(name,"rg_",3) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"rg_%d",&nreal);
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -5.12;
        max_realvar[j] = 5.12;
      }
      return;       
    }
    sscanf(name,"rg_%d",&n);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }   
    obj[0] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += x[i]*x[i] + 10*(1-cos(2*PI*x[i]));
    }
    return;
  }

  /* Test problem sin_n
    # of real variables = n
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: 0 ≤ xj ≤ 180 , j = 1,..., n
    
    Global minimum: x* = (0,0,...,0)
                    f(x*) = -3.5
    */

  if (strncmp(name,"sin_",4) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"sin_%d",&nreal);
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 180;
      }
      return;       
    }
    sscanf(name,"sin_%d",&n);
    a = 2.5;
    b = 5;
    z = 30;
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }   
    obj[0] = 0.0;
    f = a;
    for (i=1; i<=n ; i++) {
      f *= sin((x[i]-z)*PI/180);
    }
    obj[0] -= f;
    f = 1.0;
    for (i=1; i<=n ; i++) {
      f *= sin(b*(x[i]-z)*PI/180);
    }
    obj[0] -= f;
    return;
  }

  /* Test problem st_9
    # of real variables = 9
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −256.0 ≤ xj ≤ 256.0 , j = 1,..., 9
    
    Global minimum: x* = (?)
                    f(x*) = 0.0
   */

  if (strncmp(name,"st_9",4) == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 9;
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -256.0;
        max_realvar[j] = 256.0;
      }
      return;       
    }
    n = 9;
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }
    d = 72.661;
    m = 60;

    u = 0.0;
    for (i=1; i<=n; i++) {
      u += pow(1.2,(n-i))*x[i];
    }

    v = 0.0;
    for (i=1; i<=n; i++) {
       v += pow(-1.2,(n-i))*x[i];
    }

    for (j=0; j<=m; j++) {
      w[j] = 0.0;
      for (i=1 ;i<=n; i++) {
        w[j] += pow((2*j)/m-1,(n-i))*x[i];
      }
    }

    if (u<d) {
      p1 = pow(u-d,2);
    } else {
      p1 = 0.0;
    }

    if (v<d) {
      p2 = pow(v-d,2);
    } else {
      p2 = 0.0;
    }

    for (j=0; j<=m; j++) {
      if (w[j]>1) {
        pl[j] = pow(w[j]-1,2);
      } else if (w[j]<-1) {
        pl[j] = pow(w[j]+1,2);
      } else {
        pl[j] = 0.0;
      }
    }

    p3 = 0.0;
    for (j=0; j<=m; j++) {
      p3 += pl[j];
    } 
   
    obj[0] = p1 + p2 + p3;

    return;
  }

  /* Test problem xor
    # of real variables = 9
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −1.0 ≤ xj ≤ 1.0 , j = 1,..., 9
    
    Global minimum: x* = (?)
                    f(x*) = 0.867
    */

  if (strncmp(name,"xor",3) == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 9;
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -1.0;
        max_realvar[j] = 1.0;
      }
      return;       
    }
    n = 9;
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }   
    obj[0] = pow(1+exp(-x[7]/(1+exp(-x[1]-x[2]-x[3]))-x[8]/(1+exp(-x[3]-x[4]-x[6]))-x[9]),-2)
    +pow(1+exp(-x[7]/(1+exp(-x[5]))-x[8]/(1+exp(-x[6]))-x[9]),-2)
    +pow(1-pow(1+exp(-x[7]/(1+exp(-x[1]-x[5]))-x[8]/(1+exp(-x[3]-x[6]))-x[9]),-1),2)
    +pow(1-pow(1+exp(-x[7]/(1+exp(-x[2]-x[5]))-x[8]/(1+exp(-x[4]-x[6]))-x[9]),-1),2);
    return;
  }

   /* Test problem zkv_n, n >=2 (typical cases: 2, 5, 10, 20)
    # of real variables = n
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −5 ≤ xj ≤ 10, j = 1, ..., n
    
    Global minimum: x* = 0
                    f(x*) = 0
    */

  if (strncmp(name,"zkv_",4) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"zkv_%d",&nreal);
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -5;
        max_realvar[j] = 10;
      }
      return;       
    }
    sscanf(name,"zkv_%d",&n);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }   
    obj[0] = 0.0;
    for (j=1; j<=n; j++) {
      obj[0] += pow(x[j],2);
      obj[0] += pow(0.5*((double)j)*x[j],2);
      obj[0] += pow(0.5*((double)j)*x[j],4);
    }    
    return;
  }

  /* Test problem maxl.nf3_defobj_n
         uses versions of maxl_n and nf3_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"maxl.nf3_",9) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"maxl.nf3_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"maxl.nf3_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 1;
        factor[1] = 5;
      } else if (n == 20) {
        factor[0] = 1;
        factor[1] = 100; 
      } else if (n == 30) {
        factor[0] = 1;
        factor[1] = 1000;
      } else {
        printf("\n test_problem: maxl.nf3 undefined factor case");
        exit(1);
      }
    }
    /* maxl computation */
    for (i=1; i<=n; i++) {
      x[i] = (3.0/4.0)*xreal[i-1] + 25.0;
    } 
    f = 0.0;
    for(i=1; i<=n; i++) {
      f = max(f,fabs(x[i]));
    }
    obj[0] = f;
    /* nf3 computation */
    for (i=1; i<=n; i++) {
      x[i] = (1/100.0)*((double)n)*((double)n)*xreal[i-1];
    }   
    f = 0.0;
    for (i=1; i<=n; i++) {
      f += pow(x[i]-1,2);
    }
    for (i=2; i<=n; i++) {
      f -= x[i]*x[i-1];
    }
    obj[1] = f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) { 
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }
    return;
  }    

  /* Test problem maxl.rg_n
         uses versions of maxl_n and rg_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"maxl.rg_",8) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"maxl.rg_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"maxl.rg_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 1;
        factor[1] = 5;
      } else if (n == 20) {
        factor[0] = 1;
        factor[1] = 5; 
      } else if (n == 30) {
        factor[0] = 1;
        factor[1] = 10;
      } else {
         printf("\n test_problem: maxl.rg undefined factor case");
         exit(1);
      }
    }
    /* maxl computation */
    for (i=1; i<=n; i++) {
      x[i] = (3.0/4.0)*xreal[i-1] + 25.0;
    } 
    f = 0.0;
    for(i=1; i<=n; i++) {
      f = max(f,fabs(x[i]));
    }
    obj[0] = f;
    /* rg computation */
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1]/25.0 - 1.0;
    }   
    f = 0.0;
    for (i=1; i<=n; i++) {
      f += x[i]*x[i] + 10*(1-cos(2*PI*x[i]));
    }
    obj[1] = f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }
    return;
  }

  /* Test problem maxl.sin_n
         uses versions of maxl_n and sin_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"maxl.sin_",9) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"maxl.sin_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"maxl.sin_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 50;
        factor[1] = 1;
      } else if (n == 20) {
        factor[0] = 50;
        factor[1] = 1; 
      } else if (n == 30) {
        factor[0] = 50;
        factor[1] = 1;
      } else {
         printf("\n test_problem: maxl.sin undefined factor case");
         exit(1);
      }
    }
    /* maxl computation */
    for (i=1; i<=n; i++) {
      x[i] = (3.0/4.0)*xreal[i-1] + 25.0;
    } 
    f = 0.0;
    for(i=1; i<=n; i++) {
      f = max(f,fabs(x[i]));
    }
    obj[0] = f;
    /* sin computation */
    a = 2.5;
    b = 5;
    z = 30;
    for (i=1; i<=n; i++) {
      x[i] = (xreal[i-1]+100.0) * 0.9;
    }   
    obj[1] = 0.0;
    f = a;
    for (i=1; i<=n ; i++) {
      f *= sin((x[i]-z)*PI/180);
    }
    obj[1] -= f;
    f = 1.0;
    for (i=1; i<=n ; i++) {
      f *= sin(b*(x[i]-z)*PI/180);
    }
    obj[1] -= f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }
    return;
  }

  /* Test problem maxl.zkv_n
         uses versions of maxl_n and zkv_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −50 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"maxl.zkv_",9) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"maxl.zkv_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -50;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"maxl.zkv_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 1;
        factor[1] = 100;
      } else if (n == 20) {
        factor[0] = 1;
        factor[1] = 1000; 
      } else if (n == 30) {
        factor[0] = 1;
        factor[1] = 50000;
      } else {
         printf("\n test_problem: maxl.zkv undefined factor case");
         exit(1);
      }
    }
    /* computation specialized to avoid similarity of optimal */
    /* solutions; for n = 20, is same as problem maxzkv */
    /* maxl computation */
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1] + 10.0; /* 10.0 = shift to make problem */
                                /* more difficult */
    } 
    f = 0.0;
    for(i=1; i<=n; i++) {
      f = max(f,fabs(x[i]));
    }
    obj[0] = f;
    /* zkv computation */
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1]/10.0;
    }   
    f = 0.0;
    for (j=1; j<=n; j++) {
      f += pow(x[j],2);
      f += pow(0.5*((double)j)*x[j],2);
      f += pow(0.5*((double)j)*x[j],4);
    }
    obj[1] = f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }    
    return;
  }

  /* Test problem nf3.rg_n
         uses versions of nf3_n and rg_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"nf3.rg_",7) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"nf3.rg_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"nf3.rg_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 1;
        factor[1] = 1;
      } else if (n == 20) {
        factor[0] = 50;
        factor[1] = 1; 
      } else if (n == 30) {
        factor[0] = 100;
        factor[1] = 1;
      } else {
         printf("\n test_problem: nf3.rg undefined factor case");
         exit(1);
      }
    }
    /* nf3 computation */
    for (i=1; i<=n; i++) {
      x[i] = (1/100.0)*((double)n)*((double)n)*xreal[i-1];
    }   
    f = 0.0;
    for (i=1; i<=n; i++) {
      f += pow(x[i]-1,2);
    }
    for (i=2; i<=n; i++) {
      f -= x[i]*x[i-1];
    }
    obj[0] = f;
    /* rg computation */
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1]/25.0 - 1.0;
    }   
    f = 0.0;
    for (i=1; i<=n; i++) {
      f += x[i]*x[i] + 10*(1-cos(2*PI*x[i]));
    }
    obj[1] = f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }
    return;
  }

  /* Test problem nf3.sin_n
         uses versions of nf3_n and sin_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"nf3.sin_",8) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"nf3.sin_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"nf3.sin_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 100;
        factor[1] = 1;
      } else if (n == 20) {
        factor[0] = 10000;
        factor[1] = 1; 
      } else if (n == 30) {
        factor[0] = 100000;
        factor[1] = 1;
      } else {
         printf("\n test_problem: nf3.sin undefined factor case");
         exit(1);
      }
    }
    /* nf3 computation */
    for (i=1; i<=n; i++) {
      x[i] = (1/100.0)*((double)n)*((double)n)*xreal[i-1];
    }   
    obj[0] = 0.0;
    for (i=1; i<=n; i++) {
      f += pow(x[i]-1,2);
    }
    for (i=2; i<=n; i++) {
      f -= x[i]*x[i-1];
    }
    obj[0] = f;
    /* sin computation */
    a = 2.5;
    b = 5;
    z = 30;
    for (i=1; i<=n; i++) {
      x[i] = (xreal[i-1]+100.0) * 0.9;
    }   
    obj[1] = 0.0;
    f = a;
    for (i=1; i<=n ; i++) {
      f *= sin((x[i]-z)*PI/180);
    }
    obj[1] -= f;
    f = 1.0;
    for (i=1; i<=n ; i++) {
      f *= sin(b*(x[i]-z)*PI/180);
    }
    obj[1] -= f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }
    return;
  }

  /* Test problem nf3.zkv_n
         uses versions of nf3_n and zkv_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"nf3.zkv_",8) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"nf3.zkv_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"nf3.zkv_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 1;
        factor[1] = 100;
      } else if (n == 20) {
        factor[0] = 1;
        factor[1] = 100; 
      } else if (n == 30) {
        factor[0] = 1;
        factor[1] = 10;
      } else {
         printf("\n test_problem: nf3.zkv undefined factor case");
         exit(1);
      }
    }
    /* nf3 computation */
    for (i=1; i<=n; i++) {
      x[i] = (1/100.0)*((double)n)*((double)n)*xreal[i-1];
    }   
    obj[0] = 0.0;
    for (i=1; i<=n; i++) {
      f += pow(x[i]-1,2);
    }
    for (i=2; i<=n; i++) {
      f -= x[i]*x[i-1];
    }
    obj[0] = f;
    /* zkv computation */
    for (i=1; i<=n; i++) {
      x[i] = (3.0/40.0)*xreal[i-1] + 2.5;
    }   
    f = 0.0;
    for (j=1; j<=n; j++) {
      f += pow(x[j],2);
      f += pow(0.5*((double)j)*x[j],2);
      f += pow(0.5*((double)j)*x[j],4);
    }
    obj[1] = f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }    
    return;
  }

  /* Test problem rg.sin_n
         uses versions of rg_n and sin_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"rg.sin_",7) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"rg.sin_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"rg.sin_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 100;
        factor[1] = 1;
      } else if (n == 20) {
        factor[0] = 100;
        factor[1] = 1; 
      } else if (n == 30) {
        factor[0] = 100;
        factor[1] = 1;
      } else {
         printf("\n test_problem: rg.sin undefined factor case");
         exit(1);
      }
    }
    /* rg computation */
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1]/25.0 - 1.0;
    }   
    f = 0.0;
    for (i=1; i<=n; i++) {
      f += x[i]*x[i] + 10*(1-cos(2*PI*x[i]));
    }
    obj[0] = f;
    /* sin computation */
    a = 2.5;
    b = 5;
    z = 30;
    for (i=1; i<=n; i++) {
      x[i] = (xreal[i-1]+100.0) * 0.9;
    }   
    obj[1] = 0.0;
    f = a;
    for (i=1; i<=n ; i++) {
      f *= sin((x[i]-z)*PI/180);
    }
    obj[1] -= f;
    f = 1.0;
    for (i=1; i<=n ; i++) {
      f *= sin(b*(x[i]-z)*PI/180);
    }
    obj[1] -= f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }
    return;
  }

  /* Test problem rg.zkv_n
         uses versions of rg_n and zkv_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"rg.zkv_",7) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"rg.zkv_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"rg.zkv_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 1.0e+4;
        factor[1] = 1;
      } else if (n == 20) {
        factor[0] = 1.0e+5;
        factor[1] = 1; 
      } else if (n == 30) {
        factor[0] = 1.0e+6;
        factor[1] = 1;
      } else {
         printf("\n test_problem: rg.zkv undefined factor case");
         exit(1);
      }
    }
    /* rg computation */
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1]/25.0 - 1.0;
    }   
    f = 0.0;
    for (i=1; i<=n; i++) {
      f += x[i]*x[i] + 10*(1-cos(2*PI*x[i]));
    }
    obj[0] = f;
    /* zkv computation */
    for (i=1; i<=n; i++) {
      x[i] = (3.0/40.0)*xreal[i-1] + 2.5;
    }   
    f = 0.0;
    for (j=1; j<=n; j++) {
      f += pow(x[j],2);
      f += pow(0.5*((double)j)*x[j],2);
      f += pow(0.5*((double)j)*x[j],4);
    }
    obj[1] = f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }    
    return;
  }

  /* Test problem sin.zkv_n
         uses versions of sin_n and zkv_n
         bounds have been adapted
         so that same bounds apply to both functions   
    # of real variables = n
    # of integer variables = 0
    # of objectives:
       defobj = 0: define nobj = 1
                   define obj[0] = obj[0] + WEIGHTED_SUM_FACTOR * 
                                   (factor[0]/factor[1]) * obj[1]
                   input command must omit -objRange option
              = 1: define nobj = 1
                   define obj[0] = obj[1] + WEIGHTED_SUM_FACTOR * 
                                   (factor[1]/factor[0]) * obj[0]
                   input command must omit -objRange option
              = 2: define nobj = 2
                   do not change obj[0], obj[1]
                   input command must include option 
                         -objRange factor[0] factor[1]
    # of constraints = 0
    Search domain: −100 ≤ xj ≤ 100, j = 1, ..., n */

  if (strncmp(name,"sin.zkv_",8) == 0)

  {    
    if (functionFlag == FALSE) {
      sscanf(name,"sin.zkv_%d_%d",&defobj,&nreal);
      nint = 0;
      nobj = max(1,defobj);
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -100;
        max_realvar[j] =  100;
      }
      return;       
    }
    sscanf(name,"sin.zkv_%d_%d",&defobj,&n);
    /* factor[0], factor[1]: use -objrange values of defobj = 2 */
    if (defobj <= 1) {
      if (n == 10) {
        factor[0] = 1;
        factor[1] = 1.0e+6;
      } else if (n == 20) {
        factor[0] = 1;
        factor[1] = 1.0e+7; 
      } else if (n == 30) {
        factor[0] = 1;
        factor[1] = 1.0e+8;
      } else {
         printf("\n test_problem: sin.zkv undefined factor case");
         exit(1);
      }
    }
    /* sin computation */
    a = 2.5;
    b = 5;
    z = 30;
    for (i=1; i<=n; i++) {
      x[i] = (xreal[i-1]+100.0) * 0.9;
    }   
    obj[0] = 0.0;
    f = a;
    for (i=1; i<=n ; i++) {
      f *= sin((x[i]-z)*PI/180);
    }
    obj[0] -= f;
    f = 1.0;
    for (i=1; i<=n ; i++) {
      f *= sin(b*(x[i]-z)*PI/180);
    }
    obj[0] -= f;
    /* zkv computation */
    for (i=1; i<=n; i++) {
      x[i] = (3.0/40.0)*xreal[i-1] + 2.5;
    }   
    f = 0.0;
    for (j=1; j<=n; j++) {
      f += pow(x[j],2);
      f += pow(0.5*((double)j)*x[j],2);
      f += pow(0.5*((double)j)*x[j],4);
    }
    obj[1] = f;
    /* for defobj = 0 and 1, compute output obj[0] value */
    /* using factor[0], factor[1] as weights */
    if (defobj == 0) {
      obj[0] = obj[0] + 
               WEIGHTED_SUM_FACTOR*(factor[0]/factor[1])*obj[1];
    } else if (defobj == 1) {
      obj[0] = obj[1] + 
               WEIGHTED_SUM_FACTOR*(factor[1]/factor[0])*obj[0];
    }    
    return;
  } 

  /* Test problem maxzkv 
         OBSOLETE, used only in paper
         on seeding evolutionary algorithms
         uses versions of maxl and zkv_20
         specifically, bounds have been adapted
         so that same bounds apply to both functions
         maxl: lower bound was -100, here is -50
         zkv_20: had -5 <= xj <= 10, here scaled up to −50 ≤ xj ≤ 100 
                 correspondingly scale down xi by 10 when
                 function values are computed
         so that global minima are differenct, shift zkv_20 coordinate
         system by +5.0   
    # of real variables = 20
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    Search domain: −50 ≤ xj ≤ 100, j = 1, ..., n

    Global minima: maxl:   x* = ?
                           f(x*) < 4.0
                   zkv_20: x* = 0
                           f(x*) = 0
    file maxzkv.c has version of code below for distribution
    */
  if (strncmp(name,"maxzkv",6) == 0)

  {    
    if (functionFlag == FALSE) {
     nreal = 20;
     nint = 0;
     nobj = 2;
     ncon = 0;
     min_realvar = (double *)malloc(nreal*sizeof(double));
     max_realvar = (double *)malloc(nreal*sizeof(double));
     for (j=0; j<nreal; j++) {
       min_realvar[j] = -50;
       max_realvar[j] = 100;
     }
     return;       
    }
    /* computation of maxl value: shift each x[i] by +10 */
    /* to make minimum different from that of zkv_20 */
    for (i=1; i<=nreal; i++) {
      x[i] = xreal[i-1] + 10.0;
    } 
    for(i= 1;i<=20;i++) {
      app[i] =  x[i];
    }
    for(i=21;i<=40;i++) {
      app[i] = -x[i-20];
    }
    f = app[1];
    for(i=2; i<=40; i++) {
      if (f < app[i]) {
        f = app[i];
      }
    }

    obj[0] = f;

    /* computation of zkv_20 value: since zkv_20 is defined for */
    /* −5 ≤ xj ≤ 10 and here we have −50 ≤ xj ≤ 100, */
    /* divide x[i] by 10 */
    for (i=1; i<=nreal; i++) {
      x[i] = xreal[i-1];
      x[i] /= 10.0;
    }    
    f = 0.0;
    for (j=1; j<=nreal; j++) {
      f += pow(x[j],2);
      f += pow(0.5*((double)j)*x[j],2);
      f += pow(0.5*((double)j)*x[j],4);
    }

    obj[1] = f;  

    return;
  }

   /* Test problem branin
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: −5 ≤ x1 ≤ 10, 0 ≤ x2 ≤ 15.
    Number of local minima: no local minima except the global ones.
    3 global minima: x* =  (-π , 12.275), (π , 2.275) ,(9.42478, 2.475)
                     f(x*) = 0.397887.
    */

  if (strcmp(name,"branin") == 0)

    {
    if (functionFlag == FALSE) {
     nreal = 2;
     nint = 0;
     nobj = 1;
     ncon = 0;
     min_realvar = (double *)malloc(nreal*sizeof(double));
     max_realvar = (double *)malloc(nreal*sizeof(double));
     min_realvar[0] = -5;
     max_realvar[0] = 10;
     min_realvar[1] = 0;
     max_realvar[1] = 15;
     return;       
    }
    a = 1;
    b = 5.1/(4 * PI * PI);
    c = 5/PI;
    d = 6;
    e = 10;
    f = 1/(8*PI);
    obj[0] = 
      a*pow(xreal[1] - b*pow(xreal[0],2) + c*xreal[0] - d,2) +
      e*(1-f)*cos(xreal[0]) + e;
    return;
  }

   /* Test problem  hartman_3
    # of real variables = 3
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: 0 < xi < 1, i = 1, 2, 3
    Number of local minima: 4 local minima
    Global minimum: x* =  (0.114614, 0.555649, 0.852547)
                    f(x*) = - 3.86278
    */

  if (strcmp(name,"hartman_3") == 0)

  {
    if (functionFlag == FALSE) {
       nreal = 3;
       nint = 0;
       nobj = 1;
       ncon = 0;
       min_realvar = (double *)malloc(nreal*sizeof(double));
       max_realvar = (double *)malloc(nreal*sizeof(double));
       for (j=0; j<nreal; j++) {
         min_realvar[j] = 0;
         max_realvar[j] = 1;
       }
       return;       
    }
    for (j=1; j<=3; j++) {
      x[j] = xreal[j-1];
    }
    A[1][1] = 3   ; A[1][2] = 10  ; A[1][3] =  30;
    A[2][1] = 0.1 ; A[2][2] = 10  ; A[2][3] =  35; 
    A[3][1] = 3   ; A[3][2] = 10  ; A[3][3] =  30; 
    A[4][1] = 0.1 ; A[4][2] = 10  ; A[4][3] =  35; 

    C[1] = 1.0; C[2] = 1.2; C[3] = 3.0; C[4] = 3.2;

    P[1][1] = 0.36890; P[1][2] = 0.11700; P[1][3] = 0.26730;
    P[2][1] = 0.46990; P[2][2] = 0.43870; P[2][3] = 0.74700;
    P[3][1] = 0.10910; P[3][2] = 0.87320; P[3][3] = 0.55470;
    P[4][1] = 0.03815; P[4][2] = 0.57430; P[4][3] = 0.88280;

    s = 0;

    for (i=1; i<=4; i++) {
      sm=0;
      for (j=1; j<=3; j++) {
        sm=sm + A[i][j]*pow(x[j]-P[i][j], 2);
      }
      s=s+C[i]*exp(-sm);
    }

    y = -s;

    obj[0] = y;

    return;
  }

   /* Test problem hartman_6
    # of real variables = 6
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: 0 < xi < 1, i = 1, 2, . . . , 6
    Number of local minima: 6 local minima.
    Global minimum: x* =  (0.20169, 0.150011, 0.476874, 
                           0.275332, 0.311652, 0.6573)
                    f(x*) = - 3.32237

    */

  if (strcmp(name,"hartman_6") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 6;
      nint = 0;
      nobj = 1;
      ncon = 0;  
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    for (j=1; j<=6; j++) {
      x[j] = xreal[j-1];
    }

    A[1][1]=10.0; A[1][2]=3.0;  A[1][3]=17.0; 
                  A[1][4]=3.5;  A[1][5]=1.7;  A[1][6]=8.0;
    A[2][1]=0.05; A[2][2]=10.0; A[2][3]=17.0; 
                  A[2][4]=0.1;  A[2][5]=8.0;  A[2][6]=14.0;
    A[3][1]=3.0;  A[3][2]=3.5;  A[3][3]=1.7; 
                  A[3][4]=10.0; A[3][5]=17.0; A[3][6]=8.0;
    A[4][1]=17.0; A[4][2]=8.0;  A[4][3]=0.05; 
                  A[4][4]=10.0; A[4][5]=0.1;  A[4][6]=14.0;

    C[1]=1.0; C[2]=1.2; C[3]=3.0; C[4]=3.2;

    P[1][1]=0.1312; P[1][2]=0.1696; P[1][3]=0.5569; 
                    P[1][4]=0.0124; P[1][5]=0.8283; P[1][6]=0.5886;
    P[2][1]=0.2329; P[2][2]=0.4135; P[2][3]=0.8307; 
                    P[2][4]=0.3736; P[2][5]=0.1004; P[2][6]=0.9991;
    P[3][1]=0.2348; P[3][2]=0.1451; P[3][3]=0.3522; 
                    P[3][4]=0.2883; P[3][5]=0.3047; P[3][6]=0.6650;
    P[4][1]=0.4047; P[4][2]=0.8828; P[4][3]=0.8732; 
                    P[4][4]=0.5743; P[4][5]=0.1091; P[4][6]=0.0381;

    s = 0;

    for (i=1; i<=4; i++) {
      sm=0;
      for (j=1; j<=6; j++) {
        sm = sm + A[i][j]*pow(x[j]-P[i][j],2);
      }
      s=s+C[i]*exp(-sm);
    }

    y = -s;

    obj[0] = y;

    return;

  }

   /* Test problem quad_n
    # of real variables = n >= 2
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: -50 < xi < 100, i = 1, 2, . . . , n
    Global minimum: x* =  0
                    f(x*) = 0
    */

  if (strncmp(name,"quad_",5) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"quad_%d",&nreal);
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -50;
        max_realvar[j] = 100;
      }
      return;       
    }
    sscanf(name,"quad_%d",&n);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }
    obj[0] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += pow(x[i],2.0);
    }
    return;
  }

   /* Test problem quadint_n_m
    quad with n variables total, m integer variables
    obj function: sum_(j=1)^n xj^2 - 0.16*m
    # of real variables = n >= 2
    # of integer variables = m <= n
    # of objectives = 1
    # of constraints = 0
    Search domain: -50 < xi < 100, i = 1, 2, . . . , n
    Global minimum: x* =  0
                    f(x*) =  0
    */

  if (strncmp(name,"quadint_",8) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"quadint_%d_%d",&nreal,&nint);
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -50;
        max_realvar[j] = 100;
      }
      return;       
    }
    sscanf(name,"quadint_%d_%d",&n,&m);
    for (i=1; i<=m; i++) {
      x[i] = xreal[i-1] - 0.4; /* do not change 0.4 value */
    }
    for (i=m+1; i<=n; i++) {
      x[i] = xreal[i-1];
    }
    obj[0] = - 0.16*(double)m;
    for (i=1; i<=n; i++) {
      obj[0] += pow(x[i],2.0);
    }
    return;
  }

   /* Test problem quadmax_n_m
    quad version with n variables
    obj function: sum_(j=1)^m (-xj^2) + sum_(j=m+1)^n xj^2
                  + sum(j=0)^(m-1) pow(max(fabs(min_realvar[i-1]),
                                           fabs(max_realvar[i-1])),2)
    assumes: |max_realvar[j]| >= |min_realvar[j]|; for all j 
    # of real variables = n >= 2
    # of integer variables = 0
    # of objectives = 1
    # of constraints = 0
    Search domain: -50 < xi < 100, i = 1, 2, . . . , n
    Global minimum: xj* =  100; j <= m; xj* = 0; else
                    f(x*) =  0
    */

  if (strncmp(name,"quadmax_",8) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"quadmax_%d",&nreal);
      nint = 0;
      nobj = 1;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -50; /* if changed, */
        max_realvar[j] = 100;  /* must also change below */
      }
      return;       
    }
    sscanf(name,"quadmax_%d_%d",&n,&m);
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }
    obj[0] = 0.0;
    for (i=1; i<=m; i++) {
      obj[0] += pow(max(fabs(-50),    /* "-50" is lower bound */
                        fabs(100)),2); /* "100" is upper bound */
    }
    for (i=1; i<=m; i++) {
      obj[0] -= pow(x[i],2.0);
    }    
    for (i=m+1; i<=n; i++) {
      obj[0] += pow(x[i],2.0);
    }
    return;
  }

   /* Test problem quad2_n_d
    2 quad functions with n variables
    obj function 1: sum_(j=1)^n (xj + d/10)^2
    obj function 2: sum_(j=1)^n (xj - d/10)^2
    # of real variables = n >= 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    Search domain: -50 < xi < 100, i = 1, 2, . . . , n
    */

  if (strncmp(name,"quad2_",6) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"quad2_%d",&nreal);
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -50;
        max_realvar[j] = 100;
      }
      return;       
    }
    sscanf(name,"quad2_%d_%lf",&n,&f);
    f /= 10.0;
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }
    obj[0] = 0.0;
    obj[1] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += pow(x[i]+f,2.0);
      obj[1] += pow(x[i]-f,2.0);      
    }
    return;
  }

   /* Test problem quad2con_n_d
    2 quad functions with n variables
    obj function 1: sum_(j=1)^n (xj + d/10)^2
    obj function 2: sum_(j=1)^n (xj - d/10)^2
    constraint 1: -sum_(j=1)^n xj - 0.01 >= 0
    # of real variables = n >= 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 1
    Search domain: -50 < xi < 100, i = 1, 2, . . . , n
    */

  if (strncmp(name,"quad2con_",9) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"quad2con_%d",&nreal);
      nobj = 2;
      ncon = 1;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -50;
        max_realvar[j] = 100;
      }
      return;       
    }
    sscanf(name,"quad2con_%d_%lf",&n,&f);
    f /= 10.0;
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }
    obj[0] = 0.0;
    obj[1] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += pow(x[i]+f,2.0);
      obj[1] += pow(x[i]-f,2.0);      
    }
    constr[0] = -0.01;
    for (i=1; i<=n; i++) {
      constr[0] -= x[i];      
    }
    return;
  }

   /* Test problem quad3_n_d
    3 quad functions with n variables
    obj function 1: sum_(j=1)^n (xj + d/10)^2
    obj function 2: sum_(j=1)^n (xj)^2
    obj function 3: sum_(j=1)^n (xj - d/10)^2
    # of real variables = n >= 2
    # of integer variables = 0
    # of objectives = 3
    # of constraints = 0
    Search domain: -50 < xi < 100, i = 1, 2, . . . , n
    */

  if (strncmp(name,"quad3_",6) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"quad3_%d",&nreal);
      nobj = 3;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -50;
        max_realvar[j] = 100;
      }
      return;       
    }
    sscanf(name,"quad3_%d_%lf",&n,&f);
    f /= 10.0;
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }
    obj[0] = 0.0;
    obj[1] = 0.0;
    obj[2] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += pow(x[i]+f,2.0);
      obj[1] += pow(x[i],2.0);
      obj[2] += pow(x[i]-f,2.0);      
    }
    return;
  }

   /* Test problem quad3con_n_d
    3 quad functions with n variables
    obj function 1: sum_(j=1)^n (xj + d/10)^2
    obj function 2: sum_(j=1)^n (xj)^2
    obj function 3: sum_(j=1)^n (xj - d/10)^2
    constraint 1: -sum_(j=1)^n xj - 0.01 >= 0
    # of real variables = n >= 2
    # of integer variables = 0
    # of objectives = 3
    # of constraints = 1
    Search domain: -50 < xi < 100, i = 1, 2, . . . , n
    */

  if (strncmp(name,"quad3con_",9) == 0)

  {
    if (functionFlag == FALSE) {
      sscanf(name,"quad3con_%d",&nreal);
      nobj = 3;
      ncon = 1;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -50;
        max_realvar[j] = 100;
      }
      return;       
    }
    sscanf(name,"quad3con_%d_%lf",&n,&f);
    f /= 10.0;
    for (i=1; i<=n; i++) {
      x[i] = xreal[i-1];
    }
    obj[0] = 0.0;
    obj[1] = 0.0;
    obj[2] = 0.0;
    for (i=1; i<=n; i++) {
      obj[0] += pow(x[i]+f,2.0);
      obj[1] += pow(x[i],2.0);
      obj[2] += pow(x[i]-f,2.0);      
    }
    constr[0] = -0.01;
    for (i=1; i<=n; i++) {
      constr[0] -= x[i];      
    }
    return;
  }

   /*  Test problem WRP (Water Resource Planning)
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 3
    # of constraints = 0

    f1 = pow(econst,0.01*x[1]) * pow(x[1],0.02) * pow(x[2],2);
    f2 = 0.5 * pow(econst,0.01*x[1]);
    f3 = -pow(econst,0.005*x[1]) * pow(x[1],0.001) * pow(x[2],2);

    0.01 <= x[1] <= 1.3
    0.01 <= x[2] <= 10

    note :econst = E of global.h = 2.71828182845905
    */
  if (strcmp(name,"wrp") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 3;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0.01;
      }
      max_realvar[0] = 1.3;
      max_realvar[1] = 10;
      return;       
    }
    obj[0] = pow(E,0.01*xreal[0]) * 
             pow(xreal[0],0.02) * pow(xreal[1],2);
    obj[1] = 0.5 * pow(E,0.01*xreal[0]);
    obj[2] = -pow(E,0.005*xreal[0]) * 
             pow(xreal[0],0.001) * pow(xreal[1],2);
    return;
  }
  
   /*  Test problem WELD (Welded Beam Design)
    # of real variables = 4
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 4
    CAUTION: has formulation error, is infeasible
             is a good test for handling of infeasibility

    decision variables: b, t, ell, h
    intermediate variables: tau1, tau2, tau, sigma, pc

    */

  if (strcmp(name,"weld") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 4;
      nint = 0;
      nobj = 2;
      ncon = 4;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<2; j++) {
        min_realvar[j] = 0.125;
        max_realvar[j] = 5.0;
      }
      for (j=2; j<4; j++) {
        min_realvar[j] = 0.1;
        max_realvar[j] = 10.0;
      }
      return;       
    }

    /* transfer xreal[] into local variables b, h, ell, t */
    b = xreal[0];
    h = xreal[1];
    ell = xreal[2];
    tt = xreal[3];

    /* computer intermediate variables */
    tau1 = 6000/(sqrt(2)*h*ell);
    tau2 = 6000*(14+0.5*ell) * sqrt(0.25 *
                                    (pow(ell,2)+pow(h+tt,2))) /
          (2*(0.707*h*ell* (pow(ell,2)/12+0.25*pow(h+tt,2))));

    tau = sqrt(pow(tau1,2)+pow(tau2,2)+
          pow(ell*tau1*tau2,2)/
              sqrt(0.25*(pow(ell,2)+pow(h+tt,2))));

    sigma = 504000/(pow(tt,2)*b);

    pc = 64746.022*(1-0.0282346*tt)*tt*pow(b,3);

    constr[0] = 13600 - tau;
    constr[1] = 30000 - sigma;
    constr[2] = b - h;
    constr[3] = pc - 6000;

    obj[0] = 1.1047*pow(h,2)* ell + 0.04811*tt*b*(14.0+ell);
    obj[1] = 2.1952/(pow(tt,3)*b);

    return;
  }
   /*  Test problem SCH1
    # of real variables = 1
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"sch1") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 1;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -10;
        max_realvar[j] = 10;
      }
      return;       
    }
    obj[0] = pow(xreal[0],2.0);
    obj[1] = pow((xreal[0]-2.0),2.0);
    return;
  }


    /*  Test problem SCH2
    # of real variables = 1
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"sch2") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 1;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -5;
        max_realvar[j] = 10;
      }
      return;       
    }
    if (xreal[0]<=1.0)
    {
        obj[0] = -xreal[0];
        obj[1] = pow((xreal[0]-5.0),2.0);
        return;
    }
    if (xreal[0]<=3.0)
    {
        obj[0] = xreal[0]-2.0;
        obj[1] = pow((xreal[0]-5.0),2.0);
        return;
    }
    if (xreal[0]<=4.0)
    {
        obj[0] = 4.0-xreal[0];
        obj[1] = pow((xreal[0]-5.0),2.0);
        return;
    }
    obj[0] = xreal[0]-4.0;
    obj[1] = pow((xreal[0]-5.0),2.0);
    return;
  }


    /*  Test problem FON
    # of real variables = 5
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"fon") == 0)

  {
    double s1, s2;
    int i;
    if (functionFlag == FALSE) {
      nreal = 5;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -4;
        max_realvar[j] = 4;
      }
      return;       
    }
    s1 = s2 = 0.0;
    for (i=0; i<nreal; i++)
    {
        s1 += pow((xreal[i]-(1.0/sqrt((double)nreal))),2.0);
        s2 += pow((xreal[i]+(1.0/sqrt((double)nreal))),2.0);
    }
    obj[0] = 1.0 - exp(-s1);
    obj[1] = 1.0 - exp(-s2);
    return;
  }


    /*  Test problem KUR
    # of real variables = 3
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"kur") == 0)

  {
    int i;
    double res1, res2;
    if (functionFlag == FALSE) {
      nreal = 3;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -5;
        max_realvar[j] = 5;
      }
      return;       
    }
    res1 = -0.2*sqrt((xreal[0]*xreal[0]) + (xreal[1]*xreal[1]));
    res2 = -0.2*sqrt((xreal[1]*xreal[1]) + (xreal[2]*xreal[2]));
    obj[0] = -10.0*( exp(res1) + exp(res2));
    obj[1] = 0.0;
    for (i=0; i<3; i++)
    {
        obj[1] += pow(fabs(xreal[i]),0.8) + 5.0*sin(pow(xreal[i],3.0));
    }
    return;
  }


    /*  Test problem POL
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"pol") == 0)

  {
    double a1, a2, b1, b2;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -3.15;
        max_realvar[j] = 3.15;
      }
      return;       
    }
    a1 = 0.5*sin(1.0) - 2.0*cos(1.0) + sin(2.0) - 1.5*cos(2.0);
    a2 = 1.5*sin(1.0) - cos(1.0) + 2.0*sin(2.0) - 0.5*cos(2.0);
    b1 = 0.5*sin(xreal[0]) - 2.0*cos(xreal[0]) + sin(xreal[1]) - 1.5*cos(xreal[1]);
    b2 = 1.5*sin(xreal[0]) - cos(xreal[0]) + 2.0*sin(xreal[1]) - 0.5*cos(xreal[1]);
    obj[0] = 1.0 + pow((a1-b1),2.0) + pow((a2-b2),2.0);
    obj[1] = pow((xreal[0]+3.0),2.0) + pow((xreal[1]+1.0),2.0);
    return;
  }


    /*  Test problem VNT
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 3
    # of constraints = 0
    */

  if (strcmp(name,"vnt") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 3;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -3;
        max_realvar[j] = 3;
      }
      return;       
    }
    obj[0] = 0.5*(xreal[0]*xreal[0] + xreal[1]*xreal[1]) + sin(xreal[0]*xreal[0] + xreal[1]*xreal[1]);
    obj[1] = (pow((3.0*xreal[0] - 2.0*xreal[1] + 4.0),2.0))/8.0 + (pow((xreal[0]-xreal[1]+1.0),2.0))/27.0 + 15.0;
    obj[2] = 1.0/(xreal[0]*xreal[0] + xreal[1]*xreal[1] + 1.0) - 1.1*exp(-(xreal[0]*xreal[0] + xreal[1]*xreal[1]));
    return;
  }


    /*  Test problem ZDT1
    # of real variables = 30
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"zdt1") == 0)

  {
    double f1, f2, g, h;
    int i;
    if (functionFlag == FALSE) {
      nreal = 30;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    f1 = xreal[0];
    g = 0.0;
    for (i=1; i<30; i++)
    {
        g += xreal[i];
    }
    g = 9.0*g/29.0;
    g += 1.0;
    h = 1.0 - sqrt(f1/g);
    f2 = g*h;
    obj[0] = f1;
    obj[1] = f2;
    return;
  }


    /*  Test problem ZDT2
    # of real variables = 30
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"zdt2") == 0)

  {
    double f1, f2, g, h;
    int i;
    if (functionFlag == FALSE) {
      nreal = 30;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    f1 = xreal[0];
    g = 0.0;
    for (i=1; i<30; i++)
    {
        g += xreal[i];
    }
    g = 9.0*g/29.0;
    g += 1.0;
    h = 1.0 - pow((f1/g),2.0);
    f2 = g*h;
    obj[0] = f1;
    obj[1] = f2;
    return;
  }


    /*  Test problem ZDT3
    # of real variables = 30
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"zdt3") == 0)

  {
    double f1, f2, g, h;
    int i;
    if (functionFlag == FALSE) {
      nreal = 30;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    f1 = xreal[0];
    g = 0.0;
    for (i=1; i<30; i++)
    {
        g += xreal[i];
    }
    g = 9.0*g/29.0;
    g += 1.0;
    h = 1.0 - sqrt(f1/g) - (f1/g)*sin(10.0*PI*f1);
    f2 = g*h;
    obj[0] = f1;
    obj[1] = f2;
    return;
  }


    /*  Test problem ZDT4
    # of real variables = 10
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"zdt4") == 0)

  {
    double f1, f2, g, h;
    int i;
    if (functionFlag == FALSE) {
      nreal = 10;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      min_realvar[0] = 0;
      max_realvar[0] = 1;
      for (j=1; j<nreal; j++) {
        min_realvar[j] = -5;
        max_realvar[j] = 5;
      }
      return;       
    }
    f1 = xreal[0];
    g = 0.0;
    for (i=1; i<10; i++)
    {
        g += xreal[i]*xreal[i] - 10.0*cos(4.0*PI*xreal[i]);
    }
    g += 91.0;
    h = 1.0 - sqrt(f1/g);
    f2 = g*h;
    obj[0] = f1;
    obj[1] = f2;
    return;
  }


    /*  Test problem ZDT6
    # of real variables = 10
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 0
    */

  if (strcmp(name,"zdt6") == 0)

  {
    double f1, f2, g, h;
    int i;
    if (functionFlag == FALSE) {
      nreal = 10;
      nint = 0;
      nobj = 2;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    f1 = 1.0 - ( exp(-4.0*xreal[0]) ) * pow( (sin(6.0*PI*xreal[0])),6.0 );
    g = 0.0;
    for (i=1; i<10; i++)
    {
        g += xreal[i];
    }
    g = g/9.0;
    g = pow(g,0.25);
    g = 1.0 + 9.0*g;
    h = 1.0 - pow((f1/g),2.0);
    f2 = g*h;
    obj[0] = f1;
    obj[1] = f2;
    return;
  }


    /*  Test problem BNH
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 2
    */

  if (strcmp(name,"bnh") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 2;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      min_realvar[0] = 0;
      max_realvar[0] = 5;
      min_realvar[1] = 0;
      max_realvar[1] = 3;
      return;       
    }
    obj[0] = 4.0*(xreal[0]*xreal[0] + xreal[1]*xreal[1]);
    obj[1] = pow((xreal[0]-5.0),2.0) + pow((xreal[1]-5.0),2.0);
    constr[0] = 1.0 - (pow((xreal[0]-5.0),2.0) + xreal[1]*xreal[1])/25.0;
    constr[1] = (pow((xreal[0]-8.0),2.0) + pow((xreal[1]+3.0),2.0))/7.7 - 1.0;
    return;
  }


    /*  Test problem OSY
    # of real variables = 6
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 6
    */

  if (strcmp(name,"osy") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 6;
      nint = 0;
      nobj = 2;
      ncon = 6;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      min_realvar[0] = 0;
      max_realvar[0] = 10;
      min_realvar[1] = 0;
      max_realvar[1] = 10;
      min_realvar[2] = 1;
      max_realvar[2] = 5;
      min_realvar[3] = 0;
      max_realvar[3] = 6;
      min_realvar[4] = 1;
      max_realvar[4] = 5;
      min_realvar[5] = 0;
      max_realvar[5] = 10;
      return;       
    }
    obj[0] = -(25.0*pow((xreal[0]-2.0),2.0) + pow((xreal[1]-2.0),2.0) + pow((xreal[2]-1.0),2.0) + pow((xreal[3]-4.0),2.0) + pow((xreal[4]-1.0),2.0));
    obj[1] = xreal[0]*xreal[0] +  xreal[1]*xreal[1] + xreal[2]*xreal[2] + xreal[3]*xreal[3] + xreal[4]*xreal[4] + xreal[5]*xreal[5];
    constr[0] = (xreal[0]+xreal[1])/2.0 - 1.0;
    constr[1] = 1.0 - (xreal[0]+xreal[1])/6.0;
    constr[2] = 1.0 - xreal[1]/2.0 + xreal[0]/2.0;
    constr[3] = 1.0 - xreal[0]/2.0 + 3.0*xreal[1]/2.0;
    constr[4] = 1.0 - (pow((xreal[2]-3.0),2.0))/4.0 - xreal[3]/4.0;
    constr[5] = (pow((xreal[4]-3.0),2.0))/4.0 + xreal[5]/4.0 - 1.0;
    return;
  }


    /*  Test problem SRN
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 2
    */

  if (strcmp(name,"srn") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 2;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = -20;
        max_realvar[j] = 20;
      }
      return;       
    }
    obj[0] = 2.0 + pow((xreal[0]-2.0),2.0) + pow((xreal[1]-1.0),2.0);
    obj[1] = 9.0*xreal[0] - pow((xreal[1]-1.0),2.0);
    constr[0] = 1.0 - (pow(xreal[0],2.0) + pow(xreal[1],2.0))/225.0;
    constr[1] = 3.0*xreal[1]/10.0 - xreal[0]/10.0 - 1.0;
    return;
  }


    /*  Test problem TNK
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 2
    */

  if (strcmp(name,"tnk") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 2;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 3.15;
      }
      return;       
    }
    obj[0] = xreal[0];
    obj[1] = xreal[1];
    if (xreal[1] == 0.0)
    {
        constr[0] = -1.0;
    }
    else
    {
        constr[0] = xreal[0]*xreal[0] + xreal[1]*xreal[1] - 0.1*cos(16.0*atan(xreal[0]/xreal[1])) - 1.0;
    }
    constr[1] = 1.0 - 2.0*pow((xreal[0]-0.5),2.0) + 2.0*pow((xreal[1]-0.5),2.0);
    return;
  }


    /*  Test problem CTP1
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 2
    */

  if (strcmp(name,"ctp1") == 0)

  {
    double g;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 2;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    g = 1.0 + xreal[1];
    obj[0] = xreal[0];
    obj[1] = g*exp(-obj[0]/g);
    constr[0] = obj[1]/(0.858*exp(-0.541*obj[0]))-1.0;
    constr[1] = obj[1]/(0.728*exp(-0.295*obj[0]))-1.0;
    return;
  }


    /*  Test problem CTP2
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 1
    */

  if (strcmp(name,"ctp2") == 0)

  {
    double g;
    double theta, a, b, c, d, e;
    double exp1, exp2;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 1;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    theta = -0.2*PI;
    a = 0.2;
    b = 10.0;
    c = 1.0;
    d = 6.0;
    e = 1.0;
    g = 1.0 + xreal[1];
    obj[0] = xreal[0];
    obj[1] = g*(1.0  - sqrt(obj[0]/g));
    exp1 = (obj[1]-e)*cos(theta) - obj[0]*sin(theta);
    exp2 = (obj[1]-e)*sin(theta) + obj[0]*cos(theta);
    exp2 = b*PI*pow(exp2,c);
    exp2 = fabs(sin(exp2));
    exp2 = a*pow(exp2,d);
    constr[0] = exp1/exp2 - 1.0;

    return;
  }


    /*  Test problem CTP3
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 1
    */

  if (strcmp(name,"ctp3") == 0)

  {
    double g;
    double theta, a, b, c, d, e;
    double exp1, exp2;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 1;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    theta = -0.2*PI;
    a = 0.1;
    b = 10.0;
    c = 1.0;
    d = 0.5;
    e = 1.0;
    g = 1.0 + xreal[1];
    obj[0] = xreal[0];
    obj[1] = g*(1.0  - sqrt(obj[0]/g));
    exp1 = (obj[1]-e)*cos(theta) - obj[0]*sin(theta);
    exp2 = (obj[1]-e)*sin(theta) + obj[0]*cos(theta);
    exp2 = b*PI*pow(exp2,c);
    exp2 = fabs(sin(exp2));
    exp2 = a*pow(exp2,d);
    constr[0] = exp1/exp2 - 1.0;
    return;
  }


    /*  Test problem CTP4
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 1
    */

  if (strcmp(name,"ctp4") == 0)

  {
    double g;
    double theta, a, b, c, d, e;
    double exp1, exp2;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 1;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    theta = -0.2*PI;
    a = 0.75;
    b = 10.0;
    c = 1.0;
    d = 0.5;
    e = 1.0;
    g = 1.0 + xreal[1];
    obj[0] = xreal[0];
    obj[1] = g*(1.0  - sqrt(obj[0]/g));
    exp1 = (obj[1]-e)*cos(theta) - obj[0]*sin(theta);
    exp2 = (obj[1]-e)*sin(theta) + obj[0]*cos(theta);
    exp2 = b*PI*pow(exp2,c);
    exp2 = fabs(sin(exp2));
    exp2 = a*pow(exp2,d);
    constr[0] = exp1/exp2 - 1.0;
    return;
  }


    /*  Test problem CTP5
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 1
    */

  if (strcmp(name,"ctp5") == 0)

  {
    double g;
    double theta, a, b, c, d, e;
    double exp1, exp2;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 1;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    theta = -0.2*PI;
    a = 0.1;
    b = 10.0;
    c = 2.0;
    d = 0.5;
    e = 1.0;
    g = 1.0 + xreal[1];
    obj[0] = xreal[0];
    obj[1] = g*(1.0  - sqrt(obj[0]/g));
    exp1 = (obj[1]-e)*cos(theta) - obj[0]*sin(theta);
    exp2 = (obj[1]-e)*sin(theta) + obj[0]*cos(theta);
    exp2 = b*PI*pow(exp2,c);
    exp2 = fabs(sin(exp2));
    exp2 = a*pow(exp2,d);
    constr[0] = exp1/exp2 - 1.0;
    return;
  }


    /*  Test problem CTP6
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 1
    */

  if (strcmp(name,"ctp6") == 0)

  {
    double g;
    double theta, a, b, c, d, e;
    double exp1, exp2;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 1;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      min_realvar[0] = 0;
      max_realvar[0] = 1;
      min_realvar[1] = 0;
      max_realvar[1] = 10;
      return;       
    }
    theta = 0.1*PI;
    a = 40.0;
    b = 0.5;
    c = 1.0;
    d = 2.0;
    e = -2.0;
    g = 1.0 + xreal[1];
    obj[0] = xreal[0];
    obj[1] = g*(1.0  - sqrt(obj[0]/g));
    exp1 = (obj[1]-e)*cos(theta) - obj[0]*sin(theta);
    exp2 = (obj[1]-e)*sin(theta) + obj[0]*cos(theta);
    exp2 = b*PI*pow(exp2,c);
    exp2 = fabs(sin(exp2));
    exp2 = a*pow(exp2,d);
    constr[0] = exp1/exp2 - 1.0;
    return;
  }


    /*  Test problem CTP7
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 1
    */

  if (strcmp(name,"ctp7") == 0)

  {
    double g;
    double theta, a, b, c, d, e;
    double exp1, exp2;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 1;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      min_realvar[0] = 0;
      max_realvar[0] = 1;
      min_realvar[1] = 0;
      max_realvar[1] = 10;
      return;       
    }
    theta = -0.05*PI;
    a = 40.0;
    b = 5.0;
    c = 1.0;
    d = 6.0;
    e = 0.0;
    g = 1.0 + xreal[1];
    obj[0] = xreal[0];
    obj[1] = g*(1.0  - sqrt(obj[0]/g));
    exp1 = (obj[1]-e)*cos(theta) - obj[0]*sin(theta);
    exp2 = (obj[1]-e)*sin(theta) + obj[0]*cos(theta);
    exp2 = b*PI*pow(exp2,c);
    exp2 = fabs(sin(exp2));
    exp2 = a*pow(exp2,d);
    constr[0] = exp1/exp2 - 1.0;
    return;
  }


    /*  Test problem CTP8
    # of real variables = 2
    # of integer variables = 0
    # of objectives = 2
    # of constraints = 2
    */

  if (strcmp(name,"ctp8") == 0)

  {
    double g;
    double theta, a, b, c, d, e;
    double exp1, exp2;
    if (functionFlag == FALSE) {
      nreal = 2;
      nint = 0;
      nobj = 2;
      ncon = 2;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      min_realvar[0] = 0;
      max_realvar[0] = 1;
      min_realvar[1] = 0;
      max_realvar[1] = 10;
      return;       
    }
    g = 1.0 + xreal[1];
    obj[0] = xreal[0];
    obj[1] = g*(1.0  - sqrt(obj[0]/g));
    theta = 0.1*PI;
    a = 40.0;
    b = 0.5;
    c = 1.0;
    d = 2.0;
    e = -2.0;
    exp1 = (obj[1]-e)*cos(theta) - obj[0]*sin(theta);
    exp2 = (obj[1]-e)*sin(theta) + obj[0]*cos(theta);
    exp2 = b*PI*pow(exp2,c);
    exp2 = fabs(sin(exp2));
    exp2 = a*pow(exp2,d);
    constr[0] = exp1/exp2 - 1.0;
    theta = -0.05*PI;
    a = 40.0;
    b = 2.0;
    c = 1.0;
    d = 6.0;
    e = 0.0;
    exp1 = (obj[1]-e)*cos(theta) - obj[0]*sin(theta);
    exp2 = (obj[1]-e)*sin(theta) + obj[0]*cos(theta);
    exp2 = b*PI*pow(exp2,c);
    exp2 = fabs(sin(exp2));
    exp2 = a*pow(exp2,d);
    constr[1] = exp1/exp2 - 1.0;
    return;
  }

    /*  Test problem DLTZ1
    # of real variables = 7
    # of integer variables = 0
    # of objectives = 3
    # of constraints = 0
    */

  if (strcmp(name,"dltz1") == 0)

  {
    if (functionFlag == FALSE) {
      nreal = 7;
      nint = 0;
      nobj = 3;
      ncon = 0;
      min_realvar = (double *)malloc(nreal*sizeof(double));
      max_realvar = (double *)malloc(nreal*sizeof(double));
      for (j=0; j<nreal; j++) {
        min_realvar[j] = 0;
        max_realvar[j] = 1;
      }
      return;       
    }
    k = nreal - nobj + 1;     
    g = 0.0;
    for (i = nreal - k; i < nreal; i++) {
      g += (xreal[i] - 0.5)*(xreal[i] - 0.5) - 
           cos(20.0 * PI * (xreal[i] - 0.5));
    }
        
    g = 100 * (k + g);        
    for (i = 0; i < nobj; i++) {
      obj[i] = (1.0 + g) * 0.5;
    }
        
    for (i = 0; i < nobj; i++){
      for (j = 0; j < nobj - (i + 1); j++) {           
          obj[i] *= xreal[j];
      }                
      if (i != 0){
        m = nobj - (i + 1);
        obj[i] *= 1 - xreal[m];
      } 
    }
    return;
  }

  printf("\ntest_problem: Error, unknown problen name = %s\n",
         name);
  exit(1);

}

/********* last record of problemdef.lb.c **********/
