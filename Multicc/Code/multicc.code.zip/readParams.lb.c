/* readParams routines */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *
 *   void readParams(char *name, int printflag)
 *   void initsol2inputCandidate(char *filename);
 *   void lineread2inputCandidate(char *lineread, char *saveread,
 *                                int nskipvalue)
 *   void readProcessor  read processor file
 *   void writeProcessor write/copy all files for processor execution
 ****************************************************************/
/*eject*/
/**************************************************************
 * readParams(char *filename, int printflag): 
 *   read parameters of specified file
 *   to define nreal, nint, nobj, ncon, min_realvar[], max_realvar[],
 *   nCorners, corner[], objective[].direction, constraint[]
 *   if input data are included in file, then 
 *      x values are extracted, but obj and constr values are
 *      ignored and initialized to 0
 *   printfFlag = TRUE: regular printing of file info 
 *              = FALSE: no regular printing
 *   caution: nobj is total number of obj functions throughout
 *            the routines of the entire file readParams.lb.c
 *            and thus is independent of objFactor[]
 *            inputCandidate[] with keepFlag = TRUE has nobj
 *            obj values; reduction according to objFactor[]
 *            is done later in defineParameters()
 **************************************************************/
void readParams(char *filename, int printflag) {

  int i, nskipvalue;
  int nrealtemp, ncontemp, nobjtemp, nCornerstemp;

  char lineread[MAXLEN], saveread[MAXLEN];
  char paramsfile[MAX_ENTRY];

  FILE *paramsfil;

  sprintf(paramsfile,"%s",filename);
  if ((paramsfil = fopen(paramsfile,"r")) == NULL) {
    printf("\n readParams: cannot open parameter file %s",
           paramsfile);
    exit(1);
  }
/*eject*/
  /* initialize counts */
  nreal = -1;
  nint = -1;
  nobj = -1;
  ncon = -1;
  /* nInputCandidates = 0 already done in defineParameters() */
  /* nCorners = 0 already done in defineParameters() */
  /* nLinIneqs = 0 already done in defineParameters() */
  nskipvalue = -1; /* = -1  data format undefined */
                   /* >= 0  number of entries to be skipped */
                   /*       before xvalue entries are read */
  nrealtemp = 0;
  nobjtemp = 0;
  ncontemp = 0;
  nCornerstemp = 0;
  nParamsData = 0;

  if (printflag == TRUE) {
    printf("\n Input Parameter File %s:",gOption.params);
  }

  while (fgets(lineread,MAXLEN,paramsfil) != NULL) {
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty lines */
    if (lineread[0] == '\0') {
      continue;
    }

    /* save lineread in saveread */
    strcpy(saveread,lineread);
/*eject*/
    if (lineread[0] == '#') {
      /* parameter line */
      if (printflag == TRUE) {
        printf("\n  %s", saveread);
      }
      /* skip comment record */
      if (strncmp(lineread,"##",2) == 0) {
        continue;
      }
      /* data format specification */
      /* this specification is not stored in paramsData[] */
      if (strncmp(lineread,
        "# records: skip",15) == 0) {
        sscanf(lineread,"# records: skip %d entries",&nskipvalue);
        continue;
      }
 
      if (nParamsData == MAX_PARAMSDATA) {
        printf("\n Must increase MAX_PARAMSDATA = %d",MAX_PARAMSDATA);
        exit(1);
      }
      /* store line in paramsData[] */
      strcpy(paramsData[nParamsData],lineread);
      nParamsData++;
/*eject*/
      /* obtain problem statistics */
      if (strncmp(lineread,
                  "# total number of variables",27) == 0) {
        sscanf(lineread,"# total number of variables = %d",&nreal);
        if (nreal > MAX_VARIABLE) {
          printf("\n readParams: must increase MAX_VARIABLE to %d",
                 nreal);
          exit(1);
        }
        min_realvar = (double *)malloc(nreal*sizeof(double));
        max_realvar = (double *)malloc(nreal*sizeof(double));
      } else if (strncmp(lineread,
                  "# number of integer variables",29) == 0) {
        sscanf(lineread,"# number of integer variables = %d",&nint);
        if (nint > nreal) {
          printf("\n readParams: number of integer variables = %d",
                 nint);
          printf("\n exceeds total number of variables = %d",
                 nreal);
          exit(1);
        }
      } else if (strncmp(lineread,
                  "# number of objectives",22) == 0) {
        sscanf(lineread,"# number of objectives = %d",&nobj);
        if (nobj > MAX_OBJ) {
          printf("\n readParams: Must increase MAX_OBJ to %d",
                 nobj);
          exit(1);
        }
/*eject*/
      } else if (strncmp(lineread,
                "# number of constraints",23) == 0) {
        sscanf(lineread,"# number of constraints = %d",&ncon);
        if (ncon > MAX_CONSTRAINT) {
          printf("\n readParams: Must increase MAX_CONSTRAINT to %d",
                 ncon);
          exit(1);
        }
      } else if (strncmp(lineread,
                "# number of corners",18) == 0) {
        sscanf(lineread,"# number of corners = %d",&nCorners);
        if (nCorners > MAX_CORNER) {
          printf("\n Must increase MAX_CORNER to %d",nCorners);
          exit(1);
        }
/*eject*/       
      } else if (strncmp(lineread,"# objective:",12) == 0) {
        if (nobjtemp >= MAX_OBJ) {
          printf(
          "\n readParams: Too many '# objective:' records = %d",
          nobjtemp+1); 
          exit(1);         
        }
        sscanf(lineread,"# objective: %s %s", 
                        objective[nobjtemp].name,
                        objective[nobjtemp].direction);
        if ((strcmp(objective[nobjtemp].direction,"max") != 0) &&
            (strcmp(objective[nobjtemp].direction,"min") != 0)) {
          printf("\n readParams: wrong objective direction in ");
          printf("input record = %s", saveread);
          exit(1);
        }
        if (gOption.objtolerance == FALSE) {
          /* arguments of the multicc call do not define */
          /* obj tolerances*/
          /* assign default tolerance value */
          objTolerance[nobjtemp] = FUNCTION_PRECISION;
          /* if "-tolerance <f>" occurs, replace default value by f */
          tokenize(lineread);
          /* check for option '-tolerance <f>' */
          if (nTokens >= 5) {
            if (strcmp(token[4],"-tolerance") != 0) {
              printf(
               "\n callArguments: unknown option '%s' in record '%s'",
                token[4],lineread);
              printf(
               "\n           '-tolerance <f> is only option allowed");
              exit(1);
            }
            if (nTokens > 6) {
              printf(
               "\n callArguments: too many entries in record '%s'",
                lineread);
              exit(1);
            }
            if (nTokens <= 5) {
              printf(
           "\n callArguments: tolerance value missing in record '%s'",
                lineread);
              exit(1);
            }
            objTolerance[nobjtemp] = atof(token[5]);
            if (objTolerance[nobjtemp] < 0) {
              printf(
             "\n callArguments: negative tolerance %g in record '%s'",
               objTolerance[nobjtemp],lineread);
              exit(1);
            }
          }
        }
        nobjtemp++;
/*eject*/
     } else if (strncmp(lineread,"# constraint:",13) == 0) {
        if (ncontemp >= MAX_CONSTRAINT) {
          printf(
          "\n readParams: Too many '# constraint:' records = %d",
          ncontemp+1); 
          exit(1);         
        }
        sscanf(lineread,"# constraint: %s %s %lg", 
                        constraint[ncontemp].name,
                        constraint[ncontemp].inequality,
                        &constraint[ncontemp].rhs);
        if ((strcmp(constraint[ncontemp].inequality,">=") != 0) &&
            (strcmp(constraint[ncontemp].inequality,"<=") != 0)) {
          printf("\n readParams: wrong inequality sign in ");
          printf("input record = %s", saveread);
          exit(1);
        }
        if (gOption.constrtolerance == FALSE) {
          /* arguments of the multicc call do not define */
          /* constraint tolerances */
          /* assign default tolerance value */
          constrTolerance[ncontemp] = CONSTRAINT_PRECISION;
          /* if "-tolerance <f>" occurs, replace default value by f */
          tokenize(lineread);
          /* check for option '-tolerance <f>' */
          if (nTokens >= 6) {
            if (strcmp(token[5],"-tolerance") != 0) {
              printf(
               "\n callArguments: unknown option '%s' in record '%s'",
                token[5],lineread);
              printf(
               "\n           '-tolerance <f> is only option allowed");
              exit(1);
            }
            if (nTokens > 7) {
              printf(
               "\n callArguments: too many entries in record '%s'",
                lineread);
              exit(1);
            }
            if (nTokens <= 6) {
              printf(
           "\n callArguments: tolerance value missing in record '%s'",
                lineread);
              exit(1);
            }
            constrTolerance[ncontemp] = atof(token[6]);
            if (constrTolerance[ncontemp] < 0) {
              printf(
             "\n callArguments: negative tolerance %g in record '%s'",
               constrTolerance[ncontemp],lineread);
              exit(1);
            }
          }
        }
        ncontemp++;
/*eject*/   
     } else if (strncmp(lineread,"# corner:",9) == 0) {
        if (nCornerstemp >= MAX_CORNER) {
          printf(
          "\n readParams: Too many '# corner:' records = %d",
          nCornerstemp+1);
          printf(
          "\n             increase # number of corners = %d",
          nCorners); 
          exit(1);         
        }
        /* store corner string */
        strcpy(corner[nCornerstemp], &lineread[9]);
        nCornerstemp++;  
     } else if (strncmp(lineread,"# param:",8) == 0) {
        if (nrealtemp >= MAX_VARIABLE) {
          printf(
          "\n readParams: Too many '# param:' records = %d",
          nrealtemp+1); 
          exit(1);         
        }
        sscanf(lineread,"# param: %s %lg %lg", 
                        name_realvar[nrealtemp],
                        &min_realvar[nrealtemp],
                        &max_realvar[nrealtemp]);       
        nrealtemp++;
/*eject*/   
      }
      continue;
    } /* end if lineread[0] == '#' */
/*eject*/
    /* have data record */
    if (nskipvalue == -1) {
      printf("\n readParams: data format specification missing, ");
      printf("\n      yet data records are included in params file");
      printf("\n      add data format specification ");
      printf("\n        '# records: skip <n> entries'");
      printf("\n      and rerun");
      exit(1);
    }
    /* convert data record to input candidate record */
    lineread2inputCandidate(lineread,saveread,nskipvalue);

  } /* end while fgets */ 
  if (printflag == TRUE) {
    printf("\n total number of data records in params file = %d\n", 
         nInputCandidates);
  }

  fclose(paramsfil);

  /* process initial solution file if specified */
  if (strcmp(gOption.initsol,"NOINITSOLFILE") != 0) {
    initsol2inputCandidate(gOption.initsol); 
  } 
/*eject*/
  /* check if all values have been obtained */
  if (nreal == -1) {
    printf("\n readParams: missing total number of variables");
    exit(1);
  }
  if (nint == -1) {
    printf("\n readParams: missing number of integer variables");
    exit(1);
  }
  if (nobj == -1) {
    printf("\n readParams: missing number of objectives");
    exit(1);
  }
  if (ncon == -1) {
    printf("\n readParams: missing number of constraints");
    exit(1);
  }
/*eject*/
  /* check that summary statistics are consistent with records */
  if (nreal != nrealtemp) {
    printf(
      "\n readParams: total number of variables = %d", 
      nreal);
    printf(
      "\n is not equal to number of '# param:' records = %d",
      nrealtemp);
    exit(1);
  }
  if (nobj != nobjtemp) {
    printf(
      "\n readParams: number of objectives = %d", 
      nobj);
    printf(
      "\n is not equal to number of '# objective:' records = %d",
      nobjtemp);
    exit(1);
  }
  if (ncon != ncontemp) {
    printf(
      "\n readParams: number of constraints = %d", 
      ncon);
    printf(
      "\n is not equal to number of '# constraint:' records = %d",
     ncontemp);
    exit(1);
  }
  if (nCorners != nCornerstemp) {
    printf(
      "\n readParams: number of corners = %d", 
      nCorners);
    printf(
      "\n is not equal to number of '# corner:' records = %d",
     nCornerstemp);
    exit(1);
  }

  return;
}
/*eject*/
/**************************************************************
 * void initsol2inputCandidate(char *filename): 
 *      if  no cutout option: add solutions
 *        in file <filename> to inputCandidate[]
 *      if cutout option: define inputCandidate[]
 *        solely from solutions in file <filename>
 * caution: for cutout option: the file
 *          - must have at least two records
 *          - must have correct obj and constraint values 
 *            this cannot be checked, but it is verified that 
 *            the necessary condition
 *            nskipvalue = nobj + ncon is satisfied
 * caution: option "# records: skip <n> entries"
 *          may occur any number of times
 *          up to first such occurrence, processing is according
 *          to assumed "# records: skip <nobj+ncon> entries"
 **************************************************************/
void initsol2inputCandidate(char *filename) {

  int cmin, cmax, i, j, n, nskipvalue;

  double objmin, objmax;

  char lineread[MAXLEN], saveread[MAXLEN];

  FILE *initfil;

  cmin = 0; /* to suppress compiler warning */
  cmax = 0; /* to suppress compiler warning */

  /* initialize nskipvalue */
  nskipvalue = nobj + ncon;

  if ((initfil = fopen(filename,"r")) == NULL) {
    printf(
    "\n initsol2inputCandidate: cannot open file %s",filename);
    exit(1);
  }

  if (gOption.cutout == TRUE) {
    /* cutout option: discard any earlier obtained inputCandidate[] */
    nInputCandidates = 0;
  }
/*eject*/
  while (fgets(lineread,MAXLEN,initfil) != NULL) {
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty lines */
    if (lineread[0] == '\0') {
      continue;
    }

    /* save lineread in saveread */
    strcpy(saveread,lineread);

    if (lineread[0] == '#') {
      /* data format specification */
      if (strncmp(lineread,
        "# records: skip",15) == 0) {
        sscanf(lineread,"# records: skip %d entries",&nskipvalue);
        if ((gOption.cutout == TRUE) && (nskipvalue != (nobj+ncon))) {
          printf(
           "\n initsol2inputCandidate: nskipvalue (= %d)",
               nskipvalue);
          printf("\n is not equal to nobj (= %d) + ncon (= %d)",
               nobj, ncon);
          exit(1);
        }
      }
      continue;
    }

    /* have data record
     * no cutout option:
     *   convert data record to input candidate record
     *   obj and constr values, if any, are not used
     *   thus, use just x values
     * 
     * cutout option:
     *   dobj and constr values are assumed correct
     *   if objBound[] if violated or solution is infeasible:
     *         discard record
     *   else: store record with obj and constr values 
     *         together with x values
     *   both cases: assign keepFlag = FALSE
     */
    lineread2inputCandidate(lineread,saveread,nskipvalue);
 
  } /* end while fgets */
/*eject*/
  fclose(initfil);

  if ((gOption.cutout == TRUE) && (nInputCandidates <= 1)) {
    printf("\n initsol2inputCandidate: initsol file %s ",filename);
    printf("\n has %d record(s) instead of required >= 2 records",
           nInputCandidates);
    exit(1);
  }

  if (gOption.cutout == TRUE) {
    /* reduce inputCandidate[] so that for each obj, there is */
    /* one record with max value and another with min value */
    /* all other records are deleted */
    /* transfer to inputCandidate[] to candidate[] */
    /* since inputCandidate[].keepflag = FALSE, also */
    /* have candidate[].keepFlag = FALSE */
    nCandidates = 0;
    someCandidate2candidate(inputCandidate,
                            nInputCandidates, &nCandidates);
    /* determine max min obj records for each obj function */
    /* mark these records with keepFlag = TRUE */    
    for (j=0; j<nobj; j++) {
      objmin = INF;
      objmax = -INF;
      for (n=0; n<nCandidates; n++) {
        if (candidate[n].obj[j] < objmin) {
          objmin = candidate[n].obj[j];
          cmin = n;
        }
        if (candidate[n].obj[j] > objmax) {
          objmax = candidate[n].obj[j];
          cmax = n;
        }
      }
      candidate[cmin].keepFlag = TRUE;
      candidate[cmax].keepFlag = TRUE;                
    }
    /* transfer all max and min cases, which are characterized by */
    /* by keepFlag = TRUE, to inputCandidate[] */
    candidateTrue2someCandidate(inputCandidate,&nInputCandidates);
    /* reset inputCandidate[].keepFlag to FALSE */
    for (n=0; n<nInputCandidates; n++) {
      inputCandidate[n].keepFlag = FALSE;
    }
  }

  return;

}
/*eject*/
/**************************************************************
 * lineread2inputCandidate(char *lineread, char *saveread, 
 *                         int nskipvalue):
 *   if not cutout option:
 *   convert data record to input candidate record
 *   if cutout option:
 *     convert record to candidate record
 *     discard record if it violates objBound[] or is infeasible
 **************************************************************/
void lineread2inputCandidate(char *lineread, char *saveread,
                             int nskipvalue) {

  int j;

  if (nInputCandidates >= MAX_PRIOR) {
    printf("\n lineread2inputCandidate: number of input data ");
    printf("records > MAX_PRIOR = %d", MAX_PRIOR);
    exit(1);
  }
  /* check that parameters are valid */
  if ((nreal < 0) || (nobj < 0) || (ncon < 0)) {
    printf(
    "\n lineread2inputCandidate: at least one negative value below:");
    printf("\n   nreal = %d, nobj = %d, ncon = %d",
             nreal, nobj, ncon);
    exit(1);
  }

  /* read data record */
  tokenize(lineread);
  if (nTokens < nskipvalue + nreal) {
    printf("\n lineread2inputCandidate: data record %s\n",lineread);
    printf("\n has %d entries, but must have at least %d entries",
           nTokens,nskipvalue + nreal);
    exit(1);
  }
/*eject*/
  if (gOption.cutout == FALSE) {

    /* no cutout option */
    /* define dummy obj values */
    for (j=0; j<nobj; j++) {
      inputCandidate[nInputCandidates].obj[j] = 0.0; 
    }
    /* define dummy constr values */
    for (j=0; j<ncon; j++) {
      inputCandidate[nInputCandidates].constr[j] = 0.0;
    }
    /* define dummy constr_violation value */
    inputCandidate[nInputCandidates].constr_violation = 0.0;

  } else {

    /* cutout option */
    /* get obj values */
    for (j=0; j<nobj; j++) {
      inputCandidate[nInputCandidates].obj[j] = 
        atof(token[j]);
      if (inputCandidate[nInputCandidates].obj[j] > objBound[j]) {
        /* obj violates objBound[], hence discard case */
        return;
      }
    }   
    /* get constr values */
    for (j=0; j<ncon; j++) {
      inputCandidate[nInputCandidates].constr[j] = 
        atof(token[nobj+j]);
      if (inputCandidate[nInputCandidates].constr[j] < 0.0) {
        /* constraint j is violated, hence discard case */
        return;
      }
    }
    /* due to above code for constr[], constr_violation = 0.0 */
    inputCandidate[nInputCandidates].constr_violation = 0.0;

  } /* end if gOption.cutout == FALSE, else */
/*eject*/
  /* define xvalue values */
  for (j=0; j<nreal; j++) {
    inputCandidate[nInputCandidates].xvalue[j] = 
        atof(token[nskipvalue+j]);
    /* check that value is within min/max bounds */
    if (inputCandidate[nInputCandidates].xvalue[j] <
        min_realvar[j]) {
      printf(
         "\n Data record %d of %s.params file is: \n %s",
          nInputCandidates+1, problemName, saveread);
      printf(
      "\n variable %d has value %g < min bound %g",
         j+1,
         inputCandidate[nInputCandidates].xvalue[j],
         min_realvar[j]);
      exit(1);                        
    }
    if (inputCandidate[nInputCandidates].xvalue[j] >
        max_realvar[j]) {
      printf(
         "\n Data record %d of %s.params file is: \n %s",
          nInputCandidates+1, problemName, saveread);
      printf(
      "\n variable %d has value %g > max bound %g",
         j+1,
         inputCandidate[nInputCandidates].xvalue[j],
         max_realvar[j]);
      exit(1);                        
    }
  }  

  inputCandidate[nInputCandidates].keepFlag = FALSE;
  inputCandidate[nInputCandidates].distanceSquared = INF;
  inputCandidate[nInputCandidates].generation = 1;
  nInputCandidates++;

  return;

}
/*eject*/
/**************************************************************
 *   void readProcessor(): read processor file
 **************************************************************/
void readProcessor() {

  int i, p;

  char lineread[MAXLEN];
  char cmnd[MAX_ENTRY];

  char procfile[MAX_ENTRY];
  FILE *procfil;

  nProcessors = 0;
  nProcFiles = 0;
  strcpy(procfile,gOption.processor);

  if (strcmp(procfile,"NOPROCFILE") == 0) {
    return;
  }

  /* open file */
  if ((procfil = fopen(procfile,"r")) == NULL) {
    printf("\n readProcessor: cannot open processor file %s",
           procfile);
    exit(1);
  }
/*eject*/
  while (fgets(lineread,MAXLEN,procfil) != NULL) {
    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty and comments lines */
    if ((lineread[0] == '\0') || (lineread[0] =='#')) {
      continue;
    }

    /* case "processor" */
    if (strncmp(lineread,"processor",9) == 0) {
      if (nProcessors >= MAX_PROC) {
        printf(
         "\n readProcessor: too many processors, increase MAX_PROC");
        exit(1);
      }   
      /* store line */
      sscanf(lineread,"processor %s %s", 
         processor[nProcessors].machine,
         processor[nProcessors].path);
      nProcessors++;
      continue;  
    }
/*eject*/
    /* case "userfile" */
    if (strncmp(lineread,"userfile",8) == 0) {
      if (nProcFiles >= MAX_PROCFILE) {
        printf(
      "\n readProcessor: too many user files, increase MAX_PROCFILE");
        exit(1);
      }   
      /* store  line */
      sscanf(lineread,"userfile %s", procFile[nProcFiles]);
      nProcFiles++;
      continue;  
    }

    /* unknown record type */
    printf("\n readProcessor: Unknown type of record = %s",lineread);
    exit(1);

  }

  /* close file */
  fclose(procfil);
/*eject*/
  /* for each processor p: */
  /*   if processor[p].machine = 'home': */
  /*      mkdir processor[p].path directory if it does not exist */
  for (p=0; p<nProcessors; p++) {
    if (strcmp(processor[p].machine,"home") == 0) {
      /* test if directory processor[p].path exists */
      /* if not, create that directory */
      sprintf(cmnd,"test -d %s",processor[p].path);
      if( system(cmnd)  != 0 ) {
        /* directory does not exist, create it */
        sprintf(cmnd,"mkdir -p  %s",processor[p].path);
        if(system(cmnd) != 0 ) {
          printf("\n readProcessor: cannot make directory %s",
                   processor[p].path);
          exit(1);
        }       
      }    
    }
  }

  return;

}
/*eject*/
/**************************************************************
 *   void writeProcessor(): write/copy all files 
 *                          for processor execution
 *   caution: assumes black box program file and other user files
 *            that are to be executed, to have executable option
 *            assigned
 **************************************************************/
void writeProcessor() {

  int i, p;

  char cmnd[MAX_ENTRY];

  char runfile[MAX_ENTRY];
  FILE *runfil;
  char removefile[MAX_ENTRY];
  FILE *removefil;

  char userfile[MAX_ENTRY];
/*eject*/
  for (p=0; p<nProcessors; p++) {

    /* start run file */
    sprintf(runfile,"runprocess.%d.sh", p+1);
    if ((runfil = fopen(runfile,"w")) == NULL) {
      printf("\n writeProcessor: cannot open run file %s",
           runfile);
      exit(1);     
    }

    /* define run  file */
    /* bash shell */
    fprintf(runfil,"#!/bin/bash");
    /* limit cpu execution time (sec) */
    fprintf(runfil,"\nulimit -t %d",  
                   gOption.maxproctime);
    /* cd to specified processor directory */
    fprintf(runfil,"\ncd %s",processor[p].path);
    /* execute black box; outbox has .temp suffix */
    fprintf(runfil,"\n%s %s %s %s.temp",
                   gOption.blackbox, 
                   problemName,
                   gOption.inbox,
                   gOption.outbox);
    /* move outbox with .temp suffix to outbox, to be detected */
    /* by evaluate_parallelCandidate() */
    fprintf(runfil,"\nmv %s.temp %s", 
                   gOption.outbox, 
                   gOption.outbox);
    fprintf(runfil,"\n");
    /* close run file */
    fclose(runfil);
    /* make run file executable */
    sprintf(cmnd,"chmod u+x %s", runfile);
    if (system(cmnd) != 0) {
      printf("\n writeProcessor: cannot chmod file %s to executable",
             runfile);
      exit(1);
    }
/*eject*/
    /* start remove file */
    sprintf(removefile,"removebox.sh");
    if ((removefil = fopen(removefile,"w")) == NULL) {
      printf("\n writeProcessor: cannot open remove file %s",
           removefile);
      exit(1);     
    }

    /* define remove  file */
    /* bash shell */
    fprintf(removefil,"#!/bin/bash");
    /* cd to specified processor directory */
    fprintf(removefil,"\ncd %s",processor[p].path);
    /* remove outbox file if present */
    fprintf(removefil,"\nrm -f %s",gOption.outbox);
    /* close remove file */
    fclose(removefil);
    /* make remove file executable */
    sprintf(cmnd,"chmod u+x %s", removefile);
    if (system(cmnd) != 0) {
      printf("\n writeProcessor: cannot chmod file %s to executable",
             removefile);
      exit(1);
    }
/*eject*/
    /* copy run file, black box file, and user specified files */
    /* to processor p */

    for (i=-3; i<nProcFiles; i++) {
      if (i == -3) {
        /* i = -3: run file */
        strcpy(userfile,runfile);
      } else if (i == -2) {
        /* i = -2: remove file */
        strcpy(userfile,removefile);
      } else if (i == -1) {
        /* i = -1: black box file */
        strcpy(userfile,gOption.blackbox);
      } else {
        /* i >= 0: additional user file */
        strcpy(userfile,procFile[i]);
      }
      if (strcmp(processor[p].machine,"home") == 0) {
        /* copy with 'cp' */
        sprintf(cmnd,"cp %s %s/%s",
                        userfile, 
                        processor[p].path,
                        userfile);
      } else {
      /* copy with 'scp' */
        sprintf(cmnd,"scp -q %s %s:\"%s/%s\"",
                        userfile, 
                        processor[p].machine,
                        processor[p].path,
                        userfile);
      }
      if (system(cmnd) != 0) {
        printf("\n writeProcessor: command %s does not copy %s ",
               cmnd, userfile);
        printf(" into machine %s and directory %s",
               processor[p].machine, processor[p].path);
        printf(" defined for processor %d", p+1);
        exit(1);
      }
    } /* end for i */

  } /* end for p */   

  return;

}
/*********** last record of readParams.c *********/
