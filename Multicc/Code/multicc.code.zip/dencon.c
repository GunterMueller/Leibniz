/* routines solving problem */
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "dencon.h"
/**************************************************************
 *
 * subroutines in this file:
 *       void dencon(double *x)
 *       void denconsolution(char *label)
 *       void denconstop()
 **************************************************************/
/*eject*/
/**************************************************************
 *   void dencon(): main solution subroutine        
 **************************************************************/
void dencon(double *x) {

  int cambio_eps;
  int n, i, j;
  int i_dense,j_dense;
  int num_fal;
  int flag_fail[MAX_VARIABLE+1];
  int index_halton;
  int imin, imax, iminalfa, imaxalfa;
  int tipo_direzione;

  double dconv[MAX_VARIABLE+1],dnr;
  double z[MAX_VARIABLE+1],
         d[MAX_VARIABLE+1], 
         d_dense[MAX_VARIABLE+1];
  double viol_old, constr_old[MAX_CONSTRAINT+1];
  double alfa;
  double alfa_d[MAX_VARIABLE+1],
         alfa_diag[MAX_VARIABLE+1],
         alfa_coord[MAX_VARIABLE+1], 
         alfa_dense[MAX_VARIABLE+1];
  double f, fz, eta;
  double maxeps;
  int discr_change;
  double fstop[2*MAX_VARIABLE+1+1],
         d1[MAX_VARIABLE+1];
  double fz1, fz2, z1[MAX_VARIABLE+1], z2[MAX_VARIABLE+1];
  double fmin, fmax,soglia;
  double doldalfamin, doldalfamax, doldalfamedio, rapalfa;

  double dval;
/*eject*/
  /* Parallel begin */
  /* caution: parallelCandidate[] does not follow Fortran */
  /* convention; all subscripts start with index 0 */
  int flag, k, nc;
  int idx_dir, j_dir;
  double betapos, betaneg, temp;
  double dir[MAX_VARIABLE+1];
  double xpos[MAX_VARIABLE+1];
  double xneg[MAX_VARIABLE+1];
  Xstore pred; /* contains all values for the vector pred.xreal */
  /* Parallel end */

/* DEBUG begin trajectory file */
  FILE *trajectoryfil;
  char trajectoryfile[MAX_ENTRY];
  sprintf(trajectoryfile,"%s.trajectory",problemName);
  trajectoryfil = fopen(trajectoryfile,"w");
/* DEBUG end */
/*eject*/
  /* initialization to suppress compiler warning */
  alfa = 0.0;
  fz1 = 0.0;
  fz2 = 0.0;  
  fz = 0.0;
  obj = 0.0;

  /* define n */
  n = nreal;

  discr_change = FALSE; 
  eta = 1.e-6;
  for (j=1;j<=n; j++) {
    flag_fail[j] = 0;
  }
  num_fal = 0;
  istop = 0;
  for (j=1; j<=2*n+1; j++) {
   fstop[j] = 0.0;
  }

  index_halton = 19; /* option: = 19*LARGEPRIME */
  soglia = 1.e-3;
/*eject*/
  alfa_dense[1] = 0.0;
  for (i=1; i<=n; i++) {
    alfa_d[i] = max(1.e-3,min(1.0,fabs(x[i])));
    alfa_diag[i] = alfa_d[i];
    alfa_coord[i] = alfa_d[i];
    alfa_dense[1] += alfa_d[i];
    if (iprint >= 1) {
      printf("\n alfainiz[%d] = %g",i,alfa_d[i]);
      fflush(stdout);
    }
  }
  alfa_dense[1] /= (double)n;
  for (i=2; i<=n; i++) {
    alfa_dense[i] = alfa_dense[1];
  }

  if (n > 1) {
    halton(index_halton,d_dense);
  }

  for (i=1; i<=n; i++) {
    for (j=1; j<=n; j++) {
      direzioni[i][j] = 0.0;
    }
    direzioni[i][i] = 1.0;
    d[i] = 1.0;
  }
/*eject*/
  /* Parallel begin */
  /* queryXstore() */
  f = queryXstore(x);
      /* if x in xstore[], defines f, obj, constr[], viol */
      /* else, f = INF */
  if (f == INF) {
    /* this case is not possible since values for x[] */
    /* have already been computed in denconmain() */
    printf("\ndencon: case 1 f = INF = %f cannot occur\n",f);
    printf("since values for x[] have already been computed ");
    exit(1);
  }
  /* Parallel end */

  for (i=1; i<=2*n+1; i++) {
    fstop[i] = f;
  }
/*eject*/
  i_corr = 1;
  i_dense = 1;
  j_dense = 1;

  tipo_direzione = 0;

  for (i=1; i<=n; i++) {
    for (j=1; j<=2*n+1; j++) {
      xfstop[i][j] = x[i];
    }
    z[i]=x[i];
  }

  if(iprint >= 2) {
    printf("\n ----------------------------------");
    printf("\n finiz = %g",f);
    for (i=1; i<=n; i++) {
      printf("\n xiniz[%d] = %g",i,x[i]);
    }
    fflush(stdout); 
  }
/*eject*/
  while (1) {

    alfa_max = -INF;
    if ((n > 1) && (icoordonly == FALSE)) {
      for (i=1; i<=n; i++) {
        alfa_max = max(alfa_max,alfa_coord[i]);
        alfa_max = max(alfa_max,alfa_diag[i]);
        alfa_max = max(alfa_max,alfa_dense[i]);
      }
    } else {
      for (i=1; i<=n; i++) {
        alfa_max = max(alfa_max,alfa_d[i]);
      }
    }

    denconstop();
    alfa_max = -INF;
    for (i=1; i<=n; i++) {
      alfa_max = max(alfa_max,alfa_d[i]);
    }   

    if (istop >= 1) {
      return;
    }

    if (i_corr == 1) {
      for (i=1; i<=n; i++) {
        dconv[i] = 0.0;
      }
      for (i=1; i<=n; i++) {
        for (j=1; j<=n; j++) {
          dconv[j] -= direzioni[j][i];
        }
      }
    }
/*eject*/
    if (num_iter%20 == 0) {
      printf(
         "\n funct = %3d cycle = %d iter = %d obj = %g alfamax = %g",
         num_funct,cycle.sum,num_iter,obj,alfa_max);
    }

    if (iprint >= 1) {
      printf("\n ----------------------------------------------");
      printf("\n iter = %d funct = %d cycle = %df = %g alfa_max = %g",
             num_iter,num_funct,cycle.sum,f,alfa_max);
      fflush(stdout);
    }
    if (iprint >= 2) {
      for (i=1; i<=n; i++) {
        printf("\n x[%d] = %g",i,x[i]);
      }
      for (i=1; i<=ncon; i++) {
        printf("\n constr[%d] = %g and eps[%d] = %g",
               i,constr[i],i,eps[i]);
      }
      fflush(stdout);
    }

    for (i=1; i<=n; i++) {
      d[i] = direzioni[i][i_corr];
    }
/*eject*/
    /* Parallel begin */
    /* store x[] in xstore[] to prevent overwriting by */
    /* values of predicted and linesearch vectors */
    retainXstore(x);
    /* if nProcessors >= 2:
     *   compute xpos[] = x[]+betapos*dir[]
     *           xneg[] = x[]-betaneg*dir[]
     *   for each direction dir[] of direction matrix
     *   no action required if xpos[] and xneg[] of current dir[]
     *   are in cache
     *   evaluate <= nProcessors vectors in parallel, add to xstore[]
     */
    if (nProcessors >= 2) {

      nParallelCandidates = 0;

      /* loop of directions */
      /* j_dir is direction index */
      j_dir = i_corr - 1;
      for (idx_dir=1; idx_dir<=n; idx_dir++) { /* for idx_dir */

        /* increment j_dir */
        j_dir++; 
        /* if j_dir exceeds n, reset to 1 */     
        if (j_dir > n) {
          j_dir = 1;
        }
/*eject*/     
        /* xpos[], xneg[] */
        if (tipo_direzione == 0) { /* cont case */

          /* directions are unit vectors */
          if ((alfa_d[j_dir]-(ub[j_dir]-x[j_dir])) < -1.e-6) {     
              betapos = max(1.e-24,alfa_d[j_dir]);
          } else {
            betapos = ub[j_dir]-x[j_dir];
          } 
          if ((alfa_d[j_dir]-(x[j_dir]-lb[j_dir])) < -1.e-6) {
            betaneg = max(1.e-24,alfa_d[j_dir]);
          } else {
            betaneg = x[j_dir]-lb[j_dir];
          }
          /* since direction = unit vector, computation of */
          /* xpos[], xneg[] can be simplified */    
          for (i=1; i<=n; i++) {
            xpos[i] = x[i];
            xneg[i] = x[i];
          }
          xpos[j_dir] += betapos;
          xneg[j_dir] -= betaneg; 
/*eject*/                    
        } else { /* dense case */
   
          /* dir[] */  
          for (i=1; i<=n; i++) {
            dir[i] = direzioni[i][j_dir];
          }
          betapos = alfa_d[j_dir];
          betaneg = alfa_d[j_dir];
          for (i=1; i<=n; i++) {
            xpos[i] = x[i] + betapos*dir[i];
            xpos[i] = max(lb[i],min(ub[i],xpos[i]));
            xneg[i] = x[i] - betaneg*dir[i];
            xneg[i] = max(lb[i],min(ub[i],xneg[i]));
          }

        } /* end if tipo_direzione == 0, else */
/*eject*/
        /* process xpos[], xneg[]: if not in xstore[], evaluate */
        for (k=1; k<=2; k++) {
          if (k == 1) {
            vector2vector(xpos,pred.xreal,n);
          } else { /* k = 2 */
            vector2vector(xneg,pred.xreal,n);
          }
          i = memberXstore(pred.xreal);
          if (i > 0) {
            /* pred.xreal[] is in xstore[] */
            /* increment pointXstore and move up xstore[k] to */
            /* xstore[pointXstore] */
            moveupXstore(i);
          } else {
            /* pred.xreal[] is not in xstore[] */
            /* check if pred.xreal[] is in parallelCandidate[] */
            flag = FALSE;
            for (nc=0; nc<nParallelCandidates; nc++) {
              if (same_parallelCandidate(pred.xreal,nc,n) == TRUE) {
                /* pred.xreal[] exists in parallelCandidate[], so */
                /* do not store pred.xreal[] */
                flag = TRUE;
                break;
              }
            }
/*eject*/
            if (flag == FALSE) {
              /* pred.xreal[] is not in parallelCandidate[] */
              /* hence store in parallelCandidate[] */
              if (nParallelCandidates > MAX_PROC) {
                printf("\n dencon: nParallelCandidates = %d ",
                       nParallelCandidates);
                printf("must not exceed MAX_PROC = %d",MAX_PROC);
                exit(1);
              }
              vector2parallelCandidate(pred.xreal,
                                       nParallelCandidates,n);
              parallelCandidate[nParallelCandidates].keepFlag = FALSE;
              nParallelCandidates++;
            } /* end if flag == FALSE */                    
          } /* end if i > 0, else */
        } /* end for k */

        if ((j_dir == i_corr) && (nParallelCandidates == 0)) {
          /* j_dir = current direction index, and both xpos[], */
          /* xneg[] are in xstore[]; hence skip prediction */
          /* for all other directions */
          break;      
        }

        if (nParallelCandidates >= nProcessors-1) {
          /* due to number of processors, cannot handle any */
          /* additional directions */
          break;
        }

      } /* end for idx_dir */
/*eject*/
      if (nParallelCandidates > 0) {
        evaluate_parallelCandidate("dencon", TRUE);
        num_funct += nParallelCandidates;
        cycle.sum++;

        /* extract pred.real[] from parallelCandidate[] */
        for (nc=0; nc<nParallelCandidates; nc++) {
          extract_parallelCandidate(nc,
                                    pred.xreal,
                                    &temp,
                                    &pred.obj,
                                    pred.constr,
                                    &pred.constr_violation);
          /* also computes obj, constr[], viol */
          /* retain pred.xreal[], obj, constr[], viol in xstore[] */
          retainXstore(pred.xreal);
        }
      }  /* end if nParallelCandidates > 0 */

    } /* end if nProcessors >= 2 */
    /* Parallel end */
/*eject*/
    if (tipo_direzione == 0) { /* cont case */

      /* Parallel begin */
      /* predict the possible vectors produced by cont linesearch */
      /* store these vectors in plin.allz[][] */
      if (nProcessors >= 2) {
        /* store pointer for xstore[] */
        priorXstore = pointXstore;
        /* initialize counts for plin.allz[] */
        plin.nAllz[1] = -1;
        plin.nAllz[2] = 0;
        for (plin.ielle=1; plin.ielle<=2; plin.ielle++) {
          /* transfer linesearch variables to plin environment */
          transfer2plin(x,&f,d,&alfa,alfa_d,
                        z1,&fz1,z2,&fz2,
                        z,&fz,&num_fal);
          /* execute predict_cont() using plin environment */
          predict_cont(plin.x,&plin.f,plin.d,&plin.alfa,plin.alfa_d,
                       plin.z1,&plin.fz1,plin.z2,&plin.fz2,
                       plin.z,&plin.fz,&plin.num_fal);
        }
        plin.nCheckz[1] = -1;
        plin.nCheckz[2] = 0;
      } /* end if nProcessors >= 2 */
      /* Parallel end */
/*eject*/
      linesearchbox_cont(x,&f,d,&alfa,alfa_d,
                         z1,&fz1,z2,&fz2,
                         z,&fz,&num_fal);

      if(fabs(alfa) >= 1.e-12) {
        x[i_corr] += alfa*d[i_corr];
      }

      /* Parallel begin */
      /* check that x[] occurs in xstore[] */
      fz = queryXstore(x);
           /* also obtains obj, constr[], viol */
      if (fz == INF) {
        printf("\ndencon: cont case, x[] must be in storage");
        exit(1);
      }
      if (nProcessors >= 2) {
        /* reset pointXstore to priorXstore */
        pointXstore = priorXstore; 
      }
      /* place x[] insto xstore[] */
      retainXstore(x);
      /* Parallel end */
/*eject*/
    } else { /* dense case */
      /* Parallel begin */
      /* predict the possible vectors produced by dense linesearch */
      /* store these vectors in plin.allz[][] */
      if (nProcessors >= 2) {
        /* store pointer for xstore[] */
        priorXstore = pointXstore;
        /* initialize counts for plin.allz[] */
        plin.nAllz[1] = -1;
        plin.nAllz[2] = 0;
        for (plin.ielle=1; plin.ielle<=2; plin.ielle++) {
          /* transfer linesearch variables to plin environment */
          transfer2plin(x,&f,d,&alfa,alfa_d,
                        z1,&fz1,z2,&fz2,
                        z,&fz,&num_fal);
          /* execute predict_dense() using plin environment */
          predict_dense(plin.x,&plin.f,plin.d,&plin.alfa,
                        &plin.alfa_d[i_corr],
                        plin.z1,&plin.fz1,plin.z2,&plin.fz2,
                        plin.z,&plin.fz,&plin.num_fal);
        }
        plin.nCheckz[1] = -1;
        plin.nCheckz[2] = 0;
      } /* end if nProcessors >= 2 */
      /* Parallel end */
/*eject*/
      linesearchbox_dense(x,&f,d,&alfa,&alfa_d[i_corr],
                          z1,&fz1,z2,&fz2,
                          z,&fz,&num_fal);
      if(fabs(alfa) >= 1.e-12) {
        for (i=1; i<=n; i++) {
          x[i] = min(ub[i], x[i]+alfa*d[i]);
          x[i] = max(lb[i],x[i]);
        }
      }

      /* Parallel begin */
      /* check that x[] occurs in xstore[] */
      fz = queryXstore(x);
           /* also obtains obj, constr[], viol */
      if (fz == INF) {
        printf("\ndencon: cont case, x[] must be in storage");
        exit(1);
      }
      if (nProcessors >= 2) {
        /* reset pointXstore to priorXstore */
        pointXstore = priorXstore; 
      }
      /* place x[] insto xstore[] */
      retainXstore(x);
      /* Parallel end */

    } /* if tipo_direzione == 0, else */
    for (i=1; i<=n; i++) {
      direzioni[i][i_corr] = d[i];
    }
/*eject*/
    if (fabs(alfa) >= 1.e-12) {
      flag_fail[i_corr] = 0;
      f = fz;
      viol = violz;
      num_fal = 0;
      num_iter++;
    } else {
      flag_fail[i_corr] = 1;

      if(i_corr_fall == 0) { 
        fstop[i_corr] = fz1;
        fstop[2*i_corr] = fz2;
             
        for (j=1; j<=n; j++) {
          xfstop[j][i_corr] = z1[j];
          xfstop[j][2*i_corr] = z2[j];
        }            

        num_fal++;
        num_iter++;
      }
    }

    for (i=1; i<=n; i++) {
      z[i] = x[i];
    }
/*eject*/
    if (i_corr < n) {
      i_corr++;
    } else {
      dval = -INF;
      for (i=1; i<=n; i++) {
        dval = max(dval,alfa_d[i]);
      }
      if ((dval <= soglia) && (n > 1) && (icoordonly == FALSE)) {

        if (tipo_direzione == 0) {

          fmin = fstop[1]; /* = f */
          fmax = fstop[1]; /* = f */
          imin = 1;
          imax = 1;
          doldalfamin = alfa_d[1];
          doldalfamax = alfa_d[1];
          iminalfa = 1;
          imaxalfa = 1;
          for (i=2; i<=n; i++) {
            if (alfa_d[i] < doldalfamin) {
              doldalfamin = alfa_d[i];
              iminalfa = i;
            } 
            if (alfa_d[i] > doldalfamax) {
              doldalfamax = alfa_d[i];
              imaxalfa = i;
            } 
          }
/*eject*/  
          rapalfa = 3.0;

          if (doldalfamax/doldalfamin > rapalfa) {
          
            for (i=1; i<=n; i++) {
              d1[i] = dconv[i];
            }
            dnr = sqrt((double)n);
          } else {              
            for (i=2; i<=2*n; i++) {
              if (fstop[i] < fmin) {
                 fmin = fstop[i];
                 imin = i;
              }
              if (fstop[i] > fmax) {
                fmax = fstop[i];
                imax = i;
              }
            }

            dnr = 0.0;
            doldalfamedio = (doldalfamax+doldalfamin)/2.0;
            for (i=1; i<=n; i++) {             
              d1[i] = xfstop[i][imin] - xfstop[i][imax];
              dnr += d1[i]*d1[i];
            }
            dnr = sqrt(dnr);

            if (dnr <= 1.e-24) {
              for (i=1; i<=n; i++) {
                 d1[i] = dconv[i];
              }
              dnr = sqrt((double)n);
            }
          }
/*eject*/
          /* define H[][] matrix from d1 vector */
          gen_base(d1);
          /* perform Gram-Schmidt orthogonalization on H[][] */
          gram_schmidt();
          /* transfer H[][] matrix into direzione[][] matrix */
          for (i=1; i<=n; i++) {
            for (j=1; j<=n; j++) {
              direzioni[i][j] = H[i][j];
            }
          }

          tipo_direzione = 1;
          for (i=1; i<=n; i++) {                  
            alfa_coord[i] = alfa_d[i];
          }        
          if (doldalfamax/doldalfamin > rapalfa) {
            for (i=1; i<=n; i++) {
              alfa_d[i] = 1.0*alfa_diag[i];
            }
          } else {
            dnr = 0.0;
            for (i=1; i<=n; i++) { 
              dnr += alfa_d[i];
            }         
            dnr /= (double)n;
            for (i=1; i<=n; i++) {
              alfa_d[i] = 1.0*dnr;
            }
          }
             
          if (iprint >= 1) {
            printf("\n fine dir. coordinate");
            fflush(stdout);
          }
/*eject*/           
        } else if (tipo_direzione == 1) {
          /* define H[][] matrix from d_dense vector */
          gen_base(d_dense);
          /* perform Gram-Schmidt orthogonalization on H[][] */
          gram_schmidt();
          /* transfer H[][] matrix into direzione[][] matrix */
          for (i=1; i<=n; i++) {
            for (j=1; j<=n; j++) {
              direzioni[i][j] = H[i][j];
            }
          }
          index_halton += 1; /* option: += LARGEPRIME */
          halton(index_halton,d_dense);

          tipo_direzione = 2;
          for (i=1; i<=n; i++) {
            alfa_diag[i] = alfa_d[i];
          }
              
          dnr = 0.0;
          for (i=1; i<=n; i++) {
            dnr += alfa_d[i];
          }          
          dnr /= (double)n;

          for (i=1; i<=n; i++) {
            alfa_d[i] =1.e+1*dnr;
          } 

          if (iprint >= 1) {
            printf("\n fine dir. n+1");
            fflush(stdout);
          }
/*eject*/
        } else if (tipo_direzione == 2) {

          for (i=1; i<=n; i++) {
            for (j=1; j<=n; j++) {
              direzioni[i][j] = 0.0;
            }
            direzioni[i][i] = 1.0;
          }

          tipo_direzione = 0;

          for (i=1; i<=n; i++) {
            alfa_dense[i] = alfa_d[i];
            alfa_d[i] = 1.0*alfa_coord[i];
          }         

          if (iprint >= 1) {
            printf("\n fine dir. densa");
            fflush(stdout);
          }

        } else {
          printf("\n dencon: tipo_direzione = %d != 0, 1, 2",
                 tipo_direzione);
          exit(1);
        } /* end if tipo_direzione == 0, else if ... */
      
        i_corr = 1; 

      } /* end if dval < soglia ... */
   
      i_corr = 1;

    } /* end if i_corr < n, else */
/*eject*/   
    /* Parallel begin */
    /* DEBUG  begin trajectory */
    fprintf(trajectoryfil,"\n%d",num_iter);
    for (i=1; i<=n; i++) {
      fprintf(trajectoryfil," %f",x[i]); 
    }
    /* DEBUG end */
    /* queryXstore() */
    f = queryXstore(x);
        /* if x in xstore[], defines f, obj, constr[], viol */
        /* else, f = INF */
    if (f == INF) {
       /* this case is not possible since values for x[] */
       /* have already been computed regardless of case */
      printf("\ndencon: case 2 f = INF = %f cannot occur ",f);
      printf("\nsince values for x[] have already been computed ");
      exit(1);
    }
    /* Parallel end */
/*eject*/
    if ((viol > 0.0) && (ncon >= 1)) {      
      cambio_eps = FALSE;
      maxeps = -INF;
      for (i=1; i<=ncon; i++) {
        maxeps = max(maxeps,eps[i]);
      }
      dval = -INF;
      for (i=1; i<=n; i++) {
        dval = max(dval,alfa_d[i]);
      }

      if (iprint >= 1) {
        printf("\n**************************************");
        printf("\n**************************************");
      }
      for (i=1; i<=ncon; i++)  {
        if (eps[i]*constr[i] > 1.0e-2*dval) { /* orig. factor = 1.0 */
          eps[i] *= 1.e-2;
          if (iprint >= 1) {
            printf(
            "\n*********** aggiorno eps[%d] = %g *************",
            i, eps[i]);
            fflush(stdout);
          }
          cambio_eps = TRUE;
        }
      }
      if (iprint >= 1) {
        printf("\n**************************************");
        printf("\n**************************************");
      }
/*eject*/
      if (cambio_eps == TRUE) {

        /* recompute f using new eps[] */
        f = obj;
        for (i=1; i<=ncon; i++) {
          if (eps[i] <= 0.0) {
            printf("\n dencon: error, eps[%d] = %g <= 0.0",i,eps[i]);
            exit(1);
          }
          f += max(0.0,constr[i])/eps[i];
        }

        /* recompute alfa_d[] */
        for (i=1; i<=n; i++) {
          alfa_d[i] = max(1.e-3,min(1.0,fabs(x[i])));
          if (iprint >= 1) {
            printf("\n alfainiz[%d] = %g",i, alfa_d[i]);
            fflush(stdout);
          }
        } 
      }
    }
    viol_old = viol;
    for (i=1; i<=ncon; i++) {
      constr_old[i] = constr[i];
    }

  } /* end while (1) */

  return;

}
/*eject*/
/**************************************************************
 *   void denconSolution(char *label): display
 *   obj, xreal, constr, eps, violvalue
 *   under the heading given by label
 **************************************************************/
void denconsolution(char *label) {

  int i;

  printf("\n------------------------");
  printf("\n---- %s values ----",label);
  printf("\n------------------------");
  /* obj */
  printf("\nobj = %g\n",obj);
  /* xreal */
  for (i=1; i<=nreal; i++) {
    printf("\nxreal[%d] = %g",i,xreal[i]);
  }
  printf("\n");
  /* constr and eps */
  for (i=1; i<=ncon; i++) {
    printf("\nconstr[%d] = %g\teps[%d] = %g",
           i,constr[i],i,eps[i]);
  }
  printf("\n");
  /* violvalue */
  printf("\nmax violation value = %g",violvalue);
  if (violvalue == 0.0) {
    printf("\nsolution is feasible");
  } else {
    printf("\nsolution is infeasible");
  } 
  printf("\n------------------------");
  printf("\n");
  fflush(stdout);

  return;

}
/*eject*/
/**************************************************************
 *   void denconstop(): evaluate stopping criteria          
 **************************************************************/
void denconstop() {

  istop = 0;

  if (alfa_max <= alfa_stop) {
    istop = 1;
    return;
  }

  if ((gOption.objgoal == TRUE) &&
      (bestobj <= objGoal[0])) {
    istop = 3;
    return;
  }

  if (num_funct > nf_max) {
    istop = 2;
    return;
  }

  return;

}
/********* last record of dencon.c **********/
