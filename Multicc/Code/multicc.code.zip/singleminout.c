/* Utility routines */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

# include "global.h"
# include "rand.h"

# include "sample.lb.h"
/***************************************************************
 *
 * subroutines in this file:
 *   int decideAcceptance(double *x)
 *   void prepareAcceptRejectCandidate()
 *   void singleminoutfile2candidate()
 ****************************************************************/
/*eject*/
/**************************************************************
 * decideAcceptance(double *x): decide of x[] acceptance using
 *      nearest case of acceptCandidate[] or rejectCandidate[] 
 *      with Manhattan distance
 **************************************************************/
int decideAcceptance(double *x) {

  int j, n;

  double dist, mindist;

  initPop.nTotal++;

  /* if singleminout option is not specified, accept */
  if (gOption.singleminout == FALSE) {
    initPop.nAccept++;
    return TRUE;
  }

  mindist = INF;
  /* find closest acceptCandidate[] using Manhattan distance */
  for (n=0; n<nAcceptCandidates; n++) {
  dist = 0.0;
    for (j=0; j<nreal; j++) {
      dist += fabs(x[j]-acceptCandidate[n].xvalue[j]);
    }
    mindist = min(dist, mindist);
  }

  /* compare mindist with dist of closest rejectCandidate[] */
  for (n=0; n<nRejectCandidates; n++) {
    dist = 0.0;
    for (j=0; j<nreal; j++) {
      dist += fabs(x[j]-rejectCandidate[n].xvalue[j]);
    }
    if (dist < mindist) {
      initPop.nReject++;
      return FALSE;
    }
  }       

  initPop.nAccept++;
  return TRUE;

}
/*eject*/
/**************************************************************
 * prepareAcceptRejectCandidate(): 
 *      prepare acceptCandidate[] and rejectCandidate[] for   
 *      initialization process
 **************************************************************/
void prepareAcceptRejectCandidate() {

  int j, n;

  /* store records of singleminout file in candidate[] */
  /* with keepFlag = TRUE */
  singleminoutfile2candidate();

  /* eliminate infeasible, dominated, duplicate candidates */
  /* return = TRUE if there are feasible candidates */
  /*          FALSE if all candidates are infeasible */   
  if (reduceInfeasibleDominatedDuplicateCandidate() == FALSE) {
    printf("\n prepareSingleminout: ");
    printf("\n singleminout file has no feasible records");
    exit(1);
  }
  /* candidate[].keepFlag = TRUE: feasible, undominated cases */
  /*                      = FALSE: else */

  /* max and min of objs for candidate[].keepFlag = TRUE cases */
  for (j=0; j<nobj; j++) {
    maxvalue.acceptObj[j] = -INF;
    minvalue.acceptObj[j] = INF;
    for (n=0; n<nCandidates; n++) {
      if (candidate[n].keepFlag == TRUE) {
        maxvalue.acceptObj[j] = max(candidate[n].obj[j],
                                    maxvalue.acceptObj[j]);
        minvalue.acceptObj[j] = min(candidate[n].obj[j],
                                    minvalue.acceptObj[j]);
      }
    }
    /* if maxvalue = minvalue: */
    /*    reset maxvalue = INF and minvalue = -INF so that */
    /*    obj j has no effect on acceptance of population cases */  
    if (maxvalue.acceptObj[j] == minvalue.acceptObj[j] ) {
      maxvalue.acceptObj[j] = INF;
      minvalue.acceptObj[j] = -INF;
    }
  }

  /* define candidate[n].keepFlag */
  /*     = TRUE: for all j, obj[j] <= 10.0*maxvalue.acceptObj[j] */
  /*     = FALSE: else */
  for (n=0; n<nCandidates; n++) {
    candidate[n].keepFlag = TRUE;
    for (j=0; j<nobj; j++) {
      if (candidate[n].obj[j] > 
         (maxvalue.acceptObj[j] + 9.0*fabs(maxvalue.acceptObj[j]))) {
        candidate[n].keepFlag = FALSE;
        break;
      }
    }
  }

  nAcceptCandidates = 0;
  /* save candidate[].keepFlag = TRUE cases in acceptCandidate[] */
  candidateTrue2someCandidate(acceptCandidate,&nAcceptCandidates);

  /* reverse candidate[n].keepFlag TRUE/FALSE values */
  for  (n=0; n<nCandidates; n++) { 
    if (candidate[n].keepFlag == TRUE) {
      candidate[n].keepFlag = FALSE;
    } else {
      candidate[n].keepFlag = TRUE;
    }
  }

  nRejectCandidates = 0;
  /* save candidate[].keepFlag = TRUE cases in acceptCandidate[] */
  candidateTrue2someCandidate(rejectCandidate,&nRejectCandidates);

  if (gOption.printdetail > 1) {
    printf("\n");
    printf("\n Option singleminout = 1: candidate collection of");
    printf("\n single function min for accept/reject decisions");
    printf("\n   number of accept candidates = %d",nAcceptCandidates);
    printf("\n   number of reject candidates = %d",nRejectCandidates);
    printf("\n");
  }

  return;

}
/*eject*/
/**************************************************************
 * singleminoutfile2candidate(): store records of
 *   singleminout file in candidate[]; compute constr_violation
 *   and define keepFlag = TRUE
 **************************************************************/
void singleminoutfile2candidate() {

  int i, j, nrec, freq;

  char lineread[MAXLEN];

  if ((singleminoutfil = 
       openFile(singleminoutfile,"r")) == NULL) {
    printf("\n singleminoutfile2candidate: ");
    printf("cannot open singleminout file = %s case 1",
           singleminoutfile);
    exit(1);
  }

  /* count nrec = number of records in file */
  nrec = 0;
  while (fgets(lineread,MAXLEN,singleminoutfil) != NULL) {
    nrec++;
  }
  closeFile(singleminoutfil);

  /* define frequency with which records are selected */
  freq = nrec/MAX_PRIOR + 1;

  if ((singleminoutfil = 
       openFile(singleminoutfile,"r")) == NULL) {
    printf("\n singleminoutfile2candidate: ");
    printf("cannot open singleminout file = %s case 2",
           singleminoutfile);
    exit(1);
  }
/*eject*/
  nCandidates = 0;
  nrec = 0;
  while (fgets(lineread,MAXLEN,singleminoutfil) != NULL) {

    nrec++;
    if (nrec%freq != 0) {
      /* skip this record */
      continue;
    }

    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }
    /* skip over empty or comment '#' lines */
    if ((lineread[0] == '\0') || (lineread[0] == '#')) {
      continue;
    }

    if (tokenize(lineread) != (nobj+ncon+nreal)) {
      printf(
       "\n singleminoutfile2candidate: singleminout record %s ",
       lineread);
      printf("\n has %d strings, but should have %d strings",
              nTokens, nobj+ncon+nreal);
      exit(1);
    }
/*eject*/
    if (nCandidates == MAX_PRIOR) {
      printf(
      "\n singleminoutfile2candidate: number of singleminout data ");
      printf("records > MAX_PRIOR = %d,", MAX_PRIOR);
      printf(" but this should not happen due to sampling");
      exit(1); 
    }

    /* get obj[], constr[], and xvalue[] from token[] */
    for (j=0; j<nobj; j++) {
      candidate[nCandidates].obj[j] =
          atof(token[j]);
    }
    for (j=0; j<ncon; j++) {
      candidate[nCandidates].constr[j] =
          atof(token[j+nobj]);
    }
    for (j=0; j<nreal; j++) {
      candidate[nCandidates].xvalue[j] =
          atof(token[j+nobj+ncon]);
    }

    /* compute constraint violation */
    candidate[nCandidates].constr_violation = 0.0;
    for (j=0; j<ncon; j++) {
      if (candidate[nCandidates].constr[j]<0.0) {
        candidate[nCandidates].constr_violation += 
              candidate[nCandidates].constr[j];
      }
    }

    candidate[nCandidates].keepFlag = TRUE;

    nCandidates++;       
  } /* end while fgets */

  closeFile(singleminoutfil);

  return;

}
/********* last record of singleminout.c ******/
