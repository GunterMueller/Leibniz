/* transfer.nomad.exe called by nomad */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"

# include "sample.lb.h"
# include "multicc.h"
/************************************************************
 *  subroutines in this file:
 *     int main program for transfer.nomad.exe
 *     void evaluateNomadVector()
 ************************************************************/
/*eject*/
double obj[MAX_OBJ], xreal[MAX_VARIABLE], constr[MAX_CONSTRAINT],
       constr_violation;

int main (int argc, char **argv) {

  int j, n, shift;

  char filename[MAX_ENTRY];

  double singleobj;
  char lineread[MAXLEN];

  char inputfile[MAX_ENTRY];
  char outputfile[MAX_ENTRY];
  FILE *inputfil;
  FILE *outputfil;

  /* shift = 2 = number of entries ahead of xreal[] in input file
   * shift is caused by the options BB_INPUT_INCLUDE_SEED and
   * BB_INPUT_INCLUDE_TAG
   * caution: do not change options BB_INPUT_INCLUDE_SEED and
   *          BB_INPUT_INCLUDE_TAG
   */ 
  shift = 2;

  /* get parameters from transfer.nomad.params file */
  readTransferNomadParams();
  /* read processor file */
  readProcessor();

  /* if params file exists, read copy in temporary directory */
  if (strcmp(gOption.params,"NOPARAMSFILE") != 0) {
    sprintf(filename,"%s%s",gOption.tempdir,gOption.params);
    readParams(filename,FALSE);
  }

  /* define and open singleminout file */
  if (gOption.singleminout == TRUE) {
    sprintf(singleminoutfile,"%s%s.singleminout",
                          gOption.tempdir, problemName);
    if ((singleminoutfil = fopen(singleminoutfile,"a")) == NULL) {
      printf("\n nomad transfer cannot open singleminout file = %s",
             singleminoutfile);
      exit(1);
    } 
  }
/*eject*/
  if ( argc == 2 ) {
    strcpy(inputfile,argv[1]);
  } else {
    printf(
      "\n transfer.nomad: nomad input file name not specified");
    exit(1);
  }

  /* DEBUG begin */
  /* (1) comment out above code defining input file
   * (2) activate next three lines below to retain nomad input
   *     during nomad run; that run will terminate with nomad
   *     error message since this program does not produced an
   *     output file 
   */
 /*  sprintf(filename,"cp %s nomad.example.input",argv[1]);
  system(filename);
  exit(1); */
  /* (3) for the debugging run of this program, comment out 
   *     the above three lines and activate the next line to 
   *     define the input file
   */
  /* sprintf(inputfile,"nomad.example.input"); */
  /* DEBUG end */

  if ((inputfil = fopen(inputfile,"r")) == NULL) {
    printf("\n transfer.nomad: nomad input file %s does not exist",
           inputfile);
    exit(1);
  }
  /* derive outputfile from inputfile by replacing "input" */
  /* by "output" */
  /* an alternate method would be writing to standard output, */
  /* to be picked up by nomad using '>' redirection */
  strcpy(outputfile,inputfile);
  sprintf(&outputfile[strlen(inputfile)-strlen("input")],
          "output");
/*eject*/
  if (nProcessors > 0) {
    /* evaluation by parallel processors */
    /* place records of input file into parallelCandidate[] */       

    nParallelCandidates = 0;
    while (fgets(lineread,MAXLEN,inputfil) != NULL) {

      if (nParallelCandidates == MAX_PROC) {
        printf(
        "\n transfer.nomad: MAX_PROC = %d is too small",MAX_PROC);
        exit(1);
      }

      /* get tokens */
      if (tokenize(lineread) != (shift+nreal)) {
        printf("\n transfer.nomad: input record %d has %d strings ",
               nParallelCandidates+1,nTokens);
        printf("\n but should have %d",shift+nreal); 
        exit(1);
      }

      /* convert token[j], j>=2, and store in parallelCandidate[] */
      for (j=0; j<nreal; j++) {
        parallelCandidate[nParallelCandidates].xvalue[j] =  
            atof(token[j+shift]);
      }
      nParallelCandidates++;

    } /* end while */

    if (nParallelCandidates == 0) {
      printf(
        "\n transfer.nomad: nomad input file %s has no records",
        inputfile);
      exit(1);
    }
    fclose(inputfil);
/*eject*/
    /* evaluate parallelCandidate[] */
    evaluate_parallelCandidate("nomad",TRUE);

    /* define output file from parallelCandidate[] */
    if ((outputfil = fopen(outputfile,"w")) != NULL) {
      for (n=0; n<nParallelCandidates; n++) {
        fprintf(outputfil,"%g ",parallelCandidate[n].obj[0]);
        for (j=0; j<ncon; j++) {
          fprintf(outputfil,"%g ",parallelCandidate[n].constr[j]);
        }
        fprintf(outputfil,"\n");
      }   
      fclose(outputfil);
    } else {
      printf(
      "\n transfer.nomad: output file %s cannot be opened, case 1",
      outputfile);
      exit(1);
    }

    /* close singleminout file */
    if (gOption.singleminout == TRUE) {
      fclose(singleminoutfil);
    }

    return 0;
  } /* end if nProcessors > 0 */
/*eject*/
  /* regular evaluation of one record, using current processor */
  /* get xreal[] from file produced by nomad */

  if ((inputfil = fopen(inputfile,"r")) != NULL) {
    if (fgets(lineread,MAXLEN,inputfil) != NULL) {
      /* get tokens */
      if (tokenize(lineread) != (shift+nreal)) {
        printf("\n transfer.nomad: input record has %d strings ",
               nTokens);
        printf("\n but should have %d",shift+nreal); 
        exit(1);
      }
/*eject*/
      /* convert token[j], j>=2, to xreal[] */
      for (j=0; j<nreal; j++) {
        xreal[j] =  atof(token[j+shift]);
      } /* end for j */

      /* evaluate xreal */
      evaluateNomadVector();

      singleobj = obj[0]; 
    } else {
      singleobj = 1e20;
    } /* end if  fgets(lineread,MAXLEN,inputfil) != NULL, else */
    fclose(inputfil);  
  } else {
    singleobj = 1e20;
  } /* end if (inputfil = fopen(inputfile,"r")) != NULL, else */
/*eject*/
  /* DEBUG: activate five lines below */
  /* printf("\n\nblackbox output file = %s",outputfile);  
  printf("\nblackbox output: obj = %g ",singleobj);
  for (j=0; j<ncon; j++) {
    printf("constr[%d] = %g ",j+1,constr[j]);
  } */

  if ((outputfil = fopen(outputfile,"w")) != NULL) {
    fprintf(outputfil,"%g ",singleobj);
    for (j=0; j<ncon; j++) {
      fprintf(outputfil,"%g ",constr[j]);
    }   
    fclose(outputfil);

    /* close singleminout file */
    if (gOption.singleminout == TRUE) {
      fclose(singleminoutfil);
    }

    return 0;
  }

  printf(
     "\n transfer.nomad: output file %s cannot be opened, case 2",
     outputfile);
  exit(1);   

}
/*eject*/
/**************************************************************
 * void evaluateNomadVector():
 * evaluate functions and constraints with xreal[] vector 
 **************************************************************/
void evaluateNomadVector() {

  int j, juse;

  /* use nobjEvaluate for evaluation of xvalue */
  nobj = nobjEvaluate;

  /* compute obj and constr values */
  if (strcmp(gOption.input,"NOINPUTFILE") != 0) {
    queryBlackBox(problemName,xreal,obj,constr);
  } else {
    test_problem (TRUE, problemName, xreal, 
                  obj, constr);
    /* first parameter usage:
     *   TRUE: compute obj, constr values
     *   FALSE: define nreal, nbin, nobj, ncon,
     *                 min_realvar[], max_realvar[]
     */
  }

  /* have obj and constr according to nsga/gencc convention */

  /* store obj[], constr[], xreal[] in singleminout file */
  if (gOption.singleminout == TRUE) {
    fprintf(singleminoutfil,"\n## cycle\n");
    for (j=0; j<nobjEvaluate; j++) {
      fprintf(singleminoutfil,"%g ", obj[j]);
    }
    for (j=0; j<ncon; j++) {
      fprintf(singleminoutfil,"%g ", constr[j]);
    }
    for (j=0; j<nreal; j++) {
      fprintf(singleminoutfil,"%g ", xreal[j]);
    }
  }
/*eject*/
  if ((gOption.objrange == TRUE) && (nobjSolve == 1)) {
    /* compute weighted sum of objs */
    /* for single function minimization */
    /* find index juse of single function */
    for (j=0; j<nobj; j++) {
      if (objFactor[j] != 0.0) {
        juse = j;
        break;
      }  
    }
    /* compute weighted sum for positive objrange values */
    /* factor WEIGHTED_SUM_FACTOR gives weight */
    /* to obj[juse] versus obj[j] */
    if (objRange[juse] > 0.0) {
      for (j=0; j<nobj; j++) {
        if ((j != juse) && (objRange[j] > 0.0)) {
          obj[juse] += WEIGHTED_SUM_FACTOR * 
                       (objRange[juse]/objRange[j]) * 
                       obj[j];
        }  
      }
    }
  }
/*eject*/
  /* if obj factors are used, apply them to obj[] */
  /* and eliminate cases with factor = 0 */
  if (gOption.objfactor == TRUE) {
    juse = 0;
    for (j=0; j<nobj; j++) {
      if (objFactor[j] != 0.0) {
        obj[juse] = obj[j] * objFactor[j];
        juse++;
      }
    }
    if (juse != nobjSolve) {
      printf("\n evaluateNomadVector: nobjSolve = %d != juse = %d", 
             nobjSolve, juse);
      exit(1);
    }
  }

  /* ignoreconstraint option */
  if (gOption.ignoreconstraint == TRUE) {
    for (j=0; j<ncon; j++) {
      constr[j] = 0.0;
    }
  }

  /* caution: nomad assumes constraints <= 0  */
  /*          gencc/nsga assumes constraints >= 0 */
  /* hence change sign of constraint values, since they were */
  /* computed according to the gencc/nsga convention */
  /* constr_violation below is defined for nomad, not for gencc/nsga */
  constr_violation = 0.0;
  for (j=0; j<ncon; j++) {
    constr[j] *= -1.0;
    constr_violation += max(0,constr[j]);
  }

  /* if stopcriterion = feasible, define obj[0] = constr_violation */
  if (strcmp(gOption.stopcriterion,"feasible") == 0) {
    obj[0] = constr_violation;
  }

  return;

}
/*********last record of transfer.nomad.c *******************/  
