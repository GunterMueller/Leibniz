/* routines initializing and evaluating problem */

# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <unistd.h>
# include <time.h>

# include "global.h"
# include "sample.lb.h"
# include "denpar.h"

/***************************************************************
 *
 * subroutines in this file:
 *       void   convertDenparOutput2finalPopOut();
 *       void   denparbounds()
 *       void   denparstart(double *x)
 *       double evaluateDenparVector(double *x)
 **************************************************************/
/*eject*/
/**************************************************************
 *   void convertDenparOutput2finalPopOut(): convert denpar 
 *     output to final_pop.out
 *   caution: constraint violation output follows nsga/gencc rule,
 *            which is sum of violations, and not denpar rule,
 *            which is max of violations
 *   uses or modifies: nreal, ncon, obj, constr, xreal, num_iter      
 **************************************************************/
void convertDenparOutput2finalPopOut(){

  int j;
  double constr_violation;

  char finalpopfile[MAX_ENTRY];
  FILE *finalpopfil;

  /* define file name */
  sprintf(finalpopfile,"final_pop.out");

  /* open files */
  finalpopfil = openFile(finalpopfile,"w");

  if (nobj != 1) {
    printf("\n convertDenparOutput2finalPopOut: nobj = %d != 1",
           nobj);
    exit(1);
  }

  /* write final_pop.out file */
  fprintf(finalpopfil,
    "# This file contains the data of final population\n");
  fprintf(finalpopfil,
"# of objectives = %d , # of constraints = %d , # of real_var = %d , constr_violation , rank , crowding_distance , # of evaluations = %d\n",
      nobj,ncon,nreal,num_funct);
/*eject*/
  fprintf(finalpopfil,"%g ",obj);

  /* constr values were computed according to denpar rule */ 
  /* of g() <= 0; but for final_pop.out use gencc/nsga rule */
  /* of g() >= 0; hence use constr below with '-' sign */
  /* caution: index shift required */ 
  for (j=1; j<=ncon; j++) {
    fprintf(finalpopfil,"%g ",-constr[j]);
  }

  /* caution: index shift required */
  for (j=1; j<=nreal; j++) {
    fprintf(finalpopfil,"%g ",xreal[j]);
  }

  /* compute constr_violation using nsga/gencc rule, which */
  /* specifies violation = sum of violations */
  /* caution: index shift required */
  constr_violation = 0.0;
  for (j=1; j<=ncon; j++) {
    if (-constr[j] < 0) {
      constr_violation += -constr[j];
    } 
  }
  fprintf(finalpopfil,"%g ",constr_violation);

   /* rank */
  fprintf(finalpopfil,"1 ");

  /* crowding distance */
  fprintf(finalpopfil,"1.000000e+14 "); 

  fprintf(finalpopfil,"\n"); 

  closeFile(finalpopfil);

  return;

}
/*eject*/
/**************************************************************
 *   void denparbounds(): defines lb and ub bounds for given problem
 *   uses or modifies: nreal,lb,ub
 **************************************************************/
void denparbounds() {

  int j;

  /* caution: index shift required */
  for (j=1; j<=nreal; j++) {
    lb[j] = min_realvar[j-1];
    ub[j] = max_realvar[j-1];
  }

  return;

}
/*eject*/
/**************************************************************
 *   void denparstart(double *x): defines initial vector x
 *   uses or modifies: nreal
 **************************************************************/
void denparstart(double *x) {

  int j;

  /* caution: index shift required */
  if (nInputCandidates > 0) {
    /* use inputCandidate[0].xvalue as starting point */
    for (j=1; j<=nreal; j++) {
      x[j] = inputCandidate[0].xvalue[j-1];
    }
  } else {
    /* choose midpoint between bounds */
    for (j=1; j<=nreal; j++) {
        x[j] = (max_realvar[j-1]+min_realvar[j-1])/2.0;
    }
  }

  return;

}
/*eject*/
/**************************************************************
 *   double evaluateDenparVector(double *x): returns obj value 
 *   for given vector x
 *   caution: denpar vectors start with index = 1, while
 *            local.xreal, local.obj, local.constr follow the
 *            general multicc convection and start with index = 0
 *   uses or modifies: constr[], viol, nreal       
 **************************************************************/
double evaluateDenparVector(double *x){

  struct {
    double constr[MAX_CONSTRAINT];
    double obj[MAX_OBJ];
    double xreal[MAX_VARIABLE];
  } typedef Local;
  Local local;

  int j, juse;

  juse = 0; /* to suppress compiler warning */

  /* define local.xreal from denpar x */
  /* caution: index shift required */
  for (j=1; j<=nreal; j++) {
    local.xreal[j-1] = x[j];
  }

  /* use nobjEvaluate for evaluation of xvalue */
  nobj = nobjEvaluate;
/*eject*/
  /* compute local.obj and local.constr values */
  if (strcmp(gOption.input,"NOINPUTFILE") != 0) {
    queryBlackBox(problemName,local.xreal,local.obj,local.constr);
  } else {
    test_problem (TRUE, problemName, local.xreal, 
                  local.obj, local.constr);
    /* first parameter usage:
     *   TRUE: compute local.obj, local.constr values
     *   FALSE: define nreal, nbin, nobj, ncon,
     *                 min_realvar[], max_realvar[]
     */
  }

  /* store local.obj[], local.constr[], local.xreal[] */
  /* in singleminout file */
  if (gOption.singleminout == TRUE) {
    fprintf(singleminoutfil,"\n## cycle\n");
    for (j=0; j<nobjEvaluate; j++) {
      fprintf(singleminoutfil,"%g ", local.obj[j]);
    }
    for (j=0; j<ncon; j++) {
      fprintf(singleminoutfil,"%g ", local.constr[j]);
    }
    for (j=0; j<nreal; j++) {
      fprintf(singleminoutfil,"%g ", local.xreal[j]);
    }
  }
/*eject*/
  if ((gOption.objrange == TRUE) && (nobjSolve == 1)) {
    /* compute weighted sum of objs */
    /* for single function minimization */
    /* find index juse of single function */
    for (j=0; j<nobj; j++) {
      if (objFactor[j] != 0.0) {
        juse = j;
        break;
      }  
    }
    /* compute weighted sum for positive objrange values */
    /* factor WEIGHTED_SUM_FACTOR gives weight */
    /* to obj[juse] versus obj[j] */
    if (objRange[juse] > 0.0) {
      for (j=0; j<nobj; j++) {
        if ((j != juse) && (objRange[j] > 0.0)) {
          local.obj[juse] += WEIGHTED_SUM_FACTOR * 
                       (objRange[juse]/objRange[j]) * 
                       local.obj[j];
        }  
      }
    }
  }
/*eject*/
  /* if obj factors are used, apply them to local.obj[] */
  /* and eliminate cases with factor = 0 */
  if (gOption.objfactor == TRUE) {
    juse = 0;
    for (j=0; j<nobj; j++) {
      if (objFactor[j] != 0.0) {
        local.obj[juse] = local.obj[j] * objFactor[j];
        juse++;
      }
    }
    if (juse != nobjSolve) {
      printf("\n evaluateDenparVector: nobjSolve = %d != juse = %d", 
             nobjSolve, juse);
      exit(1);
    }
  }

  /* caution: denpar assumes constraints <= 0  */
  /*          gencc/nsga assumes constraints >= 0 */
  /* hence change sign of local constraint values, since they were */
  /* computed according to the gencc/nsga convention */
  for (j=0; j<ncon; j++) {
    local.constr[j] *= -1.0;
  }

  /* ignoreconstraint option */
  if (gOption.ignoreconstraint == TRUE) {
    for (j=0; j<ncon; j++) {
      local.constr[j] = 0.0;
    }
  }

  /* reset nobj to nobjSolve */
  nobj = nobjSolve;

  /* define denpar constr from local.constr */
  /* caution: index shift required */
  viol = 0.0;
  for (j=1; j<=ncon; j++) {
    constr[j] = local.constr[j-1];
    viol = max(viol,constr[j]);
  }

  return local.obj[0];

}
/***************** last record of denparProblem.c ****************/
