/*  first record of getcnf.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"

int abs();
/*
 * *******************************************************
 *  subroutine getcnf
 * 
 *       get cnf formulation for generate step
 *       from variables and arrays trxxxxxx
 *       of translate step
 *
 *   output:  if succss = 1: cnf formulation in layer 1
 *               succss = 0: problem could not be found
 * 
 *  caution:  matrix rows only are read and stored.
 * 
 * *******************************************************
 * 
 */
void getcnf() {
/*
 */
  static long i,j,js,jx;
/*
 */
  void wrtcnf();
/*
 *  minimization flag
 */
  optimz = cstflg;
/*
 *  problem name
 */
  strcpy(&prbnam_(1,1),trprbnam);
/*
 *  initialize column count
 */
  ncols = trncols;
/*
 *  error if too many columns
 */
  if (ncols>=colmax) {
    printf("*************************************\n");
    printf("Too many variables in CNF formulation\n");
    printf("Stop program generation\n");
    printf("*************************************\n");
    fprintf(errfil,"*************************************\n");
    fprintf(errfil,"Too many variables in CNF formulation\n");
    fprintf(errfil,"Stop program generation\n");
    fprintf(errfil,"*************************************\n");
    succss = 0;
    return;
  }
/*
 *  column information: colnam including delete option, 
 *  cvatf, trucst, falcst
 */
  for (j=1;j<=trncols;j++) {
    strcpy(&colnam_(1,j),&trcolnam_(1,j));
    strcpy(&colnam_(58,j),&trcolnam_(58,j));
    cvatf_(j) = trcvatf_(j);
    trucst_(j)=trtrucst_(j);
    falcst_(j)=trfalcst_(j);
  }
/*
 *  process cnf clauses
 */
  nrows = trnrows;
  nanzs = trnanzs;
/*
 *  error if too many rows
 */
  if (nrows>=rowmax) {
    printf("*************************************\n");
    printf("Too many clauses in CNF formulation\n");
    printf("Stop program generation\n");
    printf("*************************************\n");
    fprintf(errfil,"*************************************\n");
    fprintf(errfil,"Too many clauses in CNF formulation\n");
    fprintf(errfil,"Stop program generation\n");
    fprintf(errfil,"*************************************\n");
    succss = 0;
    return;
  }
/*
 *  error if too many nonzeros
 */
  if (nanzs>=anzmax) {
    printf("*************************************\n");
    printf("Too many literals in CNF file\n");
    printf("Stop program generation\n");
    printf("*************************************\n");
    fprintf(errfil,"*************************************\n");
    fprintf(errfil,"Too many literals in CNF file\n");
    fprintf(errfil,"Stop program generation\n");
    fprintf(errfil,"*************************************\n");
    succss = 0;
    return;
  }
/*
 *  get row data
 */
  for (i=1;i<=trnrows;i++) {
/*
 *  row name, level, and delete option
 */ 
    strcpy(&rownam_(1,i),&trrownam_(1,i));
    strcpy(&rownam_(54,i),&trrownam_(54,i));
/*
 *  row matrix
 */
    ptamar_(i)=trptamar_(i);
    nzamar_(i)=trnzamar_(i);
    for (jx=1;jx<=trnzamar_(i);jx++) {
      js = tramatrw_(jx+trptamar_(i));
      j = abs(js);
      if (js > 0) {
        amatrw_(jx+ptamar_(i)) =  trcolusx_(j);
      } else {
        amatrw_(jx+ptamar_(i)) = -trcolusx_(j);
      }
    }    
  }
  /*
 *  initialize ncls, nrws, nnzs for layer 1
 */
  ncls_(1) = ncols;
  nrws_(1) = nrows;
  nnzs_(1) = nanzs;

  succss = 1;
/*
 *  for debugging purposes, uncomment wrtcnf() command
 *  and obtain cnf formulation on screen
 */
/*  wrtcnf(); */
/*
 */
  return;
}
/*  last record of getcnf.c ****** */
  

