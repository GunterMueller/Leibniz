/*  first record of maxflow.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*
 * **********************************************************
 *  module max flow routines      
 * 
 *  purpose:  computes max flow from csourc, rsourc nodes to 
 *            csink, rsink, nodes for component 
 *            qblock in layer 1.
 * 
 *    input:  component qblock in layer 1, with correct indices 
 *            and counts.             
 *            arrays assumed defined:
 *              - matrix data amatcl, amatrw
 *              - nrows, ncols, nblks
 *              - colnam, rownam, prbnam
 *              - matrix indices as follows:
 *                  all columns j active (ciact(j) = 1)
 *                  all rows i active  (riact(i) = 1)
 *                  remaining indices must be consistent 
 *                  with these assignments.  
 *              - counts cnxxx, rnxxx
 *              - all cost(j) .ge. 0 if optimz = 1
 *              - scale, idxcol, idxrow
 *              - dlclop, dlrwop  
 *              - lcllim, ucllim, lrwlim, urwlim
 *              - csourc, rsourc, csink, rsink
 * 
 *     additional input requirements as well as the output 
 *     are given with each subroutine of this module.
 * 
 *     calling sequence:          
 *       maxflw     find max flow assuming zero as starting 
 *                  flow vector.
 *         intflw   initialize flows to zero by setting 
 *                  clpath, claugm, clstat, rwpath, rwaugm, 
 *                  rwstat appropriately.
 *         icrnew   start candidate list of labelled nodes
 *         maxfl1   find max flow by iterative labelling method.
 *          scancj  scan column jscan
 *          scanri  scan row iscan
 *          wbckcj  walk back from column node jscan.
 *          wbckri  walk back from row node iscan.
 *          cutlab  determine labelled and unlabelled nodes, 
 *                  and cutset
 *          rwback  backtrack on augmenting path from 
 *                  row node iscan.
 *          clback  backtrack on augmenting path from 
 *                  column node jscan
 *          resetl  reset labels following an augmentation.
 * 
 *     alternate calling sequence:
 *       if consistent paths and labels exist in 
 *       xxpath, xxaugm, xxstat, may solve max flow problem 
 *       as follows (this is same sequence
 *       as above, except that maxflw and intflw are omitted):
 *         maxfl1                 
 *           scancj               
 *           scanri               
 *           wbckcj               
 *           wbckri               
 *           cutlab               
 *           rwback               
 *           clback               
 *           resetl               
 * 
 *     caution:  solut1-solut5 and rhs1-rhs5 are modified 
 *               by use of arrays 
 *               clpath, claugm, clstat, clcutn, cllabn, and
 *               rwpath, rwaugm, rwstat, rwcutn, rwlabn.
 * 
 * **********************************************************
 * 
 * 
 * **********************************************************
 *  subroutine clback             
 * 
 *  purpose:  backtracks augmenting path when current node 
 *            is a column node that is not an unused source node.
 * 
 * **********************************************************
 * 
 */
void clback() {
/*
 */
  static long j;
/*
 */
  j=jscan;
  iscan=claugm_(j);
/*
 *  if j is not on an existing path, put it into new path
 */
  if (clpath_(j)==0) {
    clpath_(j)=claugm_(j);
    onpath=0;
    return;
  }
/*
 *  j is a node of an existing path.  check if previous node was
 *  already on this path.  
 *  if yes, j node is not kept in any path unless
 *  we are about to leave that path while backtracking.
 */
  if (onpath==1) {
    if ((clpath_(j)>0)&&
        (claugm_(j)>0)&&
        (clstat_(j)!=0)) {
/*
 *  we are leaving the path
 */
      clpath_(j)=iscan;
      onpath=0;
    } else {
/*
 *  we are staying on the path
 */
      clpath_(j)=0;
    }
/*
 *  the previous node is not on this path.  
 *  two cases possible:
 *  the complicated special case with two augmenting paths,
 *  or the case of simple entry into path while backtracking.
 */
  } else {
/*
 *  complicated special case.  must adjust iscan
 */
    if ((clpath_(j)>0)&&
        (claugm_(j)>0)&&
        (clstat_(j)>0)) {
      iscan=clstat_(j);
    }
    onpath=1;
  }
  return;
}
/*
 * **********************************************************
 *  subroutine cutlab             
 * 
 *  purpose:  determine labelled / source nodes and node cutset.
 *            cllabn(j), rwlabn(i) = 1 implies labelled or 
 *            source node, and =0 implies unlabelled and not 
 *            a source node.
 *            clcutn(j), rwcutn(i) = 1 implies cutset node, 
 *            and = 0 implies node not in cutset.
 * 
 *       ccut and rcut contain node cutset.
 * **********************************************************
 * 
 */
void cutlab() {
/*
 */
  static long n,j,i;
/*
 *  process column nodes
 */
  n=0;
  for(j=1; j<=ncols; j++)  {
    if (((clpath_(j)>=0)&&
        (claugm_(j)==0))||
        ((clpath_(j)>0)&&
        (claugm_(j)>0)&&
        (clstat_(j)<=-2))) {
      cllabn_(j)=0;
    } else {
      cllabn_(j)=1;
    }
    if (((clpath_(j)>0)&&
        (claugm_(j)>0)&&
        (clstat_(j)<=-2))||
        ((clpath_(j)==-1)&&
        (claugm_(j)==0)&&
        (clstat_(j)==-1))) {
      clcutn_(j)=1;
      n=n+1;
      ccut_(n)=j;
    } else {
      clcutn_(j)=0;
    }
  }
  ccut_(colmax+1)=n;
/*
 *  process row nodes
 */
  n=0;
  for(i=1; i<=nrows; i++)  {
    if (((rwpath_(i)>=0)&&
        (rwaugm_(i)==0))||
        ((rwpath_(i)>0)&&
        (rwaugm_(i)>0)&&
        (rwstat_(i)<=-2))) {
      rwlabn_(i)=0;
    } else {
      rwlabn_(i)=1;
    }
    if (((rwpath_(i)>0)&&
        (rwaugm_(i)>0)&&
        (rwstat_(i)<=-2))||
        ((rwpath_(i)==-1)&&
        (rwaugm_(i)==0)&&
        (rwstat_(i)==-1))) {
      rwcutn_(i)=1;
      n=n+1;
      rcut_(n)=i;
    } else {
      rwcutn_(i)=0;
    }
  }
  rcut_(rowmax+1)=n;
  return;
}
/*
 * **********************************************************
 *  subroutine icrnew             
 * 
 *  purpose:  start candidate lists of labelled and 
 *            unscanned nodes.
 * 
 * **********************************************************
 * 
 */
void icrnew() {
/*
 */
  static long n,jx,j,ix,i;
/*
 */
  n=0;
  if (csourc_(colmax+1)>0) {
    for(jx=1; jx<=csourc_(colmax+1); jx++)  {
      j=csourc_(jx);
      if (claugm_(j)==-1) {
        n=n+1;
        cnew_(n)=j;
      }
    }
  }
  cnew_(colmax+1)=n;
  n=0;
  if (rsourc_(rowmax+1)>0) {
    for(ix=1; ix<=rsourc_(rowmax+1); ix++)  {
      i=rsourc_(ix);
      if (rwaugm_(i)==-1) {
        n=n+1;
        rnew_(n)=i;
      }
    }
  }
  rnew_(rowmax+1)=n;
  return;
}
/*
 * **********************************************************
 *  subroutine intflw             
 * 
 *  purpose:  initialize flows and node labels.
 * 
 * **********************************************************
 * 
 */
void intflw() {
/*
 */
  static long i,j,jx,ix;
/*
 *  initialize index vectors
 */
  for(i=1; i<=nrows; i++)  {
    rwpath_(i)=0;
    rwaugm_(i)=0;
    rwstat_(i)=0;
  }
  for(j=1; j<=ncols; j++)  {
    clpath_(j)=0;
    claugm_(j)=0;
    clstat_(j)=0;
  }
/*
 *  programming error if no source or sink nodes
 */
  if (((csourc_(colmax+1)+rsourc_(rowmax+1))<=0)||
      ((csink_(colmax+1)+rsink_(rowmax+1))<=0)) {
    error("intflw  ","     102");
  }
/*
 *  record source nodes
 */
  if (csourc_(colmax+1)>0) {
    for(jx=1; jx<=csourc_(colmax+1); jx++)  {
      j=csourc_(jx);
      claugm_(j)=-1;
      clstat_(j)=-1;
    }
  }
  if (rsourc_(rowmax+1)>0) {
    for(ix=1; ix<=rsourc_(rowmax+1); ix++)  {
      i=rsourc_(ix);
      rwaugm_(i)=-1;
      rwstat_(i)=-1;
    }
  }
/*
 *  record sink nodes
 */
  if (csink_(colmax+1)>0) {
    for(jx=1; jx<=csink_(colmax+1); jx++)  {
      j=csink_(jx);
      clstat_(j)=-3;
    }
  }
  if (rsink_(rowmax+1)>0) {
    for(ix=1; ix<=rsink_(rowmax+1); ix++)  {
      i=rsink_(ix);
      rwstat_(i)=-3;
    }
  }
  return;
}
/*
 * **********************************************************
 *  subroutine maxflw             
 * 
 *  purpose:  computes max flow from 
 *            csourc, rsourc nodes to csink,
 *            rsink nodes for component qblock in layer 1.  
 *            assumes zero as vector of starting flows.
 * 
 *    input:  as specified in module summary.
 * 
 *   output:  max flow solution.  
 *            nodes in cutset have clcutn(j), rwcutn(i) = 1.
 *            nodes not in cutset have clcutn(j), rwcutn(j) = 0.
 *            cutset nodes are in ccut, rcut
 *            labelled nodes have cllabn(j), rwlabn(i) = 1.
 *            unlabelled nodes have cllabn(j), rwlabn(i) = 0.
 * **********************************************************
 * 
 */
void maxflw() {
/*
 */
  void icrnew();
  void intflw();
  void maxfl1();
/*
 *  initialize node labels
 */
  intflw();
/*
 *  start candidate list of labelled nodes
 */
  icrnew();
/*
 *  find max flow
 */
  maxfl1();
  return;
}
/*
 * **********************************************************
 *  subroutine maxfl1             
 * 
 *  purpose:  computes max flow from 
 *            csourc, rsourc nodes to csink, rsink nodes 
 *            for component qblock in layer 1.  assumes
 *            a given flow solution, and appropriate 
 *            clpath, claugm, clstat, rwpath, rwaugm, rwstat, 
 *            cnew, rnew
 * 
 *    input:  as specified in module summary, plus:
 *              clpath, claugm, clstat, 
 *              rwpath, rwaugm, rwstat, cnew,
 *              rnew corresponding to a valid labelling and flow
 *              assignment.       
 * 
 *   output:  max flow solution.  
 *            nodes in cutset have clcutn(j), rwcutn(i) = 1.
 *            nodes not in cutset have clcutn(j), rwcutn(i) = 0.
 *            cutset nodes are in ccut, rcut
 *            labelled nodes have cllabn(j), rwlabn(i) = 1.
 *            unlabelled nodes have cllabn(j), rwlabn(i) = 0.
 * 
 * **********************************************************
 * 
 */
void maxfl1() {
/*
 */
  void clback();
  void cutlab();
  void maxfl1();
  void resetl();
  void rwback();
  void scancj();
  void scanri();
/*
 */
  static long j,i;
/*
 */
  zz50:;
/*
 *  scan one labelled and unscanned column node.
 *  check if there is such a node.
 */
  if (cnew_(colmax+1)>0) {
/*
 *  identify the labelled column node and remove it from cnew
 */
    jscan=cnew_(1);
    cnew_(colmax+1)=cnew_(colmax+1)-1;
    for(j=1; j<=cnew_(colmax+1); j++)  {
      cnew_(j)=cnew_(j+1);
    }
/*
 *  if the unscanned column node jscan is an unused sink node, 
 *  start backtracking for augmentation
 */
    if ((clpath_(jscan)==0)&&
        (claugm_(jscan)>0)&&
        (clstat_(jscan)==-3)) {
      onpath=0;
      goto zz1500;
    }
/*
 *  column node jscan is not an unused sink node.  scan jscan
 */
    scancj();
    goto zz50;
  }
  zz150:;
/*
 *  scan one labelled and unscanned row node.
 *  check if there is such a node.
 */
  if (rnew_(rowmax+1)>0) {
/*
 *  identify the labelled row node and remove it from rnew
 */
    iscan=rnew_(1);
    rnew_(rowmax+1)=rnew_(rowmax+1)-1;
    for(i=1; i<=rnew_(rowmax+1); i++)  {
      rnew_(i)=rnew_(i+1);
    }
/*
 *  if the unscanned row node iscan is an unused sink node, 
 *  start backtracking for augmentation
 */
    if ((rwpath_(iscan)==0)&&
        (rwaugm_(iscan)>0)&&
        (rwstat_(iscan)==-3)) {
      onpath=0;
      goto zz500;
    }
/*
 *  row node iscan is not an unused sink node.  scan iscan
 */
    scanri();
    goto zz150;
  }
  if (cnew_(colmax+1)>0) {
    goto zz50;
  }
/*
 *  have no unscanned column or row nodes.  
 *  assemble optimal solution
 *  in clcutn, cllabn, rwcutn, rwlabn, ccut, rcut.
 */
  cutlab();
  return;
/*
 *  find augmenting path
 */
  zz500:;
/*
 *  if row node iscan is an unused source node, 
 *  stop backtracking;
 *  else backtrack
 */
  if ((rwpath_(iscan)==0)&&
      (rwstat_(iscan)==-1)) {
    rwpath_(iscan)=-1;
    goto zz600;
  } else {
    rwback();
  }
/*
 *  if column node jscan is an unused source node, 
 *  stop backtracking;
 *  else backtrack
 */
  zz1500:;
  if ((clpath_(jscan)==0)&&
      (clstat_(jscan)==-1)) {
    clpath_(jscan)=-1;
    goto zz600;
  } else {
    clback();
    goto zz500;
  }
/*
 *  backtracking is complete and new paths are now defined.  
 *  reset augmentation path labels
 */
  zz600:;
  resetl();
  goto zz50;
}
/*
 * **********************************************************
 *  subroutine resetl             
 * 
 *  purpose:  resets labels and indices after path augmentation.
 *            computes new set of scanning nodes.
 * 
 * **********************************************************
 * 
 */
void resetl() {
/*
 */
  static long n,j,i;
/*
 */
  n=0;
  for(j=1; j<=ncols; j++)  {
    if ((clpath_(j)==0)&&
        (clstat_(j)==-1)) {
      n=n+1;
      cnew_(n)=j;
    } else {
      claugm_(j)=0;
    }
    if ((clstat_(j)!=-1)&&
        (clstat_(j)!=-3)) {
      clstat_(j)=0;
    }
  }
  cnew_(colmax+1)=n;
  n=0;
  for(i=1; i<=nrows; i++)  {
    if ((rwpath_(i)==0)&&
        (rwstat_(i)==-1)) { 
      n=n+1;
      rnew_(n)=i;
    } else {
      rwaugm_(i)=0;
    }
    if ((rwstat_(i)!=-1)&&
        (rwstat_(i)!=-3)) {
      rwstat_(i)=0;
    }
  }
  rnew_(rowmax+1)=n;
  return;
}
/*
 * **********************************************************
 *  subroutine rwback             
 * 
 *  purpose:  backtracks augmenting path 
 *            when current node is a row
 *            node that is not an unused source node.
 * 
 * **********************************************************
 * 
 */
void rwback() {
/*
 */
  static long i;
/*
 */
  i=iscan;
  jscan=rwaugm_(i);
/*
 *  if i is not on an existing path, put it into new path
 */
  if (rwpath_(i)==0) {
    rwpath_(i)=rwaugm_(i);
    onpath=0;
    return;
  }
/*
 *  i is a node of an existing path.  
 *  check if previous node was already on this path.  
 *  if yes, i node is not kept in any path unless
 *  we are about to leave that path while backtracking.
 */
  if (onpath==1) {
    if ((rwpath_(i)>0)&&
        (rwaugm_(i)>0)&&
        (rwstat_(i)!=0)) {
/*
 *  we are leaving the path
 */
      rwpath_(i)=jscan;
      onpath=0;
    } else {
/*
 *  we are staying on the path
 */
      rwpath_(i)=0;
    }
/*
 *  the previous node is not on this path.  
 *  two cases possible:
 *  the complicated special case with two augmenting paths,
 *  or the case of simple entry into path while backtracking.
 */
  } else {
/*
 *  complicated special case.  must adjust jscan
 */
    if ((rwpath_(i)>0)&&
        (rwaugm_(i)>0)&&
        (rwstat_(i)>0)) {
      jscan=rwstat_(i);
    }
    onpath=1;
  }
  return;
}
/*
 * **********************************************************
 *  subroutine scancj             
 * 
 *  purpose:  scans column node jscan.
 * 
 * **********************************************************
 * 
 */
void scancj() {
/*
 */
  void sclall();
  void wbckcj();
  void wbckri();
/*
 */
  static long j,ix,i;
/*
 *  scan labelled column node jscan
 */
  j=jscan;
/*
 *  find the neighbors of column node j
 */
  sclall(j);
/*
 *  if column j is zero, done
 */
  if (clalli_(rowmax+1)==0) {
    return;
  }
/*
 *  process each neighboring row node of column node j
 */
  for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
    i=clalli_(ix);
/*
 *  skip i if it is labelled.
 */
    if (((rwaugm_(i)!=0)&&
        (rwstat_(i)>=-1))||
        ((rwpath_(i)==0)&&
        (rwaugm_(i)>0)&&
        (rwstat_(i)==-3))) {
      goto zz100;
    }
/*
 *  from now on i is known to be unlabelled.
 *  if row node i is unused, add to augmentation path 
 *  and to list of unscanned nodes.
 */
    if ((rwpath_(i)==0)&&
        (rwaugm_(i)==0)) {
      rwaugm_(i)=j;
      rnew_(rowmax+1)=rnew_(rowmax+1)+1;
      rnew_(rnew_(rowmax+1))=i;
      goto zz100;
    }
/*
 *  if i is a source node of an existing path, 
 *  or if i is the special
 *  case with one augmentation, skip it.
 */
    if ((rwpath_(i)==-1)||
        (rwaugm_(i)!=0)) {
      goto zz100;
    }
/*
 *  i is an intermediate or sink node of an existing path, 
 *  and is not an ancestor of j if j is on that path.  
 *  i becomes a special node with one augmentation.
 */
    rwaugm_(i)=j;
    if (rwstat_(i)==0) {
      rwstat_(i)=-2;
    }
/*
 *  walkback on the existing path and label nodes.
 */
    iscan=i;
    zz150:;
    wbckri();
    if (succss==0) {
      goto zz100;
    }
    wbckcj();
    if (succss==0) {
      goto zz100;
    }
    goto zz150;
  zz100:;}
  return;
}
/*
 * **********************************************************
 *  subroutine scanri             
 * 
 *  purpose:  scans row node iscan
 * 
 * **********************************************************
 * 
 */
void scanri() {
/*
 */
  void srwall();
  void wbckcj();
  void wbckri();
/*
 */
  static long i,jx,j;
/*
 *  scan labelled row node iscan
 */
  i=iscan;
/*
 *  find the neighbors of row node i
 */
  srwall(i);
/*
 *  if row i is zero, done
 */
  if (rwallj_(colmax+1)==0) {
    return;
  }
/*
 *  process each neighboring column node of row node i
 */
  for(jx=1; jx<=rwallj_(colmax+1); jx++)  {
    j=rwallj_(jx);
/*
 *  skip j if it is labelled.
 */
    if (((claugm_(j)!=0)&&
        (clstat_(j)>=-1))||
        ((clpath_(j)==0)&&
        (claugm_(j)>0)&&
        (clstat_(j)==-3))) {
      goto zz100;
    }
/*
 *  from now on j is known to be unlabelled.
 *  if column node j is unused, 
 *  add to augmentation path and to list
 *  of unscanned nodes.
 */
    if ((clpath_(j)==0)&&
        (claugm_(j)==0)) {
      claugm_(j)=i;
      cnew_(colmax+1)=cnew_(colmax+1)+1;
      cnew_(cnew_(colmax+1))=j;
      goto zz100;
    }
/*
 *  if j is a source node of an existing path, 
 *  or if j is the special
 *  case with one augmentation, skip it.
 */
    if ((clpath_(j)==-1)||
        (claugm_(j)!=0)) {
      goto zz100;
    }
/*
 *  j is an intermediate or sink node of an existing path, 
 *  and is not an ancestor of i if i is on that path.  
 *  j becomes a special node with one augmentation.
 */
    claugm_(j)=i;
    if (clstat_(j)==0) {
      clstat_(j)=-2;
    }
/*
 *  walkback on the existing path and labelled nodes.
 */
    jscan=j;
    zz150:;
    wbckcj();
    if (succss==0) {
      goto zz100;
    }
    wbckri();
    if (succss==0) {
      goto zz100;
    }
    goto zz150;
  zz100:;}
  return;
}
/*
 * *******************************************************
 *  subroutine wbckcj                   
 *       
 *  purpose:  walks back one step from node jscan 
 *            along an existing path.
 *       
 *   output:  iscan = next node reached.
 *            succss = 1:  further walk back must be done.
 *                   = 0:  no further walk back possible.
 *       
 * *******************************************************
 * 
 */
void wbckcj() {
/*
 */
  static long j,i;
/*
 */
  j=jscan;
  iscan=clpath_(j);
  i=iscan;
/*
 *  record node i as labelled and unscanned
 */
  rnew_(rowmax+1)=rnew_(rowmax+1)+1;
  rnew_(rnew_(rowmax+1))=i;
/*
 *  assign augmentation path label to i
 * 
 *  case 1:  i is a special node with one augmentation.  
 *           then i becomes a special node with two 
 *           augmentations.
 */
  if (rwstat_(i)==-2) {
    rwstat_(i)=j;
    succss=0;
    return;
  }
/*
 *  case 2:  i is the source node of the existing path
 */
  if (rwstat_(i)==-1) {
    rwaugm_(i)=j;
    succss=0;
    return;
  }
/*
 *  case 3:  i is an intermediate path node, 
 *           and is not a special node
 */
  rwaugm_(i)=j;
  succss=1;
  return;
}
/*
 * *******************************************************
 *  subroutine wbckri                   
 *       
 *  purpose:  walks back one step from node iscan along 
 *            an existing path.
 *       
 *   output:  jscan = next node reached.
 *            succss = 1:  further walk back must be done.
 *                   = 0:  no further walk back possible.
 *       
 * *******************************************************
 * 
 */
void wbckri() {
/*
 */
  static long j,i;
/*
 */
  i=iscan;
  jscan=rwpath_(i);
  j=jscan;
/*
 *  record node j as labelled and unscanned
 */
  cnew_(colmax+1)=cnew_(colmax+1)+1;
  cnew_(cnew_(colmax+1))=j;
/*
 *  assign augmentation path label to j
 * 
 *  case 1:  j is a special node with one augmentation.  
 *           then j becomes a special node with two 
 *           augmentations.
 */
  if (clstat_(j)==-2) {
    clstat_(j)=i;
    succss=0;
    return;
  }
/*
 *  case 2:  j is the source node of the existing path
 */
  if (clstat_(j)==-1) {
    claugm_(j)=i;
    succss=0;
    return;
  }
/*
 *  case 3:  j is an intermediate path node, 
 *           and is not a special node
 */
  claugm_(j)=i;
  succss=1;
  return;
}
/*  last record of maxflow.c****** */
