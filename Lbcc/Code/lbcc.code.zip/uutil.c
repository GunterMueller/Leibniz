/*  first record of uutil.c***** */
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*
 * *******************************************************
 *  module universal utility routines
 * 
 *  contains:
 *    error    error handling routine
 *    vrsion   defines version number
 *
 * *******************************************************
 *
 * ********************************************************
 *  subroutine error
 * 
 *  purpose:  print an error message on the screen
 *            to errfil
 * 
 *  input:    errfil 
 * 
 *  output:   text of the error message as specified by the
 *            input parameters.
 *  ==============
 *  update history
 *  ==============
 *  date      where                what was changed/reason
 * --------------------------------------------------------
 * 
 * *********************************************************
 * 
 */
void error(char *m1,char *m2) {
/*
 */
  printf("\n*******LEIBNIZ SYSTEM ERROR******\n");
  printf("ERROR IN %s  code %s\n",m1,m2);
  printf("**********************************\n");
/*
 */
  fprintf(errfil,"\n*******LEIBNIZ SYSTEM ERROR******\n");
  fprintf(errfil,"ERROR IN %s  code %s\n",m1,m2);
  fprintf(errfil,"**********************************\n");
  lbccexit(1);

}

/*
 * *******************************************************
 *  subroutine lbccexit
 * 
 *  purpose:  deallocates translation and execution
 *            memory as needed and exits with specified
 *            parameter
 *  
 * *******************************************************
 * 
 */
void lbccexit(int k) {

  void exdyn_free();
  void trdyn_free();
/*
 * deallocate execution and translation memory
 */
  if (exalcflg == 1) {
    exdyn_free();
  }
  if (tralcflg == 1) {
    trdyn_free();
  }
/*
 * exit with parameter k
 */
  exit(k);

}

/*
 * *******************************************************
 *  subroutine vrsion
 * 
 *  purpose:  defines leibniz system version number
 * 
 *  output:   lbzver
 * 
 * *******************************************************
 * 
 */
void vrsion() {

  char globalversion[5];
/*
 *  define leibniz system version number in lbzver
 *  using exactly 4 characters, nonblanks left justified
 */
#include "../../GlobalVersion/globalversion.h"
  strcpy(lbzver,globalversion);
  return;

}

/*  last record of uutil.c ****** */
