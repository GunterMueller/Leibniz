/*  first record of comp.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();
/*
 * **********************************************************
 *  module component 
 *   
 *  purpose:  finds solution algorithm, or finds a decomposition
 *            for block qblock, or composes two components.
 *
 *            call fndalg for solution algorithm.
 *            call fnddec for decomposition.
 *            call compos for composition.
 *  
 *    input:  problem in layer 1, with correct indices and 
 *            counts.  may have any number of blocks. ('*' means 
 *            condition is tested in fndalg and fnddec).
 *             arrays assumed defined:
 *              - matrix data amatcl, amatrw
 *              - nrows, ncols, nblks
 *              - colnam, rownam
 *              - matrix indices as follows:
 *        *         all columns j active (ciact(j) = 1)
 *        *         all rows i active (riact(i) = 1)
 *                  remaining indices must be consistent with 
 *                  these assignments. 
 *              - counts cnxxx, rnxxx 
 *        *     - all cost(j) must be .ge. 0 if optimz = 1
 *              - scale, idxcol, idxrow 
 *              - dlclop, dlrwop
 *              - lcllim, ucllim, lrwlim, urwlim
 *              - logrge
 *              - optimz
 *              - qblock 
 *              - flgopt = 0: find algorithm by heuristics
 *                       = 1: find optimal algorithm
 *
 *         additional input requirements as well as the output 
 *         are given with each subroutine of this module.
 *
 *    calling sequences:
 *      1.  fndalg        finds solution algorithm for block 
 *                        q = qblock.
 *            if flgopt = 0:
 *            heualg      module component algorithm, uses 
 *                        heuristic selection algorithm
 *            if flgopt = 1: 
 *            optalg      module component algorithm, uses 
 *                        optimal selection algorithm
 *   
 *      2.  fnddec        finds a decomposition of block 
 *                        q = qblock.
 *            decomp      module component decomposition.
 *            reshuf      reshuffle column and rows so that 
 *                        in the refined decomposition the 
 *                        indices of each block are contiguous.
 *    
 *      3.  compos        module component composition.
 *   
 *   caution:  uses layer 2, 3, and 4 for intermediate storage.
 * *************************************************************
 * 
 * 
 * *************************************************************
 *  subroutine fndalg
 * 
 *  purpose:  finds solution algorithm for block qblock of 
 *            problem in layer 1.
 *
 *    input:  as specified in module summary.
 * 
 *   output:  solution algorithm specified for each strip 
 *            q = qblock via twosat:
 *              twosat(q) = 0:  some columns have been moved 
 *                from freeto fixed, and some free columns 
 *                have been scaled. submatrix of free columns 
 *                is nearly negative.
 *              twosat(q) = 1:  some columns have been moved 
 *                from free to fixed.  submatrix of free columns 
 *                has 2sat form. this case requires optimz = 0. 
 *              bdfxbl(q) = number of fixed variables in 
 *                strip q.
 **
 *     caution:  uses layers 2, 3, 4 for intermediate storage.
 *
 * ************************************************************
 * 
 */
void fndalg() {
/*
 */
  void heualg();
  void mcfrfx();
  void mcfxfr();
  void optalg();
  void scalcl();
  void trancl();
  void tranpr();
  void xstrip();
/*
 */
  static long i,j,q;
/*
 */
  q=qblock;
/*
 *  verify that all columns are active
 */
  for(j=1; j<=ncols; j++)  {
    if (ciact_(j)!=1) {
      error(" fndalg ","     52 ");
    }
  }
/*
 *  verify that all rows are active
 */
  for(i=1; i<=nrows; i++)  {
    if (riact_(i)!=1) {
      error(" fndalg ","     62 ");
    }
  }
/*
 *  verify that all costs are nonnegative if optimz = 1
 */
  if (optimz==1) {
    for(j=1; j<=ncols; j++)  {
      if (cost_(j)<0) {
        error(" fndalg ","     72 ");
      }
    }
  }
/*
 *  save problem in layer 4
 */
  tranpr(c1,c4);
/*
 *  extract strip q from problem in layer 1 and retain in layer 1.
 */
  xstrip(q);
/*
 *  process strip q
 *  decide on solution via nearly negative or 2sat form
 */
  lcllmt=lcllim_(q);
  ucllmt=ucllim_(q);
  lrwlmt=lrwlim_(q);
  urwlmt=urwlim_(q);
  if (flgopt==0) {
/*
 *  heuristic selection methods are to be used
 */
    heualg();
  } else {
/*
 *  optimal selection methods are to be used
 *  check if a solution algorithm is already on hand. if not, 
 *  use heualg to obtain one
 */
    if (twosat_(q)<0) {
      heualg();
    }
    optalg();
  }
/*
 *  transfer cl of strip q with solution information 
 *  from layer 1 to layer 2
 */
  trancl(c1,c2);
/*
 *  transfer original (thus entire) problem 
 *  from layer 4 to layer 1
 */
  tranpr(c4,c1);
/*
 *  assign scale values and cixxx values of 
 *  strip q in layer 2 to the original problem, 
 *  which now is in layer 1.
 */
  for(j=lcllmt; j<=ucllmt; j++)  {
/*
 *  check if column j of strip q has been scaled.  
 *  if yes, scale column j of layer 1 problem.
 */
    if (scale_(j)!=cl_(j,19,2)) {
/*
 *  scaling error if optimization and cost(j) .ne. 0
 */
      if ((optimz==1)&&
          (cost_(j)!=0)) {
        error(" fndalg ","     302");
      } else {
        scalcl(j);
      }
    }
/*
 *  check if column j of strip q has changed 
 *  fixed\free status. if yes, update column j of 
 *  layer 1 problem accordingly
 */
    if ((cl_(j,13,2)!=0)&&
        (cifre_(j)==1)) {
      mcfrfx(j);
    } else {
      if ((cl_(j,12,2)==1)&&
          (cifix_(j)!=0)) {
        mcfxfr(j);
      }
    }
  }
  return;
}
/*
 * ************************************************************
 *  subroutine fnddec
 * 
 *  purpose:  finds a decomposition of block qblock of problem 
 *            in layer 1 if this is possible.
 *     
 *    input:  as specified in module summary.
 * 
 *   output:  problem in layer 1 with old (succss = 0) 
 *            or new (succss =1) decomposition.
 *            all input arrays have been adjusted to reflect 
 *            the change of decomposition. 
 *   
 *    caution:  uses layers 2 and 3 for intermediate storage.
 * 
 * ************************************************************* 
 * 
 */
void fnddec() {
/*
 */
  void decomp();
  void reshuf();
  void tranpr();
  void xcomp();
/*
 */
  static long j,i,q,q1,qp1;
/*
 *  verify that all columns are active
 */
  for(j=1; j<=ncols; j++)  {
    if (ciact_(j)==0) {
      error(" fnddec ","   12   ");
    }
  }
/*
 *  verify that all rows are active
 */
  for(i=1; i<=nrows; i++)  {
    if (riact_(i)!=1) {
      error(" fnddec ","   22   ");
    }
  }
/*
 *  verify that all cost(j) are .ge. 0 if optimz = 1
 */
  if (optimz==1) {
    for(j=1; j<=ncols; j++)  {
      if (cost_(j)<0) {
        error(" fnddec ","   32   ");
      }
    }
  }
/*
 *  verify that an additional block can be accommodated.
 */
  if (nblks==blkmax) {
    error(" fnddec ","   42   ");
  }
  q=qblock;
/*
 *  attempt to refine block q
 *  transfer input problem from layer 1 to layer 3 to save it
 */
  tranpr(c1,c3);
/*
 *  extract component q from layer 1 problem and retain 
 *  in layer 1.
 */
  xcomp(q);
/*
 *  decompose component q
 */
  decomp();
/*
 *  if no decomposition found, transfer current problem 
 *  from layer 3 to layer 1.
 */
  if (succss==0) {
    tranpr(c3,c1);
    return;
  }
/*
 * -----------------------------------------------------------
 *  have a good decomposition of block q in layer 2.  
 *  assign it to input problem
 * -----------------------------------------------------------
 * 
 *  transfer input problem to layer 1.
 */
  tranpr(c3,c1);
  qp1=q+1;
/*
 *  shift twosat, bdfxbl, logrge, and block indicators
 */
  if (q<nblks) {
    for(q1=nblks; q1>=qp1; q1--)  {
      twosat_(q1+1)=twosat_(q1);
      bdfxbl_(q1+1)=bdfxbl_(q1);
      logrge_(q1+1)=logrge_(q1);
    }
    for(j=lcllim_(qp1); j<=ncols; j++)  {
      ciblk_(j)=ciblk_(j)+1;
    }
    for(i=lrwlim_(qp1); i<=nrows; i++)  {
      riblk_(i)=riblk_(i)+1;
    }
  }
/*
 *  shift logrge(q) to logrge(q+1) and retain bstcut 
 *  (= cutsize) in logrge(q)
 */
  logrge_(qp1)=logrge_(q);
  logrge_(q)=bstcut;
/*
 *  indicate that solution algorithm is now 
 *  unspecified for q and q+1
 */
  twosat_(q)=-1;
  twosat_(qp1)=-1;
  bdfxbl_(q)=0;
  bdfxbl_(qp1)=0;
/*
 *  increment nblks
 */
  nblks=nblks+1;
/*
 *  deduce new block q+1 from unlabelled nodes in layer 2
 */
  for(j=lcllim_(q); j<=ucllim_(q); j++)  {
    if (cl_(j,18,2)==0) {
      ciblk_(j)=qp1;
    }
  }
  for(i=lrwlim_(q); i<=urwlim_(q); i++)  {
    if (rw_(i,22,2)==0) {
      riblk_(i)=qp1;
    }
  }
/*
 *  reshuffle columns and rows so that each block has 
 *  contiguous indices.
 */
  reshuf();
  return;
}
/*
 * ********************************************************
 *  subroutine reshuf
 * 
 *  purpose:  reshuffles columns and rows of problem
 *            in layer 1 such  that each block has contiguous
 *            indices.
 * 
 *    input:  problem in layer 1 with defined block indices.
 * 
 *   output:  reshuffled problem in layer 1 such that each 
 *            block has contiguous indices.  
 *            lcllim, ucllim, lrwlim, urwlim are updated
 *            even if nblks = 1
 * 
 *  caution:  uses layers 2 and 3 for intermediate storage.
 * 
 * *******************************************************
 * 
 */
void reshuf() {
/*
 */
  void tranpr();
/*
 */
  static long q1,j,i,l,ix,is,jx,js,m;
/*
 *  if nblks = 1, no reshuffling is needed
 *                assign correct value to lcllim,ucllim,
 *                lrwlim,urwlim
 */
  if (nblks==1) {
    lcllim_(1)=1;
    lrwlim_(1)=1;
    ucllim_(1)=ncols;
    urwlim_(1)=nrows;
    return;
  }
/*
 *  save input problem in layer 2
 */
  tranpr(c1,c2);
/*
 *  compute number of indices for each block, and place
 *  into solut4 and rhs4
 */
  for(q1=1; q1<=nblks; q1++)  {
    solut4_(q1)=0;
    rhs4_(q1)=0;
  }
  for(j=1; j<=ncols; j++)  {
    q1=ciblk_(j);
    solut4_(q1)=solut4_(q1)+1;
  }
  for(i=1; i<=nrows; i++)  {
    q1=riblk_(i);
    rhs4_(q1)=rhs4_(q1)+1;
  }
/*
 *  calculate starting index for each block
 *  initialize upper limits
 */
  lcllim_(1)=1;
  lrwlim_(1)=1;
  ucllim_(1)=lcllim_(1)-1;
  urwlim_(1)=lrwlim_(1)-1;
  for(q1=2; q1<=nblks; q1++)  {
    lcllim_(q1)=lcllim_(q1-1)+solut4_(q1-1);
    lrwlim_(q1)=lrwlim_(q1-1)+rhs4_(q1-1);
    ucllim_(q1)=lcllim_(q1)-1;
    urwlim_(q1)=lrwlim_(q1)-1;
  }
/*
 *  compute the new position of input column j,
 *  and put into solut5(j)
 */
  for(j=1; j<=ncols; j++)  {
    q1=ciblk_(j);
    ucllim_(q1)=ucllim_(q1)+1;
    solut5_(j)=ucllim_(q1);
  }
/*
 *  compute the new position of input row i,
 *  and put into rhs5_(i)
 */
  for(i=1; i<=nrows; i++)  {
    q1=riblk_(i);
    urwlim_(q1)=urwlim_(q1)+1;
    rhs5_(i)=urwlim_(q1);
  }
/*
 *  update layer 3 problem using layer 2 as input
 *  column j is moved to position solut5_(j)
 */
  for(j=1; j<=ncols; j++)  {
    m=solut5_(j);
    for(l=1; l<=lclmax; l++)  {
      cl_(m,l,3)=cl_(j,l,2);
    }
/*
 *  shift pointer
 */
    ptamc_(m,3)=ptamc_(j,2);
/*
 *  shift total
 */
    nzamc_(m,3)=nzamc_(j,2);
    if (nzamc_(j,2)>0) {
      for(ix=1; ix<=nzamc_(j,2); ix++)  {
        is=amc_(ix+ptamc_(j,2),2);
        i=abs(is);
        if (is>0) {
          amc_(ix+ptamc_(m,3),3)=rhs5_(i);
        } else {
          amc_(ix+ptamc_(m,3),3)=-rhs5_(i);
        }
      }
    }
  }
/*
 *  new idxcol_(j) = solut5_(old(idxcol_(j))
 */
  for(j=1; j<=ncols; j++)  {
    cl_(j,20,3)=solut5_(cl_(j,20,2));
  }
/*
 *  row i is moved to position rhs5_(i)
 */
  for(i=1; i<=nrows; i++)  {
    m = rhs5_(i);
    for(l=1; l<=lrwmax; l++)  {
      rw_(m,l,3)=rw_(i,l,2);
    }
/*
 *  shift pointer
 */
    ptamr_(m,3)=ptamr_(i,2);
/*
 *  shift total
 */
    nzamr_(m,3)=nzamr_(i,2);
    if (nzamr_(i,2)>0) {
      for(jx=1; jx<=nzamr_(i,2); jx++)  {
        js=amr_(jx+ptamr_(i,2),2);
        j=abs(js);
        if (js>0) {
          amr_(jx+ptamr_(m,3),3)=solut5_(j);
        } else {
          amr_(jx+ptamr_(m,3),3)=-solut5_(j);
        }
      }
    }
  }
/*
 *  new idxrow(i)  = rhs5(old idxrow(i))
 */
  for(i=1; i<=nrows; i++)  {
    rw_(i,23,3)=rhs5_(rw_(i,23,2));
  }
/*
 *  transfer reshuffled problem in layer 3 to layer 1
 */
  tranpr(c3,c1);
  return;
}
/*  last record of comp.c****** */
