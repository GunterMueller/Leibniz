/*  first record of compalg.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();
/*
 * *****************************************************************
 *  module component algorithm
 * 
 *  purpose:  selects appropriate satisfiability algorithm for
 *            component qblock (part or all), assumed to reside
 *            in layer 1.
 * 
 *    input:  part or all of component qblock in layer 1,
 *            with correct indices and counts.
 * 
 *            arrays assumed defined:
 *              - matrix data amatcl, amatrw
 *              - nrows, ncols, nblks
 *              - colnam, rownam, prbnam
 *              - indices cixxx, rixxx
 *              - counts cnxxx, rnxxx
 *              - all cost(j) must be .ge. 0 if optimz = 1
 *              - scale, idxcol, idxrow
 *              - dlclop, dlrwop
 *              - lcllmt, ucllmt, lrwlmt, urwlmt
 *              - qblock
 *              - optimz
 * 
 *     additional input requirements as well as the output are given
 *     with each subroutine of this module.
 * 
 *  calling sequences:
 *  1.heualg      select satisfiability algorithm for input problem
 *                by heuristics
 *      makneg    attempt to convert to nearly negative.
 *      heuneg    find a large nearly negative subproblem by
 *                heuristics
 *        devrd1    compute deviation reduction after column scaling.
 *        devrd2    compute deviation reduction after column fixing.
 *        crnfp1    update rnfrep after column scaling.
 *        crnfp2    update rnfrep after column fixing.
 *      heu2st    find a large 2sat subproblem by heuristics
 *                (called only if optimz = 0)
 * 
 *  2.optalg      select satisfiability algorithm for input problem
 *                by optimal selection methods
 *      makneg, heuneg, heu2st as described above
 *      optneg    find maximum nearly negative subproblem
 *        lpexec  module lp execution
 *      opt2st    find maximum 2sat subproblem
 *        lpexec  module lp execution
 * 
 *  caution:  use of optalg is restricted so that solution of too
 *            large lps is not attempted. the restrictions are
 *            defined prior to the 'BEG XMP' calls in optneg and
 *            opt2st.
 * 
 *  caution:  uses layers 2 and 3 for intermediate storage.  input
 *            problem may be larger than strip qblock (e.g., under
 *            closed boolean decomposition).
 * 
 * *****************************************************************
 * 
 * 
 * *****************************************************************
 * subroutine heualg
 * 
 * purpose:  selects solution algorithm for block qblock
 *           heuristically
 * 
 *   input:  as specified in module summary.
 * 
 *  output:  twosat(qblock), which determines solution
 *           algorithm for strip qblock.
 * 
 *           twosat(qblock) = 0:  some columns have been moved
 *                                from free to fixed, and some free
 *                                columns have been scaled so
 *                                that the submatrix of free columns
 *                                is nearly negative.
 * 
 *           twosat(qblock) = 1:  some columns have been moved
 *                                from free to fixed so that the
 *                                submatrix of free columns has
 *                                2sat format.
 *                                this case is not possible when
 *                                optimz = 1.
 * 
 *           bdfxbl(q) = number of fixed columns for block q.
 * 
 *    caution:  uses layers 2 and 3 for intermediate storage.
 * 
 * *****************************************************************
 * 
 */
void heualg() {
/*
 */
  void heuneg();
  void heu2st();
  void makneg();
  void mcfxfr();
  void tranpr();
/*
 */
  static long q,j;
/*
 */
  q=qblock;
/*
 *  shift all fixed columns to free
 */
  for(j=1; j<=ncols; j++)  {
    if (cifix_(j)!=0) {
      mcfxfr(j);
    }
  }
/*
 *  try to scale to get nearly negative case.
 *  succss = 1 implies successful; succss = 0 implies failure.
 */
  if (accflg == 1) {
    printf("heualg 0\n");
  }
  makneg();
  twosat_(q)=0;
/*
 *  initialize bound for the number of fixed variables
 */
  bdfxbl_(q)=0;
/*
 *  if nearly negative case has not been achieved, use heuristics
 *  to get a large nearly negative or 2sat subsection.  update bound
 *  for the number of fixed variables.
 */
  if (succss==0) {
/*
 *  search for large nearly negative submatrix
 */
    if (accflg == 1) {
      printf("heualg 1\n");
    }
    heuneg();
/*
 *  heuneg has placed output problem into layer 1
 *  and has transferred input problem into layer 3
 */
    bdfxbl_(q)=bdfxvr;
/*
 *  if optimz = 1, stop
 */
    if (optimz==1) {
      return;
    }
/*
 *  problem does not involve optimization
 *  save heuneg solution in layer 2
 */
    tranpr(c1,c2);
/*
 *  restore heuneg input problem from layer 3
 */
    tranpr(c3,c1);
/*
 *  search for large 2sat submatrix.
 */
    if (accflg == 1) {
      printf("heualg 2\n");
    }
/*
 *  set early termination flag
 */
    flgtrm=1;
    heu2st();
/*
 *  decide which of the two cases (nearly negative versus 2sat) yields
 *  fewer fixed variables.  accept best solution.
 * 
 *  rule below for selection of 2st assures that
 *  2sat case is possible in enufxz and enufx1,
 *  but cannot occur in enufix2. for details, see
 *  selection of procedures in enufix
 */
    if ((bdfxvr<=aggmax)&&
        (bdfxvr<bdfxbl_(q))) {
/*
 *  2sat approach is better
 */
      bdfxbl_(q)=bdfxvr;
      twosat_(q)=1;
    } else {
/*
 *  nearly negative submatrix approach is better
 */
      tranpr(c2,c1);
    }
  }
  return;
}
/*
 * *************************************************************************
 *  subroutine heuneg                                                      *
 *                                                                         *
 *  purpose:  scales the columns to create a large nearly negative         *
 *            column submatrix.                                            *
 *            scaling of column j is not permitted if optimz = 1 and       *
 *            cost(j) .ne. 0.  problem is known to be not convertible      *
 *            to nearly negative by scaling.                               *
 *                                                                         *
 *  input:    problem in layer 1, with all columns free                    *
 *                                                                         *
 *  output:   some columns have been shifted from free to fixed,           *
 *            and some free columns have been scaled, so that in           *
 *            the new matrix the submatrix of free columns and active rows *
 *            is nearly negative.                                          *
 *            original input problem in layer 3.                           *
 *                                                                         *
 *            bdfxvr = number of fixed columns in output problem,          *
 *                     which is in layer 1                                 *
 *                                                                         *
 *                                                                         *
 *  caution:  uses layers 2 and 3 for intermediate storage.                *
 *                                                                         *
 *  ==============                                                         *
 *  update history                                                         *
 *  ==============                                                         *
 *  date      where             what was changed/reason                    *
 * ------------------------------------------------------------------------*
 *                                                                         *
 * *************************************************************************
 * 
 */
void heuneg() {
/*
 */
  void crnfp1();
  void crnfp2();
  void devrd1();
  void devrd2();
  void mcfrfx();
  void mcfxfr();
  void scalcl();
  void tranpr();
/*
 */
  static long dev1,i,ix,improv,j,jx,jmin,n,min,ttdev;
/*
 *  -----------------------------------------------------------------
 *  step 1
 *  copy problem of layer 1 into layer 3 to save it
 *  ----------------------------------------------------------------
 */
  tranpr(c1,c3);
/*
 *  programming error if not all columns free
 */
  for(j=1; j<=ncols; j++)  {
    if (cifix_(j)!=0) {
      error(" heuneg ","     102");
    }
  }
/*
 *  -----------------------------------------------------------------
 *  step 2
 *  initialize scale factors in solut1 vector and set solut2(j) to 0.
 *  -----------------------------------------------------------------
 */
  for(j=1; j<=ncols; j++)  {
/*
 *  initialize solut1 - solut4
 *  solut1 = scale factors
 *  solut2 = temporary list for enumeration
 *  solut3 = list of variables that may be scaled
 *  solut4 = list of variables that may be fixed
 */
    solut1_(j)=1;
    solut2_(j)=0;
    solut3_(j)=1;
    solut4_(j)=1;
/*
 *  if column j is zero, no scaling or fixing
 */
    if (cnall_(j)==0) {
      solut3_(j)=0;
      solut4_(j)=0;
    } else {
/*
 *  column j is nonzero
 *  if optimization case with nonzero cost, then no scaling
 *  if in addition no positive entries, then no fixing
 */
      if ((optimz!=0)&&
          (cost_(j)!=0)) {
        solut3_(j)=0;
        if (cnallp_(j)==0) {
          solut4_(j)=0;
        }
      } else {
/*
 *  column j is nonzero;  if optimization, then cost is known to be zero
 *  if no positive entries, no scaling and no fixing
 */
        if (cnallp_(j)==0) {
          solut3_(j)=0;
          solut4_(j)=0;
        } else {
/*
 *  if no negative entries, scale column j and adjust rnfrep(j).
 *  then no further scaling and no fixing.
 */
          if (cnalln_(j)==0) {
            jscan=j;
            solut1_(j)=-1;
            crnfp1();
            solut3_(j)=0;
            solut4_(j)=0;
          }
        }
      }
    }
  }
  zz290:;
  improv=0;
/*
 *  -----------------------------------------------------------------
 *  step 3
 *  try scaling one column at a time.
 *  -----------------------------------------------------------------
 */
  for(n=1; n<=ncols; n++)  {
/*
 *  do not scale column n if solut3(n) = 0
 */
    if (solut3_(n)==0) {
      goto zz300;
    }
/*
 *  scale column n and compute effect
 */
    solut1_(n)=-solut1_(n);
    jscan=n;
    devrd1();
    if (devdif<0) {
/*
 *  scaling has helped; keep it; update rnfrep
 */
      improv=1;
      crnfp1();
    } else {
/*
 *  scaling has not helped;  undo it
 */
      solut1_(n)=-solut1_(n);
    }
  zz300:;}
/*
 *  try again if improvement was found.
 */
  if (improv==1) {
    goto zz290;
  }
/*
 *  -----------------------------------------------------------------
 *  step 4
 *  know that scaling just one column does not help.  try scaling of two
 *  columns at a time.
 *  -----------------------------------------------------------------
 */
  for(n=1; n<=ncols-1; n++)  {
/*
 *  do not scale column n if solut3_(n) = 0
 */
    if (solut3_(n)==0) {
      goto zz400;
    }
/*
 *  scale column n and compute effect
 */
    solut1_(n)=-solut1_(n);
    jscan=n;
    devrd1();
/*
 *  save deviation change
 */
    dev1=devdif;
/*
 *  update rnfrep
 */
    crnfp1();
/*
 *  try scaling of other columns j > n that are potential candidates
 *  for improvement.  first set up candidate list in solut2 vector.
 */
    for(ix=1; ix<=nzamac_(n); ix++)  {
      i=abs(amatcl_(ix+ptamac_(n)));
/*
 *  scan row i and record nonzero positions in solut2 vector.
 */
      for(jx=1; jx<=nzamar_(i); jx++)  {
        j=abs(amatrw_(jx+ptamar_(i)));
/*
 *  discard column j if j .le. n or solut3(j) = 0
 */
        if ((j<=n)||
            (solut3_(j)==0)) {
          goto zz420;
        }
        solut2_(j)=1;
      zz420:;}
    }
/*
 *  process the candidate columns j of solut2
 */
    for(j=n+1; j<=ncols; j++)  {
/*
 *  skip j if it is not a candidate
 */
      if (solut2_(j)==0) {
        goto zz450;
      }
/*
 *  reset solut2(j) to zero
 */
      solut2_(j)=0;
/*
 *  scale column j and compute deviation change
 */
      solut1_(j)=-solut1_(j);
      jscan=j;
      devrd1();
/*
 *  if improvement, keep the scaling, and start all over, else undo
 *  scaling.
 */
      if ((dev1+devdif)<0) {
        crnfp1();
        goto zz290;
      } else {
        solut1_(j)=-solut1_(j);
      }
    zz450:;}
/*
 *  undo scaling of column n and rnfrep change
 */
    solut1_(n)=-solut1_(n);
    jscan=n;
    crnfp1();
  zz400:;}
/*
 *  ------------------------------------------------------------------------
 *  step 5
 *  have now smallest deviation from nearly negative achievable by above
 *  heuristic.  now fix columns to get nearly negative submatrix.
 *  ---------------------------------------------------------------
 *  compute total deviation from nearly negative condition
 */
  bdfxvr=0;
  ttdev=0;
  for(i=1; i<=nrows; i++)  {
    if (rnfrep_(i)>=2) {
      ttdev=ttdev+rnfrep_(i);
    }
  }
  zz550:;
/*
 *  tentatively view each free column to be fixed and compute progress
 *  towards nearly negative
 */
  min=0;
  jmin=0;
  for(j=1; j<=ncols; j++)  {
/*
 *  skip column j if fixed or not allowed to be fixed.
 */
    if ((cifix_(j)!=0)||
        (solut4_(j)==0)) {
      goto zz520;
    }
/*
 *  compute deviation reduction if j were fixed
 */
    jscan=j;
    devrd2();
/*
 *  update min and jmin if better case
 */
    if (devdif<min) {
      min=devdif;
      jmin=j;
    }
  zz520:;}
/*
 *  implement jmin case
 */
  if (jmin==0) {
    error(" heuneg "," 522    ");
  }
  cifix_(jmin)=1;
  bdfxvr=bdfxvr+1;
  ttdev=ttdev+min;
  jscan=jmin;
  crnfp2();
/*
 *  more fixing needed if total deviation is still positive
 */
  if (ttdev>0) {
    goto zz550;
  }
/*
 *  ----------------------------------------------------------------
 *  step 6
 *  have fixed enough columns to get nearly negative.  save scaling and
 *  fixing information in layer 2.  then restore input problem of layer 3
 *  to layer 1 and update via layer 2.
 *  ----------------------------------------------------------------
 */
  for(j=1; j<=ncols; j++)  {
    cl_(j,13,2)=cifix_(j);
    cl_(j,14,2)=solut1_(j);
  }
/*
 *  transfer input problem from layer 3 to layer 1
 */
  tranpr(c3,c1);
/*
 *  scale and fix columns using layer 2 information
 */
  for(j=1; j<=ncols; j++)  {
    if ((cifix_(j)!=0)&&
        (cl_(j,13,2)==0)) {
      mcfxfr(j);
    }
    if ((cifix_(j)==0)&&
        (cl_(j,13,2)!=0)) {
      mcfrfx(j);
    }
    if ((cl_(j,13,2)==0)&&
        (cl_(j,14,2)<0)) {
      scalcl(j);
    }
  }
  return;
}
/*
 * *************************************************************************
 *  subroutine crnfp1                                                      *
 *                                                                         *
 *  purpose:  changes rnfrep by assuming that sign of solut1(jscan) was    *
 *            changed to present value.                                    *
 * *************************************************************************
 * 
 */
void crnfp1() {
/*
 */
  static long i,is,ix,j;
/*
 */
  j=jscan;
  for(ix=1; ix<=nzamac_(j); ix++)  {
    is=amatcl_(ix+ptamac_(j));
    i=abs(is);
    if ((is*solut1_(j))>0) {
/*
 *  scaled column entry in row i is now a + 1, and was a -1
 */
      rnfrep_(i)=rnfrep_(i)+1;
    } else {
/*
 *  scaled column entry in row i is now a -1, and was a + 1
 */
      rnfrep_(i)=rnfrep_(i)-1;
    }
  }
  return;
}
/*
 * *************************************************************************
 *  subroutine crnfp2                                                      *
 *                                                                         *
 *  purpose:  changes rnfrep by assuming that column jscan has been fixed. *
 *            column jscan is known to be nonzero.                         *
 * *************************************************************************
 * 
 */
void crnfp2() {
/*
 */
  static long i,is,ix,j;
/*
 */
  j=jscan;
  for(ix=1; ix<=nzamac_(j); ix++)  {
    is=amatcl_(ix+ptamac_(j));
    i=abs(is);
    if ((is*solut1_(j))>0) {
/*
 *  scaled column entry in row i is a +1
 */
      rnfrep_(i)=rnfrep_(i)-1;
    }
  }
  return;
}
/*
 * *************************************************************************
 *  subroutine devrd1                                                      *
 *                                                                         *
 *  purpose:  places change of deviation from nearly negative into         *
 *            devdif when column jscan has been scaled.  new scale         *
 *            factor is in solut1(jscan).  know column jscan to be         *
 *            nonzero.  rnfrep is not modified.                            *
 * *************************************************************************
 * 
 */
void devrd1() {
/*
 */
  static long i,is,ix,j;
/*
 */
  devdif=0;
  j=jscan;
  for(ix=1; ix<=nzamac_(j); ix++)  {
    is=amatcl_(ix+ptamac_(j));
    i=abs(is);
    if ((is*solut1_(j))>0) {
/*
 *  scaled column entry in row i is now a +1, and was a -1
 */
      if (rnfrep_(i)==1) {
        devdif=devdif+2;
      } else {
        if (rnfrep_(i)>1) {
          devdif=devdif+1;
        }
      }
    } else {
/*
 *  scaled column entry in row i is now a -1, and was a +1
 */
      if (rnfrep_(i)==2) {
        devdif=devdif-2;
      } else {
        if (rnfrep_(i)>2) {
          devdif=devdif-1;
        }
      }
    }
  }
  return;
}
/*
 * *************************************************************************
 *  subroutine devrd2                                                      *
 *                                                                         *
 *  purpose:  computes deviation reduction when free column jscan is       *
 *            declared to be fixed.  column jscan is known to be nonzero.  *
 * *************************************************************************
 * 
 */
void devrd2() {
/*
 */
  static long i,is,ix,j;
/*
 */
  devdif=0;
  j=jscan;
  for(ix=1; ix<=nzamac_(j); ix++)  {
    is=amatcl_(ix+ptamac_(j));
    i=abs(is);
    if ((is*solut1_(j))>0) {
/*
 *  scaled column entry in row i is a +1
 */
      if (rnfrep_(i)==2) {
        devdif=devdif-2;
      } else {
        if (rnfrep_(i)>2) {
          devdif=devdif-1;
        }
      }
    }
  }
  return;
}
/*
 * ***************************************************************************
 *  subroutine heu2st                                                        *
 *                                                                           *
 *  purpose:  locates a large column submatrix of 2sat form (i.e., at most   *
 *            two nonzeros in each row)                                      *
 *                                                                           *
 *    input:  as specified in module summary, with all variables free        *
 *            flgtrm = 1: early termination (depends on bdfxbl(q))           *
 *                   = 0: complete computations                              *
 *                                                                           *
 *   output:  some columns have been shifted from free to fixed              *
 *            so that in the new problem the submatrix of free               *
 *            columns has 2sat form.                                         *
 *                                                                           *
 *            bdfxvr = number of fixed columns in output problem,            *
 *                     which is in layer 1                                   *
 *                                                                           *
 *                                                                           *
 *   caution: if flgtrm = 1, then the computations are terminated as soon    *
 *            as bdfxvr reaches bdfxbl(q) value. in that case, layer 1       *
 *            must not be interpreted.                                       *
 *                                                                           *
 * ***************************************************************************
 * 
 */
void heu2st() {
/*
 */
  void mcfrfx();
/*
 */
  static long dev1,i,improv,ix,j,q;
/*
 */
  q=qblock;
/*
 *  programming error if not all columns free
 */
  for(j=1; j<=ncols; j++)  {
    if (cifix_(j)!=0) {
      error(" heu2st ","     52 ");
    }
  }
/*
 *  compute initial deviation from 2sat
 */
  devdif=0;
  for(i=1; i<=nrows; i++)  {
    if (rnall_(i)>2) {
      devdif=devdif+rnall_(i)-2;
    }
  }
/*
 *  initialize number of fixed variables
 */
  bdfxvr=0;
  zz150:;
/*
 *  done if 2sat at hand
 */
  if (devdif==0) {
    return;
  }
/*
 *  must fix at least one more column jscan
 *  initialize jscan and improv
 */
  jscan=0;
  improv=0;
/*
 *  evaluate reduction when one free column j is fixed
 */
  for(j=1; j<=ncols; j++)  {
/*
 *  skip fixed or zero columns
 */
    if ((cifix_(j)!=0)||
        (cnall_(j)==0)) {
      goto zz200;
    }
/*
 *  compute potential reduction dev1 by fixing of column j
 */
    dev1=0;
    for(ix=1; ix<=cnall_(j); ix++)  {
      i=abs(amatcl_(ix+ptamac_(j)));
      if (rnfre_(i)>2) {
        dev1=dev1+1;
      }
    }
/*
 *  update jscan and improv if better case
 */
    if (dev1>improv) {
      jscan=j;
      improv=dev1;
    }
  zz200:;}
/*
 *  if jscan = 0, have programming error
 */
  if (jscan==0) {
    error(" heu2st ","  202   ");
  }
/*
 *  fix column jscan and reduce devdif
 */
  mcfrfx(jscan);
  bdfxvr=bdfxvr+1;
  devdif=devdif-improv;
/*
 *  stop when flgtrm = 1 and bdfxvr has become as large as bdfxbl(q)
 */
  if ((flgtrm==1)&&
      (bdfxvr>=bdfxbl_(q))) {
    return;
  }
  goto zz150;
}
/*
 * ****************************************************************************
 * subroutine makneg                                                          *
 *                                                                            *
 * purpose:  scales the free columns of the problem in layer 1 so that the    *
 *           submatrix of free columns and active rows is nearly negative,    *
 *           or concludes that this is not possible.  scaling of column j     *
 *           is not permitted if optimz = 1 and cost(j) .ne. 0.               *
 *                                                                            *
 * output:   either:  succss = 1.                                             *
 *                    the free columns of the matrix so scaled that the free  *
 *                    columns and active rows define a nearly negative        *
 *                    matrix.  layer 1 contains the scaled nearly neg. matrix.*
 *                                                                            *
 *           or:      succss = 0.                                             *
 *                    the free columns cannot be scaled that the submatrix    *
 *                    of free columns and active rows becomes nearly          *
 *                    negative.                                               *
 *                    layer 1 contains input problem.                         *
 *                                                                            *
 *  caution: uses layers 2 and 3 for intermediate storage.                    *
 *                                                                            *
 *  ==============                                                            *
 *  update history                                                            *
 *  ==============                                                            *
 *  date      where                what was changed/reason                    *
 * ---------------------------------------------------------------------------*
 * ****************************************************************************
 * 
 */
void makneg() {
/*
 */
  void mcfrfx();
  void scalcl();
  void srwfre();
  void trancl();
  void tranpr();
/*
 */
  static long aij,i,j,jx,m,n;
/*
 *  -------------------------------------------------------------------
 *  step 1
 *  transfer layer 1 problem into layer 3 (to save it).  will now work
 *  in layers 1 and 2.  layer 1 initially has the problem of the input.
 *  -------------------------------------------------------------------
 */
  tranpr(c1,c3);
/*
 *  -------------------------------------------------------------------
 *  step 2
 *  if optimization, fix all columns j with cost(j) .ne. 0
 *  -------------------------------------------------------------------
 */
  if (optimz!=0) {
    for(j=1; j<=ncols; j++)  {
      if ((cnact_(j)>0)&&
          (cost_(j)!=0)) {
        mcfrfx(j);
      }
    }
/*
 *  check if fixed columns are nearly negative
 */
    for(i=1; i<=nrows; i++)  {
      if ((riact_(i)==1)&&
          (rnfixp_(i)>=2)) {
/*
 *  have violation of nearly negative.  hence cannot achieve nearly
 *  negative by scaling
 */
        succss=0;
        tranpr(c3,c1);
        return;
      }
    }
  }
/*
 *  -------------------------------------------------------------------
 *  step 3
 *  if there is an active row m with rnactp(m) >= 2 then jump to step 5
 *  (line 500)
 *  -------------------------------------------------------------------
 */
  zz300:;
  for(i=1; i<=nrows; i++)  {
    if ((riact_(i)==1)&&
        (rnactp_(i)>=2)) {
      m=i;
      goto zz500;
    }
  }
/*
 *  -------------------------------------------------------------------
 *  step 4
 *  (have desired solution in scale(j)).  transfer column information of
 *  layer 1 into layer 2.  transfer layer 3 problem (this is the original
 *  problem) into layer 1.
 *  update layer 1 using correct scale factors from layer 2 (which now
 *  has the solution).
 *  -------------------------------------------------------------------
 */
  trancl(c1,c2);
  tranpr(c3,c1);
  for(j=1; j<=ncols; j++)  {
    if (cifre_(j)==1) {
      if (scale_(j)!=cl_(j,19,2)) {
/*
 *  error if optimz = 1 and cost(j) .ne. 0
 */
        if ((optimz==1)&&
            (cost_(j)!=0)) {
          error(" makneg ","402     ");
        } else {
          scalcl(j);
        }
      }
    }
  }
  succss=1;
  return;
/*
 *  -------------------------------------------------------------------
 *  step 5
 *  here when riact(m) .eq. 1 .and. rnactp(m) .ge. 2
 *  scan row m to find a +1 coefficient in a free column n.  we will
 *  fix column n at most twice while searching for the desired result
 *  -------------------------------------------------------------------
 */
  zz500:;
  srwfre(m);
  for(jx=1; jx<=rwfrej_(colmax+1); jx++)  {
    n=rwfrej_(jx);
    if (rentry_(jx)==1) {
      goto zz600;
    }
  }
  error("makneg  ","515     ");
/*
 *  -------------------------------------------------------------------
 *  step 6
 *  move column n from free to fixed.  move problem of layer 1 to layer
 *  2 (to save it).
 *  -------------------------------------------------------------------
 */
  zz600:;
  mcfrfx(n);
  tranpr(c1,c2);
/*
 *  -------------------------------------------------------------------
 *  step 7
 *  if there is an active row i with rnfixp(i) >=2 goto step 10   (this
 *  implies that we must try scaling column n).
 *  -------------------------------------------------------------------
 */
  zz700:;
  for(i=1; i<=nrows; i++)  {
    if ((riact_(i)==1)&&
        (rnfixp_(i)>=2)) {
      goto zz1000;
    }
  }
/*
 *  -------------------------------------------------------------------
 *  step 8
 *  fixed columns are ok.  check for other columns that now can be fixed.
 *  if columns become fixed, goto step 7.
 *  -------------------------------------------------------------------
 */
  for(i=1; i<=nrows; i++)  {
    if ((riact_(i)==1)&&
        (rnfixp_(i)==1)&&
        (rnfre_(i)>=1)) {
      srwfre(i);
      for(jx=1; jx<=rwfrej_(colmax+1); jx++)  {
        j=rwfrej_(jx);
        aij=rentry_(jx);
        if (aij==1) {
          scalcl(j);
        }
        mcfrfx(j);
      }
      goto zz700;
    }
  }
/*
 *  --------------------------------------------------------------------
 *  step 9
 *  if there is a solution at all, it will exist with the fixed
 *  columns as given.  go to step 3
 *  --------------------------------------------------------------------
 */
  goto zz300;
/*
 *  --------------------------------------------------------------------
 *  step 10
 *  recover saved problem of layer 2.  must scale column n if there is
 *  to be a solution.
 *  -------------------------------------------------------------------
 */
  zz1000:;
/*
 *  move problem of layer 2 into layer 1
 */
  tranpr(c2,c1);
/*
 *  scale column n by scalcl(n)
 */
  scalcl(n);
/*
 *  -------------------------------------------------------------------
 *  step 11
 *  if there is an active row i with rnfixp(i) >= 2 : restore input
 *  problem of layer 3 to layer 1 and announce failure.
 *  -------------------------------------------------------------------
 */
  zz1100:;
  for(i=1; i<=nrows; i++)  {
    if ((riact_(i)==1)&&
        (rnfixp_(i)>=2)) {
      succss=0;
      tranpr(c3,c1);
      return;
    }
  }
/*
 *  -------------------------------------------------------------------
 *  step 12
 *  fixed columns are all ok.  check for other columns that can now
 *  be fixed.  if columns become fixed, goto step 11.
 *  -------------------------------------------------------------------
 */
  for(i=1; i<=nrows; i++)  {
    if ((riact_(i)==1)&&
        (rnfixp_(i)==1)&&
        (rnfre_(i)>=1)) {
      srwfre(i);
      for(jx=1; jx<=rwfrej_(colmax+1); jx++)  {
        j=rwfrej_(jx);
        aij=rentry_(jx);
        if (aij==1) {
          scalcl(j);
        }
        mcfrfx(j);
      }
      goto zz1100;
    }
  }
/*
 *  -------------------------------------------------------------------
 *  step 13
 *  if there is a solution at all, it will exist with the fixed columns
 *  as given.   goto step 3.
 *  -------------------------------------------------------------------
 */
  goto zz300;
}
/*
 * ****************************************************************************
 * subroutine optalg                                                          *
 *                                                                            *
 * purpose:  selects solution algorithm for block qblock optimally            *
 *                                                                            *
 *   input:  as specified in module summary. it is assumed that a solution    *
 *           method has already been selected, or equivalently, twosat(q) >=0 *
 *                                                                            *
 *  output:  twosat(qblock), which determines solution algorithm for strip    *
 *           qblock.                                                          *
 *                                                                            *
 *           twosat(qblock) = 0:  some columns have been moved from free to   *
 *                                fixed, and some columns                     *
 *                                have been scaled so that the submatrix of   *
 *                                free columns is nearly negative.            *
 *                                                                            *
 *           twosat(qblock) = 1:  some columns have been moved from free to   *
 *                                fixed so that the                           *
 *                                submatrix of free columns has 2sat format.  *
 *                                this case is not possible when              *
 *                                optimz = 1.                                 *
 *                                                                            *
 *           bdfxbl(q) = number of fixed columns for block q.                 *
 *                                                                            *
 *    caution:  do not call this routine if twosat(q) < 0                     *
 *                                                                            *
 *              uses layers 2 and 3 for intermediate storage.                 *
 *                                                                            *
 * ****************************************************************************
 * 
 */
void optalg() {
/*
 */
  void heuneg();
  void heu2st();
  void mcfxfr();
  void optneg();
  void opt2st();
  void tranpr();
/*
 */
  static long q,j;
/*
 */
  q=qblock;
  if (twosat_(q)<0) {
/*
 *  programming error, need solution algorithm for block q to start
 */
    error(" optalg ","      52");
  }
  if (bdfxbl_(q)==0) {
/*
 *  have already best possible case
 */
    return;
  }
/*
 *  shift all fixed columns to free
 */
  for(j=1; j<=ncols; j++)  {
    if (cifix_(j)!=0) {
      mcfxfr(j);
    }
  }
/*
 *  use optneg and opt2st to get a  maximum nearly negative or 2sat
 *  subproblem, and update bdfxbl(q) accordingly
 *  first we search for maximum nearly negative submatrix
 */
  if (accflg == 1) {
    printf("optalg 1\n");
  } else {
    if (scrflg == 1) {
      printf("*");
      fflush(stdout);
    }
  }
/*
 *  call heuneg to get a starting solution for the optimization problem
 */
  heuneg();
  if (twosat_(q)==0) {
/*
 *  know that nearly negative case was selected earlier. thus assume this
 *  choice is good again, even  though we may have done now worse than
 *  originally due to heuristic method
 */
    bdfxbl_(q)=bdfxvr;
  } else {
/*
 *  had 2sat case originally. we know that we always can recreate that
 *  solution in heu2st. thus update bdfxbl(q) only if bdfxvr of heuneg
 *  is better
 */
    if (bdfxbl_(q)>bdfxvr) {
      bdfxbl_(q)=bdfxvr;
      twosat_(q)=0;
    }
  }
/*
 *  save heuneg output in layer 3
 */
  tranpr(c1,c3);
/*
 *  call optneg to get maximum nearly negative subproblem
 */
  optneg();
/*
 *  decide whether solution by optneg is worse than the one by heuneg
 *  which is in layer 3 (this is possible since at present we solve
 *  the ip problem approximately by rounding lp solutions), or than the
 *  solution originally found (applies only if twosat(q) = 1)
 */
  if (bdfxvr<bdfxbl_(q)) {
/*
 *  optneg has found a better solution. accept it and retain in layer 3
 */
    if (accflg == 1) {
      printf("optneg solution better\n");
    }
    bdfxbl_(q)=bdfxvr;
    twosat_(q)=0;
    tranpr(c1,c3);
  } else {
/*
 *  the solution by optneg is inferior
 *  tranfer the solution on hand prior to optneg call, from layer 3 to 1
 */
    tranpr(c3,c1);
  }
/*
 *  at this point we have the so far best problem in layers 1 and 3,
 *  unless twosat(q) = 1. in the latter case, the originally found
 *  2sat solution is even better. the latter case is not possible under
 *  optimization
 *  if optimz = 1, stop
 */
  if (optimz==1) {
    return;
  }
/*
 *  problem does not involve optimization
 *  in next part we search for maximum 2sat submatrix.
 */
  if (accflg == 1) {
    printf("optalg 2\n");
  } else {
    if (scrflg == 1) {
      printf("*");
      fflush(stdout);
    }
  }
/*
 *  shift all fixed columns to free for heu2st
 */
  for(j=1; j<=ncols; j++)  {
    if (cifix_(j)!=0) {
      mcfxfr(j);
    }
  }
/*
 *  call heu2st to get a starting solution for optneg. set flgtrm = 0
 *  to avoid early termination of heu2st
 */
  flgtrm=0;
  heu2st();
/*
 *  if the originally selected solution has beaten heuneg and optneg,
 *  then we have twosat(q) = 1, and heu2st has now recreated that
 *  solution. in that case, we can check for error
 */
  if (twosat_(q)==1) {
    if (bdfxvr!=bdfxbl_(q)) {
/*
 *  programming error, originally selected 2sat must still be best,
 *  and must have been selected by current application of heu2st
 */
      error(" optalg ","     502");
    }
/*
 *  store the heu2st solution in layer 3 since so far it is best
 */
    tranpr(c1,c3);
  }
/*
 *  call opt2st to get maximum 2sat subproblem
 */
  opt2st();
/*
 *  decide whether solution by opt2st is better
 *  than solution on hand prior to opt2st call
 * 
 *  rule below for selection of 2st assures that
 *  2sat case is possible in enufxz and enufx1,
 *  but cannot occur in enufix2. for details, see
 *  selection of these procedures in enufix
 */
  if ((bdfxvr<=aggmax)&&
      (bdfxvr<bdfxbl_(q))) {
/*
 *  opt2st has found a better solution
 */
    if (accflg == 1) {
      printf("opt2st solution better\n");
    }
    bdfxbl_(q)=bdfxvr;
    twosat_(q)=1;
  } else {
/*
 *  the solution by opt2st is inferior
 *  transfer solution on hand prior to opt2st call, from layer 3 to 1
 */
    tranpr(c3,c1);
  }
  return;
}
/*
 * *****************************************************************
 *  subroutine optneg
 * 
 *  purpose:  scales the columns to create a maximum nearly negative
 *            column submatrix.
 *            scaling of column j is not permitted if optimz = 1 and
 *            cost(j) .ne. 0.
 * 
 *  input:    problem with existing nearly negative solution in
 *            layer 1
 *            bdfxbl(q) = number of fixed variables of that solution
 * 
 *  output:   some free columns have been shifted from free to fixed
 *            or fixed to free, and some free columns have been
 *            scaled so that in the new matrix the submatrix of free
 *            columns is nearly negative, and subject to that
 *            condition, maximum.
 * 
 *            bdfxvr = number of fixed columns in output problem,
 *            which is in layer 1.
 * 
 *  caution:  use of optneg is restricted so that solution of too
 *            large lps is not attempted. the restrictions are
 *            defined prior to the 'BEG XMP' call.
 * 
 *  caution:  if in the output we have bdfxvr = bdfxbl(q), then
 *            the optimization computations were terminated early,
 *            and layer 1 data must not be interpreted
 * 
 *            uses layer 2 for intermediate storage
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where             what was changed/reason
 * -----------------------------------------------------------------
 * 
 * *****************************************************************
 * 
 */
void optneg() {
/*
 */
  void lpexec();
  void mcfrfx();
  void mcfxfr();
  void scalcl();
/*
 */
  static long flag,i,ilp,is,ix,j,jx,js,m,n,n1,n2,n3;
  static long jlp,jjlp,nredrw,q,xj,xj1,xj2;
/*
 *  variables for epsilon perturbation
 */
  static long pf1,pf2,pfm1,pfm2;
  static double epsb,epsc;
/*
 *  ----------------------------------------------------------------
 *  step 1
 *  initialize scale factors in cl_(.,1,2) vector and set cl_(.,2,2) to 0.
 *  initialize cl_(.,3,2) and cl_(.,4,2) vectors to encode possible scaling
 *  and fixing. the notation lines up with heuneg as follows:
 *  solut1 - solut4 of heuneg is cl_(.,1,2) - cl_(.,4,2) here. note
 *  that these cl vectors cannot be interpreted as usual cl data
 *  ----------------------------------------------------------------
 */
  q=qblock;
  for(j=1; j<=ncols; j++)  {
/*
 *  initialize cl_(.,1,2) - cl_(.,4,2)
 *  cl_(.,1,2) = scale factors
 *  cl_(.,2,2) = list of variables that in optimal solution must be fixed
 *  cl_(.,3,2) = list of variables that may be scaled
 *  cl_(.,4,2) = list of variables that may be fixed
 */
    cl_(j,1,2)=1;
    cl_(j,2,2)=0;
    cl_(j,3,2)=1;
    cl_(j,4,2)=1;
/*
 *  if column j is zero, no scaling or fixing
 */
    if (cnall_(j)==0) {
      cl_(j,3,2)=0;
      cl_(j,4,2)=0;
    } else {
/*
 *  column j is nonzero
 *  if optimization case with nonzero cost, then no scaling
 *  if in addition no positive entries, then no fixing
 */
      if ((optimz!=0)&&
          (cost_(j)!=0)) {
        cl_(j,3,2)=0;
        if (cnallp_(j)==0) {
          cl_(j,4,2)=0;
        }
      } else {
/*
 *  column j is nonzero;  if optimization, then cost is known to be zero
 *  if no positive entries, no scaling and no fixing
 */
        if (cnallp_(j)==0) {
          cl_(j,3,2)=0;
          cl_(j,4,2)=0;
        } else {
/*
 *  if no negative entries, have programming error since heuneg has been
 *  applied prior to call of optneg
 */
          if (cnalln_(j)==0) {
            error(" optneg ","     102");
          }
        }
      }
    }
  }
/*
 *  ----------------------------------------------------------------
 *  step 2
 *  initialize rw_(i,1,2) = ilp = index of lp row for row i of problem
 *  initialize rw_(ilp,2,2) = i = index of problem row for lp row ilp
 *  note that these rw vectors cannot be interpreted as ususal rw data
 *  compute nredrw = number of problem rows entering lp
 *  ----------------------------------------------------------------
 * 
 *  compute effective row count to find all rows with at most one
 *  nonzero. these rows do not enter into the lp
 * 
 */
  nredrw=0;
  for(i=1; i<=nrows; i++)  {
/*
 *  n1  is the number of entries in row i and in columns j that can
 *  generate lp rows, i.e., where cl_(j,4,2) = 1
 */
    n1=0;
    if (nzamar_(i)>0) {
      for(jx=1; jx<=nzamar_(i); jx++)  {
        js=amatrw_(jx+ptamar_(i));
        j=abs(js);
        if (cl_(j,4,2)==1) {
          if ((js>0)||
              (cl_(j,3,2)==1)) {
/*
 *  column j generates (one or two) lp columns, if at all
 */
            n1=n1+1;
          }
        }
      }
    }
    if (n1<=1) {
/*
 *  row i is to be skipped
 */
      rw_(i,1,2)=0;
    } else {
/*
 *  row i does generate an lp packing row
 */
      nredrw=nredrw+1;
      rw_(i,1,2)=nredrw;
      rw_(nredrw,2,2)=i;
    }
  }
  if (nredrw<=0) {
/*
 *  programming error: if no lp rows, then makneg should have
 *  achieved nearly negative matrix
 */
    error(" optneg ","     212");
  }
/*
 * ---------------------------------------------------------------------
 *  step 3
 *  determine the total number of lp columns and nonzeros
 *  note: n1, n2, n3 are defined here, and must not be changed later
 * ---------------------------------------------------------------------
 */
  n1=0;
  n2=0;
  n3=0;
/*
 *  update column indices so that columns are correctly
 *  excluded from the lp
 */
  for(j=1; j<=ncols; j++)  {
    if (cl_(j,4,2)==1) {
/*
 *  j is a candidate column; check whether j actually
 *  generates (one or two) lp columns
 *  by definition of cl_(j,4,2), column j must be nonzero
 */
      if (nzamac_(j)<=0) {
        error(" optneg ","     302");
      }
      flag=0;
      for(ix=1; ix<=nzamac_(j); ix++)  {
        is=amatcl_(ix+ptamac_(j));
        i=abs(is);
        if (rw_(i,1,2)>0) {
/*
 *  row i does generate an lp row
 */
          if ((is>0)||
              (cl_(j,3,2)==1)) {
            n3=n3+1;
            flag=1;
          }
        }
      }
      if (flag==0) {
/*
 *  actually, no lp column needs to be generated by this column
 */
        cl_(j,3,2)=0;
        cl_(j,4,2)=0;
      } else {
/*
 *  one or two lp columns are actually generated by this column
 *  record in n1 or n2, depending on case
 */
        if (cl_(j,3,2)==0) {
          n1=n1+1;
        } else {
          n2=n2+1;
        }
      }
    }
  }
/*
 *  m = number of lp rows
 *  n = number of lp columns
 *  n3= number of nonzeros in lp
 */
  m=nredrw+n2;
  n=n1+2*n2+m;
  n3=n3+2*n2+m;
/*
 *  check if problem is too large
 */
  if ((m>800)||
      (n>1600)) {
    xpoint_(1)=0;
  } else {
/*
 *  begin xmp
 */
    strcpy(xcomnd,"BEG XMP");
    xpoint_(1)=m;
    xpoint_(2)=n;
    xpoint_(3)=n3;
    lpexec(xcomnd,xpoint,xvalue);
  }
  if (xpoint_(1)==0) {
/*
 *  lp problem is too big, either due to above test, or due to
 *  test by beg xmp command, which checks allocated xmp dimensions
 *  skip rest of subroutine
 */
    bdfxvr=bdfxbl_(q);
    return;
  }
/*
 * -----------------------------------------------------------------
 *  step 4
 *  assemble the lp columns produced by the n1 logic columns
 * ------------------------------------------------------------------
 *  set epsilon perturbation for objective function of lp
 */
  epsc=0.0001;
  pfm1=5;
  pfm2=11;
  pf1=pfm1/2;
  pf2=pfm2/2;
  jlp=0;
  for(j=1; j<=ncols; j++)  {
    if ((cl_(j,3,2)==0)&&
        (cl_(j,4,2)==1)) {
/*
 *  begin lp column
 */
      jlp=jlp+1;
      strcpy(xcomnd,"BEG COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put objective function coefficient of lp column
 *  compute factor pf2 for epsilon perturbation
 */
      pf1=pf1+1;
      if (pf1>pfm1) {
        pf1=2;
      }
      pf2=pf2+pf1;
      if (pf2>pfm2) {
        pf2=pf2-pfm2;
      }
      strcpy(xcomnd,"PUT OBJ");
      xpoint_(1)=jlp;
      xvalue_(1)=1.0+epsc*(double)pf2;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put lp column
 */
      if (nzamac_(j)<=0) {
/*
 *  programming error if column j is zero
 */
        error(" optneg ","     402");
      }
      flag=0;
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=amatcl_(ix+ptamac_(j));
        if (i>0) {
          ilp=rw_(i,1,2);
          if (ilp>0) {
            flag=1;
            strcpy(xcomnd,"PUT COL");
            xpoint_(1)=jlp;
            xpoint_(2)=ilp;
            xvalue_(1)=1.0;
            lpexec(xcomnd,xpoint,xvalue);
          }
        }
      }
      if (flag==0) {
/*
 *  programming error
 */
        error(" optneg ","     412");
      }
/*
 *  end lp column
 */
      strcpy(xcomnd,"END COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
    }
  }
  if (jlp!=n1) {
/*
 *  programming error
 */
    error(" optneg ","     422");
  }
/*
 * ---------------------------------------------------------------------
 *  step 5
 *  assemble the lp columns produced by the n2 logic columns
 * ---------------------------------------------------------------------
 */
  jjlp=0;
  for(j=1; j<=ncols; j++)  {
    if ((cl_(j,3,2)==1)&&
        (cl_(j,4,2)==1)) {
/*
 *  begin lp column for positive entries of logic column
 * 
 *  note: there may not be any such entry, due to the
 *  elimination of rows with just one entry. but lp
 *  column is nonzero due to gub row. this problem can only be
 *  eliminated by repeated matrix reductions, presently not
 *  implemented. the same comment applies to the lp column
 *  generated by the negative entries of the matrix column.
 *  but there must be at least one nonzero in the problem
 *  column, so at least one of the two lp columns must have
 *  an entry beyond the gub entry. with flag we test for this.
 */
      flag=0;
      jjlp=jjlp+1;
      jlp=jlp+1;
      strcpy(xcomnd,"BEG COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put objective function value for lp column
 *  compute factor pf2 for epsilon perturbation
 */
      pf1=pf1+1;
      if (pf1>pfm1) {
        pf1=2;
      }
      pf2=pf2+pf1;
      if (pf2>pfm2) {
        pf2=pf2-pfm2;
      }
      strcpy(xcomnd,"PUT OBJ");
      xpoint_(1)=jlp;
      xvalue_(1)=1.0+epsc*(double)pf2;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put lp column for positive entries
 */
      if (nzamac_(j)<=0) {
/*
 *  programming error if logic column is zero
 */
        error(" optneg ","     502");
      }
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=amatcl_(ix+ptamac_(j));
        if (i>0) {
          ilp=rw_(i,1,2);
          if (ilp>0) {
            flag=1;
            strcpy(xcomnd,"PUT COL");
            xpoint_(1)=jlp;
            xpoint_(2)=ilp;
            xvalue_(1)=1.0;
            lpexec(xcomnd,xpoint,xvalue);
          }
        }
      }
/*
 *  put column coefficient for gub lp row
 */
      strcpy(xcomnd,"PUT COL");
      xpoint_(1)=jlp;
      xpoint_(2)=nredrw+jjlp;
      xvalue_(1)=1.0;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  end column
 */
      strcpy(xcomnd,"END COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  initialize lp column for negative entries of logic column
 */
      jlp=jlp+1;
      strcpy(xcomnd,"BEG COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put objective function value for lp column
 *  compute factor pf2 for epsilon perturbation
 */
      pf1=pf1+1;
      if (pf1>pfm1) {
        pf1=2;
      }
      pf2=pf2+pf1;
      if (pf2>pfm2) {
        pf2=pf2-pfm2;
      }
      strcpy(xcomnd,"PUT OBJ");
      xpoint_(1)=jlp;
      xvalue_(1)=1.0+epsc*(double)pf2;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put lp column for negative entries of logic column
 */
      if (nzamac_(j)<=0) {
/*
 *  programming error if column is zero
 */
        error(" optneg ","     532");
      }
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=-amatcl_(ix+ptamac_(j));
        if (i>0) {
          ilp=rw_(i,1,2);
          if (ilp>0) {
            flag=1;
            strcpy(xcomnd,"PUT COL");
            xpoint_(1)=jlp;
            xpoint_(2)=ilp;
            xvalue_(1)=1.0;
            lpexec(xcomnd,xpoint,xvalue);
          }
        }
      }
      if (flag==0) {
/*
 *  programming error, both lp columns are zero except for
 *  the two gub entries
 */
        error(" optneg ","     542");
      }
/*
 *  put lp column coefficient for gub bound
 */
      strcpy(xcomnd,"PUT COL");
      xpoint_(1)=jlp;
      xpoint_(2)=nredrw+jjlp;
      xvalue_(1)=1.0;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  end column
 */
      strcpy(xcomnd,"END COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
    }
  }
/*
 *  programming error if jjlp .ne. n2
 */
  if (jjlp!=n2) {
    error(" optneg ","     552");
  }
/*
 * ---------------------------------------------------------------------
 *  step 6
 *  assemble lp columns for lp slack variables
 * ---------------------------------------------------------------------
 */
  for(ilp=1; ilp<=m; ilp++)  {
    jlp=jlp+1;
/*
 *  begin column
 */
    strcpy(xcomnd,"BEG COL");
    xpoint_(1)=jlp;
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  put objective function coefficient
 */
    strcpy(xcomnd,"PUT OBJ");
    xpoint_(1)=jlp;
    xvalue_(1)=0.0;
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  put column coefficient
 */
    strcpy(xcomnd,"PUT COL");
    xpoint_(1)=jlp;
    xpoint_(2)=ilp;
    xvalue_(1)=1.0;
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  end column
 */
    strcpy(xcomnd,"END COL");
    xpoint_(1)=jlp;
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 * ---------------------------------------------------------------------
 *  step 7
 *  assign lower und and upper bounds for lp variables
 * ---------------------------------------------------------------------
 */
  for(jlp=1; jlp<=n; jlp++)  {
    strcpy(xcomnd,"PUT BND");
    xpoint_(1)=jlp;
    xvalue_(1)=0.0;
    if (jlp<=n1+2*n2) {
/*
 *  have structural lp variable
 */
      xvalue_(2)=1.0;
    } else {
/*
 *  have lp slack variable, has implicit max value = 1.0
 *  use larger value to reduce degeneracy
 */
      xvalue_(2)=3.0;
    }
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 * ---------------------------------------------------------------------
 *  step 8
 *  put lp rhs values
 * ---------------------------------------------------------------------
 *  set epsilon perturbation for right hand side of lp
 */
  epsb=0.0001;
  pfm1=5;
  pfm2=11;
  pf1=pfm1/2;
  pf2=pfm2/2;
/*
 */
  for(ilp=1; ilp<=m; ilp++)  {
/*
 *  compute factor pf2 for epsilon perturbation
 */
    pf1=pf1+1;
    if (pf1>pfm1) {
      pf1=2;
    }
    pf2=pf2+pf1;
    if (pf2>pfm2) {
      pf2=pf2-pfm2;
    }
/*
 */
    strcpy(xcomnd,"PUT RHS");
    xpoint_(1)=ilp;
    xvalue_(1)=1.0+epsb*(double)pf2;
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 * ---------------------------------------------------------------------
 *  step 9
 *  put basis by declaring the lp slack variables to be basic
 * ---------------------------------------------------------------------
 */
  for(ilp=1; ilp<=m; ilp++)  {
    strcpy(xcomnd,"PUT BAS");
    xpoint_(1)=n1+2*n2+ilp;
    xpoint_(2)=ilp;
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 * ---------------------------------------------------------------------
 *  step 10
 *  put nonbasis bounds using cifre of layer 1
 * ---------------------------------------------------------------------
 */
  jlp=0;
  jjlp=0;
  for(j=1; j<=ncols; j++)  {
    if ((cl_(j,3,2)==0)&&
        (cl_(j,4,2)==1)) {
/*
 *  column j can be fixed but not scaled
 */
      jlp=jlp+1;
      if (cifre_(j)!=0) {
/*
 *  j is free
 *  put nonbasis by setting lp variable jlp to upper bound
 */
        strcpy(xcomnd,"PUT NBS");
        xpoint_(1)=jlp;
        xpoint_(2)=-1;
        lpexec(xcomnd,xpoint,xvalue);
      } else {
/*
 *  j is fixed
 *  put nonbasis by setting lp variable jlp to lower bound
 */
        strcpy(xcomnd,"PUT NBS");
        xpoint_(1)=jlp;
        xpoint_(2)=0;
        lpexec(xcomnd,xpoint,xvalue);
      }
    }
/*
 */
    if ((cl_(j,3,2)==1)&&
        (cl_(j,4,2)==1)) {
/*
 *  column j can be fixed and scaled
 */
      jjlp=jjlp+1;
      if (cifre_(j)!=0) {
/*
 *  j is free
 *  put nonbasis by setting lp variable of positive part of logic
 *  column j to upper bound, and of negative part to lower bound
 */
        strcpy(xcomnd,"PUT NBS");
        xpoint_(1)=n1+2*(jjlp-1)+1;
        xpoint_(2)=-1;
        lpexec(xcomnd,xpoint,xvalue);
        xpoint_(1)=n1+2*(jjlp-1)+2;
        xpoint_(2)=0;
        lpexec(xcomnd,xpoint,xvalue);
      } else {
/*
 *  j is fixed
 *  put nonbasis by setting both lp variables of logic column j
 *  to lower bound
 */
        strcpy(xcomnd,"PUT NBS");
        xpoint_(1)=n1+2*(jjlp-1)+1;
        xpoint_(2)=0;
        lpexec(xcomnd,xpoint,xvalue);
        xpoint_(1)=n1+2*(jjlp-1)+2;
        xpoint_(2)=0;
        lpexec(xcomnd,xpoint,xvalue);
      }
    }
  }
/*
 * ---------------------------------------------------------------------
 *  step 11
 *  factorize basis
 * ---------------------------------------------------------------------
 */
  strcpy(xcomnd,"FAC BAS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 * ---------------------------------------------------------------------
 *  step 12
 *  solve ip
 * ---------------------------------------------------------------------
 *  define lower bound on the objective function value
 *  currently known bound is n1 + n2 - bdfxbl(q)
 */
  xvalue_(1)=n1+n2-bdfxbl_(q);
  strcpy(xcomnd,"SOL IP ");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  check if fewer fixed variables have been found. xpoint(1) behaves
 *  like the succss variable
 */
  if (xpoint_(1)==0) {
/*
 *  did not find a better solution. hence skip rest of subroutine
 */
    bdfxvr=bdfxbl_(q);
    return;
  }
/*
 *  no step 13
 * ---------------------------------------------------------------------
 *  step 14
 *  get the ip solution
 *  first, the lp variables produced from the n1 logic columns
 *     xj = 0: logic column j must be fixed
 *     xj = 1: logic column j is in nearly negative subproblem
 *     initialize bdfxvr = number of fixed variables
 * ---------------------------------------------------------------------
 */
  bdfxvr=0;
  jlp=0;
  for(j=1; j<=ncols; j++)  {
    if ((cl_(j,3,2)==0)&&
        (cl_(j,4,2)==1)) {
      jlp=jlp+1;
      strcpy(xcomnd,"GET SOL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
      xj=xvalue_(1)+0.1;
      if (xj==0) {
/*
 *  logic column j must be fixed
 */
        cl_(j,2,2)=1;
        bdfxvr=bdfxvr+1;
      }
    }
  }
/*
 * ---------------------------------------------------------------------
 *  step 15
 *  second, the lp variables produced from the n2 logic columns
 *    xj1 = solution value of first lp column of a pair of lp columns
 *    xj2 = solution value of second lp column
 *  cases:
 *  xj1 = 1, xj2 = 0: logic column is free, and is not scaled
 *  xj1 = 0, xj2 = 1: logic column is free, and is scaled
 *  xj1 = 0, xj2 = 0: logic column is fixed
 *  xj1 = 1, xj2 = 1: programming error
 * ---------------------------------------------------------------------
 */
  for(j=1; j<=ncols; j++)  {
    if ((cl_(j,3,2)==1)&&
        (cl_(j,4,2)==1)) {
      jlp=jlp+1;
/*
 */
      strcpy(xcomnd,"GET SOL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
      xj1=xvalue_(1)+0.1;
/*
 */
      jlp=jlp+1;
/*
 */
      strcpy(xcomnd,"GET SOL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
      xj2=xvalue_(1)+0.1;
/*
 */
      if ((xj1==1)&&
          (xj2==1)) {
/*
 *  programming error
 */
        error(" optneg ","    1502");
      }
      if ((xj1==0)&&
          (xj2==1)) {
/*
 *  scale logic column j
 */
        cl_(j,1,2)=-1;
      }
      if ((xj1==0)&&
          (xj2==0)) {
/*
 *  declare logic column j to be fixed
 */
        bdfxvr=bdfxvr+1;
        cl_(j,2,2)=1;
      }
    }
  }
  if (bdfxvr==bdfxbl_(q)) {
/*
 *  programming error since solution by ip is not better
 */
    error(" optneg ","    1504");
  }
/*
 *  no step 16 -19
 * ---------------------------------------------------------------------
 *  step 20
 *  create output problem in layer 1
 * ---------------------------------------------------------------------
 *  update layer 1 problem according to layer 2
 *  information of cl_(.,1,2) for scaling and cl_(.,2,2) for fixing
 */
  for(j=1; j<=ncols; j++)  {
    if ((cifix_(j)!=0)&&
        (cl_(j,2,2)==0)) {
      mcfxfr(j);
    } else {
      if ((cifix_(j)==0)&&
          (cl_(j,2,2)!=0)) {
        mcfrfx(j);
      }
    }
    if ((cl_(j,1,2)<0)&&
        (cl_(j,2,2)==0)) {
      scalcl(j);
    }
  }
/*
 * ---------------------------------------------------------------------
 *  step 21
 *  check correctness of solution
 * ---------------------------------------------------------------------
 */
  for(i=1; i<=nrows; i++)  {
    if (rnfrep_(i)>=2) {
      error(" optneg ","    2102");
    }
  }
  return;
}
/*
 * ****************************************************************
 *  subroutine opt2st
 * 
 *  purpose:  selects a maximum size 2sat subsystem for the problem
 *            in layer 1. may be used only if optimz = 0
 * 
 *  input:    problem with existing 2sat solution in layer 1
 * 
 *  output:   some columns have been shifted from free to fixed or
 *            fixed to free so that in the new matrix the submatrix
 *            of free columns is 2sat, and subject to that condition,
 *            maximum.
 * 
 *            bdfxvr = number of fixed columns in output problem,
 *                     which is in layer 1
 * 
 *  caution:  use of opt2st is restricted so that solution of too
 *            large lps is not attempted. the restrictions are
 *            defined prior to the 'BEG XMP' call.
 * 
 *  caution:  if in the output we have bdfxvr = bdfxbl(q), then
 *            the optimization computations were terminated early,
 *            and layer 1 data must not be interpreted
 * 
 *            uses layer 2 for intermediate storage
 * 
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where             what was changed/reason
 * -----------------------------------------------------------------
 * 
 * *****************************************************************
 * 
 */
void opt2st() {
/*
 */
  void lpexec();
  void mcfrfx();
  void mcfxfr();
/*
 */
  static long i,ilp,ix,j,m,n,n1,n3,jlp,nredrw,q,xj;
/*
 *  variables for epsilon perturbation
 */
  static long pf1,pf2,pfm1,pfm2;
  static double epsb,epsc;
/*
 *  ------------------------------------------------------------------------
 *  step 1
 *  initialize rw_(i,1,2) = ilp = index of lp row for row i of problem
 *  initialize rw_(ilp,2,2) = i = index of problem row for lp row ilp
 *  compute nredrw = number of problem rows entering lp
 *  ------------------------------------------------------------------------
 */
  q=qblock;
  nredrw=0;
  for(i=1; i<=nrows; i++)  {
    if (rnall_(i)<=2) {
/*
 *  row i is not part of lp
 */
      rw_(i,1,2)=0;
    } else {
/*
 *  row i is in lp. record index ilp for i in rw_(i,1,2)
 *  record i corresponding to ilp in rw_(ilp,2,2)
 */
      nredrw=nredrw+1;
      rw_(i,1,2)=nredrw;
      rw_(nredrw,2,2)=i;
    }
  }
/*
 *  ----------------------------------------------------------------
 *  step 2
 *  compute cl_(j,1,2) (=1 means j in lp, =0 means j not in lp)
 *  initialize cl_(.,2,2) to 0; encodes the fixing (=1 fixed, =0 free)
 *  the vectors cl cannot be interpreted as usual cl data
 *  compute n3 = number of nonzeros in lp
 *  ----------------------------------------------------------------
 */
  n3=0;
  for(j=1; j<=ncols; j++)  {
/*
 *  cl_(.,2,2) = list of variables that in optimal solution must be fixed
 */
    cl_(j,2,2)=0;
/*
 *  determine variables that are to be in the lp
 */
    cl_(j,1,2)=0;
    if (nzamac_(j)>0) {
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=abs(amatcl_(ix+ptamac_(j)));
        if (rw_(i,1,2)>0) {
/*
 *  column j has a nonzero in a problem row that is part of the lp
 *  thus column j becomes part of the lp
 */
          cl_(j,1,2)=1;
          n3=n3+1;
        }
      }
    }
  }
/*
 * ---------------------------------------------------------------------
 *  step 3
 *  determine the total number of lp columns
 * ---------------------------------------------------------------------
 */
  n1=0;
  for(j=1; j<=ncols; j++)  {
    if (cl_(j,1,2)==1) {
      n1=n1+1;
    }
  }
/*
 *  m = number of lp rows
 *  n = number of lp columns
 *  n3= number of nonzeros in lp
 */
  m=nredrw;
  n=n1+m;
  n3=n3+m;
/*
 *  check if problem is too large
 */
  if ((m>400)||
      (n>800)) {
    xpoint_(1)=0;
  } else {
/*
 *  begin xmp
 */
    strcpy(xcomnd,"BEG XMP");
    xpoint_(1)=m;
    xpoint_(2)=n;
    xpoint_(3)=n3;
    lpexec(xcomnd,xpoint,xvalue);
  }
  if (xpoint_(1)==0) {
/*
 *  lp problem is too big, either due to above test, or due to
 *  test by beg xmp command, which checks allocated xmp dimensions
 *  skip rest of subroutine
 */
    bdfxvr=bdfxbl_(q);
    return;
  }
/*
 * -----------------------------------------------------------------
 *  step 4
 *  assemble the lp columns produced by the n1 logic columns
 * -----------------------------------------------------------------
 *  set epsilon perturbation for objective function of lp
 */
  epsc=0.0001;
  pfm1=5;
  pfm2=11;
  pf1=pfm1/2;
  pf2=pfm2/2;
  jlp=0;
  for(j=1; j<=ncols; j++)  {
    if (cl_(j,1,2)==1) {
/*
 *  error if column j is zero
 */
      if (nzamac_(j)==0) {
        error(" opt2st ","     402");
      }
/*
 *  begin lp column
 */
      jlp=jlp+1;
      strcpy(xcomnd,"BEG COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put objective function coefficient of lp column
 *  compute factor pf2 for epsilon perturbation
 */
      pf1=pf1+1;
      if (pf1>pfm1) {
        pf1=2;
      }
      pf2=pf2+pf1;
      if (pf2>pfm2) {
        pf2=pf2-pfm2;
      }
      strcpy(xcomnd,"PUT OBJ");
      xpoint_(1)=jlp;
      xvalue_(1)=1.0+epsc*(double)pf2;
      lpexec(xcomnd,xpoint,xvalue);
/*
 *  put lp column
 */
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=abs(amatcl_(ix+ptamac_(j)));
        ilp=rw_(i,1,2);
        if (ilp>0) {
          strcpy(xcomnd,"PUT COL");
          xpoint_(1)=jlp;
          xpoint_(2)=ilp;
          xvalue_(1)=1.0;
          lpexec(xcomnd,xpoint,xvalue);
        }
      }
/*
 *  end lp column
 */
      strcpy(xcomnd,"END COL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
    }
  }
  if (jlp!=n1) {
/*
 *  programming error
 */
    error(" opt2st ","     422");
  }
/*
 *  no step 5
 * ---------------------------------------------------------------------
 *  step 6
 *  assemble lp columns for lp slack variables
 * ---------------------------------------------------------------------
 */
  for(ilp=1; ilp<=m; ilp++)  {
    jlp=jlp+1;
/*
 *  begin column
 */
    strcpy(xcomnd,"BEG COL");
    xpoint_(1)=jlp;
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  put objective function coefficient
 */
    strcpy(xcomnd,"PUT OBJ");
    xpoint_(1)=jlp;
    xvalue_(1)=0.0;
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  put column coefficient
 */
    strcpy(xcomnd,"PUT COL");
    xpoint_(1)=jlp;
    xpoint_(2)=ilp;
    xvalue_(1)=1.0;
    lpexec(xcomnd,xpoint,xvalue);
/*
 *  end column
 */
    strcpy(xcomnd,"END COL");
    xpoint_(1)=jlp;
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 *  programming error if jlp .ne. n
 */
  if (jlp!=n) {
    error(" opt2st ","     602");
  }
/*
 * ---------------------------------------------------------------------
 *  step 7
 *  assign lower und and upper bounds for lp variables
 * ---------------------------------------------------------------------
 */
  for(jlp=1; jlp<=n; jlp++)  {
    strcpy(xcomnd,"PUT BND");
    xpoint_(1)=jlp;
    xvalue_(1)=0.0;
/*
 *  structural variables have upper bound 1.0, slacks have
 *  upper bound 3.0
 */
    if (jlp<=n1) {
      xvalue_(2)=1.0;
    } else {
      xvalue_(2)=3.0;
    }
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 * ---------------------------------------------------------------------
 *  step 8
 *  put lp rhs values
 * ---------------------------------------------------------------------
 *  set epsilon perturbation for right hand side of lp
 */
  epsb=0.0001;
  pfm1=5;
  pfm2=11;
  pf1=pfm1/2;
  pf2=pfm2/2;
/*
 */
  for(ilp=1; ilp<=m; ilp++)  {
/*
 *  compute factor pf2 for epsilon perturbation
 */
    pf1=pf1+1;
    if (pf1>pfm1) {
      pf1=2;
    }
    pf2=pf2+pf1;
    if (pf2>pfm2) {
      pf2=pf2-pfm2;
    }
/*
 */
    strcpy(xcomnd,"PUT RHS");
    xpoint_(1)=ilp;
    xvalue_(1)=2.0+epsb*(double)pf2;
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 * ---------------------------------------------------------------------
 *  step 9
 *  put basis by declaring the lp slack variables to be basic
 * ---------------------------------------------------------------------
 */
  for(ilp=1; ilp<=m; ilp++)  {
    strcpy(xcomnd,"PUT BAS");
    xpoint_(1)=n1+ilp;
    xpoint_(2)=ilp;
    lpexec(xcomnd,xpoint,xvalue);
  }
/*
 * ---------------------------------------------------------------------
 *  step 10
 *  put nonbasis bounds using cifre of layer 1
 * ---------------------------------------------------------------------
 */
  jlp=0;
  for(j=1; j<=ncols; j++)  {
    if (cl_(j,1,2)==1) {
      jlp=jlp+1;
      if (cifre_(j)!=0) {
/*
 *  j is free
 *  put nonbasis by setting lp variable jlp to upper bound
 */
        strcpy(xcomnd,"PUT NBS");
        xpoint_(1)=jlp;
        xpoint_(2)=-1;
        lpexec(xcomnd,xpoint,xvalue);
      } else {
/*
 *  j is fixed
 *  put nonbasis by setting lp variable jlp to lower bound
 */
        strcpy(xcomnd,"PUT NBS");
        xpoint_(1)=jlp;
        xpoint_(2)=0;
        lpexec(xcomnd,xpoint,xvalue);
      }
    }
  }
/*
 * ---------------------------------------------------------------------
 *  step 11
 *  factor basis
 * ---------------------------------------------------------------------
 */
  strcpy(xcomnd,"FAC BAS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 * ---------------------------------------------------------------------
 *  step 12
 *  solve ip
 * ---------------------------------------------------------------------
 *  define lower bound on the objective function value
 *  currently known bound is n1 - bdfxbl(q)
 */
  xvalue_(1)=n1-bdfxbl_(q);
  strcpy(xcomnd,"SOL IP ");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  check if fewer fixed variables have been found. xpoint(1) behaves
 *  like the succss variable
 */
  if (xpoint_(1)==0) {
/*
 *  did not find a better solution. hence skip rest of subroutine
 */
    bdfxvr=bdfxbl_(q);
    return;
  }
/*
 *  no step 13
 * ---------------------------------------------------------------------
 *  step 14
 *  get the ip solution
 *  interpretation of lp variables:
 *     xj = 0: logic column j must be fixed
 *     xj = 1: logic column j is in 2sat subproblem
 *     initialize bdfxvr = number of fixed variables
 * ---------------------------------------------------------------------
 */
  bdfxvr=0;
  jlp=0;
  for(j=1; j<=ncols; j++)  {
    if (cl_(j,1,2)==1) {
      jlp=jlp+1;
      strcpy(xcomnd,"GET SOL");
      xpoint_(1)=jlp;
      lpexec(xcomnd,xpoint,xvalue);
      xj=xvalue_(1)+0.1;
      if (xj==0) {
/*
 *  logic column j must be fixed
 */
        cl_(j,2,2)=1;
        bdfxvr=bdfxvr+1;
      }
    }
  }
  if (bdfxvr==bdfxbl_(q)) {
/*
 *  programming error since solution by ip is not better
 */
    error(" opt2st ","    1404");
  }
/*
 *  no step 15 - 19
 * ---------------------------------------------------------------------
 *  step 20
 *  create output problem in layer 1
 * ---------------------------------------------------------------------
 *  update layer 1 problem according to layer 2 information of
 *  cl_(.,2,2) for fixing
 */
  for(j=1; j<=ncols; j++)  {
    if ((cifix_(j)!=0)&&
        (cl_(j,2,2)==0)) {
      mcfxfr(j);
    } else {
      if ((cifix_(j)==0)&&
          (cl_(j,2,2)!=0)) {
        mcfrfx(j);
      }
    }
  }
/*
 * ---------------------------------------------------------------------
 *  step 21
 *  check correctness of solution
 * ---------------------------------------------------------------------
 */
  for(i=1; i<=nrows; i++)  {
    if (rnfre_(i)>=3) {
      error(" opt2st ","    2102");
    }
  }
  return;
}
/*  last record of compalg.c****** */
