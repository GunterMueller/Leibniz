/*
 *  local strings and arrays
 */
  static char ucomnd[64+1];
  static char pname[128+1];
  static char pstate[1+1];
  static char ptype[4+1];
  static long pvalue[8];
  static short perror[2];
/*
 *  substrings of ptype
 */
  static char ptype1[1+1];
  static char ptype2[2+1];
  static char ptype3[3+1];
