/*  first record of mktrscode.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/*
 */
/*
 * *******************************************************
 *  subroutine mktrsprocfil
 * 
 *       makes files for transfer process
 *       from user to leibniz and vice versa
 * 
 * *******************************************************
 * 
 */
void mktrsprocfil() {
/*
 */
  void mktrsdefsexts();
  void mktrscode();
  void mktrsprob();
/*
 *  open transfer files defs, exts, code, <problem>.trs
 */
  trsdefsfil = fopen(trsdefsfil_name, "w");
  if (trsdefsfil == NULL) {
    printf(
     "\nCannot open error file %s. Stop\n",trsdefsfil_name);
    lbccexit(1);
  }
  trsextsfil = fopen(trsextsfil_name, "w");
  if (trsextsfil == NULL) {
    printf(
     "\nCannot open error file %s. Stop\n",trsextsfil_name);
    lbccexit(1);
  }
  trscodefil = fopen(trscodefil_name, "w");    
  if (trscodefil == NULL) {
    printf(
     "\nCannot open error file %s. Stop\n",trscodefil_name);
    lbccexit(1);
  }
  trsprobfil = fopen(trsprobfil_name, "w");    
  if (trsprobfil == NULL) {
    printf(
     "\nCannot open error file %s. Stop\n",trsprobfil_name);
    lbccexit(1);
  }
/*
 *  make defs and exts files
 */
  mktrsdefsexts();
/*
 *  make code file
 */
  mktrscode();
/*
 *  make problem file
 */
  mktrsprob();
/*
 *  close transfer files defs, exts, code, <problem>.trs
 */
  fclose(trsdefsfil);
  fclose(trsextsfil);
  fclose(trscodefil);    
  fclose(trsprobfil);    
}
/*
 * *******************************************************
 *  subroutine mktrsdefsexts
 * 
 *       makes defs and exts files for transfer process
 * 
 * *******************************************************
 * 
 */
void mktrsdefsexts() {
/*
 */
  static long i,j,k,len,m,n1,n2;
  static char msgstr[256+1];
/*
 */
  void printdefsexts();
/*
 *  initialize msgstr
 */
  msgstr_(256+1) = '\0';
/*
 *  first record of files
 */
  fprintf(trsdefsfil,
    "/*  first record of %s***** */\n",trsdefsfil_nopa);
  fprintf(trsextsfil,
    "/*  first record of %s***** */\n",trsextsfil_nopa);
/*
 *  elements of universe (= union of all sets)
 */
  strcpy(msgstr,
    "/*\n *  element names and equivalent integers\n */\n");
  printdefsexts(msgstr);
  for (i=1;i<=nelts;i++) {
    sprintf(msgstr,
      "#define %s  %ld\n",&eltnam_(1,i),i);
    printdefsexts(msgstr);
  }
/*
 *  index limits of predicates
 */
   strcpy(msgstr,
     "/*\n *  index limits of predicates\n */\n");
  printdefsexts(msgstr);
/*
 *  j = predicate index
 *  k-th argument of predicate
 */
  for (j=1;j<=nprds;j++) {
    for (k=1;k<=prdset_(3,j);k++) {
/*
 *  m = index of set for k-th argument of predicate
 *  n1= min element index for set m
 *  n2= max element index for set m
 */
      m = prdset_(k,j);
      n1 = setdat_(eltmax+2,m);
      n2 = setdat_(eltmax+3,m);
/*
 *  definition of element limits and quantity
 */
      sprintf(msgstr,"#define min_%ld_%s  %ld\n",
              k,&prdnam_(1,j),n1);
      printdefsexts(msgstr);
      sprintf(msgstr,"#define max_%ld_%s  %ld\n",
              k,&prdnam_(1,j),n2);
      printdefsexts(msgstr);
      sprintf(msgstr,"#define qty_%ld_%s  %ld\n",
              k,&prdnam_(1,j),n2-n1+1);
      printdefsexts(msgstr);
    }
  }
/*
 *  predicate use with parentheses
 */
  strcpy(msgstr,
    "/*\n *  predicate use with parentheses\n */\n");
  printdefsexts(msgstr);
  for (j=1;j<=nprds;j++) {
    if (prdset_(3,j)==1) {
      sprintf(msgstr,"#define %s(i)  %s_[(i)-min_1_%s]\n",
              &prdnam_(1,j),&prdnam_(1,j),
              &prdnam_(1,j));
    } else if (prdset_(3,j)==2) {
      sprintf(msgstr,"#define %s(i,j)"
                     "  %s_[(i)-min_1_%s][(j)-min_2_%s]\n",
              &prdnam_(1,j),&prdnam_(1,j),
              &prdnam_(1,j),&prdnam_(1,j));
    } else {
      error("mktrsdefsexts","502");
    }
    printdefsexts(msgstr);
  }
/*
 *  allocation of predicates
 */
  strcpy(msgstr,
    "/*\n *  allocation for predicates\n */\n");
  fprintf(trsdefsfil,"%s",msgstr);
  strcpy(msgstr,
    "/*\n *  extern definitions of predicates\n */\n");
  fprintf(trsextsfil,"%s",msgstr);

  for (j=1;j<=nprds;j++) {
    if (prdset_(3,j)==1) {
      sprintf(msgstr,"long %s_[qty_1_%s];\n",
              &prdnam_(1,j),&prdnam_(1,j));
    } else if (prdset_(3,j)==2) {
        sprintf(msgstr,"long %s_[qty_1_%s][qty_2_%s];\n",
              &prdnam_(1,j),&prdnam_(1,j),
              &prdnam_(1,j));
    } else {
      error("mktrsdefsexts","602");
    }
    fprintf(trsdefsfil,"%s",msgstr);
    fprintf(trsextsfil,"extern %s",msgstr);
  }
/*
 *  propositional variables
 */
  strcpy(msgstr,
    "/*\n *  propositional variables\n */\n");
  printdefsexts(msgstr);
  for (j=1;j<=ncnfv;j++) {
/*
 *  check name in cnfvar for '*' in position 1 or any '('
 *  interpretation:
 *  '*' variable was introduced by compiler
 *      and hence is not accessible to user
 *  '(' variable is a predicate instance
 */
    if (cnfvar_(1,j)=='*') {
      goto zz705;
    }
    for (k=1;k<=strlen(&cnfvar_(1,j));k++) {
      if (cnfvar_(k,j)=='(') {
        goto zz705;
      } 
    }
/*
 *  variable is a user-defined propositional variable
 */
    fprintf(trsdefsfil,"long %s;\n",&cnfvar_(1,j));
    fprintf(trsextsfil,"extern long %s;\n",&cnfvar_(1,j));
    zz705:;    
  }
/*
 *  sts_elt (= status_element) procedure
 *
 *  determine max length of element names
 */
  len = -1;
  for (i=1;i<=nelts;i++) {
    m = strlen(&eltnam_(1,i));
    len = max(len,m);
  }
/*
 *  begin sts_elt
 */
  fprintf(trsdefsfil,"%s%s%s%s%s%s%s%s%s%s%s%s",
    "/*\n",
    " *  procedure status_element\n",
    " */\n",
    "void sts_elt(char *uname,char *ustate,char *utype,\n",
    "             long *uvalue,short *uerror) {\n",
    "\n",
    "  void trserrmsg();\n",
    "  void disprm();\n",
    "\n",
    "  static long flg=0, nes;\n",
    "  long i;\n",
    "  char ucomnd[64+1];\n");
  fprintf(trsdefsfil,
    "  static char tenm[%ld][%ld];\n",max(nelts,1),max(len+1,1));
  fprintf(trsdefsfil,"%s%s%s%s%s%s",
    "\n",
    "  strcpy(ucomnd,\"sts_elt\");\n",
    "/*\n",
    " *  initialize list of element names\n",
    " */\n",
    "  if (flg==0) {\n"); 
  fprintf(trsdefsfil,
    "    nes = %ld;\n",nelts);
  for (i=1;i<=nelts;i++) {
    fprintf(trsdefsfil,
    "    strcpy(&tenm[%ld-1][0],\"%s\");\n",i,&eltnam_(1,i));
  }
  fprintf(trsdefsfil,"%s%s",
    "    flg = 1;\n",
    "  }\n");
  fprintf(trsdefsfil,"%s%s%s",
    "/*\n",
    " *  store total number of elements in value[2]\n",
    " */\n");
  fprintf(trsdefsfil,
    "  uvalue[2] = %ld;\n",nelts);
  fprintf(trsdefsfil,"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s",
    "  if (uvalue[0] < 0) {\n",
    "    uerror[0] = 0;\n",
    "    return;\n",
    "  }\n",
    "/*\n",
    " *  know that uvalue[0] >= 0\n",
    " */\n",
    "  if (nes==0) {\n",
    "/*\n",
    " *  error, no elements specified in .log file\n",
    " */\n",
    "    uerror[0] = 3;\n",
    "    trserrmsg(2030);\n",
    "    disprm(ucomnd,uname,ustate,utype,uvalue,uerror);\n",
    "    return;\n",
    "  }\n");
  fprintf(trsdefsfil,"%s%s%s%s%s%s%s%s%s%s%s%s",
    "  if (uvalue[0]==0) {\n",
    "/*\n",
    " *  find index for given element name\n",
    " */\n",
    "    uname[128] = '\\0';\n",
    "    for (i=1;i<=nes;i++) {\n",
    "      if (strcmp(uname,&tenm[i-1][0])==0) {\n",
    "        uvalue[1] = i;\n",
    "        uerror[0] = 0;\n",
    "        return;\n",
    "      }\n",
    "    }\n");
  fprintf(trsdefsfil,"%s%s%s%s%s%s%s%s%s%s%s%s",
    "/*\n",
    " *  uname string is not in element name list\n",
    " */\n",
    "    uerror[0] = 2;\n",
    "    trserrmsg(1450);\n",
    "    disprm(ucomnd,uname,ustate,utype,uvalue,uerror);\n",
    "    return;\n",
    "  } else {\n",
    "/*\n",
    " *  find element name for given index\n",
    " *  recall that uvalue[0] >= 0\n",
    " */\n");
  fprintf(trsdefsfil,"%s%s%s%s%s%s%s%s%s%s%s%s",
    "    if (uvalue[0] > nes) {\n",
    "      uerror[0] = 2;\n",
    "      trserrmsg(1460);\n",
    "      disprm(ucomnd,uname,ustate,utype,uvalue,uerror);\n",
    "      return; \n",    
    "    }\n",
    "    strcpy(uname,&tenm[uvalue[0]-1][0]);\n",
    "    uvalue[1] = uvalue[0];\n",
    "    uerror[0] = 0;\n",
    "    return;\n",
    "  }\n",
    "}\n");
/*
 *  last record of files
 */
  fprintf(trsdefsfil,
    "/*  last record of %s***** */\n",trsdefsfil_nopa);
  fprintf(trsextsfil,
    "/*  last record of %s***** */\n",trsextsfil_nopa); 
}
/*
 * *******************************************************
 *  subroutine mktrscode
 * 
 *       makes code file for transfer process
 * 
 * *******************************************************
 * 
 */
void mktrscode() {
/*
 *  first record of file
 */
  fprintf(trscodefil,
    "/*  first record of %s***** */\n",trscodefil_nopa);
/*
 *  begin code for leibniztransfer()
 */
  fprintf(trscodefil,"%s%s%s%s",
    "/*\n",
    " *  transfers variable values from Leibniz to\n",
    " *  user program and vice versa\n",
    " */\n");
  fprintf(trscodefil,
    "#include<string.h>\n");
  fprintf(trscodefil,
    "#include \"%s\"\n", trsdefsfil_nopa);
  fprintf(trscodefil,"%s%s%s%s%s%s%s",
    "void leibniztransfer(char *move,char *problemname,\n",
    "   long *trsvar,long *errvalt,\n",
    "   char *ucomnd,char *uname,char *ustate,\n",
    "   char *utype,long *uvalue,short *uerror) {\n",
    "  void trserrmsg();\n",
    "  void error();\n",
    "  void disprm();\n");
  fprintf(trscodefil, 
    "#include \"%s\"\n",trsprobfil_nopa);
  fprintf(trscodefil,"%s%s%s%s%s%s%s%s%s%s%s%s%s",
    "/*\n",
    " *  The user may insert here #include statements\n",
    " *  of additional .trs files.\n",
    " *  All .log files producing such .trs files\n",
    " *  must have the same sets, predicates, and variables.\n",
    " *  At least one of the .log files must be compiled\n",
    " *  with the option\n",
    " *   'keep all variables even if not used in any fact'\n",
    " *  The leibnizdefs.h file of that compilation must\n",
    " *  be used for inclusion here (in leibniztrans.c).\n",
    " *  The corresponding leibnizexts.h must be included\n",
    " *  in the user code.\n",
    " */\n");
  fprintf(trscodefil,"%s%s%s%s",
    "  uerror[0]=3;\n",
    "  trserrmsg(2010);\n",
    "  disprm(ucomnd,uname,ustate,utype,uvalue,uerror);\n",
    "  return;\n");
  fprintf(trscodefil,
    "}\n");
/*
 *  last record of file
 */
  fprintf(trscodefil,
    "/*  last record of %s***** */\n",trscodefil_nopa);
}
/*
 * *******************************************************
 *  subroutine mktrsprob
 * 
 *       makes prob file for transfer process
 * 
 * *******************************************************
 * 
 */
void mktrsprob() {
/*
 */
  long j;
/*
 *  first record of file
 */
  fprintf(trsprobfil,
    "/*  first record of %s***** */\n",trsprobfil_nopa);
  fprintf(trsprobfil,"%s%s%s",
    "/*\n",
    " *  transfers variable values from trsvar to\n",
    " *  user program and vice versa\n");
  fprintf(trsprobfil,
    " *  for the logic problem %s\n",prbnam);
  fprintf(trsprobfil,
    " */\n"); 
  fprintf(trsprobfil,
    "  if (strcmp(problemname,\"%s\")==0) {\n", 
        prbnam);
  fprintf(trsprobfil,"%s%s%s%s",
    "    if (strcmp(move,\"trsvartouser\")==0) {\n",
    "/*\n",
    " *  transfer from trsvar to user\n",
    " */\n");
  for (j=1;j<=ncols;j++) {
    if (colnam_(1,j)!='*') {
      fprintf(trsprobfil,
    "      %s = trsvar[%ld];\n",&colnam_(1,j),j-1);        
    }
  }
  fprintf(trsprobfil,"%s%s%s%s%s",
    "      return;\n",
    "    } else if (strcmp(move,\"usertotrsvar\")==0) {\n",
    "/*\n",
    " *  transfer from user to trsvar\n",
    " */\n");
  for (j=1;j<=ncols;j++) {
    if (colnam_(1,j)!='*') {
      fprintf(trsprobfil,
    "      trsvar[%ld] = %s;\n",j-1,&colnam_(1,j));        
    }
  }
  fprintf(trsprobfil,"%s%s",
    "      return;\n",
    "    } else {\n");
  fprintf(trsprobfil,
    "      error(\"%s\",\"102\");\n",trsprobfil_nopa);
  fprintf(trsprobfil,"%s%s",    
    "    }\n",
    "  }\n");
/*
 *  last record of file
 */
  fprintf(trsprobfil,
    "/*  last record of %s***** */\n",trsprobfil_nopa);  
}
/*
 * *******************************************************
 *  subroutine printdefsexts
 * 
 *       writes msgstr into defs and exts files of
 *       transfer process
 * 
 * *******************************************************
 * 
 */
void printdefsexts(char *msgstr) {
/*
 */
  fprintf(trsdefsfil,"%s",msgstr);
  fprintf(trsextsfil,"%s",msgstr);
  return;
}
