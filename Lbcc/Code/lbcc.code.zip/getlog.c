/*  first record of getlog.c***** */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/* ************************************* *
 * module for getting log file
 *
 * routines:
 *  getlog        process log file
 *  openlogfil    opens log file specified by INCLUDE statement
 *  nextinputfil  checks for INCLUDE statement in tmpstr and
 *                processes that case
 *  readlogfil    reads one record from log file  
 * ************************************* *
 *
 * ************************************* */
void getlog(long *errt) {
/*
 *  convert log file into cnf formulation
 */
  void applyq();
  void chknam();
  void cnfout();
  void extcmp();
  void fctcls();
  void initds();
  void inperr();
  void prsfct();
  void prsprd();
  void prsset();
  void prsvar();
  int readlogfil();
  void scrwrt();
  void varout();
/*
 */
  long clsnum,l,r,err;
  char msgstr[128+1];
/*
 */
  err = *errt;
/*
 * initialization
 */
  initds();
/*
 *  read input line by line, parsing each line as we go
 */
  zz50:;
  if (readlogfil()==0) {
    goto zz100;  
  }
  l = 0;
  r = 0;
/*
 *  get next component of current record
 */
  extcmp(tmpstr,&l,&r);
/*
 * ----------------------------------
 *  state q100 is MINIMIZE or SATSIFY
 * ----------------------------------
 */  
  zz100:;
  if (strcmp(state,"Q100")==0) {
/*
 *  keyword MINIMIZE or SATSIFY expected
 */
    if (lstrncmp(&tmpstr_(l),"MINIMIZE",r-l+1)==0) {
      cstflg = 1;
    } else if (lstrncmp(&tmpstr_(l),"SATISFY",r-l+1)==0) {
      cstflg = 0;
    } else {
      inperr(&fatal);
      strcpy(msgstr," LBCC2010: MINIMIZE or SATISFY expected");
      scrwrt("+W",msgstr);
      goto zz100;
    }
    strcpy(state,"Q200");
    goto zz50;    
/*
 * ----------------------------------
 *  state q200 is problem name
 * ----------------------------------
 */
  } else if (strcmp(state,"Q200")==0) {
    strncpy(trprbnam,&tmpstr_(l),r-l+1);
    trprbnam_(r-l+2) = '\0';
    chknam(trprbnam,&err,"L");
/*
 *  no action needed if error found
 */
    strcpy(state,"Q300");
    goto zz50;
/*
 * ----------------------------------
 *  state q300 determines next state
 * ----------------------------------
 */
  } else if (strcmp(state,"Q300")==0) {
    if (lstrncmp(&tmpstr_(l),"SETS",r-l+1)==0) {
      strcpy(state,"Q1000");
    } else if (lstrncmp(&tmpstr_(l),"PREDICATES",r-l+1)==0) {
      strcpy(state,"Q2000");
    } else if (lstrncmp(&tmpstr_(l),"VARIABLES",r-l+1)==0) {
      strcpy(state,"Q3000");
    } else if (lstrncmp(&tmpstr_(l),"FACTS",r-l+1)==0) {
      strcpy(state,"Q4000");
    } else {
      inperr(&fatal);
      strcpy(msgstr,
      " LBCC2020: Keyword missing: SETS,"
      " PREDICATES, VARIABLES, FACTS");
      scrwrt("+W",msgstr);
      goto zz100;
    } 
  } else if (strcmp(state,"QEND")==0) {
    goto zz5000;
  } else if (strcmp(state,"Q1000")==0) {
    prsset();
  } else if (strcmp(state,"Q2000")==0) {
    prsprd();
  } else if (strcmp(state,"Q3000")==0) {
    prsvar();
  } else if (strcmp(state,"Q4000")==0) {
    if (toterr > 0 ) {
      printf(
      "\n*** FACTS not processed due to previous errors ***\n");
      fprintf(errfil,
      "\n*** FACTS not processed due to previous errors ***\n");
      goto zz5000;
    }
    newvar = 0;
    clsnum = 0;
/*
 * ----------------------------------
 *  process one fact statement at a time
 *  parse, convert to clauses, output as cnf
 * ----------------------------------
 */
    zz200:;
    prsfct();
/*
 *  if state is qend, then either a fatal error was 
 *  encountered in prsfct, or all fact statements have
 *  been parsed and endata was encountered. state qend
 *  is determined in prsfct
 */
    if (strcmp(state,"QEND")==0) {
/*
 *  if errors encountered do not create cnf formulation
 */
      if (toterr == 0) {
/*
 *  write out the cnf variables
 */
        varout();
      }
      goto zz100;
    }
/*
 *  if no errors encountered, create cnf clauses 
 */
    if (toterr == 0) {
/*
 * ----------------------------------
 *  have fact in internal representation (and/or form)
 *  convert fact to equivalent clauses
 * ----------------------------------
 */   
      fctcls();
/*
 * ----------------------------------
 *  convert clauses to final cnf form
 * ----------------------------------
 */
      clsnum++;
      if (nqnt > 0) {
/*
 *  quantification case
 */
        applyq(&clsnum);
      } else {
/*
 *  no quantification case
 */
        cnfout(&clsnum);
      }
    }
    goto zz200;
  } else {
/*
 *  error, have unrecognized state
 */
    printf(
      "\n Unrecognized state = %s",state);
    fprintf(errfil,
      "\n Unrecognized state = %s",state);
    error("getlog","222");
  }
  goto zz100;
/*
 * ----------------------------------
 *  translation complete
 * ----------------------------------
 */
  zz5000:;
  if (scrflg == 1) {
    printf("\n**********************************\n");
    printf("Total Warnings = %ld\n",totwrn);
    printf("Total Errors   = %ld\n",toterr);
   }
  fprintf(errfil,"\n**********************************\n");
  fprintf(errfil,"Total Warnings = %ld\n",totwrn);
  fprintf(errfil,"Total Errors   = %ld\n",toterr);
  if (toterr == 0) {
    if (scrflg == 1) {
      printf("Processing of .log file completed\n");
    }
    fprintf(errfil,"Processing of .log file completed\n");
  }
  if (scrflg == 1) {
    printf("**********************************\n");
  }
  fprintf(errfil,"**********************************\n");
  err = 0;
  if (totwrn > 0) {
    err = 1;
  }
  if (toterr > 0) {
    err = 2;
  }
  *errt = err;
  return; 
}
/*eject*/
/*
 * *************************************************
 *  subroutine openlogfil
 * 
 *  opens log file specified by INCLUDE statement
 * *************************************************
 */
void openlogfil(char *newfilnam) {
/*
 */
  long n;
  static char msgstr[128+1];
/*
 */
  void inperr();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  msgstr_(128+1) = '\0';
/*
 *  retain line count of currently read log input file
 */
  logcline_(nlogfil) = cline;
/*
 *  check if too many opened files
 */
  if (nlogfil+1 > logfilmax) {
/*
 *  fatal error. max number of input files that can be 
 *  opened is exceeded
 */
    n = logfilmax;
    inperr(&fatal);
    sprintf(msgstr,
      " LBCC2240: Number of input files"
      " exceeds maximum allowed (= %ld)",n);
    scrwrt("+W",msgstr);
    lbccexit(1);
  }
/*
 *  initialize directory path using path of logfilmax+1 position
 *  append newfilnam
 *  open new log input file
 *  start line count at 0 for this file
 */
  strcpy(&logfil_name_(1,nlogfil+1),&logfil_name_(1,logfilmax+1));
  strcat(&logfil_name_(1,nlogfil+1),newfilnam);
/*
 *  check that file is not already open
 */
  for (n=1;n<=nlogfil;n++) {
    if (strcmp(&logfil_name_(1,n),
               &logfil_name_(1,nlogfil+1))==0) {
      inperr(&fatal);
      sprintf(msgstr,
        " LBCC2250: Conflicting INCLUDE statements"
        " for\n %s\n",
        &logfil_name_(1,nlogfil+1));
      scrwrt("+W",msgstr);
      lbccexit(1);
    }
  }
/*
 *  file can be opened
 */
  logfil_(nlogfil+1) = fopen(&logfil_name_(1,nlogfil+1),"r");
  if (logfil_(nlogfil+1)==NULL) {
/*
 *  fatal error. cannot open specified log input file
 */
    inperr(&fatal);
    sprintf(msgstr,
      " LBCC2220: Cannot open file %s\n"
      " specified in INCLUDE statement",
      &logfil_name_(1,nlogfil+1));
    scrwrt("+W",msgstr);
    lbccexit(1);
  }
  nlogfil++;
  cline = 0;    
  return;
}
/*eject*/
/*
 * *************************************************
 *  subroutine nextinputfil
 * 
 *  checks for INCLUDE statement in tmpstr and
 *  processes that case, if present
 * *************************************************
 */
int nextinputfil() {
/*
 */
  long l,r;
  char msgstr[128+1];
/*
 */
  void extcmp();
  void inperr();
  void openlogfil();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  msgstr_(128+1) = '\0';
/*
 *  check for INCLUDE
 */
  l=0;
  r=0;
  extcmp(tmpstr,&l,&r);
  if (lstrncmp(&tmpstr_(l),"INCLUDE",r-l+1)!=0) {
    return(0);
  }
/*
 *  have INCLUDE statement
 *  extract file name
 */
  extcmp(tmpstr,&l,&r);
  if (lstrncmp(&tmpstr_(l),"$",r-l+1)==0) {
/*
 *  missing file name
 */
    inperr(&fatal);
    strcpy(msgstr,
      " LBCC2210: INCLUDE statement has file name missing");
    scrwrt("+W",msgstr);
    lbccexit(1);
  }
  tmpstr_(r+1) = '\0';
  openlogfil(&tmpstr_(l));
  tmpstr_(r+1) = '$';
  return(1);
}
/*eject*/
/*
 * *************************************************
 *  subroutine readlogfil
 * 
 *  reads one record from file &logfil_(nlogfil) into tmpstr
 *  and fills remaining entries of record with blanks
 *  opens log input files as directed by INCLUDE statements
 *  closes input files as needed
 *  skips blanks records
 *  if conditpflg = 0 or 1: outputs record into condiptfil
 *                          as directed by begcondipword and
 *                          endcondiptword; see getparm.c file
 *                          for details of rules
 *  
 *  returns: 0 if no record read
 *           1 if record read
 * *************************************************
 */
int readlogfil() {
/*
 */
  static long l,nz,r;
  static char msgstr[128+1];
/*
 */
  void compct();
  void extcmp();
  void inperr();
  int  nextinputfil();
  void convtloword();
  void scrwrt();
/*
 */
  msgstr_(128+1) = '\0';
/*
 */
  zz50:;
  if (fgets(tmpstr,126,logfil_(nlogfil))==0) {
    if (nlogfil > 1) {
/*
 *  have finished reading a log input file 
 *  that is not at lowest level
 *  close that file and revert to preceding log input file
 */
      fclose(logfil_(nlogfil));
      nlogfil--;
      cline = logcline_(nlogfil);
      goto zz50;      
    } else {
/*
 *  unexpected end-of-file in first log input file
 */
      inperr(&fatal);
      strcpy(msgstr,
        " LBCC2030: Unexpected end of source");
      scrwrt("+W",msgstr);
      return(0);
    }
  }
  cline++;
/*
 *  check length of input record
 *  due to the fgets statement, the length is at most 126
 *  characters. A length up to 125 is acceptable.
 */  
  nz = strlen(tmpstr);  
  if (nz==126) {
    inperr(&fatal);
    strcpy(msgstr,
    " LBCC2230: Input record too long");
    scrwrt("+W",msgstr);
    return(0);
  } else if (nz > 126) {
/*
 *  error, fgets must have limited length to 126
 */
     error("readlogfil","202");
  }
/*
 *  store tmpstr in inputrecord
 */
  strcpy(inputrecord,tmpstr); 
/*
 *  squeeze out blanks and insert separators
 */
  compct(tmpstr);
  if (tmpstr_(1)=='$') {
/*
 *  blank line encountered
 */
    goto zz50;
  }
/*
 *  convert all lower case reserved words in tmpstr
 *  to upper case
 */
  l = 0;
  r = 0;
/*
 *  get next component of tmpstr
 */
  zz30:;
  extcmp(tmpstr,&l,&r);
/*
 *  check for termination of string
 */
  if (lstrncmp(&tmpstr_(l),"$",r-l+1)==0) {
    goto zz40;
  }
/*
 *  if this is a lower-case reserved word, convert
 *  it to upper case
 */
  convtloword(tmpstr,&l,&r);
  goto zz30;  
/*
 */
  zz40:; 
/* 
 *  if this is an INCLUDE statement, open specified file
 *  and update line counts 
 */
  if (nextinputfil() == 1) {
    goto zz50;
  }
/*
 *  if condiptflg = 0/1 and keyword conditions are satisfied,
 *  output inputrecord into condiptfil
 *  see getparm.c for details of rules
 */
  l = 0;
  r = 0;
  extcmp(tmpstr,&l,&r);
  if (condiptflg == 0) {
    strcpy(auxmsg,begcondiptword);
    if (lstrncmp(&tmpstr_(l),auxmsg,r-l+1)==0) {
      /* have begin condensed input keyword */
      condiptflg = 1;
    }
  }
  if (condiptflg == 1) {
    strcpy(auxmsg,endcondiptword);
    if (lstrncmp(&tmpstr_(l),auxmsg,r-l+1)==0) {
      /* have end condensed input keyword */
      condiptflg = 2;
    }    
  }
  if (condiptflg == 1) {
    fprintf(condiptfil,"%s",inputrecord);
  }

  return(1);

}
/*  last record of getlog.c****** */
