/*  first record of exdyn.c***** */
#include<stdio.h>
#include<stdlib.h>
#include"exparms.h"
#include"exdefs.h"
#include"exfdefs.h"
/* **********************************************************
 */
void exdyn_alloc() {
/*
 *  memory allocation
 *  caution: when adding or deleting allocations, also
 *           must change corresponding deallocations
 *  the following parameters must be defined
 *  and must satisfy the stated conditions
 *
 *    colmax >= 2
 *    rowmax >= 2
 *    anzmax >= 2
 *    blkmax >= 2
 *    prbmax >= 2
 *    stomax >= 2 
 *    laymax >= 7
 */
  void error();
/*
 *  reset allocation flag and
 *  check that no allocation exists
 */
  if (exalcflg==0) {
    exalcflg = 1;
  } else {
    error("exdyn_alloc","102");
  }
/*
 * check conditions on parameters
 */
  if (colmax < 2 ) {
    error("exdyn_alloc","202");
  }
  if (rowmax < 2 ) {
    error("exdyn_alloc","204");   
  }
  if (anzmax < 2 ) {
    error("exdyn_alloc","206");
  }
  if (blkmax < 2 ) {
    error("exdyn_alloc","208");
  }
  if (laymax < 7 ) {
    error("exdyn_alloc","212");
  }
  if (stomax < 2 ) {
    error("exdyn_alloc","214");
  }
  if (prbmax < 2 ) {
    error("exdyn_alloc","216");
  }
/*
 */
  if((pgrec  = (char  *) malloc((pgrmax+1) * sizeof(char  )))==NULL) goto zz100;
  if((pgalp  = (char  *) malloc((1+1) * sizeof(char  )))==NULL) goto zz100;
  if((xpoint = (long  *) malloc((8) * sizeof(long  )))==NULL) goto zz100;
  if((xvalue = (double*) malloc((8) * sizeof(double)))==NULL) goto zz100;
  if((xcomnd = (char  *) malloc((7+1) * sizeof(char  )))==NULL) goto zz100;
  if((clnam = (char  *) malloc((58+1) * (colmax) * (laymax) * sizeof(char  )))==NULL) goto zz100;
  if((rwnam =  (char  *) malloc((58+1) * (rowmax) * (laymax) * sizeof(char  )))==NULL) goto zz100;
  if((idxclx = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((trucsr = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((falcsr = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((rndzv  = (double*) malloc((casmax) * sizeof(double)))==NULL) goto zz100;
  if((deltaz = (double*) malloc((prcmax) * sizeof(double)))==NULL) goto zz100;
  if((xcl2lp = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((xlp2cl = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((xrw2lp = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((xlp2rw = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((lpstat = (long  *) malloc((colmax+2*rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((rndcl  = (long  *) malloc((prcmax) * sizeof(long  )))==NULL) goto zz100;
  if((rndcas = (long  *) malloc((prcmax) * (casmax) * sizeof(long  )))==NULL) goto zz100;
  if((rndfsb = (long  *) malloc((casmax) * sizeof(long  )))==NULL) goto zz100;
  if((nlurr  = (long  *) malloc((6) * sizeof(long  )))==NULL) goto zz100;
  if((ciacpr = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((lrrval = (double*) malloc((6) * sizeof(double)))==NULL) goto zz100;
  if((urrval = (double*) malloc((6) * sizeof(double)))==NULL) goto zz100;
  if((nxtrec = (long  *) malloc((stomax) * sizeof(long  )))==NULL) goto zz100;
  if((prbbeg = (long  *) malloc((prbmax) * sizeof(long  )))==NULL) goto zz100;
  if((prbend = (long  *) malloc((prbmax) * sizeof(long  )))==NULL) goto zz100;
  if((prbsiz = (long  *) malloc((prbmax) * sizeof(long  )))==NULL) goto zz100;
  if((storec = (char  *) malloc((pgrmax+1) * (stomax) * sizeof(char  )))==NULL) goto zz100;
  if((prbnam = (char  *) malloc((58+1) * (prbmax) * sizeof(char  )))==NULL) goto zz100;
  if((nbks   = (long  *) malloc((laymax) * sizeof(long  )))==NULL) goto zz100;
  if((nders  = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((ndrge  = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((nerge  = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((ndrgep = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((nergep = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((npairs = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((lcllim = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((ucllim = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((lrwlim = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((urwlim = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((nnzs =   (long  *) malloc((laymax) * sizeof(long  )))==NULL) goto zz100;
  if((ncls =   (long  *) malloc((laymax) * sizeof(long  )))==NULL) goto zz100;
  if((nrws =   (long  *) malloc((laymax) * sizeof(long  )))==NULL) goto zz100;
  if((twosat = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((twost =  (long  *) malloc((blkmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((fxcase = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((trcst = (long  *) malloc((colmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((flcst = (long  *) malloc((colmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((prmdat = (long  *) malloc((21) * (720) * sizeof(long  )))==NULL) goto zz100;
  if((prmlim = (long  *) malloc((6) * sizeof(long  )))==NULL) goto zz100;
  if((nprms  = (long  *) malloc((6) * sizeof(long  )))==NULL) goto zz100;
  if((csourc = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rsourc = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((csink  = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rsink  = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cnew   = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rnew   = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((ccut   = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rcut   = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cdis   = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rdis   = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((histdc = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((drange = (long  *) malloc((dermax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((ptdr   = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((nzdr   = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((pter   = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((nzer   = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((rg     = (long  *) malloc((dermax) * sizeof(long  )))==NULL) goto zz100;
  if((ptrg   = (long  *) malloc((rgemax) * sizeof(long  )))==NULL) goto zz100;
  if((nzrg   = (long  *) malloc((rgemax) * sizeof(long  )))==NULL) goto zz100;
  if((rgx    = (long  *) malloc((3*dermax) * sizeof(long  )))==NULL) goto zz100;
  if((ptrgx  = (long  *) malloc((3*rgemax) * sizeof(long  )))==NULL) goto zz100;
  if((nzrgx  = (long  *) malloc((3*rgemax) * sizeof(long  )))==NULL) goto zz100;
  if((lcost  = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((rgxlst = (long  *) malloc((2) * (rowmax+3*rgemax) * sizeof(long  )))==NULL) goto zz100;
  if((rgxusd = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((auxv1  = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((auxv2  = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((auxv3  = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((aux    = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((va     = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((vb     = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((vc     = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((ldr    = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((ler    = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((ldr1   = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((ler1   = (long  *) malloc((rgemax) * (blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((retsol = (long  *) malloc((colmax) * (lclmax) * sizeof(long  )))==NULL) goto zz100;
  if((bdfxbl = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((logrge = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((ablkct = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((attblk = (long  *) malloc((blkmax) * sizeof(long  )))==NULL) goto zz100;
  if((cl     = (long  *) malloc((colmax+2) * (lclmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((centry = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((clalli = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((clacti = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((clinai = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cxlfix = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cxlbnd = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cxlsol = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cxlinp = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cxlbegthm = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cxlthm = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((cxlpath = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rw     = (long  *) malloc((rowmax+2) * (lrwmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((rentry = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rwallj = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rwactj = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rwfixj = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rwfrej = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rwinaj = (long  *) malloc((colmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rnred  = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((rxlact = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rxleqz = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rxleq1 = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rxlcu1 = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rxleq2 = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rposj  = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((rxlrhs = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((ronej  = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((aonej  = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((rxlntz = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rxlinp = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((amc    = (long  *) malloc((anzmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((ptamc  = (long  *) malloc((colmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((nzamc  = (long  *) malloc((colmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((amr    = (long  *) malloc((anzmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((ptamr  = (long  *) malloc((rowmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((nzamr  = (long  *) malloc((rowmax) * (laymax) * sizeof(long  )))==NULL) goto zz100;
  if((ablkcl = (long  *) malloc((anzmax) * sizeof(long  )))==NULL) goto zz100;
  if((ptablc = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((nzablc = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((ablkrw = (long  *) malloc((anzmax) * sizeof(long  )))==NULL) goto zz100;
  if((ptablr = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((nzablr = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((amslcl = (long  *) malloc((anzmax) * sizeof(long  )))==NULL) goto zz100;
  if((ptamsc = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((nzamsc = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((amslrw = (long  *) malloc((anzmax) * sizeof(long  )))==NULL) goto zz100;
  if((ptamsr = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((nzamsr = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((rnared = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((bmslcl = (long  *) malloc((anzmax) * sizeof(long  )))==NULL) goto zz100;
  if((ptbmsc = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((nzbmsc = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((bmslrw = (long  *) malloc((anzmax) * sizeof(long  )))==NULL) goto zz100;
  if((ptbmsr = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((nzbmsr = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((rnbred = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((ribred = (long  *) malloc((rowmax) * sizeof(long  )))==NULL) goto zz100;
  if((rxlbw1 = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((rxlbwz = (long  *) malloc((rowmax+2) * sizeof(long  )))==NULL) goto zz100;
  if((bdvalu = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((bdcase = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((bdcons = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((bdsave = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((bdtemp = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((trsvar = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((pathcase = (long  *) malloc((colmax) * sizeof(long  )))==NULL) goto zz100;
  if((selcol = (long  *) malloc((selmax) * sizeof(long  )))==NULL) goto zz100;
  if((covtot = (long  *) malloc((covmax) * sizeof(long  )))==NULL) goto zz100;
  if((covmat = (long  *) malloc((scsmax) * (covmax) * sizeof(long  )))==NULL) goto zz100;
  if((selcas = (long  *) malloc((scsmax) * (selmax) * sizeof(long  )))==NULL) goto zz100;
  if((nstrow = (long  *) malloc((scsmax) * sizeof(long  )))==NULL) goto zz100;
  trucst = trcst;
  falcst = flcst;
  colnam = clnam;
  rownam = rwnam;
  erange = &drange_(1,1);
  gpod   = &drange_(1,1);
  gpoe   = &drange_(1,1);
  gpodp  = &drange_(1,1);
  gpoep  = &drange_(1,1);
  cnallp = &cl_(1,1,1);
  cnalln = &cl_(1,2,1);
  cnall  = &cl_(1,3,1);
  cnactp = &cl_(1,4,1);
  cnactn = &cl_(1,5,1);
  cnact  = &cl_(1,6,1);
  cninap = &cl_(1,7,1);
  cninan = &cl_(1,8,1);
  cnina  = &cl_(1,9,1);
  ciactr = &cl_(1,1,1);
  ciinar = &cl_(1,2,1);
  cifrer = &cl_(1,3,1);
  cifixr = &cl_(1,4,1);
  ciacgl = &cl_(1,5,1);
  idxgol = &cl_(1,6,1);
  idxgnm = &cl_(1,7,1);
  gcoeff = &cl_(1,8,1);
  primal = &cl_(1,9,1);
  ciact  = &cl_(1,10,1);
  ciina  = &cl_(1,11,1);
  cifre  = &cl_(1,12,1);
  cifix  = &cl_(1,13,1);
  solut1 = &cl_(1,14,1);
  solut2 = &cl_(1,15,1);
  solut3 = &cl_(1,16,1);
  solut4 = &cl_(1,17,1);
  solut5 = &cl_(1,18,1);
  scale  = &cl_(1,19,1);
  idxcol = &cl_(1,20,1);
  ciblk  = &cl_(1,21,1);
  dlclop = &cl_(1,22,1);
  cost   = &cl_(1,23,1);
  cvatf  = &cl_(1,24,1);
  inlsol = &cl_(1,25,1);
  rnallp = &rw_(1,1,1);
  rnalln = &rw_(1,2,1);
  rnall  = &rw_(1,3,1);
  rnactp = &rw_(1,4,1);
  rnactn = &rw_(1,5,1);
  rnact  = &rw_(1,6,1);
  rninap = &rw_(1,7,1);
  rninan = &rw_(1,8,1);
  rnina  = &rw_(1,9,1);
  rnfrep = &rw_(1,10,1);
  rnfren = &rw_(1,11,1);
  rnfre  = &rw_(1,12,1);
  rnfixp = &rw_(1,13,1);
  rnfixn = &rw_(1,14,1);
  rnfix  = &rw_(1,15,1);
  riactr = &rw_(1,1,1);
  riinar = &rw_(1,2,1);
  levelr = &rw_(1,3,1);
  dual   = &rw_(1,4,1);
  goalxq = &rw_(1,5,1);
  glocst = &rw_(1,6,1);
  ghicst = &rw_(1,7,1);
  goalus = &rw_(1,8,1);
  goalrq = &rw_(1,9,1);
  glflg  = &rw_(1,10,1);
  riact  = &rw_(1,16,1);
  riina  = &rw_(1,17,1);
  rhs1   = &rw_(1,18,1);
  rhs2   = &rw_(1,19,1);
  rhs3   = &rw_(1,20,1);
  rhs4   = &rw_(1,21,1);
  rhs5   = &rw_(1,22,1);
  idxrow = &rw_(1,23,1);
  riblk  = &rw_(1,24,1);
  dlrwop = &rw_(1,25,1);
  level  = &rw_(1,26,1);
  amatcl = &amc_(1,1);
  ptamac = &ptamc_(1,1);
  nzamac = &nzamc_(1,1);
  amatrw = &amr_(1,1);
  ptamar = &ptamr_(1,1);
  nzamar = &nzamr_(1,1);
  clpath = &cl_(1,14,1);
  claugm = &cl_(1,15,1);
  clstat = &cl_(1,16,1);
  clcutn = &cl_(1,17,1);
  cllabn = &cl_(1,18,1);
  rwpath = &rw_(1,18,1);
  rwaugm = &rw_(1,19,1);
  rwstat = &rw_(1,20,1);
  rwcutn = &rw_(1,21,1);
  rwlabn = &rw_(1,22,1);
  height = &cl_(1,14,1);
  curprm = &cl_(1,15,1);
  fnlprm = &cl_(1,16,1);
  tmpprm = &cl_(1,17,1);
  bstprm = &cl_(1,18,1);
  return;
  zz100:;
/*
 * insufficient memory available for allocation
 */
  printf(
   "Insufficient memory available for lbcc exdyn allocation\n");
  printf(
   "Must reduce problem size or increase memory\n");
  printf(
   "Stop\n");
  fprintf(errfil,
   "Insufficient memory available for lbcc exdyn allocation\n");
  fprintf(errfil,
   "Must reduce problem size or increase memory\n");
  fprintf(errfil,
   "Stop\n"); 
  exit(1); 
}
/* **********************************************************
 */
void exdyn_free() {
/*
 *  memory de-allocation
 */
  void error();
/*
 *  reset allocation flag and
 *  check that allocation exists
 */
  if (exalcflg==1) {
    exalcflg = 0;
  } else {
    error("exdyn_free","102");
  }
/*
 */
  free(pgrec  );
  free(pgalp  );
  free(xpoint );
  free(xvalue );
  free(xcomnd );
  free(clnam  );
  free(rwnam  );
  free(idxclx );
  free(trucsr );
  free(falcsr );
  free(rndzv  );
  free(deltaz );
  free(xcl2lp );
  free(xlp2cl );
  free(xrw2lp );
  free(xlp2rw );
  free(lpstat );
  free(rndcl  );
  free(rndcas );
  free(rndfsb );
  free(nlurr  );
  free(ciacpr );
  free(lrrval );
  free(urrval );
  free(nxtrec );
  free(prbbeg );
  free(prbend );
  free(prbsiz );
  free(storec );
  free(prbnam );
  free(nbks   );
  free(nders  );
  free(ndrge  );
  free(nerge  );
  free(ndrgep );
  free(nergep );
  free(npairs );
  free(lcllim );
  free(ucllim );
  free(lrwlim );
  free(urwlim );
  free(nnzs   );
  free(ncls   );
  free(nrws   );
  free(twosat );
  free(twost  );
  free(fxcase );
  free(trcst );
  free(flcst );
  free(prmdat );
  free(prmlim );
  free(nprms  );
  free(csourc );
  free(rsourc );
  free(csink  );
  free(rsink  );
  free(cnew   );
  free(rnew   );
  free(ccut   );
  free(rcut   );
  free(cdis   );
  free(rdis   );
  free(histdc );
  free(drange );
  free(ptdr   );
  free(nzdr   );
  free(pter   );
  free(nzer   );
  free(rg     );
  free(ptrg   );
  free(nzrg   );
  free(rgx    );
  free(ptrgx  );
  free(nzrgx  );
  free(lcost  );
  free(rgxlst );
  free(rgxusd );
  free(auxv1  );
  free(auxv2  );
  free(auxv3  );
  free(aux    );
  free(va     );
  free(vb     );
  free(vc     );
  free(ldr    );
  free(ler    );
  free(ldr1   );
  free(ler1   );
  free(retsol );
  free(bdfxbl );
  free(logrge );
  free(ablkct );
  free(attblk );
  free(cl     );
  free(centry );
  free(clalli );
  free(clacti );
  free(clinai );
  free(cxlfix );
  free(cxlbnd );
  free(cxlsol );
  free(cxlinp );
  free(cxlbegthm );
  free(cxlthm );
  free(cxlpath );
  free(rw     );
  free(rentry );
  free(rwallj );
  free(rwactj );
  free(rwfixj );
  free(rwfrej );
  free(rwinaj );
  free(rnred  );
  free(rxlact );
  free(rxleqz );
  free(rxleq1 );
  free(rxlcu1 );
  free(rxleq2 );
  free(rposj  );
  free(rxlrhs );
  free(ronej  );
  free(aonej  );
  free(rxlntz );
  free(rxlinp );
  free(amc    );
  free(ptamc  );
  free(nzamc  );
  free(amr    );
  free(ptamr  );
  free(nzamr  );
  free(ablkcl );
  free(ptablc );
  free(nzablc );
  free(ablkrw );
  free(ptablr );
  free(nzablr );
  free(amslcl );
  free(ptamsc );
  free(nzamsc );
  free(amslrw );
  free(ptamsr );
  free(nzamsr );
  free(rnared );
  free(bmslcl );
  free(ptbmsc );
  free(nzbmsc );
  free(bmslrw );
  free(ptbmsr );
  free(nzbmsr );
  free(rnbred );
  free(ribred );
  free(rxlbw1 );
  free(rxlbwz );
  free(bdvalu );
  free(bdcase );
  free(bdcons );
  free(bdsave );
  free(bdtemp );
  free(trsvar );
  free(pathcase );
  free(selcol );
  free(covtot );
  free(covmat );
  free(selcas );
  free(nstrow );
  return;
}
/*  last record of exdyn.c****** */
