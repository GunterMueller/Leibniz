/*  first record of prsopt.c***** */
#include<string.h>
#include<stdio.h>
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/*
 * ***************************************************
 *  subroutine prsopt(l,r,chk,err)
 * 
 *  purpose:  parse assigned variable value, delete
 *            option, and cost specification options.
 * 
 *   input:   l, r  : the left and right indices of the
 *                    current component in tmpstr.
 *            chk   : =0, do not enforce requirement
 *                        that options are given.
 *                    =1, generate error if options
 *                        are not given.
 *            err   : =1 if an error was encountered,
 *                    =0 otherwise.
 * 
 *  output:   the ascii cost values in truec and falsc;
 *             otherwise blank
 *             1 or 0 in dopt (delete option)
 *             1 in avopt if at  (assigned true option)
 *            -1 in avopt if af  (assigned false option);
 *            otherwise 0
 * 
 *  note:  calling routine should check for error
 *         on return.
 * 
 *  caution:  prsopt assumes the input string is in
 *            tmpstr.
 *            fatal errors will not terminate translation
 *            process when they return to calling routine.
 *            calling routine would require additional
 *            state qend in its state diagram.
 *            hence no fatal errors are presently used.
 * 
 * ******************************************************
 * 
 */
void prsopt(long *lt,long *rt,long *chkt,long *errt) {
/*
 */
  static long l,r,chk,err;
  static long tcflg,fcflg,minus;
  static long n;
  static char numstr[8+1];
  static char msgstr[128+1];
/*
 */
  void chknum();
  void extcmp();
  void inperr();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  l = *lt;
  r = *rt;
  chk = *chkt;
  err = *errt;
  numstr_(8+1) = '\0';
  msgstr_(128+1) = '\0';
/*
 *  initialize flags. 0 = item not encountered.
 *                    1 = item encountered.
 *                    2 = item encountered again, error.
 */
  tcflg=0;
  fcflg=0;
/*
 *  initialize error value to indicate no error
 */
  err=0;
/*
 *  initialize option variables
 */
  strcpy(truec ,"      ");
  strcpy(falsc ,"      ");
  dopt=0;
  avopt=0;
  zz60:;
  extcmp(tmpstr,&l,&r);
  zz70:;
/*
 * -------------------------------------
 *  state q5000 check if options present
 * -------------------------------------
 */
  if (strcmp(state ,"Q5000")==0) {
    if (chk==1) {
      if (lstrncmp(&tmpstr_(l),"$",r-l+1)==0) {
/*
 *  no options specified.
 */
        inperr(&nftl);
        strcpy(msgstr,
           " LBCC1150: Variable options intended; none given");
        scrwrt("+W",msgstr);
        err=1;
        *lt = l;
        *rt = r;
        *chkt = chk;
        *errt = err;
        return;
      }
    } else {
      if (lstrncmp(&tmpstr_(l),"$",r-l+1)==0) {
        *lt = l;
        *rt = r;
        *chkt = chk;
        *errt = err;
        return;
      }
    }
    strcpy(state ,"Q5010");
    goto zz70;
  }
/*
 * -------------------------------------
 *  state q5010 branches on encountered
 *              item.
 * -------------------------------------
 */
  if (strcmp(state ,"Q5010")==0) {
    if (lstrncmp(&tmpstr_(l),"$",r-l+1)==0) {
/*
 *  no more options specified
 */
      *lt = l;
      *rt = r;
      *chkt = chk;
      *errt = err;
      return;
    }
    if (lstrncmp(&tmpstr_(l),"DELETABLE",r-l+1)==0) {
      strcpy(state ,"Q5100");
      goto zz70;
    } else if ((lstrncmp(&tmpstr_(l),"ASSIGNTRUE",r-l+1)==0)||
        (lstrncmp(&tmpstr_(l),"ASSIGNFALSE",r-l+1)==0)) {
      strcpy(state ,"Q5200");
      goto zz70;
    } else if ((lstrncmp(&tmpstr_(l),"TRUECOST",r-l+1)==0)||
        (lstrncmp(&tmpstr_(l),"FALSECOST",r-l+1)==0)) {
      strcpy(state ,"Q5300");
      goto zz70;
    } else {
      inperr(&nftl);
      strncpy(auxmsg,&tmpstr_(l),r-l+1);
      auxmsg_(r-l+2) = '\0';
      sprintf(msgstr,
          " LBCC1170: Variable option keyword expected;"
          " got: %s",auxmsg);
      scrwrt("+W",msgstr);
      err=1;
      *lt = l;
      *rt = r;
      *chkt = chk;
      *errt = err;
      return;
    }
  }
/*
 * ------------------------------------
 *  state q5100 handles delete option
 * ------------------------------------
 */
  if (strcmp(state ,"Q5100")==0) {
    if (dopt==1) {
      inperr(&nftl);
      strcpy(msgstr," LBCC1530: Delete option already specified");
      scrwrt("+W",msgstr);
      err=1;
      *lt = l;
      *rt = r;
      *chkt = chk;
      *errt = err;
      return;
    } else {
      dopt=1;
    }
    strcpy(state ,"Q5010");
    goto zz60;
  }
/*
 * ------------------------------------
 *  state q5200 handles assigned value
 * ------------------------------------
 */
  if (strcmp(state ,"Q5200")==0) {
    if (lstrncmp(&tmpstr_(l),"ASSIGNTRUE",r-l+1)==0) {
      if ((avopt==1)||
          (avopt==-1)) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1540: Variable already assigned a value");
        scrwrt("+W",msgstr);
        err=1;
        *lt = l;
        *rt = r;
        *chkt = chk;
        *errt = err;
        return;
      } else {
        avopt=1;
        strcpy(state ,"Q5010");
        goto zz60;
      }
    } else if (lstrncmp(&tmpstr_(l),"ASSIGNFALSE",r-l+1)==0) {
      if ((avopt==1)||
          (avopt==-1)) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1540: Variable already assigned a value");
        scrwrt("+W",msgstr);
        err=1;
        *lt = l;
        *rt = r;
        *chkt = chk;
        *errt = err;
        return;
      } else {
        avopt=-1;
        strcpy(state ,"Q5010");
        goto zz60;
      }
    } else {
/*
 *  programming error
 */
      error(" prsopt ","  102   ");
    }
  }
/*
 * ------------------------------------
 *  state q5300 is cost specification
 * ------------------------------------
 */
  if (strcmp(state ,"Q5300")==0) {
    if (lstrncmp(&tmpstr_(l),"TRUECOST",r-l+1)==0) {
      if (tcflg!=0) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1160: Duplicate TRUECOST definition");
        scrwrt("+W",msgstr);
        err=1;
        *lt = l;
        *rt = r;
        *chkt = chk;
        *errt = err;
        return;
      }
/*
 *  indicate true cost encountered and cost value should
 *  be applied to truec.  (allow only once)
 */
      tcflg=1;
    } else if (lstrncmp(&tmpstr_(l),"FALSECOST",r-l+1)==0) {
      if (fcflg!=0) {
        inperr(&nftl);
        strcpy(msgstr," LBCC1160: Duplicate FALSECOST definition");
        scrwrt("+W",msgstr);
        err=1;
        *lt = l;
        *rt = r;
        *chkt = chk;
        *errt = err;
        return;
      }
/*
 *  indicate false cost encountered and cost value should be
 *  applied to falsc.  (allow only once)
 */
      fcflg=1;
    } else {
/*
 *  programming error
 */
      error(" prsopt ","  104   ");
    }
    strcpy(state ,"Q5310");
    goto zz60;
  }
/*
 * ------------------------------------
 *  state q5310 is '='
 * ------------------------------------
 */
  if (strcmp(state ,"Q5310")==0) {
    if (lstrncmp(&tmpstr_(l),"=",r-l+1)!=0) {
      inperr(&nftl);
      strcpy(msgstr," LBCC1180: '=' symbol expected");
      scrwrt("+W",msgstr);
      err=1;
      *lt = l;
      *rt = r;
      *chkt = chk;
      *errt = err;
      return;
    }
    strcpy(state ,"Q5320");
    goto zz60;
  }
/*
 * ------------------------------------
 *  state q5320 is optional '-' sign
 * ------------------------------------
 */
  if (strcmp(state ,"Q5320")==0) {
    strcpy(state ,"Q5330");
    if (lstrncmp(&tmpstr_(l),"-",r-l+1)==0) {
      minus=1;
      goto zz60;
    }
    minus=0;
    goto zz70;
  }
/*
 * ------------------------------------
 *  state q5330 is cost value
 * ------------------------------------
 */
  if (strcmp(state ,"Q5330")==0) {
/*
 *  check if legal number
 */
    n = min(r-l+1,8);
    strncpy(numstr,&tmpstr_(l),n);
    numstr_(n+1) = '\0';
    chknum(numstr,&minus,&err);
    if (err==0) {
      if (tcflg==1) {
        if (minus==1) {
          strcpy(truec,"-     ");
          strncpy(&truec_(2),&tmpstr_(l),r-l+1);
        } else {
          strcpy(truec,"      ");
          strncpy(truec,&tmpstr_(l),r-l+1);
        }
        tcflg=2;
      }
      if (fcflg==1) {
        if (minus==1) {
          strcpy(falsc,"-     ");
          strncpy(&falsc_(2),&tmpstr_(l),r-l+1);
        } else {
          strcpy(falsc,"      ");
          strncpy(falsc,&tmpstr_(l),r-l+1);
        }
        fcflg=2;
      }
      strcpy(state ,"Q5010");
      goto zz60;
    } else {
      *lt = l;
      *rt = r;
      *chkt = chk;
      *errt = err;
      return;
    }
  }
/*
 * -------------------------------------
 *  error section
 * -------------------------------------
 *  state not found error
 */
  fprintf(errfil,"STATE = %s", state);
  printf("STATE = %s", state);
  error(" prsopt ","  3000  ");
  *lt = l;
  *rt = r;
  *chkt = chk;
  *errt = err;
  return;
}
/*  last record of prsopt.c****** */
