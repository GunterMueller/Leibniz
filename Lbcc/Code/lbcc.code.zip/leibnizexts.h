/*  first record of leibnizexts.h***** */
/*
 *  element names and equivalent integers
 */
/*
 *  index limits of predicates
 */
/*
 *  predicate use with parentheses
 */
/*
 *  extern definitions of predicates
 */
/*
 *  propositional variables
 */
extern long A5_1;
extern long dd12Price1_dPrice12_1;
extern long ddMgtEff_d12Price1_1;
/*  last record of leibnizexts.h***** */
