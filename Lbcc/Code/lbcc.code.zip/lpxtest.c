/*  first record of lpxtest.c***** */
/*  Copyright 1998, 1999, 2001 Leibniz Company, Plano, Texas, U.S.A.
 * *****************************************************
 *  lptest main program
 * *****************************************************
 * 
 *  parameters: xcomnd = character string telling command
 *              xpoint = integer*4 vector with 8 entries
 *              xvalue  = real*8 vector with 8 entries
 *              interpretation of xpoint and xvalue 
 *              depends on xcomnd
 * 
 * ******************************************************
 *  NOTE: This system is part of the Leibniz System
 *        and may only be used in conjunction with that
 *        system. Any other use constitutes a violation
 *        of the license agreement for the Leibniz System
 * ******************************************************
 */
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
FILE *errfil;
long lpxalcflg = 0;

int main(){
/*
 */
  static char xcomnd[7+1];
  static long xpoint[8];
  static double xvalue[8];
/*
 */
  #define xpoint_(i) xpoint[(i-1)]
  #define xvalue_(i) xvalue[(i-1)]
/*
 *  local variables
 */
  static long try;
/*
 */
  void lpexec();
/*
 *  open error file errfil
 */
   errfil = fopen("lpxtest.err","w"); 
/*
 *  lp test problem
 * 
 *  max:  3x_1 + 4x_2
 *  s.t.  2x_1 + 7x_2 <=  8   (row 1)
 *        8x_1 + 5x_2 <= 11   (row 2)
 *        0 <= x_1, x_2<= 1
 * 
 *  below all write statements are omitted 
 *  use debugging run and check values using
 *  debugger 
 * 
 *  get dim
 * 
 *  memory allocation for lpx arrays
 *  max no. of structural variables
 */
  xpoint_(4)=10;
/*
 *  max no. of equations
 */
  xpoint_(5)=10;
/*
 * max no. of nonzeros in matrix
 */
  xpoint_(6)=100;
/*
 *  iafac (must be in range 3 - 10)
 */
  xpoint_(7)=5;
  strcpy(xcomnd,"ALC DIM");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  xpoint_(8) contains total memory use
 * 
 *  put dev
 * 
 * print option
 */
  xpoint_(3)=0;
  strcpy(xcomnd,"PUT DEV");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  beg lpx
 * 
 *  no. of lp equations
 */
  xpoint_(1)=2;
/*
 *  no. of lp variables, including slacks
 */
  xpoint_(2)=4;
/*
 *  no. of lp nonzero entries, including 
 *  slack coefficients, but not counting 
 *  obj. coefficients or rhs values
 */
  xpoint_(3)=6;
  strcpy(xcomnd,"BEG XMP");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  beg col  column x_1
 * 
 */
  xpoint_(1)=1;
  strcpy(xcomnd,"BEG COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put obj  cost c_1
 * 
 */
  xpoint_(1)=1;
  xvalue_(1)=3.0;
  strcpy(xcomnd,"PUT OBJ");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put col  coefficient a_11, a_21
 * 
 */
  xpoint_(1)=1;
  xpoint_(2)=1;
  xvalue_(1)=2.0;
  strcpy(xcomnd,"PUT COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  xpoint_(1)=1;
  xpoint_(2)=2;
  xvalue_(1)=8.0;
  strcpy(xcomnd,"PUT COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  end col  columns x_1
 * 
 */
  xpoint_(1)=1;
  strcpy(xcomnd,"END COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put bnd  column x_1
 * 
 */
  xpoint_(1)=1;
  xvalue_(1)=0.0;
  xvalue_(2)=1.0;
  strcpy(xcomnd,"PUT BND");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  beg col  column x_2
 * 
 */
  xpoint_(1)=2;
  strcpy(xcomnd,"BEG COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put obj  cost c_2
 * 
 */
  xpoint_(1)=2;
  xvalue_(1)=4.0;
  strcpy(xcomnd,"PUT OBJ");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put col  coefficient a_12, a_22
 * 
 */
  xpoint_(1)=2;
  xpoint_(2)=1;
  xvalue_(1)=7.0;
  strcpy(xcomnd,"PUT COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  xpoint_(1)=2;
  xpoint_(2)=2;
  xvalue_(1)=5.0;
  strcpy(xcomnd,"PUT COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  end col  column x_2
 * 
 */
  xpoint_(1)=2;
  strcpy(xcomnd,"END COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put bnd  column x_2
 * 
 */
  xpoint_(1)=2;
  xvalue_(1)=0.0;
  xvalue_(2)=1.0;
  strcpy(xcomnd,"PUT BND");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  beg col  slack s_1
 * 
 */
  xpoint_(1)=3;
  strcpy(xcomnd,"BEG COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put obj  slack s_1
 * 
 */
  xpoint_(1)=3;
  xvalue_(1)=0.0;
  strcpy(xcomnd,"PUT OBJ");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put col  slack coefficient of s_1 in row 1
 * 
 */
  xpoint_(1)=3;
  xpoint_(2)=1;
  xvalue_(1)=1.0;
  strcpy(xcomnd,"PUT COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  end col  slack s_1
 * 
 */
  xpoint_(1)=3;
  strcpy(xcomnd,"END COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put bnd  slack s_1
 * 
 */
  xpoint_(1)=3;
  xvalue_(1)=0.0;
  xvalue_(2)=20.0;
  strcpy(xcomnd,"PUT BND");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  beg col  slack s_2
 * 
 */
  xpoint_(1)=4;
  strcpy(xcomnd,"BEG COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put obj  slack s_2
 * 
 */
  xpoint_(1)=4;
  xvalue_(1)=0.0;
  strcpy(xcomnd,"PUT OBJ");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put col  slack coefficient of s_2 in row 2
 * 
 */
  xpoint_(1)=4;
  xpoint_(2)=2;
  xvalue_(1)=1.0;
  strcpy(xcomnd,"PUT COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  end col  slack s_2
 * 
 */
  xpoint_(1)=4;
  strcpy(xcomnd,"END COL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put bnd  slack s_2
 * 
 */
  xpoint_(1)=4;
  xvalue_(1)=0.0;
  xvalue_(2)=20.0;
  strcpy(xcomnd,"PUT BND");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put rhs  rhs b_1
 * 
 */
  xpoint_(1)=1;
  xvalue_(1)=8.0;
  strcpy(xcomnd,"PUT RHS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  put rhs  rhs b_2
 * 
 */
  xpoint_(1)=2;
  xvalue_(1)=11.0;
  strcpy(xcomnd,"PUT RHS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  try = 1: solve using primal simplex method
 *        2: solve using dual simplex metho
 *        3: solve ip using rounding
 * 
 */
  try=1;
  zz105:;
  if ((try==1)||(try==3)) {
/*
 *  put bas  slacks s_1, s_2
 * 
 */
    xpoint_(1)=3;
    xpoint_(2)=1;
    strcpy(xcomnd,"PUT BAS");
    lpexec(xcomnd,xpoint,xvalue);
/*
 */
    xpoint_(1)=4;
    xpoint_(2)=2;
    strcpy(xcomnd,"PUT BAS");
    lpexec(xcomnd,xpoint,xvalue);
/*
 * put nbs variables x_1, x_2 at lower bounds
 * 
 */
    xpoint_(1)=1;
    xpoint_(2)=0;
    strcpy(xcomnd,"PUT NBS");
    lpexec(xcomnd,xpoint,xvalue);
/*
 */
    xpoint_(1)=2;
    xpoint_(2)=0;
    strcpy(xcomnd,"PUT NBS");
    lpexec(xcomnd,xpoint,xvalue);
/*
 */
  }
  if (try==2) {
/*
 *  put bas  variables x_1, x_2
 * 
 */
    xpoint_(1)=1;
    xpoint_(2)=1;
    strcpy(xcomnd,"PUT BAS");
    lpexec(xcomnd,xpoint,xvalue);
/*
 */
    xpoint_(1)=2;
    xpoint_(2)=2;
    strcpy(xcomnd,"PUT BAS");
    lpexec(xcomnd,xpoint,xvalue);
/*
 * put nbs slacks s_1, s_2 at lower bounds
 * 
 */
    xpoint_(1)=3;
    xpoint_(2)=0;
    strcpy(xcomnd,"PUT NBS");
    lpexec(xcomnd,xpoint,xvalue);
/*
 */
    xpoint_(1)=4;
    xpoint_(2)=0;
    strcpy(xcomnd,"PUT NBS");
    lpexec(xcomnd,xpoint,xvalue);
/*
 */
  }
/*
 *  fac bas
 * 
 */
  strcpy(xcomnd,"FAC BAS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  if (try==1) {
/*
 * sol pml  solve by primal simplex method
 * 
 */
    strcpy(xcomnd,"SOL PML");
    lpexec(xcomnd,xpoint,xvalue);
/*
 */
  }
  if (try==2) {
/*
 * sol dul solve by dual simplex method
 * 
 */
    strcpy(xcomnd,"SOL DUL");
    lpexec(xcomnd,xpoint,xvalue);
/*
 */
  }
  if (try==3) {
/*
 *  caution: activate code below only if 
 *  the lp is a set packing problem. 
 *  otherwise execute stop.
 */
    exit(0);
/*
 *  sol ip   solve ip using rounding
 * 
 *  lower bound on ip obj value must be 
 *  specified in xvalue_(1)
 *        xvalue_(1) = 0.0
 *        xcomnd = 'SOL IP '
 *        call lpexec(xcomnd,xpoint,xvalue)
 * 
 */
  }
/*
 *  get sol  get solution value 
 *  (is returned in xvalue_(1))
 * 
 * 
 */
  xpoint_(1)=1;
  strcpy(xcomnd,"GET SOL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  xpoint_(1)=2;
  strcpy(xcomnd,"GET SOL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  xpoint_(1)=3;
  strcpy(xcomnd,"GET SOL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  xpoint_(1)=4;
  strcpy(xcomnd,"GET SOL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  get sts  get status of variables 
 *  (is returned in xpoint_(2))
 * 
 */
  xpoint_(1)=1;
  strcpy(xcomnd,"GET STS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  xpoint_(1)=2;
  strcpy(xcomnd,"GET STS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  xpoint_(1)=3;
  strcpy(xcomnd,"GET STS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  xpoint_(1)=4;
  strcpy(xcomnd,"GET STS");
  lpexec(xcomnd,xpoint,xvalue);
/*
 *  get zvl  get obj function value 
 * (is returned in xvalue_(1))
 * 
 */
  strcpy(xcomnd,"GET ZVL");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  try=try+1;
  if (try<=3) {
    goto zz105;
  }
/*
 *  free lpx memory
 */
  strcpy(xcomnd,"FRE DIM");
  lpexec(xcomnd,xpoint,xvalue);
/*
 */
  fclose(errfil);
  exit(0);
}
/* ****************************************************
 */
void error(char *m1,char *m2) {
/*
 */
  printf("*******LP EXECUTION ERROR******");
  printf("\n");
  printf("ERROR IN %s  code %s",m1,m2);
  printf("**********************************");
/*
 */
  fprintf(errfil,"*******LP EXECUTION ERROR******");
  fprintf(errfil,"\n");
  fprintf(errfil,"ERROR IN  %s  code %s",m1,m2);
  fprintf(errfil,"**********************************");
  exit(1);
}
/*  last record of lpxtest.c****** */
