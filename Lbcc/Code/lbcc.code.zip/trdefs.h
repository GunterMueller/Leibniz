/*  first record of trdefs.h***** */
/*
 * *******************************************************
 *  definition of variables for translation module
 * ********************************************************
 *
 * --------------------------------------------------------
 *  define array limits
 * --------------------------------------------------------
 *
 */
long camax;
long crmax;
long cvmax;
long busmax;
long bchmax;
/*
 * --------------------------------------------------------
 *  define variables for handling propositional variables
 * --------------------------------------------------------
 * 
 */
char *cnfvar;
char *cnfvarflg;
/*
 * ------------------------------------
 * 
 */
char *cstval;
/*
 * ------------------------------------
 * 
 */
long *delopt;
long *varopt;
/*
 * ------------------------------------
 * 
 */
long *clsxl1;
long *clsxl2;
long *litlst;
/*
 * ------------------------------------
 * 
 */
long ncnfv;
/*
 * ------------------------------------
 * 
 */
char *truec;
char *falsc;
long dopt;
long avopt;
/*
 * ------------------------------------
 *  observe the following equivalences:
 *    tmpstr to strng1
 *    tmp to strng2
 *    grpstr to strng1
 *    litstr to strng3
 *  caution must be observed in using these strings
 *  since both tmpstr and grpstr are equivalenced to
 *  strng2.  dimension must be at least
 *  30 times cvmax for cvmax .le. 1000.
 *  otherwise should be equal to busmax parameter.
 *  so select = busmax since this  handles all cases.
 * 
 */
char *strng1;
/*
 * ------------------------------------
 * 
 */
char *strng2;
/*
 * ------------------------------------
 * 
 */
char *strng3;
/*
 * ---------------------------------------------------------
 *  define bulk storage arrays, counters,
 *  index arrays, and flags
 * ---------------------------------------------------------
 * 
 */
long *nburec;
/*
 *                         total number of record groups
 *                         already written (in write mode)
 *                         or yet to be read (in read mode)
 */
long *tburec;
/*
 *                         total number of record groups
 */
long *xbuchr;
/*
 *                         index for bulk character array
 */
long *xbuint;
/*
 *                         index for bulk integer array
 */
long *crdflg;
long *cwtflg;
/*
 *                         flag for current read or
 *                         write mode
 */
long rbuend;
/*
 *                         reading flag for end-of-file
 *                         = 0 have not reached end of 
 *                             file yet
 *                         = 1 have reached end of file
 */
char *buchr;
/*
 *                         bulk array for characters
 */
long *buint;
/*
 *                        bulk array for integers
 * 
 * 
 * -------------------------------------------------------
 *  define io devices
 *    note:  errfil is a FILE name.
 *           Internal files are stored in arrays and
 *           are referred to by integers variables:
 *           wfile  = 12 or 13  workfile
 *           ixfile = 12 or 13 and is always different
 *                    from wfile
 *           tmp1, tmp2 = 12 or 13
 * ------------------------------------------------------- 
 */
long wfile;
/*
 *                         current input file during 
 *                         compile
 */
long ixfile;
/*
 *                         file containing the clause
 *                         index list
 */
long tmp1;
/*
 *                          temporary file 1
 *                          (binary clause index lists)
 */
long tmp2;
/*
 *                          temporary file 2
 *                          (binary clause index lists)
 */
long xerror;
long fatl;
/*
 */
long totwrn;
/*
 *                         the total number of warnings.
 */
long toterr;
/*
 *                         the total number of errors.
 */
long cline;
/*
 *                         current line in the source (.log)
 */
char *state;
/*
 *                         current state of the state
 *                         transition diagram.
 * 
 * 
 * 
 * -------------------------------------------------------
 *  define common for set data
 * -------------------------------------------------------
 * 
 */
long nsets;
long nelts;
long *sused;
long *setdat;
char *setnam;
char *eltnam;
/*
 * --------------------------------------------------------
 *  define common for predicate data
 * --------------------------------------------------------
 * 
 */
long nprds;
long cstflg;
long *prdset;
long *pused;
char *prdnam;
/*
 * ------------------------------------------------------
 *  define common for propositional variable information
 * ------------------------------------------------------
 * 
 */
long nvars;
long *vused;
char *varnam;
char *nvnam;
long newvar;
/*
 * ---------------------------------------------------------
 *  define common for convert logic information
 * ---------------------------------------------------------
 * 
 */
long nqnt;
long nstmt;
long nstmt2;
long *qperm;
long *qsetix;
long qnttyp;
char *qntnam;
long *qused;
long form;
char *clsnam;
/*
 * -------------------------------------------------------
 *  define common for where information
 * -------------------------------------------------------
 * 
 */
long *whrstm;
long nwhr;
/*
 * -------------------------------------------------------
 *  define error codes and universal/existential codes
 *  ------------------------------------------------------
 */
  long warn;
  long nftl;
  long fatal;
  long exis;
  long univ;
/*
 * --------------------------------------------------------
 *  transition variables for generate step
 * --------------------------------------------------------
 *  all arrays refer to the cnf formulation outputted
 *  by the translate step
 */
  char *trprbnam;   /* problem name                      */
  char *trcolnam;   /* column names                      */
  char *trrownam;   /* row names                         */
  long trncols;     /* number of cols                    */
  long trnrows;     /* number of rows                    */
  long trnanzs;     /* number of nonzeros                */
  long *trcolusx;   /* col use index, from full-list     */
                    /* cnfvar indices to reduced-list    */
                    /* colnam indices                    */
  long *trcvatf;    /* analog of cvatf                   */
  long *trtrucst;   /* analog of trucst                  */
  long *trfalcst;   /* analog of falscst                 */
  long *tramatrw;   /* analog of amatrw, but has         */
                    /* indices of full name list cnfvar  */
  long *trptamar;   /* analog of ptamar                  */
  long *trnzamar;   /* analog of nzamar                  */ 
/*
 * --------------------------------------------------------
 *  auxiliary arrays
 * --------------------------------------------------------
 */
  char *auxmsg;
  char *inputrecord;
/*
 * --------------------------------------------------------
 *  define equivalences
 * --------------------------------------------------------
 * 
 *  equivalences to internal clause strings
 * 
 *  tmpstr is the input string
 *  (must be busmax because subroutines extcmp and
 *  compct expect to receive a string dimensioned to busmax)
 */
char *tmpstr;
/*
 *  tmp is an entire clause in internal form
 */
char *tmp;
/*
 *  grpstr is the list of and groups
 *  during the rewrit algorithm
 */
char *grpstr;
/*
 *  litstr is the list of literals joined by or
 *  during the rewrit algorithm
 */
char *litstr;
/*  last record of trdefs.h****** */
