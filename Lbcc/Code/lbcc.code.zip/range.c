/*  first record of range.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();
/*
 * *****************************************************************
 * module range computation
 * 
 *  purpose:  compute all range arrays,
 *            graphs and upper bounds on total
 *            solution time for problem in layer 1.
 * 
 *    input:  problem with block indices in layer 1.
 *            arrays assumed defined:
 *             - matrix data amatcl, amatrw
 *             - ncols, nrows, nblks
 *             - colnam, rownam, prbnam
 *             - dlclop, dlrwop
 *             - matrix indices  cixxxx, rixxxx
 *             - counts cnxxx, rnxxx
 *             - scale, idxrow, idxcol
 * 
 *    output:  - succss = 1:  nonsatisfiability has not been
 *                 detected.
 *                 modified problem is in layer 1.
 *                 changes:  added index limits for all blocks q.
 *                           variables scaled or fixed so that enufix
 *                           can process each strip.
 *               - each strip q resides in blocks section, with
 *                 correctly scaled and fixed variables for enufix.
 *               - range vectors in drange and erange for all blocks;
 *                 ndrge, nerge
 *               - partial order graphs gpod and gpoe of
 *                 range vectors for all blocks.
 *             - succss = 0:  nonsatisfiability has been detected.
 *                 input problem is in layer 1, without any modifi-
 *                 cations.
 *              -succss -1:  range data overflowed in computation
 *                 for block qblock. abandoned range calculations.
 * 
 *    caution:  uses layers 2 and 3 for intermediate storage.
 *              range calculation can only be done on problem
 *              from which atf portion has been removed by xnoatf().
 *              if xnoatf() is used, must restore original problem
 *              after range calculations. 
 *              
 * 
 *    calling sequence:
 *      ranges     compute range information and bounds on
 *                 solution time.
 *        crange   determine range arrays and graphs.
 *          crg    calculate range information for one component.
 *          cgpoe  calculate partial order graphs for e type matrices
 *          cgpod  calculate partial order graphs for d type matrices
 *          cgpoep calculate partial order graphs for erange of
 *                 blocks q, and q-1.
 *          cgpodp calculate partial order graphs for drange of
 *                blocks q, and q-1.
 * 
 *      auxiliary routines:  match, contns, combin, projct, projvb
 * 
 * *****************************************************************
 * 
 * 
 * *****************************************************************
 * function match()
 * 
 * check if 0/1 vectors va and vb are the same.
 * va and vb are in common
 * as stored prior to this function call.
 * va(rowmax+1), vb(rowmax+1) = no. of 1s in va, vb
 * match = 1 :  va is the same as vb
 * match = 0 :  va is different from vb
 * 
 * *****************************************************************
 * 
 */
int match() {
/*
 */
  int contns();
/*
 */
  if (va_(rowmax+1)!=vb_(rowmax+1)) {
    return(0);
  } else {
    return(contns());
  }
}
/*
 * *****************************************************************
 * function contns()
 * 
 * check if 0/1 vector va contains vector vb.
 * va and vb are in common as
 * stored prior to this function call.
 * va(rowmax+1), vb(rowmax+1) = no. of 1s in va, vb
 * contns = 1 : va contains vb
 * contns = 0 : va does not contain vb
 * 
 * caution: uses aux vector
 * *****************************************************************
 * 
 */
int contns() {
/*
 */
  static long ix,ixx;
/*
 */
  if (vb_(rowmax+1)==0) {
    return(1);
  }
  if (va_(rowmax+1)<vb_(rowmax+1)) {
    return(0);
  }
/*
 *  we know that both va and vb are non-zero, and that va has at least
 *  as many entries as vb.
 */
  for(ix=1; ix<=va_(rowmax+1); ix++)  {
    aux_(va_(ix))=0;
  }
  for(ix=1; ix<=vb_(rowmax+1); ix++)  {
    aux_(vb_(ix))=1;
  }
/*
 *  check if enough 1s of vb occur in va locations
 */
  ixx=0;
  for(ix=1; ix<=va_(rowmax+1); ix++)  {
    if (aux_(va_(ix))==1) {
      ixx=ixx+1;
    }
  }
  if (ixx==vb_(rowmax+1)) {
    return(1);
  } else {
    return(0);
  }
}
/*
 * *****************************************************************
 * subroutine combin()
 * 
 * combine 0/1 vectors va and vb, and put result into vc.  va and vb
 * have been stored in common prior to this call.
 * the calling code must
 * store the result (which is in vc) into the appropriate vector.
 * va(rowmax+1), vb(rowmax+1), vc(rowmax+1) =
 *                                      no. of 1s in va, vb, vc
 * for efficiency, try to call subroutine so that va(rowmax+1) .ge.
 * vb(rowmax+1).  it is not required for correctness.
 * 
 * caution:  uses aux vector
 * 
 * *****************************************************************
 * 
 */
void combin() {
/*
 */
  static long ix,ixx;
/*
 *  if va is zero vector
 */
  if (va_(rowmax+1)==0) {
    vc_(rowmax+1)=vb_(rowmax+1);
    if (vb_(rowmax+1)==0) {
      return;
    }
    for(ix=1; ix<=vb_(rowmax+1); ix++)  {
      vc_(ix)=vb_(ix);
    }
    return;
  }
/*
 *  if vb is zero vector
 */
  if (vb_(rowmax+1)==0) {
    vc_(rowmax+1)=va_(rowmax+1);
    for(ix=1; ix<=va_(rowmax+1); ix++)  {
      vc_(ix)=va_(ix);
    }
    return;
  }
/*
 *  both va and vb are non-zero
 */
  for(ix=1; ix<=vb_(rowmax+1); ix++)  {
    aux_(vb_(ix))=0;
  }
  for(ix=1; ix<=va_(rowmax+1); ix++)  {
    aux_(va_(ix))=1;
    vc_(ix)=va_(ix);
  }
  ixx=va_(rowmax+1);
  for(ix=1; ix<=vb_(rowmax+1); ix++)  {
    if (aux_(vb_(ix))==0) {
      ixx=ixx+1;
      vc_(ixx)=vb_(ix);
    }
  }
  vc_(rowmax+1)=ixx;
  return;
}
/*
 * *****************************************************************
 * subroutine projct(q)
 * 
 * eliminate non-zeros of 0/1 vector va that are in
 * rows i with riblk(i) = q
 * vector va has been stored in common prior to this function call.
 * the calling code must take the result
 * (which is again in va) and place into
 * the appropriate vector.
 * 
 * va(rowmax+1) = number of 1s in va
 * 
 * note:  this subroutine is used in the projection step
 *        when we compute the ranges of e2/e3 and d2|d1
 * *****************************************************************
 * 
 */
void projct(q)
/*
 */
long q;
{
/*
 */
  static long ix,ixx;
/*
 *  no action needed if va is the zero-vector
 */
  if (va_(rowmax+1)==0) {
    return;
  }
/*
 *  va is a non-zero vector
 */
  ixx=0;
  for(ix=1; ix<=va_(rowmax+1); ix++)  {
    if (riblk_(va_(ix))!=q) {
      ixx=ixx+1;
      va_(ixx)=va_(ix);
    }
  }
  va_(rowmax+1)=ixx;
  return;
}
/*
 * ****************************************************************
 * subroutine projvb(q)
 * 
 * eliminate non-zeros of 0/1 vector vb that are in
 * rows i with riblk(i) = q
 * vector vb has been stored in common prior to this function call.
 * the calling code must take the result
 * (which is again in vb) and place into
 * the appropriate vector.
 * 
 * vb(rowmax+1) = number of 1s in vb
 * 
 * note: this subroutine is used in the projection step of cgpodp and
 *       cgpoep.
 * *****************************************************************
 * 
 */
void projvb(q)
/*
 */
long q;
{
/*
 */
  static long ix,ixx;
/*
 *  no action needed if vb is the zero-vector
 */
  if (vb_(rowmax+1)==0) {
    return;
  }
/*
 *  vb is a non-zero vector
 */
  ixx=0;
  for(ix=1; ix<=vb_(rowmax+1); ix++)  {
    if (riblk_(vb_(ix))!=q) {
      ixx=ixx+1;
      vb_(ixx)=vb_(ix);
    }
  }
  vb_(rowmax+1)=ixx;
  return;
}
/*
 * *****************************************************************
 * subroutine crange
 * 
 * calculate range information for all blocks q of
 * level 1 matrix or detect obvious nonsatisfiability.
 * 
 * output:  succss = 1:  range information has been
 *          calculated and placed
 *          into drange and erange arrays in sorted order as follows:
 *            e2/3 range vectors in erange, and in increasing order.
 *            d2|1 range vectors in drange, and in decreasing order.
 *          calculate partial order graphs of gpod and gpoe arrays.
 *          layer 1
 *          must contain all matrix information, including ciblk(j),
 *          riblk(i), lcllim(q), ucllim(q), lrwlim(q), urwlim(q).
 * 
 *          succss = 0:  problem is obviously nonsatisfiable.
 * 
 *          succss =-1:  range data overflow occurred
 *                       with block qblock.
 *                       remedy: increase range data arrays,
 *                       or compose
 *                       blocks qblock and qblock+1 using compos.
 *                       qblock contains correct block index.
 * 
 *          regardless of succss value at termination,
 *          original layer 1 information is again in layer 1
 * 
 * caution:  uses layer 2 for intermediate storage.
 * 
 * *****************************************************************
 * 
 */
void crange() {
/*
 */
  void cgpod();
  void cgpodp();
  void cgpoe();
  void cgpoep();
  int contns();
  void crg();
  void projct();
  void tranpr();
  void xd1();
  void xe1();
/*
 */
  static long casr,i,ix,j,jx,k,q,qp1;
/*
 *  initialize gpod, and thus gpoe, gpodp, gpoep
 */
  for(q=1; q<=nblks; q++)  {
    for(j=1; j<=rgemax; j++)  {
      for(k=1; k<=rgemax; k++)  {
        gpod_(k,j,q)=0;
      }
    }
  }
/*
 *  initialize ndrge(nblks), nerge(nblks), and nders(nblks)
 */
  ndrge_(nblks)=1;
  nerge_(nblks)=1;
  nders_(nblks)=0;
/*
 *  set erange and drange vectors for nblks to 0.
 */
  nzer_(1,nblks)=0;
  nzdr_(1,nblks)=0;
  pter_(1,nblks)=0;
  ptdr_(1,nblks)=0;
/*
 *  return if there is just one block
 */
  if (nblks==1) {
    succss=1;
    return;
  }
/*
 *  save problem in layer 2
 */
  tranpr(c1,c2);
/*
 *  initialize rg array by inserting one zero vector
 */
  nrg=1;
  nnzrg=0;
  nzrg_(1)=0;
  ptrg_(1)=0;
/*
 *  process one block at a time
 */
  for(q=nblks-1; q>=1; q--)  {
    qp1=q+1;
/*
 * ----------------------------------------------------------------------
 *  process e2/3 matrix for block q.  if q .lt. nblks-1, we already have
 *  part of range of e2/3 from previous iteration.  thus in all cases
 *  we only need e1 of block qp1 and a part of previous rg information
 * ----------------------------------------------------------------------
 *  project out part of rg matrix no longer needed if q .lt. nblks-1
 */
    if (q<(nblks-1)) {
      for(casr=1; casr<=nrg; casr++)  {
/*
 *  store rg vector in va
 */
        va_(rowmax+1)=nzrg_(casr);
        if (nzrg_(casr)>0) {
          for(ix=1; ix<=nzrg_(casr); ix++)  {
            va_(ix)=rg_(ix+ptrg_(casr));
          }
        }
        projct(qp1);
/*
 *  put back into rg
 */
        nzrg_(casr)=va_(rowmax+1);
        if (va_(rowmax+1)>0) {
          for(ix=1; ix<=va_(rowmax+1); ix++)  {
            rg_(ix+ptrg_(casr))=va_(ix);
          }
        }
      }
    }
/*
 *  extract e1 of block qp1 and retain in layer 1
 */
    xe1(qp1);
/*
 *  calculate range vectors and put into rg array
 */
    crg(qp1);
    if (succss==-1) {
/*
 *  range data overflow occurred involving block q. retain block
 *  index in qblock
 */
      qblock=q;
/*
 *  restore original problem in layer 1 by transfer from layer 2
 *  and return
 */
      tranpr(c2,c1);
      return;
    }
/*
 *  --------------------------------------------------------------------
 *  derive auxv3 vector from dlrwop vector.  auxv3 contains row i index
 *  if dlrwop(i) = 0 (thus, row i may not b� deleted) and if all non-zeros
 *  of row i of input problem in layer 2 are in e2/3 matrix.  in that case,
 *  only range vectors with 1 in row i may possibly produce a satisfying
 *  solution.
 *  --------------------------------------------------------------------
 */
    ix=0;
    for(i=1; i<=urwlim_(q); i++)  {
      if (dlrwop_(i)==0) {
/*
 *  check if input problem of layer 2 has a nonzero in row i and column j
 *  outside of e2/3 submatrix (i.e., block index of column j is .le. q)
 * 
 *  if row i is zero, then problem is not satisfiable
 */
        if (nzamr_(i,2)==0) {
          succss=0;
          tranpr(c2,c1);
          return;
        }
/*
 *  row i is nonzero.  scan nonzeros of row i of input problem
 */
        for(jx=1; jx<=nzamr_(i,2); jx++)  {
          j=abs(amr_(jx+ptamr_(i,2),2));
/*
 *  if the nonzero in row i and column j is not in e2/3, skip to next row
 */
          if (cl_(j,21,2)<=q) {
            goto zz250;
          }
        }
/*
 *  row i may not be deleted, and all nonzeros in row i are in columns
 *  of e2/3.  record i in auxv3
 */
        ix=ix+1;
        auxv3_(ix)=i;
      }
    zz250:;}
    auxv3_(rowmax+1)=ix;
/*
 *  transfer range vectors from rg to erange.  they are in increasing
 *  order in rg.  eliminate range vectors using auxv3
 */
    nerge_(q)=0;
    nders_(q)=0;
    for(casr=1; casr<=nrg; casr++)  {
/*
 * ----------------------------------------------------------------
 *  if range vector casr of rg contains the auxv3 vector, then that range
 *  vector may lead to satisfiability, and is recorded in erange.
 *  otherwise, the range vector is ignored.
 * ----------------------------------------------------------------
 *  store rg in va, and auxv3 in vb for contns
 */
      va_(rowmax+1)=nzrg_(casr);
      if (nzrg_(casr)>0) {
        for(ix=1; ix<=nzrg_(casr); ix++)  {
          va_(ix)=rg_(ix+ptrg_(casr));
        }
      }
      vb_(rowmax+1)=auxv3_(rowmax+1);
      if (auxv3_(rowmax+1)>0) {
        for(ix=1; ix<=auxv3_(rowmax+1); ix++)  {
          vb_(ix)=auxv3_(ix);
        }
      }
      if (contns()==1) {
        nerge_(q)=nerge_(q)+1;
        pter_(nerge_(q),q)=nders_(q);
        nzer_(nerge_(q),q)=nzrg_(casr);
        if (nzrg_(casr)>0) {
          for(ix=1; ix<=nzrg_(casr); ix++)  {
            nders_(q)=nders_(q)+1;
            erange_(ix+pter_(nerge_(q),q),q)=rg_(ix+ptrg_(casr));
          }
        }
      }
    }
/*
 *  if nerge(q) .eq. 0, then problem is not satisfiable
 */
    if (nerge_(q)==0) {
      succss=0;
      tranpr(c2,c1);
      return;
    }
/*
 *  place erange vectors into rg
 */
    nnzrg=0;
    for(casr=1; casr<=nerge_(q); casr++)  {
      ptrg_(casr)=nnzrg;
      nzrg_(casr)=nzer_(casr,q);
      if (nzer_(casr,q)>0) {
        for(ix=1; ix<=nzer_(casr,q); ix++)  {
          nnzrg=nnzrg+1;
          rg_(ix+ptrg_(casr))=erange_(ix+pter_(casr,q),q);
        }
      }
    }
    nrg=nerge_(q);
/*
 *  restore original problem in layer 1 by transfer from layer 2
 */
    tranpr(c2,c1);
  }
/*
 * ---------------------------------------------------------------------
 *  second, handle d2|1 cases
 * ---------------------------------------------------------------------
 *  initialize rg array by inserting one zero vector
 */
  nrg=1;
  nnzrg=0;
  nzrg_(1)=0;
/*
 *  process one block at a time
 */
  for(q=1; q<=nblks-1; q++)  {
    qp1=q+1;
/*
 * ----------------------------------------------------------------------
 *  process d2|1 matrix for block q.  if q .gt. 1, we already have part
 *  of range of d2|1 from previous iteration.  thus in all cases we only
 *  need d1 of block q and a part of previous rg information
 * ----------------------------------------------------------------------
 *  project out part of rg matrix no longer needed if q .gt. 1
 */
    if (q>1) {
      for(casr=1; casr<=nrg; casr++)  {
/*
 *  store rg vector in va
 */
        va_(rowmax+1)=nzrg_(casr);
        if (nzrg_(casr)>0) {
          for(ix=1; ix<=nzrg_(casr); ix++)  {
            va_(ix)=rg_(ix+ptrg_(casr));
          }
        }
        projct(q);
/*
 *  put back into rg
 */
        nzrg_(casr)=va_(rowmax+1);
        if (va_(rowmax+1)>0) {
          for(ix=1; ix<=va_(rowmax+1); ix++)  {
            rg_(ix+ptrg_(casr))=va_(ix);
          }
        }
      }
    }
/*
 *  extract d1 of block q and retain in layer 1
 */
    xd1(q);
/*
 *  calculate range vectors and put into rg array
 */
    crg(q);
    if (succss==-1) {
/*
 *  range data overflow occurred involving block q. retain block
 *  index in qblock
 */
      qblock=q;
/*
 *  restore original problem in layer 1 by transfer from layer 2,
 *  and return
 */
      tranpr(c2,c1);
      return;
    }
/*
 *  --------------------------------------------------------------------
 *  derive auxv3 vector from dlrwop vector.  auxv3 contains row i index
 *  if dlrwop(i) = 0 (thus, row i may not be deleted) and if all non-zeros
 *  of row i of input problem in layer 2 are in d2|1 matrix.  in that case,
 *  only range vectors with 1 in row i may possibly produce a satisfying
 *  solution.
 *  --------------------------------------------------------------------
 */
    ix=0;
    for(i=lrwlim_(qp1); i<=nrows; i++)  {
      if (dlrwop_(i)==0) {
/*
 *  check if input problem of layer 2 has a nonzero in row i and column j
 *  outside of d2|1 submatrix (i.e., block index of column j is .gt. q)
 * 
 *  if row i is zero, then problem is not satisfiable
 */
        if (nzamr_(i,2)==0) {
          succss=0;
          tranpr(c2,c1);
          return;
        }
/*
 *  row i is nonzero.  scan nonzeros of row i of input problem
 */
        for(jx=1; jx<=nzamr_(i,2); jx++)  {
          j=abs(amr_(jx+ptamr_(i,2),2));
/*
 *  if the nonzero in row i and column j is not in d2|1, skip to next row
 */
          if (cl_(j,21,2)>q) {
            goto zz1250;
          }
        }
/*
 *  row i may not be deleted, and all nonzeros in row i are in columns
 *  of d2|1.  record i in auxv3
 */
        ix=ix+1;
        auxv3_(ix)=i;
      }
    zz1250:;}
    auxv3_(rowmax+1)=ix;
/*
 *  transfer range vectors from rg to drange.  they are in increasing order
 *  in rg, but are to be in decreasing order in drange.  eliminate range
 *  vectors using auxv3
 */
    nrgx=0;
    nnzrgx=0;
    for(casr=1; casr<=nrg; casr++)  {
/*
 *  if range vector casr of rg contains the auxv3 vector, then that range
 *  vector may lead to satisfiability, and is recorded in drange.
 *  otherwise, the range vector is ignored.
 *  first reduce rg by eliminating vectors
 *  that can be so ignored.  place remaining vectors in rgx array.
 * 
 *  store rg in va, and auxv3 in vb for contns
 */
      va_(rowmax+1)=nzrg_(casr);
      if (nzrg_(casr)>0) {
        for(ix=1; ix<=nzrg_(casr); ix++)  {
          va_(ix)=rg_(ix+ptrg_(casr));
        }
      }
      vb_(rowmax+1)=auxv3_(rowmax+1);
      if (auxv3_(rowmax+1)>0) {
        for(ix=1; ix<=auxv3_(rowmax+1); ix++)  {
          vb_(ix)=auxv3_(ix);
        }
      }
      if (contns()==1) {
        nrgx=nrgx+1;
        ptrgx_(nrgx)=nnzrgx;
        nzrgx_(nrgx)=nzrg_(casr);
        if (nzrg_(casr)>0) {
          for(ix=1; ix<=nzrg_(casr); ix++)  {
            nnzrgx=nnzrgx+1;
            rgx_(ix+ptrgx_(nrgx))=rg_(ix+ptrg_(casr));
          }
        }
      }
    }
/*
 *  if no range vectors in rgx, then problem is not satisfiable
 */
    if (nrgx==0) {
      succss=0;
      tranpr(c2,c1);
      return;
    }
/*
 *  put rgx range vectors into drange array in reverse order
 */
    ndrge_(q)=nrgx;
/*
 *  check if too many range vectors for block q.  this can only happen
 *  when dlclop(j) = 1 for some j. retain block index in qblock
 *  return
 */
    if (nerge_(q)+ndrge_(q)>rgemax) {
      succss=-1;
      qblock=q;
      return;
    }
    for(casr=nrgx; casr>=1; casr--)  {
      ptdr_(nrgx-casr+1,q)=nders_(q);
      nzdr_(nrgx-casr+1,q)=nzrgx_(casr);
      if (nzrgx_(casr)>0) {
        for(ix=1; ix<=nzrgx_(casr); ix++)  {
          nders_(q)=nders_(q)+1;
          if (nders_(q)>dermax) {
/*
 *  range data overflow. retain block index in qblock and return
 */
            succss=-1;
            qblock=q;
            return;
          }
          drange_(ix+ptdr_(nrgx-casr+1,q),q) =
              rgx_(ix+ptrgx_(casr));
        }
      }
    }
/*
 *  place rgx vectors into rg
 */
    for(casr=1; casr<=nrgx; casr++)  {
      ptrg_(casr)=ptrgx_(casr);
      nzrg_(casr)=nzrgx_(casr);
      if (nzrgx_(casr)>0) {
        for(ix=1; ix<=nzrgx_(casr); ix++)  {
          rg_(ix+ptrg_(casr))=rgx_(ix+ptrgx_(casr));
        }
      }
    }
/*
 *  restore original problem to layer 1 by transfer from layer 2
 */
    tranpr(c2,c1);
  }
/*
 * -----------------------------------------------------------------
 *  compute gpoe, gpoep, gpod, gpodp
 * -----------------------------------------------------------------
 */
  for(q=1; q<=nblks-1; q++)  {
/*
 *  compute partial order graph gpoe from erange array
 */
    cgpoe(q);
/*
 *  compute partial order graph gpod from drange array
 */
    cgpod(q);
  }
/*
 *  if nblks .gt. 2, compute partial order graphs gpoep, gpodp
 */
  if (nblks>2) {
    for(q=2; q<=nblks-1; q++)  {
      cgpoep(q);
      cgpodp(q);
    }
  }
  succss=1;
  return;
}
/*
 * *****************************************************************
 * subroutine crg(q)
 * 
 * calculate range information for e2/3 or d2|1.
 * part of the range information is already in rg.
 * the columns to be processed yet are in layer 1.
 * in the first pass rg may have duplicate
 * columns due to the projection step.
 * at any rate, rg has at least one
 * column, so nrg >= 1 initially.
 * use dlclop to decide whether or not a
 * column of the matrix in layer 1
 * can have a zero coefficient in the
 * range calculation.
 * 
 * *****************************************************************
 * 
 */
void crg(q)
/*
 */
long q;
{
/*
 */
  void combin();
  int match();
  void recdx();
  void sclall();
/*
 */
  static long casr,ix,ixx,iyy,j,j1,j2,n,nrg1;
/*
 *  set up limits for do loops of matrix columns
 */
  j1=lcllim_(q);
  j2=ucllim_(q);
  for(j=j1; j<=j2; j++)  {
/*
 *  if column j of layer 1 matrix has no entries, rg is already ok,
 *  unless j = j1
 */
    if ((cnall_(j)==0)&&(j>j1)) {
      goto zz100;
    }
/*
 * ------------------------------------------------------------------
 *  process column j of layer 1 matrix.  the column is known to be
 *  non-zero, unless j = j1.
 *  initialize pointers and counters.
 * -----------------------------------------------------------------
 */
    nrgx=0;
    nnzrgx=0;
    zrgx=0;
    rgxcur=rowmax;
    for(n=1; n<=rowmax; n++)  {
      rgxusd_(n)=-1;
    }
/*
 *  calculate the two vectors producible by +1 and -1 factors from
 *  column j.
 */
    ixx=0;
    iyy=0;
/*
 *  get entries of column j
 */
    sclall(j);
/*
 *  compute the two possible vectors producible from column j
 */
    if (cnall_(j)>0) {
      for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
        if (centry_(ix)==1) {
          ixx=ixx+1;
          auxv1_(ixx)=clalli_(ix);
        } else {
          iyy=iyy+1;
          auxv2_(iyy)=clalli_(ix);
        }
      }
    }
    auxv1_(rowmax+1)=ixx;
    auxv2_(rowmax+1)=iyy;
/*
 *  process all rg vectors using auxv1 and auxv2
 */
    for(casr=1; casr<=nrg; casr++)  {
/*
 *  if column j has dlclop(j) = 1, then rg vector with index casr
 *  is copied into rgx array.
 */
      if (dlclop_(j)==1) {
        nrgx=nrgx+1;
        ptrgx_(nrgx)=nnzrgx;
        nzrgx_(nrgx)=nzrg_(casr);
        if (nzrg_(casr)>0) {
          for(ix=1; ix<=nzrg_(casr); ix++)  {
            nnzrgx=nnzrgx+1;
            rgx_(ix+ptrgx_(nrgx))=rg_(ix+ptrg_(casr));
          }
        }
        recdx();
      }
/*
 *  combine auxv1 with rg vector with index casr, and store in rgx array.
 */
      nrgx=nrgx+1;
      ptrgx_(nrgx)=nnzrgx;
/*
 *  store rg vector into va and auxv1 into vb in common for combin
 */
      va_(rowmax+1)=nzrg_(casr);
      if (nzrg_(casr)>0) {
        for(ix=1; ix<=nzrg_(casr); ix++)  {
          va_(ix)=rg_(ix+ptrg_(casr));
        }
      }
      vb_(rowmax+1)=auxv1_(rowmax+1);
      if (auxv1_(rowmax+1)>0) {
        for(ix=1; ix<=auxv1_(rowmax+1); ix++)  {
          vb_(ix)=auxv1_(ix);
        }
      }
      combin();
/*
 *  put vc vector into rgx
 */
      nzrgx_(nrgx)=vc_(rowmax+1);
      if (vc_(rowmax+1)>0) {
        for(ix=1; ix<=vc_(rowmax+1); ix++)  {
          nnzrgx=nnzrgx+1;
          rgx_(ix+ptrgx_(nrgx))=vc_(ix);
        }
      }
      recdx();
/*
 *  do same for auxv2
 */
      nrgx=nrgx+1;
      ptrgx_(nrgx)=nnzrgx;
/*
 *  store rg vector into va and auxv2 into vb in common for combin
 */
      va_(rowmax+1)=nzrg_(casr);
      if (nzrg_(casr)>0) {
        for(ix=1; ix<=nzrg_(casr); ix++)  {
          va_(ix)=rg_(ix+ptrg_(casr));
        }
      }
      vb_(rowmax+1)=auxv2_(rowmax+1);
      if (auxv2_(rowmax+1)>0) {
        for(ix=1; ix<=auxv2_(rowmax+1); ix++)  {
          vb_(ix)=auxv2_(ix);
        }
      }
      combin();
/*
 *  put vc vector into rgx
 */
      nzrgx_(nrgx)=vc_(rowmax+1);
      if (vc_(rowmax+1)>0) {
        for(ix=1; ix<=vc_(rowmax+1); ix++)  {
          nnzrgx=nnzrgx+1;
          rgx_(ix+ptrgx_(nrgx))=vc_(ix);
        }
      }
      recdx();
    }
/*
 * -----------------------------------------------------------------------
 *  we now sort the rgx vector in increasing order and place them into
 *  rg.  at the same time we delete duplicates
 *  store zero vector if zrgx = 1
 * -----------------------------------------------------------------------
 */
    nnzrg=0;
    if (zrgx==1) {
      nrg=1;
      nzrg_(1)=0;
      ptrg_(1)=0;
    } else {
      nrg=0;
    }
/*
 *  scan rgxlst to extract one vector at a time
 */
    for(n=1; n<=rowmax; n++)  {
/*
 *  check if a vector with n 1s exists in rgx.  if none are present,
 *  skip to next n.
 */
      if (rgxusd_(n)==(-1)) {
        goto zz400;
      }
/*
 *  process first vector with n 1s of rgx
 */
      nrg=nrg+1;
/*
 *  check for overflow in rg
 */
      if (nrg>rgemax) {
/*
 *  range data overflow exists
 */
        succss=-1;
        return;
      }
/*
 *  transfer vector from rgx to rg
 */
      ptrg_(nrg)=nnzrg;
      nzrg_(nrg)=nzrgx_(rgxlst_(1,n));
      for(ix=1; ix<=nzrgx_(rgxlst_(1,n)); ix++)  {
        nnzrg=nnzrg+1;
        rg_(ix+ptrg_(nrg)) =
            rgx_(ix+ptrgx_(rgxlst_(1,n)));
      }
/*
 *  save nrg value in nrg1 for matching test.  initialize rgxcur for
 *  index in rgxlst
 */
      nrg1=nrg;
      rgxcur=n;
/*
 *  check if we have processed last entry
 */
      zz450:;
      if (rgxcur==rgxusd_(n)) {
        goto zz400;
      }
/*
 *  get index of next vector
 */
      rgxcur=rgxlst_(2,rgxcur);
/*
 *  check if duplicate of vector in rgx exists already in rg.  if yes,
 *  go to next vector in rgx
 */
      for(casr=nrg1; casr<=nrg; casr++)  {
/*
 *  store rgx range vector with index rgxlst(1,rgxcur) in va
 *  and rg range vector with index casr in vb for match
 */
        va_(rowmax+1)=nzrgx_(rgxlst_(1,rgxcur));
        for(ix=1; ix<=nzrgx_(rgxlst_(1,rgxcur)); ix++)  {
          va_(ix) = rgx_(ix+ptrgx_(rgxlst_(1,rgxcur)));
        }
        vb_(rowmax+1)=nzrg_(casr);
        for(ix=1; ix<=nzrg_(casr); ix++)  {
          vb_(ix)=rg_(ix+ptrg_(casr));
        }
        if (match()==1) {
          goto zz450;
        }
      }
/*
 *  vector does not yet exist in rg.  store it in rg
 */
      nrg=nrg+1;
/*
 *  check for overflow
 */
      if (nrg>rgemax) {
/*
 *  range data overflow exists
 */
        succss=-1;
        return;
      }
      ptrg_(nrg)=nnzrg;
      nzrg_(nrg)=nzrgx_(rgxlst_(1,rgxcur));
      for(ix=1; ix<=nzrgx_(rgxlst_(1,rgxcur)); ix++)  {
        nnzrg=nnzrg+1;
        if (nnzrg>dermax) {
/*
 *  too many nonzeros for range vectors
 */
          succss=-1;
          return;
        }
        rg_(ix+ptrg_(nrg)) =
            rgx_(ix+ptrgx_(rgxlst_(1,rgxcur)));
      }
      goto zz450;
    zz400:;}
/*
 * -------------------------------------------------------------------
 *  have completely processed column j of layer 1 matrix.  rg
 *  contains new range vectors in increasing order.
 * -------------------------------------------------------------------
 */
  zz100:;}
  succss=1;
  return;
}
/*
 * *****************************************************************
 * subroutine recdx
 * 
 * records vector in nrgx position of rgx array in index list rgxlst.
 * adjusts rgxcur and zrgx.
 * 
 * *****************************************************************
 * 
 */
void recdx() {
/*
 */
  static long n;
/*
 */
  n=nzrgx_(nrgx);
/*
 *  if vector is zero, remove vector from rgx array and set zrgx pointer.
 */
  if (n==0) {
    zrgx=1;
    nrgx=nrgx-1;
    return;
  }
/*
 *  vector is nonzero.  adjust rgxlst and pointers.  test if there is
 *  already a vector in rgx with n 1s.
 */
  if (rgxusd_(n)==(-1)) {
    rgxusd_(n)=n;
    rgxlst_(1,n)=nrgx;
/*
 *  at least one vector with n 1s is in rgx
 */
  } else {
    rgxcur=rgxcur+1;
/*
 *  check for overflow due to programming error
 */
    if (rgxcur>rowmax+3*rgemax) {
      error(" recdx  ","   92   ");
    }
    rgxlst_(2,rgxusd_(n))=rgxcur;
    rgxusd_(n)=rgxcur;
    rgxlst_(1,rgxcur)=nrgx;
  }
  return;
}
/*
 * *****************************************************************
 * subroutine cgpoe(q)
 * 
 * compute partial order graph gpoe.
 * if vector k contains vector j of
 * block q erange, then gpoe(k,j,q) .lt. 0.
 * remaining elements of gpoe are .ge. 0.
 * the vectors of erange are sorted in increasing order.
 * *****************************************************************
 * 
 */
void cgpoe(q)
/*
 */
long q;
{
/*
 */
  int contns();
/*
 */
  static long j,k,ix;
/*
 *  check for small case
 */
  if (nerge_(q)==1) {
    goto zz350;
  }
/*
 *  process one column of erange at a time
 */
  for(j=1; j<=nerge_(q)-1; j++)  {
    for(k=j+1; k<=nerge_(q); k++)  {
/*
 *  if vectors j and k of erange have same no. of 1s, then vector k
 *  cannot contain vector j
 */
      if (nzer_(j,q)==nzer_(k,q)) {
        goto zz200;
      }
/*
 *  if vector k contains vector j, record in gpoe
 *  store erange vector with index k in va, and erange vector with
 *  index j in vb for contns
 */
      va_(rowmax+1)=nzer_(k,q);
      if (nzer_(k,q)>0) {
        for(ix=1; ix<=nzer_(k,q); ix++)  {
          va_(ix)=abs(erange_(ix+pter_(k,q),q));
        }
      }
      vb_(rowmax+1)=nzer_(j,q);
      if (nzer_(j,q)>0) {
        for(ix=1; ix<=nzer_(j,q); ix++)  {
          vb_(ix)=abs(erange_(ix+pter_(j,q),q));
        }
      }
      if (contns()==1) {
        if (gpoe_(k,j,q)>0) {
          gpoe_(k,j,q)=-gpoe_(k,j,q);
        } else {
          gpoe_(k,j,q)=-1;
        }
      }
    zz200:;}
  }
  zz350:;
  for(j=1; j<=nerge_(q); j++)  {
    if (gpoe_(j,j,q)>0) {
      gpoe_(j,j,q)=-gpoe_(j,j,q);
    } else {
      gpoe_(j,j,q)=-1;
    }
  }
  return;
}
/*
 * *****************************************************************
 * subroutine cgpod(q)
 * 
 * compute partial order graph gpod.  if vector k is contained in
 * vector j of block q drange, then gpod(k,j+nerge(q),q) .lt. 0.
 * remaining elements of gpod are .ge. 0.  the vectors of drange are
 * sorted in decreasing order.
 * *****************************************************************
 * 
 */
void cgpod(q)
/*
 */
long q;
{
/*
 */
  int contns();
/*
 */
  static long j,k,ix;
/*
 *  check for small case
 */
  if (ndrge_(q)==1) {
    goto zz350;
  }
/*
 *  process one column of drange at a time
 */
  for(j=1; j<=ndrge_(q)-1; j++)  {
    for(k=j+1; k<=ndrge_(q); k++)  {
/*
 *  if vectors j and k of drange have same no. of 1s, then vector k
 *  cannot be contained in vector j.
 */
      if (nzdr_(j,q)==nzdr_(k,q)) {
        goto zz200;
      }
/*
 *  if vector k is contained in vector j, record in gpod
 *  store drange vector with index j in va, and drange vector with
 *  index k in vb for contns
 */
      va_(rowmax+1)=nzdr_(j,q);
      if (nzdr_(j,q)>0) {
        for(ix=1; ix<=nzdr_(j,q); ix++)  {
          va_(ix)=abs(drange_(ix+ptdr_(j,q),q));
        }
      }
      vb_(rowmax+1)=nzdr_(k,q);
      if (nzdr_(k,q)>0) {
        for(ix=1; ix<=nzdr_(k,q); ix++)  {
          vb_(ix)=abs(drange_(ix+ptdr_(k,q),q));
        }
      }
      if (contns()==1) {
        if (gpod_(k,j+nerge_(q),q)>0) {
          gpod_(k,j+nerge_(q),q)=-gpod_(k,j+nerge_(q),q);
        } else {
          gpod_(k,j+nerge_(q),q)=-1;
        }
      }
    zz200:;}
  }
  zz350:;
  for(j=1; j<=ndrge_(q); j++)  {
    if (gpod_(j,j+nerge_(q),q)>0) {
      gpod_(j,j+nerge_(q),q)=-gpod_(j,j+nerge_(q),q);
    } else {
      gpod_(j,j+nerge_(q),q)=-1;
    }
  }
  return;
}
/*
 * *****************************************************************
 * subroutine cgpoep(q)
 * 
 * compute partial order graph gpoep.
 * if projected part of vector j of
 * block q of erange is contained in
 * vector k of block q-1 of erange, then
 * add tt14 (=2**14) to gpoep(k,j,q) if nonnegative,
 * and subtract tt14 if negative.
 * 
 * *****************************************************************
 * 
 */
void cgpoep(q)
/*
 */
long q;
{
/*
 */
  int contns();
  void projvb();
/*
 */
  static long j,k,ix,i;
/*
 *  initialize nergep(q)
 */
  nergep_(q)=0;
/*
 *  process each vector j of block q of erange
 */
  for(j=1; j<=nerge_(q); j++)  {
/*
 *  put vector j into vb
 */
    vb_(rowmax+1)=nzer_(j,q);
    if (nzer_(j,q)>0) {
      for(ix=1; ix<=nzer_(j,q); ix++)  {
        i=abs(erange_(ix+pter_(j,q),q));
        i=i-(i/tt14)*tt14;
        vb_(ix)=i;
      }
    }
/*
 *  project out entries in rows i indexed by q
 */
    projvb(q);
/*
 *  place each vector k of block q-1 of erange into va and check
 *  containment of vb
 */
    for(k=1; k<=nerge_(q-1); k++)  {
      va_(rowmax+1)=nzer_(k,q-1);
      if (nzer_(k,q-1)>0) {
        for(ix=1; ix<=nzer_(k,q-1); ix++)  {
          i=abs(erange_(ix+pter_(k,q-1),q-1));
          i=i-(i/tt14)*tt14;
          va_(ix)=i;
        }
      }
/*
 *  check for containment and record in gpoep
 */
      if (contns()==1) {
        nergep_(q)=nergep_(q)+1;
        if (gpoep_(k,j,q)>=0) {
          gpoep_(k,j,q)=gpoep_(k,j,q)+tt14;
        } else {
          gpoep_(k,j,q)=gpoep_(k,j,q)-tt14;
        }
      }
    }
  }
  return;
}
/*
 * *****************************************************************
 * subroutine cgpodp(q)
 * 
 * compute partial order graph gpodp.
 * if vector j of block q of drange
 * contains projected part of vector k of block q-1 of drange,
 * then add tt14 (=2**14) to gpodp(k,j+nerge(q),q) if nonnegative,
 * and subtract tt14 if negative.
 * 
 * *****************************************************************
 * 
 */
void cgpodp(q)
/*
 */
long q;
{
/*
 */
  int contns();
/*
 */
  static long i,ix,j,k;
/*
 *  initialize ndrgep(q)
 */
  ndrgep_(q)=0;
  for(k=1; k<=ndrge_(q-1); k++)  {
/*
 *  put vector k of block q-1 of drange into vb
 */
    vb_(rowmax+1)=nzdr_(k,q-1);
    if (nzdr_(k,q-1)>0) {
      for(ix=1; ix<=nzdr_(k,q-1); ix++)  {
        i=abs(drange_(ix+ptdr_(k,q-1),q-1));
        i=i-(i/tt14)*tt14;
        vb_(ix)=i;
      }
    }
/*
 *  project out entries in rows indexed by q
 */
    projvb(q);
/*
 *  place each vector j of block q of drange into va and check
 *  containment of vb
 */
    for(j=1; j<=ndrge_(q); j++)  {
      va_(rowmax+1)=nzdr_(j,q);
      if (nzdr_(j,q)>0) {
        for(ix=1; ix<=nzdr_(j,q); ix++)  {
          i=abs(drange_(ix+ptdr_(j,q),q));
          i=i-(i/tt14)*tt14;
          va_(ix)=i;
        }
      }
/*
 *  check for containment and record in gpodp
 */
      if (contns()==1) {
        ndrgep_(q)=ndrgep_(q)+1;
        if (gpodp_(k,j+nerge_(q),q)>=0) {
          gpodp_(k,j+nerge_(q),q)=gpodp_(k,j+nerge_(q),q)+tt14;
        } else {
          gpodp_(k,j+nerge_(q),q)=gpodp_(k,j+nerge_(q),q)-tt14;
        }
      }
    }
  }
  return;
}
/*
 * ****************************************************************
 *  subroutine ranges
 * 
 *  purpose:  computes range arrays and graphs.  may determine
 *            nonsatisfiability during range calculations.   computes
 *            upper bound on solution time.
 * 
 *    input:  as given in module summary.
 * 
 *    output:  - succss = 1: nonsatisfiability has not been detected.
 *                 modified problem is in layer 1.
 *                 changes:  variables scaled or fixed so that enufix
 *                           can process each strip.
 *               - range vectors in drange and erange for all blocks;
 *                 ndrge, nerge
 *               - partial order graphs gpod and gpoe
 *                 of range vectors for all blocks.
 *               - logrge(q) = log2 of ndrge(q) * nerge(q); for all q
 *             - succss = 0:  nonsatisfiability has been detected.
 *                 input problem is in layer 1, without any modifi-
 *                 cations.
 * 
 *    caution:  uses layers 2 and 3 for intermediate storage.
 * 
 *  ==============
 *  update history
 *  ==============
 *  date          where        changes made/reason
 * ----------------------------------------------------------------
 * 
 * ****************************************************************
 * 
 */
void ranges() {
/*
 */
  void bdtsol();
  void crange();
/*
 *  calculate range information for drange,erange,gpod,gpoe,gpoep,gpodp
 */
  crange();
  if (succss==0) {
/*
 *  range calculations have determined problem to be nonsatisfiable
 */
    return;
  }
  if (succss==-1) {
/*
 *  range data overflow occurred involving block qblock. can be
 *  eliminated by composing blocks qblock and qblock+1
 */
    return;
  }
/*
 *  compute upper bound on solution time and update logrge
 */
  bdtsol();
  return;
}
/*  last record of range.c****** */
