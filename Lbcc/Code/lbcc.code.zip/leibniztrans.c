/*  first record of leibniztrans.c***** */
/*
 *  transfers variable values from Leibniz to
 *  user program and vice versa
 */
#include<string.h>
#include "leibnizdefs.h"
void leibniztransfer(char *move,char *problemname,
   long *trsvar,long *errvalt,
   char *ucomnd,char *uname,char *ustate,
   char *utype,long *uvalue,short *uerror) {
  void trserrmsg();
  void error();
  void disprm();
#include "finance.formulas.trs"
/*
 *  The user may insert here #include statements
 *  of additional .trs files.
 *  All .log files producing such .trs files
 *  must have the same sets, predicates, and variables.
 *  At least one of the .log files must be compiled
 *  with the option
 *   'keep all variables even if not used in any fact'
 *  The leibnizdefs.h file of that compilation must
 *  be used for inclusion here (in leibniztrans.c).
 *  The corresponding leibnizexts.h must be included
 *  in the user code.
 */
  uerror[0]=3;
  trserrmsg(2010);
  disprm(ucomnd,uname,ustate,utype,uvalue,uerror);
  return;
}
/*  last record of leibniztrans.c***** */
