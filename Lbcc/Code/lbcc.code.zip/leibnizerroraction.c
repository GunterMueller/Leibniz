/*  first record of leibnizerroraction.c***** */
#include<stdio.h>
/*
 * *******************************************************
 *  subroutine leibnizerroraction(long errortype)
 * 
 *  purpose:  defines action to be taken when number of
 *            execution errors of type errortype exceed
 *            limit defined by user in command lim_err.
 * 
 * *******************************************************
 * 
 */
void leibnizerroraction(long errortype) {

  void lbccexit();
/*
 *  errortype = 1: warning
 *            = 2: nonfatal error
 *            = 3: fatal error
 */
  void error();
 /*
 */
  if (errortype==1) {
/*
 *  below, insert decision when the number of warnings
 *  exceeds the limit defined in lim_err()
 */
    printf(
           "\n**********************************\n"
           "Leibniz execution terminated in procedure\n"
           "leibnizerroraction() since max number\n" 
           "of warnings was exceeded.\n"
           "**********************************\n");
    lbccexit(1);
  } else if (errortype==2) {
/*
 *  below, insert decision when the number of nonfatal errors
 *  exceeds the limit defined in lim_err()
 */
    printf(
           "\n**********************************\n"
           "Leibniz execution terminated in procedure\n"
           "leibnizerroraction() since max number\n" 
           "of nonfatal errors was exceeded.\n"
           "**********************************\n"); 
    lbccexit(1);
  } else if (errortype==3) {
/*
 *  below, insert decision when the number of nonfatal errors
 *  exceeds the limit defined in lim_err()
 */
    printf(
           "\n**********************************\n"
           "Leibniz execution terminated in procedure\n"
           "leibnizerroraction() since max number\n" 
           "of fatal errors was exceeded.\n"
           "**********************************\n");
    lbccexit(1);
  } else {
/*
 *  incorrect error type
 */
    error("leibnizerroraction","102");
  }
}
/*  last record of leibnizerroraction.c***** */
