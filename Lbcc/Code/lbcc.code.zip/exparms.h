/*  first record of exparms.h***** */
/*
 *  this file defines parameters for execution module
 * 
 *  tt14   = 2**14     = 16,384
 *  tt15m1 = 2**15 - 1 = 32767
 *  tt31m1 = 2**31 - 1 = 2,147,483,647
 */
#define tt14 16384
#define tt15m1 32767
#define tt31m1 2147483647
#define pgrmax 60
/*
 *                  size of records of .prg file
 *                  caution: if pgrmax is changed,
 *                           must also change fscanf
 *                           statement in ut.f - getprg
 *                           and getalp routines
 */
#define lclmax 25
/*
 *                  max number of l value, column
 *                  information for equivalence of cnxxxy,
 *                  cixxx,... arrays
 */
#define lrwmax 26
/*
 *                  max number of l value, row information
 *                  for equivalence of rnxxxy, rixxx,...
 *                  arrays
 */
#define rgemax 65
/*
 *                  max number of columns in a range
 *                  preferred value = 1+2**n
 *                  for some n .ge. 1
 *                  caution:  change may affect dermax
 */
#define dermax 6001
/*
 *                  max number of nonzeros of range
 *                  vectors for one block
 *                  caution: must be at least max of rowmax
 *                  and rgemax**2
 */
#define covmax 6
/*
 *                  max row count used for sat/minsat
 *                  enumeration
 */
#define selmax 5
/*
 *                  max number of selected columns used
 *                  for selection process (see enufx2)
 */
#define scsmax 10
/*                  max number of combination cases for
 *                  the columns selected (see enufx2)
 *                  must be >= selmax
 */
#define prcmax 5
/*
 *                  max number of precision levels for
 *                  approximate minimization via lp and
 *                  sat/minsat
 *                  caution:  value must be at least 2
 *                  enumeration
 */
#define casmax 32
/*
 *                  max number of cases arising from
 *                  precision levels
 *                  caution: must be = 2**prcmax
 */
#define aggmax 5
/*
 *                  max number of fixed variables for which
 *                  aggregation method of enumeration of
 *                  enufx1 is used
 */
#define namemax 32  
/*
 *                  max length of file name extension
 *                  count does not include end of string 
 *                  character
 */
#define logfilmax 32  
/*
 *                  max number of log input files
 */
/*  last record of exparms.h***** */
