/*  first record of leibnizdefs.h***** */
/*
 *  element names and equivalent integers
 */
/*
 *  index limits of predicates
 */
/*
 *  predicate use with parentheses
 */
/*
 *  allocation for predicates
 */
/*
 *  propositional variables
 */
long A5_1;
long dd12Price1_dPrice12_1;
long ddMgtEff_d12Price1_1;
/*
 *  procedure status_element
 */
void sts_elt(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {

  void trserrmsg();
  void disprm();

  static long flg=0, nes;
  long i;
  char ucomnd[64+1];
  static char tenm[1][1];

  strcpy(ucomnd,"sts_elt");
/*
 *  initialize list of element names
 */
  if (flg==0) {
    nes = 0;
    flg = 1;
  }
/*
 *  store total number of elements in value[2]
 */
  uvalue[2] = 0;
  if (uvalue[0] < 0) {
    uerror[0] = 0;
    return;
  }
/*
 *  know that uvalue[0] >= 0
 */
  if (nes==0) {
/*
 *  error, no elements specified in .log file
 */
    uerror[0] = 3;
    trserrmsg(2030);
    disprm(ucomnd,uname,ustate,utype,uvalue,uerror);
    return;
  }
  if (uvalue[0]==0) {
/*
 *  find index for given element name
 */
    uname[128] = '\0';
    for (i=1;i<=nes;i++) {
      if (strcmp(uname,&tenm[i-1][0])==0) {
        uvalue[1] = i;
        uerror[0] = 0;
        return;
      }
    }
/*
 *  uname string is not in element name list
 */
    uerror[0] = 2;
    trserrmsg(1450);
    disprm(ucomnd,uname,ustate,utype,uvalue,uerror);
    return;
  } else {
/*
 *  find element name for given index
 *  recall that uvalue[0] >= 0
 */
    if (uvalue[0] > nes) {
      uerror[0] = 2;
      trserrmsg(1460);
      disprm(ucomnd,uname,ustate,utype,uvalue,uerror);
      return; 
    }
    strcpy(uname,&tenm[uvalue[0]-1][0]);
    uvalue[1] = uvalue[0];
    uerror[0] = 0;
    return;
  }
}
/*  last record of leibnizdefs.h***** */
