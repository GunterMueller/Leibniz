/*  first record of lbccmain.c***** */
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
/*
 *  Leibniz System
 *  Copyright 1990-2015 by Leibniz Company
 *  Plano, Texas, U.S.A.
 *  
 *  This program is free software: you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free Software
 *  Foundation, either version 3 of the License, or (at your option) any later
 *  version. The License statement is in file lgpl.txt, but can also be obtained
 *  from www.gnu.org/licenses/.
 *
 *  We do not make any representation or warranty, expressed or implied, 
 *  as to the condition, merchantability, title, design, operation, or fitness 
 *  of the program for a particular purpose.
 *
 *  We do not assume responsibility for any errors, including mechanics or logic, 
 *  in the operation or use of the program, and have no liability whatsoever 
 *  for any loss or damages suffered by any user as a result of the program.
 * 
 *  In particular, in no event shall we be liable for special, incidental, 
 *  consequential, or tort damages, even if we have been advised of the 
 *  possibility of such damages.
 *
 * ===================================================
 * Leibniz System Compiler - Main Program
 * ===================================================
 */
int main() {
/*
 */
  void exdyn_alloc();
  void exdyn_free();
  void getparm();
  void lbcc();
/*
 *  begin program body
 *--------------------
 *
 *  open error file errfil with temporary name leibnizparams.err
 */
  errfil = fopen("leibnizparams.err", "w");
  if (errfil == NULL) {
    printf(
      "\nCannot open error file leibnizparams.err. Stop\n");
    lbccexit(1);
  }
/*
 *  define parameters using leibnizparams.dat
 *  argument of getparm() is empty string since
 *  leibnizparams.dat is expected in current directory
 */
  getparm("");
/*
 *  close errfil and reopen with correct name
 */
  fclose(errfil);
  errfil = fopen(errfil_name, "w");
  if (errfil == NULL) {
    printf(
     "\nCannot open error file %s. Stop\n",errfil_name);
    lbccexit(1);
  }
/*
 *  allocate for execution
 */
  exdyn_alloc();
/*
 *  translate .log file and generate program
 */
  lbcc();
/*
 *  deallocate execution arrays
 */
  exdyn_free();
/*
 *  close errfil
 */
  fclose(errfil);
/*
 *  done
 */
  lbccexit(0);
  exit(0); /* added to suppress compiler error message */
}
/*  last record of lbccmain.c***** */
