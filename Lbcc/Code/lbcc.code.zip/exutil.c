/*  first record of exutil.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();
/*
 * *******************************************************
 *  module utility routines
 * 
 *  contains:
 *    calmem    calculates memory required
 *    cbllim    calculates block limits
 *    chksol    check solution
 *    ckfisl    check solution, without text display
 *    count     compute all cnxxx, rnxxx arrays.
 *    cost/goal subroutines (module)
 *      cstprb     
 *      cstxpr     
 *      gusxpr
 *    disprm     execution display of parameters     
 *    errmsg     execution error messages type LBEX
 *    extraction subroutines (module)
 *      xaact
 *      xaart
 *      xqatf
 *      xcomp
 *      xd1
 *      xe1
 *      xnoatf
 *      xstrfx
 *      xstrip
 *    fcindx     finds column index of variable uname
 *    get/put subroutines (module)
 *      finmat
 *      getprg
 *      getnum
 *      getalp
 *      getrec
 *      putprg
 *      putnum
 *      putalp
 *      putrec
 *    index subroutines (module)
 *      icfxfr
 *      icfrfx
 *      icfrin
 *      icfxin
 *      icacin
 *      icinfr
 *      icinfx
 *      icinac
 *      iracin
 *      irinac
 *      urinac
 *    initil    initializes various parameters.
 *    injatf    inject atf part.
 *    insertion subroutines (module)
 *    moving    subroutines (module)
 *      mcfxfr
 *      mcfrfx
 *      mcfrin
 *      mcfxin
 *      mcinfr
 *      mcinfx
 *      mracin
 *      mrinac
 *    permut    calculates permutations for 1..6
 *    retain    retained index information
 *    scanning  subroutines (module)
 *      sclall
 *      sclact
 *      sclina
 *      srwall
 *      srwact
 *      srwina
 *    scalcl    scales a column.
 *    rstats    computes reduced summary statistics
 *    transfer subroutines, internal (module)
 *      trancnf
 *      trancpr
 *      tranpr
 *      trancl
 *      tranrw
 *      tranam
 *      tprblk
 *      tblkpr
 *    transfer process, external
 *      trserrmsg     handle transfer error message
 *      trsleibtovar  transfer from leibniz to trsvar
 *      trsvartoleib  transfer from trsvar to leibniz
 *    wrtcnf    write out cnf formulation in layer 1
 * *******************************************************
 */
/*eject*/
/* *******************************************************
 *  subroutine calmem
 * 
 *  purpose: calculates total memory required
 * 
 * 
 * *******************************************************
 * 
 */
void calmem() {
/*
 */
  totmem=4*
      (46*colmax+56*rowmax+16*blkmax+
/*
 *  range data
 */
      dermax*(blkmax+4)+rgemax*(9*blkmax+14)+
/*
 *  matrix data
 */
      (anzmax+2*colmax)*(laymax+2)+
      (anzmax+2*rowmax)*(laymax+2)+
/*
 *  cl and rw data
 */
      (colmax+2)*lclmax*laymax+
      (rowmax+2)*lrwmax*laymax+
/*
 *  problem storage
 */
      10*prbmax+stomax*(pgrmax/4+1))/1000+31;
/*
 */
  return;
}
/*eject*/
/* 
 * 
 * ********************************************************
 *  subroutine cbllim
 * 
 *  calculate lcllim, ucllim, lrwlim, urwlim
 *  for all blocks q, where lcllim(q) is the starting column
 *  index of layer 1 block q info,
 *  and ucllim(q) is the ending column index for block q.
 *  the convention is similar for lrwlim(q) and urwlim(q).
 *  input:  problem with block indices ciblk(j), riblk(i)
 *  is in layer 1.
 * 
 *  output: nblks, and for all blocks q = 1..nblks: lcllim(q),
 *          ucllim(q), lrwlim(q), urwlim(q)
 * ********************************************************
 * 
 */
void cbllim() {
/*
 */
  static long j,jx,ix,q;
/*
 *  compute nblks
 */
  nblks=0;
  for(j=1; j<=ncols; j++)  {
    if (ciblk_(j)>nblks) {
      nblks=ciblk_(j);
    }
  }
/*
 *  compute block limits
 */
  for(q=1; q<=nblks; q++)  {
    lcllim_(q)=0;
    ucllim_(q)=0;
    lrwlim_(q)=0;
    urwlim_(q)=0;
  }
/*
 *  compute column limits
 */
  for(jx=1; jx<=ncols; jx++)  {
    if (lcllim_(ciblk_(jx))==0) {
      lcllim_(ciblk_(jx))=jx;
      ucllim_(ciblk_(jx))=jx;
    } else {
      ucllim_(ciblk_(jx))=jx;
    }
  }
/*
 *  now, compute row limits
 */
  for(ix=1; ix<=nrows; ix++)  {
    if (lrwlim_(riblk_(ix))==0) {
      lrwlim_(riblk_(ix))=ix;
      urwlim_(riblk_(ix))=ix;
    } else {
      urwlim_(riblk_(ix))=ix;
    }
  }
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine chksol                                      
 *                                                         
 *  purpose:  checks solution.                             
 *                                                         
 *  caution:  execution of this routine assumes that enudec 
 *            has been executed.                                    
 *                                                         
 * ******************************************************
 * 
 */
void chksol() {
/*
 */
  static long i,j,jx,row;
/*
 */
  if (succss==0) {
    if (accflg == 1) {
      printf("Problem is not satisfiable\n");
    }
    return;
  }
  for(i=1; i<=nrows; i++)  {
    row=i;
    if (riina_(i)!=0) {
      goto zz100;
    }
    if (rhs1_(i)==0) {
      goto zz100;
    }
    if (nzamar_(i)==0) {
      goto zz250;
    }
    for(jx=1; jx<=nzamar_(i); jx++)  {
      j=abs(amatrw_(jx+ptamar_(i)));
      if ((solut1_(j)*amatrw_(jx+ptamar_(i)))>0) {
        goto zz100;
      }
    }
/*
 *  solution incorrect (no +1 in current row)
 */
    zz250:;
    printf("No Solution Found for ROW = %ld\n",row);
    fprintf(errfil,
            "No Solution Found for ROW = %ld\n",row);
    error(" chksol ","  252   ");
  zz100:;}
  if (accflg == 1) {
    printf("Problem is satisfiable\n");
  }
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine ckfisl(perror)
 * 
 *  purpose:  checks solution for execution module.
 *            similar to  chksol, except that no text is
 *            displayed, and perror is set to the row (row)
 *            if an error in the solution is  encountered.
 * 
 *  caution:  execution of this routine assumes that enudec
 *            has been executed.
 * 
 * *********************************************************
 * 
 */
void ckfisl(short *perror) { 
/*
 */
  static long i,j,jx,row;
/*
 */
  if (succss==0) {
/*
 *  problem is not satisfiable
 */
    return;
  }
  for(i=1; i<=nrows; i++)  {
    row=i;
    if (riina_(i)!=0) {
      goto zz100;
    }
    if (rhs1_(i)==0) {
      goto zz100;
    }
    if (nzamar_(i)==0) {
      goto zz250;
    }
    for(jx=1; jx<=nzamar_(i); jx++)  {
      j=abs(amatrw_(jx+ptamar_(i)));
      if ((solut1_(j)*amatrw_(jx+ptamar_(i)))>0) {
        goto zz100;
      }
    }
/*
 *  solution incorrect (no +1 in current row)
 */
    zz250:;
    perror[(1-1)]=row;
    return;
  zz100:;}
/*
 *  problem is satisfiable
 */
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine count
 * 
 *  purpose:  count the number of entries in rows and columns
 *            to establish  cnxxxy(j) for all j, and rnxxxy(i)
 *            for all i
 *  required: all cixxx and rixxx vectors
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where                what was changed/reason
 * --------------------------------------------------------
 * ********************************************************
 * 
 */
void count() {
/*
 */
  static long j,jx,i,ix;
  void sclact();
  void sclina();
  void srwfix();
  void srwfre();
  void srwina();
/*
 *  -------------------------------------------------------
 *  step 1
 *  for all columns, update the column counts over row type
 *  -------------------------------------------------------
 */
  for(j=1; j<=ncols; j++)  {
/*
 *  count down a column over active rows
 */
    sclact(j);
    cnact_(j)=clacti_(rowmax+1);
    cnactp_(j)=0;
    cnactn_(j)=0;
    if (clacti_(rowmax+1)>=1) {
      for(ix=1; ix<=clacti_(rowmax+1); ix++)  {
        if (centry_(ix)==1) {
          cnactp_(j)=cnactp_(j)+1;
        } else {
          cnactn_(j)=cnactn_(j)+1;
        }
      }
    }
/*
 *  count over inactive rows
 */
    sclina(j);
    cnina_(j)=clinai_(rowmax+1);
    cninap_(j)=0;
    cninan_(j)=0;
    if (clinai_(rowmax+1)>=1) {
      for(ix=1; ix<=clinai_(rowmax+1); ix++)  {
        if (centry_(ix)==1) {
          cninap_(j)=cninap_(j)+1;
        } else {
          cninan_(j)=cninan_(j)+1;
        }
      }
    }
/*
 *  compute cnall values
 */
    cnallp_(j)=cnactp_(j)+cninap_(j);
    cnalln_(j)=cnactn_(j)+cninan_(j);
    cnall_(j)=cnallp_(j)+cnalln_(j);
  }
/*
 *  -------------------------------------------------------
 *  step 2
 *  for all rows, update the row counts over column type
 *  -------------------------------------------------------
 */
  for(i=1; i<=nrows; i++)  {
/*
 *  count over free columns
 */
    srwfre(i);
    rnfre_(i)=rwfrej_(colmax+1);
    rnfrep_(i)=0;
    rnfren_(i)=0;
    if (rwfrej_(colmax+1)>=1) {
      for(jx=1; jx<=rwfrej_(colmax+1); jx++)  {
        if (rentry_(jx)==1) {
          rnfrep_(i)=rnfrep_(i)+1;
        } else {
          rnfren_(i)=rnfren_(i)+1;
        }
      }
    }
/*
 *  count over fixed columns
 */
    srwfix(i);
    rnfix_(i)=rwfixj_(colmax+1);
    rnfixp_(i)=0;
    rnfixn_(i)=0;
    if (rwfixj_(colmax+1)>=1) {
      for(jx=1; jx<=rwfixj_(colmax+1); jx++)  {
        if (rentry_(jx)==1) {
          rnfixp_(i)=rnfixp_(i)+1;
        } else {
          rnfixn_(i)=rnfixn_(i)+1;
        }
      }
    }
/*
 *  count over inactive columns
 */
    srwina(i);
    rnina_(i)=rwinaj_(colmax+1);
    rninap_(i)=0;
    rninan_(i)=0;
    if (rwinaj_(colmax+1)>=1) {
      for(jx=1; jx<=rwinaj_(colmax+1); jx++)  {
        if (rentry_(jx)==1) {
          rninap_(i)=rninap_(i)+1;
        } else {
          rninan_(i)=rninan_(i)+1;
        }
      }
    }
/*
 *  compute row counts over active columns
 */
    rnactp_(i)=rnfrep_(i)+rnfixp_(i);
    rnactn_(i)=rnfren_(i)+rnfixn_(i);
    rnact_(i)=rnfre_(i)+rnfix_(i);
/*
 *  compute row counts over all columns
 */
    rnallp_(i)=rnactp_(i)+rninap_(i);
    rnalln_(i)=rnactn_(i)+rninan_(i);
    rnall_(i)=rnact_(i)+rnina_(i);
  }
  return;
}
/*eject*/
/*
 * ********************************************************
 *   module cost/goal routines
 * 
 *  contains
 *     cstprb   - compute internal total costs
 *     cstxpr   - compute external total costs
 *     gusxpr   - compute external goal usage
 * 
 * ********************************************************
 * 
 * ********************************************************
 *  subroutine cstprb
 * 
 *  purpose:  computes total cost for strip qblock in
 *            layer 1, puts into prcost
 * 
 *    input:  problem in layer 1 with cost and solut1.
 *            qblock
 * 
 *   output:  prcost = total cost of strip qblock
 * 
 * ********************************************************
 * 
 */
void cstprb() {
/*
 */
  static long j;
/*
 */
  prcost=0;
  for(j=lcllim_(qblock); j<=ucllim_(qblock); j++)  {
    prcost=prcost+cost_(j)*solut1_(j);
  }
  return;
}
/*
 * ********************************************************
 *  subroutine cstxpr
 * 
 *  purpose:  computes total external cost of solved problem,
 *            with solution given by solut1 and ciina indices
 * 
 *    input:  solved problem in layer 1
 * 
 *   output:  prcost = total external cost of solved problem
 * 
 * ***********************************************************
 * 
 */
void cstxpr() {
/*
 */
  static long j;
/*
 *  compute total cost
 */
  prcost=0;
  for(j=1; j<=ncolsx; j++)  {
    jnam=idxclx_(j);
    jscan=idxcol_(jnam);
    if (ciact_(jscan)>0) {
      if (solut1_(jscan)*scale_(jscan)==1) {
        prcost=prcost+trucst_(jnam);
      } else {
        if (solut1_(jscan)*scale_(jscan)==-1) {
          prcost=prcost+falcst_(jnam);
        }
      }
    }
    if ((ciina_(jscan)==1)||
        (ciina_(jscan)==-1)) {
      if (ciina_(jscan)*scale_(jscan)==1) {
        prcost=prcost+trucst_(jnam);
      } else {
        if (ciina_(jscan)*scale_(jscan)==-1) {
          prcost=prcost+falcst_(jnam);
        }
      }
    }
  }
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine gusxpr
 * 
 *  purpose:  computes total external goal usage solved
 *            problem, with solution given by solut1 and ciina
 *            indices.
 *            usage computation includes deleted goal rows.
 *            then computes total external goal costs, not
 *            including deleted goal rows.
 * 
 *    input:  solved problem in layer 1
 * 
 *   output:  goalus(i) = external goal usage for each goal
 *            row i quantity is computed even if goal row has
 *            been deleted
 *            prcst = total cost of goal usage
 * ********************************************************
 * 
 */
void gusxpr() {
/*
 */
  static long i,j;
/*
 *  initialize external goal usage
 */
  for(i=1; i<=nrows; i++)  {
    if (glflg_(i)==1) {
      goalus_(i)=0;
    }
  }
/*
 *  compute external usage
 *  applying solution in solut1(j) and ciina(j)
 */
  for(j=1; j<=ncols; j++)  {
    i=idxgol_(j);
    if (i>0) {
      if (ciact_(j)>0) {
        if (solut1_(j)*scale_(j)==1) {
          goalus_(i)=goalus_(i)+(gcoeff_(j)*scale_(j));
        }
      } else {
        if (ciina_(j)*scale_(j)==1) {
          goalus_(i)=goalus_(i)+(gcoeff_(j)*scale_(j));
        }
      }
    }
  }
/*
 *  compute total costs of active goal rows
 */
  prcost=0;
  for(i=1; i<=nrows; i++)  {
    if ((glflg_(i)==1)&&
        (riina_(i)!=2)) {
      if (goalus_(i)>goalxq_(i)) {
/*
 *  have high goal usage
 */
        prcost=prcost+
            (ghicst_(i)*(goalus_(i)-goalxq_(i)));
      } else {
        if (goalus_(i)<goalxq_(i)) {
/*
 *   have low usage
 */
          prcost=prcost+
              (glocst_(i)*(goalxq_(i)-goalus_(i)));
        }
      }
    }
  }
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine disprm(ucomnd,uname,ustate,utype,uvalue,uerror)
 * 
 *  purpose:  displays parameters passed to leibniz
 *            on screen if specified
 *            always records parameters in errfil file
 * 
 * *******************************************************
 * 
 */
void disprm(char *ucomnd,char *uname,char *ustate,
            char *utype,long *uvalue,short *uerror) {
/*
 * size of arrays
 * ucomnd[64+1];
 * uname[128+1];
 * ustate[1+1];
 * utype[4+1];
 * uvalue[8];
 * uerror[2];
 */
  void leibnizerroraction();
/*
 */
  static char val[11];
  static long i;
/*
 *  write on screen if scrflg == 1
 */
  if (scrflg==1) {
    printf("\nprocedure = %s",ucomnd);
    printf("\nname = %s",uname);
    printf("\nstate = %s",ustate);
    printf("\ntype = %s",utype);
    printf("\nvalue = ");
    for (i=1; i<=8; i++) {
      sprintf(val,"   %ld",uvalue_(i));
      printf(val);
    }
    printf("\nerrcde = %hd    %hd",
                   uerror_(1),uerror_(2));
    printf(
      "\n**********************************\n");
    printf("\n");
  }
  if (errfil!=NULL) {
    fprintf(errfil,"\ncomnd = %s",ucomnd);
    fprintf(errfil,"\nname = %s",uname);
    fprintf(errfil,"\nstate = %s",ustate);
    fprintf(errfil,"\ntype = %s",utype);
    fprintf(errfil,"\nvalue = ");
    for (i=1; i<=8; i++) {
      sprintf(val,"   %ld",uvalue_(i));
      fprintf(errfil,val);
    }
    fprintf(errfil,"\nerrcde = %hd    %hd",
                     uerror_(1),uerror_(2));
    fprintf(errfil,"\n");
    fprintf(errfil,
      "\n**********************************\n");
  } else {
    printf("\nno error output to error file since\n"
           "that file has not yet been opened\n");
  }
/*
 *  test for error termination
 */
  execerr_(uerror_(1))++;
  if (execerr_(uerror_(1))>execerrmax_(uerror_(1))) {
    leibnizerroraction(uerror_(1));
  }
/*
 */
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine errmsg
 * 
 *  purpose:  writes message associated with errval to
 *            screen if scrflg=1, and also to errfil file
 * 
 * *******************************************************
 * 
 */
void errmsg() {
/*
 */
  static char msg[256+1];
  void error();
/*
 *  warning messages
 * 
 */
  if (errval==0010) {
    strcpy(msg,
    "WARNING: LBEX0010: Problem was not loaded");
    goto zz100;
  }
/*
 */
  if (errval==0020) {
    strcpy(msg,
    "WARNING: LBEX0020: No matching name");
    goto zz100;
  }
/*
 */
  if (errval==0030) {
    strcpy(msg,
    "WARNING: LBEX0030: Variable may not be deleted");
    goto zz100;
  }
/*
 */
  if (errval==0040) {
    strcpy(msg,
    "WARNING: LBEX0040: Clause may not be deleted");
    goto zz100;
  }
/*
 */
  if (errval==0050) {
    strcpy(msg,
    "WARNING: LBEX0050: Problem not solved");
    goto zz100;
  }
/*
 */
  if (errval==0060) {
    strcpy(msg,
    "WARNING: LBEX0060: Problem not satisfiable");
    goto zz100;
  }
/*
 */
  if (errval==0070) {
    strcpy(msg,
  "WARNING: LBEX0060: Problem not solved by approx. min.");
    goto zz100;
  }
/*
 *  nonfatal error messages
 */
  if (errval==1010) {
    strcpy(msg,
    "ERROR: LBEX1010: assign_device, begin_problem, or"
                      " initialize_problem required");
    goto zz100;
  }
/*
 */
  if (errval==1020) {
    strcpy(msg,
    "ERROR: LBEX1020: Cannot open program file");
    goto zz100;
  }
/*
 */
  if (errval==1030) {
    strcpy(msg,
    "ERROR: LBEX1030: Unknown variable code");
    goto zz100;
  }
/*
 */
  if (errval==1040) {
    strcpy(msg,
    "ERROR: LBEX1040: Index for variable out of bounds");
    goto zz100;
  }
/*
 */
  if (errval==1060) {
    strcpy(msg,
    "ERROR: LBEX1060: Unknown variable name");
    goto zz100;
  }
/*
 */
  if (errval==1070) {
    strcpy(msg,
   "ERROR: LBEX1070: No matching clause");
    goto zz100;
  }
/*
 */
  if (errval==1080) {
    strcpy(msg,
    "ERROR: LBEX1080: State and likelihood level incompatible");
    goto zz100;
  }
/*
 */
  if (errval==1090) {
    strcpy(msg,
    "ERROR: LBEX1090: Unknown clause code");
    goto zz100;
  }
/*
 */
  if (errval==1100) {
    strcpy(msg,
    "ERROR: LBEX1100: Improper likelihood level");
    goto zz100;
  }
/*
 */
  if (errval==1110) {
    strcpy(msg,
    "ERROR: LBEX1110: Likelihood levels not compatible");
    goto zz100;
  }
/*
 */
  if (errval==1120) {
    strcpy(msg,
    "ERROR: LBEX1120: COLMAX parameter too small");
    goto zz100;
  }
/*
 */
  if (errval==1130) {
    strcpy(msg,
    "ERROR: LBEX1130: ROWMAX parameter too small");
    goto zz100;
  }
/*
 */
  if (errval==1140) {
    strcpy(msg,
    "ERROR: LBEX1140: ANZMAX parameter too small");
    goto zz100;
  }
/*
 */
  if (errval==1150) {
    strcpy(msg,
    "ERROR: LBEX1150: BLKMAX parameter too small");
    goto zz100;
  }
/*
 */
  if (errval==1160) {
    strcpy(msg,
    "ERROR: LBEX1160: Improper cost value");
    goto zz100;
  }
/*
 */
  if (errval==1170) {
    strcpy(msg,
    "ERROR: LBEX1170: Switch to minimization not allowed");
    goto zz100;
  }
/*
 */
  if (errval==1180) {
    strcpy(msg,
    "ERROR: LBEX1180: Cost change not allowed");
    goto zz100;
  }
/*
 */
  if (errval==1190) {
    strcpy(msg,
    "ERROR: LBEX1190: Unknown code for restore_problem");
    goto zz100;
  }
/*
 */
  if (errval==1200) {
    strcpy(msg,
    "ERROR: LBEX1200: Improper precision level");
    goto zz100;
  }
/*
 */
  if (errval==1210) {
    strcpy(msg,
   "ERROR: LBEX1210: Index for clause/goal out of bounds");
    goto zz100;
  }
/*
 */
  if (errval==1220) {
    strcpy(msg,
    "ERROR: LBEX1220: PRBMAX parameter too small");
    goto zz100;
  }
/*
 */
  if (errval==1230) {
    strcpy(msg,
    "ERROR: LBEX1230: STOMAX parameter too small");
    goto zz100;
  }
/*
 */
  if (errval==1240) {
    strcpy(msg,
    "ERROR: LBEX1240: Problem cannot be stored");
    goto zz100;
  }
/*
 */
  if (errval==1250) {
    strcpy(msg,
    "ERROR: LBEX1250: Unknown problem name");
    goto zz100;
  }
/*
 */
  if (errval==1260) {
    strcpy(msg,
    "ERROR: LBEX1260: Index for problem out of bounds");
    goto zz100;
  }
/*
 */
  if (errval==1270) {
    strcpy(msg,
    "ERROR: LBEX1260: There is no stored problem");
    goto zz100;
  }
/*
 */
  if (errval==1280) {
    strcpy(msg,
    "ERROR: LBEX1280: Unknown goal name");
    goto zz100;
  }
/*
 */
  if (errval==1290) {
    strcpy(msg,
    "ERROR: LBEX1290: Unknown goal code");
    goto zz100;
  }
/*
 */
  if (errval==1310) {
    strcpy(msg,
    "ERROR: LBEX1320: Goal name missing");
    goto zz100;
  }
/*
 */
  if (errval==1320) {
    strcpy(msg,
    "ERROR: LBEX1320: Unknown goal name");
    goto zz100;
  }
/*
 */
  if (errval==1330) {
    strcpy(msg,
    "ERROR: LBEX1330: Procedure requires approx. min.");
    goto zz100;
  }
/*
 */
  if (errval==1340) {
    strcpy(msg,
    "ERROR: LBEX1340: Improper goal usage coefficient");
    goto zz100;
  }
/*
 */
  if (errval==1350) {
    strcpy(msg,
    "ERROR: LBEX1350: Improper goal quantity");
    goto zz100;
  }
/*
 */
  if (errval==1360) {
    strcpy(msg,
    "ERROR: LBEX1360: Improper goal cost value");
    goto zz100;
  }
/*
 */
  if (errval==1370) {
    strcpy(msg,
    "ERROR: LBEX1370: assign_device or initialize_problem"
                     " has already been executed");
    goto zz100;
  }
/*
 */
  if (errval==1380) {
    strcpy(msg,
    "ERROR: LBEX1380: assign_device or initialize_problem" 
                     " must be called prior to free_device");
    goto zz100;
  }
/*
 */
  if (errval==1390) {
    strcpy(msg,
    "ERROR: LBEX1390: get_value cannot be used"
    " with transfer process");
    goto zz100;
  }
/*
 */
  if (errval==1400) {
    strcpy(msg,
    "ERROR: LBEX1400: limit on warnings/errors is negative");
    goto zz100;
  }
/*
 */
  if (errval==1410) {
    strcpy(msg,
    "ERROR: LBEX1410: modify_variable cannot fix, delete,"
    " or activate variables, or define initial solution");
    goto zz100;
  }
/*
 */
  if (errval==1420) {
    strcpy(msg,
    "ERROR: LBEX1420: modify_allvar requires transfer process");
    goto zz100;
  }

/*
 */
  if (errval==1430) {
    strcpy(msg,
    "ERROR: LBEX1430: prg file without parameter records");
    goto zz100;
  }
/*
 */
  if (errval==1440) {
    strcpy(msg,
    "ERROR: LBEX1440: restore_problem with state = \"V\" "
       "cannot be used with transfer process");
    goto zz100;
  }
/*
 */
  if (errval==1450) {
    strcpy(msg,
    "ERROR: LBEX1440: Unknown element name");
    goto zz100;
  }
/*
 */
  if (errval==1460) {
    strcpy(msg,
    "ERROR: LBEX1440: Index for element out of bounds");
    goto zz100;
  }
/*
 *  fatal error messages
 */
  if (errval==2010) {
    strcpy(msg,
  "ERROR: LBEX2010: Transfer process cannot handle"
  " current problem");
    goto zz100;
  }
/*
 */
  if (errval==2020) {
    strcpy(msg,
  "ERROR: LBEX2020: Incompatible Leibniz System Versions");
    goto zz100;
  }
/*
 */
  if (errval==2030) {
    strcpy(msg,
  "ERROR: LBEX2030: No elements specified");
    goto zz100;
  }
/*
 *  unknown error code
 */
  error(" errmsg ","  102   ");
  zz100:
  if (scrflg == 1) {
    printf(
      "\n**********************************\n");
    printf(msg);
  }
/*  check if error file has been opened and write to that
 *  file only if that has been done
 */ 
  if (errfil!=NULL) {
    fprintf(errfil,
      "\n**********************************\n");
    fprintf(errfil,msg);
  }
  return;
}
/*eject*/
/*
 * ********************************************************
 *  module extraction routines
 *
 *  special extraction routines for execution:
 *   these routines do not maintain counts
 *    xaact
 *    xaart
 *
 *  routines for program generation:
 *  these routines do maintain counts 
 * 
 *  extract layer 1 information and retain in layer 1.
 * 
 *  subroutine xstrip =>          subroutine xcomp =>
 *  fig. 1     :  q   :           fig. 2     :  q  :
 *        +----########----+            +----############
 *        |    #      #    |            |    #          #
 *        |    # e(1) #    |            |    #          #
 *        |    #------#    |          - ######-----+    #
 *        |    # a(q) #    |          q #    | a(q)|    #
 *        |    #------#    |          - #    +-----######
 *        |    # d(1) #    |            #          #    |
 *        |    #      #    |            #          #    |
 *        +----########----+            ############----+
 * 
 *  subroutine xd1 =>             subroutine xe1 =>
 *  fig. 3                        fig. 4
 *        +----+------+----+            +----########----+
 *        |    |      |    |            |    #  e1  #    |
 *        |    |      |    |            |    #      #    |
 *        +----+------+----+            +----########----+
 *        |    | a(q) |    |            |    | a(q) |    |
 *        +----########----+            +----+------+----+
 *        |    #  d1  #    |            |    |      |    |
 *        |    #      #    |            |    |      |    |
 *        +----########----+            +----+------+----+
 * 
 *  subroutine xaq =>
 *  fig. 5
 *        +----+------+----+
 *        |    |      |    |
 *        |    |      |    |
 *        +----########----+
 *        |    # a(q) #    |
 *        +----########----+
 *        |    |      |    |
 *        |    |      |    |
 *        +----+------+----+
 * 
 *              x-tracted portion bounded by '#'.
 *              delete those entries outside bounded region
 * 
 *  ==============
 *  update history
 *  ==============
 *  date         where              what was changed/reason
 * --------------------------------------------------------
 * 
 * ********************************************************
 * 
 * 
 * ********************************************************
 *     subroutine xaact
 * 
 *     special matrix extraction routine used in enufix
 *     and apmsol
 * 
 *     extract column part of submatrix of active columns
 *     and active rows i with rhs1(i) = 1.
 *     place into block matrix array ablkcl.
 * 
 *  caution:  ablkrw and counts cnxxxx and rnxxxx are not
 *            computed, but row pointers ptablr(i) are
 *            defined.
 * 
 * ********************************************************
 * 
 */
void xaact() {
/*
 */
  static long i,j,ixx,ix;
/*
 *  define row pointers ptablr(i)
 */
  for(i=1; i<=nrows; i++)  {
    ptablr_(i)=ptamar_(i);
  }
/*
 * extract matrix columns
 */
  for(j=1; j<=ncols; j++)  {
    ptablc_(j)=ptamac_(j);
    if (ciact_(j)==0) {
      nzablc_(j)=0;
    } else {
      ixx=0;
      if (nzamac_(j)>0) {
        for(ix=1; ix<=nzamac_(j); ix++)  {
          i=abs(amatcl_(ix+ptamac_(j)));
          if ((riact_(i)==1)&&
              (rhs1_(i)==1)) {
            ixx=ixx+1;
            ablkcl_(ixx+ptablc_(j))=amatcl_(ix+ptamac_(j));
          }
        }
      }
      nzablc_(j)=ixx;
    }
  }
  return;
}
/*
 * *********************************************************
 *     subroutine xaart
 * 
 *     special matrix extraction routine used in apmsol
 * 
 *     extract row part of submatrix of active columns and
 *     active rows i with rhs1(i) = 1.
 *     place into block matrix array ablkrw.
 * 
 *  caution:  ablkcl and counts cnxxxx and rnxxxx are not
 *            computed, but column pointers ptablc(i) are
 *            defined.
 * 
 * **********************************************************
 * 
 */
void xaart() {
/*
 */
  static long i,j,jxx,jx;
/*
 *  define column pointers ptablc(j)
 */
  for(j=1; j<=ncols; j++)  {
    ptablc_(j)=ptamac_(j);
  }
/*
 * extract matrix rows
 */
  for(i=1; i<=nrows; i++)  {
    ptablr_(i)=ptamar_(i);
    if ((riact_(i)==0)||(rhs1_(i)==0)) {
      nzablr_(i)=0;
    } else {
      jxx=0;
      if (nzamar_(i)>0) {
        for(jx=1; jx<=nzamar_(i); jx++)  {
          j=abs(amatrw_(jx+ptamar_(i)));
          if (ciact_(j)>0) {
            jxx=jxx+1;
            ablkrw_(jxx+ptablr_(i))=amatrw_(jx+ptamar_(i));
          }
        }
      }
      nzablr_(i)=jxx;
    }
  }
  return;
}
/*
 * ********************************************************
 *  subroutine xaq(q)                                      
 *                                                         
 *  extract layer 1 information as depicted by fig. 5 above 
 *  and retain in layer 1. counts are properly adjusted.       
 *  at termination layer 1 contains extracted information. 
 *                                                         
 * ********************************************************
 * 
 */
void xaq(long q) {
/*
 */
  void count();
/*
 */
  static long j,ixx,ix,i,jxx,jx;
/*
 *  adjust column entries
 */
  for(j=1; j<=ncols; j++)  {
    if (nzamac_(j)>0) {
      ixx=0;
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=abs(amatcl_(ix+ptamac_(j)));
        if ((riblk_(i)==q)&&
            (ciblk_(j)==q)) {
          ixx=ixx+1;
          amatcl_(ixx+ptamac_(j))=amatcl_(ix+ptamac_(j));
        }
      }
      nzamac_(j)=ixx;
    }
  }
/*
 *  adjust row entries as done above
 */
  for(i=1; i<=nrows; i++)  {
    if (nzamar_(i)>0) {
      jxx=0;
      for(jx=1; jx<=nzamar_(i); jx++)  {
        j=abs(amatrw_(jx+ptamar_(i)));
        if ((riblk_(i)==q)&&
            (ciblk_(j)==q)) {
          jxx=jxx+1;
          amatrw_(jxx+ptamar_(i))=amatrw_(jx+ptamar_(i));
        }
      }
      nzamar_(i)=jxx;
    }
  }
/*
 *  adjust counts
 */
  count();
  return;
}
/*
 * ********************************************************
 *  subroutine xatf
 * 
 *  extract layer 1 information as depicted by fig. 1 above, 
 *  except that only atf columns are extracted.  
 *  retain in layer 1.  counts are properly adjusted. 
 *  at termination layer 1 contains extracted information.
 * ******************************************************** 
 */
void xatf() {
/*
 */
  void count();
/*
 */
  static long j,i,jxx,jx,js;
/*
 *  adjust amatcl entries of layer 1 matrix information
 */
  for(j=1; j<=ncols; j++)  {
    if (cvatf_(j)==0) {
      nzamac_(j)=0;
    }
  }
/*
 *  adjust amatrw entries
 */
  for(i=1; i<=nrows; i++)  {
    jxx=0;
    if (nzamar_(i)!=0) {
      for(jx=1; jx<=nzamar_(i); jx++)  {
        js=amatrw_(jx+ptamar_(i));
        j=abs(js);
        if (cvatf_(j)!=0) {
          jxx=jxx+1;
          amatrw_(jxx+ptamar_(i))=js;
        }
      }
      nzamar_(i)=jxx;
    }
  }
/*
 *  update counts
 */
  count();
  return;
}
/*
 * ********************************************************
 *  subroutine xcomp(q)
 *
 *  extract layer 1 information as depicted by fig. 2 above 
 *  and retain in layer 1. counts are properly adjusted.
 *  at termination layer 1 contains extracted information.
 * 
 * ********************************************************
 * 
 */
void xcomp(long q) {
/*
 */
  void count();
/*
 */
  static long j,ixx,ix,i,jxx,jx;
/*
 *  adjust column entries
 */
  for(j=1; j<=ncols; j++)  {
    if (nzamac_(j)>0) {
      ixx=0;
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=abs(amatcl_(ix+ptamac_(j)));
        if (((riblk_(i)>=q)||
            (ciblk_(j)>=q))&&
            ((riblk_(i)<=q)||
            (ciblk_(j)<=q))) {
          ixx=ixx+1;
          amatcl_(ixx+ptamac_(j))=amatcl_(ix+ptamac_(j));
        }
      }
      nzamac_(j)=ixx;
    }
  }
/*
 *  adjust row entries as done above
 */
  for(i=1; i<=nrows; i++)  {
    if (nzamar_(i)>0) {
      jxx=0;
      for(jx=1; jx<=nzamar_(i); jx++)  {
        j=abs(amatrw_(jx+ptamar_(i)));
        if (((riblk_(i)>=q)||
            (ciblk_(j)>=q))&&
            ((riblk_(i)<=q)||
            (ciblk_(j)<=q))) {
          jxx=jxx+1;
          amatrw_(jxx+ptamar_(i))=amatrw_(jx+ptamar_(i));
        }
      }
      nzamar_(i)=jxx;
    }
  }
/*
 *  adjust counts
 */
  count();
  return;
}
/*
 * ***********************************************************
 *  subroutine xd1(q)
 * 
 *  extract layer 1 information as depicted by fig. 3 above 
 *  and retain in layer 1. counts are properly adjusted.
 *  at termination layer 1 contains extracted information.
 * 
 * ***********************************************************
 * 
 */
void xd1(long q) {
/*
 */
  void count();
/*
 */
  static long j,ixx,ix,i,jxx,jx;
/*
 *  adjust column entries
 */
  for(j=1; j<=ncols; j++)  {
    if (ciblk_(j)!=q) {
      cost_(j)=0;
    }
    if (nzamac_(j)>0) {
      ixx=0;
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=abs(amatcl_(ix+ptamac_(j)));
        if ((riblk_(i)>q)&&
            (ciblk_(j)==q)) {
          ixx=ixx+1;
          amatcl_(ixx+ptamac_(j))=amatcl_(ix+ptamac_(j));
        }
      }
      nzamac_(j)=ixx;
    }
  }
/*
 *  adjust row entries as done above
 */
  for(i=1; i<=nrows; i++)  {
    if (nzamar_(i)>0) {
      jxx=0;
      for(jx=1; jx<=nzamar_(i); jx++)  {
        j=abs(amatrw_(jx+ptamar_(i)));
        if ((riblk_(i)>q)&&
            (ciblk_(j)==q)) {
          jxx=jxx+1;
          amatrw_(jxx+ptamar_(i))=amatrw_(jx+ptamar_(i));
        }
      }
      nzamar_(i)=jxx;
    }
  }
/*
 *  adjust counts
 */
  count();
  return;
}
/*
 * *********************************************************
 *  subroutine xe1(q)
 *
 *  extract layer 1 information as depicted by fig. 4 above
 *  and retain in layer 1. counts are properly adjusted.
 *  at termination layer 1 contains extracted information.
 *
 * *********************************************************
 * 
 */
void xe1(long q) {
/*
 */
  void count();
/*
 */
  static long j,ixx,ix,i,jxx,jx;
/*
 *  adjust column entries
 */
  for(j=1; j<=ncols; j++)  {
    if (ciblk_(j)!=q) {
      cost_(j)=0;
    }
    if (nzamac_(j)>0) {
      ixx=0;
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=abs(amatcl_(ix+ptamac_(j)));
        if ((riblk_(i)<q)&&
            (ciblk_(j)==q)) {
          ixx=ixx+1;
          amatcl_(ixx+ptamac_(j))=amatcl_(ix+ptamac_(j));
        }
      }
      nzamac_(j)=ixx;
    }
  }
/*
 *  adjust row entries as done above
 */
  for(i=1; i<=nrows; i++)  {
    if (nzamar_(i)>0) {
      jxx=0;
      for(jx=1; jx<=nzamar_(i); jx++)  {
        j=abs(amatrw_(jx+ptamar_(i)));
        if ((riblk_(i)<q)&&
            (ciblk_(j)==q)) {
          jxx=jxx+1;
          amatrw_(jxx+ptamar_(i))=amatrw_(jx+ptamar_(i));
        }
      }
      nzamar_(i)=jxx;
    }
  }
/*
 *  adjust counts
 */
  count();
  return;
}
/*
 * ******************************************************
 *  subroutine xnoatf
 *
 *  extract layer 1 information as depicted by fig. 1 above,
 *  except that non-atf columns are extracted.  
 *  retain in layer 1. counts are properly adjusted. 
 *  at termination layer 1 contains extracted information.
 *
 * *******************************************************
 * 
 */
void xnoatf() {
/*
 */
  void count();
/*
 */
  static long j,i,jxx,jx,js;
/*
 *  adjust amatcl entries of layer 1 matrix information
 */
  for(j=1; j<=ncols; j++)  {
    if (cvatf_(j)!=0) {
      nzamac_(j)=0;
    }
  }
/*
 *  adjust amatrw entries
 */
  for(i=1; i<=nrows; i++)  {
    jxx=0;
    if (nzamar_(i)!=0) {
      for(jx=1; jx<=nzamar_(i); jx++)  {
        js=amatrw_(jx+ptamar_(i));
        j=abs(js);
        if (cvatf_(j)==0) {
          jxx=jxx+1;
          amatrw_(jxx+ptamar_(i))=js;
        }
      }
      nzamar_(i)=jxx;
    }
  }
/*
 *  update counts
 */
  count();
  return;
}
/*
 * ****************************************************
 *  subroutine xstrfx(q)
 * 
 *  extract layer 1 information as depicted by fig. 1 above,
 *  except that only fixed columns are extracted.  
 *  retain in layer 1. counts are properly adjusted. 
 *  at termination layer 1 contains extracted information.
 *
 * *****************************************************
 * 
 */
void xstrfx(long q) {
/*
 */
  void count();
/*
 */
  static long j,i,jxx,jx,js;
/*
 *  adjust amatcl and cost entries of layer 1 matrix 
 *  information
 */
  for(j=1; j<=ncols; j++)  {
    if ((ciblk_(j)!=q)||
        (cifix_(j)==0)) {
      nzamac_(j)=0;
      cost_(j)=0;
    }
  }
/*
 *  adjust amatrw entries
 */
  for(i=1; i<=nrows; i++)  {
    jxx=0;
    if (nzamar_(i)!=0) {
      for(jx=1; jx<=nzamar_(i); jx++)  {
        js=amatrw_(jx+ptamar_(i));
        if ((ciblk_(abs(js))==q)&&
            (cifix_(abs(js))!=0)) {
          jxx=jxx+1;
          amatrw_(jxx+ptamar_(i))=js;
        }
      }
      nzamar_(i)=jxx;
    }
  }
/*
 *  update counts
 */
  count();
  return;
}
/*
 * *****************************************************
 *  subroutine xstrip(q)
 *
 *  extract layer 1 information as depicted by fig. 1 above 
 *  and retain in layer 1. counts are properly adjusted.
 *  at termination layer 1 contains extracted information.
 *
 * ******************************************************
 * 
 */
void xstrip(long q) {
/*
 */
  void count();
/*
 */
  static long j,i,jxx,jx,m;
/*
 *  adjust amatcl and cost entries of layer 1 matrix 
 *  information
 */
  for(j=1; j<=ncols; j++)  {
    if (ciblk_(j)!=q) {
      nzamac_(j)=0;
      cost_(j)=0;
    }
  }
/*
 *  adjust amatrw entries
 */
  for(i=1; i<=nrows; i++)  {
    jxx=0;
    if (nzamar_(i)!=0) {
      for(jx=1; jx<=nzamar_(i); jx++)  {
        m=abs(amatrw_(jx+ptamar_(i)));
        if (ciblk_(m)==q) {
          jxx=jxx+1;
          amatrw_(jxx+ptamar_(i))=amatrw_(jx+ptamar_(i));
        }
      }
      nzamar_(i)=jxx;
    }
  }
/*
 *  update counts
 */
  count();
  return;
}
/*eject*/
/*
 * ***************************************************
 *  subroutine fcindx(uname,uerror)
 * 
 *  purpose: finds column index of variable uname.
 * 
 * ***************************************************
 */
void fcindx(char *uname,short *uerror) {
/*
 * size of arrays
   uname[128+1];
   uerror[2];
 */
  static long j;
/*
 */
  void errmsg(); void disprm();
/*
 *  check for '*' in column 1
 */
  if (uname_(1) == '*') {
    uerror_(1)=nftl;
    errval=1060;
    errmsg();
/*
 *  unknown variable name
 */
    return;
  }
  for(j=1; j<=ncolsx; j++)  {
    jnam=idxclx_(j);
    if (strcmp(uname,&colnam_(1,jnam))==0) {
/*
 *  have a match
 */
      jscan=idxcol_(jnam);
      return;
    }
/*
 */
  }
/*
 *  unknown variable name
 */
  uerror_(1)=nftl;
  errval=1060;
  errmsg();
  return;
}
/*eject*/
/*
 * *******************************************************
 *  module get/put routines
 * 
 *  all get and put routines for reading, writing, storing,
 *  or retrieving problems.
 * 
 *  calling sequence of routines:
 *
 *   finmat        finish processing of cnf formulation
 * 
 *   getprg        read from disk or retrieve 
 *                 a problem from storage
 *     getnum      get an integer
 *     getalp      get a character
 *       getrec    get a record from disk or storage
 * 
 *   putprg        write a problem to disk or 
 *                 put into storage
 *     putnum      put an integer
 *     putalp      put a character
 *       putrec    put a record on disk or into storage
 * 
 *   definitions of variables:
 * 
 *   records:
 *    irec        index for records in do loops
 *    currec      index of currently processed record
 *    fstrec      index of first free record in 
 *                storec array
 *                 = 0  => there is no free record
 *    lstrec      index of last free record in storec array
 *                if fstrec = 0 (i.e., if there is no free
 *                record), lstrec is undefined
 *    nfrrec      number of free records of storec array
 *    usdrec      number of records used for storing one
 *                problem
 *    nrecs       bound on maximum number of records
 *                that the currently loaded problem may
 *                ever require in storec array
 * 
 *  problem storage
 * 
 *    storec      character array for storing problems.
 *                each record in storec has length pgrmax 
 *                and follows the format for .prg files, 
 *                except that the header section is omitted.
 *    nxtrec(currec) index of record of storec array that is 
 *                to be read or used following the record 
 *                with index currec.
 * 
 *                nxtrec(prbend(lprb)) = 0 for any lprb >= 2.
 *                      thus, thethe last record of each stored
 *                      problem has nxtrec() index equal to 0.
 *                nxtrec(lstrec) = 0
 *                       thus, the last free record has the
 *                       nxtrec() index equal to 0). 
 *                       this is defined only if there are 
 *                       free records, that is, if fstrec > 0.
 * 
 *    prbbeg(lprb) index of first record of stored problem indexed
 *                 by lprb. is not defined for lprb = 1.
 * 
 *    prbend(lprb) index of last record of stored problem indexed
 *                 by lprb. is not defined for lprb = 1.
 * 
 *    prbsiz(lprb) number of records used to store the problem
 *                 indexed by lprb. is not defined for lprb = 1.
 * 
 *    prbnam(1,lprb) name of problem indexed by lprb.
 *                 lprb = 1  => currently loaded problem
 *                 lprb > 1  => stored problem
 * 
 *    lprb         index for problem ( <= prbmax required)
 *                 lprb = 1  => currently loaded problem
 *                 lprb > 1  => stored problem
 * 
 *    nprbs        total number of problems (currently loaded or
 *                 stored)
 * 
 *    stoflg       storage flag
 *                 stoflg = 0  => do not store, but instead count
 *                                number of records for currently
 *                                loaded problem and put int nrecs
 *                                (nrecs is subsequently increase
 *                                so that it is the desired upper 
 *                                bound on max number of records 
 *                                ever required to store problem.
 * 
 *                 stoflg = 1  => if lprb = 1: write currently 
 *                                  loaded problem onto disk
 *                                  note: can write out a problem
 *                                  only when loaded, and not
 *                                  when stored.
 *                                if lprb > 1: put currently 
 *                                  loaded problem into storage.
 *                                  lprb is index of the stored 
 *                                  problem.
 * 
 *                  stoflg =-1  => if lprb = 1: read problem from
 *                                  disk (fortran) or from file
 *                                  pointer (c) and load.
 *                                if lprb > 1: load problem having
 *                                  problem index lprb.
 * 
 *    caution: stored problem may be referred from the outside
 *             by name only since the relationship between names
 *             and problem indices is changed by problem deletions
 *             and even problem storage (since a storage may 
 *             trigger first deletion of a stored problem 
 *             with same name).
 * 
 * ===============
 *  update history
 *  ==============
 *  date       where                  what was changed/reason
 * ----------------------------------------------------------
 * 
 * **********************************************************
 *
 * *******************************************************
 *  subroutine finmat
 * 
 *  purpose:  finish processing of cnf formulation
 *            that is stored in amatrw, cl, rw
 *
 *             - store matrix data in amatcl
 *             - introduce artificial variable and row, 
 *               in block 1
 *             - compute counts, block limits
 *             - scale columns with negative costs
 *             - construct external index array
 *             - initialize various flags
 * 
 *    input:  matrix given by rows only in amatrw
 * 
 *   output:  complete matrix, column and row information
 *            ready for program generation
 * 
 *  caution:  row counts nzamar must be already correct 
 * 
 * *******************************************************
 * 
 */
void finmat() {
/*
 */
  static long i,is,j,js,jx,l;
/*
 */
  void cbllim();
  void count();
  void scalcl();
/* 
 * initialize flags
 */
  flgatf = 0;
  flggol = 0;
/*
 *  define flags and indices of cl array
 *  except for those already defined by getcnf
 *  (cvatf, trucst, falcst)
 */
  for (j=1;j<=ncols;j++) {
    if (strcmp(&colnam_(1,j),"GOAL")==0) {
      flggol = 1;
    }
    if (colnam_(58,j)=='D') {
      dlclop_(j) = 1;
    } else {
      dlclop_(j) = 0;
    }
/*
 *  cvatf has been defined in getcnf
 *  here, determine atf flag
 */
    if (cvatf_(j)!=0) {
      flgatf = 1;
    }
    nzamac_(j)=0;
    ciact_(j)=1;
    ciina_(j)=0;
    cifre_(j)=1;
    cifix_(j)=0;
    ciblk_(j)=1;
    solut1_(j)=0;
    solut2_(j)=0;
    solut3_(j)=0;
    solut4_(j)=0;
    solut5_(j)=0;
    scale_(j)=1;
    idxcol_(j)=j;
/*
 *  trucst and falcst have been defined in getcnf
 *  compute cost using trucst and falcst
 */ 
    cost_(j)=trucst_(j) - falcst_(j);
  }
/*
 * -----------------------------------
 *  store matrix data in amatcl
 * -----------------------------------
 * determine column counts
 *
 */
  for (j=1; j<=ncols; j++) {
    nzamac_(j) = 0;
  }
  for (i=1; i<=nrows; i++) {
    for (jx=1; jx<=nzamar_(i); jx++) {
      js = amatrw_(jx+ptamar_(i));
      j = abs(js);
      nzamac_(j)++;
    }
  }
/*
 *  find pointer based on counts
 */
  ptamac_(1)=0;
  if (ncols>1) {
    for (j=2; j<=ncols; j++) {
      ptamac_(j)=ptamac_(j-1)+nzamac_(j-1);
    }
  }
/*
 *  obtain entries from amatrw and place into amatcl
 *  first zero out amatcl counts
 */
  for (j=1; j<=ncols; j++) {
    nzamac_(j)=0;
  }
/*  
 *  extract entries from amatrw
 */
  for (i=1; i<=nrows; i++) {
/*
 *  error if no entry in row i
 */
    if (nzamar_(i)==0) {
      error(" finmat","  1302  ");
    }
    for(jx=1; jx<=nzamar_(i); jx++)  {
      js=amatrw_(jx+ptamar_(i));
      j=abs(js);
/*
 *  place entry into amatcl
 */
      nzamac_(j)=nzamac_(j)+1;
      if (js>0) {
        is=i;
      } else {
        is=-i;
      }
      amatcl_(nzamac_(j)+ptamac_(j))=is;
    }
  }
/*
 * --------------------------------------------------- 
 *  define rw entries
 * ---------------------------------------------------
 */
  for (i=1; i<=nrows; i++) {
    if (rownam_(58,i)=='D') {
      dlrwop_(i)=1;
    } else {
      dlrwop_(i)=0;
    }
    level_(i) = 0;
    sscanf(&rownam_(54,i),"%3ld",&level_(i));
    riact_(i)=1;
    riina_(i)=0;
    riblk_(i)=1;
    rhs1_(i)=1;
    rhs2_(i)=1;
    rhs3_(i)=1;
    rhs4_(i)=1;
    rhs5_(i)=1;
    idxrow_(i)=i;
  }
/*
 * ---------------------------------------------------
 *  introduce artificial variable and row, in block 1
 * ---------------------------------------------------
 */
  ncols=ncols+1;
  nrows=nrows+1;
  strcpy(&colnam_(1,ncols),"*");
  strcpy(&colnam_(58,ncols)," ");
  strcpy(&rownam_(1,nrows),"*");
  strcpy(&rownam_(54,nrows),"000  ");
  nzamac_(ncols)=1;
  nzamar_(nrows)=1;
  ptamac_(ncols)=nanzs;
  ptamar_(nrows)=nanzs;
  amatcl_(1+ptamac_(ncols))=nrows;
  amatrw_(1+ptamar_(nrows))=ncols;
  nanzs=nanzs+1;
/*
 */
  for(l=1; l<=lclmax; l++)  {
    cl_(ncols,l,1)=0;
  }
  ciact_(ncols)=1;
  cifre_(ncols)=1;
  ciblk_(ncols)=1;
  scale_(ncols)=1;
  idxcol_(ncols)=ncols;
  trucst_(ncols)=0;
  falcst_(ncols)=0;
/*
 */
  for(l=1; l<=lrwmax; l++)  {
    rw_(nrows,l,1)=1;
  }
  riina_(nrows)=0;
  idxrow_(nrows)=nrows;
  dlrwop_(nrows)=0;
  level_(nrows)=0;
/*
 *  have processed entire problem.  compute counts
 */
  count();
/*
 *  compute block limits
 */
  cbllim();
/*
 *  scale columns with negative costs
 */
  if (optimz==1) {
    for(j=1; j<=ncols; j++)  {
      if (cost_(j)<0) {
        scalcl(j);
      }
    }
  }
/*
 *  construct external index array which contains 
 *  indices into colnam of non-asterisk column names
 */
  ncolsx=0;
  for(j=1; j<=ncols; j++)  {
    if (colnam_(1,j)!='*') {
      ncolsx=ncolsx+1;
      idxclx_(ncolsx)=j;
    }
  }
/*
 *  indicate in twosat that no solution 
 *  algorithm has been selected;
 *  initialize bdfxbl and logrge; 
 *  indicate that range data and time
 *  bound do not exist
 */
  twosat_(1)=-1;
  bdfxbl_(1)=0;
  logrge_(1)=0;
  flgrge=-1;
  realts=-1.0;
  selpgv=0;
  return;
}
/*eject*/
/*
 * 
 * -------------------------------------------------------
 *  subroutine getprg
 * 
 *  purpose:  read problem with decomposition and range
 *            information from file pointer or from
 *            storage, and place into layer 1.
 * 
 *  retrieves problem from prgfil file pointer or from 
 *  array storec. file pointer must be ready for reading. 
 *  problem includes all assignments in force when problem
 *  was stored.
 * 
 *  cases:
 * 
 *  stoflc =-1  read problem from prgfil file pointer
 *  lprb   = 1
 *              input:  none
 *              output: succss = 1: problem was been read and
 *                                  loaded
 *                             = 0: could not read problem
 * 
 *  stoflc =-1  retrieve problem from storec array
 *  lprb   > 1
 *              input:  currec = first position of storec
 *                               array to be read
 *                             = 0: do not read any record
 *              output: succss = 1: problem was retrieved
 *                             = 0: problem was not retrieved
 * 
 * -------------------------------------------------------
 * 
 */
void getprg() {
/*
 */
  static long i,ix,j,jx,k,l,q,n,nd,ne,flg,lay;
  static long loc[30];
  #define loc_(i)  loc[(i-1)]
  void getnum(), getalp(), error();
/*
 *  define lay = layer number for cnf formulation
 */
  lay = 7;
/*
 *  initialize end-of-string character 
 *  in pgalp and pgrec
 */
  pgalp_(2) = '\0';
  pgrec_((pgrmax+1)) = '\0';
/*
 */
  if ((stoflg==-1)&&(lprb==1)) {
/*
 *  read problem from disk
 * 
 *  skip over header records of .prg file;
 */
    zz60:;
    if (fscanf(prgfil,"%60c\n",pgrec) == 0) {
      goto zz3000;
    }
    if (strncmp(pgrec,"End of p",8) != 0) {
      goto zz60;
    }
  }
/*
 *  initialize  pointer for pgrec, used in getalp
 *  triggers reading of first record with first getalp call
 */
  npgrec=pgrmax-1;
/*
 *  check for compatible leibniz system versions
 *  version number for program generator is listed first in
 *  the .prg file
 *  version number of this execution module is given in lbzver
 * 
 *  program generator version a.x and execution module
 *  version b.y must have a = b to be compatible
 * 
 *  initialize succss variable
 */
  succss=0;
  flg=0;
  for(i=1; i<=4; i++)  {
    getalp();
    if (flg==0) {
      if (pgalp_(1) != lbzver_(i)) {
        succss=-9999;
        return;
      }
    }
    if (pgalp_(1) == '.') {
/*
 *  leibniz versions do match to the left of the decimal point
 *  skip remaining comparisons by setting flg = 1
 */
      flg=1;
    }
  }
/*
 *  get parameters
 */
  getnum();
  loc_(1)=pgnum;
  for(i=2; i<=loc_(1); i++)  {
    getnum();
    loc_(i)=pgnum;
  }
/*
 *  transfer loc() data to variables
 */
  ncols=loc_(2);
  nrows=loc_(3);
  nanzs=loc_(4);
  nblks=loc_(5);
/*
 *  test for correctness of parameters
 * 
 */
  if (ncols>colmax) {
    succss=succss-1;
  }
/*
 */
  if (nrows>rowmax) {
    succss=succss-2;
  }
/*
 */
  if (nanzs>anzmax) {
    succss=succss-4;
  }
/*
 */
  if (nblks>blkmax) {
    succss=succss-8;
  }
/*
 */
  if (succss<0) {
    return;
  }
/*
 */
  if (loc_(7)!=lclmax) {
    error(" getprg ","  52    ");
  }
/*
 */
  if (loc_(8)!=lrwmax) {
    error(" getprg ","  62    ");
  }
/*
 */
  if (loc_(9)!=rgemax) {
    error(" getprg ","  72    ");
  }
/*
 */
  if (loc_(10)!=dermax) {
    error(" getprg ","  82    ");
  }
/*
 *  time bounds and estimates
 *  add 0.4 to prevent rounding problems when problem is
 *  retrieved and stored again
 *  loc(11) is time bound in 100th sec
 */
  realts=loc_(11);
  realts=realts+0.4;
/*
 *  convert time bound to sec
 */
  realts=realts/100.0;
/*
 *  loc(12) is estimated time in 100th sec
 */
  realtl=loc_(12);
  realtl=realtl+0.4;
/*
 *  convert time bound to sec
 */
  realtl=realtl/100.0;
/*
 */
  selpgv=loc_(13);
  ncolsx=loc_(14);
  flgatf=loc_(15);
  optimz=loc_(16);
  optimr=loc_(17);
  flgrge=loc_(18);
  bstver=loc_(19);
  apmflg=loc_(20);
  nrecs=loc_(21);
  asgflg=loc_(22);
  solflg=loc_(23);
  satble=loc_(24);
  prcost=loc_(25);
  lbcost=loc_(26);
  ngols=loc_(27);
  jxgoal=loc_(28);
  trsprocessflg = loc_(29);
  keepallvarflg = loc_(30);
/*eject*/
/*
 *  get program
 */
  for(l=1; l<=lclmax; l++)  {
    for(j=1; j<=ncols; j++)  {
      getnum();
      cl_(j,l,1)=pgnum;
    }
  }
/*
 */
  for(j=1; j<=ncols; j++)  {
    for(n=1; n<=53; n++)  {
      getalp();
      if (pgalp_(1) != ' ') {
        colnam_(n,j) = pgalp_(1);
      } else {
        colnam_(n,j) = '\0';
        goto zz105;
      }
    }
    error("getprg","102");
    zz105:;
    getalp();
    colnam_(58,j) = pgalp_(1);
    colnam_(59,j) = '\0'; 
  }
/*
 */
  for(l=1; l<=lrwmax; l++)  {
    for(i=1; i<=nrows; i++)  {
      getnum();
      rw_(i,l,1)=pgnum;
    }
  }
/*
 */
  for(i=1; i<=nrows; i++)  {
    for(n=1; n<=53; n++)  {
      getalp();
      if (pgalp_(1) != ' ') {
        rownam_(n,i) = pgalp_(1);
      } else {
        rownam_(n,i) = '\0';
        goto zz205;
      }
    }
    error("getprg","202");
    zz205:;
    for(n=54; n<=58; n++)  {
      getalp();
      rownam_(n,i) = pgalp_(1);
    }
    rownam_(59,i) = '\0'; 
  }
/*
 */
  for(j=1; j<=ncols; j++)  {
    getnum();
    trucst_(j)=pgnum;
    getnum();
    falcst_(j)=pgnum;
    getnum();
    trucsr_(j)=pgnum;
    getnum();
    falcsr_(j)=pgnum;
  }
/*
 */
  for(j=1; j<=ncolsx; j++)  {
    getnum();
    idxclx_(j)=pgnum;
  }
/*
 */
  for(j=1; j<=ncols; j++)  {
    getnum();
    nzamac_(j)=pgnum;
    getnum();
    ptamac_(j)=pgnum;
    if (nzamac_(j)>0) {
      for(ix=1; ix<=nzamac_(j); ix++)  {
        getnum();
        amatcl_(ix+ptamac_(j))=pgnum;
      }
    }
  }
/*
 */
  for(i=1; i<=nrows; i++)  {
    getnum();
    nzamar_(i)=pgnum;
    getnum();
    ptamar_(i)=pgnum;
    if (nzamar_(i)>0) {
      for(jx=1; jx<=nzamar_(i); jx++)  {
        getnum();
        amatrw_(jx+ptamar_(i))=pgnum;
      }
    }
  }
/*
 */
  for(n=1; n<=53; n++)  {
    getalp();
    if (pgalp_(1) != ' ') {
      prbnam_(n,1) = pgalp_(1);
    } else {
      prbnam_(n,1) = '\0';
      goto zz505;
    }
  }
  error("getprg","502");
  zz505:;
/*
 */
  for(q=1; q<=nblks; q++)  {
    getnum();
    lcllim_(q)=pgnum;
    getnum();
    ucllim_(q)=pgnum;
    getnum();
    lrwlim_(q)=pgnum;
    getnum();
    urwlim_(q)=pgnum;
    getnum();
    twosat_(q)=pgnum;
    getnum();
    bdfxbl_(q)=pgnum;
    getnum();
    logrge_(q)=pgnum;
    getnum();
    ndrge_(q)=pgnum;
    getnum();
    nerge_(q)=pgnum;
    getnum();
    nders_(q)=pgnum;
/*
 */
    ne=nerge_(q);
    nd=ndrge_(q);
    if (q>1) {
      if (nerge_(q-1)>ne) {
        ne=nerge_(q-1);
      }
      if (ndrge_(q-1)>nd) {
        nd=ndrge_(q-1);
      }
    }
    for(j=1; j<=nerge_(q); j++)  {
      for(k=1; k<=ne; k++)  {
        getnum();
        gpoe_(k,j,q)=pgnum;
      }
    }
    for(j=1; j<=ndrge_(q); j++)  {
      for(k=1; k<=nd; k++)  {
        getnum();
        gpod_(k,j+nerge_(q),q)=pgnum;
      }
    }
    for(i=1; i<=nders_(q); i++)  {
      getnum();
      drange_(i,q)=pgnum;
    }
    for(i=1; i<=nerge_(q); i++)  {
      getnum();
      pter_(i,q)=pgnum;
      getnum();
      nzer_(i,q)=pgnum;
    }
    for(i=1; i<=ndrge_(q); i++)  {
      getnum();
      ptdr_(i,q)=pgnum;
      getnum();
      nzdr_(i,q)=pgnum;
    }
  }
/*eject*/
/*
 *  get cnf formulation and store in layer lay
 *
 *  column data of cnf formulation
 */
  getnum();
  ncls_(lay) = pgnum;
  for (j=1;j<=ncls_(lay);j++) {
/*
 *  column name with delete option
 */
    for(n=1; n<=53; n++)  {
      getalp();
      if (pgalp_(1) != ' ') {
        clnam_(n,j,lay) = pgalp_(1);
      } else {
        clnam_(n,j,lay) = '\0';
        goto zz1105;
      }
    }
    error("getprg","1102");
    zz1105:;
    getalp();
    clnam_(58,j,lay) = pgalp_(1);
    clnam_(59,j,lay) = '\0'; 
/*
 *  cvatf value
 */
    getnum();
    cl_(j,24,lay) = pgnum;
/*
 *  true/false costs
 */
    getnum();
    trcst_(j,lay) = pgnum;
    getnum();
    flcst_(j,lay) = pgnum;
  }
/*
 * row data of cnf formulation
 */
  getnum();
  nrws_(lay) = pgnum;
  getnum();
  nnzs_(lay) = pgnum;
  for (i=1;i<=nrws_(lay);i++) {
/*
 *  row name with level and add/delete option
 */
    for(n=1; n<=53; n++)  {
      getalp();
      if (pgalp_(1) != ' ') {
        rwnam_(n,i,lay) = pgalp_(1);
      } else {
        rwnam_(n,i,lay) = '\0';
        goto zz1205;
      }
    }
    error("getprg","1202");
    zz1205:;
    for(n=54; n<=58; n++)  {
      getalp();
      rwnam_(n,i,lay) = pgalp_(1);
    }
    rwnam_(59,i,lay) = '\0';
/*
 *  amr data
 */
    getnum();
    ptamr_(i,lay) = pgnum;
    getnum();
    nzamr_(i,lay) = pgnum;
    for (jx=1;jx<=nzamr_(i,lay);jx++) {
      getnum();
      amr_(jx+ptamr_(i,lay),lay) = pgnum;
    }  
  }      
/*
 *  problem has been loaded
 */
  succss=1;
  return;
/*
 *  problem file cannot be read
 */
  zz3000:;
  succss=0;
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine getnum
 *  decodes alphanumeric representation into integer
 *  (=inverse process of putnum)
 * *******************************************************
 * 
 */
void getnum() {
/*
 */
  static long dig,i,nc,neg;
  static long p64;
  void getalp();
/*
 *  initialize pgnum
 */
  pgnum=0;
/*
 *  get the number of alpha characters
 */
  getalp();
  dig = (int)pgalp_(1);
  if (dig==48) {
/*
 *  have the integer 0
 */
    return;
  }
  if (dig>=65) {
    if (dig<=90) {
/*
 *  have pgalp = a ... z corresponding to 1, ..., 26
 */
      pgnum=dig-64;
      return;
    } else {
/*
 *   have pgalp = a ... z corresponding to -1, ..., -26
 */
      pgnum=-(dig-96);
      return;
    }
  }
/*
 *  determine sign
 */
  dig=dig-48;
  if (dig<=4) {
    neg=0;
  } else {
    neg=4;
    dig=dig-4;
  }
/*
 *  place appropriate power of 64 into p64. do loop below
 *  is equivalent to p64 = 64**(dig-1)
 */
  p64=1;
  if (dig>=2) {
    for(i=1; i<=dig-1; i++)  {
      p64=64*p64;
    }
  }
/*
 *  decode alphanumeric representation
 *  use following table for conversion
 *      n       ascii code    ascii character
 *   0,...,11   48,...,59     0 1 ... 9 : ;
 *  12,...,37   65,...,90     a b ... z
 *  38,...,63   97,..,122     a b ... z
 * 
 */
  for(i=dig; i>=1; i--)  {
/*
 * get alpha character and convert to integer
 */
    getalp();
    nc =  (int)pgalp_(1);
    if (nc<=59) {
      pgnum=pgnum+p64*(nc-48);
    } else {
      if (nc<=90) {
        pgnum=pgnum+p64*(nc-65+12);
      } else {
        pgnum=pgnum+p64*(nc-97+38);
      }
    }
/*
 *  reduce p64
 */
    p64=p64/64;
  }
/*
 *  negate number if needed
 */
  if (neg==4) {
    pgnum=-pgnum;
  }
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine getalp
 * 
 *  retrieves one character of record pgrec
 *  and places it into pgalp
 * 
 *  input:  npgrec = most recently used position in pgrec
 *          disk1  =  disk number of input file
 * 
 *  output: one character in pgalp
 * 
 *  caution: pgrec has '*' in first and last position,
 *           must skip these when reading
 * ********************************************************
 * 
 */
void getalp() {
/*
 */
  void getrec();
/*
 * increment record counter
 */
  npgrec=npgrec+1;
  if (npgrec==pgrmax) {
/*
 *  entire record has been read since last position
 *  always has '*'
 *  read next record from prgfil file
 *  pointer, or from storec array
 *  reset npgrec to 2 since first position always has '*'
 */
    getrec();
    npgrec=2;
  }
/*
 *  place pgrec entry into pgalp
 */
  pgalp_(1) = pgrec_(npgrec);
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine getrec
 * 
 *  retrieves record from prgfil file
 *  or from array storec
 * 
 *  cases:
 * 
 *  stoflc =-1  read record from disk1 or prgfil 
 *              file pointer
 *  lprb   = 1
 *              input:  none
 *              output: pgrec  (= retrieved record
 *                                if sucss = 1)
 *                      succss = 1: record has been read
 *                                  and put into pgrec
 *                             = 0: could not read record
 * 
 *  stoflc =-1  retrieve record from storec array
 *  lprb   > 1
 *              input:  currec = position of storec array
 *                               to be read
 *                             = 0: do not read any record
 *              output: pgrec  = retrieved record
 *                               if sucss = 1
 *                      currec = position of next record
 *                               to be read
 *                             = 0: no next record available
 *                      succss = 1: record was retrieved
 *                             = 0: record was not retrieved
 * 
 * ********************************************************
 * 
 */
void getrec() {
/*
 */
  long i;
/*
 */
  if (stoflg==-1) {
    if (lprb==1) {
/*
 *  read record from prgfil file pointer
 */
      fscanf(prgfil,"%60c\n",pgrec);
      return;
    }
/*
 */
    if ((lprb>=2)&&(lprb<=nprbs)) {
/*
 *  retrieve record from storec array
 */
      if (currec==0) {
/*
 *  error, unexpected end of file given by nxtrec array
 */
        error(" getrec ","  105   ");
      }
/*
 *  get record
 */
      for (i=1; i<=pgrmax; i++){
        pgrec_(i) = storec_(i,currec);
      }
/*
 *  update currec
 */
      currec=nxtrec_(currec);
      return;
    }
/*
 *  error, lprb index outside of range 1 .. nprbs
 */
    error(" getrec ","  205   ");
  }
/*
 *  error, stoflg must be -1
 */
  error(" getrec ","  305   ");
}
/*eject*/
/*
 * -------------------------------------------------------
 *  subroutine putprg
 * 
 *  purpose:  puts problem of layer 1 with decomposition
 *            and range information on prgfil, or
 *            into storec storage area.
 *
 * 
 *  cases:
 * 
 *  stoflc = 0  do not store problem, just count records
 *              for nrecs
 *              input:  currently loaded problem
 *              output: nrecs = total number of records needed
 *                      to store problem.
 * 
 *  stoflc = 1  put problem on disk2
 *  lprb   = 1
 *              input:  currently loaded problem
 *              output: none
 * 
 *  stoflc = 1  put problem into storec array
 *  lprb   > 1
 *              input:  currently loaded problem
 *                      currec = initial position of storec
 *                               array to be used
 *              output: currec = position of next open record
 *                             = 0: no open record left
 *                      antrec = index of record anteceding
 *                               record with currec value,
 *                               at end of the routine
 *                      usdrec = number of records stored
 *                               for problem being stored
 *                      succss = 1: problem was stored
 *                             = 0: problem was not stored
 * 
 *   caution: any change of last record in header section
 *            of .prg file requires adjustment in routine
 *            getprg
 *
 * -------------------------------------------------------
 * 
 */
void putprg() {
/*
 */
  static long i,ix,j,jx,k,l,q,n,nd,ne,lay;
  static long loc[40];
  static char val[256];
  static char bst[pgrmax+1];
  #define bst_(i) bst[(i-1)]
  #define loc_(i) loc[(i-1)]
  #define val_(i) val[(i-1)] 
/*
 */
  void putnum(), putalp(), putrec(), error();
/*
 *  define lay = layer number for cnf formulation 
 */
  lay = 7;
/*
 *  initialize end-of-string character in pgalp and pgrec
 *  and initialize bst string as blanks ended by one '*' 
 */
  pgalp_(2) = '\0';
  pgrec_(pgrmax+1) = '\0';
  for (i=1;i<=pgrmax-1;i++) { 
    bst_(i) = ' ';
  }
  bst_(pgrmax) = '*';
  bst_(pgrmax+1)='\0';
/*
 *  error if range data do not exist
 */
  if (flgrge!=1) {
    error(" putprg ","   52   ");
  }
/*
 *  header section for disk output
 */
  if ((stoflg==1)&&(lprb==1)) {
/*
 *  currently loaded problem is written on disk
 *  begin with line of '*'s
 */
    for (i=1;i<=pgrmax;i++) {
      pgrec_(i) = '*';
    }
    putrec();
/*
 *  write title line
 */    
    sprintf(val,"Program for %s",&prbnam_(1,1));
    strcpy(pgrec,bst);
    n = min(strlen(val),(pgrmax-1));
    strncpy(pgrec,val,n);
    putrec();
/*
 *  write type of program
 */
    if (optimz==0) {   
      sprintf(val,"SATISFY problem ");
    } else {
      if (apmflg==0) {
        sprintf(val,
           "MINIMIZE problem (solved EXACTLY)");
      } else {
        sprintf(val,
           "MINIMIZE problem (solved APPROXIMATELY)");
      }
    }
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  write Leibniz System Version used
 */

    sprintf(val,
      "Program compiled with Leibniz System Version %s",
       lbzver);
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  write  time bound for program
 */
    if (apmflg==0) {
/*
 *  regular case, satisfiability or minimization
 */
      if (realto<1.0e6) {
        sprintf(val,
        "Execution time bound (sec)            = %10.4f",
         realto);
      } else {
        sprintf(val,
        "Execution time bound (sec)            =   %9.1e",
         realto);
      }
      strcpy(pgrec,bst);
      strncpy(pgrec,val,strlen(val));
      putrec();
    } else {
/*
 *  approximate minimization
 *  write estimated execution time
 */
      if (realtl<1.0e6) {
        sprintf(val,
        "Estimated execution time (sec)        = %10.4f",
         realtl);
      } else {
        sprintf(val,
        "Estimated execution time (sec)        =   %9.1e",
         realtl);
      }
      strcpy(pgrec,bst);
      strncpy(pgrec,val,strlen(val));
      putrec();    
/*
 *  write time bound for satisfiability check
 */
      if (realts<1.0e6) {
        sprintf(val,
        "Satisfiability check time bound (sec) = %10.4f",
         realts);
      } else {
        sprintf(val,
        "Satisfiability check time bound (sec) =   %9.1e",
         realts);
      }
      strcpy(pgrec,bst);
      strncpy(pgrec,val,strlen(val));
      putrec(); 
    }
/*
 *  write machine speed
 */
    sprintf(val,
      "  if machine speed (mips)             = %5ld",
      mspeed);
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  write minimum parameter values for execution
 *  must consider size of compiled problem
 *  in layer 1 and of cnf formulation in layer lay
 */
    sprintf(val,
      "Minimum parameter values for execution");
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
    sprintf(val,
      "Parameter  Min Value");
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  number of columns
 */
    n = max(ncols,ncls_(lay));
    sprintf(val,
      " COLMAX    %6ld",n);
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  number of rows
 */
    n = max(nrows,nrws_(lay));
    sprintf(val,
      " ROWMAX    %6ld",n);
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  number of nonzero matrix entries
 */
    n = max(nanzs,nnzs_(lay));
    sprintf(val,
      " ANZMAX    %6ld",n);
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  number of blocks
 *  parameter must be at least 2 even if nblks = 1
 */
    n = max(2,nblks);
    sprintf(val,
      " BLKMAX    %6ld",n);
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  bound on max number of program records 
 *  (for internal storage)
 */
    sprintf(val,
      " STOSIZ    %6ld",nrecs);
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();
/*
 *  end of parameters 
 */
    sprintf(val,
      "End of parameter data");
    strcpy(pgrec,bst);
    strncpy(pgrec,val,strlen(val));
    putrec();  
  }  
/*  
 *  end of header section disk output
 */
/*eject*/
/*
 *  initialize pgrec to '*' in first and last position
 */
  pgrec_(1) = '*';
  pgrec_(pgrmax) = '*';
/*
 *  store parameters and some scalars in loc array
 *  check dimension of loc here and in getprg when changing
 *  code below involving loc
 */
  loc_(1)=30;
  loc_(2)=ncols;
  loc_(3)=nrows;
  loc_(4)=nanzs;
  loc_(5)=nblks;
  loc_(6)=laymax;
  loc_(7)=lclmax;
  loc_(8)=lrwmax;
  loc_(9)=rgemax;
  loc_(10)=dermax;
/*
 *  store time bound as integer in 1/100th sec
 */
  if (100.*realts<9999999) {
    loc_(11)=(100.*realts+0.5);
  } else {
    loc_(11)=9999999;
  }
/*
 *  store estimated time as integer in 1/100th sec
 */
  if (100.*realtl<9999999) {
    loc_(12)=(100.*realtl+0.5);
  } else {
    loc_(12)=9999999;
  }
/*
 */
  loc_(13)=selpgv;
  loc_(14)=ncolsx;
  loc_(15)=flgatf;
  loc_(16)=optimz;
  loc_(17)=optimr;
  loc_(18)=flgrge;
  loc_(19)=bstver;
  loc_(20)=apmflg;
  loc_(21)=nrecs;
  loc_(22)=asgflg;
  loc_(23)=solflg;
  loc_(24)=satble;
  loc_(25)=prcost;
  loc_(26)=lbcost;
  loc_(27)=ngols;
  loc_(28)=jxgoal;
  loc_(29)=trsprocessflg;
  loc_(30)=keepallvarflg;
/*
 *  caution: if entries are added to loc() array,
 *           then loc(1) must be increased accordingly,
 *           and dimension of loc() must possibly be adjusted
 */
/*eject*/
/* 
 *  initialize pointer for pgrec, used in putalp
 */
  npgrec=1;
/*
 *  store version number
 */
  for(i=1; i<=4; i++)  {
    pgalp_(1) = lbzver_(i);
    putalp();
  }
/*
 *  store loc data
 */
  for(i=1; i<=loc_(1); i++)  {
    pgnum=loc_(i);
    putnum();
  }
/*
 * store program
 */
  for(l=1; l<=lclmax; l++)  {
    for(j=1; j<=ncols; j++)  {
      pgnum=cl_(j,l,1);
      putnum();
    }
  }
/*
 */
  for(j=1; j<=ncols; j++)  {
    for(n=1; n<=strlen(&colnam_(1,j)); n++)  {
      pgalp_(1) = colnam_(n,j);
      putalp();
    }
    pgalp_(1) = ' ';
    putalp();
    pgalp_(1) = colnam_(58,j);
    putalp();
  }
/*
 */
  for(l=1; l<=lrwmax; l++)  {
    for(i=1; i<=nrows; i++)  {
      pgnum=rw_(i,l,1);
      putnum();
    }
  }
/*
 */
  for(i=1; i<=nrows; i++)  {
    for(n=1; n<=strlen(&rownam_(1,i)); n++)  {
      pgalp_(1) = rownam_(n,i);
      putalp();
    }
    pgalp_(1) = ' ';
    putalp();
    for(n=54; n<=58; n++)  {
      pgalp_(1) = rownam_(n,i);
      putalp();
    }
  }
/*
 */
  for(j=1; j<=ncols; j++)  {
    pgnum=trucst_(j);
    putnum();
    pgnum=falcst_(j);
    putnum();
    pgnum=trucsr_(j);
    putnum();
    pgnum=falcsr_(j);
    putnum();
  }
/*
 */
  for(j=1; j<=ncolsx; j++)  {
    pgnum=idxclx_(j);
    putnum();
  }
/*
 */
  for(j=1; j<=ncols; j++)  {
    pgnum=nzamac_(j);
    putnum();
    pgnum=ptamac_(j);
    putnum();
    if (nzamac_(j)>0) {
      for(ix=1; ix<=nzamac_(j); ix++)  {
        pgnum=amatcl_(ix+ptamac_(j));
        putnum();
      }
    }
  }
/*
 */
  for(i=1; i<=nrows; i++)  {
    pgnum=nzamar_(i);
    putnum();
    pgnum=ptamar_(i);
    putnum();
    if (nzamar_(i)>0) {
      for(jx=1; jx<=nzamar_(i); jx++)  {
        pgnum=amatrw_(jx+ptamar_(i));
        putnum();
      }
    }
  }
/*
 */
  for(n=1; n<=strlen(&prbnam_(1,lprb)); n++)  {
    pgalp_(1) = prbnam_(n,lprb);
    putalp();
  }
  pgalp_(1) = ' ';
  putalp();
/*
 */
  for(q=1; q<=nblks; q++)  {
    pgnum=lcllim_(q);
    putnum();
    pgnum=ucllim_(q);
    putnum();
    pgnum=lrwlim_(q);
    putnum();
    pgnum=urwlim_(q);
    putnum();
    pgnum=twosat_(q);
    putnum();
    pgnum=bdfxbl_(q);
    putnum();
    pgnum=logrge_(q);
    putnum();
    pgnum=ndrge_(q);
    putnum();
    pgnum=nerge_(q);
    putnum();
    pgnum=nders_(q);
    putnum();
/*
 */
    ne=nerge_(q);
    nd=ndrge_(q);
    if (q>1) {
      if (nerge_(q-1)>ne) {
        ne=nerge_(q-1);
      }
      if (ndrge_(q-1)>nd) {
        nd=ndrge_(q-1);
      }
    }
    for(j=1; j<=nerge_(q); j++)  {
      for(k=1; k<=ne; k++)  {
        pgnum=gpoe_(k,j,q);
        putnum();
      }
    }
    for(j=1; j<=ndrge_(q); j++)  {
      for(k=1; k<=nd; k++)  {
        pgnum=gpod_(k,j+nerge_(q),q);
        putnum();
      }
    }
    for(i=1; i<=nders_(q); i++)  {
      pgnum=drange_(i,q);
      putnum();
    }
    for(i=1; i<=nerge_(q); i++)  {
      pgnum=pter_(i,q);
      putnum();
      pgnum=nzer_(i,q);
      putnum();
    }
    for(i=1; i<=ndrge_(q); i++)  {
      pgnum=ptdr_(i,q);
      putnum();
      pgnum=nzdr_(i,q);
      putnum();
    }
  }
/*eject*/
/*
 *  put cnf formulation of layer lay
 *
 *  column data of cnf formulation
 */
  pgnum = ncls_(lay);
  putnum();
  for (j=1;j<=ncls_(lay);j++) {
/*
 *  column name with delete option
 */
    for(n=1; n<=strlen(&clnam_(1,j,lay)); n++)  {
      pgalp_(1) = clnam_(n,j,lay);
      putalp();
    }
    pgalp_(1) = ' ';
    putalp();
    pgalp_(1) = clnam_(58,j,lay);
    putalp();
/*
 *  cvatf value
 */
    pgnum = cl_(j,24,lay);
    putnum();
/*
 *  true/false costs
 */
    pgnum = trcst_(j,lay);
    putnum();
    pgnum = flcst_(j,lay);
    putnum();
  }
/*
 * row data of cnf formulation
 */
  
  pgnum = nrws_(lay);
  putnum();
  pgnum = nnzs_(lay);
  putnum();
  for (i=1;i<=nrws_(lay);i++) {
/*
 *  row name with level and add/delete option
 */
    for(n=1; n<=strlen(&rwnam_(1,i,lay)); n++)  {
      pgalp_(1) = rwnam_(n,i,lay);
      putalp();
    }
    pgalp_(1) = ' ';
    putalp();
    for(n=54; n<=58; n++)  {
      pgalp_(1) = rwnam_(n,i,lay);
      putalp();
    }
/*
 *  amr data
 */
    pgnum = ptamr_(i,lay);
    putnum();
    pgnum = nzamr_(i,lay);
    putnum();
    for (jx=1;jx<=nzamr_(i,lay);jx++) {
      pgnum = amr_(jx+ptamr_(i,lay),lay);
      putnum();
    }
  }
/*
 *  write last data record in pgrec
 */
  if (npgrec<(pgrmax-1)) {
    for(i=npgrec+1; i<=pgrmax-1; i++)  {
      pgrec_(i) = ' ';
    }
  }
  putrec();
/*
 *  write termination record
 */
  if ((stoflg==1)&&(lprb==1)) {
    strcpy(pgrec ,"last record of program");
    for(i=23; i<=pgrmax; i++)  {
      pgrec_(i) = '*';
    }
    putrec();
  }
  return;
}
/*eject*/
/*
 * **********************************************************
 *  subroutine putnum
 *  encodes integer of pgnum into alphanumeric representation
 *  caution: fails for integers with absolute value greater
 *           than 64**4 - 1 (approx 16,000,000).
 * **********************************************************
 * 
 */
void putnum() {
/*
 */
  static long dig,i,n,neg;
  static long p64;
/*
 */
  void putalp();
/*
 *  if pgnum = 0, put out '0'
 */
  if (pgnum==0) {
    strcpy(pgalp ,"0");
    putalp();
    return;
  }
/*
 *  if 1.le.pgnum.le.26, encode pgnum by a ... z
 */
  if ((pgnum>=1)&&(pgnum<=26)) {
    pgalp_(1) = (char)(pgnum+64);
    putalp();
    return;
  }
/*
 *  if -26.le.pgnum.le.-1, encode pgnum by a ... z
 */
  if ((pgnum>=-26)&&(pgnum<=-1)) {
    pgalp_(1) = (char)(-pgnum+96);
    putalp();
    return;
  }
/*
 *  record sign of pgnum in neg
 */
  if (pgnum>0) {
    neg=0;
  } else {
    neg=4;
    pgnum=-pgnum;
  }
/*
 *  initialize dig  = number of digits in encoding
 */
  dig=0;
/*
 *  place highest power of 64 allowed into p64
 */
  p64=64*64*64;
/*
 *  encode integer
 */
  for(i=4; i>=1; i--)  {
    if ((dig==0)&&(pgnum>=p64)) {
/*
 *  encode number of digits: 1-4 for positive number,
 *                           5-8 for negative number
 */
      dig=i+neg;
      pgalp_(1) = (char)(dig+48);
      putalp();
    }
    if (dig>0) {
/*
 *  encode one digit of pgnum in base 64 representation
 */
      n=pgnum/p64;
      if (n>=64) {
/*
 *  putnum integer is too large or programming error
 */
        error(" putnum "," 105    ");
      }
/*
 *  use following table for conversion
 *      n       ascii code    ascii character
 *   0,...,11   48,...,59     0 1 ... 9 : ;
 *  12,...,37   65,...,90     a b ... z
 *  38,...,63   97,..,122     a b ... z
 * 
 */
      if (n<=11) {
        pgalp_(1) = (char)(n+48);
      } else {
        if (n<=37) {
          pgalp_(1) = (char)(n-12+65);
        } else {
          pgalp_(1) = (char)(n-38+97);
        }
      }
      putalp();
/*
 *  reduce pgnum and p64
 */
      pgnum=pgnum-(n*p64);
    }
    p64=p64/64;
  }
  return;
}
/*eject*/
/*
 * ********************************************************
 *  subroutine putalp
 * 
 *  stores character in pgalp into record pgrec
 *  passes full records to putrec
 * 
 *  input:  npgrec = most recently used position in pgrec
 * 
 *  output: alphanumeric records in pgrec
 * 
 *  caution: pgrec has '*' in first and last position,
 *           must not change these when recording characters
 * *********************************************************
 * 
 */
void putalp() {
/*
 */
  void putrec();
/*
 * increment record counter
 */
  npgrec=npgrec+1;
  if (npgrec==pgrmax) {
/*
 *  record is full since last position always has '*'
 *  write pgrec and reset npgrec to 2
 *  since first position always has '*'
 */
    putrec();
    npgrec=2;
  }
/*
 *  store pgalp in pgrec
 */
  pgrec_(npgrec) = pgalp_(1);
  return;
}
/*eject*/
/*
 * *********************************************************
 *  subroutine putrec
 * 
 *  stores record into prgfil file
 *  pointer or into array storec
 * 
 *  cases:
 * 
 *  stoflc = 0  do not store record, just count records
 *              for nrecs
 *              input:  pgrec (has record, but is not used)
 *              output: nrecs (has been incremented by 1)
 * 
 *  stoflc = 1  put record into prgfil file pointer
 *  lprb   = 1
 *              input:  pgrec (has record)
 *              output: record has been placed on disk2 or
 *                      prgfil
 * 
 *  stoflc = 1  put record into storec array
 *  lprb   > 1
 *              input:  pgrec   (has record)
 *                      currec = position of storec array
 *                               to be used
 *                      usdrec = number of records stored so far
 *                               for the problem being stored
 *              output: currec = position of next open record
 *                             = 0: no open record left
 *                      antrec = index of record anteceding
 *                               record with currec value, at end
 *                               of the routine
 *                               (= input value of currec)
 *                      usdrec = number of records stored so far
 *                               for problem being stored, at end
 *                               of the routine
 *                      succss = 1: record was stored
 *                             = 0: record was not stored
 * 
 * **********************************************************
 * 
 */
void putrec() {
/*
 */
  static long  i;
/*
 */
  if (stoflg==0) {
/*
 *  count record, do not write out or store record
 */
    nrecs=nrecs+1;
    return;
  }
/*
 */
  if (stoflg==1) {
    if (lprb==1) {
/*
 *  write record pgrec to file prgfil
 */
      fprintf(prgfil,"%s\n",pgrec); 
      return;
    }
/*
 */
    if (lprb==(nprbs+1)) {
/*
 *  store record in storec array
 */
      if (currec==0) {
/*
 *  no space left
 */
        succss=0;
        return;
      }
/*
 *  put record
 */
      for (i=1; i<=pgrmax; i++){
        storec_(i,currec) = pgrec_(i);
      }
      storec_(pgrmax+1,currec) = '\0';
/*
 *  update currec
 */
      antrec=currec;
      usdrec=usdrec+1;
      currec=nxtrec_(currec);
      succss=1;
      return;
    }
/*
 *  error, lprb index outside of range 1 .. nprbs
 */
    error(" putrec ","  105   ");
  }
/*
 *  error, stoflg is not equal to 0 or 1
 */
  error(" putrec ","  205   ");
}
/*eject*/
/*
 * ***********************************************************
 *  module index routines
 * 
 *  contains the following subroutines for changing column
 *  or row indices from one type to another:
 *    columns:                                       rows:
 *     icfxfr     icinfr                             iracin
 *     icfrfx     icinfx                             irinac
 *     icfrin     icinac                             urinac
 *     icfxin
 *     icacin
 * 
 *  caution: counts cnxxxx and rnxxxx are not changed by
 *           these routines.
 * 
 *  ==============
 *  update history
 *  ==============
 *  date       where                  what was changed/reason
 * ----------------------------------------------------------
 * 
 * **********************************************************
 * 
 * 
 * 
 * **********************************************************
 *  subroutine icinfr(j)
 * 
 *  purpose:  index change of column from inactive to free.
 * 
 *  output:   the column indicator vector for inactive and
 *            free status are updated (ciina(j), cifre(j),
 *            ciact(j)) to reflect the move.
 *  caution:  row counts are not updated.
 * **********************************************************
 * 
 */
void icinfr(long j) {
/*
 */
  void error();
/*
 *  check for error
 */
  if (ciina_(j)==0) {
    error("icinfr  ","90      ");
  }
/*
 *  update indicator vectors
 */
  ciina_(j)=0;
  cifre_(j)=1;
  ciact_(j)=1;
  return;
}
/*
 * *********************************************************
 *  subroutine icinfx(j)
 * 
 *  purpose:  index change of column from inactive to fixed.
 * 
 *  output:   the column indicator vector for inactive and
 *            fixed status are updated (ciina(j), cifix(j),
 *            ciact(j)) to reflect the move.
 *  caution:  row counts are not updated.
 * **********************************************************
 * 
 */
void icinfx(long j) {
/*
 */
  void error();
/*
 *  check for error
 */
  if (ciina_(j)==0) {
    error("icinfx  ","90      ");
  }
/*
 *  update the indicator vectors
 */
  ciina_(j)=0;
  cifix_(j)=1;
  ciact_(j)=1;
  return;
}
/*
 * ********************************************************
 *  subroutine icinac(j)
 * 
 *  purpose:  index change of column from inactive to active.
 * 
 *  output:   the column indicator vector for inactive and
 *            free status are updated (ciina(j), cifre(j),
 *            cifix(j), ciact(j)) to reflect the move.
 *  caution:  row counts are not updated.
 * *********************************************************
 * 
 */
void icinac(long j) {
/*
 */
  void error();
/*
 *  check for error
 */
  if (ciina_(j)==0) {
    error(" icinac ","90      ");
  }
/*
 *  update indicator vectors
 */
  if (cifrer_(j)!=0) {
    cifre_(j)=1;
  } else {
    cifix_(j)=1;
  }
  ciina_(j)=0;
  ciact_(j)=1;
  return;
}
/*
 * **********************************************************
 *  subroutine icfrin(j)
 * 
 *  purpose:  index change of column from free to inactive.
 * 
 *  output:   the column indicator vector for free and
 *            inactive status are updated (cifre(j), ciina(j),
 *            ciact(j)) to reflect the move.
 *  caution:  row counts are not updated.
 * **********************************************************
 * 
 */
void icfrin(long j) {
/*
 */
  void error();
/*
 *  check for error
 */
  if (cifre_(j)!=1) {
    error("icfrin  ","90      ");
  }
/*
 *  update indicator vectors
 */
  cifre_(j)=0;
  ciina_(j)=1;
  ciact_(j)=0;
  return;
}
/*
 * **********************************************************
 *  subroutine icfxin(j)
 * 
 *  purpose:  index change of column from fixed to inactive.
 * 
 *  output:   the column indicator vector for fixed and
 *            inactive status are updated (cifix(j), ciina(j),
 *            ciact(j)) to reflect the move.
 *  caution:  row counts are not updated.
 * ***********************************************************
 * 
 */
void icfxin(long j) {
/*
 */
  void error();
/*
 *  check for error
 */
  if ((cifix_(j)!=1)&&(cifix_(j)!=-1)) {
    error("icfxin  ","90      ");
  }
/*
 *  update indicator vectors
 */
  cifix_(j)=0;
  ciina_(j)=1;
  ciact_(j)=0;
  return;
}
/*
 * *********************************************************
 *  subroutine icacin(j)
 * 
 *  purpose:  index change of column from active to inactive.
 * 
 *  output:   the column indicator vector for free and
 *            inactive status are updated (cifre(j), cifix(j),
 *            ciina(j), ciact(j)) to reflect the move.
 *  caution:  row counts are not updated.
 * **********************************************************
 * 
 */
void icacin(long j) {
/*
 */
  void error();
/*
 *  check for error
 */
  if (ciact_(j)!=1) {
    error(" icacin "," 90     ");
  }
/*
 *  update indicator vectors
 */
  cifix_(j)=0;
  cifre_(j)=0;
  ciina_(j)=1;
  ciact_(j)=0;
  return;
}
/*
 * ******************************************************
 *  subroutine icfxfr(j)
 * 
 *  purpose:  index change of column from fixed to free.
 * 
 *  output:   the column indicator vector for fixed and
 *            free status are updated (cifix(j), cifre(j))
 *            to reflect the move.
 *  caution:  row counts are not updated.
 * ******************************************************
 * 
 */
void icfxfr(long j) {
/*
 */
  void error();
/*
 *  check for error
 */
  if ((cifix_(j)!=1)&&(cifix_(j)!=-1)) {
    error("icfxfr  ","90      ");
  }
/*
 *  update indicator vectors
 */
  cifix_(j)=0;
  cifre_(j)=1;
  return;
}
/*
 * **********************************************************
 *  subroutine icfrfx(j)
 * 
 *  purpose:  index change of column from free to fixed.
 * 
 *  output:   the column indicator vector for free and fixed
 *            status are updated (cifre(j), cifix(j)) to
 *            reflect the move.
 *  caution:  row counts are not updated.
 *            assigns cifix(j) = 1 for default.
 * **********************************************************
 * 
 */
void icfrfx(long j) {
/*
 */
  void error();
/*
 *  check for error
 */
  if (cifre_(j)!=1) {
    error("icfrfx  ","90      ");
  }
/*
 *  update indicator vectors
 */
  cifre_(j)=0;
  cifix_(j)=1;
  return;
}
/*
 * *********************************************************
 *  subroutine iracin(i)
 * 
 *  purpose:  index change of row from active to inactive.
 * 
 *  output:   the row indicator vector for active and
 *            inactive status are updated (riact(i), riina(i))
 *            to reflect the move.
 *  caution:  column counts are not updated.
 * **********************************************************
 * 
 */
void iracin(long i) {
/*
 */
  void error();
/*
 *  check for error
 */
  if (riact_(i)!=1) {
    error("iracin  ","90      ");
  }
/*
 *  update indicator vectors
 */
  riact_(i)=0;
  riina_(i)=1;
  return;
}
/*
 * ***********************************************************
 *  subroutine irinac(i)
 * 
 *  purpose:  index change of row from inactive to active.
 * 
 *  output:   the row indicator vector for inactive and active
 *            status are updated (riina(i), riact(i)) to reflect
 *            the move.
 *  caution:  column counts are not updated.
 * ***********************************************************
 * 
 */
void irinac(long i) {
/*
 */
  void error();
/*
 *  check for error
 */
  if (riina_(i)==0) {
    error("irinac  ","90      ");
  }
/*
 *  update indicator vectors
 */
  riina_(i)=0;
  riact_(i)=1;
  return;
}
/*
 * *********************************************************
 *  subroutine urinac
 * 
 *  purpose:  restores all rows i with riina(i) = 1 to active.
 *            then moves all active rows i that are satisfied
 *            by assigned variable values to inactive with
 *            riina(i) = 1.
 * 
 *  output:   riina(i) = 1 for the rows i satisfied by the
 *            assigned variable values.
 *            note: does not affect rows i with riina(i) = 2
 *                 (such rows have been deleted and thus are
 *                  ignored).
 * *********************************************************
 * 
 */
void urinac() {
/*
 */
  static long i,is,ix,j;
/*
 *  compute correct inactive rows
 *  first restore all rows i with riina(i) = 1 to active
 */
  for(i=1; i<=nrows; i++)  {
    if (riina_(i)==1) {
      irinac(i);
    }
  }
/*
 *  update active rows to inactive with riina=1 according to
 *  assigned variable values
 */
  for(j=1; j<=ncols; j++)  {
    if ((ciina_(j)==1)||(ciina_(j)==-1)) {
/*
 *  column j has assigned value given by ciina(j).  declare
 *  all rows i inactive that are currently active and that
 *  become satisfied by column j
 */
      if (nzamac_(j)>0) {
        for(ix=1; ix<=nzamac_(j); ix++)  {
          is=amatcl_(ix+ptamac_(j));
          i=abs(is);
          if ((is*ciina_(j)>0)&&
              (riact_(i)!=0)) {
            iracin(i);
          }
        }
      }
    }
  }
  return;
}
/*eject*/
/*
 * *********************************************************
 *  subroutine initil
 * 
 *  purpose:  initializes all machine dependent variables
 * 
 *   note:  machine speed is retrieved from parameter file.
 * 
 * *********************************************************
 * 
 */
void initil() {
/*
 */
  void calmem();
  void lpexec();
  void permut();
/*
 */
  static long n;
/*
 */
  aggdif=3;
/*
 *  number of machine instructions per matrix element done 
 *  in satneg or sat2st.  
 *  the number below must be verified with test run
 */
  inselt=125;
/*
 *  calculate totmem = total number of bytes (kbytes)
 *  used for memory. first calculate memory for generator
 *  as well as execution module. does not include memory
 *  used by xmp for linear programming problems.
 */
  calmem();
/*
 *  add memory required by xmp
 *  caution: memory must have already been allocated
 */
  strcpy(xcomnd,"GET DIM");
  lpexec(xcomnd,xpoint,xvalue);
  totmem=totmem+xpoint_(8)/1000;
/*
 *  compute matrix of permutations
 */
  permut();
/*
 *  calculate max number of source/sink paths for decomposition with
 *  max flow algorithm.  maxcut = largest n so that 2**n .lt. rgemax
 */
  maxcut=1;
  n=2;
  zz50:;
  if (n<rgemax) {
    maxcut=maxcut+1;
    n=n*2;
    goto zz50;
  } else {
    maxcut=maxcut-1;
  }
/*
 *  check correctness of blkmax parameter. cannot be <2 or >999
 */
  if ((blkmax<2)||
      (blkmax>999)) {
    error(" initil ","   52   ");
  }
/*
 *  check correctness of dermax parameter
 */
  if ((dermax<rowmax)||
      (dermax<rgemax*rgemax)) {
    error(" initil ","   53   ");
  }
/*
 *  display information
 */
  if (scrflg == 1) {
    printf("Memory Required (Kbytes) = %ld\n",totmem);
    printf("Machine Speed (mips)     = %ld\n",mspeed);
  }
  return;
}
/*eject*/
/*
 * *********************************************************
 *  subroutine injatf
 * 
 *  purpose:  injects atf part, which resides in layer 1, into
 *            layer 1 problem
 * 
 *  input:    current problem in layer 1
 *            atf part in layer 5
 * 
 *  output:   current problem with atf part injected
 *            atf variables j have been declared to be inactive
 *            with ciina(j) = +/-1. 
 *            correspondingly, rows i satisfied
 *            by the atf variables have been declared to 
 *            be inactive with riina(i) = 1. 
 *            this agrees with convention in
 *            query and execution modules. there have following
 *            convention:
 *            spec. value for col j  --> ciina(j) = +/-1
 *            row i satisfied by
 *            specified values       --> riina(i) = 1
 *            deleted column j       --> ciina(j) = 2
 *            deleted row i          --> riina(i) = 2
 * 
 *  caution:  uses layers 2 and 3 for intermediate storage
 * 
 *            indexing of atf part in layer 5 must be in 
 *            agreement with indexing in .cnf input file, 
 *            i.e.,
 *            for all j: atf-idxcol(j) = j
 *            for all i: atf-idxrow(i) = i
 * 
 * *********************************************************
 * 
 */
void injatf() {
/*
 */
  void count();
  void mcfrin();
  void mracin();
  void scalcl();
  void trancl();
  void tranpr();
  void tranrw();
/*
 */
  static long i,is,iatf,isatf,ix,j,js,jatf,jsatf,jx;
  static long m;
/*
 *  save input problem in layer 2
 */
  tranpr(c1,c2);
/*
 *  transfer atf part from layer 5 to layer 1
 */
  tranpr(c5,c1);
/*
 *  scale atf part in layer 1 so that it is in agreement 
 *  with scaling of input problem in layer 2
 */
  for(jatf=1; jatf<=ncols; jatf++)  {
/*
 *  idxcol has index l = 20
 */
    j=cl_(jatf,20,2);
/*
 *  scale has index l = 19
 */
    if (scale_(jatf)!=cl_(j,19,2)) {
      scalcl(jatf);
    }
  }
/*
 *  transfer atf part from layer 1 to layer 3
 */
  tranpr(c1,c3);
/*
 *  transfer cl and rw information of input problem
 *  from layer 2 to layer 1
 */
  trancl(c2,c1);
  tranrw(c2,c1);
/*
 *  may now use idxcol and idxrow in layer 1 when corresponding
 *  information of layer 2 is needed.
 *  compose input matrix of layer 2 with atf matrix of layer 3
 *  put resulting matrix into layer 1
 * 
 *  build column part
 */
  nanzs=0;
  for(jatf=1; jatf<=ncols; jatf++)  {
    j=idxcol_(jatf);
    ptamac_(j)=nanzs;
/*
 *  insert layer 2 matrix column j
 */
    if (nzamc_(j,2)>0) {
      for(ix=1; ix<=nzamc_(j,2); ix++)  {
        amatcl_(ix+ptamac_(j))=amc_(ix+ptamc_(j,2),2);
      }
    }
/*
 *  insert layer 3 atf column jatf
 */
    if (nzamc_(jatf,3)>0) {
      for(ix=1; ix<=nzamc_(jatf,3); ix++)  {
        isatf=amc_(ix+ptamc_(jatf,3),3);
        iatf=abs(isatf);
        i=idxrow_(iatf);
        if (isatf>0) {
          is=i;
        } else {
          is=-i;
        }
        m=ix+nzamc_(j,2)+ptamac_(j);
        amatcl_(m)=is;
      }
    }
    nzamac_(j)=nzamc_(j,2)+nzamc_(jatf,3);
    nanzs=nanzs+nzamac_(j);
  }
/*
 *  build row part
 */
  nanzs=0;
  for(iatf=1; iatf<=nrows; iatf++)  {
    i=idxrow_(iatf);
    ptamar_(i)=nanzs;
/*
 *  insert layer 2 matrix row i
 */
    if (nzamr_(i,2)>0) {
      for(jx=1; jx<=nzamr_(i,2); jx++)  {
        amatrw_(jx+ptamar_(i))=amr_(jx+ptamr_(i,2),2);
      }
    }
/*
 *  insert layer 3 atf row iatf
 */
    if (nzamr_(iatf,3)>0) {
      for(jx=1; jx<=nzamr_(iatf,3); jx++)  {
        jsatf=amr_(jx+ptamr_(iatf,3),3);
        jatf=abs(jsatf);
        j=idxcol_(jatf);
        if (jsatf>0) {
          js=j;
        } else {
          js=-j;
        }
        m=jx+nzamr_(i,2)+ptamar_(i);
        amatrw_(m)=js;
      }
    }
    nzamar_(i)=nzamr_(i,2)+nzamr_(iatf,3);
    nanzs=nanzs+nzamar_(i);
  }
/*
 *  error if nanzs too large
 */
  if (nanzs>anzmax) {
    error(" injatf ","     432");
  }
/*
 *  compute counts
 */
  count();
/*
 *  declare atf variables j to be inactive, with ciina(j) = +/-1
 *  in agreement with cvatf(j) = +/-1
 */
  for(j=1; j<=ncols; j++)  {
    if (cvatf_(j)!=0) {
      mcfrin(j);
      if (cvatf_(j)>0) {
        ciina_(j)=1;
      } else {
        ciina_(j)=-1;
      }
/*
 *  declare rows i satisfied by atf column j to be inactive
 *  with riina(i) = 1
 */
      if (nzamac_(j)>0) {
        for(ix=1; ix<=nzamac_(j); ix++)  {
          is=amatcl_(ix+ptamac_(j));
          i=abs(is);
          if (((cvatf_(j)*is)>0)&&
              (riina_(i)==0)) {
            mracin(i);
            riina_(i)=1;
          }
        }
      }
    }
  }
  return;
}
/*eject*/
/*
 * ***********************************************************
 *  module moving routines
 * 
 *  contains the following subroutines for moving columns 
 *  from/to another type, and for moving rows 
 *  from/to another type:
 *    columns:                                       rows:
 *     mcfxfr     mcinfr                             mracin
 *     mcfrfx     mcinfx                             mrinac
 *     mcfrin 
 *     mcfxin 
 * 
 *  ============== 
 *  update history
 *  ==============
 *  date       where                  what was changed/reason
 * ----------------------------------------------------------
 * 
 * ************************************************************
 * 
 * 
 * 
 * ************************************************************
 *  subroutine mcinfr(j)
 *  
 *  purpose:  moves a column from inactive status to 
 *            free status.
 * 
 *  output:   the column indicator vector for inactive and 
 *            free status are updated 
 *            (ciina(j), cifre(j), ciact(j)) to reflect 
 *            the move.
 *            all row counts are updated as necessary.
 * ************************************************************
 * 
 */
void mcinfr(long j) {
/*
 */
  void sclall();
/*
 */
  static long aij,i,ix;
/*
 *  check for error
 */
  if (ciina_(j)==0) {
    error("mcinfr  ","92      ");
  }
/*
 *  move column; update indicator vectors
 */
  ciina_(j)=0;
  cifre_(j)=1;
  ciact_(j)=1;
/*
 *  update the row counts
 */
  sclall(j);
  if (clalli_(rowmax+1)>=1) {
    for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
      i=clalli_(ix);
      aij=centry_(ix);
      rnina_(i)=rnina_(i)-1;
      rnfre_(i)=rnfre_(i)+1;
      rnact_(i)=rnact_(i)+1;
      if (aij==1) {
        rninap_(i)=rninap_(i)-1;
        rnfrep_(i)=rnfrep_(i)+1;
        rnactp_(i)=rnactp_(i)+1;
      } else {
        rninan_(i)=rninan_(i)-1;
        rnfren_(i)=rnfren_(i)+1;
        rnactn_(i)=rnactn_(i)+1;
      }
    }
  }
  return;
}
/*
 * **********************************************************
 *  subroutine mcinfx(j) 
 * 
 *  purpose:  moves a column from inactive status to 
 *            fixed status.
 * 
 *  output:   the column indicator vector for inactive and 
 *            fixed status are updated 
 *            (ciina(j), cifix(j), ciact(j)) to reflect 
 *            the move.
 *            all row counts are updated as necessary. 
 * ***********************************************************
 * 
 */
void mcinfx(long j) {
/*
 */
  void sclall();
/*
 */
  static long aij,i,ix;
/*
 *  check for error
 */
  if (ciina_(j)==0) {
    error("mcinfx  ","92      ");
  }
/*
 *  move column; update the indicator vectors
 */
  ciina_(j)=0;
  cifix_(j)=1;
  ciact_(j)=1;
/*
 *  update the row counts
 */
  sclall(j);
  if (clalli_(rowmax+1)>=1) {
    for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
      i=clalli_(ix);
      aij=centry_(ix);
      rnina_(i)=rnina_(i)-1;
      rnfix_(i)=rnfix_(i)+1;
      rnact_(i)=rnact_(i)+1;
      if (aij==1) {
        rninap_(i)=rninap_(i)-1;
        rnfixp_(i)=rnfixp_(i)+1;
        rnactp_(i)=rnactp_(i)+1;
      } else {
        rninan_(i)=rninan_(i)-1;
        rnfixn_(i)=rnfixn_(i)+1;
        rnactn_(i)=rnactn_(i)+1;
      }
    }
  }
  return;
}
/*
 * *******************************************************
 *  subroutine mcfrin(j)
 *   
 *  purpose:  moves a column from free status to 
 *            inactive status.
 * 
 *  output:   the column indicator vector for free and 
 *            inactive status are updated 
 *            (cifre(j), ciina(j), ciact(j)) to reflect 
 *            the move.
 *            all row counts are updated as necessary.
 * ********************************************************
 * 
 */
void mcfrin(long j) {
/*
 */
  void sclall();
/*
 */
  static long ix,i,aij;
/*
 *  check for error
 */
  if (cifre_(j)!=1) {
    error("mcfrin  ","92      ");
  }
/*
 *  move row; update indicator vectors
 */
  cifre_(j)=0;
  ciina_(j)=1;
  ciact_(j)=0;
/*
 *  update the row counts
 */
  sclall(j);
  if (clalli_(rowmax+1)>=1) {
    for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
      i=clalli_(ix);
      aij=centry_(ix);
      rnfre_(i)=rnfre_(i)-1;
      rnina_(i)=rnina_(i)+1;
      rnact_(i)=rnact_(i)-1;
      if (aij==1) {
        rnfrep_(i)=rnfrep_(i)-1;
        rninap_(i)=rninap_(i)+1;
        rnactp_(i)=rnactp_(i)-1;
      } else {
        rnfren_(i)=rnfren_(i)-1;
        rninan_(i)=rninan_(i)+1;
        rnactn_(i)=rnactn_(i)-1;
      }
    }
  }
  return;
}
/*
 * ************************************************************
 *  subroutine mcfxin(j)
 * 
 *  purpose:  moves a column from fixed status to 
 *            inactive status.
 * 
 *  output:   the column indicator vector for fixed and 
 *            inactive status are updated 
 *            (cifix(j), ciina(j), ciact(j)) 
 *            to reflect the move.
 *            all row counts are updated as necessary.          
 * ***********************************************************
 * 
 */
void mcfxin(long j) {
/*
 */
  void sclall();
/*
 */
  static long ix,i,aij;
/*
 *  check for error
 */
  if ((cifix_(j)!=1)&&
      (cifix_(j)!=-1)) {
    error("mcfxin  ","92      ");
  }
/*
 *  move column, update indicator vectors
 */
  cifix_(j)=0;
  ciina_(j)=1;
  ciact_(j)=0;
/*
 *  update the row counts
 */
  sclall(j);
  if (clalli_(rowmax+1)>=1) {
    for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
      i=clalli_(ix);
      aij=centry_(ix);
      rnfix_(i)=rnfix_(i)-1;
      rnina_(i)=rnina_(i)+1;
      rnact_(i)=rnact_(i)-1;
      if (aij==1) {
        rnfixp_(i)=rnfixp_(i)-1;
        rninap_(i)=rninap_(i)+1;
        rnactp_(i)=rnactp_(i)-1;
      } else {
        rnfixn_(i)=rnfixn_(i)-1;
        rninan_(i)=rninan_(i)+1;
        rnactn_(i)=rnactn_(i)-1;
      }
    }
  }
  return;
}
/*
 * ***********************************************************
 *  subroutine mcfxfr(j)                      
 * 
 *  purpose:  moves a column from fixed status to free status.  
 * 
 *  output:   the column indicator vector for fixed and free 
 *            status are updated 
 *            (cifix(j), cifre(j)) to reflect the move.  
 *            all row  counts are updated as necessary.
 * ***********************************************************
 * 
 */
void mcfxfr(long j) {
/*
 */
  void sclall();
/*
 */
  static long ix,i,aij;
/*
 *  check for error
 */
  if ((cifix_(j)!=1)&&
      (cifix_(j)!=-1)) {
    error("mcfxfr  ","92      ");
  }
/*
 *  move column, update indicator vectors
 */
  cifix_(j)=0;
  cifre_(j)=1;
/*
 *  update the row counts
 */
  sclall(j);
  if (clalli_(rowmax+1)>=1) {
    for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
      i=clalli_(ix);
      aij=centry_(ix);
      rnfix_(i)=rnfix_(i)-1;
      rnfre_(i)=rnfre_(i)+1;
      if (aij==1) {
        rnfixp_(i)=rnfixp_(i)-1;
        rnfrep_(i)=rnfrep_(i)+1;
      } else {
        rnfixn_(i)=rnfixn_(i)-1;
        rnfren_(i)=rnfren_(i)+1;
      }
    }
  }
  return;
}
/*
 * ***********************************************************
 *  subroutine mcfrfx(j)                      
 * 
 *  purpose:  moves a column from free status to fixed status.  
 * 
 *  output:   the column indicator vector for free and fixed 
 *            status are updated 
 *            (cifre(j), cifix(j)) to reflect the move.  
 *            all row  counts are updated as necessary.
 *            assigns cifix(j) = 1 for default.                 
 * ***********************************************************
 * 
 */
void mcfrfx(long j) {
/*
 */
  void sclall();
/*
 */
  static long ix,i,aij;
/*
 *  check for error
 */
  if (cifre_(j)!=1) {
    error("mcfrfx  ","92      ");
  }
/*
 *  move column; update indicator vectors
 */
  cifre_(j)=0;
  cifix_(j)=1;
/*
 *  update the row counts
 */
  sclall(j);
  if (clalli_(rowmax+1)>=1) {
    for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
      i=clalli_(ix);
      aij=centry_(ix);
      rnfre_(i)=rnfre_(i)-1;
      rnfix_(i)=rnfix_(i)+1;
      if (aij==1) {
        rnfrep_(i)=rnfrep_(i)-1;
        rnfixp_(i)=rnfixp_(i)+1;
      } else {
        rnfren_(i)=rnfren_(i)-1;
        rnfixn_(i)=rnfixn_(i)+1;
      }
    }
  }
  return;
}
/*
 * ***********************************************************
 *  subroutine mracin(i)                      
 * 
 *  purpose:  moves a row from active status to inactive status.
 * 
 *  output:   the row indicator vector for active and inactive 
 *            status are updated 
 *            (riact(i), riina(i)) to reflect the move. 
 *            all column counts are updated as necessary.
 * ***********************************************************
 * 
 */
void mracin(long i) {
/*
 */
  void srwall();
/*
 */
  static long jx,j,aij;
/*
 *  check for error
 */
  if (riact_(i)!=1) {
    error("mracin  ","92      ");
  }
/*
 *  move row, update indicator vectors
 */
  riact_(i)=0;
  riina_(i)=1;
/*
 *  update the column counts
 */
  srwall(i);
  if (rwallj_(colmax+1)>=1) {
    for(jx=1; jx<=rwallj_(colmax+1); jx++)  {
      j=rwallj_(jx);
      aij=rentry_(jx);
      cnact_(j)=cnact_(j)-1;
      cnina_(j)=cnina_(j)+1;
      if (aij==1) {
        cnactp_(j)=cnactp_(j)-1;
        cninap_(j)=cninap_(j)+1;
      } else {
        cnactn_(j)=cnactn_(j)-1;
        cninan_(j)=cninan_(j)+1;
      }
    }
  }
  return;
}
/*
 * ***********************************************************
 *  subroutine mrinac(i)                      
 * 
 *  purpose:  moves a row from inactive status to active status.
 * 
 *  output:   the row indicator vector for inactive and active 
 *            status are updated 
 *            (riina(i), riact(i)) to reflect the move.  
 *            all column counts are updated as necessary.
 * ***********************************************************
 * 
 */
void mrinac(long i) {
/*
 */
  void srwall();
/*
 */
  static long jx,j,aij;
/*
 *  check for error
 */
  if (riina_(i)==0) {
    error("mrinac  ","92      ");
  }
/*
 *  move row, update indicator vectors
 */
  riina_(i)=0;
  riact_(i)=1;
/*
 *  update the column counts
 */
  srwall(i);
  if (rwallj_(colmax+1)>=1) {
    for(jx=1; jx<=rwallj_(colmax+1); jx++)  {
      j=rwallj_(jx);
      aij=rentry_(jx);
      cnina_(j)=cnina_(j)-1;
      cnact_(j)=cnact_(j)+1;
      if (aij==1) {
        cninap_(j)=cninap_(j)-1;
        cnactp_(j)=cnactp_(j)+1;
      } else {
        cninan_(j)=cninan_(j)-1;
        cnactn_(j)=cnactn_(j)+1;
      }
    }
  }
  return;
}
/*eject*/
/*
 * *******************************************************
 *  subroutine permut
 *
 *  purpose: calculates permutation table for size 1..6
 *
 * *******************************************************
 * 
 */
void permut() {
/*
 */
  static long cs,i,k,p,pnew;
/*
 *  calculate permutation table limits and number of 
 *  permutations for each k
 */
  prmlim_(1)=1;
  nprms_(1)=1;
  for(k=2; k<=6; k++)  {
    prmlim_(k)=prmlim_(k-1)+k-1;
    nprms_(k)=nprms_(k-1)*k;
  }
/*
 *  initialize permutation set k=1
 */
  prmdat_(1,1)=1;
/*
 *  compute permutations of size k+1 from size k
 */
  for(k=1; k<=5; k++)  {
    for(p=1; p<=nprms_(k); p++)  {
      for(cs=1; cs<=k+1; cs++)  {
        pnew=(p-1)*(k+1)+cs;
        prmdat_(prmlim_(k+1)+cs-1,pnew)=k+1;
        if (cs>1) {
          for(i=1; i<=cs-1; i++)  {
            prmdat_(prmlim_(k+1)+i-1,pnew)=
                prmdat_(prmlim_(k)+i-1,p);
          }
        }
        if (cs<k+1) {
          for(i=cs; i<=k; i++)  {
            prmdat_(prmlim_(k+1)+i,pnew)=
                prmdat_(prmlim_(k)+i-1,p);
          }
        }
      }
    }
  }
  return;
}
/*eject*/
/*
 * --------------------------------------------------------------
 *  subroutine retain
 * 
 *  purpose:  retains problem data in xxxxxr arrays and 
 *            initializes dual values and goal information
 *
 *            is called just prior to storing of generated program
 * 
 *    input:  complete generated program in layer 1, to be stored
 *            as .prg file.
 * 
 *   caution: if subroutine is not called at end of program
 *            generation, then permutation of columns or rows
 *            or other data changes invalidate retained data.
 *   caution: subroutine destroys counts stored 
 *            in cnxxxx and rnxxxx arrays. 
 *            hence no program generation subroutine may be
 *            executed after retain, except that a new problem may
 *            be loaded
 * 
 * --------------------------------------------------------------
 * 
 */
void retain() {
/*
 */
  static long i,ix,j;
/*
 *  retain optimization flag
 */
  optimr=optimz;
/*
 */
  for(j=1; j<=ncols; j++)  {
/*
 *  retain and initialize column information
 */
    ciinar_(j)=ciina_(j);
    ciactr_(j)=ciact_(j);
    cifixr_(j)=cifix_(j);
    cifrer_(j)=cifre_(j);
    trucsr_(j)=trucst_(j);
    falcsr_(j)=falcst_(j);
/*
 * initialize goal information for columns
 */
    ciacgl_(j)=0;
    idxgol_(j)=0;
    idxgnm_(j)=0;
    gcoeff_(j)=0;
/*
 *  set initial solution for approx. min. to 0
 *  that is, there are no initial solution values
 */
    inlsol_(j)=0;
  }
/*
 */
  for(i=1; i<=nrows; i++)  {
/*
 *  retain and initialize row information
 */
    levelr_(i)=level_(i);
    riinar_(i)=riina_(i);
    riactr_(i)=riact_(i);
/*
 *  initialize dual values
 */
    dual_(i)=0;
/*
 * initialize goal information for rows
 */
    goalxq_(i)=0;
    glocst_(i)=0;
    ghicst_(i)=0;
    goalus_(i)=0;
    goalrq_(i)=0;
    glflg_(i)=0;
  }
/*
 *  find index jxgoal of goal variable if present
 *  determine number of goals
 */
  ngols=0;
  jxgoal=0;
  for(j=1; j<=ncols; j++)  {
    if (strcmp(&colnam_(1,j),"GOAL")==0) {
/*
 *  save in jxgoal the internal index for the goal variable
 */
      jxgoal=idxcol_(j);
/*
 *  update entry in glflg(i)
 *  for each row i containing the goal variable
 */
      if (nzamac_(jxgoal)==0) {
/*
 *  error, must have goal variable in at least one row
 */
        error(" retain ","  305   ");
      }
      ngols=nzamac_(jxgoal);
      for(ix=1; ix<=nzamac_(jxgoal); ix++)  {
        i=amatcl_(ix+ptamac_(jxgoal));
        if (i<=0) {
/*
 *  error, only positive goal variable entries possible
 */
          error(" retain ","  315   ");
        }
        glflg_(i)=1;
      }
      return;
    }
  }
  return;
}
/*eject*/
/*
 * *********************************************************
 *  module scanning routines
 * 
 *  this module contains the following scanning routines:
 *    columns:-                            rows:-
 *      sclall                               srwall   srwfre
 *      sclact                               srwact   srwfix
 *      sclina                               srwina
 * 
 *  ==============
 *  update history
 *  ==============
 *  date      where             what was changed/reason
 * ---------------------------------------------------------
 * *********************************************************
 * 
 * 
 * *********************************************************
 *  subroutine sclall(j)
 * 
 *  scan a column of non-zero values over all rows.
 *  put the row indices in clalli(i) and the row entries 
 *  in centry(i)
 * 
 * *********************************************************
 * 
 */
void sclall(long j) {
/*
 */
  static long ix;
/*
 */
  clalli_(rowmax+1)=nzamac_(j);
  if (clalli_(rowmax+1)==0) {
    return;
  }
  for(ix=1; ix<=nzamac_(j); ix++)  {
    if (amatcl_(ix+ptamac_(j))>0) {
      clalli_(ix)=amatcl_(ix+ptamac_(j));
      centry_(ix)=1;
    } else {
      clalli_(ix)=-amatcl_(ix+ptamac_(j));
      centry_(ix)=-1;
    }
  }
  return;
}
/*
 * *********************************************************
 *  subroutine sclact(j)                   
 *                                         
 *  scan a column of non-zero entries over active rows.      
 *  put the row indices in clacti(i) and the row entries 
 *  in centry(i) 
 *                                         
 * *********************************************************
 * 
 */
void sclact(long j) {
/*
 */
  static long ixx,ix,i;
/*
 */
  clacti_(rowmax+1)=0;
  if (nzamac_(j)==0) {
    return;
  }
  ixx=0;
  for(ix=1; ix<=nzamac_(j); ix++)  {
    i=abs(amatcl_(ix+ptamac_(j)));
    if (riact_(i)==1) {
      ixx=ixx+1;
      clacti_(ixx)=i;
      if (amatcl_(ix+ptamac_(j))>0) {
        centry_(ixx)=1;
      } else {
        centry_(ixx)=-1;
      }
    }
  }
  clacti_(rowmax+1)=ixx;
  return;
}
/*
 * *********************************************************
 *  subroutine sclina(j)                   
 *                                         
 *  scan a column over inactive rows.      
 *  put the row indices in clinai(i) and the row entries 
 *  in centry(i) 
 *                                         
 * *********************************************************
 * 
 */
void sclina(long j) {
/*
 */
  static long ixx,ix,i;
/*
 */
  clinai_(rowmax+1)=0;
  if (nzamac_(j)==0) {
    return;
  }
  ixx=0;
  for(ix=1; ix<=nzamac_(j); ix++)  {
    i=abs(amatcl_(ix+ptamac_(j)));
    if (riina_(i)!=0) {
      ixx=ixx+1;
      clinai_(ixx)=i;
      if (amatcl_(ix+ptamac_(j))>0) {
        centry_(ixx)=1;
      } else {
        centry_(ixx)=-1;
      }
    }
  }
  clinai_(rowmax+1)=ixx;
  return;
}
/*
 * *********************************************************
 *  subroutine srwall(i)                   
 *                                         
 *  scan a row over all columns.           
 *  put the column indices in rwallj(j) and the row entries 
 *  in rentry(j)
 *                                         
 * *********************************************************
 * 
 */
void srwall(long i) {
/*
 */
  static long jx;
/*
 */
  rwallj_(colmax+1)=nzamar_(i);
  if (rwallj_(colmax+1)==0) {
    return;
  }
  for(jx=1; jx<=nzamar_(i); jx++)  {
    if (amatrw_(jx+ptamar_(i))>0) {
      rwallj_(jx)=amatrw_(jx+ptamar_(i));
      rentry_(jx)=1;
    } else {
      rwallj_(jx)=-amatrw_(jx+ptamar_(i));
      rentry_(jx)=-1;
    }
  }
  return;
}
/*
 * *********************************************************
 *  subroutine srwact(i)                   
 *                                         
 *  scan a row over active columns.        
 *  put the column indices in rwactj(j) and the row entries 
 *  in rentry(j)
 *                                         
 * *********************************************************
 * 
 */
void srwact(long i) {
/*
 */
  static long jxx,jx,j;
/*
 */
  rwactj_(colmax+1)=0;
  if (nzamar_(i)==0) {
    return;
  }
  jxx=0;
  for(jx=1; jx<=nzamar_(i); jx++)  {
    j=abs(amatrw_(jx+ptamar_(i)));
    if (ciact_(j)!=0) {
      jxx=jxx+1;
      rwactj_(jxx)=j;
      if (amatrw_(jx+ptamar_(i))>0) {
        rentry_(jxx)=1;
      } else {
        rentry_(jxx)=-1;
      }
    }
  }
  rwactj_(colmax+1)=jxx;
  return;
}
/*
 * *********************************************************
 *  subroutine srwina(i)                   
 *                                         
 *  scan a row over inactive columns.      
 *  put the column indices in rwinaj(j) and the row entries 
 *  in rentry(j)
 *                                         
 * *********************************************************
 * 
 */
void srwina(long i) {
/*
 */
  static long jxx,jx,j;
/*
 */
  rwinaj_(colmax+1)=0;
  if (nzamar_(i)==0) {
    return;
  }
  jxx=0;
  for(jx=1; jx<=nzamar_(i); jx++)  {
    j=abs(amatrw_(jx+ptamar_(i)));
    if (ciina_(j)!=0) {
      jxx=jxx+1;
      rwinaj_(jxx)=j;
      if (amatrw_(jx+ptamar_(i))>0) {
        rentry_(jxx)=1;
      } else {
        rentry_(jxx)=-1;
      }
    }
  }
  rwinaj_(colmax+1)=jxx;
  return;
}
/*
 * *********************************************************
 *  subroutine srwfre(i)                   
 *                                         
 *  scan a row over free columns.          
 *  put the column indices in rwfrej(j) and the row entries 
 *  in rentry(j)
 *                                         
 * *********************************************************
 * 
 */
void srwfre(long i) {
/*
 */
  static long jxx,jx,j;
/*
 */
  rwfrej_(colmax+1)=0;
  if (nzamar_(i)==0) {
    return;
  }
  jxx=0;
  for(jx=1; jx<=nzamar_(i); jx++)  {
    j=abs(amatrw_(jx+ptamar_(i)));
    if (cifre_(j)!=0) {
      jxx=jxx+1;
      rwfrej_(jxx)=j;
      if (amatrw_(jx+ptamar_(i))>0) {
        rentry_(jxx)=1;
      } else {
        rentry_(jxx)=-1;
      }
    }
  }
  rwfrej_(colmax+1)=jxx;
  return;
}
/*
 * *********************************************************
 *  subroutine srwfix(i)                   
 *                                         
 *  scan a row over fixed columns.         
 *  put the column indices in cifixi(j) and the row entries 
 *  in centry(j)
 *                                         
 * *********************************************************
 * 
 */
void srwfix(long i) {
/*
 */
  static long jxx,jx,j;
/*
 */
  rwfixj_(colmax+1)=0;
  if (nzamar_(i)==0) {
    return;
  }
  jxx=0;
  for(jx=1; jx<=nzamar_(i); jx++)  {
    j=abs(amatrw_(jx+ptamar_(i)));
    if (cifix_(j)!=0) {
      jxx=jxx+1;
      rwfixj_(jxx)=j;
      if (amatrw_(jx+ptamar_(i))>0) {
        rentry_(jxx)=1;
      } else {
        rentry_(jxx)=-1;
      }
    }
  }
  rwfixj_(colmax+1)=jxx;
  return;
}
/*eject*/
/*
 * *********************************************************
 *  subroutine scalcl                      
 *                                         
 *  scale a column of problem in layer 1.  in layer 1, 
 *  scale column by -1, adjust column and row information 
 *  accordingly, including solut1(j),...,solut5(j) vectors 
 *  and cifix(j)   
 *                                         
 *  ==============                         
 *  update history                         
 *  ==============                         
 *  date       where               what was changed/reason   
 * --------------------------------------------------------
 * *********************************************************
 * 
 */
void scalcl(long j) {
/*
 */
  void sclall();
/*
 */
  static long ix,i,aij,jx,m;
/*
 *  exchange the number of positive values with the 
 *  number of negative values to reflect the scaling
 */
  m=cnallp_(j);
  cnallp_(j)=cnalln_(j);
  cnalln_(j)=m;
  m=cnactp_(j);
  cnactp_(j)=cnactn_(j);
  cnactn_(j)=m;
  m=cninap_(j);
  cninap_(j)=cninan_(j);
  cninan_(j)=m;
/*
 *  fix the column with the new value
 */
  cifix_(j)=-cifix_(j);
/*
 *  update the solution vectors
 */
  solut1_(j)=-solut1_(j);
  solut2_(j)=-solut2_(j);
  solut3_(j)=-solut3_(j);
  solut4_(j)=-solut4_(j);
  solut5_(j)=-solut5_(j);
/*
 *  update atf value
 */
  cvatf_(j)=-cvatf_(j);
/*
 *  update the scale value and cost value
 */
  scale_(j)=-scale_(j);
  cost_(j)=-cost_(j);
/*
 *  scan column j :- set up clalli, centry information
 */
  sclall(j);
/*
 *  update row information
 */
  if (clalli_(rowmax+1)>=1) {
    for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
      i=clalli_(ix);
      aij=centry_(ix);
      rnallp_(i)=rnallp_(i)-aij;
      rnalln_(i)=rnalln_(i)+aij;
      if (ciact_(j)==1) {
        rnactp_(i)=rnactp_(i)-aij;
        rnactn_(i)=rnactn_(i)+aij;
      } else {
        rninap_(i)=rninap_(i)-aij;
        rninan_(i)=rninan_(i)+aij;
      }
      if (cifre_(j)==1) {
        rnfrep_(i)=rnfrep_(i)-aij;
        rnfren_(i)=rnfren_(i)+aij;
      }
      if (cifix_(j)!=0) {
        rnfixp_(i)=rnfixp_(i)-aij;
        rnfixn_(i)=rnfixn_(i)+aij;
      }
    }
/*
 *  change column information in amatcl and amatrw
 */
    for(ix=1; ix<=clalli_(rowmax+1); ix++)  {
      i=clalli_(ix);
/*
 *  find entry in row information amatrw
 */
      for(jx=1; jx<=nzamar_(i); jx++)  {
        if (amatrw_(jx+ptamar_(i))==j*centry_(ix)) {
          amatrw_(jx+ptamar_(i))=-amatrw_(jx+ptamar_(i));
          amatcl_(ix+ptamac_(j))=-amatcl_(ix+ptamac_(j));
          goto zz200;
        }
      }
      error("scalcl  ","302     ");
    zz200:;}
  }
  return;
}
/*eject*/
/*
 * *********************************************************
 *  subroutine rstats                      
 *                                         
 *  purpose:  computes reduced summary statistics of problem 
 *            in layer 1.
 *            the data displayed is a portion of that 
 *            displayed by stats.
 *            this routine is called automatically after 
 *            loading problem.
 *                                         
 *    input:  problem in layer 1.  arrays required :         
 *               - matrix data amatcl, amatrw                
 *               - nrows, ncols, nblks     
 *               - colnam, rownam, prbnam                 
 *               - column and row information for layer 1, 
 *                 in cl and rw.
 *               - lcllim, ucllim, lrwlim, urwlim.           
 *                                         
 * *********************************************************
 * 
 */
void rstats() {
/*
 */
  static long n1,n3,n4,n5,n6,n7,i,j;
/*
 */
  if (scrflg==1) {
    printf("Problem Name: %s\n",&prbnam_(1,1));
    printf("Statistics for problem including\n");
    printf("additional variables and clauses:\n");
    printf("No. of variables = %ld\n",ncols);
    printf("No. of clauses   = %ld\n",nrows);
  }
/*
 *  max number of nonzero columns, rows and zero columns, rows
 */
  n1=0;
  n3=0;
  for(j=1; j<=ncols; j++)  {
    if (n1<cnall_(j)) {
      n1=cnall_(j);
    }
    n3=n3+cnall_(j);
  }
  if (scrflg==1) {
    printf("No. of literals  =  %ld\n",n3);
    printf("Max no. of literals for a variable =  %ld\n",n1);
  }
  n1=0;
  for(i=1; i<=nrows; i++)  {
    if (n1<rnall_(i)) {
      n1=rnall_(i);
    }
  }
  if (scrflg==1) {
    printf("Max no. of literals in a clause =  %ld\n",n1);
  }
/*
 *  number of user specified atf variables 
 *  note: there are also internally specified 
 *  atf variables, with cvatf(j) = +-2
 */
  n4=0;
  n5=0;
  n6=0;
  n7=0;
  for(j=1; j<=ncols; j++)  {
    if (cvatf_(j)==1) {
      n4=n4+1;
    } else {
      if (cvatf_(j)==-1) {
        n5=n5+1;
      } else {
        if (cvatf_(j)==2) {
          n6=n6+1;
        } else {
          if (cvatf_(j)==-2) {
            n7=n7+1;
          }
        }
      }
    }
  }
  if (scrflg==1) {
    printf(
        "No. of user specified ASSIGNTRUE  variables = %ld\n",n4);
    printf(
        "No. of user specified ASSIGNFALSE variables = %ld\n",n5);
    printf(
        "No. of additional     ASSIGNTRUE  variables = %ld\n",n6);
    printf(
        "No. of additional     ASSIGNFALSE variables = %ld\n",n7);
  }
/*
 *  upper bound on solution time for single processor
 */
  if (realts>0.) {
    if (scrflg==1) {
      printf("Time bound (sec) = %f\n",realts);
    }
  }
  if (selpgv!=0) {
    if (scrflg==1) {
      printf("Program generator version %ld was used\n",selpgv);
    }
  }
  return;
}
/*eject*/
/*
 * ******************************************************
 *  module transfer subroutines
 *
 *  contains the following transfer subroutines to move 
 *  information from layer x to layer y:-
 *             tranam(x,y) - transfer condensed column 
 *                           and row matrix information 
 *                           from layer x to layer y.
 *             trancnf(x,y)- transfer cnf row formulation 
 *                           from layer x to layer y.
 *             trancpr(x,y)- transfer compiled problem
 *                           from layer x to layer y.
 *             tranpr(x,y) - transfer column, row, 
 *                           condensed column and row 
 *                           matrix data information from
 *                           layer x to layer y.
 *             trancl(x,y) - transfer column information 
 *                           layer x to layer y.
 *             tranrw(x,y) - transfer row information 
 *                           layer x to layer y.
 *  transfer routines between blk information and layer1:
 *             tprblk      - transfer layer 1 problem 
 *                           to blk arrays
 *             tblkpr      - transfer blk arrays
 *                           to layer 1 problem
 *
 *  ==============
 *  update history
 *  ==============
 *  date        where            what changed/reason
 * --------------------------------------------------------
 * ********************************************************
 * 
 * 
 *
 * ********************************************************
 *  subroutine trancnf(k1,k2)
 *
 *  purpose: transfer cnf formulation between layers.
 * ********************************************************
 * 
 */
void trancnf(long k1,long k2) {
/*
 */
long i,j,jx;
/*
 *  transfer size parameters and row names
 */
  if (k1==1) {
    ncls_(k2) = ncols;
    nrws_(k2) = nrows;
    nnzs_(k2) = nanzs;
  } else {
    ncls_(k2) = ncls_(k1);
    nrws_(k2) = nrws_(k1);
    nnzs_(k2) = nnzs_(k1);
  }
  if (k2==1) {
    ncols = ncls_(k1);
    nrows = nrws_(k1);
    nanzs = nnzs_(k1);
  }
/*
 *  transfer col names with delete option
 */
  for (j=1;j<=ncls_(k2);j++) {
    strcpy(&clnam_(1,j,k2),&clnam_(1,j,k1));
    strcpy(&clnam_(58,j,k2),&clnam_(58,j,k1));
  }
/*
 *  transfer row names with level and add/delete option
 */
  for (i=1; i<=nrws_(k2); i++) {
    strcpy(&rwnam_(1,i,k2),&rwnam_(1,i,k1));
    strcpy(&rwnam_(54,i,k2),&rwnam_(54,i,k1));
  }
/*
 *  transfer cvatf, trucst, falcst column information
 */
  for(j=1; j<=ncls_(k2); j++)  {
    cl_(j,24,k2)=cl_(j,24,k1);
    trcst_(j,k2) = trcst_(j,k1);
    flcst_(j,k2) = flcst_(j,k1);
  }
/*
 *  transfer complete amr information
 */
  for(i=1; i<=nrws_(k2); i++)  {
    ptamr_(i,k2)=ptamr_(i,k1);
    if (nzamr_(i,k1)>0) {
      for(jx=1; jx<=nzamr_(i,k1); jx++)  {
        amr_(jx+ptamr_(i,k2),k2)=amr_(jx+ptamr_(i,k1),k1);
      }
    } else {
/*
 *  error, row i must be nonzero
 */
      error("trancnf","302");
    }
    nzamr_(i,k2)=nzamr_(i,k1);
  } 
  return;
} 
/* ********************************************************
 *  subroutine trancpr(k1,k2)
 *
 *  purpose: transfer compiled problem 
 *           between layers.
 *  caution: before subsequent use, must execute
 *             cbllim: block limits
 *             ranges: range data
 *             retain: retain indices
 * ********************************************************
 * 
 */
void trancpr(long k1,long k2) {
/*
 */
long i,ix,j,jx,l,q;
/*
 *  transfer size parameters and
 *  solution algorithm flags
 */
  if (k1==1) {
    ncls_(k2) = ncols;
    nrws_(k2) = nrows;
    nnzs_(k2) = nanzs;
    nbks_(k2) = nblks;
    for (q=1;q<=nbks_(k2);q++) {
      twost_(q,k2) = twosat_(q);
    }
  } else {
    ncls_(k2) = ncls_(k1);
    nrws_(k2) = nrws_(k1);
    nnzs_(k2) = nnzs_(k1);
    nbks_(k2) = nbks_(k1);
    for (q=1;q<=nbks_(k2);q++) {
      twost_(q,k2) = twost_(q,k1);
    }
  }
  if (k2==1) {
    ncols = ncls_(k1);
    nrows = nrws_(k1);
    nanzs = nnzs_(k1);
    nblks = nbks_(k1);
    for (q=1;q<=nbks_(k2);q++) {
      twosat_(q) = twost_(q,k1);
    }
  }

/*
 *  transfer cl information
 */
  for(l=1; l<=lclmax; l++)  {
    for(j=1; j<=ncls_(k2); j++)  {
      cl_(j,l,k2)=cl_(j,l,k1);
    }
  }
/*
 *  transfer rw information
 */
  for(l=1; l<=lrwmax; l++)  {
    for(i=1; i<=nrws_(k2); i++)  {
      rw_(i,l,k2)=rw_(i,l,k1);
    }
  }
/*
 *  transfer amc counts 
 */
  for(j=1; j<=ncls_(k2); j++)  {
    ptamc_(j,k2)=ptamc_(j,k1);
    if (nzamc_(j,k1)!=0) {
      for(ix=1; ix<=nzamc_(j,k1); ix++)  {
        amc_(ix+ptamc_(j,k2),k2)=amc_(ix+ptamc_(j,k1),k1);
      }
    }
    nzamc_(j,k2)=nzamc_(j,k1);
  }
/*
 *  transfer complete amr information
 */
  for(i=1; i<=nrws_(k2); i++)  {
    ptamr_(i,k2)=ptamr_(i,k1);
    if (nzamr_(i,k1)!=0) {
      for(jx=1; jx<=nzamr_(i,k1); jx++)  {
        amr_(jx+ptamr_(i,k2),k2)=amr_(jx+ptamr_(i,k1),k1);
      }
    }
    nzamr_(i,k2)=nzamr_(i,k1);
  }
  return;
} 
/* ********************************************************
 *  subroutine tranpr(k1,k2)
 *
 *  purpose: transfer column, row, matrix and name information 
 *           between layers.
 * ********************************************************
 * 
 */
void tranpr(long k1,long k2) {
/*
 */
  void tranam();
  void trancl();
  void tranrw();
/*
 */
  tranam(k1,k2);
  trancl(k1,k2);
  tranrw(k1,k2);
/*
 */
  return;
}
/*
 * ***********************************************************
 *  subroutine trancl(k1,k2)
 *
 *  purpose: transfer column information between layers.
 * ***********************************************************
 * 
 */
void trancl(long k1,long k2) {
  static long j,l;
/*
 */
  for(l=1; l<=lclmax; l++)  {
    for(j=1; j<=ncols; j++)  {
      cl_(j,l,k2)=cl_(j,l,k1);
    }
  }
  return;
}
/*
 * *********************************************************
 *  subroutine tranrw(k1,k2)
 *
 *  purpose: transfer row information between layers.
 * *********************************************************
 * 
 */
void tranrw(long k1,long k2) {
/*
 */
  static long i,l;
/*
 */
  for(l=1; l<=lrwmax; l++)  {
    for(i=1; i<=nrows; i++)  {
      rw_(i,l,k2)=rw_(i,l,k1);
    }
  }
  return;
}
/*
 * *********************************************************
 *  subroutine tranam(k1,k2)
 * 
 *  purpose: transfer matrix information between layers.
 * *********************************************************
 * 
 */
void tranam(long k1,long k2) {
/*
 */
  static long j,ix,i,jx;
/*
 */
  for(j=1; j<=ncols; j++)  {
    ptamc_(j,k2)=ptamc_(j,k1);
    if (nzamc_(j,k1)!=0) {
      for(ix=1; ix<=nzamc_(j,k1); ix++)  {
        amc_(ix+ptamc_(j,k2),k2)=amc_(ix+ptamc_(j,k1),k1);
      }
    }
    nzamc_(j,k2)=nzamc_(j,k1);
  }
  for(i=1; i<=nrows; i++)  {
    ptamr_(i,k2)=ptamr_(i,k1);
    if (nzamr_(i,k1)!=0) {
      for(jx=1; jx<=nzamr_(i,k1); jx++)  {
        amr_(jx+ptamr_(i,k2),k2)=amr_(jx+ptamr_(i,k1),k1);
      }
    }
    nzamr_(i,k2)=nzamr_(i,k1);
  }
  return;
}
/*
 * *********************************************************
 *  subroutine tprblk
 *
 *  purpose: transfer matrix information
 *           from layer 1 problem to blk section 
 * *********************************************************
 * 
 */
void tprblk() {
/*
 */
  static long i,ix,j,jx;
/*
 */
  for(j=1; j<=ncols; j++)  {
    ptablc_(j)=ptamac_(j);
    if (nzamac_(j)!=0) {
      for(ix=1; ix<=nzamac_(j); ix++)  {
        ablkcl_(ix+ptamac_(j))=amatcl_(ix+ptamac_(j));
      }
    }
    nzablc_(j)=nzamac_(j);
  }
  for(i=1; i<=nrows; i++)  {
    ptablr_(i)=ptamar_(i);
    if (nzamar_(i)!=0) {
      for(jx=1; jx<=nzamar_(i); jx++)  {
        ablkrw_(jx+ptamar_(i))=amatrw_(jx+ptamar_(i));
      }
    }
    nzablr_(i)=nzamar_(i);
  }
  return;
}
/*
 * **********************************************************
 *  subroutine tblkpr
 *
 *  purpose: transfer matrix information
 *           from blk section to layer 1 problem
 * **********************************************************
 * 
 */
void tblkpr() {
/*
 */
  static long i,ix,j,jx;
/*
 */
  for(j=1; j<=ncols; j++)  {
    ptamac_(j)=ptablc_(j);
    if (nzablc_(j)!=0) {
      for(ix=1; ix<=nzablc_(j); ix++)  {
        amatcl_(ix+ptablc_(j))=ablkcl_(ix+ptablc_(j));
      }
    }
    nzamac_(j)=nzablc_(j);
  }
  for(i=1; i<=nrows; i++)  {
    ptamar_(i)=ptablr_(i);
    if (nzablr_(i)!=0) {
      for(jx=1; jx<=nzablr_(i); jx++)  {
        amatrw_(jx+ptablr_(i))=ablkrw_(jx+ptablr_(i));
      }
    }
    nzamar_(i)=nzablr_(i);
  }
  return;
}
/*eject*/
/*
 * ******************************************************
 *  module transfer process
 *
 *  contains the following transfer subroutines to move 
 *  information from leibniz to trsvar and vice versa
 *      trserrmsg    - handle transfer error message
 *      trsleibtovar - transfer from leibniz to trsvar
 *      trsvartoleib - transfer from trsvar to leibniz
 *
 *  ==============
 *  update history
 *  ==============
 *  date        where            what changed/reason
 * --------------------------------------------------------
 * ********************************************************
 *
 * --------------------------------------------------------------
 *  subroutine trserrmsg
 * 
 *  purpose:  handle transfer error message
 * 
 *    input:  message index k
 *
 *   output:  errval (= k)
 *
 * -------------------------------------------------------------- 
 */
void trserrmsg(int k) {
/*
 */
  void errmsg();
/*
 */
  errval = k;
  errmsg();
  return;
}
/*eject*/
/* ********************************************************
 *
 * --------------------------------------------------------------
 *  subroutine trsleibtovar
 * 
 *  purpose:  transfer from leibniz to trsvar
 * 
 *    input:  ciact, ciina, cifre, cifix, cvatf
 *
 *   output:  trsvar
 *
 *  caution:  user value trsvar_(j)=0 is replaced by nonzero
 *            if in preceding trsvartoleib() call column j
 *            was determined to be not deletable and therefore
 *            deletion was not carried out  
 * -------------------------------------------------------------- 
 */
void trsleibtovar() {
/*
 */

  for(jnam=1; jnam<=ncols; jnam++)  {
/*
 *  skip variable if its name begins with '*'
 *  since such variable is not user accessible
 */
    if (colnam_(1,jnam)!='*') {
      jscan = idxcol_(jnam);
/*
 *  jnam is name index
 *  jscan is inside index
 */
      if ((trsvar_(jnam)<=2)&&
          (trsvar_(jnam)>=-2)) {
/*
 *  user has not fixed value by >=3 or <=-3
 */
        if ((ciact_(jscan)==1)&&
            (solut1_(jscan)!=0)) {
/*
 *  variable is active and solution value is nonzero
 *  assign trsvar the scaled solution value
 */
          trsvar_(jnam)=solut1_(jscan)*scale_(jscan);
        } else if ((ciact_(jscan)==1)&&
                   (solut1_(jscan)==0)) {
/*
 *  variable is active and solution value is 0
 *  assign trsvar -1
 */
          trsvar_(jnam)=-1;
        } else if (cvatf_(jscan)>0) {
/*
 *  variable is atf (+1) or monotone nonneg (+2)
 *  assign scaled value +-1 corresponding to internal +1/+2
 */
          trsvar_(jnam)= 1*scale_(jscan);        
        } else if (cvatf_(jscan)<0) {
/*
 *  variable is atf (-1) or monotone nonneg (-2)
 *  assign scaled value +-1 corresponding to internal -1/-2
 */
          trsvar_(jnam)= (-1)*scale_(jscan);
        } else {
/*
 *  error, remaining columns must have been fixed by 
 *  >=3 or <=-3 of user
 */
          error("trsleibtovar","102");
        }
      }
    }
  }
}
/*eject*/
/*
 * --------------------------------------------------------------
 *  subroutine trsvartoleib
 * 
 *  purpose:  transfer from trsvar to leibniz
 * 
 *    input:  trsvar
 *
 *   output:  ciact, ciina, cifre, cifix
 *
 *  caution:  carries out deletion specified by trsvar_(j)=0
 *            only if delete option is specified for column j
 *            if delete option is not specified, column j remains
 *            active/fixed as is currently the case, with no
 *            change attempted, and a warning message is given  
 * -------------------------------------------------------------- 
 */
void trsvartoleib(char *ucomnd,char *uname,char *ustate,
                   char *utype,long *uvalue,short *uerror) {
/*
 */
  void errmsg();
  void disprm();
/*
 */
  for(jnam=1; jnam<=ncols; jnam++)  {
/*
 *  skip variable if its name begins with '*'
 *  since such variable is not user accessible
 */
    if (colnam_(1,jnam)!='*') {
      jscan = idxcol_(jnam);
/*
 *  jnam is name index
 *  jscan is inside index
 */
      if ((trsvar_(jnam)>=3)||
          (trsvar_(jnam)<=-3)) {
/*
 *  user has fixed value to true or false by >=3 or <=-3
 *
 *  set cifix(jscan) and cifre(jscan) to new values
 */
        if (cifre_(jscan)!=0) {
          icfrin(jscan);
        } else if (cifix_(jscan)!=0) {
          icfxin(jscan);
        }
/*
 *  set ciina(jscan) to new value
 */
        if (((trsvar_(jnam)>=3)&&
             (scale_(jscan)==1))||
            ((trsvar_(jnam)<=-3)&&
             (scale_(jscan)==-1))) {
          ciina_(jscan)=1;
        } else {
          ciina_(jscan)=-1;
        }
      } else if (trsvar_(jnam)==0) {
/*
 *  user has deleted variable
 */
        if (dlclop_(jscan)==1) {
/*
 *  set cifix(jscan) and cifre(jscan) to new values
 */
          if (cifre_(jscan)!=0) {
            icfrin(jscan);
          } else if (cifix_(jscan)!=0) {
            icfxin(jscan);
          }
/*
 *  update ciina(jscan) 
 */
          if (ciina_(jscan)!=2) {
            ciina_(jscan)=2;
          }
        } else {
/*
 *  delete variable option not specified
 */
          uerror_(1)=warn;
          errval=0030;
          errmsg();
          if (scrflg==1) {
            printf(": %s",&colnam_(1,jnam));
          }
          fprintf(errfil,": %s",&colnam_(1,jnam));
          disprm(ucomnd,uname,ustate,utype,uvalue,uerror);
        }
/*
 *  remaining case: user has specified variable to be active
 */
      } else {
        if (ciina_(jscan)!=0) {
          if (cvatf_(jscan)!=0) {
/*
 *  variable jscan is atf type. 
 *  reset to default true/false value if
 *  not already at that value
 *  note: cvatf(jscan) may be 0, +/-1, +/-2, where
 *  the third case is due to monotone column assignment
 *  in monotn
 */
            if ((cvatf_(jscan)>0)&&
                (ciina_(jscan)!=1)) {
              ciina_(jscan)=1;
            } else if ((cvatf_(jscan)<0)&&
                       (ciina_(jscan)!=-1)) {
              ciina_(jscan)=-1;
            }
          } else {
/*
 *  variable jscan is non-atf type. move to active.  decide on
 *  free/fixed according to cifrer (which indicates whether
 *  column was originallly free)
 */
            if (cifrer_(jscan)!=0) {
              icinfr(jscan);
            } else {
              icinfx(jscan);
            }
          }
        }
      }
    }
  }
}
/*eject*/
/*
 * *******************************************************
 *  subroutine wrtcnf
 * 
 *       write out cnf formulation in layer 1
 *
 *   input : optimz, prbnam, ncols, nrows, nanzs,
 *           colnam, cvatf, trucst, falcst,
 *           rownam, nzamar, ptamar, amatrw
 *
 *   output:  cnf formulation
 * 
 * *******************************************************
 * 
 */
void wrtcnf() {
/*
 */
  static long i,j,jx,js;
/*
 *  optimization flag, problem name, 
 *  no. of cols, rows, nonzeros
 */
  printf("\n****begin of cnf formulation****\n");
  printf(
    "\n"
    "optimz flag     = %ld\n"
    "problem name    = %s\n"
    "no. of cols     = %ld\n"
    "no. of rows     = %ld\n"
    "no. of nonzeros = %ld\n",
    optimz, prbnam, ncols, nrows, nanzs);
/*
 *  column information: index, cvatf, trucst, falcst, 
 *  colnam including delete option, 
 */
  printf(
    "\n"
    "variables\n"
    "index  cvatf  trucst  falcst  delopt ciblk name\n");   
  for (j=1;j<=ncols;j++) {
    printf("%5ld  %5ld  %6ld  %6ld     %s%6ld   %s\n",
      j, cvatf_(j), trucst_(j),  falcst_(j),
      &colnam_(58,j), ciblk_(j), &colnam_(1,j));
  }
/*
 *  row information: index, options, name, clause on 
 *  subsequent lines
 */
  printf(
    "\n"
    "clauses\n"
    "index  options riblk clause name\n");
  for (i=1;i<=nrows;i++) {
    printf("%5ld    %s  %2ld   %s\n                    ",
      i, &rownam_(54,i), riblk_(i), &rownam_(1,i));
    for (jx=1;jx<=nzamar_(i);jx++) {
      if ((jx % 8)==0) {
        printf("\n                    ");
      }
      js = amatrw_(jx+ptamar_(i));
      printf("%6ld",js);
    }
    printf("\n");    
  }
/*
 *  comment out section below when input cnf is printed
 *  leave in if internal matrix is printed since then
 *  link of names to rows and variables is needed
 */
  printf("\ncolumns\n");
  for(j=1; j<=ncols; j++)  {
     printf("j = %3ld colnam(1,j) = %10s idxcol_(j) = %ld\n",
             j, &colnam_(1,j), idxcol_(j));
   }
   printf("\nrows\n");
   for(i=1; i<=nrows; i++)  {
     printf("i = %3ld rownam(1,i) = %10s idxrow_(i) = %ld\n",
             i, &rownam_(1,i), idxrow_(i));
   }
/*
 *  end of section for names of variables and rows
 */
  printf("\n****end of cnf formulation****\n\n");
}
/*  last record of exutil.c ****** */
