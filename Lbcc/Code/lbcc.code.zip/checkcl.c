/*  first record of checkcl.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

void checkcl(long l,long k) {
  long j;
  for (j=1;j<=ncols;j++) {
    if (cl_(j,l,k)!=0) {
      printf("\ncl_(%ld,%ld,%ld) = %ld",j,l,k,cl_(j,l,k));
      lbccexit(0);
    }
  }
}
