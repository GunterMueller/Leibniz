/*  first record of execute.c***** */
/*
 * -----------------------------------------------------
 * leibniz interactive command module
 * copyright 1990-2000 by Leibniz Company, Plano, Texas
 * 
 * purpose: interactive execution
 * -----------------------------------------------------
 *
 */ 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
/*
 */
int main() {
/*
 *  include leibnizmacro.h file, which contains
 *     - leibniz parameters for procedures
 *     - alternate definitions of leibniz procedures
 */
#include "leibnizmacro.h"
/*
 * miscellaneous variables
 */
  static long i, n, num;
  static char comnd[64+1];
  static long num_cols=0,num_rows=0;
  static char srecord[128];
  static PRGNAME_ARRAY prgname[20];
  static CLAUSE_ARRAY clause[20];
/*eject*/
/*
 *  begin program
 */
  printf(
   "Leibniz Interactive Execution Module Version 5.0\n"
   "Caution: If logic programs are executed that  have  been\n"
   "         compiled with the transfer option, then  cannot\n"
   "         get or modify values of variables interactively\n");
/*
 *  set error limits
 */
  value[0] = 50; /* limit on warnings        */
  value[1] = 50; /* limit on nonfatal errors */
  value[2] = 0;  /* limit on fatal errors    */
  limit_error();
/*
 */
  main_loop:;
  errcde[0] = 0;
  printf("\nCommand> ");
  scanf("%s",comnd);
  n = strlen(comnd);
  gets(&comnd[n]);
/*-------------------------------------------
 * determine which command was given and execute 
 *-------------------------------------------
 */
/*eject*/
/*----------------
 * assign device        
 *----------------
 */
  if (strcmp(comnd,"assign device") == 0) {
/*  
 *  define error file
 */
    strcpy(name,"execute.err"); 
    printf("All error messages saved in execute.err\n");
/*
 *  determine if error messages also on screen
 */
    printf("Specify if error output on screen\n"
           "( =1 on screen, =-1 not on screen): ");
    scanf("%ld",&value[0]);
/*
 *  get values for problem parameters
 */
    printf("Enter COLMAX parameter (min = 2): ");
    scanf("%ld",&value[1]);
    printf("Enter ROWMAX parameter (min = 2): ");
    scanf("%ld",&value[2]);
    printf("Enter ANZMAX parameter (min = 2): ");
    scanf("%ld",&value[3]);
    printf("Enter BLKMAX parameter (min = 2): ");
    scanf("%ld",&value[4]);
    printf("Enter PRBMAX parameter (min = 2): ");
    scanf("%ld",&value[5]);
    printf("Enter STOMAX parameter (min = 2): ");
    scanf("%ld",&value[6]);
    assign_device();
    if (errcde[0] != 0) {
      printf(
       "Error received from assign_device = %hd\n",errcde[0]);
    } else {
      printf(
       "Memory has been allocated and\n"
       "error output device assigned\n");
      printf("COLMAX parameter = %ld\n",value[1]);
      printf("ROWMAX parameter = %ld\n",value[2]);
      printf("ANZMAX parameter = %ld\n",value[3]);
      printf("BLKMAX parameter = %ld\n",value[4]);
      printf("PRBMAX parameter = %ld\n",value[5]);
      printf("STOMAX parameter = %ld\n",value[6]);
      printf("Memory used for arrays (Kbytes) = %ld\n",
             value[7]);
      printf(
      "Leibniz System Version (Execution Module) = %s\n",type);
    }
/*
 *  reset error limits
 */
    value[0] = 50; /* limit on warnings        */
    value[1] = 50; /* limit on nonfatal errors */
    value[2] = 0;  /* limit on fatal errors    */
    limit_error();
    goto main_loop;
  }
/*eject*/
/*-----------------
 * begin problem
 *-----------------
 */
  if (strcmp(comnd,"begin problem") == 0) {
    printf("Enter pathname of program file: ");
    gets(name);
    begin_problem();
    if (errcde[0] != 0) {
      printf(
        "Error received from begin_problem = %hd\n",errcde[0]);
    } else {
      printf("Problem has been loaded\n");
      printf("Problem name = %s\n",name);
      printf("Problem type = %s\n",type);
      printf("Number of variables (user defined) = %ld\n",
             value[0]);
      printf("Number of clauses/goals (total) = %ld\n",
              value[1]);
      num_cols = value[0];
      num_rows = value[1];
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * delete problem
 *-----------------
 */
  if (strcmp(comnd,"delete problem") == 0) {
    printf("Enter name of problem: ");
    gets(name);
    delete_problem();
    if (errcde[0] != 0) {
      printf
        ("Error received from delete problem = %hd\n",errcde[0]);
    } else {
      printf("Problem has been deleted\n");
      printf("Total number of problems after deletion = %ld\n",
             value[1]);
      printf("Total number of storage records in use = %ld\n",
             value[2]);
      printf("Total number of storage records not used = %ld\n",
             value[3]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * execute lbcc
 *-----------------
 */
  if (strcmp(comnd,"execute lbcc") == 0) {
    execute_lbcc();
    if (errcde[0] != 0) {
      printf(
       "Error received from execute_lbcc = %hd\n",errcde[0]);
    } else {
      printf("Problem has been compiled\n");
      printf("Problem name = %s\n",name);
      printf("Problem type = %s\n",type);
      printf("Number of variables (user defined) = %ld\n",
             value[0]);
      printf("Number of clauses/goals (total) = %ld\n",
              value[1]);
      num_cols = value[0];
      num_rows = value[1];
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * free device
 *-----------------
 */
  if (strcmp(comnd,"free device") == 0) {
    free_device();
    if (errcde[0] != 0) {
      printf(
        "Error received from free_device = %hd\n",errcde[0]);
    } else {
      printf(
      "Memory deallocated and error output device closed\n");
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * get clsname
 *-----------------
 */
  if (strcmp(comnd,"get clsname") == 0) {
    printf("Enter clause or goal index: ");
    scanf("%ld",&value[0]);
    get_clsname();
    if (errcde[0] != 0) {
      printf(
       "Error received from get_clause_name = %hd\n",errcde[0]);
    } else {
      printf("Clause or goal name = %s\n",name);
      printf("(name = blank implies no external name)\n");
      printf("Type = %s\n",type);
      printf("Status of clause or goal = %s\n",state);
      printf("Likelihood level of clause or goal = %ld\n",
             value[1]);
    }
    goto main_loop;
  }
/*eject*/
/*----------------
 * get dual
 *-----------------
 */
  if (strcmp(comnd,"get dual") == 0) {
    printf("Enter clause or goal index: ");
    scanf("%ld",&value[0]);
    get_dual();
    if (errcde[0] != 0) {
      printf(
       "Error received from get_dual = %hd\n",errcde[0]);
    } else {
      printf("Clause or goal name = %s\n",name);
      printf("(name = blank implies no external name)\n");
      printf("Type = %s\n",type);
      printf("Dual value of clause or goal = %ld\n",value[2]);
      printf("Status of clause or goal = %s\n",state);
      printf("Likelihood level of clause or goal = %ld\n",
             value[1]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * get goal
 *-----------------
 */
  if (strcmp(comnd,"get goal") == 0) {
    printf("Enter name: ");
    gets(name);
    get_goal();
    if (errcde[0] != 0) {
      printf(
       "Error received from get_goal = %hd\n",errcde[0]);
    } else {
      printf("Status of clause or goal = %s\n",state);
      printf("Goal quantity = %ld\n",value[0]);
      printf("Cost of low usage = %ld\n",value[1]);
      printf("Cost of high usage = %ld\n",value[2]);
      printf("Solution indicator = %ld\n",value[3]);
      printf("(= 0: not solved; = 1: solved)\n");
      if (value[3] == 1) {
        printf("Goal usage = %ld\n",value[4]);
      }
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * get primal
 *-----------------
 */
  if (strcmp(comnd,"get primal")==0) {
    name[0] = '\0';
    printf("Enter name of variable (blank -> ALL) or 'index': ");
    gets(name);
    if (name[0] == '\0') {
      for (i=1; i<=num_cols; i++) {
        value[0] = i;
        get_primal();
        if (errcde[0] != 0) {
          printf("Error received from get_primal = %hd\n",
                 errcde[0]);
          goto main_loop;
        } else {
             printf("%s     %s\n",name,state);
      }
    }
  } else {
    if (strcmp(name,"index") == 0) {
        printf("Enter index: ");
       scanf("%ld",&value[0]);
     } else {
       value[0] = 0;
     }
    get_primal();
     if (errcde[0] != 0) {
        printf(
         "Error received from get_primal = %hd\n",errcde[0]);
     } else {
       printf("%s     %s\n",name,state);
     }
   }
   goto main_loop;
  }
/*eject*/
/*-----------------
 * get value
 *-----------------
 */
  if (strcmp(comnd,"get value")==0) {
    name[0] = '\0';
    printf("Enter name of variable (blank -> ALL) or 'index': ");
    gets(name);
    if (name[0] == '\0') {
      for (i=1; i<=num_cols; i++) {
        value[0] = i;
        get_value();
        if (errcde[0] != 0) {
          printf("Error received from get_value = %hd\n",
                  errcde[0]);
          goto main_loop;
        } else {
          printf("%s     %s\n",name,state);
        }
      }
    } else {
      if (strcmp(name,"index") == 0) {
        printf("Enter index: ");
        scanf("%ld",&value[0]);
      } else {
        value[0] = 0;
      }
      get_value();
      if (errcde[0] != 0) {
        printf(
         "Error received from get_value = %hd\n",errcde[0]);
      } else {
        printf("%s     %s\n",name,state);
      }
    }
    goto main_loop;
  }
/*eject*/
/*----------------
 * initialize problem        
 *----------------
 */
  if (strcmp(comnd,"initialize problem") == 0) {
/*
 *  get prg file names
 */
    i = 0;
    moreprg:;
    printf("Enter prg file name (blank -> done): ");
    gets(prgname[i]);
    if (prgname[i][0]!='\0') {
      i++;
      goto moreprg;
    }
/*  
 *  define error file
 */
    strcpy(name,"execute.err"); 
    printf("All error messages saved in execute.err\n");
/*
 *  determine if error messages also on screen
 */
    printf("Specify if error output on screen\n"
           "( =1 on screen, =-1 not on screen): ");
    scanf("%ld",&value[0]);
    initialize_problem();
    if (errcde[0] != 0) {
      printf(
      "Error received from initialize_problem = %hd\n",errcde[0]);
    } else {
      num_cols = value[0];
      num_rows = value[1];
      printf(
       "Memory has been allocated and\n"
       "error output device assigned\n"
       "All prg files have been read and all problems stored\n"
       "Problem below is loaded\n");
      printf("Problem name = %s\n",name);
      printf("Type = %s\n",type);
      printf("State = %s\n",state);
      printf("Number of variables (user defined) = %ld\n",
        value[0]); /* value[0] must be = num_cols */
      printf("Number of clauses and goals = %ld\n",
        value[1]); /* value[1] must be = num_rows */
      printf("Number of goals = %ld\n",value[4]);
      if (strcmp(state,"") == 0) {
        printf("Caution: Transfer process is used; cannot get\n"
               "         or modify the values of variables in\n" 
               "         this interactive program\n");
      } else {
        printf("Transfer process is not used\n");
      }
    }
/*
 *  reset error limits
 */
    value[0] = 50; /* limit on warnings        */
    value[1] = 50; /* limit on nonfatal errors */
    value[2] = 0;  /* limit on fatal errors    */
    limit_error();
    goto main_loop;
  }
/*eject*/
/*-----------------
 * limit error
 *-----------------
 */
  if (strcmp(comnd,"limit error")==0) {
    printf("Enter limit on number of warnings: ");
    scanf("%ld",&value[0]);
    printf("Enter limit on number of nonfatal errors: ");
    scanf("%ld",&value[1]);
    printf("Enter limit on number of fatal errors: ");
    scanf("%ld",&value[2]);
    limit_error();
    if (errcde[0] != 0) {
      printf("Error received from limit_error = %hd\n",errcde[0]);
    } else {
      printf(
        "Limit on number of warnings        = %ld\n",value[0]);
      printf(
        "Limit on number of nonfatal errors = %ld\n",value[1]);
      printf(
        "Limit on number of fatal errors    = %ld\n",value[1]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * maxcls sat
 *-----------------
 */
  if (strcmp(comnd,"maxcls sat")==0) {
/*
 *  get clause names
 */
    i = 0;
    morecls1:;
    printf("Enter clause name (blank -> done): ");
    gets(clause[i].name);
    if (clause[i].name[0]!='\0') {
      i++;
      goto morecls1;
    }
    num = i;
/*
 *  find max set of satisfiable clauses
 */
    maxcls_sat();
    if (errcde[0] != 0) {
      printf(
        "Error received from maxcls_sat = %hd\n",errcde[0]);
    } else {
/*
 *
 */
      for (i=0;i<=num;i++) {
        if (clause[i].status==-1) {
          printf("Unknown clause name: %s\n",clause[i].name); 
        }
      }
      if (strcmp(state,"U")==0) {
        printf("Problem is unsatisfiable even if all specified\n"
               "clauses are deleted\n");
      } else {
        printf("Problem has become satisfiable with\n"
               "the following changes of clauses:\n");
        printf("  Clauses activated (set is maximal):\n");    
        for (i=0;i<=num;i++) {
          if (clause[i].status==1){
            printf("    %s\n",clause[i].name);
          }
        }
        printf("  Clauses deleted (set is minimal):\n");    
        for (i=0;i<=num;i++) {
          if (clause[i].status==0){
            printf("    %s\n",clause[i].name);
          }
        } 
      }
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * mincls unsat
 *-----------------
 */
  if (strcmp(comnd,"mincls unsat")==0) {
/*
 *  get clause names
 */
    i = 0;
    morecls2:;
    printf("Enter clause name (blank -> done): ");
    gets(clause[i].name);
    if (clause[i].name[0]!='\0') {
      i++;
      goto morecls2;
    }
    num = i;
/*
 *  find min set of unsatisfiable clauses
 */
    mincls_unsat();
    if (errcde[0] != 0) {
      printf(
       "Error received from mincls_unsat = %hd\n",errcde[0]);
    } else {
/*
 *
 */
      for (i=0;i<=num;i++) {
        if (clause[i].status==-1) {
          printf("Unknown clause name: %s\n",clause[i].name); 
        }
      }
      if (strcmp(state,"S")==0) {
        printf("Problem is satisfiable even if all specified\n"
               "clauses are activated\n");
      } else {
        printf("Problem has become unsatisfiable with\n"
               "the following changes of clauses:\n");
        printf("  Clauses activated (set is minimal):\n");    
        for (i=0;i<=num;i++) {
          if (clause[i].status==1){
            printf("    %s\n",clause[i].name);
          }
        }
        printf("  Clauses deleted (set is maximal):\n");    
        for (i=0;i<=num;i++) {
          if (clause[i].status==0){
            printf("    %s\n",clause[i].name);
          }
        } 
      }
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * modify allvar
 *-----------------
 */
  if (strcmp(comnd,"modify allvar")==0) {
    printf("Enter value for all user variables (T/F/D/A): ");
    scanf("%s",state);
    modify_allvar();
    if (errcde[0] != 0) {
      printf(
      "Error received from modify_allvar = %hd\n",
      errcde[0]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * modify clause
 *-----------------
 */
  if (strcmp(comnd,"modify clause")==0) {
    name[0] = '\0';
    printf("Enter name (wildcard ? allowed): ");
    gets(name);
    printf("Enter lowest likelihood level: ");
    scanf("%ld",&value[0]);
    printf("Enter highest likelihood level: ");
    scanf("%ld",&value[1]);
    printf("Enter clause code (A/D/L): ");
    scanf("%s",state);
    if ((state[0] == 'L') ||
        (state[0] == 'l')) {
      printf("Enter new likelihood level: ");
      scanf("%ld",&value[4]);
    }
    modify_clause();
    if (errcde[0] != 0) {
      printf(
       "Error received from modify_clause = %hd\n",errcde[0]);
    } else {
      printf("Number of matching clauses = %ld\n",value[2]);
      printf("Number of clauses modified = %ld\n",value[3]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * modify goal
 *-----------------
 */
  if (strcmp(comnd,"modify goal")==0) {
    name[0] = '\0';
    printf("Enter name (wildcard ? allowed): ");
    gets(name);
    printf("Enter goal code (A/D/Q/L/H/P): ");
    scanf("%s",state);
    if ((state[0] == 'Q') ||
        (state[0] == 'q')) {
      printf("Enter new goal quantity: ");
      scanf("%ld",&value[0]);
    }
    if ((state[0] == 'L') ||
    (state[0] == 'l')) {
      printf("Enter new cost of low usage: ");
      scanf("%ld",&value[1]);
    }
    if ((state[0] == 'H') ||
        (state[0] == 'h')) {
      printf("Enter new cost of high usage: ");
      scanf("%ld",&value[2]);
    }
    if ((state[0] == 'P') ||
        (state[0] == 'p')) {
      printf("Enter new goal quantity: ");
      scanf("%ld",&value[0]);
      printf("Enter new cost of high usage: ");
      scanf("%ld",&value[1]);
      printf("Enter new cost of low usage: ");
      scanf("%ld",&value[2]);
    }
    modify_goal();
    if (errcde[0] != 0) {
      printf(
       "Error received from modify_goal = %hd\n",errcde[0]);
    } else {
      printf("Number of matching goals = %ld\n",value[3]);
      printf("Number of goals modified = %ld\n",value[4]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * modify problem
 *-----------------
 */
  if (strcmp(comnd,"modify problem") == 0) {
    printf("Enter new problem type (MIN/SAT): ");
    scanf("%s",type);
    modify_problem();
    if (errcde[0] != 0) {
      printf(
        "Error received from modify_problem = %hd\n",errcde[0]);
    } else {
      printf("Problem type modified as requested\n");
      printf("Number of variables (user defined) = %ld\n",
       value[0]); /* value[0] must be = num_cols */
      printf("Number of clauses and goals = %ld\n",
        value[1]); /* value[1] must be = num_rows */
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * modify variable
 *-----------------
 */
  if (strcmp(comnd,"modify variable")==0) {
    name[0] = '\0';
    printf("Enter name (wildcard ? allowed, but\n");
    printf("may not be empty string), or 'index': ");
    gets(name);
    if (strcmp(name,"index") == 0) {
      printf("Enter index: ");
      scanf("%ld",&value[0]);
    } else {
    value[0] = 0;
    }
    printf("Enter variable code (T/F/D/A/M/G): ");
    scanf("%s",state);
    if ((state[0] == 'M') ||
        (state[0] == 'm')) {
      printf("Enter new cost for True: ");
      scanf("%ld",&value[4]);
      printf("Enter new cost for False: ");
      scanf("%ld",&value[5]);
    }
    if ((state[0] == 'G') ||
        (state[0] == 'g')) {
      printf("Enter new goal name: ");
      printf("(Press return to eliminate goal): ");
      gets(&name[60]);
      if (name[60] == '\0') {
        value[6] = 0;
      }
      else{
        printf("Enter new usage coefficient: ");
        scanf("%ld",&value[6]);
      }
    }
    if ((state[0] == 'I') ||
        (state[0] == 'i')) {
      printf("Enter value code (IT/IF/IN): ");
      gets(type);
    }
    modify_variable();
    if (errcde[0] != 0) {
      printf(
       "Error received from modify_variable = %hd\n",errcde[0]);
    } else {
      printf("Number of variables matched = %ld\n",value[2]);
      printf("Number of variables modified = %ld\n",value[3]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * retrieve problem
 *-----------------
 */
  if (strcmp(comnd,"retrieve problem") == 0) {
    printf("Enter name of problem: ");
    gets(name);
    retrieve_problem();
    if (errcde[0] != 0) {
      printf(
       "Error received from retrieve_problem = %hd\n",errcde[0]);
    } else {
      num_cols = value[0];
      num_rows = value[1];
      printf("Problem name = %s\n",name);
      printf("Type = %s\n",type);
      printf("State = %s\n",state);
      printf("Number of variables (user defined) = %ld\n",
        value[0]);
      printf("Number of clauses and goals = %ld\n",value[1]);
      if (strcmp(state,"N") == 0) {
        printf("Problem has not been solved\n");
      } else if (strcmp(state,"S") == 0) {
        printf("Problem solved: satisfiable\n");
        if (type[0] == 'M') {
          printf("Total cost of solution = %ld\n",value[2]);
          printf("Lower bound on total cost = %ld\n",
                 value[3]);
        }
      } else  if (strcmp(state,"S") == 0) {
        printf("Problem solved: unsatisfiable\n");
      } else if  (strcmp(state,"") == 0) {
        printf("Transfer process specified\n");
      }
      num_cols = value[0];
      num_rows = value[1];
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * restore problem
 *-----------------
 */
  if (strcmp(comnd,"restore problem") == 0) {
    printf("Enter option (A/V/M/C/L/T/I): ");
    scanf("%s",state);
    restore_problem();
    if (errcde[0] != 0) {
      printf(
       "Error received from restore_problem = %hd\n",errcde[0]);
    } else {
      printf("Problem has been reset as specified\n");
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * solve problem
 *-----------------
 */
  if (strcmp(comnd,"solve problem")==0) {
/*  
 *  parameters value[4] and type are only needed for 
 *  approximate minimization
 *  see manual for range of possible values
 */
    value[4] = 18;
    type[0] = '\0';
    solve_problem();
    if (errcde[0] != 0) {
      printf(
         "Error received from solve_problem = %hd\n",errcde[0]);
    } else {
      printf("Problem name = %s\n",name);
      if (state[0] == 'S') {
        printf("Problem solved: satisfiable\n");
        if (type[0] == 'M') {
          printf(
           "Total cost of solution = %ld\n",value[2]);
          printf(
           "Lower bound on total cost = %ld\n",value[3]);
        }
      } else {
    printf("Problem solved: unsatisfiable\n");
      }
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * status clause
 *-----------------
 */
  if (strcmp(comnd,"status clause") == 0) {
    printf("Enter name (wildcard ? allowed): ");
    gets(name);
    printf("Enter lowest likelihood level: ");
    scanf("%ld",&value[0]);
    printf("Enter highest likelihood level: ");
    scanf("%ld",&value[1]);
    status_clause();
    if (errcde[0] != 0) {
      printf(
       "Error received from status_clause = %hd\n",errcde[0]);
    } else {
      printf("state= %s\n",state);
      printf(
       "Number of matching clauses         = %ld\n",value[2]);
      printf(
       "Number of active matching clauses  = %ld\n",value[3]);
      printf(
       "Number of deleted matching clauses = %ld\n",value[4]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * status problem
 *-----------------
 */
  if (strcmp(comnd,"status problem") == 0) {
    status_problem();
    if (errcde[0] != 0) {
      printf(
       "Error received from status_problem = %hd\n",errcde[0]);
    } else {
      printf("Problem name = %s\n",name);
      printf("Type = %s\n",type);
      printf("State = %s\n",state);
      printf("Number of variables (user defined) = %ld\n",
        value[0]); /* value[0] must be = num_cols */
      printf("Number of clauses and goals = %ld\n",
        value[1]); /* value[1] must be = num_rows */
      if (strcmp(state,"N") == 0) {
        printf("Problem has not been solved\n");
      } else if (strcmp(state,"S") == 0) {
        printf("Problem solved: satisfiable\n");
        if (type[0] == 'M') {
          printf("Total cost of solution = %ld\n",value[2]);
          printf("Lower bound on total cost = %ld\n",
           value[3]);
        }
      } else if (strcmp(state,"U") == 0) {
        printf("Problem solved: unsatisfiable\n");
      } else  if (strcmp(state,"") == 0) {
        printf("Transfer process specified\n");
      }
      printf("Number of goals = %ld\n",value[4]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * status storage
 *-----------------
 */
  if (strcmp(comnd,"status storage") == 0) {
    printf("Enter problem index\n");
    printf("(press Return for default = 1): ");
    gets(srecord);
    if (srecord[0] == '\0') {
      value[0] = 1;
    } else {
      sscanf(srecord,"%ld",&value[0]);
      if (value[0] <= 0) {
      value[0] = 1;
      }
    }
    status_storage();
    if (errcde[0] != 0) {
      printf(
       "Error received from status_storage = %hd\n",errcde[0]);
    } else {
      printf("Problem name = %s\n",name);
      printf("Number of records used for this problem =  %ld\n",
        value[4]);
      printf(
         "Total number of problems (current and stored) = %ld\n",
         value[1]);
      printf(
      "Number of records used for storage = %ld\n",
         value[2]);
      printf(
      "Number of records still available for storage = %ld\n",
      value[3]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * status variable
 *-----------------
 */
  if (strcmp(comnd,"status variable") == 0) {
    printf("Enter name of variable (blank -> ALL) or 'index': ");
    gets(name);
    if (name[0]== '\0') {
      for (i=1; i<=num_cols; i++) {
        value[0] = i;
        status_variable();
        if (errcde[0] != 0) {
          printf(
           "Error received from status_variable = %hd\n",
           errcde[0]);
        } else {
          printf("name = %s\n",name);
          printf("state = %s\n",state);
          printf("type = %s\n",type);
          printf("TRUECOST  (used only if type = MIN) = %ld\n",
            value[2]);
          printf("FALSECOST (used only if type = MIN) = %ld\n",
            value[3]);
        }
      }
    } else {
      if (strcmp(name,"index") == 0) {
        printf("Enter index: ");
        scanf("%ld",&value[0]);
      } else {
      value[0] = 0;
      }
      status_variable();
      if (errcde[0] != 0) {
        printf(
         "Error received from status_variable = %hd\n",errcde[0]);
      } else {
        printf("state = %s\n",state);
        printf("type = %s\n",type);
        printf("TRUECOST  (used only if type = MIN) = %ld\n",
          value[2]);
        printf("FALSECOST (used only if type = MIN) = %ld\n",
          value[3]);
        printf("Goal name = %s\n",&name[60]);
        printf("Goal usage coefficient = %ld\n", value[4]);
      }
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * store problem
 *-----------------
 */
  if (strcmp(comnd,"store problem") == 0) {
    name[0] = '\0';
    printf("Enter name under which problem is to be stored\n");
    printf("(press Return for default = current name): ");
    gets(name);
    store_problem();
    if (errcde[0] != 0) {
      printf(
       "Error received from store_problem = %hd\n",errcde[0]);
    } else {
      printf("Name of stored problem = %s\n",name);
      if (state[0] == 'E') {
        printf(
        "A stored problem with same name"
        " existed and was deleted");
        printf("prior to storage or current problem");
      }
      printf(
        "Total number of problems (current and stored) = %ld\n",
         value[1]);
      printf(
         "Total number of records used for storage = %ld\n",
         value[2]);
      printf(
        "Total number of records still available"
        " for storage = %ld\n",
         value[3]);
      printf(
        "Number of records used to store"
        " current problem = %ld\n",
         value[4]);
    }
    goto main_loop;
  }
/*eject*/
/*-----------------
 * quit
 *-----------------
 */
  if ((strcmp(comnd,"quit")==0) ||
      (comnd[0] == 'q')) {
    exit(0);
  } else {
/*-----------------
 * Unknown command
 *-----------------
 */
    printf("Unknown command\n");
  }
  goto main_loop;
}
/* last record of execute.c***** */
