/*  first record of getparm.c***** */
/* Version selections  */

/* Select exactly one version size*/
#define version_size "full"
/* #define version_size "student" */

#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

/* ************************************* */
void getparm(char *pardir) {
/*
 *  gets compile parameters from file leibnizparams.dat
 *  or defines them directly. File leibnizparams.dat is
 *  in directory pardir. If pardir = empty string, current
 *  directory used.
 */
  long i, ix, m, n, nz;

  void vrsion();

/*
 *  begin program body
 *--------------------
 */

/*
 *  define Leibniz System version
 */
  vrsion();

/*
 *  access flag and screen flag for details
 *  note: access flag cannot be set by leibnizparams.dat
 * 
 *  accflg = 1 details shown
 *         = 0 not details
 *
 *  scrflg = 1 print on screen
 *         = 0 no screen printing
 */
  accflg = 0;
  scrflg = 0;
/*
 *  initialize xerror
 */
  xerror=0;

/*
 *  if no allocation of devices for execution
 *  has been made:
 *  initialize max size of formulations;
 *  caution: see exdyn.c for the
 *  conditions that must be satisfied by the
 *  parameters below
 */
  if (exalcflg==0) { 
    colmax = 5001;
    rowmax = 5001;
    anzmax = 60000;
    blkmax = 40;
    prbmax = 2;
    stomax = 2;
    laymax = 7;
  }

/*
 *  initialize extension names
 */
  strcpy(&namext_(1,1),".log");
  strcpy(&namext_(1,2),".trs");
  strcpy(&namext_(1,3),".prg");
  strcpy(&namext_(1,4),".err");
  strcpy(&namext_(1,5),".lrn");

/*
 *  initialize version selection for normal process
 */
  selvr_(1) = 3;
  selvr_(2) = 6;
  nselvr = 2;
  satchk = 0;

/*
 *  initialize approximate minimization flag
 *  apmflg = 1 approx. minimization
 *         = 0 no approx. minimization
 */
  apmflg = 0;

/*
 *  initialize flags for defining transfer process
 *  trsprocessflg = 0 do not define transfer process
 *                = 1 define transfer process
 *  mktrsprocfilflg = 0 do not make transfer process files
 *                = 1 make transfer process files
 *  keepallvarflg    = 1 keep all variables of log formulation,
 *                    whether or not they are used in facts
 *                = 0 keep only variables used in facts
 *  nonusewarnflg = 0 skip warnings about unused variables
 *                    (specified in .log file but not used
 *                     in clauses)
 *                = 1 warn about unused variables
 *  outputprgflg  = 0 do not output compiled program to .prg file 
 *                = 1 output compiled program
 *  for details about condiptflg and related begcondiptword
 *  and endcondiptword, see below when leibnizparams.dat records
 *  are processed
 */
  trsprocessflg = 0;
  mktrsprocfilflg = 0;
  keepallvarflg = 0;
  nonusewarnflg = 0;
  outputprgflg = 0;
  condiptflg = -1;
  strcpy(begcondiptword,"");
  strcpy(endcondiptword,"");

/*
 *  initialize time bound that forces switch to 
 *  approx. min.
 *  apmbnd >  0 switch to approx. min. if time bound 
 *                exceeds the specified value (sec)
 *         =  0 must do approx. min.   
 *         = -1 approx. min. not allowed
 */
  apmbnd = -1;

/*
 *  initialize learn flag and max learning cycles
 *  lrnflg    = 0 no learning
 *            = 1 learn using learn file
 *            = 2 learn from random statements
 *            = 3 learning completed
 *  lrnoutflg = 0 no output of learned rows
 *            = 1 file output of learned rows
 *  ilrnzero  = number of times, no learning takes place
 *              during a learning cycle
 *  nlrnzero  = max value allowed for nlrnzero   
 */
  lrnflg = 0;
  lrnoutflg = 0;
  ilrncyc = 1;
  nlrncyc = 1;
  ilrnzero = 0;
  nlrnzero = 5;

/*
 *  initialize machine speed (mips)
 */
  mspeed = 100;
  prbdir[0] = '\0';

/*
 *  read and process parameter file, which is in directory
 *  pardir. If pardir = empty string, current directory is used.
 */
   strcpy(auxnam,pardir);
   strcat(auxnam,"leibnizparams.dat");
   prmfil = fopen(auxnam,"r");
   if (prmfil  == NULL) {
     printf("Cannot open leibnizparams.dat file");
     if (strcmp(pardir,"") != 0) {
       printf("\nin %s directory",pardir);
     }
     printf(".\nStop.\n");
     fprintf(errfil,"Cannot open leibnizparams.dat file\n");
     if (strcmp(pardir,"") != 0) {
       fprintf(errfil,"\nin %s directory",pardir);
     }
     fprintf(errfil,".\nStop.\n");
     lbccexit(1);
   }
/*eject*/
/*
 *  begin of reading loop
 */
  zz50:
  if (fgets(parstr,256,prmfil)==NULL) {
/*
 *  missing ENDATA record
 */
    printf("ENDATA record missing in leibnizparams.dat\nStop\n");
    fprintf(errfil,
           "ENDATA record missing in leibnizparams.dat\nStop\n");
    lbccexit(1);
  }

/*
 *  change all string characters 
 *  with ascii code 1-31 or 127-254 by blanks
 */
  nz = strlen(parstr);
  for(i=1; i<=nz; i++)  {
    ix = (int)parstr_(i);
    if (((ix>=1)&&
        (ix<=31))||
        ((ix>=127)&&
        (ix<=254))) {
      parstr_(i) = ' ';
    }
  }
/*
 *  introduce carriage return character and,
 *  if necessary, new end of string character
 */
  if (parstr_(nz) == ' ') {
    parstr_(nz) = '\n';
  } else {
    parstr_(nz+1) = '\n';
    parstr_(nz+2) = '\0';
    nz++;
  }  
/*
 *  compress string and look for '='
 */
  m = 0;
  n = 0;
  for (i=1;i<=256;i++) {
    if (parstr_(i) == ' ') {
      n = n + 1;
    } else {
      parstr_(i-n) = parstr_(i);
      if (parstr_(i) == '=') {
        m = i - n + 1;
      }
      if (parstr_(i-n)=='\n') {
        parstr_(i-n)='\0';
        goto zz55;
      }
    }
  }
  printf("Error while processing leibnizparams.dat record:\n");
  printf("\n%s\n",parstr);
  printf("Stop\n");
  fprintf(errfil,
      "Error while processing leibnizparams.dat record:\n");
  fprintf(errfil,"\n%s\n",parstr);
  fprintf(errfil,"Stop\n");
  lbccexit(1);

  zz55:
 /*  
 *  if parstr has become null string, skip record
 */
  if (parstr_(1)=='\0') {
    goto zz50;
  }

/*
 *  comment - skip to next line
 */
  if (parstr_(1) == '*') {
    goto zz50;
  }

/*
 *  ENDATA record - close parameter file, process parameters
 */
  if (strcmp(parstr,"ENDATA") == 0) {
    fclose(prmfil);
    goto zz80;
  }

/*
 *  process parstr
 */

/*
 *  "show steps on screen"
 */
  if (strncmp(parstr,"showstep",8) == 0) {
    scrflg = 1;
    printf("show steps on screen\n");
    printf("             Leibniz System\n");
    printf("             lbcc Compiler\n");
    printf("              Version %s\n",lbzver);
    printf("     Copyright 1990-2015 by Leibniz\n");
    printf("          Plano, Texas, U.S.A.\n\n");
    goto zz50;
  }

/*
 *  "keep all variables even if not used in any fact"
 */
  if (strncmp(parstr,"keepallvariable",15) == 0) {
    keepallvarflg = 1;
    if (scrflg == 1) {
      printf("keep all variables even if not used in any fact\n");
    }
    goto zz50;
  }

/*
 *  "compile for transfer process"
 */
  if (strncmp(parstr,"compilefortrans",15) == 0) {
    trsprocessflg = 1;
    if (scrflg == 1) {
      printf("compile for transfer process\n");
    }
    goto zz50;
  }

/*
 *  "make transfer files"
 */
  if (strncmp(parstr,"maketransfer",12) == 0) {
    if (trsprocessflg==1) {
      mktrsprocfilflg = 1;
      if (scrflg == 1) {
        printf("make transfer files\n");
      }      
    } else {
      if (scrflg == 1) {
        printf("option 'make transfer files' is ignored\n"
               "  since option 'compile for transfer process'\n"
               "  has not been specified\n");
      }
    }
    goto zz50;
  }

/*
 *  "list warnings for nonuse of sets, predicates, variables"
 */
  if (strncmp(parstr,"listwarn",8) == 0) {
    nonusewarnflg = 1;
    if (scrflg == 1) {
      printf("list warnings for nonuse"
             " of sets, predicates, variables\n");
    }
    goto zz50;
  }

/*
 *  "output compiled program to program file"
 */
  if (strncmp(parstr,"outputco",8) == 0) {
    outputprgflg = 1;
    if (scrflg == 1) {
      printf("output compiled program to program file\n");
    }
    goto zz50;
  }

/*
 *  "output learned clauses"
 */
  if (strncmp(parstr,"outputle",8) == 0) {
    lrnoutflg = 1;
    if ((scrflg == 1)&&
        (lrnflg>=1)) {
      printf("output learned clauses \n");
    }
    goto zz50;
  }

/*
 *  "do satisfiability test"
 */
  if (strncmp(parstr,"dosatisf",8) == 0) {
    satchk = 1;
    if (scrflg == 1) {
      printf("do satisfiability test\n");
    }
    goto zz50;
  }
/*eject*/
/*
 *  all lines of leibnizparams.dat without '=' must be
 *  processed above this point
 *  below, have error if no '='
 */
  if (m == 0) {
    printf("Cannot decode leibnizparams.dat record:\n");
    printf("\n%s\n",parstr);
    printf("Possibly '=' missing in record\n");
    printf("Stop\n");
    fprintf(errfil,"Cannot decode leibnizparams.dat record:\n");
    fprintf(errfil,"\n%s\n",parstr);
    fprintf(errfil,"Possibly '=' missing in record\n");
    fprintf(errfil,"Stop\n");
    lbccexit(1);
  }
/*
 *  error if no r.h.s value in record
 */
  if (parstr_(m) == '\0') {
    printf("Error in leibnizparams.dat file\n");
    printf(" r.h.s. missing in record\n");
    printf("\n%s\n",parstr);
    printf("Stop\n");
    fprintf(errfil,"Error in leibnizparams.dat file\n");
    fprintf(errfil," r.h.s. missing in record\n");
    fprintf(errfil,"\n%s\n",parstr);
    fprintf(errfil,"Stop\n");
    lbccexit(1);
  }

/*
 *  extract parameters
 */

/*
 *  input file
 */
  if (strncmp(parstr,"inputfil",8) == 0) {
    strcpy(filnam,&parstr_(m));
    if (scrflg == 1) {
      printf("input file             = %s\n",filnam);
    }
    goto zz50;
  }

/*
 *  input directory
 */
  if (strncmp(parstr,"inputdir",8) == 0) {
    strcpy(prbdir,&parstr_(m));
    if (scrflg == 1) {
      printf("input directory        = %s\n",prbdir);
    }
    goto zz50;
  }

/*
 *  file extensions
 *  leave existing '.' unchanged by strcpy step
 */
  if (strncmp(parstr,"logicfil",8) == 0) {
    strcpy(&namext_(2,1),&parstr_(m));
    if (scrflg == 1) {
      printf("logic file extension           = %s\n",
               &namext_(1,1));
    }
    goto zz50;
  }

  if (strncmp(parstr,"transferfile",12) == 0) {
    strcpy(&namext_(2,2),&parstr_(m));
    if (scrflg == 1) {
      printf("transfer file extension        = %s\n",
               &namext_(1,2));
    }
    goto zz50;
  }

  if (strncmp(parstr,"programf",8) == 0) {
    strcpy(&namext_(2,3),&parstr_(m));
    if (scrflg == 1) {
      printf("program file extension         = %s\n",
               &namext_(1,3));
    }
     goto zz50;
  }

  if (strncmp(parstr,"errorfil",8) == 0) {
    strcpy(&namext_(2,4),&parstr_(m));
    if (scrflg == 1) {
      printf("error file extension           = %s\n",
              &namext_(1,4));
    }
    goto zz50;
  }

  if (strncmp(parstr,"learnedc",8) == 0) {
    strcpy(&namext_(2,5),&parstr_(m));
    if (scrflg == 1) {
      printf("learned clauses file extension = %s\n",
              &namext_(1,5));
    }
    goto zz50;
  }

/*
 *  colmax (max number of variables)
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 */
  if (strncmp(parstr,"colmax(m",8) == 0) {
    if (exalcflg==0) {    
      sscanf(&parstr_(m),"%ld",&colmax);
      if (scrflg == 1) {
        printf("colmax (max variables) = %ld\n",colmax);
      }
    } else {
      if (scrflg == 1) {
        printf("colmax (max variables) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*
 *  rowmax (max number of clauses)
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 */
  if (strncmp(parstr,"rowmax(m",8) == 0) {
    if (exalcflg==0) {
      sscanf(&parstr_(m),"%ld",&rowmax);
      if (scrflg == 1) {
        printf("rowmax (max clauses)   = %ld\n",rowmax);
      }
    } else {
      if (scrflg == 1) {
        printf("rowmax (max clauses) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*
 *  anzmax (max number of literals)
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 */
  if (strncmp(parstr,"anzmax(m",8) == 0) {
    if (exalcflg==0) {
      sscanf(&parstr_(m),"%ld",&anzmax);
      if (scrflg == 1) {
        printf("anzmax (max literals)  = %ld\n",anzmax);
      }
    } else {
      if (scrflg == 1) {
        printf("anzmax (max literals) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*
 *  blkmax (max number of blocks)
 *  accept value if no allocation of devices for execution
 *  has been made as yet
 */
  if (strncmp(parstr,"blkmax(m",8) == 0) {
    if (exalcflg==0) {
      sscanf(&parstr_(m),"%ld",&blkmax);
      if (scrflg == 1) {
        printf("blkmax (max blocks)    = %ld\n",blkmax);
      }
    } else {
      if (scrflg == 1) {
        printf("blkmax (max blocks)) value ignored "
               "since allocation already done\n");
      }
    }
    goto zz50;
  }

/*
 *  approximate minimization option
 */
  if (strncmp(parstr,"useappro",8) == 0) {
    sscanf(&parstr_(m),"%ld",&apmbnd);
    if (scrflg == 1) { 
      printf("For minimization cases:\n");
      if (apmbnd > 0) {
        printf("  use approximate minimization\n");
        printf("  if time bound exceeds %ld sec\n",apmbnd);
      } else {
        apmbnd = 0;
        printf("Must use approximate minimization\n");
      }
    }
    goto zz50;
  }
/*eject*/
/*
 *  compile process options
 *
 *  compile process 
 */
  if (strncmp(parstr,"compileprocess",14) == 0) {
    strcpy(auxnam,&parstr_(m));
    if (scrflg == 1) {
      printf("compile process = %s\n",
         auxnam);
    }
    if (strcmp(auxnam,"normal")==0) {
      nselvr = 2;
      selvr_(1) = 3;
      selvr_(2) = 6;
    } else if (strcmp(auxnam,"fast")==0) {
      nselvr = 1;
      selvr_(1) = 3;
    } else if (strcmp(auxnam,"veryfast")==0) {
      nselvr = 1;
      selvr_(1) = 2;
    } else if (strcmp(auxnam,"version1")==0) {
      nselvr = 1;
      selvr_(1) = 1;
    } else if (strcmp(auxnam,"version2")==0) {
      nselvr = 1;
      selvr_(1) = 2;
    } else if (strcmp(auxnam,"version3")==0) {
      nselvr = 1;
      selvr_(1) = 3;
    } else if (strcmp(auxnam,"version4")==0) {
      nselvr = 1;
      selvr_(1) = 4;
    } else if (strcmp(auxnam,"version5")==0) {
      nselvr = 1;
      selvr_(1) = 5;
    } else if (strcmp(auxnam,"version6")==0) {
      nselvr = 1;
      selvr_(1) = 6;
    } else if (strcmp(auxnam,"version7")==0) {
      nselvr = 1;
      selvr_(1) = 7;
    } else if (strcmp(auxnam,"version8")==0) {
      nselvr = 1;
      selvr_(1) = 8;
    } else if (strcmp(auxnam,"version9")==0) {
      nselvr = 1;
      selvr_(1) = 9;
    }
    goto zz50;
  }

/*
 *  names of transfer files
 *  defs.h file
 */
  if (strncmp(parstr,"transferdefs",12) == 0) {
    strcpy(trsdefsfil_name,prbdir);
    strcat(trsdefsfil_name,&parstr_(m));
    strcpy(trsdefsfil_nopa,&parstr_(m));
    if (scrflg == 1) { 
      printf("transfer defs.h file = %s\n",trsdefsfil_nopa);
    }
    goto zz50;
  }

/*
 *  exts.h file
 */
  if (strncmp(parstr,"transferexts",12) == 0) {
    strcpy(trsextsfil_name,prbdir);
    strcat(trsextsfil_name,&parstr_(m));
    strcpy(trsextsfil_nopa,&parstr_(m));
    if (scrflg == 1) { 
      printf("transfer exts.h file = %s\n",trsextsfil_nopa);
    }
    goto zz50;
  }

/*
 *  code file
 */
  if (strncmp(parstr,"transfercode",12) == 0) {
    strcpy(trscodefil_name,prbdir);
    strcat(trscodefil_name,&parstr_(m));
    strcpy(trscodefil_nopa,&parstr_(m));
    if (scrflg == 1) { 
      printf("transfer code file = %s\n",trscodefil_nopa);
    }
    goto zz50;
  }

/*
 *  learn using specified file
 */
  if (strncmp(parstr,"learnusi",8) == 0) {
    strcpy(auxnam,&parstr_(m));
    if (scrflg == 1) {
      printf("learn using file = %s\n",auxnam);
    }
    if (strcmp(auxnam,"random")==0) {
      lrnflg = 2;
    } else {
      lrnflg = 1;
    }
    goto zz50;
  }

/*
 *  max learning cycles
 */
  if (strncmp(parstr,"maxlearn",8) == 0) {
    sscanf(&parstr_(m),"%ld",&nlrncyc);
    if ((scrflg == 1)&&
        (lrnflg>=1)) {
      printf("max learning cycles = %ld\n",
              nlrncyc);
    }
    goto zz50;
  }

/*
 *  machine speed
 */
  if (strncmp(parstr,"machines",8) == 0) {
    sscanf(&parstr_(m),"%ld",&mspeed);
    if (scrflg == 1) {
      printf("machine speed %ld mips\n",mspeed);
    }
    goto zz50;
   }

/*
 *  write condensed input into file
 *
 *  condensed: no INCLUDE statements
 *             if a record has only comments or is blank,
 *             it is skipped
 *             all statements in one file
 *
 *  process is controlled by condiptflg
 *  begcondiptword = begin keyword, triggers beginning of
 *                   writing; record containing the keyword
 *                   becomes part of the condensed output
 *                   if keyword = empty string, begin writing
 *                   with first record
 *  endcondiptword = end keyword, triggers end of writing
 *                   record containing the keyword does not
 *                   become part of the condensed output
 *                   if keyword = empty string, no early
 *                   termination
 *  caution: if keyword for begin or end is a special word
 *  of the leibniz syntax, then the test for presence always
 *  uses upper case version for the test
 *  thus the test becomes independent of user version of keywords
 *
 *  condiptflg = 
 *    -1: no writing takes place
 *     0: writing planned, but begin keyword has not yet
 *        been reached
 *     1: begin keyword has been reached or passed, and
 *        writing is taking place
 *     2: end keyword has been reached or passed, and
 *        writing has stopped 
 *
 *  write condensed input into file
 */
  if (strncmp(parstr,"writecondensed",14) == 0) {
    condiptflg = 0;
    strcpy(condiptfil_name,&parstr_(m));
    if (scrflg == 1) {
      printf(
       "write condensed input file into = %s\n",&parstr_(m));
    }
    goto zz50;
   }
/*
 * begin condensed input keyword
 */ 
  if (strncmp(parstr,"begincondensed",14) == 0) {
    strcpy(begcondiptword,&parstr_(m));
    if (scrflg == 1) {
      printf(
       "begin condensed input keyword = %s\n",&parstr_(m));
    }
    goto zz50;
   }
/*
 * end condensed input keyword
 */
  if (strncmp(parstr,"endcondensed",12) == 0) {
    strcpy(endcondiptword,&parstr_(m));
    if (scrflg == 1) {
      printf(
       "end condensed keyword = %s\n",&parstr_(m));
    }
    goto zz50;
   }

/*
 *  unknown record type
 */
  printf("Cannot decode leibnizparams.dat record:\n");
  printf("\n%s\n",parstr);
  printf("Stop\n");
  fprintf(errfil,"Cannot decode leibnizparams.dat record:\n");
  fprintf(errfil,"\n%s\n",parstr);
  fprintf(errfil,"Stop\n");
  lbccexit(1);

/*eject*/
/*
 *  done with reading leibnizparams.dat
 *  assemble file names and finish preparation of parameters
 */
  zz80:

/*
 *  define log, trs, prg, lrn files, 
 *  and learn row file
 *  also initialize problem directory string
 *  in position logfilmax+1 of logfil_name for later use
 *
 *  first check that input file has correct logic file
 *  extension
 */
  m = strlen(&namext_(1,1));
  n = strlen(filnam);
  if (strcmp(&filnam_(max(1,n-m+1)),&namext_(1,1))!=0) {
/*
 *  extension of input file name filnam does not match
 *  log file extension in namext_(1,1)
 */
    printf("Error in leibnizparams.dat file\n"
           "Input file name extension does"
           " not match logic extension\n"
           "Stop\n");
    fprintf(errfil,
           "Error in leibnizparams.dat file\n"
           "Input file name extension does"
           " not match logic extension\n"
           "Stop\n");      
    lbccexit(1);   
  }
/*
 *  remove logic file extension from input file name
 */
  filnam_(n-m+1) = '\0';
/*
 *  construct all file names
 */
  strcpy(logfil_name,prbdir);
  strcpy(&logfil_name_(1,logfilmax+1),logfil_name);
  strcat(logfil_name,filnam);
  strcpy(trsprobfil_nopa,filnam);
  strcpy(trsprobfil_name,logfil_name);
  strcpy(prgfil_name,logfil_name);
  strcpy(errfil_name,logfil_name);
  strcpy(lrnrowfil_name,logfil_name);
  strcat(logfil_name,&namext_(1,1));
  strcat(trsprobfil_nopa,&namext_(1,2));
  strcat(trsprobfil_name,&namext_(1,2));
  strcat(prgfil_name,&namext_(1,3));
  strcat(errfil_name,&namext_(1,4));
  strcat(lrnrowfil_name,&namext_(1,5));
  if (lrnflg == 1) {
    strcpy(lrnthmfil_name,prbdir);
    strcat(lrnthmfil_name,auxnam);
  } else {
    strcpy(lrnthmfil_name,"\0");
  }
/*
 *  student version only: limit allocation
 *  accept value if no allocation of devices for execution
 *  has been made as yet  
 */
  if (strcmp(version_size,"student")==0) {
    if (exalcflg==0) {
      colmax =  101;
      rowmax =  101;
      anzmax = 1001;
    }
  }
/*
 *  modify parameters to accommodate learning
 */
  if ((lrnflg==1) ||
      (lrnflg==2)) {
/*
 * assume at most 1/2 rowmax rows added by learning
 * and at most 10 entries per learned row
 */
    n = max(100,(rowmax/2));
    rowmax += n;
    anzmax += 10*n;
  }
/*
 *  done
 */
  return;
}
/*  last record of getparm.c***** */
