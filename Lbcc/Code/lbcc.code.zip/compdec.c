/*  first record of compdec.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"

int abs();
/*
 * ************************************************************
 *  module component decomposition   
 * 
 *  purpose:  decomposes component qblock into two blocks if this is
 *            possible.
 * 
 *    input:  component qblock in layer 1, with correct indices and
 *            counts.  
 *            arrays assumed defined:
 *              - matrix data amatcl, amatrw
 *              - nrows, ncols, nblks
 *              - colnam, rownam, prbnam 
 *              - matrix indices as follows:
 *                  all columns j active (ciact(j) = 1)  
 *                  all rows i active  (riact(i) = 1) 
 *                  remaining indices must be consistent with these
 *                  assignments. 
 *              - counts cnxxx, rnxxx
 *              - all cost(j) must be .ge. 0 if optimz = 1 
 *              - scale, idxcol, idxrow 
 *              - dlclop, dlrwop 
 *              - lcllim, ucllim, lrwlim, urwlim   
 *              - logrge   
 *              - qblock   
 * 
 *     additional input requirements as well as the output are given
 *     with each subroutine of this module. 
 * 
 *     calling sequence:   
 *        decomp          decompose component qblock if possible.
 *          srcsnk        determine source and sink nodes for max flow
 *                          problem. 
 *            shortr      shortest route algorithm from given source
 *                          nodes to all other nodes of the given part
 *                          of component qblock.   
 *            addss       add source and sink nodes of all other blocks.
 *          maxflw        module max flow problems.
 *          strcut        store a cut set and labelled nodes.
 * 
 *  caution:  uses layer 2 for intermediate storage.  
 * 
 * ************************************************************
 * 
 * 
 * ************************************************************
 *  subroutine addss   
 * 
 *  purpose:  adds to the csourc and rsourc lists for block qblock the
 *            nodes of blocks 1, ..., qblock-1, and to the csink and
 *            rsink lists the nodes of blocks qblock+1, ..., nblks.
 * 
 *   input:   as specified in module summary, plus:
 *              csourc, rsourc, csink, rsink
 * 
 *  output:   extended csourc, rsourc, csink, rsink lists so that
 *            csourc, rsourc contain all nodes of blocks 1,...,qblock-1,
 *            and csink, rsink contain all nodes of blocks 
 *            qblock+1, ..., nblks.  
 * 
 * ************************************************************
 * 
 */
void addss() {
/*
 */
  static long q,n,j,i;
/*
 */
  q=qblock;
/*
 *  if q .gt. 1 extend csourc and rsourc list by all nodes of blocks .lt. q
 */
  if (q>1) {
    n=csourc_(colmax+1);
    for(j=1; j<=ucllim_(q-1); j++)  {
      n=n+1;
      csourc_(n)=j;
    }
    csourc_(colmax+1)=n;
    n=rsourc_(rowmax+1);
    for(i=1; i<=urwlim_(q-1); i++)  {
      n=n+1;
      rsourc_(n)=i;
    }
    rsourc_(rowmax+1)=n;
  }
/*
 *  if q .lt. nblks, extend csink and rsink by all nodes of blocks .gt. q
 */
  if (q<nblks) {
    n=csink_(colmax+1);
    for(j=lcllim_(q+1); j<=ncols; j++)  {
      n=n+1;
      csink_(n)=j;
    }
    csink_(colmax+1)=n;
    n=rsink_(rowmax+1);
    for(i=lrwlim_(q+1); i<=nrows; i++)  {
      n=n+1;
      rsink_(n)=i;
    }
    rsink_(rowmax+1)=n;
  }
  return;
}
/*
 * ************************************************************
 *  subroutine decomp  
 * 
 *  purpose:  finds a decomposition of component qblock in layer 1, or
 *            concludes that such a refinement is not possible. 
 * 
 *   input:   as specified in module summary.  
 * 
 *  output:   succss = 1: component qblock in layer 1.  in layer 2
 *            refined decomposition derived from best of several max
 *            flow solutions and given as follows: 
 *              column j of qblock:  
 *                solut4(j) = 1: column j is in node cutset. 
 *                          = 0: column j is not in node cutset.
 *                solut5(j) = 1: column j is in first reduced component.
 *                          = 0: column j is in second reduced component
 * 
 *              row i of qblock: 
 *                rhs4(i) = 1: row i is in node cutset.  
 *                        = 0: row i is not in node cutset.
 *                rhs5(i) = 1: row i is in first reduced component.
 *                        = 0: row i is in second reduced component.
 * 
 *            bstcut = size of node cutset  
 *            succss = 0: component qblock in layer 1 of input.  reason
 *            for failure:  for each attempted case, the cutset size
 *            is equal to the number of source nodes in block qblock.
 * 
 *    caution: uses layer 2 for intermediate storage. 
 * 
 * ************************************************************
 * 
 */
void decomp() {
/*
 */
  void addss();
  void maxflw();
  void srcsnk();
  void strcut();
  void tranpr();
/*
 */
  static long q,deltaj,round,j,m;
/*
 *  save input component qblock in layer 2
 */
  q=qblock;
  tranpr(c1,c2);
/*
 *  initialize bstcut = size of best cut found so far
 */
  bstcut=tt15m1;
/*
 *  establish deltaj = increment of j as columns are scanned.  deltaj
 *  assures that at most 25 cases are handled in each round.
 */
  deltaj=1+(ucllim_(q)-lcllim_(q))/25;
/*
 *  start rounds
 */
  m=min(4,maxcut+1);
  for(round=m; round<=maxcut+1; round++)  {
    srcsiz=round;
/*
 *  enumerate columns in deltaj increments
 */
    for(j=lcllim_(q); j<=ucllim_(q); j+=deltaj)  {
/*
 *  skip column j if zero
 */
      if (nzamac_(j)==0) {
        goto zz200;
      }
/*
 *  initialize source node sets
 */
      csourc_(colmax+1)=1;
      csourc_(1)=j;
      rsourc_(rowmax+1)=0;
/*
 *  find source and sink nodes
 */
      srcsnk();
/*
 *  if succss = 0, did not find source and sink nodes; hence skip case
 */
      if (succss==0) {
        goto zz200;
      }
/*
 *  if nblks .gt. 1, add to source nodes all nodes of blocks with index
 *  less than q, and to sink nodes all nodes of blocks with index
 *  greater than q.
 */
      if (nblks>1) {
        addss();
      }
/*
 *  use maxflow algorithm to find best decomposition
 */
      maxflw();
/*
 *  store cut in layer 2 if attractive
 */
      strcut();
    zz200:;}
/*
 *  if a cut has been found, accept it
 */
    if (bstcut<tt15m1) {
      succss=1;
      return;
    }
  }
/*
 *  did not find a good decomposition of block q in any one of the rounds
 */
  succss=0;
  return;
}
/*
 * ************************************************************
 *  subroutine shortr  
 * 
 *  purpose:  computes shortes routes from given set of column nodes
 *            in cdis to all other nodes.  among the latter nodes,
 *            picks a column node farthest away from the given cdis
 *            nodes.  places the selected node into cfar, and the
 *            related distance into distce. 
 * 
 *   input:   as specified in module summary, plus:
 *              cdis, nodlim, flgsrc 
 * 
 *  output:   solut1(j) = distance from cdis nodes to column node j
 *            rhs1(i)   = distance from cdis nodes to row node i
 *            distance  = tt15m1 implies that a node cannot be
 *                        reached from cdis nodes. 
 *            distce    = max of the distances to column nodes of block
 *                        qblock from initial cdis.
 *            cfar      = a column node that is distance distce away
 *                        from the cdis nodes. 
 * 
 *            if flgsrc = 1: have added to csourc, rsourc lists nodlim
 *                           nodes closest to the input cdis column
 *                           nodes.  
 *            if flgsrc = 0: have added to csink, rsink lists nodlim
 *                           nodes closest to the input cdis column
 *                           nodes.  in this case the shortest route
 *                           calculation is stopped once these nodes
 *                           have been found.  
 * 
 *      caution:  cdis, rdis lists are extended.   
 * 
 * ************************************************************
 * 
 */
void shortr() {
/*
 */
  static long q,j,jx,i,cp1,cp2,r1,r2,dst,ix,cp3;
/*
 */
  q=qblock;
/*
 *  initialize solut1 vector: value for column j is 0 if j is a source
 *  node, and tt15m1 otherwise.
 */
  for(j=1; j<=ncols; j++)  {
    solut1_(j)=tt15m1;
  }
  for(jx=1; jx<=cdis_(colmax+1); jx++)  {
    j=cdis_(jx);
    solut1_(j)=0;
  }
/*
 *  initialize rhs1 vector entries
 */
  for(i=1; i<=nrows; i++)  {
    rhs1_(i)=tt15m1;
  }
/*
 *  initialize pointers
 */
  cp1=1;
  cp2=cdis_(colmax+1);
  r1=1;
  r2=0;
  dst=1;
/*
 *  do bfs (breadth-first-search) pass
 */
  zz50:;
  for(jx=cp1; jx<=cp2; jx++)  {
    j=cdis_(jx);
    if (nzamac_(j)>0) {
/*
 *  process rows with entry in column j
 */
      for(ix=1; ix<=nzamac_(j); ix++)  {
        i=abs(amatcl_(ix+ptamac_(j)));
/*
 *  check if row i has already been encountered
 */
        if (rhs1_(i)==tt15m1) {
/*
 *  row i has not yet been processed.  do it now.
 */
          rhs1_(i)=dst;
          r2=r2+1;
          rdis_(r2)=i;
/*
 *  retain row node i if indexed by q and if node limit has not been
 *  reached.
 */
          if (nodlim>0) {
            if (riblk_(i)==q) {
              nodlim=nodlim-1;
              if (flgsrc==1) {
                rsourc_(rowmax+1)=rsourc_(rowmax+1)+1;
                rsourc_(rsourc_(rowmax+1))=i;
              } else {
                rsink_(rowmax+1)=rsink_(rowmax+1)+1;
                rsink_(rsink_(rowmax+1))=i;
                if (nodlim==0) {
                  return;
                }
              }
            }
          }
        }
      }
    }
  }
/*
 *  if no row node was added to rdis list, then done
 */
  if (r1>r2) {
    goto zz500;
  }
/*
 *  at least one row node was added.  do second part of bfs pass
 */
  cp1=cp2+1;
  cp2=cp1-1;
  dst=dst+1;
  for(ix=r1; ix<=r2; ix++)  {
    i=rdis_(ix);
    if (nzamar_(i)>0) {
/*
 *  process columns with entry in row i
 */
      for(jx=1; jx<=nzamar_(i); jx++)  {
        j=abs(amatrw_(jx+ptamar_(i)));
/*
 *  check if column j has already been encountered
 */
        if (solut1_(j)==tt15m1) {
          solut1_(j)=dst;
          cp2=cp2+1;
          cdis_(cp2)=j;
/*
 *  retain column node j if indexed by q and if node limit has not been
 *  reached
 */
          if (nodlim>0) {
            if (ciblk_(j)==q) {
              nodlim=nodlim-1;
              if (flgsrc==1) {
                csourc_(colmax+1)=csourc_(colmax+1)+1;
                csourc_(csourc_(colmax+1))=j;
              } else {
                csink_(colmax+1)=csink_(colmax+1)+1;
                csink_(csink_(colmax+1))=j;
                if (nodlim==0) {
                  return;
                }
              }
            }
          }
        }
      }
    }
  }
/*
 *  if no column nodes were added to list, then done
 */
  if (cp1>cp2) {
    goto zz500;
  }
/*
 *  start next bfs pass
 */
  r1=r2+1;
  r2=r1-1;
  dst=dst+1;
  goto zz50;
/*
 *  find column node cfar of block q farthest away from initial cdis nodes.
 *  prefer node with highest index
 *  if cdis(1) .le. (ucllim(q)+lcllim(q))/2,
 *  and node with lowest index otherwise
 */
  zz500:;
  distce=0;
  if (cdis_(1)<=(ucllim_(q)+lcllim_(q))/2) {
    cp1=ucllim_(q);
    cp2=lcllim_(q);
    cp3=-1;
  } else {
    cp1=lcllim_(q);
    cp2=ucllim_(q);
    cp3=1;
  }
/*
 *  define cfar to be the first nonzero column node with largest distance
 *  value.
 */
  if (cp3>0) {
    for(j=cp1; j<=cp2; j+=cp3)  {
      if ((solut1_(j)>distce)&&
          (nzamac_(j)>0)) {
        distce=solut1_(j);
        cfar=j;
      }
    }
  }
  if (cp3<0) {
    for(j=cp1; j>=cp2; j+=cp3)  {
      if ((solut1_(j)>distce)&&
          (nzamac_(j)>0)) {
        distce=solut1_(j);
        cfar=j;
      }
    }
  }
/*
 *  programming error if distce = 0
 */
  if (distce==0) {
    error("shortr  ","     602");
  }
  return;
}
/*
 * ************************************************************
 *  subroutine srcsnk  
 * 
 *  purpose:  finds source nodes and sink nodes for max flow algorithm.
 * 
 *   input:   as specified in module summary, plus:
 *              srcsiz, csourc(1)
 * 
 *  output:   succss = 1:  
 *              csourc    = source column node list.  
 *              rsourc    = source row node list.  
 *              csink     = sink column node list. 
 *              rsink     = sink row node list.
 * 
 *            succss = 0:  
 *              cannot find disjoint source and sink node sets. 
 * 
 * ************************************************************
 * 
 */
void srcsnk() {
/*
 */
  void shortr();
/*
 */
  static long q,jx,j,jxx,ix,i,ixx;
/*
 */
  q=qblock;
/*
 *  initialize cdis, rdis for shortest route computation
 */
  cdis_(colmax+1)=1;
  cdis_(1)=csourc_(1);
  rdis_(rowmax+1)=0;
/*
 *  initialize node limit and source flag
 */
  nodlim=srcsiz-1;
  flgsrc=1;
/*
 *  compute shortest routes from cdis(1) and put set of source
 *  nodes into csourc
 */
  shortr();
/*
 *  cfar is farthest node from csourc(1).  initialize for second
 *  shortest route application to get sink nodes
 */
  csink_(colmax+1)=1;
  csink_(1)=cfar;
  rsink_(rowmax+1)=0;
  cdis_(colmax+1)=1;
  cdis_(1)=cfar;
  rdis_(rowmax+1)=0;
  nodlim=srcsiz-1;
  flgsrc=0;
/*
 *  get sink nodes
 */
  shortr();
/*
 *  if no column source or sink nodes, declare error
 */
  if ((csourc_(colmax+1)==0)||
      (csink_(colmax+1)==0)) {
    error(" srcsnk ","  102   ");
  }
/*
 *  if no row source or sink nodes, declare succss = 0 and return
 */
  if ((rsourc_(rowmax+1)==0)||
      (rsink_(rowmax+1)==0)) {
    succss=0;
    return;
  }
/*
 *  check if source and sink nodes intersect.  if yes, succss = 0
 */
  for(jx=1; jx<=csourc_(colmax+1); jx++)  {
    j=csourc_(jx);
    for(jxx=1; jxx<=csink_(colmax+1); jxx++)  {
      if (j==csink_(jxx)) {
        succss=0;
        return;
      }
    }
  }
  for(ix=1; ix<=rsourc_(rowmax+1); ix++)  {
    i=rsourc_(ix);
    for(ixx=1; ixx<=rsink_(rowmax+1); ixx++)  {
      if (i==rsink_(ixx)) {
        succss=0;
        return;
      }
    }
  }
  succss=1;
  return;
}
/*
 * ************************************************************
 *  subroutine strcut  
 * 
 *  purpose:  stores cut nodes and labelled nodes of best cut found
 *            so far in level 2 cl array as follows.  
 * 
 *            solut4(j), rhs4(i) = 1: i,j in cutset.  
 *                               = 0: i,j not in cutset. 
 *            solut5(j), rhs5(i) = 1: i,j are labelled.  
 *                               = 0: i,j unlabelled. 
 *            ccut, rcut are the node lists of the cut nodes.
 * 
 * ************************************************************
 * 
 */
void strcut() {
/*
 */
  static long q,cutsiz,j,i;
/*
 */
  q=qblock;
/*
 *  compute cutsiz = size of node cutset
 */
  cutsiz=ccut_(colmax+1)+rcut_(rowmax+1);
/*
 *  compare cutsiz with srcsiz = size of source node set in qblock;
 *  skip to next case if cutsiz .ge. srcsiz.
 */
  if (cutsiz>=srcsiz) {
    return;
  }
/*
 *  if cut size is better than bstcut, retain case in level 2
 */
  if (cutsiz<bstcut) {
/*
 *  update bstcut
 */
    bstcut=cutsiz;
/*
 *  store case in level 2
 */
    for(j=lcllim_(q); j<=ucllim_(q); j++)  {
      cl_(j,17,2)=solut4_(j);
      cl_(j,18,2)=solut5_(j);
    }
    for(i=lrwlim_(q); i<=urwlim_(q); i++)  {
      rw_(i,21,2)=rhs4_(i);
      rw_(i,22,2)=rhs5_(i);
    }
  }
  return;
}
/*  last record of compdec.c****** */
