/*  first record of hm3_2.c***** */
/*
 * -----------------------------------------------------
 * Homework 3 expert system
 * copyright 1990-2001 by Leibniz Company, Plano, Texas
 * 
 * -----------------------------------------------------
 *
 */ 
#include<stdio.h>
#include<string.h>
#include<fcntl.h>
#include "leibnizexts.h"
/*
 */
int main() {
/*
 *  include leibnizmacro.h file, which contains
 *     - leibniz parameters for procedures
 *     - alternate definitions of leibniz procedures
 */
#include "leibnizmacro.h"
/*
 * miscellaneous variables
 */
  PRGNAME_ARRAY prgname[2];
/*
 *  initialize problem in hm3_2.prg
 */
  value[0] = 1;
  strcpy(name,"hm3_2.err");
  strcpy(prgname[0],"hm3_2.prg");
  strcpy(prgname[1],"");
  initialize_problem();
/*
 *  initialize all logic variables to active (= -1)
 *  and solve problem
 *  any satisfying solution is a possible scenario
 */
  strcpy(state,"A");
  modify_allvar();
  solve_problem();
  if (strcmp(state,"U")==0) {
    printf("\n****Problem is not satisfiable\n");
  } else {
    printf("\n****Problem is satisfiable\n");
  }
  free_device();
  exit(0);
}                  
/*  last record of hm3_2.c***** */
