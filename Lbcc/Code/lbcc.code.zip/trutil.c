/*  first record of trutil.c***** */
#include<string.h>
#include<stdio.h>
#include"exparms.h"
#include"exexts.h"
#include"exfdefs.h"
#include"trparms.h"
#include"trexts.h"
#include"trfdefs.h"
/* ***********************************************
 *
 *  Utilies for translate step
 *
 *      chklev       parses level number
 *      chknam       parses name
 *      chknum       parses number
 *      ckeoln       checks for end of line
 *      cmpres       removes blanks
 *      compct       compacts line
 *      convtloword  converts string to upper case if is a
 *                   lower-case reserved word                 
 *      extcmp       extracts next component from tmparg
 *      extnam       returns variable or predicate name
 *      fndnam       finds index and type of name
 *      gnewv        generates new variable
 *      initds       initializes for translation step
 *      inperr       outputs line number of type of error
 *      itostr       converts integer to string
 *      lstrncmp     compares n chars of one string with
 *                   another string
 *      testupword   tests if string is upper-case reserved word
 *      scrwrt       outputs line on screen
 *      varout       places cnf variable information into
 *                   trcolnam, trcvatf, trtrucst, trfalcst
 */
/*eject*/
/*
 * ******************************************************
 *  subroutine chklev
 * 
 *  purpose:  parses level number.
 * 
 *  output:   err : 0 means number is valid.
 *                  1 means not valid.
 * 
 *  note: calling routine should check for error.
 * 
 *  caution:  fatal errors will not terminate translation process
 *            when they return to calling routine.
 *            calling routine would require additional state
 *            'QEND' in its state diagram.
 *            hence no fatal errors are presently used.
 * 
 * ******************************************************
 * 
 */
void chklev(char *numstr,long *errt) {
/*
 */
  static long err,i,sl;
  static long n;
  static char msgstr[128+1];
/*
 */
  void inperr();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  err = *errt;
  msgstr_(128+1) = '\0';
/*
 */
  err=0;
  if (strcmp(numstr,"$")==0) {
/*
 *  blank number
 */
    inperr(&nftl);
    strcpy(msgstr," LBCC1570: Level or % value expected");
    scrwrt("+W",msgstr);
    err=1;
    *errt = err;
    return;
  }
/*
 *  check for length
 */
  sl = strlen(numstr);
  if (sl>3) {
    inperr(&nftl);
    strcpy(msgstr," LBCC1580: Three digits maximum for"
                  " level or % value");
    scrwrt("+W",msgstr);
    err=1;
    *errt = err;
    return;
  }
/*
 *  check that all are digits; ignore blanks
 */
  for(i=1; i<=sl; i++)  {
    n = (int)numstr_(i);
    if ((n<48)||
        (n>57)) {
      inperr(&nftl);
      sprintf(msgstr,
          " LBCC1590: Invalid level value: "
          "non-numeric characters");
      scrwrt("+W",msgstr);
      err=1;
      *errt = err;
      return;
    }
  }
/*
 *  range must be 1 to 100
 */
  sscanf(numstr,"%ld",&n);
  if ((n>100)||
      (n<1)) {
    inperr(&nftl);
    sprintf(msgstr," LBCC1600: Level value must be "
        "an integer: 1..100");
    scrwrt("+W",msgstr);
    err=1;
    *errt = err;
    return;
  }
  *errt = err;
  return;
}
/*eject*/
/*
 * ************************************************
 *  subroutine chknam
 * 
 *  purpose:  parses name.
 * 
 *   input:   type  meaning
 *            "L"   problem name
 *            "S"   set name
 *            "P"   predicate name
 *            "V"   variable name
 *            "Q"   quantifier name
 *            "E"   element name
 *            "C"   clause name
 * 
 *  output:   err : 0 means name is valid.
 *                  1 means not valid.
 * 
 *  note:  calling routine should check for error.
 * 
 *  caution:  fatal errors will not terminate translation 
 *            process when they return to calling routine.
 *            calling routine would require additional
 *            state 'QEND' in its state diagram.
 *            hence no fatal errors are presently used.
 * 
 * **************************************************
 */
void chknam(char *nam,long *errt,char *type) {
/*
 */
  static long err;
  static long i,sl;
  static long n;
  static char msgstr[128+1];
/*
 */
  void inperr();
  void scrwrt();
  int testupword();
/*
 * initialize local variables and strings
 */
  err = *errt;
  msgstr_(128+1) = '\0';
/*
 *  test for upper-case reserved word
 */
  err = testupword(nam,&err);
/*
 *  err = 1 if this is a upper-case reserved word
 *      = 0 else
 */
  if (err==1) {
    inperr(&nftl);
    sprintf(msgstr," LBCC1190: %s is an illegal"
        " identifier: reserved word",nam);
    scrwrt("+W",msgstr);
    *errt = err;
    return;
  }
/*
 *  check if name is too big based on type of name
 *  propositional variables, predicates, quantifiers, elements
 *  names, set names can be 52 chars long
 *  get actual size of name
 */
  sl = strlen(nam);
  if ((strcmp(type  ,"L")==0)||
      (strcmp(type  ,"C")==0)||
      (strcmp(type  ,"E")==0)||
      (strcmp(type  ,"P")==0)||
      (strcmp(type  ,"Q")==0)||
      (strcmp(type  ,"V")==0)||
      (strcmp(type  ,"S")==0)) {
/*
 *  all names may be at most 52 characters long
 */
    if (sl>52) {
      err=1;
      inperr(&nftl);
      sprintf(msgstr,
        " LBCC1190: %s is an illegal identifier: "
        "too long",nam);
      scrwrt("+W",msgstr);
      *errt = err;
      return;
    }
  } else {
/*
 *  must be one of above cases
 */
    error("chknam","102");
  }
/*
 *  first character must be alpha or underscore, and
 *  cannot be numeral
 */
  n = (int)nam_(1);
  if (((n<65)||
      (n>90))&&
      ((n<97)||
      (n>122))&&
      (n!=95)) {
    err=1;
    inperr(&nftl);
    sprintf(msgstr," LBCC1190: %s is an illegal"
            " identifier:  illegal characters", nam);
    scrwrt("+W",msgstr);
    *errt = err;
    return;
  }
/*
 *  remaining characters must be alphanumeric or underscore
 */
  for(i=2; i<=sl; i++)  {
    n = (int)nam_(i);
    if (((n<65)||
        (n>90))&&
        ((n<97)||
        (n>122))&&
        ((n<48)||
        (n>57))&&
        (n!=95)) {
      err=1;
      inperr(&nftl);
      sprintf(msgstr," LBCC1190: %s is an illegal"
              " identifier:  illegal characters", nam);
      scrwrt("+W",msgstr);
      *errt = err;
      return; 
    }
  }
/*
 *  name is okay
 */
  *errt = err;
  return;
}
/*eject*/
/*
 * ******************************************************
 *  subroutine chknum
 * 
 *  purpose:  parses number.
 * 
 *  output:   err : 0 means number is valid.
 *                  1 means not valid.
 * 
 *  note: calling routine should check for error.
 * 
 *  caution:  fatal errors will not terminate translation process
 *            when they return to calling routine.
 *            calling routine would require additional state
 *            'QEND' in its state diagram.
 *            hence no fatal errors are presently used.
 * 
 * ******************************************************
 * 
 */
void chknum(char *numstr,long *minust,long *errt) {
/*
 */
  static long minus,err,i,sl;
  static long n;
  static char msgstr[128+1];
/*
 */
  void inperr();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  minus = *minust;
  err = *errt;
  msgstr_(128+1) = '\0';
/*
 */
  err=0;
  if (strcmp(numstr,"$")==0) {
/*
 *  blank number
 */
    inperr(&nftl);
    strcpy(msgstr," LBCC1200: Cost value expected");
    scrwrt("+W",msgstr);
    err=1;
    *minust = minus;
    *errt = err;
    return;
  }
/*
 *  check for length
 */
  sl = strlen(numstr);
  if (sl>5) {
    inperr(&nftl);
    sprintf(msgstr,
        " LBCC1210: Five digits maximum for cost value");
    scrwrt("+W",msgstr);
    err=1;
    *minust = minus;
    *errt = err;
    return;
  }
/*
 *  check that all are digits; ignore blanks
 */
  for(i=1; i<=sl; i++)  {
    n = (int)numstr_(i);
    if ((n<48)||
        (n>57)) {
      inperr(&nftl);
      sprintf(msgstr,
          " LBCC1230: Invalid number: "
          "non-numeric characters");
      scrwrt("+W",msgstr);
      err=1;
      *minust = minus;
      *errt = err;
      return;
    }
  }
/*
 *  range must be -16,383 to 16,383 (=2**14 - 1)
 */
  sscanf(numstr,"%ld",&n);
  if (minus==1) {
    n=n*(-1);
  }
  if ((n>16383)||(n<-16383)) {
    inperr(&nftl);
    sprintf(msgstr,
        " LBCC1220: Cost must be an integer: "
        "-16,383..16,383");
    scrwrt("+W",msgstr);
    err=1;
    *minust = minus;
    *errt = err;
    return;
  }
  *minust = minus;
  *errt = err;
  return;
}
/*eject*/
/*
 * ************************************************
 *  subroutine ckeoln
 * 
 *  purpose:  checks for end of line by
 *            determining if there are characters
 *            after the current position, r, in tmparg.
 *            gives warning message if there are such
 *            characters. it is assumed that such
 *            characters are unwanted.
 * 
 *    input:  tmparg - the current line.
 *            r      - the right index of the current
 *                     position in the line being parsed.
 * 
 * ************************************************
 * 
 */
void ckeoln(char *tmparg,long *rt) {
/*
 */
  static long r;
  static char msgstr[128+1];
/*
 */
  void inperr();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  r = *rt;
  msgstr_(128+1) = '\0';
/*
 *  if the two characters after the rightmost position
 *  of the current component are not '$$',
 *  then there are more components on this line.
 */
  if (lstrncmp(&tmparg_(r+1),"$$",2)!=0) {
    inperr(&warn);
    sprintf(msgstr,"LBCC0080: Extra characters on this "
        "line are ignored");
    scrwrt("+W",msgstr);
  }
  *rt = r;
  return;
}
/*eject*/
/*
 * ************************************************
 *  subroutine cmpres
 * 
 *  purpose:  removes blanks
 *
 *  input:    tmparg = string tmparg
 *            *ixt   = last index of string
 *
 *  output:   tmparg with all blanks squeezed out
 *            *ixt   = new last index of string
 * 
 * ************************************************
 * 
 */
void cmpres(char *tmparg,long *ixt) {
/*
 */
  static long i,ip,ix;
/*
 * initialize local variables and strings
 */
  ix = *ixt;
  ip = 0;
/*
 *  process each entry in tmparg
 */
  for (i=1;i<=ix;i++) {
    if (tmparg_(i)!=' ') {
      ip++;
      if (ip<i) {
        tmparg_(ip) = tmparg_(i);
      }
    }
  }
/*
 *  done
 */
    *ixt = ip;
    return;
}
/*eject*/
/*
 * *************************************************
 *  subroutine compct
 * 
 *  purpose:  compacts the line given by tmparg,
 *            inserting '$' between syntactical components.
 *            tmparg is stored in stmp, and the
 *            compacted string is built in tmparg.
 * 
 *   caution:  although tmparg is dimensioned large,
 *             we assume text prior to compaction to be no
 *             more than 125 characters.
 * 
 * *************************************************
 * 
 */
void compct(char *tmparg) {
/*
 */
  static char stmp[128+1];
  static long fn,j,jx,i,ix,nz;
/*
 * initialize local variables and strings
 */
  stmp_(128+1) = '\0';
/*
 */
  nz = strlen(tmparg);
/*
 *  eliminate comment portion, if any
 *  change all string characters 
 *  with ascii code 1-31 or >=127 by blanks
 */
  for(i=1; i<=nz; i++)  {
    if (tmparg_(i)=='*') {
      for (j=i;j<=nz;j++) {
        tmparg_(j) = ' ';
      }
      goto zz60;
    }
    ix = (int)tmparg_(i);
    if (((ix>=1)&&
        (ix<=31))||
        (ix>=127)) {
      tmparg_(i) = ' ';
    }    
  }
/*
 *  introduce one blank at end if
 *   not present, and add new end of string character
 */
  if (tmparg_(nz) != ' ') {
    tmparg_(nz+1) = ' ';
    tmparg_(nz+2) = '\0';
    nz++;
  }
/*
 */
  zz60:;
  strcpy(stmp,tmparg);
/*
 *  skip over leading blanks
 *  ix will point at first non-blank
 */
  ix=1;
  jx=0;
  for(i=1; i<=nz; i++)  {
    if (stmp_(i)==' ') {
      ix=ix+1;
    } else {
      goto zz190;
    }
  }
/*
 *  blank line encountered
 */
  goto zz300;
  zz190:;
/*
 *  check if this is INCLUDE statement
 *  if yes, do not parse '.' or '/' in next step
 */
  if ((strncmp(&stmp_(ix),"INCLUDE ",8)==0)||
      (strncmp(&stmp_(ix),"include ",8)==0)) {
    fn = 1; 
  } else {
    fn = 0;
  } 
  for(j=ix; j<=nz; j++)  {
    if ((stmp_(j)!=' ') &&
        ((stmp_(j)!=':')||(fn==1)) &&
        (stmp_(j)!='(') &&
        (stmp_(j)!=')') &&
        (stmp_(j)!='[') &&
        (stmp_(j)!=']') &&
        (stmp_(j)!='|') &&
        (stmp_(j)!='&') &&
        (stmp_(j)!='*') &&
        (stmp_(j)!=',') &&
        ((stmp_(j)!='.')||(fn==1)) &&
        ((stmp_(j)!='/')||(fn==1)) &&
        ((stmp_(j)!='\\')||(fn==1)) &&
        (stmp_(j)!='=') &&
        (stmp_(j)!='!') &&
        (stmp_(j)!='<') &&
        (stmp_(j)!='>') &&
        ((stmp_(j)!='-')||(fn==1)) ) {
/*
 *  store character
 *  identifier length is checked during parsing
 */
      jx=jx+1;
      tmparg_(jx) = stmp_(j);
    } else {
/*
 *  delimiter encountered.  insert separation marker
 */      
      if (j!=ix) {
        if (tmparg_(jx)!='$') {
/*
 *  only want one consecutive '$'
 *  (multiple blanks encountered)
 */
          jx=jx+1;
          tmparg_(jx) = '$';
        }
      }
      if (stmp_(j)!=' ') {
/*
 *  store delimiter
 */
        jx=jx+1;
        tmparg_(jx) = stmp_(j);
/*
 *  handle cases of two special characters, where second
 *  character follows the first one without separator
 */
        if (((stmp_(j)=='!')&&
             (stmp_(j+1)=='='))||
            ((stmp_(j)=='=')&&
             (stmp_(j+1)=='='))||
            ((stmp_(j)=='<')&&
             (stmp_(j+1)=='='))||
            ((stmp_(j)=='>')&&
             (stmp_(j+1)=='='))) {
          jx=jx+1;
          tmparg_(jx) = stmp_(j+1);
          stmp_(j+1) = ' ';
        }
        jx=jx+1;
        tmparg_(jx) = '$';
      }
    }
  }
/*
 *  attach terminating '$' and '\0'
 */
  zz300:;
  jx=jx+1;
  tmparg_(jx) = '$';
  jx=jx+1;
  tmparg_(jx) = '\0';
  if (jx>busmax) {
/*
 *  array dimension exceeded
 */
    error("compct","302");
  }
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine convtloword
 * 
 *  purpose: converts input string if it is a 
 *           lower-case reserved word, to upper case
 *
 *  input:   nam   string
 *           l     beginning index of word
 *           r     ending index of word
 *
 *  ouput:   nam   converted to upper case if the input string
 *                 is a served word in lower case
 * 
 * ******************************************************
 */
void convtloword(char *nam,long *lt,long *rt) {
/*
 */
  long i,l,r;
  static char str[32+1];
/*
 */
  int testupword(); 
/*
 * initialize local variables and strings
 */
  l = *lt;
  r = *rt;
/*
 *  if string is longer than 32 characters, it cannot
 *  be reserved
 */
  if((r-l+1)>32) {
    return;
  }
/*
 *  copy string into str
 */
  strncpy(str,&nam_(l),r-l+1);
  str_(r-l+2) = '\0';
/*
 *  check whether this is an upper-case reserved word
 */
  if (testupword(str)==1) {
    return;
  }
/*
 *  check if string is entirely in lower case
 */
  for (i=1;i<=r-l+1;i++) {
    if (((int)str_(i) < 97) || 
      ((int)str_(i) > 122)) {
/*
 *  string str is not entirely in lower case
 */
      return;
    } else {
/*
 *  convert to upper case
 */
      str_(i) = (char)((int)str_(i) - 32);
    }
  }
/*
 *  check if string converted to upper case is 
 *  a reserved word
 *  if yes, put str string into nam string
 */
  if (testupword(str)==1) {
    strncpy(&nam_(l),str,r-l+1);
  }
  return;
}
/*eject*/
/*
 * ************************************************
 *  subroutine extcmp
 * 
 *  purpose:  extracts next component from tmparg
 * 
 *    input:  tmparg - l: the left index of the current component
 *                        initially this is 0
 *                     r: the right index of the current component
 *                        initially this is 0
 * 
 *   output:  l,r - the new left and right indices of the 
 *                  extracted component.
 *            if there are no more components to extract, then
 *            tmparg(l:r) = '$'
 * 
 *  caution:  any string in tmparg must have at least 
 *            two consecutive terminating '$' characters 
 *            so that it can be detected when there are
 *            no more components to extract.
 * 
 * ************************************************
 * 
 */
void extcmp(char *tmparg,long *lt,long *rt) {
/*
 */
  static long l,r,n;
  static long bidx,mtchbr;
/*
 */
  void smtchbr();
/*
 * initialize local variables and strings
 */
  l = *lt;
  r = *rt;
/*
 */
  if ((l==0)&&
      (r==0)) {
    l=1;
    r=1;
    goto zz100;
  }
/*
 *  make l the first character after the '$'
 */
  l=r+2;
  r=l;
/*
 *  return if there is not a component to extract
 */
  if (tmparg_(l)=='$') {
    *lt = l;
    *rt = r;
    return;
  }
/*
 *  search right until '$' encountered, or,
 *  if first character is '[' and it is not
 *  the only character of this component,
 *  search for matching ']'
 */
  zz100:;
  if ((tmparg_(l)=='[')&&
      (tmparg_(l+1)!='$')) {
/*
 *  search for matching ']'
 */
    n=busmax;
    smtchbr(&mtchbr,tmparg,&l,&n);
    bidx=mtchbr;
    r=bidx;
    *lt = l;
    *rt = r;
    return;
  } else {
    zz120:;
    r=r+1;
    if (tmparg_(r)=='$') {
      r=r-1;
      *lt = l;
      *rt = r;
      return;
    }
    goto zz120;
  }
}
/*eject*/
/*
 * ************************************************
 *  subroutine extnam
 * 
 *  purpose:  given name in tmparg(l to r).
 *  if it is a variable, return variable name in nam.
 *  if it is a predicate, return the predicate name
 *  in nam and the arguments in arg1 and arg2.
 * 
 * ************************************************
 * 
 */
void extnam(char *tmparg,long *lt,long *rt,char *nam,
            char *arg1,char *arg2,long *minust) {
/*
 */
  static long l,r;
  static long minus,r1,ix,tl,j;
/*
 * initialize local variables and strings
 */
  l = *lt;
  r = *rt;
  minus = *minust;
/*
 */
  strcpy(nam   ,"                           ");
  strcpy(arg1  ,"        ");
  strcpy(arg2  ,"        ");
/*
 *  check for minus sign
 */
  minus=0;
  zz100:;
  if (tmparg_(l)==' ') {
    l=l+1;
    goto zz100;
  }
  if (tmparg_(l)=='-') {
    l=l+1;
    minus=1;
  }
/*
 *  if it is a predicate, will find '('; search for it.
 */
  r1=r;
  for(ix=l; ix<=r; ix++)  {
    if (tmparg_(ix)=='(') {
      r1=ix-1;
      goto zz200;
    }
  }
/*
 *  must be a variable name since '(' was not found; return
 */
  strncpy(nam,&tmparg_(l),r-l+1);
  nam_(r-l+2) = '\0';
  *lt = l;
  *rt = r;
  *minust = minus;
  return;
/*
 *  predicate name is now: tmparg(l to r1).
 *  extract argument(s) and
 *  find ',' or ')'.  tl is first char of first argument.
 */
  zz200:;
  strncpy(nam,&tmparg_(l),r1-l+1);
  nam_(r1-l+2) = '\0';
  tl=r1+1;
  for(j=tl; j<=r; j++)  {
    if ((tmparg_(j)==',')||
        (tmparg_(j)==')')) {
/*
 *  extract argument
 */
      strncpy(arg1,&tmparg_(tl+1),(j-1)-(tl+1)+1);
      arg1_((j-1)-(tl+1)+2) = '\0';
      if (tmparg_(j)==',') {
/*
 *  extract second argument
 */
        strncpy(arg2,&tmparg_(j+1),(r-1)-(j+1)+1);
        arg2_((r-1)-(j+1)+2) = '\0';
      } else {
/*
 *  second argument does not exist
 */
        strcpy(arg2  ,"?");
      }
      *lt = l;
      *rt = r;
      *minust = minus;
      return;
    }
  }
/*
 *  error: argument delimiters not found
 */
  error(" extnam ","  212   ");
}
/*eject*/
/*
 * ************************************************
 *  subroutine fndnam
 * 
 *  purpose:  given name in nam, find index and 
 *            type of name.
 * 
 *   output:  indx: index of name in eltnam, setnam,
 *                  prdnam, varnam, qntnam, nvnam
 *                  0 means was not found anywhere.
 *            type: "E"  element
 *                  "S"  set
 *                  "P"  predicate
 *                  "V"  variable
 *                  "N"  new variable (generated in rewrit)
 *                  "Q"  quantified variable
 * 
 * ************************************************
 * 
 */
void fndnam(char *nam,long *indxt,char *type) {
/*
 */
  static long indx;
  static long i;
/*
 * initialize local variables and strings
 */
  indx = *indxt;
/*
 */
  indx=0;
  strcpy(type  ," ");
/*
 *  search set names
 */
  if (nsets>0) {
    for(i=1; i<=nsets; i++)  {
      if (strcmp(nam,&setnam_(1,i))==0) {
        indx=i;
        strcpy(type  ,"S");
        *indxt = indx;
        return;
      }
    }
  }
/*
 *  search element names
 */
  if (nelts>0) {
    for(i=1; i<=nelts; i++)  {
      if (strcmp(nam,&eltnam_(1,i))==0) {
        indx=i;
        strcpy(type  ,"E");
        *indxt = indx;
        return;
      }
    }
  }
/*
 *  search predicates
 */
  if (nprds>0) {
    for(i=1; i<=nprds; i++)  {
      if (strcmp(nam,&prdnam_(1,i))==0) {
        indx=i;
        strcpy(type  ,"P");
        *indxt = indx;
        return;
      }
    }
  }
/*
 *  search variables
 */
  if (nvars>0) {
    for(i=1; i<=nvars; i++)  {
      if (strcmp(nam,&varnam_(1,i))==0) {
        indx=i;
        strcpy(type  ,"V");
        *indxt = indx;
        return;
      }
    }
  }
/*
 *  search quantified variables
 */
  if (nqnt>0) {
    for(i=1; i<=nqnt; i++)  {
      if (strcmp(nam,&qntnam_(1,i))==0) {
        indx=i;
        strcpy(type  ,"Q");
        *indxt = indx;
        return;
      }
    }
  }
/*
 *  search new variable names
 */
  if (newvar>0) {
    for(i=1; i<=newvar; i++)  {
      if (strcmp(nam,&nvnam_(1,i))==0) {
        indx=i;
        strcpy(type  ,"N");
        *indxt = indx;
        return;
      }
    }
  }
  *indxt = indx;
  return;
}
/*eject*/
/*
 * ************************************************
 *  subroutine gnewv
 * 
 *  purpose:  generates a new variable as determined
 *            by newvar and stores it in tstr.
 * 
 * ************************************************
 * 
 */
void gnewv(char *tstr) {
/*
 */
  static char a[1+1];
  static long n,n1,j,i;
  static long tento[10];
  static char msgstr[128+1];
/*
 */
  void inperr();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  a_(1+1) = '\0';
  msgstr_(128+1) = '\0';
/*
 */
  newvar=newvar+1;
/*
 *  convert to string, storing right justified in tstr,
 *  padded with leading zeros and distinguishing character '*'.
 */
  tstr_(1) = '*';
  n=newvar;
  j=1;
  tento[0] = 1;
  for (i=1;i<=3;i++) {
    tento[i] = tento[i-1]*10;
  }
  for(i=3; i>=0; i--)  {
    j=j+1;
    if (n >= tento[i]) {
      n1 = n/tento[i];
      n = n - (n/tento[i])*tento[i];
    } else {
      n1=0;
    }
    a_(1) = (char)(48+n1);
    tstr_(j) = a_(1);
  }
  tstr_(5+1) = '\0';
/*
 *  store new variable in nvnam
 */
  strcpy(&nvnam_(1,newvar),tstr);
/*
 *  store variable in cnfvar
 */
  ncnfv=ncnfv+1;
  if (ncnfv>cvmax) {
    inperr(&fatal);
    n = cvmax;
    sprintf(msgstr,
        "  LBCC2120: New variable addition exceeds"
        " max total variables: %ld",n);
    scrwrt("+W",msgstr);
    return;
  }
  strcpy(&cnfvar_(1,ncnfv),tstr);
  return;
}
/*eject*/
/*
 * ************************************************
 *  subroutine initds
 * 
 *  purpose:  initialize 
 *              delete option and cost data structures;
 *              usage arrays for sets, predicates, 
 *                 variables, and quantifiers;
 *              start state (for transition diagram);
 *              file identifiers.
 * 
 * ************************************************
 * 
 */
void initds() {
/*
 */
  static long i,j;
/*
 * initialize local variables and strings
 * 
 */
  for(i=1; i<=cvmax; i++)  {
    delopt_(i)=0;
    strcpy(&cstval_(1,1,i),"      ");
    strcpy(&cstval_(1,2,i),"      ");
    for (j=1;j<=vnamln;j++) {
      cnfvar_(j,i) = ' ';
    }
    cnfvar_(vnamln+1,i) = '\0';
  }
/*
 *  initialize 'used' arrays
 */
  for(i=1; i<=setmax; i++)  {
    sused_(i)=0;
  }
  for(i=1; i<=prdmax; i++)  {
    pused_(i)=0;
  }
  for(i=1; i<=cvmax; i++)  {
    vused_(i)=0;
  }
  for(i=1; i<=qntmax; i++)  {
    qused_(i)=0;
  }
/*
 *  initially we are in state q100
 */
  strcpy(state ,"Q100");
/*
 *  initialize ncnfv, the number of cnf variables.
 */
  ncnfv=0;
/*
 *  current source code line number is 0
 */
  cline=0;
/*
 *  initialize column and row count for output 
 *  cnf formulation
 */
  trncols = 0;
  trnrows = 0;
  trnanzs = 0;
/*
 *  initialize number of sets, elements, predicates, variables
 */
  nsets=0;
  nelts=0;
  nprds=0;
  nvars=0;
/*
 *  associate values with tmp1, tmp2 file units
 */
  tmp1=12;
  tmp2=13;
/*
 *  initialize total errors and warnings
 */
  toterr=0;
  totwrn=0;
/*
 *  initialize variable option information
 */
  strcpy(truec ,"      ");
  strcpy(falsc ,"      ");
  dopt=0;
  avopt=0;
  return;
}
/*eject*/
/*
 * **************************************************
 *  subroutine inperr
 * 
 *  purpose:  outputs line number and type of error,
 *            determined by err, and increments appropriate
 *            error counter
 * 
 *    input:  err    - either fatal, nftl, or warn
 * 
 *    if the error is fatal, then the current state is
 *    set to 'QEND'
 * 
 * ************************************************** 
 */
void inperr(long *errt) {
/*
 */
  static long err;
  static char msgstr[128+1];
/*
 */
  void inperr();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  err = *errt;
  msgstr_(128+1) = '\0';
/*
 */
  sprintf(msgstr,"file %s\nline %ld",
                 &logfil_name_(1,nlogfil),cline);
  scrwrt("  ",msgstr);
  if (err==fatal) {
    strcpy(msgstr," FATAL ERROR:");
    scrwrt("+ ",msgstr);
    toterr=toterr+1;
    strcpy(state ,"QEND");
  }
  if (err==warn) {
    strcpy(msgstr," WARNING:");
    scrwrt("+ ",msgstr);
    totwrn=totwrn+1;
  }
  if (err==nftl) {
    strcpy(msgstr," ERROR:");
    scrwrt("+ ",msgstr);
    toterr=toterr+1;
  }
  *errt = err;
  return;
}
/*eject*/
/*
 * *************************************************
 *  subroutine itostr
 * 
 *  purpose:  converts the integer n to a string.
 *  at most 8 characters can be generated.
 *  string is padded with leading 0s.
 * 
 *   caution:  will not place minus sign in
 *             string for negative numbers.
 * 
 * *************************************************
 * 
 */
void itostr(long *nt,char *tnam) {
/*
 */
  static long n;
  static long nx,nn,i,n1;
  static long tento[10];
/*
 * initialize local variables and strings
 */
  n = *nt;
/*
 */
  nx=0;
  nn=n;
  tento[0] = 1;
  for (i=1;i<=7;i++) {
    tento[i] = tento[i-1]*10;
  }
  for(i=7; i>=0; i--)  {
    if (nn >= tento[i]) {
      n1 = nn/tento[i];
      nn = nn - (nn/tento[i])*tento[i];
    } else {
      n1=0;
    }
    nx=nx+1;
    tnam_(nx) = (char)(48+n1);
  }
  *nt = n;
  return;
}
/*eject*/
/*
 * *****************************************************
 *  subroutine lstrncmp
 * 
 *  compares n characters of string s1 with entries
 *  of string s2.
 * 
 *  return: 1 if strlen(s2) == n and if the n characters
 *            match
 *          0 otherwise
 *            (in particular, if s1 is shorter than s2)
 * ******************************************************
 */
int lstrncmp(char *s1,char *s2,long n) {
/*
 */
  static long i;
/*
 *  check that s1 has length of at least n
 */
  for (i=1;i<=n;i++) {
    if (s1_(i)=='\0') {
      return(1);
    }
  }
/*
 *  check string length of s2 and compare the entries
 */
  if ((strlen(s2)==n) &&
      (strncmp(s1,s2,n)==0)) {
    return(0);
  } else {
    return(1);
  }
}
/*eject*/
/*
 * **************************************************
 *  subroutine scrwrt
 * 
 *  purpose:  this routine is used when output from
 *            two or more write statements is required
 *            to be on the same line of the screen.
 *            depending on the value of funct,
 *            does one of the following:
 *             '  ' -> put contents of msgstr into
 *                     local string scrstr,
 *                     starting at the first position.
 * 
 *             '+ ' -> put contents of msgstr into scrstr,
 *                     at current string position.
 * 
 *             'W ' -> write the contents of scrstr
 *                     to the screen.
 *                     msgstr is ignored for this case.
 * 
 *             '+W' -> first perform '+ ' command,
 *                     then 'W ' command.
 * 
 *    input:  funct string: it is the command
 *            msgstr string: it is the text string
 * 
 * **************************************************
 * 
 */
void scrwrt(char *funct,char *msgstr) {
/*
 */
  static char scrstr[512+1];
  static long i,wf;
/*
 * initialize local variables and strings
 */
  scrstr_(512+1) = '\0';
/*
 * initialize writing flag for too many messages
 */
  if ((totwrn+toterr)<mwemax) {
    wf=1;
  } else {
    wf=wf-1;
  }
/*
 *  write message about too many warning/error
 *  messages for screen
 */
  if (wf==0) {
    printf(
        "Writing of warning/error messages "
        "to screen stopped\n"
        "since there are too many such messages\n"
        "Writing of warning/error messages "
        "to error file continues");
  }
/*
 */
  if (strcmp(funct,"  ")==0) {
/*
 *  initialize output string
 *  copy msgstr starting in character position 1
 */
    strcpy(scrstr,msgstr);
  }
/*
 * protect against out-of-order call of message writing
 */
  if (strlen(scrstr)==512) {
    scrstr_(1) = '\0';
  }
  if (funct_(1)=='+') {
    if ((strlen(scrstr)+1+128) > 512) {
/*
 *  not enough space left in scrstr
 */
      error(" scrwrt ","  102   ");
    }
    i = strlen(scrstr);
    strcpy(&scrstr_(i+1),msgstr);
  }
  if ((funct_(1)=='W') ||
      (funct_(2)=='W')) {
/*
 *  write the contents of scrstr to the screen
 */
    if (wf==1) {
      printf(
         "\n**********************************\n%s\n",scrstr);
    }
    fprintf(errfil,
         "\n**********************************\n%s\n",scrstr);
  }
  return;
}
/*eject*/
/*
 * ************************************************
 *  subroutine testupword
 * 
 *  purpose:  tests for upper-case reserved word
 * 
 *   input:   nam string
 * 
 *  returns:  1 if it is upper-case reserved word
 *            0 else
 *
 *  caution:  the word GOAL is a reserved word but is
 *            not tested since it is a unique variable name.
 * 
 * **************************************************
 */
int testupword(char *nam) {
/*
 */
  if (strcmp(nam   ,"AND")==0) return(1);
  if (strcmp(nam   ,"ALL")==0) return(1);
  if (strcmp(nam   ,"ALWAYS")==0) return(1);
  if (strcmp(nam   ,"ADATA")==0) return(1);
  if (strcmp(nam   ,"ASSIGNFALSE")==0) return(1);
  if (strcmp(nam   ,"ASSIGNTRUE")==0) return(1);
  if (strcmp(nam   ,"AT")==0) return(1);
  if (strcmp(nam   ,"BDATA")==0) return(1);
  if (strcmp(nam   ,"DEFINE")==0) return(1);
  if (strcmp(nam   ,"DELETABLE")==0) return(1);
  if (strcmp(nam   ,"ENDATA")==0) return(1);
  if (strcmp(nam   ,"EXISTS")==0) return(1);
  if (strcmp(nam   ,"FACTS")==0) return(1);
  if (strcmp(nam   ,"FALSECOST")==0) return(1);
  if (strcmp(nam   ,"FC")==0) return(1);
  if (strcmp(nam   ,"FCOST")==0) return(1);
  if (strcmp(nam   ,"FOR")==0) return(1);
  if (strcmp(nam   ,"FREQUENTLY")==0) return(1);
  if (strcmp(nam   ,"HALF")==0) return(1);
  if (strcmp(nam   ,"IF")==0) return(1);
  if (strcmp(nam   ,"IN")==0) return(1);
  if (strcmp(nam   ,"INCLUDE")==0) return(1);
  if (strcmp(nam   ,"LEVEL")==0) return(1);
  if (strcmp(nam   ,"MINIMIZE")==0) return(1);
  if (strcmp(nam   ,"NAME")==0) return(1);
  if (strcmp(nam   ,"NOT")==0) return(1);
  if (strcmp(nam   ,"ON")==0) return(1);
  if (strcmp(nam   ,"OR")==0) return(1);
  if (strcmp(nam   ,"PREDICATES")==0) return(1);
  if (strcmp(nam   ,"RARELY")==0) return(1);
  if (strcmp(nam   ,"SATISFY")==0) return(1);
  if (strcmp(nam   ,"SETS")==0) return(1);
  if (strcmp(nam   ,"SOMETIMES")==0) return(1);
  if (strcmp(nam   ,"TC")==0) return(1);
  if (strcmp(nam   ,"TCOST")==0) return(1);
  if (strcmp(nam   ,"THE")==0) return(1);
  if (strcmp(nam   ,"THEN")==0) return(1);
  if (strcmp(nam   ,"THERE")==0) return(1);
  if (strcmp(nam   ,"TIME")==0) return(1);
  if (strcmp(nam   ,"TRUECOST")==0) return(1);
  if (strcmp(nam   ,"VARIABLES")==0) return(1);
  if (strcmp(nam   ,"VERY")==0) return(1);
  if (strcmp(nam   ,"WHERE")==0) return(1);
  return(0);
}
/*eject*/
/*
 * ************************************************
 *  subroutine varout
 * 
 *  purpose:  collects the flagged variables of cnfvar
 *            in trcolnam, along with related use index,
 *            atf value, delete option, and true/false costs.
 *            gives warnings if a cost was
 *            specified for a variable but that
 *            variable does not appear in the clauses.
 * 
 * ************************************************
 * 
 */
void varout() {
/*
 */
  static long i;
  static char msgstr[128+1];
/*
 */
  void inperr();
  void scrwrt();
/*
 * initialize local variables and strings
 */
  msgstr_(128+1) = '\0';
/*
 * -----------------------------------------------
 *  collect the flagged variables of cnfvar
 *  write them out in the order in which
 *  they are encountered.
 * -----------------------------------------------
 */
  if (ncnfv<=0) {
/*
 *  error: ncnfv cannot be zero here
 */
    error(" varout ","   12   ");
  }
  trncols = 0;
  for(i=1; i<=ncnfv; i++)  {
/*
 *  keep variables that have been used in clauses or if
 *  keepallvarflg specified that all variables are kept
 */
    if ((cnfvarflg_(i)=='P')||
        (keepallvarflg==1)) {
/*
 *  increment trncols
 */
      trncols++;
      /* check added March 8, 2008 */
      if (trncols > cvmax) {
        printf("\nToo many columns, increase colmax = %ld\n",cvmax); 
        fprintf(errfil,
           "Too many columns, increase colmax = %ld\n",cvmax);
        lbccexit(1);
      }
/*
 *  record use-index function: from index i of cnfvar to
 *  reduced list index trncols of trcolnam
 */
      trcolusx_(i) = trncols;
/*
 *  if this is GOAL variable, it must have been used in
 *  at least one clause
 */
      if ((strcmp(&cnfvar_(1,i),"GOAL")==0)&&
          (cnfvarflg_(i)!='P')) {
        inperr(&fatal);
        strcpy(msgstr,
            " LBCC2260: GOAL variable specified but not used");
        scrwrt("+W",msgstr);
        return;
      }    
/*
 *  store - variable name
 *        - delete option
 */
      strcpy(&trcolnam_(1,trncols),&cnfvar_(1,i));
      if (delopt_(i)==1) {
        trcolnam_(58,trncols) = 'D';
      } else {
        trcolnam_(58,trncols) = ' ';
      }
      trcolnam_(59,trncols) = '\0';
/*
 *  store - atf value
 *        - true/false cost
 */
      trcvatf_(trncols) = varopt_(i);
      trtrucst_(trncols) = 0;
      trfalcst_(trncols) = 0;
      sscanf(&cstval_(1,1,i),"%6ld",&trtrucst_(trncols));    
      sscanf(&cstval_(1,2,i),"%6ld",&trfalcst_(trncols));
    } else {
/*
 *  check if cost specified but variable not used
 */
      if (((strcmp(&cstval_(1,1,i),"      ")!=0) ||
          (strcmp(&cstval_(1,2,i),"      ")!=0)) &&
          (cstflg==1)) {
        inperr(&warn);
        sprintf(msgstr," LBCC0010: Variable with cost "
            "not used: %s",&cnfvar_(1,i));
        scrwrt("+W",msgstr);
      }
/*
 *  check if delete option specified for variable
 *  but not used
 */
      if (delopt_(i)==1) {
        inperr(&warn);
        sprintf(msgstr," LBCC0020: Variable with delete option "
            "not used: %s",&cnfvar_(1,i));
        scrwrt("+W",msgstr);
      }
/*
 *  check if assigned value specified for variable
 *  but not used
 */
      if (varopt_(i)!=0) {
        inperr(&warn);
        sprintf(msgstr," LBCC0025: Variable with assigned value "
            "not used: %s",&cnfvar_(1,i));
        scrwrt("+W",msgstr);
      }
    }
  }
/*
 * -----------------------------------------------
 *  if nonusewarnflg = 1, then warn
 *  if any sets, predicates or variables
 *  given in the declaration section of the source
 *  file were not used
 * -----------------------------------------------
 */
  if (nonusewarnflg==1) {
    for(i=1; i<=nsets; i++)  {
      if ((sused_(i)==0)&&
          ((strcmp(&setnam_(1,i),"UNIVERSE")!=0)&&
          (strcmp(&setnam_(1,i),"universe")!=0))) {
        inperr(&warn);
        sprintf(msgstr," LBCC0030: Set never used: %s",
            &setnam_(1,i));
        scrwrt("+W",msgstr);
      }
    }
    for(i=1; i<=nprds; i++)  {
      if (pused_(i)==0) {
        inperr(&warn);
        sprintf(msgstr," LBCC0040: Predicate never used: %s",
            &prdnam_(1,i));
        scrwrt("+W",msgstr);
      }
    }
    for(i=1; i<=nvars; i++)  {
      if (vused_(i)==0) {
        inperr(&warn);
        sprintf(msgstr,"  LBCC0050: Variable never used: %s",
            &varnam_(1,i));
        scrwrt("+W",msgstr);
      }
    }
  }
  return;
}
/*  last record of trutil.c****** */

