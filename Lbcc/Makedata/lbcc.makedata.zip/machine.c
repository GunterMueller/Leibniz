/*  first record of machine.c***** */
/*
 * -----------------------------------------------------
 * machine example expert system
 * copyright 1990-2001 by Leibniz Company, Plano, Texas
 * 
 * -----------------------------------------------------
 *
 */ 
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
#include "leibnizexts.h"
/*
 */
int main() {
/*
 *  include leibnizmacro.h file, which contains
 *     - leibniz parameters for procedures
 *     - alternate definitions of leibniz procedures
 */
#include "leibnizmacro.h" 
/*
 * miscellaneous variables
 */
  char answer[10];
  long pi;
  PRGNAME_ARRAY prgname[2];
/*
 *  initialize problem in machine.prg
 */
  value[0] = 1;
  strcpy(name,"machine.err");
  strcpy(prgname[0],"machine.prg");
  strcpy(prgname[1],"");
  initialize_problem();
/*
 */
  printf(
  "\n        ****Checking Crash Scenarios****\n"
  "An automated assembly machine has two blocks among\n"
  "its components.\n"
  "Block_a moves between position_1 and position_2.\n"
  "Block_b moves between position_3 and position_4.\n"
  "If both blocks move simultaneously, then potentially\n"
  "they will collide and produce a crash of the machine.\n"
  "Objective is to find how the system may crash due to\n"
  "failure of switches at the four positions.\n\n"
  "                ____               \n"
  "     o---------|____|->>>--o       \n"
  "position_1    block_a   position_2 \n\n");

/*
 *  determine if crash may occur at all
 */
  printf("Determine whether there is a worst case scenario\n"
         "where crash may happen\n");
/*
 *  initialize all logic variables to ACTIVE (= -1)
 *  set crash to FIXTRUE (= 3) and solve problem
 *  any satisfying solution is a possible crash scenario
 */
  strcpy(state,"A");
  modify_allvar();
  crash = FIXTRUE;
  solve_problem();
  if (strcmp(state,"U")==0) {
    printf("\n****Crash cannot happen at all\n");
  } else {
    printf("\n****Crash may happen\n"
             "    Possible scenario:\n");
    for (pi=position_1;pi<=position_4;pi++) {
      if (stuck_open(pi)>=TRUE) {
        printf("      position_%ld: switch open\n",pi);
      } else if (stuck_closed(pi)>=TRUE) {
        printf("      position_%ld: switch closed\n",pi);
      } else {
        printf("      position_%ld: switch okay\n",pi);
      }
    }
    printf("\n");
    if (conflict(z1)>=TRUE) {
      printf("    moves 1 and 3 may collide\n");
    } else if (conflict(z2)>=TRUE) {
      printf("    moves 1 and 4 may collide\n");
    } else if (conflict(z3)>=TRUE) {
      printf("    moves 2 and 3 may collide\n");
    } else if (conflict(z4)>=TRUE) {
      printf("    moves 2 and 4 may collide\n");
    }
  }
  printf("\n\n");
  
  top_of_loop:;
/*
 *  re-initialize all logic variables to ACTIVE (=-1)
 */
  strcpy(state,"A");
  modify_allvar();
/*
 *  obtain conditions of switches and assign values to
 *  logic variables accordingly
 */
  printf("Define condition of each switch\n"
         "Respond by 'open', 'closed', 'failed' or 'ok'\n"
         "Type 'q' or 'quit' at any time to quit\n");
  for (pi=position_1;pi<=position_4;pi++) {
    printf("\nPosition_%ld: ",pi);
    scanf("%s",answer);
    if (strcmp(answer,"open")==0) {
      stuck_open(pi) = FIXTRUE;
    } else if (strcmp(answer,"closed")==0) {
      stuck_closed(pi) = FIXTRUE;
    } else if (strcmp(answer,"failed")==0) {
        switch_okay(pi) = FIXFALSE;
    } else if (strcmp(answer,"ok")==0) {
        switch_okay(pi) = FIXTRUE;
    } else {
      free_device();
      exit(0);
    }
  }
/*
 *  can crash happen?
 *  the answer is 'no' if and only if the statement
 *  S = 'not crash' is a theorem. 
 *  hence, enforce the negated statement by setting
 *  variable crash to 3 (meaning true)
 *  and check for satisfiability.
 *    if there is a solution:   crash may happen 
 *    if there is no solution:  crash cannot happen
 */
  crash = FIXTRUE;
  solve_problem();
  if (strcmp(state,"U")==0) {
    printf("\n****Crash cannot happen\n");
  } else {
    printf("\n****Crash may happen\n"
             "    Possible scenario:\n");
    for (pi=position_1;pi<=position_4;pi++) {
      if (stuck_open(pi)>=TRUE) {
        printf("      position_%ld: switch open\n",pi);
      } else if (stuck_closed(pi)>=TRUE) {
        printf("      position_%ld: switch closed\n",pi);
      } else {
        printf("      position_%ld: switch okay\n",pi);
      }
    }
    printf("\n");
    if (conflict(z1)>=TRUE) {
      printf("    moves 1 and 3 may collide\n");
    } else if (conflict(z2)>=TRUE) {
      printf("    moves 1 and 4 may collide\n");
    } else if (conflict(z3)>=TRUE) {
      printf("    moves 2 and 3 may collide\n");
    } else if (conflict(z4)>=TRUE) {
      printf("    moves 2 and 4 may collide\n");
    }
  }
  printf("\n\n");
  goto top_of_loop;
}                  
/*  last record of machine.c***** */

