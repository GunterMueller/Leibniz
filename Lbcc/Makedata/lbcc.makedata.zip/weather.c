/*  first record of weather.c***** */
/*
 * -----------------------------------------------------
 * weather example problem
 * copyright 1990-2001 by Leibniz Company, Plano, Texas
 * 
 * -----------------------------------------------------
 *
 */ 
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
#include "leibnizexts.h"
/*
 */
int main() {
/*
 *  include leibnizmacro.h file, which contains
 *     - leibniz parameters for procedures
 *     - alternate definitions of leibniz procedures
 */
#include "leibnizmacro.h"
/*
 * miscellaneous variables
 */
  PRGNAME_ARRAY prgname[2];
/*
 *  initialize problem in weather.prg
 */
  value[0] = 1;
  strcpy(name,"weather.err");
  strcpy(prgname[0],"weather.prg");
  strcpy(prgname[1],"");
  initialize_problem();
/*
 *  initialize all logic variables to ACTIVE (= -1)
 */
  strcpy(state,"A");
  modify_allvar();
/*
 *  fix sunshine to FIXTRUE (=3)
 */
  sunshine = FIXTRUE;
/*
 * question: is it possible that an umbrella is used?
 * to answer the question, set umbrella to FIXTRUE (=3)
 */
  umbrella = FIXTRUE;
/*
 *  check whether a satisfying solution exists
 */
  solve_problem();
  if (strcmp(state,"U")==0) {
    printf("\n****if sun is shining, umbrella is never used\n");
  } else {
    printf("\n****if sun is shining, umbrella may be used\n");
  }
  free_device();
  exit(0);
}
/*  last record of weather.c***** */

