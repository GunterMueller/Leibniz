/*  first record of leibniznotrans.c***** */
/*
 *  dummy version of transfer program leibniztransfer()
 *  must be used when user c program is linked with leibniz
 *  object code and transfer process option has not been
 *  specified during for compilation of log files via lbcc
 *
 *  if transfer process option has been specified, must use
 *  leibniztransfer.c created by lbcc compiler   
 */
#include<string.h>
void leibniztransfer(char *move,char *problemname,
   long *trsvar,long *errvalt,
   char *ucomnd,char *uname,char *ustate,
   char *utype,long *uvalue,short *uerror) {
  return;
}
/*  last record of leibniznotrans.c***** */
