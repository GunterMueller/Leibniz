SETS

define persons
  alice
  john
  mary
  robert
  

PREDICATES

define is_married_to on persons X persons

VARIABLES

  x
  y
  z

