/*  first record of application.c***** */
/*
 * -----------------------------------------------------
 * example program using solution programs of several
 * .log files
 * copyright 2001 by Leibniz Company, Plano, Texas
 * 
 * -----------------------------------------------------
 *
 */ 
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<fcntl.h>
#include "leibnizexts.h"
/*
 */
int main() {
/*
 *  include leibnizmacro.h file, which contains
 *     - leibniz parameters for procedures
 *     - alternate definitions of leibniz procedures
 */
#include "leibnizmacro.h"
/*
 * miscellaneous variables
 */
  PRGNAME_ARRAY prgname[3];
/*
 *  initialize problems in app1.prg and app2.prg
 *  caution: do not initialize the problem in total.prg
 *           since otherwise the transfer process becomes
 *           incorrect
 */
  value[0] = 1;
  strcpy(name,"multilog.err");
  strcpy(prgname[0],"app1.prg");
  strcpy(prgname[1],"app2.prg");
  strcpy(prgname[2],"");
  initialize_problem();

/*
 *  answer a question using the solution program for the
 *  problem in app1.log, which has the name application1
 *  -  retrieve solution program for application1
 *  -  initialize all logic variables of this problem to
 *     ACTIVE (=-1)
 *  -  fix values of some logic variables
 *  -  solve problem
 */
  strcpy(name,"application1");
  retrieve_problem();
  strcpy(state,"A");
  modify_allvar();
  is_married_to(mary,john) = FIXTRUE;
  is_married_to(alice,robert) = FIXFALSE;
  solve_problem();

/*
 *  insert here code evaluating the outcome
 */

/*
 *  answer a question using the solution program for the
 *  problem in app2.log, which has the name application2
 *  -  retrieve solution program for application2
 *  -  initialize all logic variables of this problem to 
 *     ACTIVE (=-1)
 *  -  fix values of some logic variables
 *  -  solve problem
 */
  strcpy(name,"application2");
  retrieve_problem();
  strcpy(state,"A");
  modify_allvar();
  x = FIXTRUE;
  y = FIXFALSE;
  solve_problem();

/*
 *  insert here code evaluating the outcome
 */  
  free_device();
  exit(0);
}
