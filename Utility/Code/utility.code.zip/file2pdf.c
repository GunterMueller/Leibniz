/****************************************************************
 *  file2tex program
 *
 *  Purpose: Convert the specified file to a Tex file
 *
 ****************************************************************
 */


#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<time.h> 

int main(int argc, char *argv[])
{

  time_t tp;
  char current_time[128];
  char fname[128+1];
  char ofname[128+1];
  char tmpstr[256+1];  
  int i,imax,fmax,lblank,ofnsz;
  int line,page;
  /* int n; */
  char cmnd[1024];
  FILE *infile,*outfile;

  if (argc != 2) {
    printf("Calling Sequence: filename\n");
    exit(1);
  }

  strcpy(fname,argv[1]);

  /*
   * get time
   */

  tp = time(NULL);
  strcpy(current_time,asctime(localtime(&tp)));

  /*
   * get input file name; removed August 2007  
   */
  /*  zz50:;
  printf("\nEnter Filename> ");
  scanf("%s",fname);
  n = strlen(fname);
  gets(&fname[n]);
  if (fname [0]==' '){
    goto zz50;
    } 
  */
  if ((infile = fopen(fname, "r")) == NULL) {
    printf("\n Cannot open file %s\n",fname);
    exit(1);
  }

  /*
   * open output TeX file
   */
  if ((outfile = fopen("TEX31417.tex", "w")) == NULL) {
    printf("\n Error: Cannot open output file TEX31417.tex\n");
    printf("\n Stop\n");
    exit(1);
  }

  /*
   *  write TeX definitions into output file 
   */

  fprintf(outfile,"\\font\\tty=cmtt12 scaled\\magstephalf\n");
  fprintf(outfile,"\\global\\hsize=40pc\n");
  fprintf(outfile,"\\global\\tolerance=10000\n");
  fprintf(outfile,"\\global\\vsize=64pc\n");
  fprintf(outfile,"\\parindent=0pt\n");
  fprintf(outfile,"\\nopagenumbers\n");
  fprintf(outfile,"\\global\\def\\b{$\\backslash$}\n");
  fprintf(outfile,"\\global\\def\\t{\\~{}}\n");
  fprintf(outfile,"\\global\\def\\c{\\^{}}\n");
  fprintf(outfile,"\\global\\def\\l{$\\{$}\n");
  fprintf(outfile,"\\global\\def\\r{$\\}$}\n");
  fprintf(outfile,"\\global\\def\\w{ }\n");
  fprintf(outfile,"\\global\\def\\s{\\hbox{\\tty;}}\n");
  fprintf(outfile,"\\global\\def\\d{\\hbox{\\tty:}}\n");
  fprintf(outfile,"\\global\\def\\p{\\hbox{\\tty.}}\n");
  fprintf(outfile,"\\global\\def\\m{\\hbox{\\tty,}}\n");
  fprintf(outfile,"\\global\\def\\e{\\hbox{\\tty<}}\n");
  fprintf(outfile,"\\global\\def\\f{\\hbox{\\tty>}}\n");
  fprintf(outfile,"\\tty\n");

  /*
   * find length of fname
   */

  fmax = strlen(fname);

  /*
   * create ofname from fname by accounting for special
   * symbols in name
   */
  ofnsz = -1;
  for (i=0;i<=fmax;i++){
    if ((fname[i]=='%')||
        (fname[i]=='~')||
        (fname[i]=='_')){
      ofnsz++;
      ofname[ofnsz] = '\\';
    }
    ofnsz++;
    ofname[ofnsz] = fname[i];
  }
  if (fname[i]=='~'){
      ofnsz++;
      ofname[ofnsz] = '{';
      ofnsz++;
      ofname[ofnsz] = '}';
  }
  ofname[ofnsz+1] = '\0';

  printf("Processing %s\n",fname);

  /*
   * initialize page and line number
   */

  page = 1;
  line = 0;

  /*
   * begin printing file
   * read and print one line at a time
   */

  zz100:;

  if (line>=50) {
    /*
     * new page
     */
    fprintf(outfile,"\\vfil\\eject\n");
    line = 0;
    page++;
  }

  if (fgets(tmpstr, 256, infile) == NULL) {
  /*
   * input file has been processed
   * add closing TeX statements
   */
    /* printf("\nTeX output file completed\n");
       printf("\nNext step: tex TEX31417\n"); */  
    fprintf(outfile,"\\vfil\\bye\n");

    /*
     * close files
     */

    fclose(infile);
    fclose(outfile);

    sprintf(cmnd,"tex TEX31417");
    system(cmnd);
    sprintf(cmnd,"pdftex TEX31417");
    system(cmnd);
    sprintf(cmnd,"cp TEX31417.pdf %s.pdf",fname);
    system(cmnd);
/*    sprintf(cmnd,
     "evince %s.pdf &",fname);
    system(cmnd); */    
    
    return(0);
  }

  if (strncmp(tmpstr,"/*eject*/",9)==0) {
    /*
     * do not start a new page if line = 0
     */
    if (line == 0) {
      goto zz100;
    }
    /*
     * new page
     */
    fprintf(outfile,"\\vfil\\eject\n");
    line = 0;
    page++;
    goto zz100;
  }

  line++;

  if (tmpstr[strlen(tmpstr)-1]=='\n') {
    tmpstr[strlen(tmpstr)-1]='\0';
  }

  if (line == 1) {
    fprintf(outfile,
      "Page: %d\\ \\ File: %s\\ \\ Date: %s",
      page,ofname,current_time);
    fprintf(outfile,"\\par\\medskip\\medskip\n");
  }

  /*
   * convert line to TeX line
   */

  imax = strlen(tmpstr);

  if (imax == 0) {
    /*
     * have a line without entries
     */
    fprintf(outfile,"\\line{\\hfil}\n");
    goto zz100;
  }

  /*
   * find leading blanks
   */
  for (i = 0;i<=imax-1;i++) {
    if (tmpstr[i]!=' ') {
      lblank = i;
      fprintf(outfile,"\\hskip%dtruemm{}",(5+(lblank)*24)/10);
      goto zz200;
    }
  }
    fprintf(outfile,"\\line{\\hfil}\n");
    goto zz100;  

  zz200:;

  for (i=lblank;i<=imax-1;i++) {

    /*
     * detect special symbols
     */
    if ((tmpstr[i]=='#')||
        (tmpstr[i]=='$')||
        (tmpstr[i]=='%')||
        (tmpstr[i]=='&')||
        (tmpstr[i]=='_')) {
      fprintf(outfile,"\\");
      fprintf(outfile,"%c",tmpstr[i]);
      continue;
    }
    /* left bracket */
    if (tmpstr[i]=='{' ) {
      fprintf(outfile,"\\l ");
      continue;
    }
   /* right bracket */
    if (tmpstr[i]=='}' ) {
      fprintf(outfile,"\\r ");
      continue;
    }
   /* tilde */
    if (tmpstr[i]=='~' ) {
      fprintf(outfile,"\\t ");
      continue;
    }
   /* caret */
    if (tmpstr[i]=='^' ) {
      fprintf(outfile,"\\c ");
      continue;
    }
   /* backslash */
    if (tmpstr[i]=='\\' ) {
      fprintf(outfile,"\\b ");
      continue;
    }
   /* white space (=blank) */
    if (tmpstr[i]==' ' ) {
      fprintf(outfile,"\\w ");
      continue;
    }
   /* punctuation marks */
   /* semicolon */
    if (tmpstr[i]==';' ) {
      fprintf(outfile,"\\s ");
      continue;
    }
   /* colon */
    if (tmpstr[i]==':' ) {
      fprintf(outfile,"\\d ");
      continue;
    }
   /* period */
    if (tmpstr[i]=='.' ) {
      fprintf(outfile,"\\p ");
      continue;
    }
   /* < symbol */
    if (tmpstr[i]=='<' ) {
      fprintf(outfile,"\\e ");
      continue;
    }
   /* comma */
    if (tmpstr[i]==',' ) {
      fprintf(outfile,"\\m ");
      continue;
    }
   /* > symbol */
    if (tmpstr[i]=='>' ) {
      fprintf(outfile,"\\f ");
      continue;
    }
   /* have regular character */   
      fprintf(outfile,"%c",tmpstr[i]);

  }
  fprintf(outfile,"\\par\n");
  goto zz100;

}
