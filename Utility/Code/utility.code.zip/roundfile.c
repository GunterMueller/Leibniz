/* round numbers to whole integers */
# include <stdio.h>
# include <string.h>
# include <stdlib.h>
# include <math.h>
# include <time.h>

/************************************************************
 *  subroutines in this file:
 *    int main program for roundnumber
 *       execution: roundfile <inputfile> <outputfile>
 *         rounds all numbers of form xx.xx or x.xx to 
 *         nearest integer
 *
 *    int roundnumber(char *number)                       
 ************************************************************/
/*eject*/
#define MAXLEN 15000
#define MAX_ENTRY 256

/********* global variables ********/
/* tokens obtained from records */
char token[MAX_ENTRY][MAX_ENTRY];
int nTokens;

/* files */
char inputfile[MAX_ENTRY];
char outputfile[MAX_ENTRY];

FILE *inputfil;
FILE *outputfil;


/* subroutines */
int roundnumber(char *string);
int tokenize(char *lineread);
/*eject*/
int main (int argc, char **argv) {

  int i, j;
  char number[MAX_ENTRY];

  char lineread[MAXLEN];

  if (argc != 3) {
    printf("\n Usage: ./roundfile <inputfile <outputfile> ");
    exit(1);
  }
  strcpy(inputfile,argv[1]);
  strcpy(outputfile,argv[2]);

  /* DEBUG begin: comment out above code involving argc */
  /*              and activate below */
/*
  sprintf(inputfile,"inputroundfile");
  sprintf(outputfile,"outputroundfile");
*/
  /* DEBUG end */
/*eject*/
  if ((inputfil = fopen(inputfile,"r")) == NULL) {
     printf("\n roundfile: cannot open file %s\n",inputfile);
     exit(1);
  }

  if ((outputfil = fopen(outputfile,"w")) == NULL) {
     printf("\n roundfile: cannot open file %s\n",outputfile);
     exit(1);
  }

  while (fgets(lineread,MAXLEN,inputfil) != NULL) {

    /* strip off carriage return and whitespace */
    /* at end of the line */
    i = strlen(lineread) - 1;
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* check if line has nonzero length */
    if (strlen(lineread) < 5) {
      fprintf(outputfil,"%s\n",lineread);
      continue;
    }

    /* scan all strings of 5 consecutive */
    /* characters */
    for (i=0; i<=strlen(lineread)-5; i++) {
      for (j=0; j<=4; j++) {
        number[j] = lineread[i+j];
      }
      number[5] = '\0';

      /* convert number[] if it is a number */    
      if (roundnumber(number) == 0) {
        /* have converted string in number[] */         
        /* to string representing rounded integer */
        /* right-justified, with blanks to left */
        /* LaTeX: insert forced blank if single digit */
        for (j=0; j<=4; j++) {
          lineread[i+j] = number[j];
        }
        /* skip to end of new section in lineread */
        i += 4;
      }
    } /* end for i */

    /* store final lineread[] in outputfile */
    fprintf(outputfil,"%s\n",lineread);

  } /* end while */    

  fclose(inputfil);
  fclose(outputfil);

  return 0;

}
/*eject*/
/*************************************************************
 * int roundnumber(cha* number)
 * convert value in number[] to string with
 * value rounded to integer, inserted right-justified
 * in number[], with blanks filled to left
 *
 * caution: number[] must be " x.xx" or "xx.xx" 
**************************************************************/
int roundnumber(char *number) {

  int i;
  double value;



  for (i=0; i<=4; i++) {
    if ((i == 0) && (number[i] == ' ')) {
      continue;
    }
    if (i == 2) {
      if (number[i] == '.') {
        continue;
      }
      return 1;
    }
    if ((number[i] < 48) ||
       (number[i] > 59)) {
      /* number[i] does not represent an integer digit */
      return 1;
    }              
  }

  value = atof(number);
  i = value + 0.5;
  sprintf(number,"%5d",i);

  return 0;

}
/*eject*/
/*************************************************************
 * int tokenize(char *lineread): extract up to MAX_ENTRY
 * non-white-space strings from lineread[]
 * stops with error if a string has length >= MAX_ENTRY 
 * place strings into token[][];
 * defines nTokens = number of extracted tokens
 * process does not change lineread[]
 ************************************************************/
int tokenize(char *lineread) {

  int i, j;
  char saveread[MAXLEN];
  char *buffer;

  strcpy(saveread,lineread);

  /* strip off carriage return and whitespace */
  /* at end of the line */
  i = strlen(lineread) - 1;
  while (lineread[i]>=1 && lineread[i]<=32) {
    lineread[i] = '\0';
    i--;
  }
/*eject*/
  for (j=0; j<MAX_ENTRY; j++) {

    if (j == 0) {  
      buffer = strtok(saveread," \t\n");
    } else {
      buffer = strtok(NULL," \t\n");
    }

    if (buffer == NULL) {
      break;
    }

    if (strlen(buffer) >= MAX_ENTRY) {
      printf(
        "\n tokenize: lineread = %s contains too-large\n",
        lineread);
      printf(
        "\n token = %s with strlen >= %d \n", 
        buffer, MAX_ENTRY);
      exit(1);
    }

    strcpy(token[j],buffer);

  } /* end for j */

  nTokens = j;

  return nTokens;

}
/************** last record of roundfile.c **************/

