/*  first record of top_sep_dist.c***** */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lsqparms.h"
#include "lsqexts.h"

void top_sep_dist() {

  void lsqerror();
  int top_separation();
  void top_distribution();

  if (lsqscrflg == 1) {
    if ((fortypartialsepflg == 1) &&
        (disprocessflg == 1)) {
      printf("\n\nCompute separations and distributions\n");
    } else {
      printf("\n\nCompute separations\n");
    }
  }

/*
 *  find separations
 */
  top_separation();

/*
 *  find distributions
 */
  if ((fortypartialsepflg == 1) &&
      (disprocessflg == 1)) {
    top_distribution();
  }
  return;

}

/*eject*/
/* ---------------------------------------------------------
 *  top_distribution(): top routine for generating vote
 *  distributions 
 * ---------------------------------------------------------
 */
void top_distribution() {

  void lsqerror();
  char * pathing();
  void remove_work_area();
  void stat_16votes();
  int  stat_covar();
  void stat_distributions();
  int  stat_mu_sig();
  void stat_untrained_vote();

  if (lsqscrflg == 1) {
    printf(" - Compute distributions\n");
  }
     
  stat_untrained_vote();

  if (stat_covar() < 0) {
    printf(
    "\nTraining set is too small to compute distributions\n");
    printf("Condition detected in stat_covar()\n");
    fprintf(errfil,
    "\nTraining set is too small to compute distributions\n");
    fprintf(errfil,"Condition detected in stat_covar()\n");
    lsqerror("top_distribution","102");
  }
  
  stat_16votes();

  if (stat_mu_sig() == -1) {
    printf(
    "\nTraining set is too small to compute distributions\n");
    printf("Condition detected in stat_mu_sig()\n");
    fprintf(errfil,
    "\nTraining set is too small to compute distributions\n");
    fprintf(errfil,"Condition detected in stat_mu_sig()\n");
    lsqerror("top_distribution","202");
  }

  stat_distributions();

  if (lsqscrflg == 1) {
    printf("*** Distributions are in file: \n    %s\n\n", 
           distribution_file);
  }
  return;
  
}

/*eject*/
/* ------------------------------------------------------------
 * int top_separation(): top routine for generating separations
 * ------------------------------------------------------------ 
 */
int top_separation() {

  void compile_log_programs();
  int  compute_separations();
  void generate_record_sets();
  void generate_log_files();
  void lsqerror();
  char * pathing();   

/*
 *  generate record sets and subsets
 */
  if (lsqscrflg == 1) {
    printf(" - Create subsets of input records\n");
  }
  generate_record_sets(); 

/*
 *  generate .log files
 */
  generate_log_files();

/*
 *  compute separations
 */
  if (lsqscrflg == 1) {
    if (fortypartialsepflg == 1) {
      printf(" - Compute separations (10 steps)\n   ");
    }
  }      
  if (compute_separations() != 0) {
    /* error detected during computations */
    lsqerror("top_separation","102");
  }

  if (lsqscrflg == 1) {
    if ((fourtotalsepflg==1) &&
        (optcstsepflg==1)) {
      printf(
       "*** Optimal records/separations are in file:\n    %s\n",
       optimization_file);
    }
    if (((globalfourtotalsepflg==1) &&
         (fourtotalsepflg==1)) ||
        ((globalfortypartialsepflg==1) &&
         (fortypartialsepflg==1))) {
      printf("*** Separations are in file: \n    %s\n\n", 
           separation_file);
    }
  }
  return(0);

}

/*  last record of top_sep_dist.c***** */
