/*  first record of stat_16votes.c***** */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h"

int untrain_rec[max_untrain_size + 1];
int master_rec[separation_num + 1][2 + 1]
              [sub_range_num +1][max_record_num + 1];
int sep_ind;
char s1[namesize],s2[namesize];
FILE *fp;

int  get_A_untrain_total(int);
int  get_B_untrain_total(int);
void get_master_rec();
void get_sub_info();
void lsqerror();
char * pathing();   

/* -----------------------------------------------------------
 *  stat_16votes(): get 16 votes on untrained records
 * -----------------------------------------------------------
 */
void stat_16votes() {

  get_sub_info();
  get_master_rec();
  return;

}

/*eject*/
/* -----------------------------------------------------------
 *  int get_A_untrain_total() : compute total untrain 
 *  for each sub A set
 * -----------------------------------------------------------
 */
int get_A_untrain_total(int k) {

  int i,l,x1,x2,total;

  void remove_work_area();

  total = 0;
  if ((sep_l_a[sep_ind][k][3] == 0) && 
      (sep_l_a[sep_ind][k][4] == 0)) {
    total = sep_l_a[sep_ind][k][2] - 
            sep_l_a[sep_ind][k][1] + 1;
    x1 = sep_l_a[sep_ind][k][1] - 1;
    if (x1 > 0) {
      for ( i = 1 ; i <= x1 ; i++) {
        untrain_rec[i] = i;
      }
    }
    x2 = sep_l_a[sep_ind][10][2] - 
         sep_l_a[sep_ind][k][2];
    if (x2 > 0) {
      l = 1;
      for ( i = 1 ; i <= x2 ; i++) {
        untrain_rec[x1+l] = sep_l_a[sep_ind][k][2] + l;
        l++;
      }
    }
  } else {
    total = sep_l_a[sep_ind][k][4] - 
            sep_l_a[sep_ind][k][3] + 1;
    total = total +  sep_l_a[sep_ind][k][2] - 
            sep_l_a[sep_ind][k][1] + 1;
    x1 = sep_l_a[sep_ind][k][1] - 
         sep_l_a[sep_ind][k][4] -1;
    if (x1 < 0) {
      printf(
       "Error in untrain_records construction.\n");
      fprintf(errfil,
       "Error in untrain_records construction.\n");
      lsqerror("get_A_untrain_total","102");
    } else { 
      l = 1 ;
      for ( i = 1 ; i<= x1 ; i++) {
        untrain_rec[i] = sep_l_a[sep_ind][k][4] + l;
        l++;
      }
    }
  }    
  total = sep_l_a[sep_ind][10][2] - total;
  if (total == 0) {
    printf(
    "\nTraining set is too small to compute distributions\n");
    printf("Condition detected in get_A_untrain_total()\n");
    fprintf(errfil,
    "\nTraining set is too small to compute distributions\n");
    fprintf(errfil,
    "Condition detected in get_A_untrain_total()\n");
    lsqerror("get_A_untrain_total","202");
    exit(1); /* added to suppress compiler warning */
  } else {
   return total;
  }

}
      
/*eject*/
/* -----------------------------------------------------------
 *  int get_B_untrain_total(int k) : compute total untrain 
 *  for each sub B set.
 * -----------------------------------------------------------
 */
int get_B_untrain_total(int k) {
  int i,l,x1,x2,total;

  void remove_work_area();

  total = 0;
  if ((sep_l_b[sep_ind][k][3] == 0) && 
      (sep_l_b[sep_ind][k][4] == 0)) {
    total = sep_l_b[sep_ind][k][2] - 
            sep_l_b[sep_ind][k][1] + 1;
    x1 = sep_l_b[sep_ind][k][1] - 1;
    if ( x1 > 0) {
      for (i=1;i<= x1;i++)
      untrain_rec[i] = i;
    }
    x2 = sep_l_b[sep_ind][10][2] - 
         sep_l_b[sep_ind][k][2];
    if (x2 > 0) {
      l = 1;
      for (i=1;i<=x2;i++) {
        untrain_rec[x1+l] = sep_l_b[sep_ind][k][2] + l;
        l++;
      }
    }
  } else {
    total = sep_l_b[sep_ind][k][4] - 
            sep_l_b[sep_ind][k][3] + 1;
    total = total +  sep_l_b[sep_ind][k][2] - 
            sep_l_b[sep_ind][k][1] + 1;
    x1 = sep_l_b[sep_ind][k][1] - 
         sep_l_b[sep_ind][k][4] -1;
    if (x1 < 0) {
      printf(
       "Error in untrain_records construction.\n");
      fprintf(errfil,
       "Error in untrain_records construction.\n");
      lsqerror("get_B_untrain_total","102");
    } else { 
      l = 1 ;
      for (i=1;i<=x1;i++) {
        untrain_rec[i] = sep_l_b[sep_ind][k][4] + l;
        l++;
      }
    }
  }    
  total = sep_l_b[sep_ind][10][2] - total;
  if (total == 0) {
    printf(
    "\nTraining set is too small to compute distributions\n");
    printf("Condition detected in get_B_untrain_total()\n");
    fprintf(errfil,
    "\nTraining set is too small to compute distributions\n");
    fprintf(errfil,
    "Condition detected in get_B_untrain_total()\n");
    lsqerror("get_A_untrain_total","202");
    exit(1); /* added to suppress compiler warning */
  } else {
    return total;
  }

}

/*eject*/
/* -----------------------------------------------------------
 *  void get_master_rec(): read the untrain votes file
 *  master_rec.data, compute 16 vote results, and output
 *  these results in files
 *    A_sixteenvote_sepid.data 
 *    B_sixteenvote_sepid.data
 * -----------------------------------------------------------
 */
void get_master_rec() { 
  int i,j,k,l,x,i_num,untrain_total;
  int  A_sixteenvote[3+1][max_record_num+1];
  int  B_sixteenvote[3+1][max_record_num+1];
  char s1[namesize];
  FILE *f1;

  for(j=1;j<=3;j++) {
    for(i=1;i<=row_count;i++) {
      A_sixteenvote[j][i] = 0;
    }
    for(i=1;i<=row_count;i++) {
      B_sixteenvote[j][i] = 0;
    }
  } 

  for(k=0;k<=separation_num;k++) {
    for(l=0;l<=2;l++) {
      for(i=0;i<=sub_range_num;i++) {
        for(j=0;j<=max_untrain_size;j++) {
              master_rec[k][l][i][j] = 0;
        }
      }
    }
  }
  sprintf(s1,"master_rec.data");
  if ((f1 = fopen(pathing(s1),"r")) == NULL) {
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("get_master_rec","102");
  }
  for (k=1;k<=separation_num;k++) {
    sep_ind = k;
    for (l=1;l<=2;l++) {
      for (i=1;i<=sub_range_num;i++) {
        if (l == 1) {
          untrain_total = get_A_untrain_total(i);
        } else {
          untrain_total = get_B_untrain_total(i);
        }
        for (j = 1;j<=untrain_total;j++) {
          fscanf(f1,"%d",&i_num);
          fscanf(f1,"%d",&i_num);
          fscanf(f1,"%d",&i_num);
          fscanf(f1,"%d",&x);
          fscanf(f1,"%d",&i_num);
          master_rec[k][l][i][x] = i_num;
          if (l == 1) {
            A_sixteenvote[k][x] = A_sixteenvote[k][x] + i_num;
          } else if ( l == 2) {
            B_sixteenvote[k][x] = B_sixteenvote[k][x] + i_num;
          }
        }
      }
    }
  }
  fclose(f1);

  for (j=1;j<=separation_num;j++) {
    sprintf(s1,"A_sixteenvote_sep%d.data",j);
    if ((f1 = fopen(pathing(s1),"w")) == NULL) {
      printf("Cannot open file %s\n",s1);
      fprintf(errfil,"Cannot open file %s\n",s1);
      lsqerror("get_master_rec","202");
    }
    for (i=1;i<= row_count;i++)
        fprintf(f1,"%3d %3d\n",i,A_sixteenvote[j][i]);
    fclose(f1);
    sprintf(s1,"B_sixteenvote_sep%d.data",j);
    if ((f1 = fopen(pathing(s1),"w")) == NULL) {
      printf("Cannot open file %s\n",s1);
      fprintf(errfil,"Cannot open file %s\n",s1);
      lsqerror("get_master_rec","204");
    }
    for (i=1;i<=row_count;i++) {
        fprintf(f1,"%3d %3d\n",i,B_sixteenvote[j][i]);
    }
    fclose(f1);
  }
  return;

}

/*  last record of stat_16votes.c***** */
