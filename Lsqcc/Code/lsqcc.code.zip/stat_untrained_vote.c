/*  first record of stat_untrained_vote.c***** */
#include <stdio.h>
#include <string.h>
#include "lsqparms.h"
#include "lsqexts.h"

int BA_smin[separation_num + 1][sub_range_num+1]
           [sep_set_size+1][max_column_size + 1];
int BA_smax[separation_num + 1][sub_range_num+1]
           [sep_set_size+1][max_column_size + 1];
int AB_smin[separation_num + 1][sub_range_num+1]
           [sep_set_size+1][max_column_size + 1];
int AB_smax[separation_num + 1][sub_range_num+1]
           [sep_set_size+1][max_column_size + 1];
int BA_smin_sep_set_size[separation_num + 1][sub_range_num+1];
int BA_smax_sep_set_size[separation_num + 1][sub_range_num+1];
int AB_smin_sep_set_size[separation_num + 1][sub_range_num+1];
int AB_smax_sep_set_size[separation_num + 1][sub_range_num+1];
int test_data[max_record_num + 1][max_column_size + 1];
char s1[namesize],s2[namesize];
FILE *fp;

void collect_votes();
void get_sep_set();
int  get_A_log_data();
int  get_B_log_data();
void get_sub_info();
void lsqerror();
void separate_b2(int,int);
char *pathing();   

/* ----------------------------------------------------
 *  stat_untrained_vote(): compute votes for records
 *  not used in training
 * ----------------------------------------------------
 */
void stat_untrained_vote() {
  
  get_sep_set();
  get_sub_info();
  collect_votes();
  return;

}
/* -----------------------------------------------------
 *  collect_votes(): compute votes for all records and
 *  all separations, and collect in file master_rec.data
 * -----------------------------------------------------
 */
void collect_votes() {

  int  i,j,l,t,subS,row_num;
  int  BA_smin_in_AB;
  int  BA_smax_in_AB;
  int  AB_smin_in_AB;
  int  AB_smax_in_AB;
  char s1[namesize];

  FILE *f1;

  void lsqerror();

  BA_smin_in_AB = 0; /* to suppress compiler warning message */
  BA_smax_in_AB = 0; /* to suppress compiler warning message */
  AB_smin_in_AB = 0; /* to suppress compiler warning message */
  AB_smax_in_AB = 0; /* to suppress compiler warning message */ 
  
  sprintf(s1,"master_rec.data");
  if ((f1 = fopen(pathing(s1),"w")) == NULL) {
    printf("\nCannot open file %s\n",s1);
    fprintf(errfil,"\nCannot open file %s\n",s1); 
    lsqerror("collect_votes","102");
  }

  for (l = 1 ; l <= separation_num ; l++) {
    row_num = get_A_log_data(l);
    for ( subS = 1; subS <= 10 ; subS++) {
      for (t = sep_l_a[l][subS][2]+1; 
           t<= sep_l_a[l][10][2] ; t++) { 
        for (i = 1; i <= BA_smin_sep_set_size[l][subS];i++) {
          BA_smin_in_AB = -1;    
          for (j = 1; j <= col_count; j++) {
            if (((BA_smin[l][subS][i][j] == 1) && 
                 (test_data[t][j] != 1)) ||
                ((BA_smin[l][subS][i][j] == -1) && 
                 (test_data[t][j] != -1))) {
               BA_smin_in_AB = 1;
               break;
            }
          }                   
          if (BA_smin_in_AB == -1) {
            break;
          }
        }
        for (i = 1; i <= BA_smax_sep_set_size[l][subS];i++) {
          BA_smax_in_AB = -1;    
          for (j = 1; j <= col_count; j++) {
            if (((BA_smax[l][subS][i][j] == 1) && 
                 (test_data[t][j] != 1)) ||
                ((BA_smax[l][subS][i][j] == -1) && 
                 (test_data[t][j] != -1))) {
              BA_smax_in_AB = 1;
              break;
            }
          }                   
          if (BA_smax_in_AB == -1) {
            break;
          }
        }
        for (i = 1; i <= AB_smin_sep_set_size[l][subS];i++) {
          AB_smin_in_AB = 1;    
          for (j = 1; j <= col_count; j++) {
            if (((AB_smin[l][subS][i][j] == 1) && 
                 (test_data[t][j] != 1)) ||
                ((AB_smin[l][subS][i][j] == -1) && 
                 (test_data[t][j] != -1))) {
                              AB_smin_in_AB = -1;
                              break;
            }
          }                   
          if (AB_smin_in_AB == 1) {
            break;
          }
        }
        for (i = 1;i <= AB_smax_sep_set_size[l][subS];i++) {
          AB_smax_in_AB = 1;    
          for (j = 1; j <= col_count; j++) {
            if (((AB_smax[l][subS][i][j] == 1) && 
                 (test_data[t][j] != 1)) ||
                ((AB_smax[l][subS][i][j] == -1) && 
                 (test_data[t][j] != -1))) {
              AB_smax_in_AB = -1;
              break;
            }
          }                   
          if (AB_smax_in_AB == 1) {
            break;
          }
        }
        fprintf(f1,"%3d %3d %3d %3d %3d\n",
                l,1,subS,t,(BA_smin_in_AB +
                BA_smax_in_AB + AB_smin_in_AB + AB_smax_in_AB));
      }

      for (t = sep_l_a[l][subS][4]+1; 
           t<= sep_l_a[l][subS][1]-1 ; t++) {
        for (i = 1;i <= BA_smin_sep_set_size[l][subS];i++) {
          BA_smin_in_AB = -1;
          for (j = 1;j <= col_count;j++) {
            if (((BA_smin[l][subS][i][j] == 1) &&
                 (test_data[t][j] != 1)) ||
                ((BA_smin[l][subS][i][j] == -1) &&
                 (test_data[t][j] != -1))) {
               BA_smin_in_AB = 1;
               break;
            }
          }
          if (BA_smin_in_AB == -1) {
            break;
          }
        }
        for (i = 1;i <= BA_smax_sep_set_size[l][subS];i++) {
          BA_smax_in_AB = -1;
          for (j = 1;j <= col_count;j++) {
            if (((BA_smax[l][subS][i][j] == 1) &&
                 (test_data[t][j] != 1)) ||
                ((BA_smax[l][subS][i][j] == -1) &&
                 (test_data[t][j] != -1))) { 
              BA_smax_in_AB = 1;
              break;
            }
          }
          if (BA_smax_in_AB == -1) {
            break;
          }
        }
        for (i = 1;i <= AB_smin_sep_set_size[l][subS];i++) {
          AB_smin_in_AB = 1;
          for (j = 1;j <= col_count;j++) {
            if (((AB_smin[l][subS][i][j] == 1) &&
                 (test_data[t][j] != 1)) ||
                ((AB_smin[l][subS][i][j] == -1) &&
                 (test_data[t][j] != -1))) {
              AB_smin_in_AB = -1;
              break;
            }
          }
          if (AB_smin_in_AB == 1) {
            break;
          }
        }
        for (i = 1;i <= AB_smax_sep_set_size[l][subS];i++) {
          AB_smax_in_AB = 1;
          for (j = 1;j <= col_count;j++) {
            if (((AB_smax[l][subS][i][j] == 1) &&
                 (test_data[t][j] != 1)) ||
                ((AB_smax[l][subS][i][j] == -1) &&
                 (test_data[t][j] != -1))) {
              AB_smax_in_AB = -1;
              break;
            }
          }
          if (AB_smax_in_AB == 1) {
            break;
          }
        }
        fprintf(f1,"%3d %3d %3d %3d %3d\n",
            l,1,subS,t,(BA_smin_in_AB \
            + BA_smax_in_AB + AB_smin_in_AB + AB_smax_in_AB));
      }
      fprintf(f1,"\n");
    }
    fprintf(f1,"\n\n");
    
    row_num = get_B_log_data(l);
    for ( subS = 1; subS <= 10 ; subS++) {
      for (t = sep_l_b[l][subS][2]+1;t<= sep_l_b[l][10][2];t++) { 
        for (i = 1;i <= BA_smin_sep_set_size[l][subS];i++) {
          BA_smin_in_AB = -1;    
          for (j = 1;j <= col_count;j++) {
            if (((BA_smin[l][subS][i][j] == 1) && 
                 (test_data[t][j] != 1)) ||
                ((BA_smin[l][subS][i][j] == -1) && 
                 (test_data[t][j] != -1))) {
              BA_smin_in_AB = 1;
              break;
            }
          }                   
          if (BA_smin_in_AB == -1) {
            break;
          }
        }
        for (i = 1;i <= BA_smax_sep_set_size[l][subS];i++) {
          BA_smax_in_AB = -1;    
          for (j = 1;j <= col_count;j++) {
            if (((BA_smax[l][subS][i][j] == 1) && 
                 (test_data[t][j] != 1)) ||
                ((BA_smax[l][subS][i][j] == -1) && 
                 (test_data[t][j] != -1))) {
              BA_smax_in_AB = 1;
              break;
            }
          }                   
          if (BA_smax_in_AB == -1) {
            break;
          }
        }
        for (i = 1;i <= AB_smin_sep_set_size[l][subS];i++) {
          AB_smin_in_AB = 1;    
          for (j = 1;j <= col_count;j++) {
            if (((AB_smin[l][subS][i][j] == 1) && 
                 (test_data[t][j] != 1)) ||
                ((AB_smin[l][subS][i][j] == -1) && 
                 (test_data[t][j] != -1))) {
              AB_smin_in_AB = -1;
              break;
            }
          }                   
          if (AB_smin_in_AB == 1) {
            break;
          }
        }
        for (i = 1;i <= AB_smax_sep_set_size[l][subS];i++) {
          AB_smax_in_AB = 1;    
          for (j = 1;j <= col_count;j++) {
            if (((AB_smax[l][subS][i][j] == 1) && 
                 (test_data[t][j] != 1)) ||
                ((AB_smax[l][subS][i][j] == -1) && 
                 (test_data[t][j] != -1))) {
              AB_smax_in_AB = -1;
              break;
            }
          }                   
          if (AB_smax_in_AB == 1) {
            break;
          }
        }
        fprintf(f1,"%3d %3d %3d %3d %3d\n",
             l,2,subS,t,-(BA_smin_in_AB +\
             BA_smax_in_AB + AB_smin_in_AB + AB_smax_in_AB));
      }

      for (t = sep_l_b[l][subS][4]+1;
           t<= sep_l_b[l][subS][1]-1;t++) {
        for (i = 1;i <= BA_smin_sep_set_size[l][subS];i++) {
          BA_smin_in_AB = -1;
          for (j = 1;j <= col_count;j++) {
            if (((BA_smin[l][subS][i][j] == 1) &&
                 (test_data[t][j] != 1)) ||
                ((BA_smin[l][subS][i][j] == -1) &&
                 (test_data[t][j] != -1))) {
              BA_smin_in_AB = 1;
              break;
            }
          }
          if (BA_smin_in_AB == -1) {
            break;
          }
        }
        for (i = 1;i <= BA_smax_sep_set_size[l][subS];i++) {
          BA_smax_in_AB = -1;
          for (j = 1;j <= col_count;j++) {
            if (((BA_smax[l][subS][i][j] == 1) &&
                 (test_data[t][j] != 1)) ||
                ((BA_smax[l][subS][i][j] == -1) &&
                 (test_data[t][j] != -1))) {
              BA_smax_in_AB = 1;
              break;
            }
          }
          if (BA_smax_in_AB == -1) {
            break;
          }
        }
        for (i = 1;i <= AB_smin_sep_set_size[l][subS];i++) {
          AB_smin_in_AB = 1;
          for (j = 1;j <= col_count;j++) {
            if (((AB_smin[l][subS][i][j] == 1) &&
                 (test_data[t][j] != 1)) ||
                ((AB_smin[l][subS][i][j] == -1) &&
                 (test_data[t][j] != -1))) {
              AB_smin_in_AB = -1;
              break;
            }
          }
         if (AB_smin_in_AB == 1) {
           break;
         }
      }
      for (i = 1;i <= AB_smax_sep_set_size[l][subS];i++) {
        AB_smax_in_AB = 1;
        for (j = 1;j <= col_count;j++) {
          if (((AB_smax[l][subS][i][j] == 1) &&
               (test_data[t][j] != 1)) ||
              ((AB_smax[l][subS][i][j] == -1) &&
               (test_data[t][j] != -1))) {
            AB_smax_in_AB = -1;
            break;
          }
        }
        if (AB_smax_in_AB == 1) {
          break;
        }
      }
      fprintf(f1,"%3d %3d %3d %3d %3d\n",
          l,2,subS,t,-(BA_smin_in_AB \
          + BA_smax_in_AB + AB_smin_in_AB + AB_smax_in_AB));
      }
    fprintf(f1,"\n");
    }
    fprintf(f1,"\n\n");
  }
  fclose(f1);
  return;
 
}

/*eject*/
/* --------------------------------------------------
 *  get_A_log_data(): get A log.data from file
 *  AiB_A_log.data and store in array test_data[i][j]
 * --------------------------------------------------
 */
int  get_A_log_data(int sep_ind) {

  int i,j,i_num,row_num,col_num;
  char s1[namesize];

  FILE *f1;

  sprintf(s1,"A%dB_A_log.data",sep_ind);
  if ((f1 = fopen(pathing(s1),"r")) == NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("get_A_log_data","102");
  }
  fscanf(f1,"%d",&row_num);
  fscanf(f1,"%d",&col_num);
  for (i = 1;i <= row_num;i++){
/* 
 * skip over external and internal record index 
 */
    fscanf(f1,"%d",&i_num);
    fscanf(f1,"%d",&i_num);
/* 
 * read record into test_data 
 */
    for (j = 1;j <= col_num;j++){
      fscanf(f1,"%d",&i_num);
      test_data[i][j] = i_num;
    }
  }
  fclose(f1);
  return row_num;

}

/*eject*/
/* --------------------------------------------------
 *  get_B_log_data(): get B log.data from file
 *  AiB_A_log.data and store in array test_data[i][j]
 * --------------------------------------------------
 */
int get_B_log_data(int sep_ind) {

  int i,j,row_num,col_num,i_num;
  char s1[namesize];

  FILE *f1;

  sprintf(s1,"A%dB_B_log.data",sep_ind);
  if ((f1 = fopen(pathing(s1),"r")) == NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("get_B_log_data","102");
  }
  fscanf(f1,"%d",&row_num);
  fscanf(f1,"%d",&col_num);
  for (i = 1;i <= row_num;i++){
/* 
 * skip over external and internal record index 
 */
    fscanf(f1,"%d",&i_num);
    fscanf(f1,"%d",&i_num);
/* 
 * read record into test_data 
 */
    for (j = 1;j <= col_num;j++){
      fscanf(f1,"%d",&i_num);
      test_data[i][j] = i_num;
    }
  }
  fclose(f1);
  return row_num;

}

/*eject*/
/* -----------------------------------------------------------
 *  void get_sep_set(): get separations from file
 *  sep_vectors_file and store in arrays 
 *    BA_smin[i][j][k][l]
 *    BA_smax[i][j][k][l]
 *    AB_smin[i][j][k][l]
 *    AB_smax[i][j][k][l]
 * -----------------------------------------------------------
 */
void get_sep_set() {

  int i,j,k,l,i_num,set_size;
  char s1[namesize];

  FILE *f1;

  if ((f1 = fopen(pathing("sep_vectors_file"),"r")) == NULL) {
    printf("Cannot open file sep_vectors_file\n");
    fprintf(errfil,"Cannot open file sep_vectors_file\n");
    lsqerror("get_sep_set","102");
  }
  for (i = 1;i <= separation_num;i++ ) {
    for (j = 1;j <= sub_range_num;j++) {

      fscanf(f1,"%s",s1);   
      fscanf(f1,"%d",&set_size);
      BA_smin_sep_set_size[i][j] = set_size;
      for (k = 1;k <= set_size;k++) {
        for (l = 1;l <= col_count;l++) {
          fscanf(f1,"%d",&i_num);
          BA_smin[i][j][k][l] = i_num;
        }
      }

      fscanf(f1,"%s",s1);   
      fscanf(f1,"%d",&set_size);
      BA_smax_sep_set_size[i][j] = set_size;
      for (k = 1;k <= set_size;k++) {
        for (l = 1;l <= col_count;l++) {
          fscanf(f1,"%d",&i_num);
          BA_smax[i][j][k][l] = i_num;
        }
      }  
    
      fscanf(f1,"%s",s1);   
      fscanf(f1,"%d",&set_size);
      AB_smin_sep_set_size[i][j] = set_size;
      for (k = 1;k <= set_size;k++) {
        for (l = 1;l <= col_count;l++) {
          fscanf(f1,"%d",&i_num);
          AB_smin[i][j][k][l] = i_num;
        }
      }

      fscanf(f1,"%s",s1);   
      fscanf(f1,"%d",&set_size);
      AB_smax_sep_set_size[i][j] = set_size;
      for (k = 1;k <= set_size;k++) {
        for (l = 1;l <= col_count;l++) {
          fscanf(f1,"%d",&i_num);
          AB_smax[i][j][k][l] = i_num;
        }
      }   
    }
  }
  fclose(f1);
  return;
 
}

/*eject*/
/* -------------------------------------------------
 *  get_sub_info(): get subrange control information
 *  from files
 *    AiB_Asubrange.cnl
 *    AiB_Bsubrange.cnl
 *  and store in arrays
 *    sep_l_a[i][j][k]
 *    sep_l_b[i][j][k] 
 * -------------------------------------------------
 */
void get_sub_info() {

  int i,j,k,i_num;
  char s1[namesize];
  char s2[namesize];

  FILE *f1,*f2;

  for (i = 1;i <= separation_num;i++) {
    strcpy(s1,"A");
    sprintf(s2,"%d",i);
    strcat(s1,s2);
    strcat(s1,"B_Asubrange.cnl");
    if ((f1 = fopen(pathing(s1),"r")) == NULL) {
      printf("Cannot open file %s\n",s1);
      fprintf(errfil,"Cannot open file %s\n",s1);
      lsqerror("get_sub_info","102");
    } 
    strcpy(s1,"A");
    sprintf(s2,"%d",i);
    strcat(s1,s2);
    strcat(s1,"B_Bsubrange.cnl");
    if ((f2 = fopen(pathing(s1),"r")) == NULL){
      printf("Cannot open file %s\n",s1);
      fprintf(errfil,"Cannot open file %s\n",s1);
      lsqerror("get_sub_info","202");
    }   
    for (j = 1;j <= sub_range_num;j++){
      for (k = 1;k <= 4;k++) {
        fscanf(f1,"%d",&i_num);
        sep_l_a[i][j][k] = i_num;
        fscanf(f2,"%d",&i_num);
        sep_l_b[i][j][k] = i_num;
      }
    }
    fclose(f1);
    fclose(f2);
  }
  return;

}

/*eject*/
/* --------------------------------------------------------
 *  separate_b(): compute and output votes (debugging only) 
 * --------------------------------------------------------
 */
void separate_b2(int row_num, int sep_ind) {

  int  in_A,in_B; 
  int  i,j,k,l;
  int  subS,A_count,B_count;

  in_A = 0; /* to suppress compiler warning message */
  in_B = 0; /* to suppress compiler warning message */

  l = sep_ind;
  for (k = 1;k <= row_num;k++) {                
    A_count = 0;
    for (subS = 1;subS <= 10;subS++) {
      for ( i = 1; i <= BA_smin_sep_set_size[l][subS]; i++){
        in_A = LSQFALSE;    
        for (j = 1;j <= col_count;j++){
          if (((BA_smin[l][subS][i][j] == 1) && 
               (test_data[k][j] != 1)) ||
              ((BA_smin[l][subS][i][j] == -1) && 
               (test_data[k][j] != -1))){
            in_A = LSQTRUE;
            break;
          }
        }                   
        if (in_A == LSQFALSE) {
          break;
        }
      }
      if (in_A == LSQTRUE) {   
        A_count = A_count + 1;
      }
    }
    for (subS = 1; subS <= 10;subS++){
      for (i = 1;i <= BA_smax_sep_set_size[l][subS];i++) {
        in_A = LSQFALSE;    
        for ( j = 1; j <= col_count; j++){
          if (((BA_smax[l][subS][i][j] == 1) && 
               (test_data[k][j] != 1)) ||
              ((BA_smax[l][subS][i][j] == -1) && 
               (test_data[k][j] != -1))) { 
            in_A = LSQTRUE;
            break;
          }
        }                   
        if (in_A == LSQFALSE) {
          break;
        }
      }
      if (in_A == LSQTRUE) {
        A_count = A_count + 1;
      }
    }
         
         
    B_count = 0;
    for (subS = 1;subS <= 10;subS++){
      for (i = 1;i <= AB_smin_sep_set_size[l][subS];i++){
        in_B = LSQFALSE;    
        for ( j = 1; j <= col_count; j++){
          if (((AB_smin[l][subS][i][j] == 1) && 
               (test_data[k][j] != 1)) ||
              ((AB_smin[l][subS][i][j] == -1) && 
               (test_data[k][j] != -1))){
            in_B = LSQTRUE;
            break;
          }
        }                   
        if (in_B == LSQFALSE) {
          break;
        }
      }
      if (in_B == LSQTRUE){
        B_count = B_count + 1;
      }
    }
    for (subS = 1;subS <= 10;subS++){
      for ( i = 1; i <= AB_smax_sep_set_size[l][subS]; i++){
        in_B = LSQFALSE;    
        for ( j = 1; j <= col_count; j++){
          if (((AB_smax[l][subS][i][j] == 1) && 
               (test_data[k][j] != 1)) ||
              ((AB_smax[l][subS][i][j] == -1) && 
               (test_data[k][j] != -1))){
            in_B = LSQTRUE;
            break;
         }
       }                   
       if (in_B == LSQFALSE) {
         break;
       }
     }
     if (in_B == LSQTRUE){
       B_count = B_count + 1;
     }
   }

   if (A_count + (20 - B_count )>= maj_count) {
     printf("s%2d put r%3d in A, vote = %d, A = %2d, B = %2d.\n",\
             l,k,(A_count+20-B_count),A_count,B_count);
   } else {
     printf("s%2d put r%3d in B, vote = %d, A = %2d, B = %2d.\n",\
             l,k,(20 - A_count + B_count),A_count,B_count);
   }
 }
 printf("\n");
 return;

}
/*  last record of stat_untrained_vote.c***** */
