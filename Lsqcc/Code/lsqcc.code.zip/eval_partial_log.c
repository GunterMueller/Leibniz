/*  first record of eval_partial_log.c***** */
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include "lsqparms.h"
#include "lsqexts.h"

void compile_partial_prg();
void get_log_name_list();
void lsqerror();
void lsqexit();

char * pathing();

/* --------------------------------------------------
 * eval_partial_log(): evaluates partial logic definitions
 * of training file
 * creates partial_log_file in workarea
 * defines log_name_list[][]
 * --------------------------------------------------
 */
void eval_partial_log() {

  if (lsqscrflg == 1) {
    printf(
       "Check logic definitions by compiling logic portion\n");
  }
  compile_partial_prg();
  get_log_name_list();    
  return;

}

/*eject*/
/* ----------------------------------------------------
 *  compile_partial_prg(): compile partial log definitions
 *  of training file
 * ----------------------------------------------------
 */
void compile_partial_prg() {

  #include "leibnizmacro.h"

  int j,m,n;

  FILE *f1;

/*
 *  create leibnizparams.dat file
 */  
  if ((f1 = fopen(pathing("leibnizparams.dat"),"w")) == NULL) {
    printf("\nCannot open leibnizparams.dat");
    fprintf(errfil,"\nCannot open leibnizparams.dat");
    lsqerror("compile_partial_prg","102");
  }

/*
 *  assemble essential part of leibnizparams.dat
 *  CAUTION: do not change time bound for approximate
 *           minimization from 0 to a positive value 
 *           since this may slow down compilation
 *           and execution
 */
  if (lsqscrflg == 1) {
    fprintf(f1,"show steps on screen\n");
  }
  fprintf(f1,"input file = %s\n",training_file_wo_dir);
  fprintf(f1,"input directory = %s\n",lsqtraindir);
  fprintf(f1,"logic file extension (default: log) = %s\n",
              trnext_nodot);
  fprintf(f1,
    "compile process (normal, fast, very fast) = version 2\n");
  fprintf(f1,
    "use approximate minimization if time bound (sec) >= 0\n");
  fprintf(f1,
    "keep all variables even if not used in any fact\n");
  fprintf(f1,
    "write condensed input into file = %s\n",
    pathing("partial_log_file"));
  fprintf(f1,
	  "begin condensed input keyword = SETS\n");
  fprintf(f1,
	  "end condensed input keyword = ENDATA\n");
  fprintf(f1,"ENDATA\n");
  fclose(f1);

/*  
 *  execute lbcc compiler
 */
  strcpy(name,lsqworkarea);
  execute_lbcc();
  if (errcde[0] != 0) {
    printf(
      "Errors detected during compilation of logic part\n");
    printf(
      "See lsqcc.err for details\nStop\n");
    fprintf(errfil,
      "Errors detected during compilation of logic part\n");
    fprintf(errfil,
      "See lsqcc.err for details\nStop\n");
    lsqexit(1);
  }
/*
 *  check satisfiability of compiled program
 */
  strcpy(type,"SAT");  
  modify_problem();
  if (errcde[0] != 0) {
    lsqerror("compile_partial_prg","302");
  }
  solve_problem();
  if (errcde[0] != 0) {
    lsqerror("compile_partial_prg","304");
  }
  if (strcmp(state,"U") == 0) {
    printf(
      "Clauses of logic portion are not satisfiable\n");
    printf(
      "Must correct clauses\nStop\n");
    fprintf(errfil,
      "Clauses of logic portion are not satisfiable\n");
    fprintf(errfil,
      "Must correct clauses\nStop\n");
    lsqexit(1);
  } else {
    if (lsqscrflg == 1) {
      printf(
      "Clauses of logic portion are satisfiable\n");
      printf(
      "Predicate instances with 'pos' and 'neg' arguments:\n");
      fprintf(errfil,
      "Clauses of logic portion are satisfiable\n");
      fprintf(errfil,
      "Predicate instances with 'pos' and 'neg' arguments:\n");
    }
  }
/*
 *  initialize triviallogflg = 1
 */
  triviallogflg = 1;
/*
 *  reset triviallogflg = 0 if it is discovered that
 *  a variable ending with "pos)" or "neg)" has literals
 *  in the partial logic formulation 
 */
  status_problem();
  if (errcde[0] != 0) {
    lsqerror("compile_partial_prg","312");
  }
/*
 *  value[0] = number of variables
 */
  n = value[0];
  for (j=1;j<=n;j++) {
    value[0] = j;
    status_variable();
    if (errcde[0] != 0) {
      lsqerror("compile_partial_prg","314");
    }
/*
 *  value[5] = number of literals of variable
 */
    m = strlen(name);
    if ((value[5] > 0) &&
        (m >= 6)) {
      if ((strcmp(&name[m-4],"pos)")==0) ||
	  (strcmp(&name[m-4],"neg)")==0)) {
	triviallogflg = 0;
        break;
      }
    }
  }
/*
 *  reset for minimization
 */
  strcpy(type,"MIN");  
  modify_problem();
  if (errcde[0] != 0) {
    lsqerror("compile_partial_prg","402");
  }

  return;

}

/*eject*/
/* ----------------------------------------------------
 *  get_log_name_list(): get names of logic variables,
 *  place into log_name_list[][]
 *  also determine pos_name_idx[], neg_name_idx[]
 * ----------------------------------------------------
 */
void get_log_name_list() {

  #include "leibnizmacro.h" 

  int aflg,flg,i,j,k,nlist,ntot;

  char pos_name[58+1];
  char neg_name[58+1];

/*
 *  initialize number of log names in list
 */
  nlist = 0;

/*
 *  get total number of logic variables in 
 *  partial logic definitions
 */
  status_problem();
  if (errcde[0] != 0) {
    lsqerror("get_log_name_list","102");
  }
  ntot = value[0];

/*
 *  get variables names and extract logic names for list
 */
  for (i=1;i<=ntot;i++) {
    value[0] = i;
    status_variable();
    if (errcde[0] != 0) {
      lsqerror("get_log_name_list","202");
    }

/*
 *  check if this is a candidate name
 */
    if (strlen(name) >= 6) {
      if ((strcmp(&name[strlen(name)-5],"(pos)") == 0) ||
          (strcmp(&name[strlen(name)-5],",pos)") == 0)) {
/*  
 *  increment nlist
 */
        nlist++;
        if (nlist > max_column_size) {
          k = max_column_size;
          printf(
          "Too many logic variables defined by predicates\n");
          printf(
          "Limit is %d\nStop\n",k);
          fprintf(errfil,
          "Too many logic variables defined by predicates\n");
          fprintf(errfil,
          "Limit is %d\nStop\n",k);
          lsqexit(1);
        }
/*
 *  store pos_name, pos_name_idx[], pos_name_list[][],
 *  log_name_list[][], pos_var_cst[], neg_var_cst[]
 */
        strcpy(pos_name,name);
        pos_name_idx[nlist] = i;
        strcpy(&pos_name_list[nlist][0],pos_name);
        strcpy(&log_name_list[nlist][0],pos_name);
        pos_var_cst[nlist] = value[2];
        j = strlen(pos_name) - 5;
        if (log_name_list[nlist][j] == ',') {
          strcpy(&log_name_list[nlist][j],")");
        } else {
          strcpy(&log_name_list[nlist][j],"");
        }
/*
 *  store ASSIGNFALSE option if present
 */
        if (strcmp(&type[2],"AF") == 0) {
          aflg = 1;  
        } else {
          aflg = 0;
        }
/*
 *  convert pos_name to neg case
 */
        strcpy(neg_name,pos_name);
        strcpy(&neg_name[strlen(neg_name)-4],"neg)");
        flg = 0;
        if (lsqscrflg == 1) {
          printf("  %s\n  %s\n",pos_name,neg_name);
        }
        fprintf(errfil,"  %s\n  %s\n",pos_name,neg_name);
/*
 *  search for neg_name
 */
        for (j=1;j<=ntot;j++) {
          value[0] = j;
          status_variable();
          if (errcde[0] != 0) {
            lsqerror("get_log_name_list","202");
          }
          if (strcmp(neg_name,name) == 0) {
/*
 *  have a matching name
 */
            flg = 1;
/*
 *  store neg_name_idx[], neg_name_list[][],
 *  and process ASSIGNFALSE if present
 */
            neg_name_idx[nlist] = j;
            neg_var_cst[nlist] = value[2];
            strcpy(&neg_name_list[nlist][0],neg_name);
            if  (strcmp(&type[2],"AF") == 0) {
              aflg++;
            }

            if (aflg == 2) {
/*
 *  have ASSIGNFALSE for both 'pos' and 'neg' case
 *  for nestedness checking, consider the variable deleted
 */
              delete_var[nlist] = 1;              
            } else {
              delete_var[nlist] = 0;
            }
            break;
          } 
        }
/*
 *  neg name corresponding to pos name does not exist
 */
        if (flg == 0) {
          printf(
           "Have logic variable %s but no\n",pos_name);
          printf(
           "corresponding variable %s\nStop\n",neg_name);
          fprintf(errfil,
           "Have logic variable %s but no\n",pos_name);
          fprintf(errfil,
           "corresponding variable %s\nStop\n",neg_name);
          lsqexit(1);
        }
      }
    }
  }
 
  col_count = nlist;
  if (col_count == 0) {
    printf(
     "Partial log file does not have any predicates\n");
    printf(
     "with 'pos' and 'neg' as last argument\n");
    printf(
     "Thus, no variables for sets A and B are specified\nStop\n");
    fprintf(errfil,
     "Partial log file does not have any predicates\n");
    fprintf(errfil,
     "with 'pos' and 'neg' as last argument\n");
    fprintf(errfil,
     "Thus, no variables for sets A and B are specified\nStop\n");
    lsqexit(1);
  }

/*
 *  print variables of log_name_list[][], which are for A and B
 */
  if (lsqscrflg == 1) {
    printf(
    "These predicate instances produce the following\n");
    printf(
    "%d variables for the sets A and B\n",
     col_count);
    printf(
    "If ASSIGNFALSE is specified for both 'pos and 'neg'\n");
    printf(
    "of a predicate, then the corresponding variable is\n");
    printf(
    "marked 'deleted' and is removed from the sets A and B\n");
    fprintf(errfil,
    "These predicate instances produce the following\n");
    fprintf(errfil,
    "%d variables for the sets A and B\n",
    col_count);
    fprintf(errfil,
    "If ASSIGNFALSE is specified for both 'pos and 'neg'\n");
    fprintf(errfil,
    "of a predicate, then the corresponding variable is\n");
    fprintf(errfil,
    "marked 'deleted' and is removed from the sets A and B\n");
    for (k=1;k<=col_count;k++) {
      printf("  %s",&log_name_list[k][0]);
      fprintf(errfil,"  %s",&log_name_list[k][0]);
      if (delete_var[k] == 1) {
        printf("   deleted");
        fprintf(errfil,"   deleted");
      }
      printf("\n");
      fprintf(errfil,"\n");      
    }
  }

  return;

}

/*  last record of eval_partial_log.c***** */
