/*  first record of optcc.c***** */
/*
 *   Leibniz System: Lsqcc System
 *   Copyright 2004 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * =====================================================
 * Lsqcc Learning Logic - Callable Optimal Records optcc
 * =====================================================
 *
 *  program for optimal training records
 *
 *  for each training record of set A, derives a record
 *  that can be separated from all records of set B,
 *  and vice versa
 *  
 *  input:  training file .trn with sets A and B
 *  output: optimal training file .opt with sets A* and B*
 * -----------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h" 
/* corresponding lsqdefs.h is included in lsqutil.c */

void optcc() {
/*
 *  callable version of optimal record program optcc
 *  caution: 
 *   - parameters must have been obtained (see lsqgetparm() for
 *   - required information)
 *   - allocation of leibniz arrays must have been done
 *   - errfil must have been opened
 *  caution: these conditions are not checked by the program
 */

  void  lsqcc();
  void  lsqexit();

  if (lsqscrflg == 1) {
    printf("\n\nOptimize records\n");
  }

/* 
 *  check that unknown = unavailable
 *  if not so specified, error message and stop
 */
  if (strongsepflg == 1) {
    printf(
    "Optimization of records requires that unknown values are\n");
    printf(
   "specified as unavailable. However, lqccparams.dat defines\n");
    printf(
   "unknown = absent. Must change lsqccparams.dat\nStop\n");
    fprintf(errfil,
    "Optimization of records requires that unknown values are\n");
    fprintf(errfil,
   "specified as unavailable. However, lqccparams.dat defines\n");
    fprintf(errfil,
   "unknown = absent. Must change lsqccparams.dat\nStop\n");
    lsqexit(1);
  }
  
/* 
 *  set flags for processing
 */
  shortsepflg = 0;
  optcstsepflg = 1;
  optreconlyflg = 1;

  lsqcc();

  return;

}

/*  last record of optcc.c***** */
