/*  first record of stat_covar.c***** */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h"

int sub_ys[6+1];
int common_untrain[max_record_num+1];
int untrain_rec[max_untrain_size + 1];
int common_untrain_total;
int master_rec[separation_num+1][2+1][sub_range_num+1][max_record_num + 1];
int sep_ind,buc_ind;
double mu[sub_range_num + 1];
double sig_sqr[sub_range_num + 1];
double co_var[sub_range_num + 1][sub_range_num + 1];

FILE *f2,*f3;

void comp_mu_var();
int  compute_covar(int , int);
void get_common_untrain_rec(int,int);
int  get_master_rec1();
void get_sub_info();
void get_sub_ys(int);
int  get_A_untrain_total();
int  get_B_untrain_total();
void init_covar();
double linear_curve_fit(double, double, double);
void lsqerror();
void new_covar_comp();
char * pathing();
void print_mu_var();
void sum_of_var();
  

/* ---------------------------------------------------
 *  stat_covar(): compute mean and variance via
 *  covariance matrix
 * ---------------------------------------------------
 */
int stat_covar() {

  int i,j,l,b,sub_x,sub_y;

  get_sub_info();
  i = get_master_rec1();
  if (i == -99){ 
    fclose(f2); 
    fclose(f3);  
    return(-99); 
  }
  if ((f2 = fopen(pathing("covar_matrix.data"),"w")) == NULL) {
    printf("Cannot open file covar_matrix.data\n");
    fprintf(errfil,"Cannot open file covar_matrix.data\n");
    lsqerror("stat_covar","102");
  }
  if ((f3 = fopen(pathing("mu_sig.data"),"w")) == NULL) {
    printf("Cannot open file mu_sig.data\n");
    fprintf(errfil,"Cannot open file mu_sig.data\n");
    lsqerror("stat_covar","104");
  }
  for (l=1;l<=separation_num;l++) {
    for (b=1;b<=2;b++) {
      sep_ind = l;
      buc_ind = b;
      comp_mu_var();
      init_covar();
      for (i=1;i<=10;i++) {
        sub_x = i;
        get_sub_ys(i);
        for (j=1;j<=6;j++) {
          sub_y = sub_ys[j];
          get_common_untrain_rec(sub_x , sub_y);
          if (compute_covar(sub_x , sub_y) == 2) { 
            fclose(f2); 
            fclose(f3); 
            return(-1); 
          }
        }
      }
      new_covar_comp();
      sum_of_var();
    }
  }
  fclose(f2);
  fclose(f3);
  return(0);

}

/*eject*/
/* --------------------------------------------------------
 *  comp_mu_var(): compute mean and variance
 * --------------------------------------------------------
 */
void comp_mu_var() {
  int   i,j;
  int   untrain_total;
  double sqr_total;
  double mu_total;

  for (i=1;i<= 10;i++) {
    mu_total = 0;
    sqr_total = 0;
    if (buc_ind == 1) {
           untrain_total = get_A_untrain_total(i);
    } else {
           untrain_total = get_B_untrain_total(i);
    }
    for (j=1;j<=untrain_total;j++) {
       mu_total = mu_total + master_rec[sep_ind][buc_ind][i]
                  [untrain_rec[j]];
       sqr_total = sqr_total + master_rec[sep_ind][buc_ind][i]
                   [untrain_rec[j]] *
       master_rec[sep_ind][buc_ind][i][untrain_rec[j]];
    }
    mu[i] = mu_total / untrain_total;
    sig_sqr[i] = (sqr_total - (untrain_total * mu[i]*mu[i]))/
                 (untrain_total - 1);
  }
  return;

}

/*eject*/
/* ---------------------------------------------------------
 *  compute_covar(): compute covariance
 * ---------------------------------------------------------
 */
int compute_covar(int x, int y) {

  int i;
  double co_total;
  double new_mu_x;
  double new_mu_y;

  new_mu_x = mu[x];
  new_mu_y = mu[y]; 
  co_total = 0;
  for (i=1;i<=common_untrain_total;i++) {
    co_total = co_total + 
               (master_rec[sep_ind][buc_ind][x]
                          [common_untrain[i]] - new_mu_x)*
               (master_rec[sep_ind][buc_ind][y]
                          [common_untrain[i]] - new_mu_y);
  }
  if ((common_untrain_total - 1) == 0) {
/*
 *  divisor is zero; hence cannot compute value
 */
   return(2);
  }

  if (co_total > 0) {
    co_var[x][y] = co_total / common_untrain_total ;
  } else {
       co_var[x][y] = 0;
  }
  return(0);

}

/*eject*/
/* ---------------------------------------------------
 *  get_common_untrain_rec(): compute indices for untrain
 *  records
 * ---------------------------------------------------
 */
void get_common_untrain_rec(int x, int y) {

  int i,ind,left_ind,right_ind;
  int x_left,x_right,y_left,y_right;

  if (buc_ind == 1) {
    if ((sep_l_a[sep_ind][x][3] == 0)&&             /* case 1 */
       (sep_l_a[sep_ind][x][4] == 0)&&
       (sep_l_a[sep_ind][y][3] == 0)&&
       (sep_l_a[sep_ind][y][4] == 0)) {
      x_left  = sep_l_a[sep_ind][x][1];
      x_right = sep_l_a[sep_ind][x][2];
      y_left  = sep_l_a[sep_ind][y][1]; 
      y_right = sep_l_a[sep_ind][y][2];
      if (x_left < y_left) {
            left_ind = x_left;
      } else {
            left_ind = y_left;
      }
      if (x_right > y_right) {
            right_ind = x_right;
      } else {
            right_ind = y_right;
      }
      ind = 1;
      if (left_ind != 1) {
        for (i=1;i<=(left_ind - 1);i++) {
          common_untrain[ind] = i;
          ind++;
        }
      }
      if (right_ind != sep_l_a[sep_ind][10][2]) {
        for (i=(right_ind + 1);
             i<=(sep_l_a[sep_ind][10][2]);i++) {
          common_untrain[ind] = i;
          ind++;
        }
      }
      common_untrain_total = ind - 1;

    } else if ((sep_l_a[sep_ind][x][3] == 0)&&      /* case 2 */
               (sep_l_a[sep_ind][x][4] == 0)&&
               (sep_l_a[sep_ind][y][3] != 0)&&
               (sep_l_a[sep_ind][y][4] != 0)) { 
      if (sep_l_a[sep_ind][x][2] < sep_l_a[sep_ind][y][1]) {
        left_ind  = sep_l_a[sep_ind][x][2];
        right_ind = sep_l_a[sep_ind][y][1];
      } else {
        left_ind  = sep_l_a[sep_ind][y][4];
        right_ind = sep_l_a[sep_ind][x][1];
      }
      ind = 1;
      for (i=(left_ind + 1);i<=(right_ind - 1);i++) {
        common_untrain[ind] = i;
        ind++;
      } 
      common_untrain_total = ind - 1;

    } else if ((sep_l_a[sep_ind][x][3] != 0)&&      /* case 3 */
               (sep_l_a[sep_ind][x][4] != 0)&&
               (sep_l_a[sep_ind][y][3] == 0)&&
               (sep_l_a[sep_ind][y][4] == 0)) {
       if (sep_l_a[sep_ind][y][2] < sep_l_a[sep_ind][x][1]) {
         left_ind  = sep_l_a[sep_ind][y][2];
         right_ind = sep_l_a[sep_ind][x][1];
       } else {
         left_ind  = sep_l_a[sep_ind][x][4];
         right_ind = sep_l_a[sep_ind][y][1];
     }
     ind = 1;
     for (i=(left_ind + 1);i<=(right_ind - 1);i++) {
       common_untrain[ind] = i;
       ind++;
     } 
     common_untrain_total = ind - 1;

   } else if ((sep_l_a[sep_ind][x][3] != 0)&&       /* case 4 */
              (sep_l_a[sep_ind][x][4] != 0)&&
              (sep_l_a[sep_ind][y][3] != 0)&&
              (sep_l_a[sep_ind][y][4] != 0)) {
      x_left  = sep_l_a[sep_ind][x][4];
      x_right = sep_l_a[sep_ind][x][1];
      y_left  = sep_l_a[sep_ind][y][4];
      y_right = sep_l_a[sep_ind][y][1];
      if (x_left > y_left) {
        left_ind = x_left;
      } else {
        left_ind = y_left;
      }
      if (x_right < y_right) {
        right_ind = x_right;
      } else {
        right_ind = y_right;
      }
      ind = 1;
      for (i=(left_ind + 1);i<=(right_ind - 1);i++) {
         common_untrain[ind] = i;
         ind++;
      }
      common_untrain_total = ind - 1; 
    } else {
/*
 *  program error
 */
      lsqerror("get_common_untrain_rec","102");
    }

  } else if (buc_ind == 2) {
    if ((sep_l_b[sep_ind][x][3] == 0)&&             /* case 5 */
        (sep_l_b[sep_ind][x][4] == 0)&&
        (sep_l_b[sep_ind][y][3] == 0)&&
        (sep_l_b[sep_ind][y][4] == 0)) {
      x_left  = sep_l_b[sep_ind][x][1];
      x_right = sep_l_b[sep_ind][x][2];
      y_left  = sep_l_b[sep_ind][y][1]; 
      y_right = sep_l_b[sep_ind][y][2];
      if ( x_left < y_left) {
        left_ind = x_left;
      } else {
        left_ind = y_left;
      }
      if (x_right > y_right) {
        right_ind = x_right;
      } else {
        right_ind = y_right;
      }
      ind = 1;
      if (left_ind != 1) {
        for (i=1;i<=(left_ind - 1);i++) {
          common_untrain[ind] = i;
          ind++;
        }
      }
      if ( right_ind != sep_l_b[sep_ind][10][2]) {
        for(i=(right_ind + 1);i<=(sep_l_b[sep_ind][10][2]);i++) {
          common_untrain[ind] = i;
          ind++;
        }
      }
      common_untrain_total = ind - 1;

    } else if ((sep_l_b[sep_ind][x][3] == 0)&&      /* case 6 */
               (sep_l_b[sep_ind][x][4] == 0)&&
               (sep_l_b[sep_ind][y][3] != 0)&&
               (sep_l_b[sep_ind][y][4] != 0)) {
      if (sep_l_b[sep_ind][x][2] < sep_l_b[sep_ind][y][1]) {
        left_ind  = sep_l_b[sep_ind][x][2];
        right_ind = sep_l_b[sep_ind][y][1];
      } else {
        left_ind  = sep_l_b[sep_ind][y][4];
        right_ind = sep_l_b[sep_ind][x][1];
      }
        ind = 1;
        for (i=(left_ind + 1);i<=(right_ind - 1);i++) {
          common_untrain[ind] = i;
          ind++;
        } 
        common_untrain_total = ind - 1;

      } else if ((sep_l_b[sep_ind][x][3] != 0)&&    /* case 7 */
                 (sep_l_b[sep_ind][x][4] != 0)&&
                 (sep_l_b[sep_ind][y][3] == 0)&&
                 (sep_l_b[sep_ind][y][4] == 0)) {
        if (sep_l_b[sep_ind][y][2] < sep_l_b[sep_ind][x][1]) {
          left_ind  = sep_l_b[sep_ind][y][2];
          right_ind = sep_l_b[sep_ind][x][1];
        } else {
          left_ind  = sep_l_b[sep_ind][x][4];
          right_ind = sep_l_b[sep_ind][y][1];
        }
        ind = 1;
        for (i=(left_ind + 1);i<=(right_ind - 1);i++) {
          common_untrain[ind] = i;
          ind++;
        } 
        common_untrain_total = ind - 1;

      } else if ((sep_l_b[sep_ind][x][3] != 0)&&    /* case 8 */
                  (sep_l_b[sep_ind][x][4] != 0)&&
                  (sep_l_b[sep_ind][y][3] != 0)&&
                  (sep_l_b[sep_ind][y][4] != 0)) {
       x_left  = sep_l_b[sep_ind][x][4];
       x_right = sep_l_b[sep_ind][x][1];
       y_left  = sep_l_b[sep_ind][y][4];
       y_right = sep_l_b[sep_ind][y][1];
       if (x_left > y_left) {
         left_ind = x_left;
       } else {
         left_ind = y_left;
       }
       if (x_right < y_right) {
         right_ind = x_right;
       } else {
         right_ind = y_right;
       }
       ind = 1;
       for (i=(left_ind + 1);i<=(right_ind - 1);i++) {
          common_untrain[ind] = i;
          ind++;
       }
       common_untrain_total = ind - 1; 
    } else {
/*
 *  program error
 */
      lsqerror("get_common_untrain_rec","202");
    }
  } else {
/*
 *  program error
 */
    lsqerror("get_common_untrain_rec","302");
  }
  return;

}

/*eject*/
/* ---------------------------------------------------
 *  get_master_rec1(): read file master_rec.data and 
 *  compute array master_rec[k][l][i][x]
 * ---------------------------------------------------
 */
int get_master_rec1() {
 
  int i,j,k,l,x,i_num;
  int untrain_total;
  char s1[namesize];

  FILE *f1;
  
  for(k=0;k<=separation_num;k++) {
    for(l=0;l<=2;l++) {
      for(i=0;i<=sub_range_num;i++) {
        for(j=0;j<=max_untrain_size;j++) {
              master_rec[k][l][i][j] = 0;
        }
      }
    }
  }

  sprintf(s1,"master_rec.data");
  if ((f1 = fopen(pathing(s1),"r")) == NULL) {
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("get_master_rec1","102");
  }
  for(k=1;k<=separation_num;k++) {
    sep_ind = k;
    for(l=1;l<=2;l++) {
      for(i=1;i<=sub_range_num;i++) {
        if (l == 1) { 
          untrain_total = get_A_untrain_total(i);
          if (untrain_total == -99 ) { 
            fclose(f1); 
            return(-99);  
          }
        } else {
          untrain_total = get_B_untrain_total(i);
        }           
        for (j=1;j<= untrain_total;j++) {
          fscanf(f1,"%d",&i_num);
          fscanf(f1,"%d",&i_num);
          fscanf(f1,"%d",&i_num);
          fscanf(f1,"%d",&x);
          fscanf(f1,"%d",&i_num);
          master_rec[k][l][i][x] = i_num;
        }
      }
    }
  }
  fclose(f1);
  return(1);

}

/*eject*/
/* ---------------------------------------------------
 *  get_sub_ys(): compute indices for ys
 * ---------------------------------------------------
 */
void get_sub_ys(int k) {

  if ((k+1)>10) {
     sub_ys[1] = (k+1)%10;
  } else { 
     sub_ys[1] = k+1;
  }

  if ((k+2)>10) {
     sub_ys[2] = (k+2)%10;
  } else {
     sub_ys[2] = k+2;
  }

  if ((k+3)>10) {
    sub_ys[3] = (k+3)%10;
  } else {
    sub_ys[3] = k+3;
  }

  if ((k+7)>10) {
    sub_ys[4] = (k+7)%10;
  } else {
    sub_ys[4] = k+7;
  }

  if ((k+8)>10) {
    sub_ys[5] = (k+8)%10;
  } else {
    sub_ys[5] = k+8;
  }

  if ((k+9)>10) {
    sub_ys[6] = (k+9)%10;
  } else {
     sub_ys[6] = k+9;
  }

  return;

}  

/*eject*/
/* --------------------------------------------------------
 *  init_covar(): compute initial variance
 * --------------------------------------------------------
 */
void init_covar() {
  int i,j;

  for (i=1;i<=sub_range_num;i++) {
    for (j=1;j<=sub_range_num;j++) {
      co_var[i][j] = 10000;
    }
  }
  return;

}

/*eject*/
/* ---------------------------------------------------------
 *  linear_curve_fit(): subroutine for ridge regression
 * ---------------------------------------------------------
 */
double linear_curve_fit(double w1, double w2, double w3) {

  int i,j,k;
  double A[3+1][2+1];
  double A_tran[2+1][3+1];
  double B[2+1][2+1];
  double b[2+1];
  double y[3+1];
  double beta_alpha[2+1];
  double pivot;
   
  y[1] = w1;
  y[2] = w2;
  y[3] = w3;

  A[1][1] = 1; 
  A[2][1] = 2;
  A[3][1] = 3;
  A[1][2] = 1;
  A[2][2] = 1;
  A[3][2] = 1;

  A_tran[1][1] = 1;
  A_tran[2][1] = 1;
  A_tran[1][2] = 2;
  A_tran[2][2] = 1;
  A_tran[1][3] = 3;
  A_tran[2][3] = 1;

  B[1][1] = 14;
  B[1][2] = 6;
  B[2][1] = 6;
  B[2][2] = 3;

  b[1] = A_tran[1][1] * y[1] + A_tran[1][2] * y[2] + 
         A_tran[1][3] * y[3];
  b[2] = A_tran[2][1] * y[1] + A_tran[2][2] * y[2] + 
         A_tran[2][3] * y[3];

  for (k=1;k<=2;k++) {
    pivot = B[k][k];
    if ( fabs(pivot) < 1.0e-10) {
      printf("pivoting assumption has failed.\n");
      fprintf(errfil,"pivoting assumption has failed.\n");
      lsqerror("linear_curve_fit","102");
    }
    if (pivot == 0) {
      printf("Error in learn_curve_fit(), pivot = 0.\n");
      fprintf(errfil,"Error in learn_curve_fit(), pivot = 0.\n");
      lsqerror("linear_curve_fit","104");
    }
    if (pivot > 1.e200) {
       printf("Error in inverse B, pivot is too large.\n");
       fprintf(errfil,
         "Error in inverse B, pivot is too large.\n");
       lsqerror("linear_curve_fit","106");
    }
    B[k][k] = 1;
    for (j=1;j<=2;j++) {
      B[k][j] = B[k][j]/pivot;
    }
    for (i=1;i<=2;i++) {
      if (i != k) {
        pivot = B[i][k];
        B[i][k] = 0;
        for (j=1;j<=2;j++) {
          B[i][j] = B[i][j] - pivot*B[k][j];
        }
      }
    }
  }  

  beta_alpha[1] = B[1][1] * b[1] + B[1][2] * b[2] ;
  beta_alpha[2] = B[2][1] * b[1] + B[2][2] * b[2] ;

  if (beta_alpha[1] < 0) {
    return (beta_alpha[1] * 4 + beta_alpha[2]);
  } else {
    return (beta_alpha[2]);
  }
  
}

/*eject*/
/* ---------------------------------------------------------
 *  new_covar_comp(): covariance estimation via ridge
 *  regression (introduced Jan 1998)
 * ---------------------------------------------------------
 */
void new_covar_comp() {

  int i,j,r_ind,l_ind;
  double w0,w1,w2,w3,w4;

  /* for linear curve fit */
  
  w0 = 0;
  for (i=1;i<=10;i++) { 
    w0 = w0 + sig_sqr[i];
  }
  w0 = w0 / 10;

  w1 = 0;
  for (i=1;i<=10;i++) {
    r_ind = i+1;
    if (r_ind >10) {
      r_ind = r_ind -10;
    }
    l_ind = i+9;
    if (l_ind >10) {
      l_ind = l_ind - 10;        
    }     
    w1 = w1 + ((co_var[i][l_ind] + co_var[i][r_ind])/2);
  }
  w1 = w1/10;

  w2 = 0;
  for (i=1;i<=10;i++) {
    r_ind = i+2;
    if (r_ind >10) {
      r_ind = r_ind -10;
    }
    l_ind = i+8;
    if (l_ind >10) {
      l_ind = l_ind - 10;        
    }     
    w2 = w2 + ((co_var[i][l_ind] + co_var[i][r_ind])/2);
  }
  w2 = w2/10;

  w3 = 0;
  for (i=1;i<=10;i++) {
    r_ind = i+3;
    if (r_ind > 10) {
         r_ind = r_ind -10;
    }
    l_ind = i+7;
    if (l_ind >10) {
      l_ind = l_ind - 10;        
    }     
    w3 = w3 + ((co_var[i][l_ind] + co_var[i][r_ind])/2);
  }
  w3 = w3/10;

  w4 = linear_curve_fit(w1,w2,w3);

  for (i=1;i<=sub_range_num;i++) {
    for (j=1;j<=sub_range_num;j++) {
      if ((i != j) && ( co_var[i][j] == 10000))
        co_var[i][j] = w4;
    }
  }
  return;

}

/*eject*/
/* ---------------------------------------------------------
 *  print_mu_var(): print mean and variance values
 *  (debugging only)
 * ---------------------------------------------------------
 */
void print_mu_var()
{
  int i,j;

  for (i=1;i<=sub_range_num;i++) {
    for (j=1;j<=sub_range_num;j++) {
      if (i == j) {
        printf("%5.2f ",sig_sqr[i]);
      } else {
        printf("%5.2f ",co_var[i][j]);
      }
    }
    printf("\n\n");
  }
  return;

}

/*eject*/
/* ---------------------------------------------------------
 *  sum_of_var(): compute and output sum of variance
 *  and covariance values
 * ---------------------------------------------------------
 */ 
void sum_of_var() {

  int i,j;
  double sumofmu;
  double sumofvar;
    
  fprintf(f2,"sep %2d --- buc %2d\n",sep_ind,buc_ind);
  sumofmu = 0;
  for (i=1;i<=sub_range_num;i++) {
    sumofmu = sumofmu + mu[i];
  }
  fprintf(f2,"mu       = %8.2f\n",sumofmu);
  fprintf(f3,"%8.2f\n",sumofmu);

  sumofvar = 0;
  for (i=1;i<=sub_range_num;i++) {
    for (j=1;j<=sub_range_num;j++) {
      if(i==j) {
        sumofvar = sumofvar + sig_sqr[i];
      } else {
        sumofvar = sumofvar + co_var[i][j];
      }
    }
  }
  fprintf(f2,"sig      = %8.2f\n",sqrt(sumofvar));
  fprintf(f3,"%8.2f\n",sqrt(sumofvar));
  return;

}

/*  last record of stat_covar.c***** */

