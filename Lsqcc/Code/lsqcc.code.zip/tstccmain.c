/*  first record of tstccmain.c***** */
/*
 *   Leibniz System: Lsqcc System
 *   Copyright 2004 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * ===================================================
 * Lsqcc System - Main Testing Program tstccmain
 * ===================================================
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h" /* lsqdefs.h is in lsqutil.c */

FILE *errfil;

int main(int argc, char *argv[]) { // argc and argv for lsqccparams
                                    // file definition

  void lsqgetparm();
  void tstcc();

/*
 *  open error file errfil
 */
  if ((errfil = fopen("tstcc.err", "w")) == NULL) {
    printf("\n Cannot open error file tstcc.err. Stop");
    exit(1);
  }

/* lsqccparams file name option 
 *  if no name given, use default "lsqccparams.dat" 
 */
  if (argc == 2 && strcmp(argv[1],"") != 0) {
    strcpy(lsqccparamsname,argv[1]);
  } else {
    strcpy(lsqccparamsname,"lsqccparams.dat");
  }

/*
 *  get parameters from file lsqccparams.dat
 */      
  lsqgetparm();

/*
 *  test data of testing file
 */
  tstcc();

  exit(0);

}

/* vacuous definition of fre_dev() */
void fre_dev(char *uname,char *ustate,char *utype,
             long *uvalue,short *uerror) {
  return;
}

/*  last record of tstccmain.c***** */
