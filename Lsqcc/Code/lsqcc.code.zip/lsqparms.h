#define nameextsize        32 /* do not change        */
#define namesize          256 /* do not change        */
#define buc_num             2 /* do not change        */
#define separation_num      1 /* do not change        */
#define sub_range_num      10 /* do not change        */

                              /* max number of:       */
#define sep_set_size      100 /* clauses in formula   */
#define MAX_RECORD       2500 /* number of records    */
                              /* must be >= 80        */
#define MAX_ATTRIBUTE     1200 /* entries of record    */  /* 300 */
                              /* number must include entries  */
                              /* computed by pyramid formulas */ 
#define max_record_num    MAX_RECORD  /* train/test records   */
                                      /* must be >= 80        */
#define max_untrain_size  MAX_RECORD  /* untrained records    */
                                      /* must be >= 80        */
#define max_buc_size      MAX_RECORD  /* records in bucket    */
                                      /* must be >= 80        */
#define max_column_size   MAX_ATTRIBUTE /* entries of record  */
                              /* number must include entries  */
                              /* computed by pyramid formulas */

#define maj_count          21 /*  do not change       */
#define LSQBEG             -1 /*  do not change       */
#define LSQTRUE             1 /*  do not change       */
#define LSQFALSE            0 /*  do not change       */
#define LSQSAME             2 /*  do not change       */
#define BEGIN_A         99999 /*  do not change       */
#define BEGIN_B        -99999 /*  do not change       */

/* parameters for lbcc allocation in lsqcc */
#define max_user_col       50 /* additional log vars  */
                              /* must be >= 2         */
#define max_user_row       500 /* additional log rows  */
                              /* must be >= 2         */
#define max_user_anz       3000 /* additional literals  */
                              /* must be >= 2         */

#define max_total_col   2*max_column_size + max_user_col + 1
#define max_total_row   max_record_num + max_user_row + 1
#define max_total_anz   2*max_column_size*max_record_num + \
                        max_user_anz + 1

/* parameters for lbcc allocation in pyrcc */
#define max_pyr_count      50 /* max number of pyramid formulas */
#define max_formula_lit   300 /* max number of literals in one  */
                              /* formula                        */

#define max_pyr_col      2*max_formula_lit + 1
#define max_pyr_row      4*max_formula_lit + 1
#define max_pyr_anz      12*max_formula_lit + 1

