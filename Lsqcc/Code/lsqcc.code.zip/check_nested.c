/*  first record of check_nested.c***** */
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "lsqparms.h"
#include "lsqexts.h"

int  row_size_A;
int  row_size_B;
int  row_end_A;
int  row_begin_B;
int  bad_nested_flg;

void lsqexit(); 


/* ----------------------------------------------
 *  check_nested(): check records of training file
 *  for nestedness 
 *  if A (B) records are nested in B (A) records, set
 *  bad_nested_flg = 1 to indicate bad nesting
 *  if bad nesting is detected:
 *    if removal option has been specified: 
 *      remove records of bad nesting
 *    else
 *      stop
 *
 *  add values defined by pyramid formulas
 *  construct files
 *    partial_log_fil 
 *    ll_raw_log.data
 *    AB_separation.cnl
 *    bucket_separation.cnl
 * ----------------------------------------------
 */ 

void check_nested() {

  void get_logrc();
  void remove_logrc();
  void construct_ll_raw_log_file();

  if (lsqscrflg == 1) {
    printf("\n");
    printf("Check nestedness of records\n");
  }
  get_logrc();
  remove_logrc();
  if ((bad_nested_flg == 1) && (rmnestedflg == 0)) {
/*
 * at least one case of bad nesting of records is present
 * removal option of such nested records has not been specified.
 * hence, stop processing
 */
    printf("Some A (B) records are nested in B (A) records\n");
    printf("Since deletion of such records is not allowed\n");
    printf("according to lsqccparams.dat, stop\n");
    fprintf(errfil,
           "Some A (B) records are nested in B (A) records\n");
    fprintf(errfil,
           "Since deletion of such records is not allowed\n");
    fprintf(errfil,
           "according to lsqccparams.dat, stop\n");
    lsqexit(1);
  }
  construct_ll_raw_log_file();
  return;
}

/*eject*/
/* 
 * -----------------------------
 * construct_ll_raw_log_file(): read the    
 * records of training file, skip over records
 * of bad nesting, and output rest into ll_raw_log.data 
 * -----------------------------
 */
void construct_ll_raw_log_file() {

  int i,j,k,k_A,k_B,k_mult,m_A,m_B,n,r_A,r_B;

  FILE *fp2;
  FILE *fp3;
  FILE *fp4;

  void add_pyr_values();
  void lsqerror();
  char* pathing();

/*
 *  if bad nested records have been determined,
 *  reduce row counts to account for records to be deleted
 */
  m_A = 0;
  m_B = 0;
  if (bad_nested_flg == 1) {
    for (i=1;i<=log_rec_count;i++) {
      if (log_rec[i][0] == LSQTRUE) {
        if (i <= row_end_A) {
          m_A++;
        } else {
          m_B++;
        }
      }
    }
    
    row_size_A -= m_A;
    row_size_B -= m_B;
    del_rows_A = m_A;
    del_rows_B = m_B;
  }
  row_count =  row_size_A + row_size_B;

/* 
 *  if pyramid exists, add values defined by pyramid formulas
 */
  if (pyr_form_count > 0) {
    add_pyr_values(&log_rec_count);
  }

  if (lsqscrflg == 1) {
    if (m_A == 0) {
      printf("No removal of nested records from A required\n");
      printf("A has %d records\n",row_size_A);
    } else if (m_A > 0) {
      printf("Size of A reduced from %d to %d by removal\n",
             row_size_A+m_A,row_size_A);
      printf("of %d record(s) nested in B records\n",m_A);
    } else {
      lsqerror("construct_ll_raw_log_file","102");
    }
    if (m_B == 0) {
      printf("No removal of nested records from B required\n");
      printf("B has %d records\n",row_size_B);
    } else if (m_B > 0) {
      printf("Size of B reduced from %d to %d by removal\n",
             row_size_B+m_B,row_size_B);
      printf("of %d record(s) nested in A records\n",m_B);
    } else {
      lsqerror("construct_ll_raw_log_file","104");
    }
  }

/*
 * consistency check
 */
  if (row_size_A < 0) {
    lsqerror("construct_ll_raw_log_file","102");
  }
  if (row_size_B < 0) {
    lsqerror("construct_ll_raw_log_file","104");
  }

/*
 *  test whether sets A and B are nonempty
 */
  if ((row_size_A == 0 ) ||
      (row_size_B == 0 )) {
    if (lsqscrflg == 1) {
      printf("Removal of nested records deletes\n");
    }
    fprintf(errfil,"Removal of nested records deletes\n");
    if (row_size_A == 0 ) {
      if (lsqscrflg == 1) {
        printf("all A records\n");
      }
      fprintf(errfil,"all A records\n");  
    }
    if (row_size_B == 0 ) {
      if (lsqscrflg == 1) {
        printf("all B records\n");
      }
      fprintf(errfil,"all B records\n");    
    }
    if (lsqscrflg == 1) {
      printf("Stop\n");
    }
    fprintf(errfil,"Stop\n");
    lsqexit(1);        
  } 

/*
 *  create ll_raw_log_file
 */

  if((fp2 = fopen(pathing("ll_raw_log.data"),"wb")) == NULL) {
    printf("\nCannot open file: ll_raw_log.data \n");
    fprintf(errfil,
       "\nCannot open file: ll_raw_log.data \n");
    lsqerror("construct_ll_raw_log_file", "204");
    lsqexit(1);
  }

/*
 *  compute row_count, row_size_A, row_size_B
 *  r_A,B = minimum number of records required
 *  k_A,B = multiplier for expansion of record set
 *  if no distributions: r_A,B = 3
 *  if distributions   : r_A,B = 2*sub_range_num
 */
  if ((disprocessflg == 0 ) ||
      (globalfourtotalsepflg == 1)) {
    r_A = 3;
    r_B = 3;
  } else {
    r_A = 2*sub_range_num;
    r_B = 2*sub_range_num;
  }
  k_A = (r_A + row_size_A - 1)/row_size_A;
  k_B = (r_B + row_size_B - 1)/row_size_B;
  row_size_A *= k_A;
  row_size_B *= k_B;
  row_count = row_size_A + row_size_B;
             
  fprintf(fp2,"%d \n",row_count);
  fprintf(fp2,"%d \n",col_count);

/*
 *  expand record sets by multipliers k_A,B
 */
  k_mult = k_A;
  n = 0;
  for (i=1;i<=log_rec_count;i++) {
    if (log_rec[i][0] == LSQFALSE) {
/*
 *  have a record of A or B
 *  expand k_mult times
 */
      for (k=1;k<=k_mult;k++) {
        fprintf(fp2," %d",rec_filidx[i]);
        for (j=1;j<=col_count;j++) {
          fprintf(fp2," %d",log_rec[i][j]);
        }
        fprintf(fp2,"\n");
        n++;
      }      
    } else if (log_rec[i][0] == BEGIN_B) {
      k_mult = k_B;
    }
  }

  if (n != row_count) {
/*
 *  n must match row_count
 */
    lsqerror("construct_ll_raw_log_file","206");
  }
                      
  fclose(fp2);
                  
/* 
 * write row indices for classes A and B into the files 
 * "AB_separation.cnl" and "bucket_separation.cnl"
 */
                    
  fp3 = fopen(pathing("AB_separation.cnl"),"wb");
  fprintf(fp3,"%d \n",1);
  fprintf(fp3,"   %d     %d \n",1,row_size_A);
  fprintf(fp3,"   %d    %d \n",row_size_A+1,row_count);
  fclose(fp3);
                  
  fp4 = fopen(pathing("bucket_separation.cnl"),"wb");
  fprintf(fp4,"%d \n",2);
  fprintf(fp4,"   %d     %d \n",1,row_size_A);
  fprintf(fp4,"   %d    %d \n",row_size_A+1,row_count);
  fclose(fp4);

  return;

}

/*eject*/
/* 
 * --------------------------------------------
 * get_logrc(): read the logic data and convert
 * into logic records of log_rec[][] 
 * --------------------------------------------
 */
void get_logrc() {

  int i,j,k,kpos,left,n,stage;
  double z;

  char record[256 + 1];
  char s1[128 + 1];
  
  FILE *f1;

  void lsqerror();
  int  nextentry();

  if ((f1 = fopen(training_file,"r")) == NULL){
    printf("Cannot open training file:\n %s\n",training_file);
    printf("Stop\n");
    fprintf(errfil,
       "Cannot open training file:\n %s\n",training_file);
    fprintf(errfil,"Stop\n");
    lsqexit(1);
  }
  filesize = 0;
  log_rec_count = 0;
  row_count = 0;
  row_size_A = 0;
  row_size_B = 0;
  row_end_A = 0;
  row_begin_B = 0;
  stage = 0;

/*eject*/
/*
 *  top of loop
 */
  zz105:;
/*
 *  read record from file
 */
  if (fgets(record,256,f1)==NULL) {
    printf("Unexpected end of training file:\n");
    printf("%s\n",training_file);
    printf("Maybe BEGIN A or ENDATA record missing\n");
    printf("Stop\n");
    fprintf(errfil,"Unexpected end of training file:\n");
    fprintf(errfil,"%s\n",training_file);
    fprintf(errfil,"Maybe BEGIN A or ENDATA record missing\n");
    fprintf(errfil,"Stop\n");
    lsqexit(1);
  }

  filesize++;
  kpos = -1;
/*
 *  eliminate comments
 */
  n = strlen(record)-1;
  for (j=0;j<=n;j++) {
    if (record[j] == '*') {
      record[j] = '\0';
      break;
    }
  }

/*
 *  test for blank record
 */
  k = -1;
  if (nextentry(&k,record) == -1) {
    /* have blank line */
    goto zz105;
  }

/*
 *  have k >= 0 due to nextentry call
 *  extract first component and, if second component exists,
 *  extract second component and concatenate it
 */
  sscanf(&record[k],"%s",s1);
  if (nextentry(&k,record) > 0) {
    sscanf(&record[k],"%s",&s1[strlen(s1)]);
  }
/*eject*/  
/*
 *  begin stage processing
 */
  zz205:;

/*
 *  stage = 0: skip over logic records
 */
  if (stage == 0) {
    if ((strcmp(s1,"BEGINA") != 0) &&
        (strcmp(s1,"begina") != 0)) {
      goto zz105;
    } else {
      stage = 1;
      goto zz205;
    }
  } /* end of stage = 0 */

/*eject*/
/* 
 *  stage = 1: process BEGIN A
 */
  if (stage == 1) {
    log_rec_count = 1;
    log_rec[log_rec_count][0] = BEGIN_A;
    for (j=1;j<=col_count;j++) {
      log_rec[log_rec_count][j] = 0;
    }
    rec_filidx[log_rec_count] = filesize;
    stage = 2;
    goto zz105;
  } /* end of stage = 1 */

/*eject*/ 
/* 
 *  stage = 2:  decide on ENDATA, BEGIN B, or data record
 */
  if (stage == 2) {
/*
 *  check for duplicate BEGIN A
 */
    if ((strcmp(s1,"BEGINA") == 0) ||
        (strcmp(s1,"begin a") == 0)) {
      printf(
       "Duplicate BEGIN A on line: %d\nStop\n",filesize);
      fprintf(errfil,
       "Duplicate BEGIN A on line: %d\nStop\n",filesize);
      lsqexit(1);
    }
/*
 *  check for ENDATA
 */
    if ((strcmp(s1,"ENDATA") == 0) ||
        (strcmp(s1,"endata") == 0)) {
      stage = 4;
      goto zz205;
    } 
/*
 *  increment log_rec_count. check for max allowed size
 */
    log_rec_count++;
    if ((log_rec_count) > max_record_num +2) {
        printf(
          "Total number of A,B records in training file is too ");
        printf(
          "large\nmust not exceed: %d\nStop\n",max_record_num+1);
        fprintf(errfil,
          "Total number of A,B records in training file is too ");
        fprintf(errfil,
         "large\nmust not exceed: %d\nStop\n",max_record_num+1);
        lsqexit(1);
     }
/*
 * store record index
 */
    rec_filidx[log_rec_count] = filesize;
/*
 *  check for BEGIN B
 */
    if ((strcmp(s1,"BEGINB") == 0) ||
        (strcmp(s1,"beginb") == 0)) {
      stage = 3;
      goto zz205;
    }
/*
 *  have begin of data record
 *  initialize LSQBEG flag
 *  zero out log_rec[[log_rec_count][j>=1]
 */
    log_rec[log_rec_count][0] = LSQBEG;  
    for (j=1;j<=col_count;j++) {
      log_rec[log_rec_count][j] = 0;
    }
    stage = 21;
    goto zz205;
  } /* end of stage = 2 */

/*eject*/
/* 
 *  stage = 21: extract data of A/B record
 */
  if (stage == 21) {
/*
 *  get next entry
 */
    if (nextentry(&kpos,record) == -1) {
      /*  have read all entries of line */ 
      goto zz105;
    }
/* 
 * put entry into s1 
 */
    sscanf(&record[kpos],"%s",s1);

/*
 * handle termination period
 */

  if (s1[strlen(s1)-1] == '.') {
    if (strlen(s1) == 1) {
      /*  s1 is "." */
      stage = 2;
      goto zz105;  
    }
    /*  move period in record to the right and adjust s1 */
      strcpy(&record[kpos+strlen(s1)-1]," .");
      s1[strlen(s1)-1] = '\0';
    }

/* 
 *  check for negation symbol
 */
    if (s1[0] == '-') {
      left = 1;
    } else {
      left = 0;
    }

/*
 *  find name in log_name_list[][]
 */
    for (i=1;i<=col_count;i++) {
      if (strcmp(&s1[left],&log_name_list[i][0]) == 0) {
	/*
	 *  check for duplicate entry in record
	 */
        if (log_rec[log_rec_count][i] != 0) {
          printf(
            "Duplicate entry for variable: %s \n",
            &log_name_list[i][0]);
          printf(
            "in an A/B record; see lines: %d - %d\nStop\n",
            rec_filidx[log_rec_count],filesize);
          fprintf(errfil,
            "Duplicate entry for variable: %s \n",
            &log_name_list[i][0]);
          fprintf(errfil,
            "in an A/B record; see lines: %d - %d\nStop\n",
            rec_filidx[log_rec_count],filesize);
          lsqexit(1);
        }  
        if (left == 0) {
          log_rec[log_rec_count][i] = 1;
        } else {
          log_rec[log_rec_count][i] = -1;
        }
        goto zz205;
      }
    }
    /*
     *  unkown variable name
     */
    printf(
      "Unknown variable: %s on line: %d\nStop\n",
      &s1[left],filesize);
    fprintf(errfil,
      "Unknown variable: %s on line: %d\nStop\n",
      &s1[left],filesize);
    lsqexit(1);
 
  } /* end of stage = 21 */

/*eject*/
/* 
 *  stage = 3: process BEGIN B
 */
  if (stage == 3) {
/*
 *  check for duplicate BEGIN B
 */
    if (row_end_A != 0) {
      printf(
       "Duplicate BEGIN B on line: %d\nStop\n",filesize);
      fprintf(errfil,
       "Duplicate BEGIN B on line: %d\nStop\n",filesize);
      lsqexit(1);
    }

    log_rec[log_rec_count][0] = BEGIN_B;
    for (j=1;j<=col_count;j++) {
      log_rec[log_rec_count][j] = 0;
    }
    row_end_A = log_rec_count-1;
    row_begin_B = log_rec_count+1;
    stage = 2;
    goto zz105;
  } /* end of stage = 3 */

/*eject*/
/* 
 *  stage = 4: process ENDATA
 */
  if (stage == 4) {
    row_size_A = row_end_A - 1;
    row_size_B = log_rec_count - row_end_A - 1;
    row_count = row_size_A + row_size_B;
    init_row_size_A = row_size_A;
    init_row_size_B = row_size_B;
    if (lsqscrflg == 1) {
      printf("Number of A records: %d\n",row_size_A);
      printf("Number of B records: %d\n",row_size_B);
    }
/*
 *  check for training file errors
 */
    if ((row_end_A ==0)&&(row_begin_B ==0)) {
      printf(
        "BEGIN B record missing in training file\nStop\n");
      fprintf(errfil,
        "BEGIN B record missing in training file\nStop\n");
      lsqexit(1);
    }
    if (row_size_A == 0) {
      printf("Have no A records\nStop\n");
      fprintf(errfil,"Have no A records\nStop\n");
      lsqexit(1);
    }
    if (row_size_B == 0) {
      printf("Have no B records\nStop\n");
      fprintf(errfil,"Have no B records\nStop\n");
      lsqexit(1);
    }
/*
 *  estimate population A fraction from training sizes
 *  if parameter file does not specify that fraction
 */
    if (pop_A_fraction < 0.) {
      pop_A_fraction = row_size_A;
      z = row_count; 
      pop_A_fraction /= z;
      if (lsqscrflg == 1) {
        printf("Estimated fraction of A population: %4f\n",
               pop_A_fraction);
      }
    }

/*eject*/
/* 
 *  determine number of zeros in each row of log_rec[][]
 */
    for (i=2;i<=log_rec_count;i++) {
      nzeros_inrow_log_rec[i] = 0;
      if (log_rec[i][0] == BEGIN_B) {
        continue;
      }
      for (j=1;j<=col_count;j++) {
        if (log_rec[i][j] == 0) {
          nzeros_inrow_log_rec[i]++;
        }
      }
    }

    fclose(f1);
    return;
  } /* end of stage = 4 */

/*
 *  must be one of the above cases
 */
  lsqerror("get_log","402");

}

/*eject*/
/* -------------------------------------
 * remove_logrc(): remove nested records
 * -------------------------------------
 */
void remove_logrc() { 
  int i, j, k, nested1, nested2, nsame_A, nsame_B, same;
  double total_A, total_B;

  void lsqerror();

  bad_nested_flg = 0;

  if (lsqscrflg == 1) {
    printf("\n---------Check Nestedness of Records---------\n");
  }
  fprintf(errfil,
           "\n---------Check Nestedness of Records---------\n");


/*
 *  search for identical records in A and B
 */
  for (i=2; i<=row_end_A;i++) {  /* loop 1 */
    if (log_rec[i][0] != LSQBEG) {
      continue;
    }
    log_rec[i][0] = LSQSAME;
    nsame_A = 1;
    nsame_B = 0;
    for (j=i+1;j<=log_rec_count;j++) { /* loop 2 */
      if (log_rec[j][0]!=LSQBEG) {
        continue;
      }
/*
 *  check if records i and j are identical
 */
      same = 1;
      for (k=1;k<=col_count;k++) {
        if (log_rec[i][k] != log_rec[j][k]) {
          same = 0;
          break;
        }
      }
      if (same == 1) {
        log_rec[j][0] = LSQSAME;
        if (j <= row_end_A) {
          nsame_A++;
        } else {
          nsame_B++;
        }
      }
    } /* end loop 2 */
/*
 *  decide on deletion
 */
    if (nsame_B >= 1) { /* if 1 */
/*
 *  record i also occurs in B
 *  decide which records are to be deleted
 */
      bad_nested_flg = 1;
      total_A = nsame_A;
      total_B = nsame_B;
      total_A /= row_size_A;  
      total_B /= row_size_B;        
      total_A *= pop_A_fraction * cost_A_error;
      total_B *= (1.0-pop_A_fraction) * cost_B_error;

      if ((lsqscrflg == 1) || (rmnestedflg == 0)) {
        printf("Identical records:\n");
      }
      fprintf(errfil,"Identical records:\n");
/*
 *  delete or keep records using costs and rmnestedflg
 */        
      for (j=i;j<=log_rec_count;j++) { /* loop 3 */
        if (log_rec[j][0] == LSQSAME) { /* if 3 */
          if (j <= row_end_A) {
            if (lsqscrflg == 1) {
              printf("A record %4d, line %4d\n",
                     j-1,rec_filidx[j]);
            }
            fprintf(errfil,
                    "A record %4d, line %4d\n",
                    j-1,rec_filidx[j]);
          } else {
            if (lsqscrflg == 1) {
             printf("B record %4d, line %4d\n",
                    j-row_begin_B+1,rec_filidx[j]);
            }
            fprintf(errfil,
                     "B record %4d, line %4d\n",
                     j-row_begin_B+1,rec_filidx[j]);
          }
          if (rmnestedflg <= 1) {
            if (total_A >= total_B) {
              if (j <= row_end_A) {
                log_rec[j][0] = LSQFALSE; /* keep A record */
              } else {
               log_rec[j][0] = LSQTRUE; /* delete B record */
              }
            } else {
              if (j <= row_end_A) {
                log_rec[j][0] = LSQTRUE; /* delete A record */
              } else {
              log_rec[j][0] = LSQFALSE; /* keep B record */
              }
            }
          } else { /* rmnestedflg = 2 */
            log_rec[j][0] = LSQTRUE;
          }
        } /* end if 3 */
      } /* end loop 3 */

      if (rmnestedflg <= 1) {
        if (total_A >= total_B) {
          if (lsqscrflg == 1) {
            printf("    delete B record(s)\n");
          }
          fprintf(errfil,"    delete B record(s)\n");
        } else {
          if (lsqscrflg == 1) {
            printf("    delete A record(s)\n");
          }
          fprintf(errfil,"    delete A record(s)\n");
        } 
      } else { /* rmnestedflg = 2 */
        if (lsqscrflg == 1) {
          printf("    delete A and B records\n");
        }
        fprintf(errfil,"    delete A and B records\n");
      }

    } else { /* else of if 1 */
/*
 *  there are only identical A records
 */      
      for (j=i;j<=row_end_A;j++) {
        if (log_rec[j][0] == LSQSAME) {
          log_rec[j][0] = LSQFALSE;
        }
      }
    } /* end if 1 */
  } /* end loop 1 */
/*
 *  set all B records with LSQBEG to LSQFALSE
 */
  for (i=row_begin_B;i<=log_rec_count;i++) {
    if (log_rec[i][0] == LSQBEG) {
      log_rec[i][0] = LSQFALSE;
    }
  }
/*
 *  end of test for identical records
 */
 
/*
 *  nonnestedness definition of record j in record i:
 *
 *  if strongsepflg = 1:
 *    for some k, records j and i have opposite nonzero entries.
 *    Thus, log_rec[j][k]*log_rec[i][k] = -1
 *  if weaksepflg = 1:
 *    for some k,
 *    log_rec[j][k] =  1 and log_rec[i][k] !=  1
 *    or
 *    log_rec[j][k] = -1 and log_rec[i][k] != -1
 *
 *  Process as follows:
 *    find nested record pairs and
 *    delete record with larger number of zeros
 */
  if (lsqscrflg == 1) {
    printf("\nNested Records:\n");
  }
  fprintf(errfil,"\nNested Records:\n");

  for (i=2;i<=row_end_A;i++) { /* loop 10 */
    if (log_rec[i][0] == LSQTRUE) { /* record already deleted */
      continue;
    }
    for (j=row_begin_B;j<=log_rec_count;j++) { /* loop 11 */
      if (log_rec[j][0] == LSQTRUE) { /* record already deleted */
        continue;
      }
      nested1 = LSQTRUE;
      nested2 = LSQTRUE;
      if (strongsepflg == 1) { /* if 11 */
        for (k=1;k<=col_count;k++) {
          if (delete_var[k] != 0) {
            continue;
          }
          if ((log_rec[i][k] * log_rec[j][k]) == -1) { 
            nested1 = LSQFALSE;  /* not nested */
            nested2 = LSQFALSE;  /* not nested */
            break;
          }
        }
      } else { /* else of if 11 */
        for (k=1;k<=col_count;k++) {
          if (delete_var[k] != 0) {
            continue;
          }
          /* is record i not nested in record j ? */
          if (((log_rec[i][k] == 1) && 
               (log_rec[j][k] != 1)) ||
              ((log_rec[i][k] == -1 ) &&
               (log_rec[j][k] != -1))) {
            nested1 = LSQFALSE;  /* not nested */
            break;
          }
        }
        if (nested1 == LSQFALSE) {
          for (k=1;k<=col_count;k++) {
            if (delete_var[k] != 0) {
              continue;
            }
            /* is record j not nested in record i ? */
            if (((log_rec[j][k] == 1) && 
                 (log_rec[i][k] != 1)) ||
                ((log_rec[j][k] == -1 ) &&
                 (log_rec[i][k] != -1))) {
              nested2 = LSQFALSE; /* not nested */
              break;
            }
          }
        }
      } /* end if 11 */

      if ((nested1 == LSQTRUE) || (nested2 == LSQTRUE)) {
        bad_nested_flg = 1;
        if (lsqscrflg == 1) {
          printf("A record %4d, line %4d, and ",
                 i-1,rec_filidx[i]);
          printf("B record %4d, line %4d\n",
                 j-row_begin_B+1,rec_filidx[j]);
        }
        fprintf(errfil,"A record %4d, line %4d, and ",
                i-1,rec_filidx[i]);
        fprintf(errfil,"B record %4d, line %4d\n",
                j-row_begin_B+1,rec_filidx[j]);

/*
 *  delete record with larger number of zeros
 */
        if (nzeros_inrow_log_rec[i] < nzeros_inrow_log_rec[j]) {
          log_rec[j][0] = LSQTRUE; /* delete record j */
          if (lsqscrflg == 1) {
            printf("    delete B record\n");
          }
          fprintf(errfil,"    delete B record\n");
        } else {
          log_rec[i][0] = LSQTRUE; /* delete record i and stop */
                                   /* testing of record i */
          if (lsqscrflg == 1) {
            printf("    delete A record\n");
          }
          fprintf(errfil,"    delete A record\n");
          break;
        }            
      }     
    } /* loop 11 */

  } /* end loop 10 */


  if ((bad_nested_flg == 1) &&
      ((lsqscrflg == 1) || (rmnestedflg == 0))) {
    printf(
      "----------------------------------------------\n");
    printf(
      "At least one record in one of the sets A and B\n");
    printf(
      "is nested in a record of the  other  set;  all\n");
    printf(
      "such cases have been marked above and must  be\n");
    printf(
      "eliminated before separations can be  computed\n");
    printf(
      "That reduction is done below by lsqcc  if  the\n");
    printf(
      "file   lsqccparams.dat  specifies  the  option\n");
    printf(
      "'nestedness delete option = least cost' or 'all'\n\n");
/*
 * display of records that must be removed
 */
    printf(
      "-------------Records to be Removed------------\n");
    for (i=1;i<= log_rec_count;i++) {
      if (log_rec[i][0]==BEGIN_A) {
        printf("Records of A set:\n");
      } else if (log_rec[i][0]==BEGIN_B) {
        printf("Records of B set:\n");
      } else if (log_rec[i][0] == LSQTRUE ) {
        if (i <= row_end_A) {
          printf("  %4d, line %4d\n",i-1,rec_filidx[i]);
        } else {
          printf("  %4d, line %4d\n",
                 i-row_begin_B+1,rec_filidx[i]);
        }
      }
    }
    printf(
      "-----------End of Nestedness Checking---------\n\n");
  }
  if (bad_nested_flg == 1) {
    fprintf(errfil,
      "----------------------------------------------\n");
    fprintf(errfil,
      "At least one record in one of the sets A and B\n");
    fprintf(errfil,
      "is nested in a record of the  other  set;  all\n");
    fprintf(errfil,
      "such cases have been marked above and must  be\n");
    fprintf(errfil,
      "eliminated before separations can be  computed\n");
    fprintf(errfil,
      "That reduction is done below by lsqcc  if  the\n");
    fprintf(errfil,
      "file   lsqccparams.dat  specifies  the  option\n");
    fprintf(errfil,
      "'nestedness delete option = least cost' or 'all'\n\n");
    fprintf(errfil,
      "------------Records to be Removed-------------\n");
    for (i=1;i<= log_rec_count;i++) {
      if (log_rec[i][0]==BEGIN_A) {
        fprintf(errfil,"Records of A set:\n");
      } else if (log_rec[i][0]==BEGIN_B) {
        fprintf(errfil,"Records of B set:\n");
      } else if (log_rec[i][0] == LSQTRUE ) {
        if (i <= row_end_A) {
          fprintf(errfil,"  %4d, line %4d\n",i-1,rec_filidx[i]);
        } else {
          fprintf(errfil,"  %4d, line %4d\n",
                 i-row_begin_B+1,rec_filidx[i]);
        }
      }
    }
    fprintf(errfil,
      "----------End of Nestedness Checking----------\n\n");
  }
  return;

}
/*  last record of check_nested.c***** */






