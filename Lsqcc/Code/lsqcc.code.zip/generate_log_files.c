/*  first record of generate_log_files.c***** */
#include <stdio.h>
#include <string.h>
#include "lsqparms.h"
#include "lsqexts.h"

int  sub_A_log_rec[max_record_num + 1] [max_column_size + 1];
int  sub_A_rec_filidx[max_record_num + 1];
int  sub_A_rec_intidx[max_record_num + 1];
int  sub_B_log_rec[max_record_num + 1] [max_column_size + 1];
int  sub_B_rec_filidx[max_record_num + 1];
int  sub_B_rec_intidx[max_record_num + 1];

/*
 * index interpretation
 *
 * for X = A or B:
 *
 * sub_X_rec_filidx[j] = line where the 
 * record sub_X_log_rec[j][1..col_count] begins in the
 * training file
 *
 * sub_X_rec_intidx[j] = index for the record of the total
 * A or B set that is equal to the record  
 * sub_X_log_rec[j][1..col_count]
 */ 

int  sub_A_total,sub_B_total;

FILE *fp;
FILE *f1;
FILE *f2;
FILE *f5;
char s3[namesize];
char s4[namesize];
char s5[namesize];
char s6[namesize];
char s7[namesize];
char s8[namesize];
char s9[namesize];
char s10[namesize];
char s11[namesize];
char s12[namesize];
char s13[namesize];
char s14[namesize];  

/* ---------------------------------------------------
 *  generate_log_files(): generate all log files
 *  conceptually, there are six files for each pair of
 *  sets, as follows:
 *
 *  for separation of B subset from A subset:
 *  1 satisfiability problem
 *  2 minimization problems (1 for min size, 1 for max size)
 *
 *  for separation of B subset from A subset:
 *  1 satisfiability problem
 *  2 minimization problems (1 for min size, 1 for max size)
 *
 *  log files are produced for the min problems,
 *  but not for the sat or max problems.
 *  the sat problems are handled later by dropping the objective
 *  functions of the minimization problems, as needed.
 *  the max problems are trivial sat problems since the
 *  columns of the separation clauses are monotone and since
 *  all other clauses are ignored.
 *
 *  however, this routine still writes the names of the
 *  sat and max problems into the control file
 *  prb_set.cnl, to preserve the relationships between
 *  sets used for checking separations.
 * ---------------------------------------------------
 */
void generate_log_files() {

  int  i,j,k,l,n,nprb,srn;

  void con_logname(int,int);
  void con_sub_A(int,int);
  void con_sub_B(int,int);
  void lsqerror();
  char *pathing();

  nprb = 0; /* to suppress compiler warning message */
  srn  = 0; /* to suppress compiler warning message */

/*
 *  start prb_set.cnl and define srn
 */
  if ((fp = fopen(pathing("prb_set.cnl"),"w")) == NULL) {
    printf("\n Cannot open prb_set.cnl\n");
    fprintf(errfil,"\n Cannot open prb_set.cnl\n");
    lsqerror("generate_log_files","102");
  }
  if (fourtotalsepflg == 1) {
    nprb = 4;
    srn = 1;
  } else if (fortypartialsepflg == 1) {
    nprb = 40;
    srn = sub_range_num;
  } else {
    lsqerror("generate_log_files","104");
  }
  fprintf(fp,"%d\n",nprb);
    
/*
 *  caution:
 *  if the sequence of separation cases,
 *  as recorded below in prb_sep.cnl,
 *  is changed, must correspondingly change the sequence in 
 *  get_sep_set(), where the separations are retrieved for
 *  the computation of distributions.
 */

  for (l = 1; l <= separation_num; l++) {
    for (i = 1; i <= srn ; i++ ) {
       
      con_sub_A(l,i);
      con_sub_B(l,i); 
      con_logname(l,i);

/*  
 *  relationship between files and strings
 *  f2 - s4
 *  f5 - s7
 */
      if ((f2 = fopen(pathing(s4),"w")) == NULL) {
        printf("\n Cannot open file %s\n",pathing(s4));
        fprintf(errfil,"\n Cannot open file %s\n",pathing(s4));
        lsqerror("generate_log_files","204");
      }
      if ((f5 = fopen(pathing(s7),"w")) == NULL) {
        printf("\n Cannot open file %s\n",pathing(s7));
        fprintf(errfil,"\n Cannot open file %s\n",pathing(s7));
        lsqerror("generate_log_files","206");
      }
/*  
 *  case: nesting in B, clash with A
 */
      /* skip sat case                BiA_subAj_msat */
      fprintf(f2,"MINIMIZE\n");    /* BiA_subBj_smin */
      /* skip  max case               BiA_subBj_smax */
/*  
 *  case: nesting in A, clash with B
 */ 
      /* skip sat case                AiB_subBj_msat */  
      fprintf(f5,"MINIMIZE\n");    /* AiB_subAj_smin */
      /* skip  max case               AiB_subAj_smax */

      fprintf(f2,"%s\n",s10);      /* BiA_subBj_smin */
      fprintf(fp,"%s\n%s\n%s\n",s9,s10,s11);

      fprintf(f5,"%s\n",s13);      /* AiB_subAj_smin */
      fprintf(fp,"%s\n%s\n%s\n",s12,s13,s14);

/*
 *  include partial logic formulation of training file
 *  contained in partial_log_file
 *  the latter file has all set, predicate, variable
 *  definitions, FACTS statement, and any number of 
 *  logic statements
 */
      fprintf(f2,"INCLUDE partial_log_file\n");
      fprintf(f5,"INCLUDE partial_log_file\n");

/*
 *  below, the logic statements of the separations
 *  are added
 */
      for (k = 1 ; k <= sub_A_total ; k++ ){
        n = 0;
        for (j = 1 ; j <= col_count ; j++ ){
          if (((strongsepflg == 1) &&
               (sub_A_log_rec[k][j] == 1)) ||
              ((weaksepflg == 1) &&
               (sub_A_log_rec[k][j] >= 0))) {
            if (n == 0) {
              fprintf(f2,"%s",&neg_name_list[j][0]);
              n += strlen(&neg_name_list[j][0]);
            } else {
              fprintf(f2," | %s",&neg_name_list[j][0]);
              n += 3 + strlen(&neg_name_list[j][0]);
            }             
            if (n >= 60) {
              fprintf(f2,"\n");
              n = 1;
            }
          }
          if (((strongsepflg == 1) &&
               (sub_A_log_rec[k][j] == -1)) ||
              ((weaksepflg == 1) &&
               (sub_A_log_rec[k][j] <= 0))) {
            if (n == 0) {
              fprintf(f2,"%s",&pos_name_list[j][0]);
              n += strlen(&pos_name_list[j][0]);
            } else {
              fprintf(f2," | %s",&pos_name_list[j][0]);
              n += 3 + strlen(&pos_name_list[j][0]);
            }
            if (n >= 60) { 
              fprintf(f2,"\n");
              n = 1;
            }
          }
        }
        fprintf(f2,".\n");
      }
       
      for (k = 1; k <= sub_B_total ; k++ ) {
        n = 0;
        for (j = 1 ; j <= col_count ; j++ ) {
          if (((strongsepflg == 1) &&
               (sub_B_log_rec[k][j] == 1)) ||
              ((weaksepflg == 1) &&
               (sub_B_log_rec[k][j] >= 0))) {
            if (n == 0) {
              fprintf(f5,"%s",&neg_name_list[j][0]);
              n += strlen(&neg_name_list[j][0]);
            } else {
              fprintf(f5," | %s",&neg_name_list[j][0]);
              n += 3 + strlen(&neg_name_list[j][0]);
            }
            if (n >= 60) {
              fprintf(f5,"\n");
              n = 1;
            }
          }
          if (((strongsepflg == 1) &&
               (sub_B_log_rec[k][j] == -1)) ||
              ((weaksepflg == 1) &&
               (sub_B_log_rec[k][j] <= 0))) {
            if (n == 0) {                  
              fprintf(f5,"%s",&pos_name_list[j][0]);
              n += strlen(&pos_name_list[j][0]);
            } else {
              fprintf(f5," | %s",&pos_name_list[j][0]);
              n += 3 + strlen(&pos_name_list[j][0]);
            }
            if (n >= 60) {
              fprintf(f5,"\n");
              n = 1;
            }
          }                
        }
        fprintf(f5,".\n");
      }

      /*
       * fix AFORMULA and BFORMULA variables to True/False
       * depending on case
       * f2: separate B from A, hence B formulas
       *     are produced
       *     hence, BFORMULA = True and AFORMULA = False
       * f2: separate A from B, hence A formulas
       *     are produced
       *     hence, BFORMULA = False and AFORMULA = True
       */
      fprintf(f2,"BFORMULA.\n");
      fprintf(f2,"-AFORMULA.\n");
      fprintf(f5,"-BFORMULA.\n");
      fprintf(f5,"AFORMULA.\n"); 

      fprintf(f2,"ENDATA\n");
      fprintf(f5,"ENDATA\n");

      fclose(f2);
      fclose(f5);
    }
  }
  fclose(fp);
  return;

}

/*eject*/ 
/* ------------------------------------------------
 * con_logname(): create log file names
 * ------------------------------------------------
 */
void con_logname(int ind1, int ind2) {

  char s1[namesize];
  char s2[namesize];

/*
 *  BiA_subAj_msat
 *  sat case, uses A records for logic
 *  hence, separation nests in B and clashes with A
 */
  strcpy(s1,"B");
  sprintf(s2,"%d",ind1);
  strcat(s1,s2);
  strcat(s1,"A_subA");
  sprintf(s2,"%d",ind2);
  strcat(s1,s2);
  strcat(s1,"_msat");
  strcpy(s3,s1);
  strcat(s3,".log");
  strcpy(s9,s1);

/*
 *  BiA_subBj_smin
 *  min case, uses A records for logic
 *  hence, separation nests in B and clashes with A
 */
  strcpy(s1,"B");
  sprintf(s2,"%d",ind1);
  strcat(s1,s2);
  strcat(s1,"A_subB");
  sprintf(s2,"%d",ind2);
  strcat(s1,s2);
  strcat(s1,"_smin");
  strcpy(s4,s1);
  strcat(s4,".log");
  strcpy(s10,s1);

/*
 *  BiA_subBj_smax
 *  max case, uses A records for logic
 *  hence, separation nests in B and clashes with A
 */
  strcpy(s1,"B");
  sprintf(s2,"%d",ind1);
  strcat(s1,s2);
  strcat(s1,"A_subB");
  sprintf(s2,"%d",ind2);
  strcat(s1,s2);
  strcat(s1,"_smax");
  strcpy(s5,s1);
  strcat(s5,".log");
  strcpy(s11,s1);

/*
 *  AiB_subBj_msat
 *  sat case, uses B records for logic
 *  hence, separation nests in A and clashes with B
 */
  strcpy(s1,"A");
  sprintf(s2,"%d",ind1);
  strcat(s1,s2);
  strcat(s1,"B_subB");
  sprintf(s2,"%d",ind2);
  strcat(s1,s2);
  strcat(s1,"_msat");
  strcpy(s6,s1);
  strcat(s6,".log");
  strcpy(s12,s1);

/*
 *  AiB_subAj_smin
 *  min case, uses B records for logic
 *  hence, separation nests in A and clashes with B
 */
  strcpy(s1,"A");
  sprintf(s2,"%d",ind1);
  strcat(s1,s2);
  strcat(s1,"B_subA");
  sprintf(s2,"%d",ind2);
  strcat(s1,s2);
  strcat(s1,"_smin");
  strcpy(s7,s1);
  strcat(s7,".log");
  strcpy(s13,s1);

/*
 *  AiB_subAj_smax
 *  max case, uses B records for logic
 *  hence, separation nests in A and clashes with B
 */
  strcpy(s1,"A");
  sprintf(s2,"%d",ind1);
  strcat(s1,s2);
  strcat(s1,"B_subA");
  sprintf(s2,"%d",ind2);
  strcat(s1,s2);
  strcat(s1,"_smax");
  strcpy(s8,s1);
  strcat(s8,".log");
  strcpy(s14,s1);

  return;

}

/*eject*/
/* ------------------------------------------------
 * con_sub_A(): create sub_A record file
 * ------------------------------------------------
 */
void con_sub_A(int ind1, int ind2) {

  int i,j,col_num;
  char s1[namesize];
  char s2[namesize];

  void lsqerror();
  char *pathing();  

  strcpy(s1,"A");
  sprintf(s2,"%d",ind1);
  strcat(s1,s2);
  strcat(s1,"B_subA");
  sprintf(s2,"%d",ind2);
  strcat(s1,s2);
  strcat(s1,"_log.data");
  if ((f1 = fopen(pathing(s1),"r")) == NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("con_sub_A","102");
  }
  fscanf(f1,"%d",&sub_A_total);
  fscanf(f1,"%d",&col_num);
  for (i = 1; i <= sub_A_total; i++) {
    fscanf(f1,"%d",&sub_A_rec_filidx[i]);
    fscanf(f1,"%d",&sub_A_rec_intidx[i]);
    for (j = 1; j <= col_num ; j++) {
      fscanf(f1,"%d",&sub_A_log_rec[i][j]);
    }
  }
  fclose(f1);
  return;

}

/*eject*/
/* ------------------------------------------------
 * con_sub_B(): create sub_B record file
 * ------------------------------------------------
 */
void con_sub_B(int ind1, int ind2) {

  int i,j,col_num;
  char s1[namesize];
  char s2[namesize];

  void lsqerror();
  char *pathing();  
  
  strcpy(s1,"A");
  sprintf(s2,"%d",ind1);
  strcat(s1,s2);
  strcat(s1,"B_subB");
  sprintf(s2,"%d",ind2);
  strcat(s1,s2);
  strcat(s1,"_log.data");
  if ((f1 = fopen(pathing(s1),"r")) == NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("con_sub_B","102");
  }
  fscanf(f1,"%d",&sub_B_total);
  fscanf(f1,"%d",&col_num);
  for ( i = 1; i <= sub_B_total; i++) {
    fscanf(f1,"%d",&sub_B_rec_filidx[i]);
    fscanf(f1,"%d",&sub_B_rec_intidx[i]);
    for (j = 1; j <= col_num ; j++) {
      fscanf(f1,"%d",&sub_B_log_rec[i][j]);
    }
  }
  fclose(f1);
  return;

}
/*  last record of generate_log_files.c***** */



