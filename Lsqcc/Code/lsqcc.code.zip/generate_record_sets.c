/*  first record of generate_record_sets.c***** */ 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h"

int bucket_size[ buc_num + 1 ];
int buc_log_rec[buc_num + 1][max_buc_size + 1]
                [max_column_size + 1];
int buc_rec_filidx[buc_num + 1][max_buc_size + 1];
int buc_rec_intidx[buc_num + 1][max_buc_size + 1];

int A_log_rec[max_record_num + 1] [ max_column_size + 1];
int A_rec_filidx[max_record_num + 1];
int A_rec_intidx[max_record_num + 1];

int B_log_rec[max_record_num + 1] [ max_column_size + 1];
int B_rec_filidx[max_record_num + 1];
int B_rec_intidx[max_record_num + 1];

/*
 * index interpretation
 *
 * for buckets:
 *
 * buc_rec_filidx[i][j] = line where the 
 * record buc_log_rec[i][j][1..col_count] begins in the 
 * training file
 *
 * buc_rec_intidx[i][j] = j (thus, = index for the record j of
 * bucket i, which is  buc_log_rec[i][j][1..col_count]
 *
 * for X = A or B:
 *
 * X_rec_filidx[j] = line where the 
 * record X_log_rec[j][1..col_count] begins in the
 * training file
 *
 * X_rec_intidx[j] = index for the record of the total
 * A or B set that is equal to the record  
 * X_log_rec[j][1..col_count]
 */ 

int buc_l_a[ buc_num + 1 ][ sub_range_num + 1 ][4+1];
char s1[namesize],s2[namesize];
char s3[namesize],s4[namesize],s5[namesize];
char s6[namesize],s7[namesize],s8[namesize];
FILE *fp;

void gen_sub_bucket();
void get_inp_rec_data();
void gen_AB_sub_num();
void gen_AB_sub_rec();

void gen_sub_num_partial();
void gen_sub_num_total();

void gen_A();

void gen_B_partial();
void gen_B_total();

void get_Alogrc();
void get_Blogrc();
void lsqerror();
char *pathing();   

/* ---------------------------------------------------
 *  generate_record_sets(): generate A B buckets from 
 *  the input records for the various separations
 *
 *  the code of this subroutine allows for more than
 *  two sets A and B of records to be separated.
 *  below, each such set is called a bucket.
 *  in the file names, the index i refers to the ith
 *  bucket.
 *  the separation then classifies Ai versus the 
 *  union of the remaining Ak, which is called B here. 
 * ---------------------------------------------------
 */ 
void generate_record_sets() {

/*
 *  create the following files for all i
 *
 *  AiB_A_log.data
 *  AiB_B_log.data
 *  AiB_Asubrange.cnl
 *  AiB_Bsubrange.cnl
 */
  gen_sub_bucket();
  get_inp_rec_data();
  gen_AB_sub_num();

/*
 *  create the following files for all i and j
 *
 *    AiB_subAj_log.data (A subset)
 *    this file is also referenced under the 
 *    following names
 *      BiA_subAj_msat.data
 *      AiB_subAj_smin.data
 *      AiB_subAj_smax.data
 *
 *    AiB_subBj_log.data (B subset)
 *    this file is also referenced under the 
 *    following names
 *      AiB_subBj_msat.data
 *      BiA_subBj_smin.data
 *      BiA_subBj_smax.data
 */
  gen_AB_sub_rec();
  return;

}

/*eject*/
/* -----------------------------------------------------
 *  gen_A(): output records of A buckets
 * -----------------------------------------------------
 */
void gen_A(int A_bucket_num, int sep_ind) {
  int  i,j;
  char s1[namesize];
  FILE *f1;
  
  sprintf(s1,"A%dB_A_log.data",sep_ind);
  if ((f1 = fopen(pathing(s1),"w")) == NULL) {
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("gen_A","102");
  }
  fprintf(f1,"%d\n",bucket_size[A_bucket_num]);
  fprintf(f1,"%d\n",col_count);
  for ( i = 1 ; i <= bucket_size[A_bucket_num] ; i++) {
    fprintf(f1,"%d ",buc_rec_filidx[A_bucket_num][i]);
    fprintf(f1,"%d ",buc_rec_intidx[A_bucket_num][i]);
    for ( j = 1 ; j <= col_count ; j++) {
      fprintf(f1,"%d ",buc_log_rec[A_bucket_num][i][j]);
    }
    fprintf(f1,"\n");
  }
  fclose(f1);
  return;
}

/*eject*/
/* ---------------------------------------------
 *  gen_AB_sub_num(): output bucket information
 * ---------------------------------------------
 */
                          
void gen_AB_sub_num() {
  int i;
  int A_bucket_num;
  
  for ( i = 1 ; i <= separation_num ; i++) {
    A_bucket_num = i;
    gen_A(A_bucket_num, i);
    if (fourtotalsepflg == 1) {
      gen_B_total(A_bucket_num, i);
      gen_sub_num_total(A_bucket_num, i);
    } else if (fortypartialsepflg == 1) {
      gen_B_partial(A_bucket_num, i);
      gen_sub_num_partial(A_bucket_num, i);
    } else {
      lsqerror("gen_AB_sub_num","102");
    }
  }
  return;

}

/*eject*/
/* -----------------------------------------------------
 *  gen_AB_sub_rec(): construct the sub_A and sub_B 
 *  records for A and B for each separation                       
 *  INPUT:  AiB_A_log.data
 *          AiB_B_log.data
 *          AiB_Asubrange.cnl
 *          AiB_Bsubrange.cnl
 *  OUTPUT: AiB_subAj_log.data (A subset)
 *          this file is also referenced under the 
 *          following names
 *            BiA_subAj_msat.data
 *            AiB_subAj_smin.data
 *            AiB_subAj_smax.data
 *
 *          AiB_subBj_log.data (B subset)
 *          this file is also referenced under the 
 *          following names
 *            AiB_subBj_msat.data
 *            BiA_subBj_smin.data
 *            BiA_subBj_smax.data
 * ------------------------------------------------------
 */ 

void gen_AB_sub_rec() {

  int  i,j,k,l,r1,r2,r3,r4,srn;
  int sub_A_total,sub_B_total;
  char s1[namesize],s2[namesize];
  FILE *f1,*f2;

  srn = 0; /* to suppress compiler warning message */

  if (fourtotalsepflg == 1) {
    srn = 1;
  } else if (fortypartialsepflg == 1) {
    srn = sub_range_num;
  } else {
    lsqerror("gen_AB_sub_rec","102");
  }
  
  for (i = 1; i <= separation_num; i++) {
    get_Alogrc(i);
    strcpy(s1,"A");
    sprintf(s2,"%d",i);
    strcat(s1,s2);
    strcat(s1,"B_Asubrange.cnl");
    if ((f1 = fopen(pathing(s1),"r")) == NULL) {
      printf("Cannot open file %s\n",s1);
      fprintf(errfil,"Cannot open file %s\n",s1);
      lsqerror("gen_AB_sub_record","104");            
    }

    for (j = 1; j <= srn ; j++) {
      strcpy(s1,"A");
      sprintf(s2,"%d",i);
      strcat(s1,s2);
      strcat(s1,"B_subA");
      sprintf(s2,"%d",j);
      strcat(s1,s2);
      strcat(s1,"_log.data");
      if ((f2 = fopen(pathing(s1),"w")) == NULL){
        printf("Cannot open file %s\n",s1);
        fprintf(errfil,"Cannot open file %s\n",s1);
        lsqerror("gen_AB_sub_record","106");
      }

      fscanf(f1,"%d",&r1);
      fscanf(f1,"%d",&r2);
      fscanf(f1,"%d",&r3);
      fscanf(f1,"%d",&r4);
      if ((r3 == 0) && (r4 == 0)) {
        sub_A_total = r2 - r1 + 1;
      } else {
        sub_A_total = (r2 - r1 + 1) + (r4 - r3 + 1);
      }
              
      fprintf(f2,"%d\n",sub_A_total);
      fprintf(f2,"%d\n",col_count);
      for (k = r1; k <= r2; k++) {
        fprintf(f2,"%d ", A_rec_filidx[k]);
        fprintf(f2,"%d ", A_rec_intidx[k]);
        for ( l = 1; l <= col_count; l++){ 
          fprintf(f2,"%d ", A_log_rec[k][l]);
        }
        fprintf(f2,"\n");
      }

      if ((r3 != 0) && (r4 != 0)) {
        for (k = r3; k <= r4; k++) {
          fprintf(f2,"%d ", A_rec_filidx[k]);
          fprintf(f2,"%d ", A_rec_intidx[k]);
          for (l = 1; l <= col_count; l++) {
            fprintf(f2,"%d ", A_log_rec[k][l]);
          }
          fprintf(f2,"\n");
        }
      }
      fclose(f2);
    }   
    fclose(f1);

    get_Blogrc(i);
    strcpy(s1,"A");
    sprintf(s2,"%d",i);
    strcat(s1,s2);
    strcat(s1,"B_Bsubrange.cnl");
    if ((f1 = fopen(pathing(s1),"r")) == NULL) {
      printf("Cannot open file %s\n",s1);
      fprintf(errfil,"Cannot open file %s\n",s1);
      lsqerror("gen_AB_sub_record","202");
    }

    for (j = 1; j <= srn ; j++) {
      strcpy(s1,"A");
      sprintf(s2,"%d",i);
      strcat(s1,s2);
      strcat(s1,"B_subB");
      sprintf(s2,"%d",j);
      strcat(s1,s2);
      strcat(s1,"_log.data");
      if ((f2 = fopen(pathing(s1),"w")) == NULL) {
        printf("Cannot open file %s\n",s1);
        fprintf(errfil,"Cannot open file %s\n",s1);
        lsqerror("gen_AB_sub_record","204");
      }
      fscanf(f1,"%d",&r1);
      fscanf(f1,"%d",&r2);
      fscanf(f1,"%d",&r3);
      fscanf(f1,"%d",&r4);
      if ((r3 == 0) && (r4 == 0)) {
        sub_B_total = r2 - r1 + 1;
      } else {
        sub_B_total = (r2 - r1 + 1) + (r4 - r3 + 1);
      }
      fprintf(f2,"%d\n",sub_B_total);
      fprintf(f2,"%d\n",col_count);
      for (k = r1; k <= r2; k++) {
         fprintf(f2,"%d ", B_rec_filidx[k]);
         fprintf(f2,"%d ", B_rec_intidx[k]);
         for (l = 1; l <= col_count; l++){ 
           fprintf(f2,"%d ", B_log_rec[k][l]);
         }
         fprintf(f2,"\n");
      }
      if ((r3 != 0) && ( r4 != 0)) {
        for (k = r3; k <= r4; k++){
          fprintf(f2,"%d ", B_rec_filidx[k]);
          fprintf(f2,"%d ", B_rec_intidx[k]);
          for ( l = 1; l <= col_count; l++){
            fprintf(f2,"%d ", B_log_rec[k][l]);
          }
          fprintf(f2,"\n");
        }
      }
      fclose(f2);            
    }
    fclose(f1);
  }
  return;

}

/*eject*/
/* -----------------------------------------------------------
 *  gen_B_partial(): output records of B buckets, partial case
 * -----------------------------------------------------------
 */

void gen_B_partial(int A_bucket_num , int sep_ind) {

  int i,j,k,l,row_num;  
  char s1[namesize];
  FILE *f1;
  
  sprintf(s1,"A%dB_B_log.data",sep_ind);
  if ((f1 = fopen(pathing(s1),"w")) == NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("gen_B_partial","102");    
  }
  row_num = 0;
  for (i = 1; i <= buc_num; i++) {
    if (i != A_bucket_num) {
      row_num = row_num + bucket_size[i];
    }
  }
  fprintf(f1,"%d\n",row_num);
  fprintf(f1,"%d\n",col_count);

  for (i = 1; i <= 9; i++) {
    for (j = 1; j <= buc_num; j++) {
      if (j != A_bucket_num ) {
        for (k = buc_l_a[j][i][1]; 
             k <= (buc_l_a[j][i+1][1] - 1); k++) {
          fprintf(f1,"%d ",buc_rec_filidx[j][k]);
          fprintf(f1,"%d ",buc_rec_intidx[j][k]);
          for (l = 1; l <= col_count; l++){
            fprintf(f1,"%d ",buc_log_rec[j][k][l]);
          }
          fprintf(f1,"\n");
        }
      }
    }
  }

  for (i = 10; i <= 10; i++){
    for (j = 1; j <= buc_num; j++) {
      if (j != A_bucket_num) {
        for (k = buc_l_a[j][i][1]; 
             k <= buc_l_a[j][i][2]; k++) {
          fprintf(f1,"%d ",buc_rec_filidx[j][k]);
          fprintf(f1,"%d ",buc_rec_intidx[j][k]);
          for (l = 1; l <= col_count; l++){
            fprintf(f1,"%d ",buc_log_rec[j][k][l]);
          }
          fprintf(f1,"\n");
        }
      }
    }
  }

  fclose(f1);
  return;

}

/*eject*/
/* -----------------------------------------------------------
 *  gen_B_total(): output records of B buckets, total case
 * -----------------------------------------------------------
 */

void gen_B_total(int A_bucket_num , int sep_ind) {

  int i,j,k,row_num;  
  char s1[namesize];
  FILE *f1;
  
  sprintf(s1,"A%dB_B_log.data",sep_ind);
  if ((f1 = fopen(pathing(s1),"w")) == NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("gen_B_total","102");    
  }
  row_num = 0;
  for (i=1; i<=buc_num; i++) {
    if (i != A_bucket_num) {
      row_num = row_num + bucket_size[i];
    }
  }
  fprintf(f1,"%d\n",row_num);
  fprintf(f1,"%d\n",col_count);

  for (i=1; i<=buc_num; i++) {
    if (i != A_bucket_num) {
      for (j=1; j<=bucket_size[i]; j++) {
        fprintf(f1,"%d ",buc_rec_filidx[i][j]);
        fprintf(f1,"%d ",buc_rec_intidx[i][j]);
        for (k=1; k<=col_count; k++) {
          fprintf(f1,"%d ",buc_log_rec[i][j][k]);
        }
      fprintf(f1,"\n");
      }
    }
  }

  fclose(f1);
  return;

}

/*eject*/
/* ---------------------------------------------
 *  gen_sub_bucket(): generate index bounds for
 *  the record subsets defining the various 
 *  separations
 * ---------------------------------------------
 */
void gen_sub_bucket() {
  int i,j,k,l,A[11];
  int head,tail,unit,row_num,surplus;
  FILE *f1;

  if ((f1 = 
     fopen(pathing("bucket_separation.cnl"),"r")) == NULL){
    printf("Cannot open bucket_separation.cnl\n");
    fprintf(errfil,"Cannot open bucket_separation.cnl\n");
    lsqerror("gen_sub_bucket","102");
  }
  fscanf(f1,"%d",&row_num);
  for(i=1;i<=row_num;i++) {
    fscanf(f1,"%d",&head);
    fscanf(f1,"%d",&tail);
    bucket_size[i] = (tail - head + 1 );
  }
  fclose(f1);

/*
 *  rest only for partial separations
 */
  if (fourtotalsepflg == 1) {
    return;
  } else if (fortypartialsepflg == 1) {

    for(i=0;i<=buc_num;i++) {
      for(j=0;j<=sub_range_num;j++) {
        for(k=0;k<=4;k++) {
          buc_l_a[i][j][k] = 0;
        }
      }
    }
    for(i=1;i<=buc_num;i++) {
      l = bucket_size[i] ;
      unit = l/10;
      surplus = l%10;
      for(j=0;j<=10;j++) {
        A[j] = 0;
      }
      for(j=1;j<=10;j++) {
        A[j] = unit;
      }
      for(j=1;j<=surplus;j++) {
        if (j<=5) {
          A[2 * j-1] = A[2 * j-1] + 1;
        } else {
          k=j-5;
          A[2 * k] = A[2 * k] + 1;
        }
      }
      for (j = 2 ; j <= 10; j++) {
        A[j] = A[j-1] + A[j];
      }
      for (j = 1 ; j <= 10 ; j++) {
        if (j <= 5) {
          buc_l_a[i][j][1] = A[j-1]+1;
          buc_l_a[i][j][2] = A[j+5];
          buc_l_a[i][j][3] = 0;
          buc_l_a[i][j][4] = 0;
        } else {
          k = (j+5)%10;
          buc_l_a[i][j][1] = A[j-1]+1;
          buc_l_a[i][j][2] = A[10];
          buc_l_a[i][j][3] = 1;
          buc_l_a[i][j][4] = A[k];
        }
      }
    }
  } else {
    lsqerror("gen_sub_bucket","202");
  }
  return;

}

/*eject*/
/* -----------------------------------------------------
 *  gen_sub_num_partial(): output files 
 *  AiB_Asubrange.cnl and AiB_Bsubrange.cnl,
 *  partial case
 * -----------------------------------------------------
 */
void gen_sub_num_partial(int A_bucket_num, int sep_ind) {
  int i,j,k,l,A[11],unit,surplus;
  char s1[namesize];
  FILE *f1;

/*
 *  print AiB_Asubrange.cnl file
 */

  l = bucket_size[A_bucket_num];
  unit = l/10;
  surplus = l%10;
  for (j = 0 ; j <= 10 ; j++) {
    A[j] = 0;
  }
  for (j = 1 ; j <= 10 ; j++) {
    A[j] = unit;
  }
  for (j = 1 ; j <= surplus ; j++) {
    if ( j <= 5) {
      A[2 * j-1] = A[2 * j-1] + 1;
    } else {
      k = j - 5;
      A[2 * k] = A[2 * k] + 1;
    }
  }
  for (j = 2 ; j <= 10; j++) {
    A[j] = A[j-1] + A[j];
  }

  sprintf(s1,"A%dB_Asubrange.cnl",sep_ind);
  if ((f1 = fopen(pathing(s1),"w"))== NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("gen_sub_num_partial","102");
  }
  for (j = 1; j <= 10 ; j++) {
    if (j <= 5) {
      fprintf(f1,"%3d %3d %3d %3d\n",(A[j-1]+1),A[j+5],0,0);
		
    } else {
      k = (j+5)%10;
      fprintf(f1,"%3d %3d %3d %3d\n",(A[j-1]+1),A[10],1,A[k]);
    }
  }
  fclose(f1);

/* 
 * print AiB_Bsubrange.cnl file
 */
  l = 0;
  for (i = 1 ; i <= buc_num ; i++) {
    if (i != A_bucket_num ) {
      l = l + bucket_size[i];
    }
  } 
  for (j = 0 ; j <= 10 ; j++) {
    A[j] = 0;
  }

  unit = l/10;
  surplus = l%10;
  for (j = 0 ; j <= 10 ; j++) {
    A[j] = 0;
  }
  for (j = 1 ; j <= 10 ; j++) {
    A[j] = unit;
  }
  for (j = 1 ; j <= surplus ; j++) {
    if ( j <= 5) {
      A[2 * j-1] = A[2 * j-1] + 1;
    } else {
      k = j - 5;
      A[2 * k] = A[2 * k] + 1;
    }
  }
  for (j = 2 ; j <= 10; j++) {
    A[j] = A[j-1] + A[j];
  }

  sprintf(s1,"A%dB_Bsubrange.cnl",sep_ind);
  if ((f1 = fopen(pathing(s1),"w"))== NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("gen_sub_num_partial","202");
  }

  for (j = 1; j <= 10 ; j++) {
    if (j <= 5) {
      fprintf(f1,"%3d %3d %3d %3d\n",(A[j-1]+1),A[j+5],0,0);
    } else {
      k = (j+5)%10;
      fprintf(f1,"%3d %3d %3d %3d\n",(A[j-1]+1),A[10],1,A[k]);
    }
  }

  fclose(f1);
  return;

}

/*eject*/
/* -----------------------------------------------------
 *  gen_sub_num_total(): output files 
 *  AiB_Asubrange.cnl and AiB_Bsubrange.cnl,
 *  total case
 * -----------------------------------------------------
 */
void gen_sub_num_total(int A_bucket_num, int sep_ind) {
  int i,l;
  char s1[namesize];
  FILE *f1;

/*
 *  print AiB_Asubrange.cnl file
 */

  l = bucket_size[A_bucket_num];

  sprintf(s1,"A%dB_Asubrange.cnl",sep_ind);
  if ((f1 = fopen(pathing(s1),"w"))== NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("gen_sub_num_total","102");
  }
  fprintf(f1,"%3d %3d %3d %3d\n",1,bucket_size[A_bucket_num],0,0);
  fclose(f1);

/* 
 * print AiB_Bsubrange.cnl file
 */
  l = 0;
  for (i = 1 ; i <= buc_num ; i++) {
    if (i != A_bucket_num ) {
      l = l + bucket_size[i];
    }
  }

  sprintf(s1,"A%dB_Bsubrange.cnl",sep_ind);
  if ((f1 = fopen(pathing(s1),"w"))== NULL){
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("gen_sub_num_total","202");
  }
  fprintf(f1,"%3d %3d %3d %3d\n",1,l,0,0);
  fclose(f1);
  return;

}

/*eject*/
/* -----------------------------------------
 *  get_Alogrc(): get A records
 * -----------------------------------------
 */
void get_Alogrc(int ind) {

  int i,j;
  int row_size,col_size;
  char s1[namesize];
  char s2[namesize];

  FILE *f1;
 
  strcpy(s1,"A");
  sprintf(s2,"%d",ind);
  strcat(s1,s2);
  strcat(s1,"B_A_log.data");
  if ((f1 = fopen(pathing(s1),"r")) == NULL) {
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("get_Alogrc","102");
  }

  fscanf(f1,"%d",&row_size);
  fscanf(f1,"%d",&col_size);
  for ( i = 1; i<= row_size; i++) {
    fscanf(f1,"%d",&A_rec_filidx[i]);
    fscanf(f1,"%d",&A_rec_intidx[i]);
    for (j = 1; j<= col_size; j++){
      fscanf(f1,"%d",&A_log_rec[i][j]);
    }
  }
  fclose(f1);
  return;

}

/*eject*/
/* -----------------------------------------
 *  get_Blogrc(): get B records
 * -----------------------------------------
 */
void get_Blogrc(int ind)
{
  int i,j;
  int col_size,row_size;
  char s1[namesize];
  char s2[namesize];

  FILE *f1;
  
  strcpy(s1,"A");
  sprintf(s2,"%d",ind);
  strcat(s1,s2);
  strcat(s1,"B_B_log.data");
  if ((f1 = fopen(pathing(s1),"r")) == NULL) {
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot opening %s\n",s1);
    lsqerror("get_Blogrc","102");
  }

  fscanf(f1,"%d",&row_size);
  fscanf(f1,"%d",&col_size);
  for (i = 1; i<= row_size; i++) {
    fscanf(f1,"%d",&B_rec_filidx[i]);
    fscanf(f1,"%d",&B_rec_intidx[i]);
    for (j = 1; j<= col_size; j++){
      fscanf(f1,"%d",&B_log_rec[i][j]);
    }
  }
  fclose(f1);
  return;

}

/*eject*/
/* -----------------------------------------------------
 *  get_inp_rec_data(): get input records in ll_raw_log.data
 * -----------------------------------------------------
 */
void get_inp_rec_data() {
  int i,j,k,row_num,col_num;
  FILE *f1;

  void lsqexit();

  if ((f1 = fopen(pathing("ll_raw_log.data"),"r")) == NULL) {
    printf("Cannot open ll_raw_log.data\n");
    fprintf(errfil,"Cannot open ll_raw_log.data\n");
    lsqerror("get_inp_rec_data","102");
    lsqexit(1);
  }
  fscanf(f1,"%d",&row_num);
  fscanf(f1,"%d",&col_num);
  for (i = 1 ; i <= buc_num ; i++) {
    for (j = 1 ; j <= bucket_size[i] ; j++) {
      fscanf(f1,"%d",&buc_rec_filidx[i][j]);
      buc_rec_intidx[i][j] = j; 
      for (k = 1 ; k <= col_count ; k++) {
        fscanf(f1,"%d",&buc_log_rec[i][j][k]);
      }
    }
  }
  fclose(f1);
  return;

}             
/*  last record of generate_record_sets.c***** */
