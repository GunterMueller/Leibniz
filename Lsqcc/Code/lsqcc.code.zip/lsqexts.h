/* first record of lsqexts.h *****/
extern FILE *errfil; /* file is defined by Leibniz System or */
                     /* in tstccmain.c                       */

#define abs(x)   ((x) >= 0 ? (x) : -(x))
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))

/* Lsqcc System definitions */
extern int  disprocessflg;
extern int  trnprocessflg;
extern int  tstprocessflg;
extern int  lsqscrflg;
extern int  rmnestedflg;
extern int  fourtotalsepflg;
extern int  fortypartialsepflg;
extern int  globalfourtotalsepflg;
extern int  globalfortypartialsepflg;
extern int  strongsepflg;
extern int  weaksepflg;
extern int  shortsepflg;
extern int  optcstsepflg;
extern int  triviallogflg;
extern int  optreconlyflg;
extern int  triviallogflg;
extern int  pyrsuccessflg; 
extern int  pyrminmaxuseflg; 
extern int  pyrnumberselectflg;
extern int  evalformulaflg;
extern int  litfrequencyflg;

extern char lsqccparamsname[256];
extern char lsqver[4+1];
extern char lsqworkarea[256];
extern char lsqtraindir[256];

extern char filename_wo_ext[256];
extern char distribution_file[256];
extern char optimization_file[256]; 
extern char separation_file[256];
extern char testing_file[256];
extern char training_file[256];
extern char training_file_wo_dir[256];
extern char vote_file[256];
extern char pyramid_file[256];
extern char pyrpred_file[256];

extern char trnext_nodot[nameextsize + 1];

extern int  col_count;
extern int  row_count;
extern int  init_row_size_A;
extern int  init_row_size_B;
extern int  del_rows_A;
extern int  del_rows_B;
extern int  est_row_size_A;
extern int  est_row_size_B;
extern int  log_rec_count;
extern int  filesize;

extern char log_name_list[max_column_size + 1][58 + 1];
extern char pos_name_list[max_column_size + 1][58 + 1];
extern char neg_name_list[max_column_size + 1][58 + 1];
extern int  pos_var_cst[max_column_size + 1];
extern int  neg_var_cst[max_column_size + 1];

extern int  pos_name_idx[max_column_size + 1];
extern int  neg_name_idx[max_column_size + 1];

extern float cost_A_error;
extern float cost_B_error;
extern float lsqlambda;
extern float pop_A_fraction;

extern int  lsqdelta;

extern int  log_rec[max_record_num + 2 + 1]
                   [max_column_size + 1];
extern int  nzeros_inrow_log_rec[max_record_num + 2 + 1];
extern int  rec_filidx[max_record_num + 2 +1];
struct{
  float pos;
  float neg;
  float zero;
} typedef prob_cases;
extern prob_cases prob_of_entry[max_column_size + 1]; 
extern int  sep_l_a[separation_num + 1][sub_range_num + 1][4+1];
extern int  sep_l_b[separation_num + 1][sub_range_num + 1][4+1];
extern int  delete_var[max_column_size + 1];

extern int  sep_rec[4*sub_range_num + 1]
            [sep_set_size + 1]
            [max_column_size + 1];

extern float normDistr[42];

struct{
  int count;
  float prob;
  float zvalue;
  float imp;
} typedef sep_rec_facts;
extern sep_rec_facts sep_rec_stat[4*sub_range_num + 1][sep_set_size + 1];
struct{
  float freq;
  float signif;
} typedef lit_imp;
extern lit_imp lit_importance[4+1][max_column_size+1][2];

extern char formula_type[4*sub_range_num+ 1][2];
extern char record[10*max_column_size + 1];

extern int  formula_count;
extern int  formula_index;

extern int  sep_use[max_column_size + 1]; 
extern int  sep_tmp[max_column_size + 1];

extern int  lit_freq[4*sub_range_num + 1][max_column_size + 1][2];

extern int  pyr_form_count;
extern int  pyr_form_index;
extern int  pyr_col_count;

extern int  pyr_rec[max_pyr_count + 1]
            [sep_set_size + 1]
            [max_column_size + 1];

extern char pyr_name_list[max_column_size + 1][58+1];

extern int pyr_obj_val[max_pyr_count + 1];

extern int pyr_blk_var[max_column_size + 1];
extern int blk_var;
extern int pyr_blk_cls[sep_set_size + 1];
extern int blk_cls;

/* last record of lsqexts.h *****/




