/*  first record of tstcc.c***** */
/*
 *   Leibniz System: Lsqcc System
 *   Copyright 2004 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * =====================================================
 * Lsqcc Learning Logic - Callable Testing Version tstcc
 * =====================================================
 *
 *  tests data of testing file using separations of 
 *  separations file
 * -----------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h" 
/* corresponding lsqdefs.h is included in lsqutil.c */

void tstcc() {
/*
 *  callable version of testing logic program tstcc
 *  caution: 
 *   - parameters must have been obtained (see lsqgetparm() for
 *   - required information)
 *   - errfil must have been opened
 *  caution: these conditions are not checked by program
 *
 *  for details about the handling of col_count and pyr_col_count,
 *  see lsqcc.c
 */

  FILE *f1;

  void add_pyr_values();
  void compute_votes();
  void consistency_pyrvar_sepvar();
  void get_pyrrc();
  void get_seprc();
  void get_tstrc();
  void lsqexit();



  if (lsqscrflg == 1) {
    printf("\nCompute votes\n");
  }
/*
 *  read the variables and separations of the separation file 
 *  into log_name_list[][] and sep_rec[][][]
 */
  get_seprc();

/*
 *  if pyramid file exists, read pyramid variables and formulas
 *  into pyr_name_list[][] and pyr_rec[][][]
 */
  if ((f1 = fopen(pyramid_file,"r")) != NULL) {
    fclose(f1);
    get_pyrrc();
  } else {
    pyr_form_count = 0;
  }
/*
 *  check consistency of pyramid variables and
 *  separation variables
 */
  consistency_pyrvar_sepvar();

/*
 *  read the logic test records into log_rec[][]
 */
  get_tstrc();

/*
 *  use pyramid to expand records
 */
  if (pyr_form_count > 0) {
    add_pyr_values(&row_count);
  }

/*
 *  compute and output votes
 */
  compute_votes();
  if (lsqscrflg == 1) {
    printf("\n");
    printf("*** Votes are in file =\n    %s\n\n", 
           vote_file);
  }
  return;

}

/*eject*/

/* 
 * -----------------------------------------
 * compute_votes(): compute and output votes 
 * -----------------------------------------
 */
void compute_votes() {

  int  clash,i,i4,iform,jsep,jvar,jvarsigned,ksign,n;
  int  lit,minval,nest,rec,undecided,term;
  float x, y;
  char explain_size[namesize];

  float fac,lb,ub;
  int flg,ir,lir,uir;

  struct{
    int all;
    int min;
    int max;
    int Amin;
    int Bmin;
  } typedef voteclass;
  voteclass vote,psum,nsum,zsum;

/* 
 * variables below are initialized to suppress compiler warning
 */
  int  weakest_record_count = 0;
  int  weakest_record_line = 0; 
  int  weakest_record_vote = 0;

  FILE *f1;

  void rec_entry_probabilities();
  void random_process_mean_var();
  void valuesNormDistr();
  void lsqerror();
  void lsqexit();

/*
 *  open vote file and print header line
 */
  if ((f1 = fopen(vote_file,"w")) == NULL){
    printf("Cannot open vote file:\n %s\n",vote_file);
    printf("Stop\n");
    fprintf(errfil,
       "Cannot open vote file:\n %s\n",vote_file);
    fprintf(errfil,"Stop\n");
    lsqerror("compute_votes","102");
  }

/*  litfrequencyflg for output of usage frequency of literals
 *  litfrequencyflg = 0: do not output usage frequency
 *                       of literals making formulas True
 *                       for testing records
 *                  = 1: output usage frequency
 *  litfrequencyflg is set in lsqgetparm()
 *
 *  set lit_freq[][][] array to 0
 */
  if (litfrequencyflg == 1) {
    for (iform=1;iform<=formula_count;iform++) {
      for (jvar=1;jvar<=col_count;jvar++) {
        for (ksign=0;ksign<=1;ksign++) {
          lit_freq[iform][jvar][ksign] = 0;
        }
      }
    }
  }

  nest = 0;      /* added to suppress compiler warning message */
  minval = 0;    /* added to suppress compiler warning message */
  vote.all = 0;  /* added to suppress compiler warning message */
  vote.min = 0;  /* added to suppress compiler warning message */
  vote.max = 0;  /* added to suppress compiler warning message */
  vote.Amin = 0; /* added to suppress compiler warning message */
  vote.Bmin = 0; /* added to suppress compiler warning message */

/*eject*/

  if (strongsepflg == 1) {

    fprintf(f1,"\n%s%s%s%s",
    "Part 1 Counts\n\n",
    "The vote counts below list Undecided cases separately.\n",
    "These vote counts should not be used in connection with\n",
    "probability distributions of the vote total.\n");
    fprintf(f1,"\n%s%s",
     "  Record     Vote    Undecided |         Range        |\n",
     "Count Line                     | Low Vote   High Vote |\n");

/*
 *  loop through all test records
 */
    for (rec=1;rec<=row_count;rec++) {
      vote.all = 0;
      undecided = 0;
      for (iform=1;iform<=formula_count;iform++) {
        clash = 0;
        for (jsep=1;jsep<=sep_rec[iform][0][0];jsep++) {
          nest = 1;
          for (lit=1;lit<=sep_rec[iform][jsep][0];lit++) {
            term = sep_rec[iform][jsep][lit]*
                   log_rec[rec][abs(sep_rec[iform][jsep][lit])];
            if (term < 0) {
              clash++;
              nest = 0;
              break;
            }
            if (term <= 0) {
              nest = 0;
            }
          } /* end of lit loop */
          if (nest == 1) {
              break;
          }
        } /* end of jsep loop */
        if (clash == sep_rec[iform][0][0]) {
          nest = -1;
        }
        if (nest == 0) {
          undecided++;
        } else {
          if (((nest == 1) &&
             (strcmp(&formula_type[iform][0],"A") == 0)) || 
            ((nest == -1) &&
             (strcmp(&formula_type[iform][0],"B") == 0))) {
          vote.all++;
          } else {
          vote.all--;
          }
        }
      } /* end of iform loop */
/*
 *  output vote and undecided for record
 */
      fprintf(f1,
       "%d %5d    %3d      %3d     |   %3d         %3d    |\n",
       rec, rec_filidx[rec],vote.all,undecided,
       vote.all-undecided,vote.all+undecided);

    } /* end of rec loop */
    fprintf(f1,"\n\n%s%s%s%s\n",
    "Part 2 Counts\n\n",
    "The vote counts below consider each Undecided value\n",
    "as False and therefore can be used in connection with\n",
    "probability distributions of the vote total.\n");
  }

/*eject*/

  if ((strongsepflg == 1) ||
      (weaksepflg == 1)) {
    if (evalformulaflg == 1) {
      fprintf(f1,"  Record          Votes of Formulas\n");
      fprintf(f1,"Count Line    All   Min   Max   Amin  Bmin\n");
    } else {
      fprintf(f1,"  Record     Vote\n");
      fprintf(f1,"Count Line\n");
    }
    psum.all = 0;
    nsum.all = 0;
    zsum.all = 0;
    psum.min = 0;
    nsum.min = 0;
    zsum.min = 0;
    psum.max = 0;
    nsum.max = 0;
    zsum.max = 0;
    psum.Amin = 0;
    nsum.Amin = 0;
    zsum.Amin = 0;
    psum.Bmin = 0;
    nsum.Bmin = 0;
    zsum.Bmin = 0;
    for (iform = 1; iform <= formula_count; iform++) {
      for (jsep = 1; jsep <= sep_rec[iform][0][0]; jsep++) {
        sep_rec_stat[iform][jsep].count = 0;
      }
    }

/*
 *  evalformulaflg flag for evaluation method of formulas
 *  evalformulaflg  = 1: 1 vote if for min or max formula
 *                         all lit's = True
 *                  = 2: 1 vote for
 *                       min if all lit's = True
 *                       max if all lit's of min and 50% of add'l
 *                              lit's = True
 *                  = 3: 2 votes for min max pair of formulas
 *                       if all lit's of min and 50% of add'l
 *                       lit's = True
 *  caution: evaluation change only affects process below
 *           and does not affect the process above
 *  caution: usage frequency of literals is calculated only if
 *           evalformulaflg  = 1
 *  evalformulaflg is set in lsqgetparm()
 */

/*
 *  loop through all test records
 */
    for (rec=1;rec<=row_count;rec++) {
      if (evalformulaflg == 1) {
        vote.all = 0;
        vote.min = 0;
        vote.max = 0;
        vote.Amin = 0;
        vote.Bmin = 0;

        for (iform=1;iform<=formula_count;iform++) {
          for (jsep=1;jsep<=sep_rec[iform][0][0];jsep++) {
            nest = 1;
            for (lit=1;lit<=sep_rec[iform][jsep][0];lit++) {
              if (sep_rec[iform][jsep][lit]*
                  log_rec[rec]
                          [abs(sep_rec[iform][jsep][lit])] <= 0) {
                 nest = 0;
                 break;
              }
            } /* end of lit loop */
            if (nest == 1) {
                break;
            }
          } /* end of sep loop */     
          if (((nest == 1) &&
               (strcmp(&formula_type[iform][0],"A") == 0)) || 
              ((nest == 0) &&
               (strcmp(&formula_type[iform][0],"B") == 0))) {
            vote.all++;
            if (iform%2 == 1) {         /* min formula */
              vote.min++;
            } else {                    /* max formula */
              vote.max++;
            }
            if (iform%4 == 3) {         /* Amin formula */
              vote.Amin++;
            } else if (iform%4 == 1) {  /* Bmin formula */
              vote.Bmin++;
            }
          } else {
            vote.all--;
            if (iform%2 == 1) {         /* min formula */
              vote.min--;
            } else {                    /* max formula */
              vote.max--;
            }
            if (iform%4 == 3) {         /* Amin formula */
              vote.Amin--;
            } else if (iform%4 == 1) {  /* Bmin formula */
              vote.Bmin--;
            }

          }
          /* collect usage of separation                        */
          /* collect usage frequency of literals                */
          /* caution: correctness relies on the fact that the   */
          /*          case 'nest = 1' always causes 'break' in  */
          /*          above jsep loop. Hence current jsep value */
          /*          is index of clause producing 'nest = 1'   */
          if ((nest == 1) && (litfrequencyflg == 1)) {
            sep_rec_stat[iform][jsep].count++;
            for (lit=1;lit<=sep_rec[iform][jsep][0];lit++) {
              if (sep_rec[iform][jsep][lit] > 0) {
                ksign = 0;
              } else {
                ksign = 1;
              }
              lit_freq[iform]
                [abs(sep_rec[iform][jsep][lit])][ksign]++;
            }
          }
        } /* end of iform loop */
      } else if (evalformulaflg >= 2) {
        vote.all = 0;
        for (iform=1;iform<=formula_count;iform++) {
          for (jsep=1;jsep<=sep_rec[iform][0][0];jsep++) {
            nest = 0;
            for (lit=1;lit<=sep_rec[iform][jsep][0];lit++) {
              if (sep_rec[iform][jsep][lit]*
                  log_rec[rec]
                          [abs(sep_rec[iform][jsep][lit])] > 0) {
                 nest++;
              }
            } /* end of lit loop */
            if (iform%2 == 1) {  /* min formula */
              if (nest == sep_rec[iform][jsep][0]) {
                minval = 1;
                break;
              } else {
                minval = 0;
                nest = 0;
              }
            } else { /* max formula */
              /* define separation = True if all lit's of */
              /* min case and 50% of add'l lit's = True   */
              if ((minval == 1) &
                  (nest >= ((sep_rec[iform-1][jsep][0] +
                            sep_rec[iform][jsep][0])/2))) {
                break;
              } else {
                nest = 0;
              }
            }               
          } /* end of sep loop */
          if (evalformulaflg == 2) {     
            if (((nest >= 1) &&
                 (strcmp(&formula_type[iform][0],"A") == 0)) || 
                ((nest == 0) &&
                 (strcmp(&formula_type[iform][0],"B") == 0))) {
              vote.all++;
            } else {
              vote.all--;
            }
          } else if (evalformulaflg == 3) {
            if (iform%2 == 0) {
              if (((nest >= 1) &&
                   (strcmp(&formula_type[iform][0],"A") == 0)) || 
                  ((nest == 0) &&
                   (strcmp(&formula_type[iform][0],"B") == 0))) {
                vote.all += 2;
              } else {
                vote.all -= 2;
              }
	    }

          } else {
            lsqerror("compute_votes","202");
          } 
        } /* end of iform loop */
      } else {
        lsqerror("compute_votes","204");
      } /* end of 'if (evalformulaflg == 1)' */
/*
 *  output vote for record, update sum of votes 
 */
      if (evalformulaflg == 1) {
        fprintf(f1,"%4d %5d    %3d   %3d   %3d   %3d   %3d",
                rec,rec_filidx[rec],
                vote.all,vote.min,vote.max,vote.Amin,vote.Bmin);
        if ((formula_count == 4) &&
            (vote.Amin == 1) &&
            (vote.Bmin == -1)) {
          fprintf(f1,"  Amin = Bmin = True\n");
        } else {
          fprintf(f1,"\n");
        }
      } else {
        fprintf(f1,"%4d %5d    %3d\n",rec,rec_filidx[rec],vote.all);
      }
      if (vote.all > 0) {
        psum.all++;
      } else if (vote.all == 0) {
        zsum.all++;
      } else {
        nsum.all++;
      }
      if (vote.min > 0) {
        psum.min++;
      } else if (vote.min == 0) {
        zsum.min++;
      } else {
        nsum.min++;
      }
      if (vote.max > 0) {
        psum.max++;
      } else if (vote.max == 0) {
        zsum.max++;
      } else {
        nsum.max++;
      }
      if (vote.Amin > 0) {
        psum.Amin++;
      } else if (vote.Amin == 0) {
        zsum.Amin++;
      } else {
        nsum.Amin++;
      }
      if (vote.Bmin > 0) {
        psum.Bmin++;
      } else if (vote.Bmin == 0) {
        zsum.Bmin++;
      } else {
        nsum.Bmin++;
      }
/*
 *  update weakest vote
 */
      if ((rec == 1) | (abs(weakest_record_vote) > abs(vote.all))) {
        weakest_record_count = rec;
        weakest_record_line = rec_filidx[rec];
        weakest_record_vote = vote.all;
      }
    }

/*eject*/

/*
 *  output vote counts
 */
    n = psum.all+nsum.all+zsum.all;
    if (evalformulaflg == 1) {
      if ((n != (psum.min+nsum.min+zsum.min))    ||
          (n != (psum.max+nsum.max+zsum.max))    ||
          (n != (psum.Amin+nsum.Amin+zsum.Amin)) ||
          (n != (psum.Bmin+nsum.Bmin+zsum.Bmin))) {
        lsqerror("compute_votes","301");
      }
      fprintf(f1,
         "\n\nVoting of Formulas        All  Min  Max  Amin Bmin\n");
      fprintf(f1,      "No. of positive votes  = %4d %4d %4d %4d %4d\n",
              psum.all,psum.min,psum.max,psum.Amin,psum.Bmin);
      fprintf(f1,      "No. of zero votes      = %4d %4d %4d %4d %4d\n",
              zsum.all,zsum.min,zsum.max,zsum.Amin,zsum.Bmin);
      fprintf(f1,      "No. of negative votes  = %4d %4d %4d %4d %4d\n\n",
              nsum.all,nsum.min,nsum.max,nsum.Amin,nsum.Bmin);
      fprintf(f1,      "Total no. of votes     = %4d %4d %4d %4d %4d\n\n",
              n,n,n,n,n);
    } else {
      fprintf(f1,"\n\n\nVoting of Formulas\n");
      fprintf(f1,"\n\n\nNo. of positive votes  = %4d\n",psum.all);
      fprintf(f1,      "No. of zero votes      = %4d\n",zsum.all);
      fprintf(f1,      "No. of negative votes  = %4d\n\n",nsum.all);
      fprintf(f1,      "Total no. of votes     = %4d\n\n",n);    
    }
  } else {
    lsqerror("compute_votes","302");
  }

/*
 *  output weakest vote information
 */
  fprintf(f1,"\n");
  fprintf(f1,"Record With Smallest Absolute Vote\n");
  fprintf(f1,"Count = %4d\n",weakest_record_count);
  fprintf(f1,"Line  = %4d\n",weakest_record_line);
  fprintf(f1,"Vote  = %4d\n\n\n\n",weakest_record_vote);

/*eject*/

/*
 *  output usage frequency and significance of literals and clauses
 */
  if (litfrequencyflg == 1) {
    fprintf(f1,
    "CAUTION: Frequencies and significance values below may\n");
    fprintf(f1,
    "be used only if the testing data contain A and B cases\n");
    fprintf(f1,
    "approximately in the same proportion as the training\n");
    fprintf(f1,
    "data that produced the separations\n\n");

/*
 *  compute probabilities for entries in testing records
 */
    rec_entry_probabilities();

/*
 *  compute normal distribution values
 */
    valuesNormDistr();

/*
 *  estimate the following:
 *    probability of a separation becoming true
 *    for a testing record; mean and sigma of normal
 *    approximation of related random 0/1 selection process;
 *    z value of count of true cases; prob[actual count 
 *    of true cases <= current count using z value], which
 *    is the probability that separation is important
 */
    random_process_mean_var();

/*
 *  initialize frequency counts and significance values
 *  of lit_importance array
 */
    for (i4=1;i4<=4;i4++) {
      for (jvar=1;jvar<=col_count;jvar++) {
        for (ksign=0;ksign<=1;ksign++) {
          lit_importance[i4][jvar][ksign].freq = 0.;
          lit_importance[i4][jvar][ksign].signif = 0.;
        }
      }
    }

    fprintf(f1,
      "Number of records = %d\n",row_count);
    fprintf(f1,
      "Estimated number of A records = %d\n",est_row_size_A);
    fprintf(f1,
      "Estimated number of B records = %d\n\n",est_row_size_B);
    if (formula_count == 4) {
      fprintf(f1,"\n");
      fprintf(f1,
     "ARP Probability, True Count, and Significance of Clauses\n\n");
      for (iform=1;iform<=formula_count;iform++) {
        if (iform%2 == 1) {
          strcpy(explain_size,"min");
        } else {
          strcpy(explain_size,"max");
        }
        fprintf(f1,"Formula %d %s %d %s ",
	     iform,&formula_type[iform][0],sep_rec[iform][0][0],
             explain_size);
        fprintf(f1,"(True means vote for %s, ",
             &formula_type[iform][0]);
        fprintf(f1,"%d %s size clause(s))\n",
             sep_rec[iform][0][0],explain_size);
        fprintf(f1,"Clause  ARP Prob  True Count  Significance\n");
        for (jsep = 1; jsep <= sep_rec[iform][0][0]; jsep++) {
          fprintf(f1,"  %2d      %4.2f      %5d         %4.2f\n",
           jsep,
	   sep_rec_stat[iform][jsep].prob,
           sep_rec_stat[iform][jsep].count,
           sep_rec_stat[iform][jsep].imp);
        }
      }
    }
      
    for (iform=1;iform<=formula_count;iform++) {
      for (jvar=1;jvar<=col_count;jvar++) {
        for (ksign=0;ksign<=1;ksign++) {
          if (ksign == 0) {
            jvarsigned = jvar;
          } else {
            jvarsigned = -jvar;
          }

          x = 0.0; /* x is probability that literal defined */
                   /* by jvar and ksign is important      */
          for (jsep = 1; jsep <= sep_rec[iform][0][0]; jsep++) {
            for (lit = 1; lit <= sep_rec[iform][jsep][0]; lit++) {
              if (sep_rec[iform][jsep][lit] == jvarsigned) {   
                x = max(x, sep_rec_stat[iform][jsep].imp);
              }
            }
          }
          if ((iform%4 == 0) || (iform%4 == 3)) { /* A formula */
            y = (float)lit_freq[iform][jvar][ksign]/
                (float)est_row_size_A;
          } else { /* B formula */
            y = (float)lit_freq[iform][jvar][ksign]/
                (float)est_row_size_B;
          }
          i4 = (iform-1)%4 + 1;
          lit_importance[i4][jvar][ksign].freq += y;
          lit_importance[i4][jvar][ksign].signif += x;
        } /* end of ksign loop */
      } /* end of jvar loop */
    } /* end of iform loop */

    for (i4 = 1; i4 <= 4; i4++) {
      for (jvar = 1;jvar <= col_count;jvar++) {
        for (ksign=0;ksign<=1;ksign++) {
          lit_importance[i4][jvar][ksign].freq /= 
	    (float)formula_count /4.0;
          lit_importance[i4][jvar][ksign].signif /= 
	    (float)formula_count /4.0;
        }
      }
    }

    for (jvar=1;jvar<=col_count;jvar++) {
      for (ksign=0;ksign<=1;ksign++) {
        lit_importance[0][jvar][ksign].freq = 
	  max(lit_importance[1][jvar][ksign].freq,
              lit_importance[3][jvar][ksign].freq);
        lit_importance[0][jvar][ksign].signif = 
	  max(lit_importance[1][jvar][ksign].signif,
              lit_importance[3][jvar][ksign].signif);
      } /* end of ksign loop */
    } /* end of jvar loop */

    for (flg=1;flg<=2;flg++) {
      fprintf(f1,"\n\n");
      if (flg==1) {
        fprintf(f1,"Frequency of Literals\n\n");
        fprintf(f1,"Literal             Frequency\n");
      } else {
        fprintf(f1,"Significance of Literals\n\n");
        fprintf(f1,"Literal             Significance\n");
      }
      uir = 100;
      lir = 1;
      fac = 0.01;
      for (ir=uir;ir>=lir;ir--) {
        if (ir < uir) {
          ub = (float)ir * fac;
        } else {
          ub = 99999.0;
        }
        lb = ((float)ir - 1.0) * fac;
        for (jvar=1;jvar<=col_count;jvar++) {
          for (ksign=0;ksign<=1;ksign++) {
            if (((flg == 1) && 
                 (lit_importance[0][jvar][ksign].freq < ub) &&
                 (lit_importance[0][jvar][ksign].freq >= lb)) ||
                ((flg == 2) && 
                 (lit_importance[0][jvar][ksign].signif < ub) &&
                 (lit_importance[0][jvar][ksign].signif >= lb))) {
              fprintf(f1," %s ",&log_name_list[jvar][0]);
              if (ksign ==0) {
                fprintf(f1,"+ ");
                jvarsigned = jvar;
              } else {
                fprintf(f1,"- ");
                jvarsigned = -jvar;
              }
              for (i=strlen(&log_name_list[jvar][0])+3;i<=20;i++) {
                fprintf(f1," ");
              }
              if (flg == 1) {
                fprintf(f1," %4.2f\n",
                           lit_importance[0][jvar][ksign].freq);
              } else {
                fprintf(f1," %4.2f\n",
                           lit_importance[0][jvar][ksign].signif);
              }
	    }
          } /* end of ksign loop */ 
        } /* end of jvar loop */
      } /* end of ir loop */
    } /* end of flg loop */

  } /* end of 'if (litfrequencyflg == 1)' */

/*
 *  done with processing of records
 */
  fclose(f1); 
  return;

}

/*eject*/

/* 
 * -----------------------------------
 * get_tstrc(): read the    
 * logic test records into log_rec[][] 
 * -----------------------------------
 */
void get_tstrc() {

  int i,j,k,kpos,left,n,stage;

  char s1[namesize + 1];

  FILE *f1;

  void lsqerror();
  void lsqexit();
  int  nextentry();

  if ((f1 = fopen(testing_file,"r")) == NULL){
    printf("Cannot open testing file:\n %s\n",testing_file);
    printf("Stop\n");
    fprintf(errfil,
       "Cannot open testing file:\n %s\n",testing_file);
    fprintf(errfil,"Stop\n");
    lsqexit(1);
  }
  filesize = 0;
  row_count = 0;
  stage = 20;

/*
 *  top of loop
 */
  zz105:;
/*
 *  read record from file
 */
  if (fgets(record,256,f1)==NULL) {
    printf("Unexpected end of testing file:\n");
    printf("%s\n",testing_file);
    printf("File must terminate with ENDATA record\n"); 
    printf("Stop\n");
    fprintf(errfil,"Unexpected end of testing file:\n");
    fprintf(errfil,"%s\n",testing_file);
    fprintf(errfil,"File must terminate with ENDATA record\n");
    fprintf(errfil,"Stop\n");
    lsqexit(1);
  }
  filesize++;
  kpos = -1;
/*
 *  eliminate comments
 */
  n = strlen(record)-1;
  for (j=0;j<=n;j++) {
    if (record[j] == '*') {
      record[j] = '\0';
      break;
    }
  }

/*
 *  test for blank record
 */
  k = -1;
  if (nextentry(&k,record) == -1) {
    /* have blank line */
    goto zz105;
  }
/*
 *  have k >= 0 due to nextentry call
 */
  sscanf(&record[k],"%s",s1);

 zz205:;
/*
 *  stage = 20: begin processing of next test record
 */
  if (stage == 20) { 
/*
 *  ENDATA case
 */
    if (strcmp(s1,"ENDATA")==0) {
      fclose(f1);
      if (lsqscrflg == 1) {
        printf("Testing file:\n");
        printf("Number of records   = %d\n",row_count);
      }
      return;
    }
/*
 *  increment row_count, check for max allowed size
 */
    row_count++;
    if ((row_count) > max_record_num) {
      printf(
        "Total number of records in testing file\n");
      printf(
          "cannot exceed %d\nStop\n",max_record_num+1);
      fprintf(errfil,
          "Total number of records in testing file\n");
      fprintf(errfil,
          "cannot exceed %d\nStop\n",max_record_num+1);
      lsqexit(1);
    }

/*
 *  rec_filidx[row_count] = line number in test file
 */
    rec_filidx[row_count] = filesize;

/*
 *  insert flag value LSQFALSE into position 0 of record 
 *  the flag is used in add_pyr_values() and is consistent
 *  with the flag utilized in check_nested() and its subroutines
 */
    log_rec[row_count][0] = LSQFALSE; 

/*
 *  zero out log_rec[row_count][j>=1]
 */
    for (j=1;j<=col_count;j++) {
      log_rec[row_count][j] = 0;
    }
    stage = 21;
  } /* end of stage 20 */
   
/*
 *  stage = 21: process record entries
 */
  if (stage == 21) {
/*
 *  get next entry
 */
    if (nextentry(&kpos,record) == -1) {
      /*  have read all entries of line */ 
      goto zz105;
    }
/* 
 * put entry into s1 
 */
    sscanf(&record[kpos],"%s",s1);

/*
 * handle termination period
 */

  if (s1[strlen(s1)-1] == '.') {
    if (strlen(s1) == 1) {
      /*  s1 is "." */
      stage = 20;
      goto zz105;  
    }
    /*  move period in record to the right and adjust s1 */
      strcpy(&record[kpos+strlen(s1)-1]," .");
      s1[strlen(s1)-1] = '\0';
    }

/* 
 *  check for negation symbol
 */
    if (s1[0] == '-') {
      left = 1;
    } else {
      left = 0;
    }

/*
 *  find name in log_name_list[][]
 */
    for (i=1;i<=col_count;i++) {
      if (strcmp(&s1[left],&log_name_list[i][0]) == 0) {
	/*
	 *  check for duplicate entry in record
	 */
        if (log_rec[row_count][i] != 0) {
          printf(
            "Duplicate entry for variable: %s \n",
            &log_name_list[i][0]);
          printf(
            "in a test record; see lines: %d - %d\nStop\n",
            rec_filidx[row_count],filesize);
          fprintf(errfil,
            "Duplicate entry for variable: %s \n",
            &log_name_list[i][0]);
          fprintf(errfil,
            "in a test record; see lines: %d - %d\nStop\n",
            rec_filidx[row_count],filesize);
          exit(1);
        }  
        if (left == 0) {
          log_rec[row_count][i] = 1;
        } else {
          log_rec[row_count][i] = -1;
        }
        goto zz205;
      }
    }
    /*
     *  unkown variable name
     */
    printf(
      "Unknown variable: %s on line: %d\nStop\n",
      &s1[left],filesize);
    fprintf(errfil,
      "Unknown variable: %s on line: %d\nStop\n",
      &s1[left],filesize);
    exit(1);
 
  } /* end of stage = 21 */

/*
 *  must be one of the above cases
 */
  lsqerror("get_tstrc","502");

}

/***************************************************************
 *  rec_entry_probabilities(): Compute probabilities for positive,
 *  negative, and zero entries in testing records of log_rec array
 */
void rec_entry_probabilities() {

  int i, npos, nneg, nzero, rec;

/*
 *  compute probabilities from testing records
 */

  for (i=1;i <= col_count; i++) {
    npos = 0;
    nneg = 0;
    nzero = 0;

    for (rec = 1; rec <= row_count; rec++) {
      if (log_rec[rec][i] == 1) {
        npos++;
      } else if (log_rec[rec][i] == -1) {
        nneg++;
      } else {
        nzero++;
      }
    }

    prob_of_entry[i].pos = (float)npos/(float)row_count;
    prob_of_entry[i].neg = (float)nneg/(float)row_count;
    prob_of_entry[i].zero = (float)nzero/(float)row_count;
  }

/*
 *  compute estimates for number of A and B records for testing records
 *  using counts from training data, contained in separation file
 */
  est_row_size_A =
    (float)row_count * (float)init_row_size_A/
    ((float)init_row_size_A + (float)init_row_size_B) + 0.5;
  est_row_size_B =
    (float)row_count * (float)init_row_size_B/
    ((float)init_row_size_A + (float)init_row_size_B) + 0.5;

}

/********************************************************
 *  random_process_mean_var(): Estimate the following:
 *    probability of a separation becoming True for a 
 *    testing record, assuming independence
 *    of the individual probabilities of the record entries;
 *    mean and sigma of normal approximation of related random 
 *    0/1 selection process;
 *    1 - prob[actual count of true cases >= current count using zvalue]
 */
void random_process_mean_var() {

  int iform, jsep, lit, k, zi;
  float p, mu, sigma, sigma2; 
  float probmin1, probmin2, probmin3; /* March 19, 2007 */

  void lsqerror();

  p = 0.0; /* to suppress compiler warning */

  for (iform = 1; iform <= formula_count; iform++) {

    for  (jsep = 1; jsep <= sep_rec[iform][0][0]; jsep++) {
      if (iform%2 == 1 ) { /* min formula; probability is computed */
                           /* via probabilities of record entries  */
        sep_rec_stat[iform][jsep].prob = 1.0;
        probmin1 = 1.0;
        probmin2 = 1.0;
        probmin3 = 1.0;
        for (lit = 1; lit <= sep_rec[iform][jsep][0]; lit++) {
	  /* March 19, 2007 begin 
	   * probability = 
           * product of smallest lit probabilities
	   */
          k = abs(sep_rec[iform][jsep][lit]);
	  if (sep_rec[iform][jsep][lit] > 0) {
	    p = prob_of_entry[k].pos;
	  } else if (sep_rec[iform][jsep][lit] < 0) {
	    p = prob_of_entry[k].neg;
	  }
	  /* May 10, 2007: introduce lower bound of 0.4 on p */
	  if (p < 0.40) {
	    p = 0.40;
	  }
	  /* May 10, 2007: end of change */
          if (p <= probmin1) {
            probmin3 = probmin2;
            probmin2 = probmin1;
            probmin1 = p;
          } else if (p <= probmin2) {
            probmin3 = probmin2;
            probmin2 = p;
          } else if (p < probmin3) {
            probmin3 = p;          
          }  /* March 19, 2007 end */
	  /*
	   * old code: probability = product of all lit probabilities
	   *         
	   * if (sep_rec[iform][jsep][lit] > 0) {
	   *   sep_rec_stat[iform][jsep].prob *= prob_of_entry[k].pos;
	   * } else if (sep_rec[iform][jsep][lit] < 0) {
	   * sep_rec_stat[iform][jsep].prob *= prob_of_entry[k].neg;
	   * }
	   */
        } /* end lit loop */

        /* March 19, 2007 begin */
        if (probmin1 == 1.0) {
          /* May 30, 2007 begin */
          /* lsqerror("random_process_mean_var","102"); */
          /* write warning into error file that prob = 1 */
          /* and lower p value */
          if (lsqscrflg == 1) {
            printf(
             "WARNING: probmin1 = 1.0 in random_process_mean_var\n");
            printf(
             "Ignore warning if testing A file or B file\n");
          }
          fprintf(errfil,
             "WARNING: probmin1 = 1.0 in random_process_mean_var\n");
          fprintf(errfil,
             "Ignore warning if testing A file or B file\n");
	  probmin1 = 0.99;
	  /* May 30 end */
        }
        sep_rec_stat[iform][jsep].prob =
             probmin1 * probmin2; 
	  /* probmin1 * probmin2 * probmin3; */ /* alternate formula */
       /* March 19, 2007 end */

      } else { /* max formula; probability is same */
               /* as for corresponding min formula */
        sep_rec_stat[iform][jsep].prob = 
          sep_rec_stat[iform-1][jsep].prob;
      }
      /* caution: the statement below currently has no effect
       *          since the lower bound on p (see above) is 0.4
       */            
      if (sep_rec_stat[iform][jsep].prob < 0.1) { 
        /* prob is too small, increase to 0.1 */
        sep_rec_stat[iform][jsep].prob = 0.1;
      }
/*
 *  estimate mean and variance of number of times  that
 *  separation jsep satisfies a record of the testing data,
 *  assuming random 0/1 process with above probability
 */
      p = sep_rec_stat[iform][jsep].prob;
      if ((iform%4 == 3) || (iform%4 == 0)) { 
        /* Amin or Amax formula */
        mu = (float)est_row_size_A * p;
        sigma2 = (float)est_row_size_A * p * (1-p);
      } else {
        /* Bmin or Bmax formula */
        mu = (float)est_row_size_B * p;
        sigma2 = (float)est_row_size_B * p * (1-p);
      }
      sigma = sqrt(sigma2);
      sep_rec_stat[iform][jsep].zvalue = 
        ((float)sep_rec_stat[iform][jsep].count - mu)/sigma;
      if (sep_rec_stat[iform][jsep].zvalue > 4.0) {
        sep_rec_stat[iform][jsep].zvalue = 4.0;
      } else if (sep_rec_stat[iform][jsep].zvalue < -4.0) {
        sep_rec_stat[iform][jsep].zvalue = -4.0;
      }
/*
 *  compute normal distr. prob. corresponding to zvalue,
 *  which estimates the probability that the clause is
 *  important
 */
      if (sep_rec_stat[iform][jsep].zvalue >= 0) {
        zi = 10.0*(sep_rec_stat[iform][jsep].zvalue+0.05);
        sep_rec_stat[iform][jsep].imp = normDistr[zi];
      } else {
        zi = 10.0*(-sep_rec_stat[iform][jsep].zvalue+0.05);
        sep_rec_stat[iform][jsep].imp = 1.0 - normDistr[zi];
      }
    } /* end jsep loop */
  } /* end iform loop */
}

/**********************************************************
 * valuesNormDistr(): computes values of the 
 * normal distribution with mean = 0 and sigma = 1
 * for positive values
 * the values are stored as normDist[zi], which is the
 * distribution value for the z value = (float)zi /10.0,
 * for 0 <= zi <= 41 
 */
void valuesNormDistr(){
  int i;
  float y,ym1,sum;

  for (i=1;i<=41;i++) {
    y = (float)i / 10.0;
    ym1 = ((float)i - 1.0)/ 10.0;
    normDistr[i] = 0.1 * (1.0/sqrt(2.0*3.14159)) *
      (exp(-.5*y*y)+exp(-.5*ym1*ym1))/2.0;
  }

/* 
 *  Add up area values and normalize
 */
  sum = 0.0;
  for (i=1;i<=41;i++) {
    sum += normDistr[i];
  }

/* 
 *  normalize to total of 0.5 
 */
  for (i=1;i<=41;i++) {
    normDistr[i] *= 0.5/sum;
  }
/* 
 *  compute distribution values 
 */
  normDistr[0] = 0.5;
  for (i=1;i<=41;i++) {
    normDistr[i] += normDistr[i-1];
  } 

}
/******************************************************************/

/*  last record of tstcc.c***** */
