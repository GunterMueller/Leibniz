/*  first record of stat_distributions.c***** */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h"



/* ---------------------------------------------------
 *  stat_distributions(): compute error distribution
 *  and output both vote and error distributions
 * ---------------------------------------------------
 */
void stat_distributions() {

  int i,k,n1;
  float x1,y1;
  char s1[namesize];
  float expected_total, min_expected_total;
  int min_threshold;

  FILE *f1,*f2;

  void lsqerror();
  char * pathing();


/*  write the vote distribution data into the file 
 *  distribution_file
 */
  if ((f1 = fopen(distribution_file,"w")) == NULL) {
    printf("\n Cannot open distribution file: %s. Stop\n\n",
           distribution_file);
    fprintf(errfil,
           "\n Cannot open distribution file: %s. Stop\n\n",
           distribution_file);
    lsqerror("stat_distributions","102");
  }

  for (k=1;k<=separation_num;k++) {

    sprintf(s1,"qaqb_train_sep%d.data",k);
    if ((f2 = fopen(pathing(s1),"r")) == NULL) {
      printf("Cannot open qaqb_train_sep%d.data\n",k);
      fprintf(errfil,"Cannot open qaqb_train_sep%d.data\n",k);
      lsqerror("stat_distributions","202");
    }

    fprintf(f1,"    Conditional Distributions of Votes\n");
    fprintf(f1,"-----------------------------------------\n");
    fprintf(f1,"Notation\n");
    fprintf(f1," F_A(z) = P(Vote < z | A record)\n");
    fprintf(f1," G_A(z) = P(Vote > z | A record)\n");
    fprintf(f1," F_B(z) = P(Vote < z | B record)\n");
    fprintf(f1," G_B(z) = P(Vote > z | B record)\n");
    fprintf(f1,"-----------------------------------------\n"); 
    fprintf(f1,"  z   F_A(z)   G_A(z)    F_B(z)    G_B(z)\n");
    fprintf(f1,"-----------------------------------------\n");
 
    for (i=1;i<=42;i++) {
      fscanf(f2," %d  %f  %f ",&n1,&x1,&y1);
      fprintf(f1,"%3d   %5.3f    %5.3f     %5.3f     %5.3f \n",
                 n1,x1,(1.-x1),(1.-y1),y1);
    }
    fprintf(f1,"-----------------------------------------\n");
  
    fprintf(f1,"\n");

    fprintf(f1,"\n");
    fprintf(f1,"        Conditional Error Probabilities and  \n");
    fprintf(f1,"                Expected Error Costs         \n");
    fprintf(f1,
    "--------------------------------------------------------\n");
    fprintf(f1,"Prior_P(record is in population A) = %5.3f\n",
               pop_A_fraction);
    fprintf(f1,"Prior_P(record is in population B) = %5.3f\n",
               (1.-pop_A_fraction));
    fprintf(f1,"Cost of type A error               = %9.2f\n",
               cost_A_error);
    fprintf(f1,"Cost of type B error               = %9.2f\n",
               cost_B_error);
    fprintf(f1,
    "--------------------------------------------------------\n");
    fprintf(f1,"Notation\n");
    fprintf(f1,"P_Aerr(z)  = P(type A error if z = threshold)\n");
    fprintf(f1,"           = F_A(z) * Prior_P(record in A)\n");
    fprintf(f1,"P_Berr(z)  = P(type B error if z = threshold)\n");
    fprintf(f1,"           = G_B(z) * Prior_P(record in B)\n");
    fprintf(f1,"E_Acost(z) = expected cost of record due to\n");
    fprintf(f1,"                type A error if z = threshold\n");
    fprintf(f1,"           = P_Aerr(z) * cost of type A error\n");
    fprintf(f1,"E_Bcost(z) = expected cost of record due to\n");
    fprintf(f1,"                type B error if z = threshold\n");
    fprintf(f1,"           = P_Berr(z) * cost of type B error\n");
    fprintf(f1,"E_Rcost(z) = expected cost of record due to\n");
    fprintf(f1,
         "                type A or B error if z = threshold\n");
    fprintf(f1,"           = E_Acost + E_Bcost\n");
    fprintf(f1,
    "--------------------------------------------------------\n");
    fprintf(f1,
   "  z P_Aerr(z) P_Berr(z) E_Acost(z) E_Bcost(z) E_Rcost(z)\n");
    fprintf(f1,
    "--------------------------------------------------------\n");

    min_expected_total = 0;
    min_threshold = 0;
    for (i=1;i<=42;i++) {
      fscanf(f2," %d  %f  %f ", &n1,&x1,&y1);
      expected_total =  x1*cost_A_error+y1*cost_B_error;
      if ((i == 1) | (min_expected_total > expected_total) |
	  ((min_expected_total == expected_total) & (n1 < 0))) {
	min_expected_total = expected_total;
	min_threshold = n1;
      }
     fprintf(f1,
     "%3d  %5.3f      %5.3f  %9.2f  %9.2f  %9.2f\n",
                  n1,x1,y1,x1*cost_A_error,y1*cost_B_error,
                  expected_total);
    }
    fprintf(f1,
    "--------------------------------------------------------\n");
    fprintf(f1,"\n");

    fprintf(f1,"Minimum expected total cost = %9.2f\n",
	    min_expected_total);
    fprintf(f1,"Optimal threshold           =    %3d\n\n",
	    min_threshold);
    fprintf(f1,
    "--------------------------------------------------------\n");
    fprintf(f1,"\n");
    fprintf(f1,"Training Set A:\n");
    fprintf(f1,"Input number of A training records = %4d\n",
	    init_row_size_A);
    fprintf(f1,"Deleted due to nestedness          = %4d\n",
	    del_rows_A);
    fprintf(f1,"Used for training of separations   = %4d\n\n",
	    init_row_size_A-del_rows_A);
    fprintf(f1,"Training Set B:\n");
    fprintf(f1,"Input number of B training records = %4d\n",
	    init_row_size_B);
    fprintf(f1,"Deleted due to nestedness          = %4d\n",
	    del_rows_B);
    fprintf(f1,"Used for training of separations   = %4d\n\n",
	    init_row_size_B-del_rows_B);
    fprintf(f1,
    "--------------------------------------------------------\n");
    fclose(f2);
  }
  fclose(f1);
  return;

}

/*  last record of stat_distributions.c***** */



