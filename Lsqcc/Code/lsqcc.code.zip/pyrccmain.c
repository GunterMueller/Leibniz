/*  first record of pyrccmain.c***** */
/*
 *   Leibniz System: Lsqcc System
 *   Copyright 2004 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * ===================================================
 * Lsqcc System - Pyramid Building Program pyrccmain
 * ===================================================
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h" /* lsqdefs.h is in lsqutil.c */

int main(int argc, char *argv[]) {

  void  alloc_leib_pyr();
  void  lsqexit();
  void  lsqgetparm();
  void  pyrcc();

/* lsqccparams file name option 
 *  if no name given, use default "lsqccparams.dat" 
 */
  if (argc == 2 && strcmp(argv[1],"") != 0) {
    strcpy(lsqccparamsname,argv[1]);
  } else {
    strcpy(lsqccparamsname,"lsqccparams.dat");
  }

/*
 *  open error file and allocate leibniz arrays
 */
  alloc_leib_pyr();

/*
 *  get parameters from file lsqccparams.dat
 */      
  lsqgetparm();

/*
 *  build pyramid
 */
  pyrcc();

  lsqexit(0);
  exit(0); /* to suppress compiler error message */
}

/*eject*/
/* ----------------------------------------------------------
 * void alloc_leib_pyr(): allocate for leibniz system
 * and define error limits.
 * ---------------------------------------------------------- 
 */
void alloc_leib_pyr() {

  #include "leibnizmacro.h"

  void lsqerror();

  strcpy(name,"pyrcc.err");
  value[0] = 1;                        
  value[1] = max_pyr_col;
  value[2] = max_pyr_row;
  value[3] = max_pyr_anz;
  value[4] = 5;
  value[5] = 2;
  value[6] = 2;

  assign_device();
  if (errcde[0] != 0) {
    lsqerror("alloc_leib_pyr","102");
  }

/* assign leibniz error limits so that leibniz system does not
 * stop due to the limits. instead, after each leibniz
 * command, check errcde[0] for error code and stop process
 * if any warning, nonfatal error, or error is detected.
 * display code with error message so that error can be
 * analyzed.
 */
  value[0] = 10; /* limit for number of warnings        */      
  value[1] = 10; /* limit for number of nonfatal errors */
  value[2] = 10; /* limit for number of fatal errors    */
  limit_error();
  if (errcde[0] != 0) {
    lsqerror("alloc_leib_pyr","104");
  }

  return;

}


/*  last record of pyrccmain.c***** */
