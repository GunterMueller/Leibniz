/*  first record of stat_mu_sig.c***** */
#include <stdio.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h"

int    m_16_star[35+1];
int    m_40_star[43+1];
double Qa[42+1];
double Qb[42+1];
double Pa[42+1];
double Pb[42+1];
double A_MU[separation_num+1];
double A_SIG[separation_num+1];
double B_MU[separation_num+1];
double B_SIG[separation_num+1];
int    Train_A_record_num[separation_num+1];
int    Train_B_record_num[separation_num+1];
int    A_sixteen_vote[max_record_num+1];
double A_mu_head;
double A_sig_head;
double A_new_mu_head;
double A_new_sig_head;
double A_x_head[35+1];
double A_y[35+1];
double A_mu;
double A_sig;
double A_Px[35+1];
double A_odd_Px[18+1];
int    A_Px_ind[35+1];
int    B_sixteen_vote[max_record_num+1];
double B_mu_head;
double B_sig_head;
double B_new_mu_head;
double B_new_sig_head;
double B_x_head[35+1];
double B_y[35+1];
double B_mu;
double B_sig;
double B_Px[35+1];
double B_odd_Px[18+1];
int    B_Px_ind[35+1];
double A_17_dens[17+1];
int    A_x_sixteen[17+1];
double A_x_forty[17+1];
int    A_x_round_forty[17+1];
double A_mu_16_est;
double A_mu_40_est;
double A_mu_40_round_all_est;
double B_17_dens[17+1];
int    B_x_sixteen[17+1];
double B_x_forty[17+1];
int    B_x_round_forty[17+1];
double B_mu_16_est;
double B_mu_40_est;
double B_mu_40_round_all_est;
double Axrf_40den[81];
double  Bxrf_40den[81];


int  com_A_den();
void com_A_x_ind();
int  com_B_den();
void com_B_x_ind();
void comp_A_mu_sig(int);
void comp_B_mu_sig(int);
void expandA_16_40();
void expandB_16_40();
void gen_A_error(int);
void gen_B_error(int);
void gen_m_16_star();
void gen_m_40_star();
void get_AB_train_num();
void get_AB_MU_SIG();
void get_A_sixteen(int,int);
void get_B_sixteen(int,int);
void lsqerror();
char * pathing();
void smooth_A_v40(int);
void smooth_B_v40(int);
void output_dist(int);


/* ---------------------------------------------------
 *  stat_mu_sig(): compute mean and variance
 * ---------------------------------------------------
 */
int stat_mu_sig() {

  int i;

  get_AB_train_num();
  get_AB_MU_SIG();
  gen_m_16_star();
  gen_m_40_star();
  for (i=1;i<=separation_num;i++) {
    get_A_sixteen(i,Train_A_record_num[i]);
    gen_A_error(Train_A_record_num[i]);
    if (com_A_den() == 2) {
      return (-1);
    }
    com_A_x_ind();
    expandA_16_40();
    smooth_A_v40(i);
    get_B_sixteen(i,Train_B_record_num[i]);
    gen_B_error(Train_B_record_num[i]);
    if (com_B_den() == 2) {
      return(-1);
    }
    com_B_x_ind();
    expandB_16_40();
    smooth_B_v40(i);
    output_dist(i);
  }
  return (0);

}

/*eject*/
/* ----------------------------------------------------------
 *  com_A_den(): density is computed for 
 *  -16, -14, ... 14, 16 because m_star values varies from 
 *  -17, -15, .... 15, 17 and the votes for A and B are all 
 *  even.
 *  if we mutiply density with the even votes, we will get 
 *  the mu value for the votes of -16 to 16 cases.
 *  we can also compute the mu_est for the -40 to 40 case 
 *  by multiplying the density with the scaling m_stars that 
 *  vary from less than -40 to bigger than +40. 
 * ----------------------------------------------------------
 */
int com_A_den() {

  int i,floor_num,ceiling_num;
  double den;
  double less_minus_40dens;
  double more_plus_40dens;

  less_minus_40dens = 0;
  more_plus_40dens = 0;
  A_mu_16_est = 0;
  A_mu_40_est = 0;
  A_mu_40_round_all_est = 0;

  for (i=2;i<=18;i++ ) {
    den =(double) ( A_odd_Px[i] - A_odd_Px[i-1] ) ;
    A_17_dens[i-1] = den;
    A_mu_16_est = A_mu_16_est + den * A_Px_ind[2*i - 2];
    A_mu_40_est = A_mu_40_est + den * A_y[2 * i -2];
    if ( A_y[2 * i - 2] < -40 ) {
      less_minus_40dens = less_minus_40dens + den;
    } else if ( A_y[2 * i - 2] > 40 ) {
      more_plus_40dens = more_plus_40dens + den;

    } else if (( A_y[ 2 * i - 2 ] <= 40 ) && 
               ( A_y[2*i-2] >= -40 )) {
      floor_num = floor(A_y[ 2 * i - 2 ]);
      ceiling_num = ceil(A_y[ 2 * i - 2 ]);
      if ( (floor_num % 2) == 0) {
        A_mu_40_round_all_est = A_mu_40_round_all_est +
                                floor_num * den;
      } else {
        A_mu_40_round_all_est = A_mu_40_round_all_est +
                                ceiling_num * den;
      }
    } else{
      return (2);
    }
  }
  less_minus_40dens = less_minus_40dens * (-40);
  more_plus_40dens = more_plus_40dens * 40;
  A_mu_40_round_all_est = A_mu_40_round_all_est + 
                          less_minus_40dens +
                          more_plus_40dens;
  return(0);

}


/*eject*/
/* ----------------------------------------------------------
 *  com_A_x_ind(): compute the scaled and rounded to
 *  even num for 40 index.
 * ----------------------------------------------------------
 */
void com_A_x_ind() {
  int i ;
  int floor_num;
  
  for (i=2;i<=18;i++ ) {
    A_x_sixteen[i-1] = A_Px_ind[ 2 * i - 2 ];
    A_x_forty[i-1]  = A_y[ 2 * i - 2];       
    floor_num = floor(A_y[ 2 * i - 2]); 
    if ((floor_num % 2 ) == 0) {
      A_x_round_forty[ i - 1] = floor(A_y[ 2 * i - 2 ]);
    } else {
      A_x_round_forty[ i - 1] = ceil(A_y[ 2 * i - 2 ]);
    }
    if (A_x_round_forty[i - 1] < -40) {
      A_x_round_forty[i - 1] = -40;
    }
    if (A_x_round_forty[i - 1] > 40) {
      A_x_round_forty[i - 1] = 40;
    }
  }
  return;
}

/*eject*/
/* ----------------------------------------------------------
 *  com_B_den(): density is computed for 
 *  -16, -14, ... 14, 16 because m_star values varies from 
 *  -17, -15, .... 15, 17 and the votes for A and B are all 
 *  even. 
 *  if we mutiply density with the even votes, we will get 
 *  the mu value for the votes of -16 to 16 cases.
 *  we can also compute the mu_est for the -40 to 40 case 
 *  by multiplying the density with the scaling m_stars that 
 *  vary from less than -40 to bigger than +40.
 * ----------------------------------------------------------
 */
int com_B_den() {
  int i,floor_num,ceiling_num;
  double den;
  double less_minus_40dens;
  double more_plus_40dens;

  less_minus_40dens = 0;
  more_plus_40dens = 0;
  B_mu_16_est = 0;
  B_mu_40_est = 0;
  B_mu_40_round_all_est = 0;

  for (i=2;i<=18;i++) {
    den =(double) ( B_odd_Px[i-1] - B_odd_Px[i] ) ;
    B_17_dens[i-1] = den;
    B_mu_16_est = B_mu_16_est + den * B_Px_ind[2*i - 2];
    B_mu_40_est = B_mu_40_est + den * B_y[2 * i -2];
    if (B_y[2 * i - 2] < -40) {
      less_minus_40dens = less_minus_40dens + den;
    } else if ( B_y[2 * i - 2] > 40 ) {
      more_plus_40dens = more_plus_40dens + den;
    } else if ((B_y[ 2 * i - 2 ] <= 40) && 
             (B_y[2*i-2] >= -40)) {
      floor_num = floor(B_y[ 2 * i - 2 ]);
      ceiling_num = ceil(B_y[ 2 * i - 2 ]);
      if ((floor_num % 2) == 0) {
        B_mu_40_round_all_est = B_mu_40_round_all_est +
                                floor_num * den;
      } else {
        B_mu_40_round_all_est = B_mu_40_round_all_est +
                                ceiling_num * den;
      }
    } else{
      return(2);
    }
  }
  less_minus_40dens = less_minus_40dens * (-40);
  more_plus_40dens = more_plus_40dens * 40;
  B_mu_40_round_all_est = B_mu_40_round_all_est + 
                          less_minus_40dens +
                          more_plus_40dens;
  return(0);

}


/*eject*/
/* ----------------------------------------------------------
 *  B_x_ind(): compute indices for B case
 * ----------------------------------------------------------
 */
void com_B_x_ind() {

  int i ;
  int floor_num;
  
  for (i=2;i<=18;i++ ) {
    B_x_sixteen[i-1] = B_Px_ind[ 2 * i - 2 ];
    B_x_forty[i-1]  = B_y[ 2 * i - 2];       
    floor_num = floor(B_y[ 2 * i - 2]); 
    if ((floor_num % 2 ) == 0) {
      B_x_round_forty[ i - 1] = floor(B_y[ 2 * i - 2 ]);
    } else {
      B_x_round_forty[ i - 1] = ceil(B_y[ 2 * i - 2 ]);
    }  
    if (B_x_round_forty[i - 1] < -40) {
      B_x_round_forty[i - 1] = -40;
    }
    if (B_x_round_forty[i - 1] > 40) {
      B_x_round_forty[i - 1] = 40;
    }
  }
  return;
}

/*eject*/
/* ----------------------------------------------------------
 *  comp_A_mu_sig(): compute the mu and sig 
 *  for the 16 votes
 * ----------------------------------------------------------
 */
void comp_A_mu_sig(int A_record_num) {
  double mu_total;
  double sqr_total;
  int i;

  mu_total = 0;
  sqr_total = 0;

  for (i=1;i<=A_record_num;i++) {
    mu_total = mu_total + A_sixteen_vote[i];
    sqr_total = sqr_total + 
                A_sixteen_vote[i] * A_sixteen_vote[i];
  }
  A_mu_head = mu_total/A_record_num;
  A_sig_head = sqrt((sqr_total - (A_record_num *
                    (A_mu_head * A_mu_head)))/
                    (A_record_num -1));
  A_new_mu_head  = A_mu_head  * 2.5;
  A_new_sig_head = A_sig_head * 2.5;
  return;

}


/*eject*/
/* -----------------------------------------------------------
 *  comp_B_mu_sig(): compute the mu and sig 
 *  for the 16 votes  
 * -----------------------------------------------------------
 */
void comp_B_mu_sig(int B_record_num) {
  double mu_total;
  double sqr_total;
  int i;

  mu_total = 0;
  sqr_total = 0;

  for (i=1;i<=B_record_num;i++) {
    mu_total = mu_total + B_sixteen_vote[i];
    sqr_total = sqr_total + 
                B_sixteen_vote[i] * B_sixteen_vote[i];
  }
  B_mu_head = mu_total/B_record_num;
  B_sig_head = sqrt((sqr_total - ( B_record_num *
                    (B_mu_head * B_mu_head)))/ 
                    (B_record_num - 1));
  B_new_mu_head  = B_mu_head * 2.5;
  B_new_sig_head = B_sig_head * 2.5;
  return;

}

/*eject*/
/* ----------------------------------------------------------
 *  expandA_16_40(): expand the density of 
 *  16 vote into 40 vote density (Class A)
 * ----------------------------------------------------------
 */
void  expandA_16_40() {

  int   i, k, k1, k2, k3, k4;

  for(i=0; i<=80; i++) {
    Axrf_40den[i] = 0;
  }
       
 /** divisible by 4 **/  
  for(i=3;i<=15;i=i+2) {
    k = A_x_sixteen[i];
    k2 = (k*5)/2;
    k1 = k2 - 2;
    k3 = k2 + 2;
    Axrf_40den[k1+40] += (3.0*A_17_dens[i])/10.0;
    Axrf_40den[k2+40] += (4.0*A_17_dens[i])/10.0;
    Axrf_40den[k3+40] += (3.0*A_17_dens[i])/10.0;
  }

  k = A_x_sixteen[1];     /*i.e. k = -16   */
  k2 = (k*5)/2;
  k1 = k2;
  k3 = k2 + 2;
  Axrf_40den[k1+40] += (3.0*A_17_dens[1])/10.0;
  Axrf_40den[k2+40] += (4.0*A_17_dens[1])/10.0;
  Axrf_40den[k3+40] += (3.0*A_17_dens[1])/10.0;

  k = A_x_sixteen[17];     /*i.e. k = 16   */
  k2 = (k*5)/2;
  k1 = k2 - 2;
  k3 = k2;
  Axrf_40den[k1+40] += (3.0*A_17_dens[17])/10.0;
  Axrf_40den[k2+40] += (4.0*A_17_dens[17])/10.0;
  Axrf_40den[k3+40] += (3.0*A_17_dens[17])/10.0;

 /** not divisible by 4 **/  
  for(i=2;i<=16;i=i+2) {
    k = A_x_sixteen[i];
    k1 = (k*5)/2 - 3;
    k2 = (k*5)/2 - 1;
    k3 = (k*5)/2 + 1;
    k4 = (k*5)/2 + 3;
    Axrf_40den[k1+40] += (1.0*A_17_dens[i])/10.0;
    Axrf_40den[k2+40] += (4.0*A_17_dens[i])/10.0;
    Axrf_40den[k3+40] += (4.0*A_17_dens[i])/10.0;
    Axrf_40den[k4+40] += (1.0*A_17_dens[i])/10.0;
  }
  return;

}

/*eject*/
/* ----------------------------------------------------------
 *  expandB_16_40(): expand the density of 
 *  16 vote into 40 vote density (Class B)
 * ----------------------------------------------------------
 */
void expandB_16_40() {

 int   i, k, k1, k2, k3, k4;

 for(i=0; i<=80; i++) {
       Bxrf_40den[i] = 0;
}
       
 /** divisible by 4 **/  
  for(i=3;i<=15;i=i+2) {
    k = B_x_sixteen[i];
    k2 = (k*5)/2;
    k1 = k2 - 2;
    k3 = k2 + 2;
    Bxrf_40den[k1+40] += (3.0*B_17_dens[i])/10.0;
    Bxrf_40den[k2+40] += (4.0*B_17_dens[i])/10.0;
     Bxrf_40den[k3+40] += (3.0*B_17_dens[i])/10.0;
  }

  k = B_x_sixteen[1];     /*i.e. k = -16   */
  k2 = (k*5)/2;
  k1 = k2;
  k3 = k2 + 2;
  Bxrf_40den[k1+40] += (3.0*B_17_dens[1])/10.0;
  Bxrf_40den[k2+40] += (4.0*B_17_dens[1])/10.0;
  Bxrf_40den[k3+40] += (3.0*B_17_dens[1])/10.0;

  k = B_x_sixteen[17];     /*i.e. k = 16   */
  k2 = (k*5)/2;
  k1 = k2 - 2;
  k3 = k2;
  Bxrf_40den[k1+40] += (3.0*B_17_dens[17])/10.0;
  Bxrf_40den[k2+40] += (4.0*B_17_dens[17])/10.0;
  Bxrf_40den[k3+40] += (3.0*B_17_dens[17])/10.0;

 /** not divisible by 4 **/  
  for(i=2;i<=16;i=i+2) {
    k = B_x_sixteen[i];
    k1 = (k*5)/2 - 3;
    k2 = (k*5)/2 - 1;
    k3 = (k*5)/2 + 1;
    k4 = (k*5)/2 + 3;
    Bxrf_40den[k1+40] += (1.0*B_17_dens[i])/10.0;
    Bxrf_40den[k2+40] += (4.0*B_17_dens[i])/10.0;
    Bxrf_40den[k3+40] += (4.0*B_17_dens[i])/10.0;
    Bxrf_40den[k4+40] += (1.0*B_17_dens[i])/10.0;
  }
  return;

 }

/*eject*/
/* ----------------------------------------------------------
 *  gen_A_error(): compute the error percentage.
 * ----------------------------------------------------------
 */
void gen_A_error(int A_record_num) {

  int i,j,k,vote_A,vote_B;
  double error_rate;

  k = 1;
  for (i=1;i<=35;i++) {
    if ((i % 2) == 1) { 
      vote_A = 0;
      vote_B = 0;
      for (j=1;j<=A_record_num;j++) {
        if (A_sixteen_vote[j] > m_16_star[i]) {
          vote_A = vote_A + 1;
        } else {
          vote_B = vote_B + 1;
        }
      }
      error_rate = (double)vote_B/A_record_num;
      A_Px[i] = error_rate;
      A_odd_Px[k] = error_rate;
      k++;
    }
  }
  return;
}

/*eject*/
/* ----------------------------------------------------------
 *  gen_B_error(): compute the error percentage.
 * ----------------------------------------------------------
 */
void gen_B_error(int B_record_num) {

  int i,j,k,vote_A,vote_B;
  double error_rate;

  k = 1;
  for (i=1;i<=35;i++) {
    if ((i % 2 ) == 1){
      vote_A = 0;
      vote_B = 0;
      for (j=1;j<=B_record_num;j++) {
        if (B_sixteen_vote[j] > m_16_star[i]) {
          vote_A = vote_A + 1;
        } else {
          vote_B = vote_B + 1;
        }
      }
      error_rate = (double)vote_A/B_record_num;
      B_Px[i] = error_rate;
      B_odd_Px[k] = error_rate;
      k++;
    }
  }
  return;
}

/*eject*/
/* ---------------------------------------------------------
 *  gen_m_16_star(): m_16_star values are 
 *  from -17, -16, ... 16, 17.
 * ---------------------------------------------------------
 */
void gen_m_16_star() {

  int i,k;

  k = 1;
  for (i =-17;i<=17;i++) {
    m_16_star[k] = i ;
    A_Px_ind[k] = i ;
    B_Px_ind[k] = i;
    k++;
  }
  return;

}

/*eject*/
/* ----------------------------------------------------------
 *  gen_m_40_star() : m* ranges from -41, -39, .... 39, 41.
 * ----------------------------------------------------------
 */
void gen_m_40_star()
{
  int i,k;

  k = 1;
  for (i=-21;i<=20;i++) {
    m_40_star[k] = i * 2 + 1;
    k++;
  }
  return;

}

/*eject*/
/* ----------------------------------------------------------
 *  get_AB_MU_SIG(): For each separation, there are one 
 *  MU value and one SIG (ie covariance) value.
 * ----------------------------------------------------------
 */
void get_AB_MU_SIG() {
  int i;
  FILE *f1;
  double f_num;

  if ((f1 = fopen(pathing("mu_sig.data"),"r")) == NULL) {
    printf("Cannot open file mu_sig.data\n");
    fprintf(errfil,"Cannot open file mu_sig.data\n");
    lsqerror("get_AB_MU_SIG","102");
  }
  
  for (i=1;i<= separation_num;i++) {
    fscanf(f1,"%lf",&f_num);
    A_MU[i] = f_num;
    fscanf(f1,"%lf",&f_num);
    A_SIG[i] = f_num;
    fscanf(f1,"%lf",&f_num);
    B_MU[i] = f_num;
    fscanf(f1,"%lf",&f_num);
    B_SIG[i] = f_num;
  }
  fclose(f1);
  return;
}

/*eject*/
/* ----------------------------------------------------------
 *  get_AB_train_num(): read the bucket_separation.cnl
 * and compute the A, B record numbers for each separation.
 * ----------------------------------------------------------
 */
void get_AB_train_num() {

  int i,x,y,loop_num;

  FILE *f1;

  if ((f1 = 
       fopen(pathing("bucket_separation.cnl"),"r")) == NULL) {
    printf("Cannot open file bucket_separation.cnl\n");
    fprintf(errfil,"Cannot open file bucket_separation.cnl\n");
    lsqerror("get_AB_train_num","102");
  }

  fscanf(f1,"%d",&loop_num);

  if (separation_num == 1) {
    fscanf(f1,"%d",&x);
    fscanf(f1,"%d",&y);
    Train_A_record_num[1] = y - x + 1;
    fscanf(f1,"%d",&x);
    fscanf(f1,"%d",&y);
    Train_B_record_num[1] = y - Train_A_record_num[1];
  } else {
    if (loop_num != separation_num) {
      printf("Error in get_AB_train_num()");
      fprintf(errfil,"Error in get_AB_train_num()");
      lsqerror("get_AB_train_num","102");
    }

    for (i=1;i<=loop_num;i++) {
      fscanf(f1,"%d",&x);
      fscanf(f1,"%d",&y);
      Train_A_record_num[i] = y - x + 1;
    }
    fclose(f1);
    for (i=1;i<= loop_num;i++) {
            Train_B_record_num[i] = y - Train_A_record_num[i];
    }
  }  
  fclose(f1);
  return;
  
}

/*eject*/
/* ----------------------------------------------------------
 *  get_A_sixteen(): read the 16 votes for each 
 *  record into program.
 * ----------------------------------------------------------
 */
void get_A_sixteen(int sep_ind,int A_record_num) {

  int i,i_num;
  char s1[namesize];

  FILE *f1;

  sprintf(s1,"A_sixteenvote_sep%d.data",sep_ind);
  if ((f1 = fopen(pathing(s1),"r")) == NULL) {
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("get_A_sixteen","102");
  }
  for (i=1;i<=A_record_num;i++) {
    fscanf(f1,"%d",&i_num);
    fscanf(f1,"%d",&i_num);
    A_sixteen_vote[i] = i_num;
  }
  fclose(f1);
  return;

}

/*eject*/
/* ----------------------------------------------------------
 *  get_B_sixteen(): read the 16 votes for each 
 *  record into program.
 * ----------------------------------------------------------
 */
void get_B_sixteen(int sep_ind,int B_record_num) {

  int i,i_num;
  char s1[namesize];

  FILE *f1;

  sprintf(s1,"B_sixteenvote_sep%d.data",sep_ind);
  if ((f1 = fopen(pathing(s1),"r")) == NULL) {
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("get_B_sixteen","102");
  }
  for (i=1;i<=B_record_num;i++) {
    fscanf(f1,"%d",&i_num);
    fscanf(f1,"%d",&i_num);
    B_sixteen_vote[i] = -(i_num);
  }
  fclose(f1);
  return;

}

/*eject*/
/* ----------------------------------------------------------
 *  smooth_A_v40(): After scaling the sixteen votes to 
 *  the forty votes, in the forty votes densities, there are
 *  some gaps in between need to be filled.
 *  right now, just use the adjacent values.
 * ----------------------------------------------------------
 */
void smooth_A_v40(int sep_ind) {
  int i,j,ind;
  double total_den;
  
  for (i=1;i<=42;i++) {
    ind = m_40_star[i];
    total_den = 0;
    for (j=0;j<=80;j=j+2) {
      if ((j-40) <= ind) {
        total_den = total_den + Axrf_40den[j];
      } else {
        break;
      }
  } 
  Qa[i] = total_den;         
  } 
  return;
    
}   

/*eject*/
/* ----------------------------------------------------------
 *  smooth_B_v40(): After scaling the sixteen votes to 
 *  the forty votes, in the forty votes densities, there are
 *  some gaps in between need to be filled.
 *  right now, just use the adjacent values.
 * ----------------------------------------------------------
 */        
void smooth_B_v40(int sep_ind) {
  int i,j,ind;
  double total_den;
  
  for (i=1;i<=42;i++) {
    ind = m_40_star[i];
    total_den = 0;
    for (j=0;j<=80;j=j+2) {
      if ((j-40) <= ind) {
        total_den = total_den + Bxrf_40den[j];
      } else {
        break;
      }
    } 
    Qb[i] = ( 1 - total_den);         
  }
  return;  
  
} 

/*eject*/
/* ----------------------------------------------------------
 *  output_dist(): output Qa[i], Qb[i] distribution values
 *  compute and output error probabilities
 *  output file is qaqb_train_sepxd.data
 * ----------------------------------------------------------
 */
void output_dist( int sep_ind) {

  int  i;
  char s1[namesize];

  FILE *f1;

  sprintf(s1,"qaqb_train_sep%d.data",sep_ind);
  if ((f1 = fopen(pathing(s1),"w")) == NULL) {
    printf("Cannot open file %s\n",s1);
    fprintf(errfil,"Cannot open file %s\n",s1);
    lsqerror("output_dist","102");
  }
/*
 *  vote distributions
 *  caution: Qa[i] = distribution function of A votes
 *           Qb[i] = power function of B votes
 *           for details, see stat_distributions()
 */
  for (i=1;i<=42;i++) {
    fprintf(f1," %3d   %6.4f   %6.4f \n",\
               m_40_star[i],Qa[i],Qb[i]);
  }
/*
 *  error probabilities
 *  for details, see stat_distributions()
 */
  for (i=1;i<=42;i++) {
       if (Qa[i] < .000001) {
         Pa[i] = 0.0;
       } else {
         Pa[i] = pop_A_fraction*Qa[i];
       }
       if (Qb[i] < .000001) {
         Pb[i] = 0.0;
       } else { 
         Pb[i] = (1.-pop_A_fraction)*Qb[i];
       }
    fprintf(f1," %3d   %6.4f   %6.4f\n",\
       m_40_star[i],Pa[i],Pb[i]);
  }
  fclose(f1);
  return;

}

/*  last record of stat_mu_sig.c***** */
