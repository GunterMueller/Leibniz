/*  first record of lsqutil.c ****** */
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "lsqparms.h"
#include "lsqdefs.h"
#include "features.h" /* system version selection */

char tempx[namesize];

/* *****************************************************
 *
 *  Utilies for lsqcc 
 *
 *  add_pyr_values add values defined by pyramid formulas
 *  consistency_pyrvar_sepvar check consistency of pyramid
 *               variables and separation variables
 *  construct_work_area construct work area
 *  get_pyrrc    read pyramid formulas into pyr_rec[][][]
 *  get_seprc    read separation records into sep_rec[][][] 
 *  lsqerror     lsqcc system error termination
 *  lsqexit      free memory and exit
 *  lsqvrsion    version number of lsqcc system
 *  nextentry    finds nonwhite sequence after current one
 *  pathing      concatenate workarea path and filename
 *  sqrtapprox   approximate square root
 *  remove_work_area remove work area
 * ******************************************************
 */

/* -------------------------------------------------
 *  add_pyr_values(): add values defined by pyramid formulas
 *  input:  log_rec[][]       logic records, without pyramid
 *                            values
 *          col_count         number of variables; includes
 *                            pyramid variables
 *          log_name_list[][] names of variables; includes pyramid
 *                            variables
 *          pyr_rec[][][]     pyramid formulas
 *          pyr_form_count    number of pyramid formulas = 
 *                            number of pyramid variables
 *          pyr_col_count     number of variables; includes
 *                            pyramid variables
 *                            must match col_count
 * output:  new log_rec[][]   logic records with pyramid values
 * caution: routine expands only records where 
 *          log_rec[i][0] = LSQFALSE
 * caution: must have col_count = pyr_col_count, as well as
 *          log_name_list[][] = pyr_name_list[][]
 *          = list of all variables, including pyramid variables; 
 *          these conditions are checked in the routine
 * -------------------------------------------------
 */

void  add_pyr_values(int *rc) {

  int  clash,iform,jsep,lit,nest,rec,rct,term;

  void lsqerror();

  nest = 0; /* added to suppress compiler warning */
  rct = *rc;

/*
 *   compute pyramid values for all records
 */
  for (rec=1;rec<=rct;rec++) {
    if (log_rec[rec][0] == LSQFALSE) {
      for (iform=1;iform<=pyr_form_count;iform++) {
        clash = 0;
        for (jsep=1;jsep<=pyr_rec[iform][0][0];jsep++) {
          nest = 1;
          for (lit=1;lit<=pyr_rec[iform][jsep][0];lit++) {
            term = pyr_rec[iform][jsep][lit]*
                   log_rec[rec][abs(pyr_rec[iform][jsep][lit])];
            if (term < 0) {
              clash++;
              nest = 0;
              break;
            }
            if (term <= 0) {
              nest = 0;
            }
          } /* end of lit loop */
          if (nest == 1) {
            break;
          }
        } /* end of jsep loop */
        if (clash == pyr_rec[iform][0][0]) {
          nest = -1;
        }
/*
 *  add value to log_rec[][][]
 *  nest =  1: True
 *  nest = -1: False
 *  nest =  0: Undecided if missing entry = absent
 *             False if missing entry = unavailable 
 */
        log_rec[rec][col_count - pyr_form_count + iform] = nest;
        if ((weaksepflg == 1) && (nest == 0)) {
          log_rec[rec][col_count - pyr_form_count + iform] = -1;
        }
      } /* end of iform loop */
    } /* end of 'if log_rec[rec][0] == LSQFALSE' */
  } /* end of rec loop */
  
  return;
}


/*eject*/
/* -------------------------------------------------
 *   consistency_pyrvar_sepvar(): check consistency of
 *   pyramid variables and separation variables
 * -------------------------------------------------
 */

void consistency_pyrvar_sepvar() {

  int i,flg;

  void lsqexit();

  if (pyr_form_count == 0) {
    return;
  }

  flg = 0;

  if (col_count != pyr_col_count) {
/*
 *   error, must have col_count = pyr_col_count
 */
    flg = 1;
  }
  for (i=1;i<=col_count;i++) {
    if (strcmp(&log_name_list[i][0],&pyr_name_list[i][0])!=0) {
/*
 *   error, variables of the two lists must match
 */
      flg = 1;
      break;
    }
  }

/*eject*/
  if (flg == 1) {
/*
 *  error, pyramid variables and separation variables
 *  are not consistent
 */
    printf(
    "The variables of the existing pyramid file\n%s\n",
    pyramid_file);
    printf(
    "and of the existing separation file\n%s\n",
    separation_file);
    printf(
    "are not identical. Such consistency is required.\n");
    printf(
    "Possible reasons for inconsistency:\n");
    printf(
    "- Logic variables in training file have been changed.\n");
    printf(
    "  and training file is no longer compatible with pyramid\n");
    printf(
    "  file. Remedy: delete pyramid file.\n");
    printf(
    "- Pyramid file has been updated by pyrcc, but lsqcc\n");
    printf(
    "  has not yet been run again. Remedy: Run lsqcc.\n");
    printf(
    "- Pyramid file has been run once, and currently\n");
    printf(
    "  lsqcc is applied. Inconsistency is caused by missing\n");
    printf(
    "  statement 'include xxx.prd' in training file.\n");
    printf(
    "  Remedy: add 'include xxx.prd' to training file.\n");
    printf(
    "See manual for details.\nStop\n");
    fprintf(errfil,
    "The variables of the existing pyramid file\n%s\n",
    pyramid_file);
    fprintf(errfil,
	    "and of the existing separation file\n%s\n",
    separation_file);
    fprintf(errfil,
    "are not identical. Such consistency is required.\n");
    fprintf(errfil,
    "Possible reasons for inconsistency:\n");
    fprintf(errfil,
    "- Logic variables in training file have been changed.\n");
    fprintf(errfil,
    "  and training file is no longer compatible with pyramid\n");
    fprintf(errfil,
    "  file. Remedy: delete pyramid file.\n");
    fprintf(errfil,
    "- Pyramid file has been updated by pyrcc, but lsqcc\n");
    fprintf(errfil,
    "  has not yet been run again. Remedy: Run lsqcc.\n");
    fprintf(errfil,
    "- Pyramid file has been run once, and currently\n");
    fprintf(errfil,
    "  lsqcc is applied. Inconsistency is caused by missing\n");
    fprintf(errfil,
    "  statement 'include xxx.prd' in training file.\n");
    fprintf(errfil,
    "  Remedy: add 'include xxx.prd' to training file.\n");
    fprintf(errfil,
    "See manual for details.\nStop\n");

    lsqexit(1);
  }

  return;
 
}

/*eject*/
/* -------------------------------------------------
 *   construct_work_area(): construct work area
 * -------------------------------------------------
 */

void  construct_work_area() {
  char cmnd[240];
  FILE *out;  

#ifdef UNIX
  strcpy(lsqworkarea,lsqtraindir);
  strcat(lsqworkarea,"TMPlsq76xi2uy3/");
  sprintf(cmnd,"test -d %s",lsqworkarea);

/*  
 *  lsqworkarea contains a terminating "/"to be consistent
 *  with Leibniz System convention
 */    
    if( system(cmnd)  == 0 ) { 

/*
 * directory exists already, clean it
 * after introduction of fake file TMPlsq76xi2uy3
 * so that rm command does not cause error message
 * for empty directory
 */
      sprintf(cmnd,"%sTMPlsq76xi2uy3TMPlsq76xi2uy3",lsqworkarea);
      out = fopen(cmnd,"w");
      fclose(out);  
      sprintf(cmnd,"rm  %s*",lsqworkarea);
      system(cmnd);   

    } else {
/*
 * work area does not exist, create it
 */
      sprintf(cmnd,"mkdir  %s",lsqworkarea);
      system(cmnd);
    }
#endif
#ifdef WINDOWS
  strcpy(lsqworkarea,lsqtraindir);
  strcat(lsqworkarea,"TMPlsq76xi2uy3");
/* IF EXIST TMPlsq76xi2uy3. (del /f /q TMPlsq76xi2uy3\*) ELSE mkdir TMPlsq76xi2uy3. */
  sprintf(cmnd, "IF EXIST %s. (del /f /q %s\\*) ELSE mkdir %s.",
		  lsqworkarea, lsqworkarea, lsqworkarea);
  system(cmnd);

  /* Lsqcc is expecting this variable to be the directory with a
   * slash (or backslash) appended to the end.  We have to do
   * append the slash/backslash after we create the directory or
   * Windows will fail to create it.
   */
  strcat(lsqworkarea, "\\");
#endif 

  return;
}

/*eject*/
/* 
 * -------------------------------------
 * get_pyrrc(): read the    
 * pyramid formulas into pyr_rec[][][]
 * output:  pyr_rec[][][]
 *          pyr_name_list[][] 
 *          pyr_form_count 
 *          pyr_col_count
 * caution: pyr_col_count contains all variables, including
 *          pyramid variables
 * caution: col_count is not defined by this routine 
 * -------------------------------------
 */
void get_pyrrc() {

  int iform,jsep,jvar,k,kentry,stage;

  FILE *f1;

  void lsqerror();
  void lsqexit();
  int  nextentry();

  jvar = 0;   /* added to suppress compiler warning */
  kentry = 0; /* added to suppress compiler warning */

  if ((f1 = fopen(pyramid_file,"r")) == NULL){
    printf("Cannot open pyramid file:\n %s\n",pyramid_file);
    printf("Stop\n");
    fprintf(errfil,
       "Cannot open pyramid file:\n %s\n",pyramid_file);
    fprintf(errfil,"Stop\n");
    lsqerror("get_pyrrc","102");
  }

  pyr_form_count = 0;
  stage = 0;

/*
 *  top of loop
 */
  zz105:;
/*
 *  read record from file
 */
  if (fgets(record,256,f1)==NULL) {
    printf("Unexpected end of pyramid file:\n");
    printf("%s\n",pyramid_file);
    printf("File must terminate with ENDATA record\n");
    printf("Stop\n");
    fprintf(errfil,"Unexpected end of pyramid file:\n");
    fprintf(errfil,"%s\n",pyramid_file);
    fprintf(errfil,"File must terminate with ENDATA record\n");
    fprintf(errfil,"Stop\n");
    lsqexit(1);
  }
/*
 *  ENDATA case
 */
  if (strncmp(record,"ENDATA",6)==0) {
/*
 *  pyr_form_count must be equal to iform
 */
    if (pyr_form_count != iform) {
      lsqerror("get_pyrrc","102");
    }
    fclose(f1);
    if (lsqscrflg == 1) {
      printf("Pyramid file:\n");
      printf("Number of formulas  = %d\n",
              pyr_form_count);
      printf("Number of variables = %d\n",pyr_col_count);
      printf("includes pyramid variables\n"); 
    }
    return;
  }
 
/*
 *  process record
 *
 *  stage = 0: first record of pyramid file
 */
  if (stage == 0) {
 
    if (sscanf(record,
     "%d pyramid formula(s) with %d variables, including pyramid",
	       &pyr_form_count, &pyr_col_count) != 2) {
      lsqerror("get_pyrrc","104");
    }
    jvar = 0;
    stage = 1;
    goto zz105;
  } /* end of stage 0 */

/*
 *  stage = 1: subsequent header records of pyramid file
 */
  if (stage == 1) {
    if (strncmp(record,"Variables",9)==0) {
      stage = 10;
      goto zz105;  
    } else {
      lsqerror("get_pyrrc","108");
    }
  } /* end of stage 1 */

/*
 *  stage = 10: read pyr_name_list[][]
 */
  if (stage == 10) {
    jvar++;
    sscanf(record,"%s",&pyr_name_list[jvar][0]);
    if (jvar == pyr_col_count) {
      stage = 20;
    }
    goto zz105;
  } /* end of stage 10 */
/*
 *  stage = 20: look for "Formula" keyword
 */
  if (stage == 20) {
    if (strncmp(record,"Formula",7) != 0) {
      goto zz105;
    } else {
      k = 0;
      nextentry(&k,record);             /* skip over "Formula" */
      sscanf(&record[k],"%d",&iform);   /* formula number      */
      nextentry(&k,record);  /* formula variable name, skip    */
      nextentry(&k,record);
      sscanf(&record[k],"%d",
            &pyr_rec[iform][0][0]); /* number of clauses */
      stage = 30;
      goto zz105;
    }
  } /* end of stage 20 */

/*
 *  stage = 30: "clause" keyword must be first word
 */
  if (stage == 30) {
    if (strncmp(record,"clause",6) != 0) {
      lsqerror("get_pyrrc","202");
    }
    stage = 40;
    goto zz105;
  } /* end of stage 30 */

/*
 *  stage = 40: determine separation number and
 *              number of literals        
 */
  if (stage == 40) {
    kentry = 0;
    k = -1;
    nextentry(&k,record);
    sscanf(&record[k],"%d",&jsep);
    nextentry(&k,record);
    sscanf(&record[k],"%d",&pyr_rec[iform][jsep][0]);
    stage = 50;
  } /* end of stage 40 */

/*
 *  stage = 50: process literals       
 */
  if (stage == 50) {
    nextentry(&k,record); 
    while (k >= 0) {
/*
 *  read literal
 */
      kentry++;
      sscanf(&record[k],"%d",&pyr_rec[iform][jsep][kentry]);
      nextentry(&k,record);
    }
/*
 *  have processed record, and k = -1
 *  kentry cannot exceed pyr_rec[iform][jsep][0]
 */
    if (kentry > pyr_rec[iform][jsep][0]) {
      lsqerror("get_pyrrc","302");
    }
/*
 *  if kentry < pyr_rec[iform][jsep][0], additional literal(s)
 *  must be read; know k = -1
 */
    if (kentry < pyr_rec[iform][jsep][0]) {
      goto zz105;
    }
/*
 *  decide on next step
 */
    if (jsep < pyr_rec[iform][0][0]) {
/*
 *  process another clause of formula iform
 */
      stage = 40;
      goto zz105;
    } else if (jsep == pyr_rec[iform][0][0]) {
/*
 *  done with formula iform
 */
      stage = 20;
      goto zz105;
    } else {
      lsqerror("get_pyrrc","402");
    }
  } /* end of stage 50 */  

/*
 *  must be one of the above stage cases
 */
  lsqerror("get_pyrrc","502");

}

/*eject*/
/* 
 * -------------------------------------
 * get_seprc(): read the    
 * separation records into sep_rec[][][] 
 * -------------------------------------
 */
void get_seprc() {

  int iform,jsep,jvar,k,kentry,stage;

  char s1[namesize + 1];

  FILE *f1;

  void lsqerror();
  void lsqexit();
  int  nextentry();

  jvar = 0;   /* added to suppress compiler warning */
  kentry = 0; /* added to suppress compiler warning */

  if ((f1 = fopen(separation_file,"r")) == NULL){
    printf("Cannot open separation file:\n %s\n",separation_file);
    printf("Stop\n");
    fprintf(errfil,
       "Cannot open separation file:\n %s\n",separation_file);
    fprintf(errfil,"Stop\n");
    lsqexit(1);
  }

  formula_count = 0;
  stage = 0;

/*
 *  top of loop
 */
  zz105:;
/*
 *  read record from file
 */
  if (fgets(record,256,f1)==NULL) {
    printf("Unexpected end of separation file:\n");
    printf("%s\n",separation_file);
    printf("File must terminate with ENDATA record\n");
    printf("Stop\n");
    fprintf(errfil,"Unexpected end of separation file:\n");
    fprintf(errfil,"%s\n",separation_file);
    fprintf(errfil,"File must terminate with ENDATA record\n");
    fprintf(errfil,"Stop\n");
    lsqexit(1);
  }
/*
 *  ENDATA case
 */
  if (strncmp(record,"ENDATA",6)==0) {
/*
 *  formula_count must be equal to iform
 */
    if (formula_count != iform) {
      lsqerror("get_seprc","102");
    }
    fclose(f1);
    if (lsqscrflg == 1) {
      printf("Separation file:\n");
      printf("Number of formulas  = %d\n",
              formula_count);
      printf("Number of variables = %d\n",col_count);
    }
    return;
  }
 
/*
 *  process record
 *
 *  stage = 0: first record of separation file
 */
  if (stage == 0) {
 
    if (sscanf(record,
       "%d formulas with %d logic variables, missing values = %s",
	       &formula_count, &col_count, s1) != 3) {
      lsqerror("get_seprc","104");
    }
    if (strcmp(s1,"absent") == 0) {
      strongsepflg = 1;
      weaksepflg = 0;
    } else if (strcmp(s1,"unavailable") == 0) {
      strongsepflg = 0;
      weaksepflg = 1;
    } else {
      lsqerror("get_seprc","106");
    }
    jvar = 0;
    stage = 1;
    goto zz105;
  } /* end of stage 0 */

/*
 *  stage = 1: subsequent header records of separation file
 */
  if (stage == 1) {
    if (strncmp(record,"with least",10)==0) {
      shortsepflg = 1;
      optcstsepflg = 0;
      goto zz105;
    } else if (strncmp(record,"for optimal",11)==0) {
      shortsepflg = 0;
      optcstsepflg = 1;
      goto zz105;
    } else if (strncmp(record,"derived from",12)==0) {
      if (sscanf(record,"derived from %d A records and %d B records\n",
                        &init_row_size_A, &init_row_size_B) != 2) {
        lsqerror("get_seprc","108");
      }
      goto zz105;
    } else if (strncmp(record,"Variables",9)==0) {
      stage = 10;
      goto zz105;  
    } else {
      lsqerror("get_seprc","108");
    }
  } /* end of stage 1 */

/*
 *  stage = 10: read log_name_list[][] and, if optimization case,
 *              pos_var_cst[] and neg_var_cst[]
 */
  if (stage == 10) {
    jvar++;
    if (shortsepflg == 1) {
      sscanf(record,"%s",&log_name_list[jvar][0]);
    } else if (optcstsepflg == 1) {
      sscanf(record,"%s %d %d",&log_name_list[jvar][0],
                    &pos_var_cst[jvar],&neg_var_cst[jvar]);
    } else {
      lsqerror("get_seprc","110");
    }
    if (jvar == col_count) {
      stage = 20;
    }
    goto zz105;
  } /* end of stage 10 */
/*
 *  stage = 20: look for "Formula" keyword
 */
  if (stage == 20) {
    if (strncmp(record,"Formula",7) != 0) {
      goto zz105;
    } else {
      k = 0;
      nextentry(&k,record);             /* skip over "Formula" */
      sscanf(&record[k],"%d",&iform);        /* formula number */
      nextentry(&k,record);
      sscanf(&record[k],"%s",
             &formula_type[iform][0]);       /* type = A or B  */
      nextentry(&k,record);
      sscanf(&record[k],"%d",
                     &sep_rec[iform][0][0]); /* number of sep's*/
      stage = 30;
      goto zz105;
    }
  } /* end of stage 20 */

/*
 *  stage = 30: "clause" keyword must be first word
 */
  if (stage == 30) {
    if (strncmp(record,"clause",6) != 0) {
      lsqerror("get_seprc","202");
    }
    stage = 40;
    goto zz105;
  } /* end of stage 30 */

/*
 *  stage = 40: determine separation number and
 *             number of literals        
 */
  if (stage == 40) {
    kentry = 0;
    k = -1;
    nextentry(&k,record);
    sscanf(&record[k],"%d",&jsep);
    nextentry(&k,record);
    sscanf(&record[k],"%d",&sep_rec[iform][jsep][0]);
    stage = 50;
  } /* end of stage 40 */

/*
 *  stage = 50: process literals       
 */
  if (stage == 50) {
    nextentry(&k,record); 
    while (k >= 0) {
/*
 *  read literal
 */
      kentry++;
      sscanf(&record[k],"%d",&sep_rec[iform][jsep][kentry]);
      nextentry(&k,record);
    }
/*
 *  have processed record, and k = -1
 *  kentry cannot exceed sep_rec[iform][jsep][0]
 */
    if (kentry > sep_rec[iform][jsep][0]) {
      lsqerror("get_seprc","302");
    }
/*
 *  if kentry < sep_rec[iform][jsep][0], additional literal(s)
 *  must be read; know k = -1
 */
    if (kentry < sep_rec[iform][jsep][0]) {
      goto zz105;
    }
/*
 *  decide on next step
 */
    if (jsep < sep_rec[iform][0][0]) {
/*
 *  process another separation of formula iform
 */
      stage = 40;
      goto zz105;
    } else if (jsep == sep_rec[iform][0][0]) {
/*
 *  done with formula iform
 */
      stage = 20;
      goto zz105;
    } else {
      lsqerror("get_seprc","402");
    }
  } /* end of stage 50 */  

/*
 *  must be one of the above stage cases
 */
  lsqerror("get_seprc","502");

}

/*eject*/
/*
 * -------------------------------------------------------
 *  lsqerror(): lsqcc system error termination
 * ------------------------------------------------------- 
 */
void lsqerror(char *m1,char *m2) {
/*
 */
  void lsqexit();

  printf("\n*******LSQCC SYSTEM ERROR*******\n");
  printf("ERROR IN %s  code %s\n",m1,m2);
  printf("**********************************\n");
  printf("For details, see error file lsqcc.err\n");
/*
 */
  fprintf(errfil,"\n*******LSQCC SYSTEM ERROR*******\n");
  fprintf(errfil,"ERROR IN %s  code %s\n",m1,m2);
  fprintf(errfil,"**********************************\n");
  lsqexit(1);

}

/*eject*/
/*
 * -------------------------------------------------------
 *  lsqexit(): frees memory and exits with specified
 *  parameter
 *  if tstccmain is main program, free_device() is vacuous
 * ------------------------------------------------------- 
 */
void lsqexit(int k) {

  void fre_dev();

  char name[129]="";
  char state[2]="";
  char type[5]="";
  long value[8]={0,0,0,0,0,0,0,0};
  short errcde[2]={0,0};
/*
 *  free leibniz memory
 */
  fre_dev(name,state,type,value,errcde);  
  exit(k);
 
}

/*eject*/
/*
 * -------------------------------------------------------
 *  lsqvrsion(): defines lsqcc system version number
 *  outputs lsqver 
 * ------------------------------------------------------- 
 */
void lsqvrsion() {

  char globalversion[5];
/*
 *  define lsqcc system version number in lsqver
 *  using exactly 4 characters, nonblanks left justified
 */
#include "../../GlobalVersion/globalversion.h"
  strcpy(lsqver,globalversion);
  return;
}

/*eject*/
/*
 * --------------------------------------------------
 *  nextentry():
 *  if *k = -1: in string s, starts at position 0,
 *    scans all white spaces (blank, tab, end-of-line),
 *    and stops with first nonwhite character.
 *  if *k >= 0: in string s, starts at position k,
 *  searches for next sequence of nonwhite spaces, 
 *  then scans all white spaces, and stops when first 
 *  nonwhite space is found 
 *
 *  output: 
 *  if the desired nonwhite space is found: returns
 *    in *k the index of the nonwhite space, and also returns
 *    that index as value of the procedure.
 *  if the desired nonwhite is not found: returns -1 as value
 *    for *k and als value of the procedure
 * --------------------------------------------------
 */
int nextentry(int *k,char s[]) {

  int flag,i,ix,nz;

  void lsqerror();

  nz = strlen(s);
  if (nz == 0) {
    *k = -1;
    return(-1);
  }

  if (*k == -1) {
    for (i=0;i<=nz-1;i++) {
      ix = (int)s[i];
      if ((ix>=33)&&
          (ix<=126)) {
        *k = i;
        return(i);
      }
    }
    return(-1);
  } else if (*k >= 0) { 
    flag = 0;
    for (i=*k;i<=nz-1;i++) {
      ix = (int)s[i];
      if ((ix>=33)&&
          (ix<=126)) { 
        if (flag == 0) {
          flag = 1;
        } else if (flag == 2) {
          *k = i;
          return(i);
        }
      } else {
        if (flag == 1) {
          flag = 2;
        }
      }
    }
    *k = -1;
    return(-1);
  } else {
    lsqerror("nextentry","102");
    return(-2); /* added to supress compiler warning */
  }

}

/*eject*/
/*---------------------------------------------------------
 *  pathing(): concatenate workarea path and filename
 * --------------------------------------------------------
 */

char *pathing(char filename[]) { 
  strcpy(tempx,lsqworkarea);
  strcat(tempx,filename);
  return(tempx);

}

/*eject*/
/* ----------------------------------------------
 * remove_work_area(): clean and remove work area
 * ----------------------------------------------
 */
void remove_work_area() {

  char command[namesize];

#ifdef UNIX
  sprintf(command,"rm %s*",lsqworkarea);
  system(command);
  
  sprintf(command,"rmdir %s",lsqworkarea);
  system(command);
#endif
#ifdef WINDOWS
/*
 * rd /s /q lsqworkarea
 */
  sprintf(command, "rd /s /q %s", lsqworkarea);
  system(command);
#endif
}

/*  last record of lsqutil.c ****** */
