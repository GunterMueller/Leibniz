/*  first record of lsqcc.c***** */
/*
 *   Leibniz System: Lsqcc System
 *   Copyright 2015 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * ===================================================
 * Lsqcc System - Callable Learning Version lsqcc
 * ===================================================
 *
 *  generates separations and vote distributions from records
 *  of training file
 *
 *  if leibniz system version changes, update leibnizparams.dat
 *  definition in compile_log_programs() (in file
 *  compile_log_programs.c) as demanded by new version.
 *
 *  when new separation options are introduced, must check
 *  all code with if-tests for such options (e.g., 
 *  fourtotalsepflg, fortypartialsepflg).
 *  
 *  for relationships between logic files (.log) and
 *  data files, (.data), see compute_separations.c file.
 * -----------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h" /* lsqdefs.h is in lsqutil.c */

void lsqcc() {
/*
 *  callable version of learning logic program lsqcc
 *  caution: 
 *   - parameters must have been obtained (see lsqgetparm() for
 *   - required information)
 *   - allocation of leibniz arrays must have been done
 *   - errfil must have been opened
 *  caution: these conditions are not checked by the program
 *
 *  col_count, pyr_col_count, and related sets of variables:
 *  training: the logic portion of the training file is expanded
 *            via inclusion of the predicate file .prd. This
 *            adds all variables of the pyramid formulas. 
 *            Thus, col_count = pyr_col_count.
 *  pyramid computation: the input separation file and pyramid 
 *            file are checked to have the same variables.
 *            After the pyramid formula has been computed and
 *            the pyramid file has been enlarged, the variables
 *            of the pyramid file and of the separation file
 *            no longer agree, unless no no pyramid formula
 *            was computed.
 *  testing:  the separation file and the pyramid file are
 *            checked to have the same variables.
 *            Thus, col_count = pyr_col_count.
 */

  FILE *f1;

  void  check_nested();
  void  consistency_pyrvar_sepvar();
  void  construct_work_area();
  void  eval_partial_log();
  void  get_pyrrc();
  void  lsqerror();
  void  lsqexit();
  void  define_pyrpred();
  void  remove_work_area();
  void  top_sep_dist();
       
/* 
 *  construct work area 
 */   
  construct_work_area();

/*
 * if .pyr file exists, get pyramid formulas
 */
  if ((f1 = fopen(pyramid_file,"r")) != NULL) {
    fclose(f1);
    get_pyrrc();
  } else {
    pyr_form_count = 0;
  }

/*
 *  create predicate file for training file
 *  if pyr_form_count = 0, the file has one blank record
 */
  define_pyrpred();

/*
 *  evaluate partial logic data of training file
 *  define log_name_list[][]
 */
  eval_partial_log();

/* 
 *  caution: col_count includes all pyramid variables
 *
 *  check consistency of pyramid variables
 *  and separation variables
 */
  consistency_pyrvar_sepvar();

/*
 *  get training records
 *  check records of training file for nestedness
 *  add values defined by pyramid formulas 
 *  construct files
 *    partial_log_fil 
 *    ll_raw_log.data
 *    AB_separation.cnl
 *    bucket_separation.cnl          
 */
  check_nested(); 
                                     
/*
 *  generate separations and distributions
 *
 *  separation control
 *  globalfourtotalsepflg    = global flag for 4 total case
 *  globalfortypartialsepflg = global flag for 40 partial case
 *
 *  fourtotalsepflg = local flag for 4 total case
 *  fortypartialflg = local flag for 40 partial case
 *
 *  as part of 4 total case, separability of individual records
 *  is checked; in addition, if optcstsepflg = 1, an optimal
 *  separation for each record is computed, which is needed
 *  when optimal separations are computed for either 4 total case
 *  or 40 partial case
 */

/*
 *  if optcstsepflg = 1 and optreconlyflg = 1, only optimal
 *  records and no separations are computed by setting
 *      globalfourtotalsepflg = 0
 *      globalfortypartialsepflg = 1
 */
  if ((optcstsepflg == 1) && (optreconlyflg == 1)) {
    globalfourtotalsepflg = 0;
    globalfortypartialsepflg = 1;
  }

  fourtotalsepflg = 1;
  fortypartialsepflg = 0;
  top_sep_dist();

/*
 *  if optcstsepflg = 1 and optreconlyflg = 1,
 *  additional separation calculations are prevented by setting
 *      globalfourtotalsepflg = 1
 *      globalfortypartialsepflg = 0
 */
  if ((optcstsepflg == 1) && (optreconlyflg == 1)) {
    globalfourtotalsepflg = 1;
    globalfortypartialsepflg = 0;
  }

  if (globalfortypartialsepflg == 1) {
    fourtotalsepflg = 0;
    fortypartialsepflg = 1;
    top_sep_dist();
  }

/*
 *  clean and remove work area
 */  
  remove_work_area();
/*
 *  final check of flags
 */
  if ((globalfourtotalsepflg + globalfortypartialsepflg) != 1) {
    lsqerror("lsqcc","202");
    lsqexit(1);
  }
  if ((fourtotalsepflg + fortypartialsepflg) != 1) {
    lsqerror("lsqcc","204");
    lsqexit(1);
  }
  if ((strongsepflg + weaksepflg) != 1) {
    lsqerror("lsqcc","206");
    lsqexit(1);
  }
  if ((shortsepflg + optcstsepflg) != 1) {
    lsqerror("lsqcc","208");
    lsqexit(1);
  } 

  return;
  
}

/*eject*/
/* ----------------------------------------------------------- 
 *  define_pyrpred(): defines pyramid predicate file
 *  for inclusion in training file
 *  if number of pyramid formulas is 0, defines the file to
 *  have one blank record
 * -----------------------------------------------------------
 */
void define_pyrpred() {

  FILE *f1;
  int i;
  void  lsqerror();

  if (lsqscrflg == 1) {
    printf("\n\nDefine predicates file of pyramid\n");
    printf("for use in training file\n");
  }

/* 
 *  open predicate file
 */
  if ((f1 = fopen(pyrpred_file,"w")) == NULL) {
    printf("Cannot open predicates of pyramid file:\n%s\n",
           pyrpred_file);
    printf("Stop\n");
    fprintf(errfil,
           "Cannot open predicates of pyramid file:\n%s\n",
           pyrpred_file);
    fprintf(errfil,
           "Stop\n");
    lsqerror("define_pyrpred","102");
  }

/*
 *  if there are no pyramid formulas, create one blank
 *  record
 */
  if (pyr_form_count == 0 ) {
    fprintf(f1," \n");
    fclose(f1);
    return;
  }

/*
 *  below, pyr_form_count > 0
 */

/*
 *  pyr predicate file
 */
  for (i=pyr_col_count - pyr_form_count +1;
       i<=pyr_col_count;i++) {
    fprintf(f1,"define %s on cases truecost = 1\n",
               &pyr_name_list[i][0]);
  }

  fclose(f1);

  return; 
}

/*  last record of lsqcc.c***** */
