/*  first record of leibnizmacro.h***** */
/*
 *  ********************************************************
 *  definitions of leibniz constants, procedures,
 *  and parameters
 *  ********************************************************
 *
 *  definition of leibniz constants
 */
#define ACTIVE   (-1)
#define DELETED    0
#define TRUE       1
#define FALSE    (-1)
#define FIXTRUE    3
#define FIXFALSE (-3) 
/*
 *  definition of leibniz procedures
 */ 
#define assign_device()    asg_dev(name,state,type,value,errcde)
#define begin_problem()    beg_prb(name,state,type,value,errcde)
#define delete_problem()   del_prb(name,state,type,value,errcde)
#define execute_lbcc()     exe_lbcc(name,state,type,value,errcde)
#define free_device()      fre_dev(name,state,type,value,errcde)
#define get_clsname()      get_cgn(name,state,type,value,errcde)
#define get_dimension()    get_dim(name,state,type,value,errcde)
#define get_dual()         get_dul(name,state,type,value,errcde)
#define get_goal()         get_gol(name,state,type,value,errcde)
#define get_primal()       get_pml(name,state,type,value,errcde)
#define get_value()        get_val(name,state,type,value,errcde)
#define initialize_problem() inz_prb(prgname,name,state,type,value,errcde)
#define limit_error()      lim_err(name,state,type,value,errcde)
#define maxcls_sat()       mxcls_sat(clause,name,state,type,value,errcde)
#define mincls_unsat()     mncls_unsat(clause,name,state,type,value,errcde)  
#define modify_allvar()    mst_allvar(name,state,type,value,errcde)
#define modify_clause()    mst_cls(name,state,type,value,errcde)
#define modify_goal()      mst_gol(name,state,type,value,errcde)
#define modify_problem()   mst_prb(name,state,type,value,errcde)
#define modify_variable()  mst_var(name,state,type,value,errcde)
#define restore_problem()  rst_prb(name,state,type,value,errcde)
#define retrieve_problem() ret_prb(name,state,type,value,errcde)
#define solve_problem()    sol_prb(name,state,type,value,errcde)
#define status_clause()    sts_cls(name,state,type,value,errcde)
#define status_element()   sts_elt(name,state,type,value,errcde)
#define status_problem()   sts_prb(name,state,type,value,errcde)
#define status_storage()   sts_sto(name,state,type,value,errcde)
#define status_variable()  sts_var(name,state,type,value,errcde)
#define store_problem()    sto_prb(name,state,type,value,errcde)
/*
 *  definition of leibniz parameters
 *  they are required in any file calling leibniz procedures
 */
  char name[128+1]="";
  char state[2]="";
  char type[5]="";
  long value[8]={0,0,0,0,0,0,0,0};
  short errcde[2]={0,0};
/*
 *  typedefs needed for some macros
 */
typedef struct {
  char  name[58+1];
  short status;
} CLAUSE_ARRAY;
typedef char PRGNAME_ARRAY[256+1];
/*
 *  declaration of leibniz procedures
 */
  void asg_dev(); 
  void beg_prb();
  void del_prb();
  void exe_lbcc();
  void fre_dev();
  void get_cgn();
  void get_dim();
  void get_dul();
  void get_gol();
  void get_pml();
  void get_val();
  void inz_prb();
  void lim_err();
  void mxcls_sat();
  void mncls_unsat();
  void mst_allvar();
  void mst_cls();
  void mst_gol();
  void mst_prb();
  void mst_var();
  void ret_prb();
  void rst_prb();
  void sol_prb();
  void sts_cls();
  void sts_elt();
  void sts_prb();
  void sts_sto();
  void sts_var();
  void sto_prb();
/*
 */
/* last record of leibnizmacro.h***** */
