/*  first record of compute_separations.c***** */ 
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include "lsqparms.h"
#include "lsqexts.h"


/*
 * interpretation of index arrays
 * applies to both global and local sets A and B
 *
 * for X = A or B:
 *
 * X_rec_intidx[..][j] = index for the record of the total
 * A or B set that is equal to the record  
 * X_log_rec[..][j][1..col_count]
 *
 * for X = A, A_opt, B, or B_opt:
 *
 * X_rec_filidx[..][j] = line where the 
 * record X_log_rec[..][j][1..col_count] begins in the
 * training file
 */

/* 
 *  the labels A and B below refer to the global sets A and B
 */
int  A_opt_rec[max_record_num + 1] [max_column_size + 1];
int  A_opt_rec_filidx[max_record_num + 1];
int  B_opt_rec[max_record_num + 1] [max_column_size + 1];
int  B_opt_rec_filidx[max_record_num + 1];

int  A_opt_cst[max_record_num + 1];
int  B_opt_cst[max_record_num + 1];

int  A_opt_cst_total;
int  B_opt_cst_total;
/* end of arrays with global sets A and B */
 
/*  
 *  the labels A and B below refer to the local sets A and B
 *  thus, the interpretation depends on the subcase being
 *  processed
 */

/*  opt_... refers to records of the local B set */
int  opt_rec[max_record_num + 1] [max_column_size + 1];
int  opt_cst[max_record_num + 1];
int  high_opt_cst;

int  A_log_rec[max_record_num + 1] [max_column_size + 1];
int  A_rec_filidx[max_record_num + 1];
int  A_rec_intidx[max_record_num + 1];

int  B_log_rec[max_record_num + 1] [max_column_size + 1];
int  B_rec_filidx[max_record_num + 1];
int  B_rec_intidx[max_record_num + 1];

int  A_total;
int  B_total;

int  sep_set[sep_set_size][max_column_size +1];
int  sep_set_min[sep_set_size][max_column_size +1];
int  sep_set_max[sep_set_size][max_column_size +1];
int  S_total;
 
int  B_rec_carry_zero[max_record_num][max_column_size + 1];
int  B_rec_carry_posone[max_record_num][max_column_size + 1];
int  B_rec_carry_negone[max_record_num][max_column_size + 1];
int  B_rec_has_zero[max_record_num + 1];
int  B_rec_has_posone[max_record_num + 1];
int  B_rec_has_negone[max_record_num + 1];

int  pos_value[max_column_size + 1];
int  neg_value[max_column_size + 1];
int  bef_fix_B[max_record_num];
int  aft_fix_B[max_record_num];
int  bef_fix_B_total;
int  aft_fix_B_total;
int  B_star_total;
int  B_star[max_record_num];

char s1[namesize];
char s2[namesize];
char tempx[namesize];

char A_set_name[namesize];

char B_set_name[namesize];
char B_set_name1[namesize];
char B_set_name2[namesize];

char explain_size[namesize];
char explain_size1[namesize];
char explain_size2[namesize];

/* end of arrays with local A and B */

FILE *fsep, *fseptmp, *fopt;

void analyze_infeas();
void asg_bef_fix_B();
int  check_pq_var();
void check_separable();
void check_sep_set();
void compile_prg();
int  compute_two_seps();
void con_sub_AB();
char * equiv_log_name();
int  fix_pq_var();
void get_high_opt_cst();
void get_pq_var();
void lsqerror();
void lsqexit();
void print_one_sep_idx();
void print_one_opt_log();
void print_one_sep_log();
void print_opt_rec();
void print_sep_set();
void retrieve_opt_cst();
void show_pq_var();
void sort_bef_fix_B();
void store_B_rec();
void store_opt_rec_cst();
void undo_pq_var();

char * pathing();

/*eject*/
/* -----------------------------------------------------------
 * Summary:
 * int  compute_separations() main routine
 *
 * analyze_infeas()       analyze infeasibility caused by
 *                        logic conditions in training file
 * asg_bef_fix_B()        save records for B set 
 *                        before fixing prb2  
 * check_pq_var()         check if fixing of p and q variables
 *                        makes prb1 unsatisfiable
 * check_separable()      check separability of one record of A/B
 *                        from all records of the other set
 * check_sep_set()        check separation by testing nestedness
 *                        in B and nonnestedness in A
 * compile_prg()          compile and load one program
 * compute_two_seps()     compute two (min/max) separations
 * con_sub_AB()           read the sub_A records and 
 *                        sub_B records. these records are used
 *                        for validation of the separation sets
 * equiv_log_name()       determine equivalent log.data name
 *                        for given problem.data name 
 * fix_pq_var()           fix the p and q variables in prb1 
 *                        according to each B record
 * get_high_opt_cst()     compute high_opt_cst and jlim_bef_fix_B
 * get_pq_var()           retrieve current values of p and q 
 *                        variables
 * lsqerror()             (defined in lsqutil.c)
 * print_one_sep_idx()    write literals by indices for one
 *                        separation
 * print_one_opt_log()    write one optimal record
 * print_one_sep_log()    write literals in logic notation for
 *                        one separation
 * print_opt_rec()        write optimal record
 * print_sep_set()        output separation sets
 * retrieve_opt_cst()     retrieve optimal cost for separating
 *                        A/B records, one at a time, from all
 *                        records of the other set
 * show_pq_var()          show p and q values 
 *                        (diagnostic routine)
 * sort_bef_fix_B()       sort bef_fix_B[] according to 
 *                        opt_cost[]
 * store_B_rec()          store index for 0, 1, -1 for each b
 *                        in B set
 * store_opt_rec_cst()    store optimal separations and costs
 *                        involving each time one A/B record
 *                        versus all records of the other set
 * undo_pq_var()          redo the assignments in prb1 so that 
 *                        the effect of the record b in B 
 *                        processed most recently is eliminated
 *
 * Relationships
 * problem         type of clauses    data.file used in
 *                 and problem        checking step
 *
 * BiA_subAj_msat  clash with A, sat  BiA_subAj_msat.data
 * (is obtained from min problem)     = AiB_subAj_log.data
 *                                    = A subset
 *
 * BiA_subBj_smin  clash with A, min  BiA_subBj_smin.data
 *                                    = AiB_subBj_log.data
 *                                    = B subset
 * BiA_subBj_smax  clash with A, max  BiA_subBj_smax.data
 * (same as sat due to monotonicity)  = AiB_subBj_log.data
 *                                    = B subset
 *
 * AiB_subBj_msat  clash with B, sat  AiB_subBj_msat.data
 * (is obtained from min problem)     = AiB_subBj_log.data
 *                                    = B subset
 *
 * AiB_subAj_smin  clash with B, min  AiB_subAj_smin.data
 *                                    = AiB_subAj_log.data
 *                                    = A subset
 *
 * AiB_subAj_smax  clash with B, max  AiB_subAj_smax.data
 * (same as sat due to monotonicity)  = AiB_subAj_log.data
 *                                    = A subset
 *
 * note: prb1 is a satisfiability problem
 *       prb2 is minimization problem solved approximately
 *------------------------------------------------------------
 */

/*eject*/
/* --------------------------------------------------
 * compute_separations(): compute all separations 
 * and compile logic programs as needed
 * Input:  prb_set.cnl
 * Output: all separation files
 * --------------------------------------------------
 */
int compute_separations() {

  FILE *f1;
  int  sep_pair_num; 
  int  i; 
  int  cbd; /* compile bound */

/*
 *  open problem control file
 */
  if ((f1 = fopen(pathing("prb_set.cnl"),"r")) == NULL) {
    printf("\nCannot open prb_set.cnl\n");
    fprintf(errfil,"\nCannot open prb_set.cnl\n");
    lsqerror("compute_separations","102");
  }
  fscanf(f1,"%d",&sep_pair_num);

/*
 *  open separation file separation_file if
 *  global 4 total case or 40 partial case is specified
 */
  if ((globalfourtotalsepflg == 1) ||
      (fortypartialsepflg == 1)) {
    if ((fsep=fopen(separation_file,"w"))==NULL) {
      printf(
        "\n\n Cannot open separation file: %s\nStop\n\n",
            separation_file);
      fprintf(errfil,
        "\n\n Cannot open separation file: %s\nStop\n\n",
            separation_file);
      lsqerror("compute_separations","104");
    }

/*
 *  open temporary file of separation vectors
 */
    if ((fseptmp = 
       fopen(pathing("sep_vectors_file"),"w")) == NULL) {
      printf("\nCannot open sep_vectors_file\n");
      fprintf(errfil,"\nCannot open sep_vectors_file\n");
      lsqerror("compute_separations","106");
    }

/*  
 *  write separation file header
 */
    fprintf(fsep,"%d formulas with %d logic variables",
            sep_pair_num, col_count);
    if (strongsepflg == 1) {
      fprintf(fsep,", missing values = absent\n");
    } else if (weaksepflg == 1) {
      fprintf(fsep,", missing values = unavailable\n");
    } else {
      lsqerror("compute_separations","202");
    }
    fprintf(fsep,"derived from %d A records and %d B records\n",
	    init_row_size_A, init_row_size_B);
    if (shortsepflg == 1) {
      fprintf(fsep,"Variables\n");
    } else if (optcstsepflg == 1) {
      fprintf(fsep,"for optimal cost classification\n");
      fprintf(fsep,"Variables Cost +Case     -Case\n");
    } else {
      lsqerror("compute_separations","204");
    }

/*
 *  write log_name_list[][] into separation file
 */
    if (shortsepflg == 1) {
      for (i=1;i<=col_count;i++) {
        fprintf(fsep,"    %s\n",&log_name_list[i][0]);
      }
    } else if (optcstsepflg == 1) {
      for (i=1;i<=col_count;i++) {
        fprintf(fsep,"%8s   %8d  %8d\n",&log_name_list[i][0],
                     pos_var_cst[i],neg_var_cst[i]);
      }
    } else {
      lsqerror("compute_separations","206");
    } 
  } /* end of initialization of fsep and fseptmp */

/*
 *  open optimization file optimization_file
 *  if optcstsepflg = 1 and fourtotalsepflg = 1
 */
  if ((optcstsepflg == 1) &&
      (fourtotalsepflg == 1)) {
    if ((fopt=fopen(optimization_file,"w"))==NULL) {
      printf(
        "\n\n Cannot open optimization file: %s\nStop\n\n",
            optimization_file);
      fprintf(errfil,
        "\n\n Cannot open optimization file: %s\nStop\n\n",
            optimization_file);
      lsqerror("compute_separations","208");
    }

/*
 *  write optimization file header
 */
    fprintf(fopt,"Optimal records with");
    fprintf(fopt," %d variables\n",col_count);
    fprintf(fopt,"Variables\n");
/*
 *  write log_name_list[][] into optimization file
 */
    for (i=1;i<=col_count;i++) {
      fprintf(fopt,"    %s\n",&log_name_list[i][0]);
    }

  } /* end of initialization of fopt */ 

/*
 *  process all separation pairs
 */               
  for (i=1; i<=sep_pair_num/2; i++) {
    fscanf(f1,"%s",A_set_name);
    fscanf(f1,"%s",B_set_name1);
    fscanf(f1,"%s",B_set_name2);
    sprintf(explain_size1,"min");
    sprintf(explain_size2,"max");
/*
 *  define B_set_name and explanation for min case
 *  A_set_name is already correct
 */
    strcpy(B_set_name,B_set_name1);
    strcpy(explain_size,explain_size1);
/*
 *  compile and load program
 *  B_set_name is min problem prb2
 *  A_set_name is sat problem prb1, obtained here by
 *  dropping objective function from B_set_name problem 
 */
    cbd = 0;
    compile_prg(B_set_name,cbd);
/*
 * read sub_A and sub_B records 
 */
    con_sub_AB();
/*
 *  if fourtotalsepflg = 1 and 
 *     (optcstsepflg = 1 or triviallogflg = 0): 
 *    check separability of each record
 *    if optcstsepflg = 1 :
 *      compute and store in opt_rec[][] separations each of 
 *      which separates one record of current B from all records 
 *      of current A, and store optimal cost in opt_cst[]
 *      the separations may also be viewed as optimal B records 
 *      that are still separable from all A records
 */
    if ((fourtotalsepflg == 1) &&
        ((optcstsepflg == 1) || 
         (triviallogflg == 0))) {
      check_separable();
      if (optcstsepflg == 1) {
/*
 *  store opt_rec[][], opt_cst[], B_rec_filidx[] in
 *  appropriate arrays for global A and B as follows:
 *  into A_opt_rec[],A_opt_rec_filidx[], A_opt_cst[], A_opt_cst_total
 *  or   B_opt_rec[],B_opt_rec_filidx[], B_opt_cst[], B_opt_cst_total
 */ 
        store_opt_rec_cst();
      }
    }
    if (fortypartialsepflg == 1) {
/*
 * retrieve optimal cost of separating each record of current
 * B from all records of current A, if optcstsepflg = 1 and
 * fortypartialsepflg = 1
 */
      if (optcstsepflg == 1) {
        retrieve_opt_cst();
      }
    }
/*
 * compute two separations (min and max) if 
 * globalfourtotalsepflg = 1 or fortypartialsepflg = 1
 */
    if ((globalfourtotalsepflg == 1) ||
        (fortypartialsepflg == 1)) {
      if (compute_two_seps(i) == -1) {
        lsqerror("compute_separations","302");
      }
    }

    if (fortypartialsepflg == 1) {
      if (i%2 ==0) {
        if (lsqscrflg == 1) {
          printf("%d ",i/2);
          fflush(stdout);
        }
      }
    }
  }
/*
 * write optimal separation output if
 * optcstsepflg = 1 and fourtotalsepflg = 1
 */
  if ((optcstsepflg == 1) &&
      (fourtotalsepflg == 1)) {
    print_opt_rec();
    fprintf(fopt,"ENDATA\n");
    fclose(fopt);
  }

/*
 * close f1, fsep, fseptmp
 */
  fclose(f1);
  if ((globalfourtotalsepflg == 1) ||
      (fortypartialsepflg == 1)) {
    fprintf(fsep,"ENDATA\n");  
    fclose(fsep);
    fclose(fseptmp);
  }
 
  if (fortypartialsepflg == 1) {
    if (lsqscrflg == 1) {
      printf("\n");
    }
  }
  return(0);

}

/*eject*/
/* ----------------------------------------------------------
 * void analyze_infeas(): analyze infeasibility caused by
 * logic conditions in training file
 * ---------------------------------------------------------- 
 */
void analyze_infeas() {

  #include "leibnizmacro.h"

  int i,in,nr;

  CLAUSE_ARRAY clause[max_user_row + 1];

/* 
 *  get problem size
 */
  status_problem();
  if (errcde[0] != 0) {
    lsqerror("analyze_infeas","102");
  }
  nr = value[1];

/* 
 *  get clause names assigned by user
 */
  in = -1;
  for (i=1;i<=nr;i++) {
    value[0] = i;
    get_clsname();
    if (errcde[0] != 0) {
    lsqerror("analyze_infeas","202");
    }
    if (strcmp(type,"LOGC") == 0) {
      in++;
      if (in > max_user_row -1) {
        lsqerror("analyze_infeas","204");
      }
      strcpy(clause[in].name,name);
    } 
  }
  strcpy(clause[in+1].name,"");

/* 
 *  find minimal unsatisfiable subset
 */
  mincls_unsat();
  printf(
   "The unnamed logic clauses and the logic clauses\n");
  printf(
   "with the subsequently given names cause the problem\n");
  printf(
   "If no clause name follows below, the user should assign\n");
  printf(
   "names to suspected clauses and rerun the program\n\n");
  fprintf(errfil,
   "The unnamed logic clauses and the logic clauses\n");
  fprintf(errfil,
   "with the subsequently given names cause the problem\n");
  fprintf(errfil,
   "If no clause name follows below, the user should assign\n");
  fprintf(errfil,
   "names to suspected clauses and rerun the program\n");

  for (i=0;i<=in;i++) {
    if (clause[i].status == -1) {
      printf(
        "Unknown clause: %s\n",clause[i].name);
      fprintf(errfil,
        "Unknown clause: %s\n",clause[i].name);
      lsqerror("analyze_infeas","302");
    }
    if (clause[i].status == 1) {
      printf(
        "  %s\n",clause[i].name);
      fprintf(errfil,
        "  %s\n",clause[i].name);
    }
  } /* end for i */
  printf("\n");
  fprintf(errfil,"\n");

  return;
}

/*eject*/
/* ----------------------------------------------------------
 * void asg_bef_fix_B()
 * save records for B set before fixing prb2
 * ---------------------------------------------------------- 
 */
void asg_bef_fix_B() {

  int i;

  bef_fix_B_total = B_total;   
  for (i=1;i<=B_total;i++ ) {
    bef_fix_B[i] = i;
  }
/*
 *  if optcstsepflg = 1, sort the bef_fix_B[] indices
 *  according to opt_cst[]
 */
  if (optcstsepflg == 1) {
    sort_bef_fix_B(); 
  }
  return;

}

/*eject*/
/*----------------------------------------------------------- 
 * int check_pq_var()
 * check if fixing of p and q variables makes prb1 
 * unsatisfiable.
 *-----------------------------------------------------------
 */
int check_pq_var() {

  #include "leibnizmacro.h"

  if (optcstsepflg == 1) {
    value[4] = 17;
    strcpy(type,"N");
  }
  solve_problem();
  if (errcde[0] != 0) {
    lsqerror("check_pq_var","102");
  }
  if ((strcmp(state, "U") == 0) ||
      ((optcstsepflg == 1) &&
       (value[2] > high_opt_cst))) {
    return 1;
  } else {
    return 0;
  }
  
}

/*eject*/
/*----------------------------------------------------------- 
 * void check_separable(): check separability of each record 
 * of A/B from all records of the other set
 * if optcstsepflg = 1, also output for each A/B record
 * optimal separation that separates the record from all records
 * of the other set. That separation may also be viewed as
 * an optimal A/B record
 * output: opt_rec[][]
 *         opt_cst[]
 *-----------------------------------------------------------
 */
void check_separable() {

  #include "leibnizmacro.h"

  int  i,j,stopflg;

  char s1[2],s2[2];

/*
 *  store A and B label, initialize stopflg
 */
  s1[0] = B_set_name[0];
  s1[1] = '\0';
  s2[0] = B_set_name[2];
  s2[1] = '\0';
  stopflg = 0;

/*
 *  set problem type depending on optcstsepflg
 */


  if (optcstsepflg == 1) {
    strcpy(type,"MIN");
  } else {
    strcpy(type,"SAT");
  }
  modify_problem();
  if (errcde[0] != 0) {
    lsqerror("check_separable","102");
  }

/*
 *  process each B record
 */
  for (i=1;i<=B_total;i++) {

/*
 *  unfix all variables
 */
    strcpy(state,"V");
    restore_problem();
    if (errcde[0] != 0) {
      lsqerror("check_separable","202");
    }

/*
 *  restrict variables according to B record i
 */
    for (j=1;j<=col_count;j++) {
      if ((B_log_rec[i][j] == 0) ||
          (B_log_rec[i][j] == 1)) {
        value[0] = neg_name_idx[j];
        strcpy(state,"F");
        modify_variable();
        if (errcde[0] != 0) {
          lsqerror("check_separable","302");
        }
      }
      if ((B_log_rec[i][j] == 0) ||
          (B_log_rec[i][j] == -1)) {
        value[0] = pos_name_idx[j];
        strcpy(state,"F");
        modify_variable();
        if (errcde[0] != 0) {
          lsqerror("check_separable","304");
        }
      }
    } /* end for j */

/*
 *  solve problem
 */

    if (optcstsepflg == 1) {
      value[4] = 17;
      strcpy(type,"N");
    }
    solve_problem();
    if (errcde[0] != 0) {
      lsqerror("check_separable","502");
    }

/*
 *  if infeasible, have incompatible logic conditions
 */
    if (strcmp(state,"U") == 0) {
      printf(
         "Logic conditions in training file rule out\n");
      printf(
         "separation of record %d of set %s from set %s\n",
         B_rec_filidx[i],s1,s2);
      fprintf(errfil,
         "Logic conditions in training file rule out\n");
      fprintf(errfil,
         "separation of record %d of set %s from set %s\n",
         B_rec_filidx[i],s1,s2);
      analyze_infeas();
      stopflg = 1;
    }

/*
 *  skip subsequent optimization calculations if an error in
 *  logic conditions has been detected above or if short 
 *  separations are to be found
 */
    if ((stopflg == 1) ||
        (shortsepflg == 1)) {
      continue;
    }

/*
 *  no error has been detected so far, and have optimization case
 *  store optimal objective function value
 */
    opt_cst[i] = value[2];
/*
 *  store separation
 */
    for (j=1;j<=col_count;j++) {

      value [0] = pos_name_idx[j];
      get_value();
      if (errcde[0] != 0) {
        lsqerror("check_separable","702");
      }
      if (strcmp(state,"T") == 0) {
        opt_rec[i][j] = 1;
        continue;
      }

      value [0] = neg_name_idx[j];
      get_value();
      if (errcde[0] != 0) {
        lsqerror("check_separable","704");
      }
      if (strcmp(state,"T") == 0) {
        opt_rec[i][j] = -1;
        continue;
      }

      opt_rec[i][j] = 0;
      
    } /* end for j */
  } /* end for i*/

/*
 *  if stopflg = 1, user has specified incompatible logic in
 *  training file, stop
 */
  if (stopflg == 1) {
    printf(
      "Logic specified in training file rules out");
    printf(
      " separations\nStop\n");
    fprintf(errfil,
      "Logic specified in training file rules out");
    fprintf(errfil,
      " separations\nStop\n");
    lsqexit(1);
  }

  return;
}
 
/*eject*/
/*---------------------------------------------------
 * check_sep_set()
 * check separation set by testing nestedness in B and
 * nonnestedness in A
 *---------------------------------------------------
 */

void check_sep_set() {
  int i,j,A_true,B_true;

  j = 0; /* to suppress compiler warning message */

/*
 *  check min case
 */
  for (i=1;i<=A_total;i++) {                /* A_true loop */
    A_true = LSQFALSE;
    if (strongsepflg == 1) {
      for (j=1;j<= col_count;j++) {
        if ((sep_set_min[S_total][j]*A_log_rec[i][j]) == -1) {
          A_true = LSQTRUE;
          break;
        }
      }
    } else if (weaksepflg == 1) {
      for (j=1;j<= col_count;j++) {
        if (((sep_set_min[S_total][j] == 1) &&
           (A_log_rec[i][j] != 1)) || 
          ((sep_set_min[S_total][j] == -1) &&
           (A_log_rec[i][j] != -1))) {
          A_true = LSQTRUE;
          break;
        }
      }
    } else {
      lsqerror("check_sep_set","102");
    }
    if (A_true == LSQFALSE) {
      /* from A set checking, separating set is invalid */
      printf("Indices i = %3d , j = %3d\n",i,j);
      fprintf(errfil,"Indices i = %3d , j = %3d\n",i,j);
      lsqerror("check_sep_set","104");
    }
  }
               
  for (i=1;i<= B_star_total;i++) {          /* B_true loop */
    B_true = LSQTRUE;
    for (j = 1;j <= col_count;j++) {
      if (((sep_set_min[S_total][j] == 1) &&
         (B_log_rec[B_star[i]][j] != 1)) || 
        ((sep_set_min[S_total][j] == -1) &&
         (B_log_rec[B_star[i]][j] != -1))) {
        B_true = LSQFALSE;
        break;
      }
    }
    if (B_true == LSQFALSE) {
      /* from B set checking, separation set is invalid */
      printf("Indices i = %3d , j = %3d\n",i,j);
      fprintf(errfil,"Indices i = %3d , j = %3d\n",i,j); 
      lsqerror("check_sep_set","106");
    }
  }
/*
 *  check max case
 */
  for (i=1;i<=A_total;i++) {                /* A_true loop */
    A_true = LSQFALSE;
    if (strongsepflg == 1) {
      for (j=1;j<= col_count;j++) {
        if ((sep_set_max[S_total][j]*A_log_rec[i][j]) == -1) {
          A_true = LSQTRUE;
          break;
        }
      }
    } else if (weaksepflg == 1) {
      for (j=1;j<= col_count;j++) {
        if (((sep_set_max[S_total][j] == 1) &&
           (A_log_rec[i][j] != 1)) || 
          ((sep_set_max[S_total][j] == -1) &&
           (A_log_rec[i][j] != -1))) {
          A_true = LSQTRUE;
          break;
        }
      }
    } else {
      lsqerror("check_sep_set","202");
    }
    if (A_true == LSQFALSE) {
      /* from A set checking, separating set is invalid */
      printf("Indices i = %3d , j = %3d\n",i,j);
      fprintf(errfil,"Indices i = %3d , j = %3d\n",i,j);
      lsqerror("check_sep_set","204");
    }
  }
               
  for (i=1;i<= B_star_total;i++) {          /* B_true loop */
    B_true = LSQTRUE;
    for (j = 1;j <= col_count;j++) {
      if (((sep_set_max[S_total][j] == 1) &&
           (B_log_rec[B_star[i]][j] != 1)) ||
          ((sep_set_max[S_total][j] == -1) &&
           (B_log_rec[B_star[i]][j] != -1))) {
        B_true = LSQFALSE;
        break;
      }
    }
    if (B_true == LSQFALSE) {
      /* from B set checking, separation set is invalid */
      printf("Indices i = %3d , j = %3d\n",i,j);
      fprintf(errfil,"Indices i = %3d , j = %3d\n",i,j); 
      lsqerror("check_sep_set","206");
    }
  }
  return;
}

/*eject*/
/* ------------------------------------------------
 *  compute_two_seps(): compute two separations using 
 *  the program for B_set_name for sat, min, and max
 * ------------------------------------------------
 */
int compute_two_seps(int ns) {

  #include "leibnizmacro.h"

  int  i,done,l;

/*
 *  store B records in several arrays
 */
  store_B_rec();
/*
 *  intialize bef_fix_B[]
 *  if optcstsepflg = 1, sort according to opt_cst[]
 */
  asg_bef_fix_B();
 
  S_total = 0;
  done = 1;

  while (done != 0) {
    if (S_total>=sep_set_size-1) {
/*
 *  too many iterations
 */
      printf(
        "Too many clauses required for formula\n");
      fprintf(errfil,
        "Too many clauses required for formula.\n");
      printf(
        "To eliminate the difficulty, must\n");
      fprintf(errfil,
        "To eliminate the difficulty, must\n");
      if (optcstsepflg == 1) {
        printf(
       "increase lambda value to reduce number of clauses, or\n");
        printf(
         "Stop\n");
        fprintf(errfil,
       "increase lambda value to reduce number of clauses, or\n");
        fprintf(errfil,
         "Stop\n");
      } else {
        printf(
         "increase parameter sep_set_size\n");
        printf(
         "Stop\n");
        fprintf(errfil,
         "increase parameter sep_set_size\n");
        fprintf(errfil,
         "Stop\n"); 
      }
      lsqexit(1);         
    }

    S_total++;

/*
 *  if optcstsepflg = 1, use MINSAT for record selection
 *  else use SAT
 */
    if (optcstsepflg == 1) {
      strcpy(type,"MIN");
    } else {        
    strcpy(type,"SAT");
    }
    modify_problem();
    if (errcde[0] != 0) {
      lsqerror("compute_two_seps","208");
    }

/*
 *  unfix all variables
 */
    strcpy(state,"V");
    restore_problem();
    if (errcde[0] != 0) {
      lsqerror("compute_two_seps","210");
    }

/*
 *  decide fixing of variables according to B records
 */ 
    done = fix_pq_var();
    if ((done != 0) &&
        (done != 1)) {          /* cannot generate classifier */
      lsqerror("compute_two_seps","212");
    }
/*
 *  fixing of pos and neg variables to 
 *  False values is now completed
 *  use same fixing to solve prb2
 *
 *  solve prb2 twice
 *  (1) min case, gives solution for min number of literals
 *      or for minimum total cost
 *      the min solution is found solving the compiled
 *      minimization problem   
 *  (2) max case, gives solution for max number of literals
 *      the max solution is computed directly from the
 *      fixed variable values since all variables of the
 *      separation clauses are monotone and since the remaining
 *      clauses are ignored for the max problem
 */

/*
 *  min case
 */
    strcpy(type,"MIN");
    modify_problem();
    if (errcde[0] != 0) {
      lsqerror("compute_two_seps","232");
    }
    if (optcstsepflg == 1) {
      value[4] = 17;
    } else {
      value[4] = 1;
    }
    strcpy(type,"N"); 
    solve_problem();
    if (errcde[0] != 0) {
      lsqerror("compute_two_seps","234");
    }
/*
 *  max case requires no computation since all
 *  variables not fixed at False can be set to True
 *  due to monotonicity of columns
 *
 *  get solution values for both cases and output 
 *  corresponding separating vectors 
 */
    for (i=1;i<=col_count;i++) {
/*
 *  implicitly used fact: for each j, at least one of the logic 
 *  pos, neg variables has been fixed at False
 *
 *  value for pos variable
 */
      value[0] = pos_name_idx[i];
      get_value();  
      if (errcde[0] != 0) {
        lsqerror("compute_two_seps","302");
      }
/*
 *  if variable value is True, have correct information for
 *  both cases 
 */
      if (strcmp(state,"T") == 0) {
        sep_set_min[S_total][i] = 1;
        sep_set_max[S_total][i] = 1;
        continue;
      }
      sep_set_min[S_total][i] = 0;
      sep_set_max[S_total][i] = 0;   
/*
 *  if value[2] = Truecost <= lsqdelta, reconsider
 *  the assignment of 0 for max case, and assign 1 for max case
 *  if it is not contrary to fixing variables forced by B records
 *  given such assignment of 1 for max case, 0 is already
 *  correctly assigned to min case. 
 */
      if (value[2] <= lsqdelta) {
        value[0] = pos_name_idx[i];
        status_variable();
        if (errcde[0] != 0) {
          lsqerror("compute_two_seps","314");
        }
        if (strcmp(state,"F") != 0) {
          sep_set_max[S_total][i] = 1;
          continue;
        }
      }
/*
 *  value for neg variable
 */
      value[0] = neg_name_idx[i];
      get_value();  
      if (errcde[0] != 0) {
        lsqerror("compute_two_seps","312");
      }
/*
 *  if variable value is True, have correct information for
 *  both cases 
 */
      if (strcmp(state,"T") == 0) {
        sep_set_min[S_total][i] = -1;
        sep_set_max[S_total][i] = -1;
        continue;
      }  
/*
 *  if value[2] = Truecost <= lsqdelta, reconsider
 *  the assignment of 0 for max case, and assign -1 for max case
 *  if it is not contrary to fixing variables forced by B records
 *  given such assignment of -1 for max case, 0 is already
 *  correctly assigned to min case. 
 */
      if (value[2] <= lsqdelta) {
        value[0] = neg_name_idx[i];
        status_variable();
        if (errcde[0] != 0) {
          lsqerror("compute_two_seps","314");
        }
        if (strcmp(state,"F") != 0) {
          sep_set_max[S_total][i] = -1;
          continue;
        }
      }
    } /* end for i */
/*
 *  check sep_set_min[S_total][] and sep_set_max[S_total][]
 *  for correctness
 */     
    check_sep_set();

/* if the statement below is activated, all
 * logic formulas consist of just the first clause
 * and thus are NOT correct. Thus, activate the
 * statement ONLY for experiments involving the
 * first generated clause of each formula
 */
/*   if (S_total==25) {
     done = 0;
     } */
/* end of test modification
 */

  }/* end while */

/*
 *  output min separation
 */
  for (l=1;l<=S_total;l++) {
    for (i=1;i<=col_count;i++) {
      sep_set[l][i] = sep_set_min[l][i];
    }
  }
  print_sep_set(2*(ns-1)+1);
/*
 *  output max separation
 */
  strcpy(B_set_name,B_set_name2);
  strcpy(explain_size,explain_size2);

  for (l=1;l<=S_total;l++) {
    for (i=1;i<=col_count;i++) {
      sep_set[l][i] = sep_set_max[l][i];
    }
  }
  print_sep_set(2*ns);
  
  return(0);
}

/*eject*/
/*-------------------------------------------------------------
 * void con_sub_AB(): read the sub_A records and sub_B records
 *-------------------------------------------------------------
 */
void con_sub_AB() {

  int i,j,i_num;
  char s1[namesize];
  FILE *f1;

  strcpy(s1,A_set_name);
  strcat(s1,".data");
/* 
 *  convert s1 to equivalent log file name,
 *  which is returned by equiv_log_name()
 */
  strcpy(s2,equiv_log_name(s1));  
  if ((f1 = fopen(pathing(s2),"r")) == NULL) {
    printf("Cannot open file %s\n",s2);
    fprintf(errfil,"Cannot open file %s\n",s2);
    lsqerror("con_sub_AB","102");
  }
  fscanf(f1,"%d",&A_total);
  fscanf(f1,"%d",&i_num);        /* column count, have already */
  for (i=1;i<=A_total;i++) {
    fscanf(f1,"%d",&A_rec_filidx[i]);
    fscanf(f1,"%d",&A_rec_intidx[i]);
    for(j=1;j<=col_count;j++) {
      fscanf(f1,"%d",&A_log_rec[i][j]);
    }
  }
  fclose(f1);
  
  strcpy(s1,B_set_name);
  strcat(s1,".data");
/* 
 *  convert s1 to equivalent log file name,
 *  which is returned by equiv_log_name()
 */
  strcpy(s2,equiv_log_name(s1));
  if ((f1 = fopen(pathing(s2),"r")) == NULL) {
    printf("Cannot open file %s\n",s2);
    fprintf(errfil,"Cannot open file %s\n",s2);
    lsqerror("con_sub_AB","104");
  }
  fscanf(f1,"%d",&B_total);
  fscanf(f1,"%d",&i_num);        /* column count, have already */
  for(i=1;i<=B_total;i++) {
    fscanf(f1,"%d",&B_rec_filidx[i]);
    fscanf(f1,"%d",&B_rec_intidx[i]);
    for(j=1;j<=col_count;j++) {
      fscanf(f1,"%d",&B_log_rec[i][j]);
    }
  }
  fclose(f1);
  return;
 
}

/*eject*/
/*----------------------------------------------------------
 *  equiv_log_name(): converts problem.data file name
 *  to log.data file name containing the desired subset of
 *  records
 *----------------------------------------------------------
 */
char * equiv_log_name(char st[]) {

int  n;
/*
 *  input file name      output file name      
 *  BiA_subAj_msat.data  AiB_subAj_log.data (is A subset)  
 *  AiB_subAj_smin.data           "
 *  AiB_subAj_smax.data           "
 *
 *  AiB_subBj_msat.data  AiB_subBj_log.data (is B subset)
 *  BiA_subBj_smin.data           "
 *  BiA_subBj_smax.data           "
 */
  strcpy(tempx,st);
  tempx[0] = 'A';
  if (tempx[3] == '_') {        /* i has 1 digit   */
    tempx[2] = 'B';
  } else if(tempx[4] == '_') {  /* i has 2 digits  */
    tempx[3] = 'B';
  } else {                      /* i has >2 digits */
    lsqerror("equiv_log_name","102");
  }
  n = strlen(tempx);
  strcpy(&tempx[n-9],"log.data");
  return(tempx);  

}

/*eject*/
/*-----------------------------------------------------------
 * int fix_pq_var(): fix the p and q variables in prb1 
 * according to each record of B
 *-----------------------------------------------------------
 */
int fix_pq_var() {

  #include "leibnizmacro.h"

  int i,j,k;

/*
 *  bef_fix_B[j] = index of jth record that has not yet been
 *                 processed and thus is in B and not Bstar
 *  bef_fix_B_total = total number of records not yet processed
 *  B_star[j] = index of jth record in Bstar
 *  B_star_total = size of Bstar
 *  aft_fix_B[j] and aft_fix_B_total are the bef_fix data 
 *  for next call of fix_pq_var
 *
 *  check that bef_fix_B_total > 0
 */
  if (bef_fix_B_total <= 0) {
    lsqerror("fix_pq_var","92");
  }
/*
 *  if optcstsepflg = 1, compute high_opt_cst and jlim_bef_fix_B
 */
  if (optcstsepflg == 1) {
    get_high_opt_cst();
  }  
  
  aft_fix_B_total = 0;
  B_star_total = 0;
  for(j=1;j<= bef_fix_B_total;j++) {
/*
 * if optcstsepflg = 1 and opt_cst[] > high_opt_cst, then
 *  skip over all remaining cases since opt_cst[] is too high
 */
    if ((optcstsepflg == 1) &&
        (opt_cst[B_rec_intidx[bef_fix_B[j]]] > high_opt_cst)) {
      for (i=j;i<=bef_fix_B_total;i++) {
        aft_fix_B_total++;
        aft_fix_B[aft_fix_B_total] = bef_fix_B[i];
      }
      break;
    }
    get_pq_var(); /* for the undo job */
    for (i = 1 ; i <= (B_rec_has_posone[bef_fix_B[j]]); i++) {
      value[0] = 
        neg_name_idx[B_rec_carry_posone[bef_fix_B[j]][i]];
      strcpy(state,"F");
      modify_variable();
      if (errcde[0] != 0) {
        lsqerror("fix_pq_var","102");
      }       
    }

    for (i=1;i<=(B_rec_has_negone[bef_fix_B[j]]);i++) {
      value[0] = 
        pos_name_idx[B_rec_carry_negone[bef_fix_B[j]][i]];
      strcpy(state,"F");
      modify_variable();
      if (errcde[0] != 0) {
        lsqerror("fix_pq_var","104");
      }       
    }

    for (i=1;i<=(B_rec_has_zero[bef_fix_B[j]]);i++) {
      value[0] =
        pos_name_idx[B_rec_carry_zero[bef_fix_B[j]][i]];
      strcpy(state,"F");
      modify_variable();
      if (errcde[0] != 0) {
        lsqerror("fix_pq_var","106");
      }       
    }

    for (i=1;i<=(B_rec_has_zero[bef_fix_B[j]]);i++) {
      value[0] =
        neg_name_idx[B_rec_carry_zero[bef_fix_B[j]][i]];
      strcpy(state,"F");
      modify_variable();
      if (errcde[0] != 0) {
        lsqerror("fix_pq_var","108");
      }       
    }
/* 
 * if this is first B record, need not check if separation exists
 * or that its cost is below high_opt_cst
 */
    if ((B_star_total >= 1) &&
        (check_pq_var())) {
      undo_pq_var(bef_fix_B[j]);
      aft_fix_B_total++;
      aft_fix_B[aft_fix_B_total] = bef_fix_B[j];
    } else {
      B_star_total++;
      B_star[B_star_total] = bef_fix_B[j];
    }
  }

  if (aft_fix_B_total != 0) {
    bef_fix_B_total = aft_fix_B_total;
    for ( k = 1; k <= bef_fix_B_total; k++) {
      bef_fix_B[k] = aft_fix_B[k];
    }
/*
 *  check that at least one B record was handled
 */
    if (B_star_total == 0) {
      lsqerror("fix_pq_var","302");
    }
    return 1;
  } else { 
    return 0;       /* no B records left */
  }
  
}

/*eject*/
/* ----------------------------------------------------------
 * void get_high_opt_cst(): compute high_opt_cst
 * ---------------------------------------------------------- 
 */
void get_high_opt_cst() {

  float z;

  if (bef_fix_B_total < 1) {
    lsqerror("get_pq_var","102");
  } 
  z = opt_cst[B_rec_intidx[bef_fix_B[1]]];
  z *= lsqlambda;
  z += 0.5;
  high_opt_cst = z;

  return;

}
 
/*eject*/
/*-----------------------------------------------------------
 * void get_pq_var()
 * retrieve current values of p and q variables.
 *-----------------------------------------------------------
 */
void get_pq_var() {

  #include "leibnizmacro.h"

  int i;
  
  for (i=1; i<=col_count; i++) {
    value[0] = pos_name_idx[i];
    status_variable();
    if (errcde[0] != 0) {
      lsqerror("get_pq_var","102");
    }

    if (strcmp(state,"F") == 0) {
      pos_value[i] = 0; 
    } else {
      pos_value[i] = 1;
    }
  }
  
  for (i=1; i<=col_count; i++) {
    value[0] = neg_name_idx[i];
    status_variable();
    if (errcde[0] != 0) {
      lsqerror("get_pq_var","104");
    }
    if (strcmp(state,"F") == 0) {
      neg_value[i] = 0; 
    } else {
      neg_value[i] = 1;
    }
  }      
  return;
  
}

/*eject*/
/* ----------------------------------------------------------
 * void print_one_opt_log(): write entries of one optimal record
 * caution: does not write final end_of_line '\n'
 * ---------------------------------------------------------- 
 */
void print_one_opt_log(FILE *fout,
     char *indentformat,int ktot,int sep[]) {

  int j,k,n,nskip;

  nskip = strlen(indentformat);
  fprintf(fout,"%s",indentformat);
  n = nskip; /* writing position for current record */
  k = 0; /* number of literals already processed */
  for (j=1;j<=col_count;j++) {
    if (sep[j] != 0) {
      k++;
      if (sep[j] == -1) {
       fprintf(fout,"-");
        n++;
      }
      fprintf(fout,"%s",&log_name_list[j][0]);
      n += strlen(&log_name_list[j][0]);
      if (k < ktot) {
        fprintf(fout,"  ");
        n += 2;
      }
      if ((n > 50) &&
          (k < ktot)) {
        fprintf(fout,"\n%s",indentformat);
        n = nskip;
      }
    }    
  }
  fprintf(fout,".");
  return;

}

/*eject*/
/* ----------------------------------------------------------
 * void print_one_sep_idx(): write literals by indices for 
 * one separation into file fout
 * caution: does not write final end_of_line '\n'
 * ---------------------------------------------------------- 
 */
void print_one_sep_idx(FILE *fout,
     char *indentformat,int ktot,int sep[]) {

  int j,k,n,nskip;

  nskip = strlen(indentformat);
  k = 0; /* number of literals already processed */
  n = nskip; /* writing position for current record */
  for (j=1;j<=col_count;j++) {
    if (sep[j] == 1) {
      fprintf(fout," %4d",j);
      k++;
      n += 5;
    } else if (sep[j] == -1) {
      fprintf(fout," %4d",-j);
      k++;
      n += 5;
    }
    if ((n > 50) &&
        (k < ktot)) {
      fprintf(fout,"\n%s",indentformat);
      n = nskip;
    }
  }

  return;

}

/*eject*/
/* ----------------------------------------------------------
 * void print_one_sep_log(): write literals in logic notation
 * for one separation into file fout
 * caution: does not write final end_of_line '\n'
 * ---------------------------------------------------------- 
 */
void print_one_sep_log(FILE *fout,
     char *indentformat,int ktot,int sep[]) {

  int j,k,n,nskip;

  nskip = strlen(indentformat);
  fprintf(fout,"%s",indentformat);
  n = nskip; /* writing position for current record */
  fprintf(fout,"[ ");
  n += 2;
  k = 0; /* number of literals already processed */
  for (j=1;j<=col_count;j++) {
    if (sep[j] != 0) {
      k++;
      if (k >= 2) {
        fprintf(fout," & ");
        n += 3;
      }
      if (sep[j] == -1) {
        fprintf(fout,"-");
        n++;
      }
      fprintf(fout,"%s",&log_name_list[j][0]);
      n += strlen(&log_name_list[j][0]);
      if ((n > 50) &&
          (k < ktot)) {
        fprintf(fout,"\n%s",indentformat);
        n = nskip;
      }    
    }
  }
  fprintf(fout," ]");
  return;

}

/*eject*/
/* ----------------------------------------------------------
 * void print_opt_rec(): write optimal records of
 * sets Astar and Bstar
 * ---------------------------------------------------------- 
 */
void print_opt_rec() {

  int i,j,ktot;

  char fmt[100];

  strcpy(fmt,"");

  fprintf(fopt,
  "\n* 'line' means line number of original training record\n");
  fprintf(fopt,
  "* 'cost' means minimum total cost for classifying record\n");
  fprintf(fopt,
  "* 'entries' means number of entries in record\n");

  fprintf(fopt,"\nBEGIN A   * optimal set Astar\n");
  for (i=1;i<=A_opt_cst_total;i++) {
    if ((i > 1) &&
        (A_opt_rec_filidx[i] == A_opt_rec_filidx[i-1])) {
/*
 *  skip duplicate record, created in construct_ll_raw_log_file()
 *  so that record sets have minimum required number of records
 */
      continue;
    }
    ktot = 0;
    for (j=1;j<=col_count;j++) {
      if (A_opt_rec[i][j] != 0) {
        ktot++;
      }
    }
    fprintf(fopt,
    "* begin optimal record    line = %d",A_opt_rec_filidx[i]);
    fprintf(fopt,"    cost = %d",A_opt_cst[i]);
    fprintf(fopt,"    entries = %d\n",ktot);
    print_one_opt_log(fopt,fmt,ktot,&A_opt_rec[i][0]);
    fprintf(fopt,"\n");
    fprintf(fopt,"* end   optimal record    line = %d\n",
                 A_opt_rec_filidx[i]);
  }

  fprintf(fopt,"\nBEGIN B   * optimal set Bstar\n");
  for (i=1;i<=B_opt_cst_total;i++) {
    if ((i > 1) &&
        (B_opt_rec_filidx[i] == B_opt_rec_filidx[i-1])) {
/*
 *  skip duplicate record, created in construct_ll_raw_log_file()
 *  so that record sets have minimum required number of records
 */
      continue;
    }
    ktot = 0;
    for (j=1;j<=col_count;j++) {
      if (B_opt_rec[i][j] != 0) {
        ktot++;
      }
    }
    fprintf(fopt,
    "* begin optimal record    line = %d",B_opt_rec_filidx[i]);
    fprintf(fopt,"    cost = %d",B_opt_cst[i]);
    fprintf(fopt,"    entries = %d\n",ktot);
    print_one_opt_log(fopt,fmt,ktot,&B_opt_rec[i][0]);
    fprintf(fopt,"\n");
    fprintf(fopt,"* end   optimal record    line = %d\n",
                 B_opt_rec_filidx[i]);    
  }

  return;

}

/*eject*/
/* ---------------------------------------------------------
 * void print_sep_set()
 * output separation sets.
 * ---------------------------------------------------------
 */
void print_sep_set(int nc) {

  int i,j,ktot;

  char fmt[100];

  strcpy(fmt,"             "); /* 13 blanks */

/*
 *  output to separation_file
 */
  s1[0] = B_set_name[0];
  s1[1] = '\0';
  fprintf(fsep,"\nFormula %d %s %d %s ",
      nc,s1,S_total,explain_size);
  fprintf(fsep,"(True means vote for %s, ",s1);
  fprintf(fsep,"%d %s size clause(s))\n",
          S_total,explain_size);
  fprintf(fsep,"clause size literals\n");

  for (i=1; i<=S_total; i++) {
    ktot = 0;
    for (j=1; j<=col_count; j++) {
      if (sep_set[i][j] != 0) {
        ktot++;
      }
    }
    fprintf(fsep,"%5d%5d   ",i,ktot);
    print_one_sep_idx(fsep,fmt,ktot,&sep_set[i][0]);
    fprintf(fsep,"\n");
  }
  fprintf(fsep,"%sLogic notation\n",fmt);
  for (i=1; i<=S_total; i++) {
    ktot = 0;
    for (j=1; j<=col_count; j++) {
      if (sep_set[i][j] != 0) {
        ktot++;
      }
    }
    print_one_sep_log(fsep,fmt,ktot,&sep_set[i][0]);
    if (i < S_total) {
      fprintf(fsep," |\n");
    } else {
      fprintf(fsep,"\n");
    }
  }

/*
 *  output to temporary file of separation vectors
 */
  fprintf(fseptmp,"%s\n",B_set_name);
  fprintf(fseptmp,"%d\n",S_total);
  for (i=1; i<=S_total; i++) {
    for (j=1; j<=col_count; j++) {
      fprintf(fseptmp,"%2d ",sep_set[i][j]);
    }
    fprintf(fseptmp,"\n");
  } 

  return;

}

/*eject*/
/* ----------------------------------------------------------
 * void retrieve_opt_cst(): retrieve optimal cost of 
 * separating each record of current B from all records 
 * of current A
 *
 * B_total = local B set size for compute_two_seps
 * opt_cst[] = local array for compute_two_seps
 *
 * A_opt_cst[] and B_opt_cst[] = global arrays
 * ---------------------------------------------------------- 
 */
void retrieve_opt_cst() {
  int i;

  if (B_set_name[0] == 'A' ){
    for (i=1;i<=A_opt_cst_total;i++) {
      opt_cst[i] = A_opt_cst[i];
    }
  } else {
    for (i=1;i<=B_opt_cst_total;i++) {
      opt_cst[i] = B_opt_cst[i];
    }
  }
 return;

}

/*eject*/
/*-----------------------------------------------------------
 * void show_pq_var()
 * show p and q values (diagnostic routine)
 *-----------------------------------------------------------
 */
void show_pq_var() {

  #include "leibnizmacro.h"

  int i;

  for (i=1;i<=col_count;i++) {
    value[0] = pos_name_idx[i];
    status_variable();
    if (errcde[0] != 0) {
      lsqerror("show_pq_var","102");
    }
    printf("%s%s ",name,state);
  }
  for (i=1;i<=col_count;i++) {
    value[0] = neg_name_idx[i];
    status_variable();
    if (errcde[0] != 0) {
      lsqerror("show_pq_var","104");
    printf("%s%s ",name,state);
    }
  }
  return;

}

/*eject*/
/* ----------------------------------------------------------
 * void sort_bef_fix_B(): sort bef_fix_B[] according to 
 * opt_cost[], using bubble sort
 * ---------------------------------------------------------- 
 */
void sort_bef_fix_B() {

  int j,jshift,kmax,knext;

  if (bef_fix_B_total < 1) {
    lsqerror("sort_bef_fix","102");
  }
  if (bef_fix_B_total == 1) {
    return;
  }
/*
 *  bubble sort
 */
  kmax = bef_fix_B_total - 1;

  zz105:;
  knext = 0;

  for (j=1;j<=kmax;j++) {
    if (opt_cst[B_rec_intidx[bef_fix_B[j]]] >
        opt_cst[B_rec_intidx[bef_fix_B[j+1]]] ) {
      jshift = bef_fix_B[j];
      bef_fix_B[j] = bef_fix_B[j+1];
      bef_fix_B[j+1] = jshift;
      knext = j;
    }
  }
  if (knext >= 2) {
    kmax = knext - 1;
    goto zz105;
  }

  return;

}

/*eject*/
/*-----------------------------------------------------------
 * void store_B_rec()
 * store index for 0, 1, -1 for each b in B set
 *-----------------------------------------------------------
 */
void store_B_rec() {

  int i,j,zero_total,posone_total,negone_total,i_num;
 
  for(i=1;i<=B_total;i++) {
    zero_total = 1;
    posone_total = 1;
    negone_total = 1;
    for(j=1;j<=col_count;j++) {
      i_num = B_log_rec[i][j];
      if (i_num==0) {
        B_rec_carry_zero[i][zero_total] = j;
        zero_total++;
      } else if (i_num==1) {
        B_rec_carry_posone[i][posone_total] = j;
        posone_total++;
      } else if (i_num == -1) {
        B_rec_carry_negone[i][negone_total] = j;
        negone_total++;
      } else {
        lsqerror("store_B_rec","202");  /* must be 0,+1,-1 */
      }
    }
    zero_total--;
    posone_total--;
    negone_total--;
    B_rec_has_zero[i] = zero_total;
    B_rec_has_posone[i] = posone_total;
    B_rec_has_negone[i] = negone_total;
  }    
  return;

}

/*eject*/
/* ----------------------------------------------------------
 * void store_opt_rec_cst(): store optimal cost and separation 
 * record, for separating each record of current B from 
 * all records of current A
 *
 * B_total = local B set size for compute_two_seps
 * B_rec_filidx[] = local, opt_cst[], opt_rec[][] = local arrays
 * for compute_two_seps
 *
 * A_opt.. and B_opt.. = global variables and arrays
 * ---------------------------------------------------------- 
 */
void store_opt_rec_cst() {
  int i,j;

  if (B_set_name[0] == 'A' ){
    A_opt_cst_total = B_total;
    for (i=1;i<=B_total;i++) {
      A_opt_rec_filidx[i] = B_rec_filidx[i];
      A_opt_cst[i] = opt_cst[i];
      for (j=1;j<=col_count;j++) {
        A_opt_rec[i][j] = opt_rec[i][j];
      }
    }
  } else {
    B_opt_cst_total = B_total;
    for (i=1;i<=B_total;i++) {
      B_opt_rec_filidx[i] = B_rec_filidx[i];
      B_opt_cst[i] = opt_cst[i];
      for (j=1;j<=col_count;j++) {
        B_opt_rec[i][j] = opt_rec[i][j];
      }
    }
  }

  return;

}  

/*eject*/
/* ---------------------------------------------------------
 * void undo_pq_var()
 * redo the assignments in prb1 so that the effect of the
 * record b in B processed most recently is eliminated
 *----------------------------------------------------------
 */
void undo_pq_var(int k) {

  #include "leibnizmacro.h"

  int i;

  for (i=1;i<= B_rec_has_zero[k];i++) {
    if (pos_value[B_rec_carry_zero[k][i]] == 1) {
      value[0] = pos_name_idx[B_rec_carry_zero[k][i]];
      strcpy(state,"A");
      modify_variable();
      if (errcde[0] != 0) {
        lsqerror("undo_pq_var","102");
      }
    }
  }

  for (i=1;i<= B_rec_has_zero[k];i++) {
    if (neg_value[B_rec_carry_zero[k][i]] == 1) {
      value[0] = neg_name_idx[B_rec_carry_zero[k][i]];
      strcpy(state,"A");
      modify_variable();
      if (errcde[0] != 0) {
        lsqerror("undo_pq_var","104");
      }
    }
  }

  for (i=1;i<= B_rec_has_negone[k];i++) {
    if (pos_value[B_rec_carry_negone[k][i]] == 1) {
      value[0] = pos_name_idx[B_rec_carry_negone[k][i]];
      strcpy(state,"A");
      modify_variable();
      if (errcde[0] != 0) {
        lsqerror("undo_pq_var","106");
      }
    }
  }

  for (i=1;i<= B_rec_has_posone[k];i++) {
    if (neg_value[B_rec_carry_posone[k][i]] == 1) {
      value[0] = neg_name_idx[B_rec_carry_posone[k][i]];
      strcpy(state,"A");
      modify_variable();
      if (errcde[0] != 0) {
        lsqerror("undo_pq_var","108");
      }
    }
  }
  return;

}
/*  last record of compute_separations.c***** */
