/*  first record of derive_pyramid.c***** */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h"
/* corresponding lsqdefs.h is included in lsqutil.c */

FILE *fpyr, *f1;

/* -------------------------------------------------------------
 * Summary:
 * void derive_pyramid()         derive and output pyramid from
 *                               separation formulas of one 
 *                               .sep file
 * void make_one_pyr_formula()   construct one pyramid formula 
 *                               from one separation formula
 * void print_one_pyr_formula()  print one pyramid formula
 * void print_one_pyr_idx()      print indices of pyramid literal
 *                               for one clause
 * void print_one_pyr_log()      print literals of pyramid
 *                               for one clause
 * void print_pyramid()          print entire pyramid
 * -------------------------------------------------------------
 */

/*eject*/
/* -------------------------------------------------------------
 *  derive_pyramid(): derive and output all pyramid formulas
 *  that can be deduced from the formulas of one separation file.
 *  Input:  sep_rec[][][]         array of separation formulas
 *          pyr_form_count        number of current pyramid 
 *                                formulas
 *  Output: new pyr_rec[][][]     new array of pyramid formulas,
 *                                has additional formulas 
 *          new  pyr_form_count  new number of pyramid formulas
 *  Caution: assumes that optino '4 total' was used to
 *          create separation formulas
 * -------------------------------------------------------------
 */
void derive_pyramid() {

  int  fc,kentry,pcls;

  void  lsqexit();
  void  make_one_pyr_formula();
  void  print_pyramid();

/* 
 *  pyrminmaxuseflg flag for choice of separation formulas
 *  pyrminmaxuseflg = 1: use two min formulas
 *                  = 2: use two max formulas
 *  flag is set in lsqgetparm() 
 */ 

  for (fc=pyrminmaxuseflg;fc<=pyrminmaxuseflg+2;fc+=2) {
    pyr_form_count++;
    if (pyr_form_count > max_pyr_count) {
      printf("Parameter max_pyr_count must be increased\nStop\n");
      fprintf(errfil,
           "Parameter max_pyr_count must be increased\nStop\n");
      lsqexit(1);
    }
/* 
 *  make one pyramid formula 
 */     
    formula_index = fc;
    pyr_form_index = pyr_form_count;
    make_one_pyr_formula();
/* 
 *  update pyr_col_count and pyramid names list
 */
    pyr_col_count++;
    if (pyr_col_count > max_column_size) {
      printf(
        "Parameter max_column_size must be increased\nStop\n");
      fprintf(errfil,
        "Parameter max_column_size must be increased\nStop\n");
      lsqexit(1);
    }
      sprintf(&pyr_name_list[pyr_col_count][0],
             "pyr_var_%d", pyr_form_index);    
  } /* end of fc loop */

/*
 *  pyrnumberselectflg flag for number of pyramid formulas
 *  pyrnumberselectflg = 1: select 1 formula
 *                     = 2: select 2 formulas
 *  flag is set in lsqgetparm()
 */

/* 
 *  formula with smaller objective function value is favored
 *  and is placed second-to-last in pyr_rec[][][]
 */
  if (pyr_obj_val[pyr_form_count]<
      pyr_obj_val[pyr_form_count-1]) {
    pyr_rec[pyr_form_count-1][0][0] =
      pyr_rec[pyr_form_count][0][0];
    for (pcls=1;pcls<=pyr_rec[pyr_form_count][0][0];pcls++) {
      pyr_rec[pyr_form_count-1][pcls][0] =
        pyr_rec[pyr_form_count][pcls][0];
      for (kentry=1;kentry<=pyr_rec[pyr_form_count][pcls][0];
           kentry++) {
        pyr_rec[pyr_form_count-1][pcls][kentry] =
           pyr_rec[pyr_form_count][pcls][kentry];
      }    
    }
  }
  if ((pyrnumberselectflg == 1) ||
      (pyr_rec[pyr_form_count][0][0] == 0)) { 
    pyr_form_count--;
    pyr_col_count--;
  }
  if (pyr_rec[pyr_form_count][0][0] == 0) {
    pyr_form_count--;
    pyr_col_count--;
    pyrsuccessflg = 0;
  } else {
    pyrsuccessflg = 1;
  }

/* 
 *  output entire pyramid 
 */   
  print_pyramid();

  return;

}

/*eject*/
/* -------------------------------------------------
 * make_one_pyr_formula(): eliminate block of literals from
 * formula of sep_rec[formula_index][][] by solving minsat
 * problem. Remove that block, get a pyramid formula, and store
 * that formula in pyr_rec[pyr_form_index][][]
 * Input:  sep_rec[formula_index][][] formula
 *         formula_index   for sep_rec[][][] input
 *         pyr_form_index  for pyr_rec[][][] output
 * Output: pyr_rec[pyr_form_index][][] formula
 * 
 * -------------------------------------------------
 */
void  make_one_pyr_formula() {

  #include "leibnizmacro.h" 

  int pcls; /* number of clauses in pyramid formula */
  int total_lit;  /* total number of literals in formula */
  int i,lit,jsep,kentry,plit;
  int bkclsflg, bkvarflg; /* flags for clauses and variables in block */ 
  int cbd; /* compile bound */  

  char lognam[256]; /* file name for minsat, with .log */
  char nam[256];    /* file name for minsat, without .log */

  void compile_prg();
  void  lsqerror();
  void  lsqexit();
  void *pathing();

/*
 *  define .log file name for minsat problem
 */  
  strcpy(nam,"pyramid");
  strcpy(lognam,nam);
  strcat(lognam,".log");

/* 
 *  compute total number of literals in formula
 */
  total_lit = 0;
  for (jsep=1;jsep<=sep_rec[formula_index][0][0];jsep++) {
    total_lit += sep_rec[formula_index][jsep][0];
  }  

/*
 *  if total_lit > max_formula_lit, then parameter max_formula_lit
 *  must be increased
 */
  if (total_lit > max_formula_lit) {
    printf("Parameter max_formula_lit must be increased \n");
    printf("at least to %d\nStop\n",total_lit);
    fprintf(errfil,
           "Parameter max_formula_lit must be increased \n");
    fprintf(errfil,
           "at least to %d\nStop\n",total_lit);
    lsqexit(1);
  }

/*
 *  insert into sep_use[] the attributes used by
 *  formula formula_index
 */
  for (i=1;i<=col_count;i++) {
    sep_use[i] = 0;
  }

  for (jsep=1;jsep<=sep_rec[formula_index][0][0];jsep++) {
    for (kentry=1;kentry<=sep_rec[formula_index][jsep][0];
          kentry++) {
      sep_use[abs(sep_rec[formula_index][jsep][kentry])] = 1;
    }
  }

/* 
 * assemble .log file for minsat problem
 *
 * logic variables:
 * s jsep  True => separation jsep is part of eliminated block
 *         False=> separation jsep is not part of eliminated block
 * c jvar  True => variable jvar is selected for eliminated block
 *         False=> variable jvar is not selected for 
 *                 eliminated block
 * cv jvar True =>  variable occurs positive in eliminated block
 *         False=>  variable occurs negative in eliminated block
 * x lit   True => literal lit is in eliminated block
 *         False=> literal lit is not in eliminated block
 */

/*
 *  open .log file
 */
  if ((f1 = fopen(pathing(lognam),"w")) == NULL) {
    printf("\nCannot open file:\n%s\n",lognam);
    fprintf(errfil,"\nCannot open file:\n%s\n",lognam);
    lsqerror("make_one_pyr_formula","202");
  }

  fprintf(f1,"MINIMIZE\npyramid_problem\n");
  fprintf(f1,"VARIABLES\n");
/* 
 *  variables
 * caution: do not rearrange variables since indices are
 *          used later to get values
 *
 *  variables for literals
 */
  for (lit=1;lit<=total_lit;lit++) {
    fprintf(f1,"x%d truecost = -1\n",lit);
  }
/*
 *  variables for separations
 */
  for (jsep=1;jsep<=sep_rec[formula_index][0][0];jsep++) {
    fprintf (f1,"s%d\n",jsep);
  }
/* 
 *  variables for columns
 */
  for (i=1;i<=col_count;i++) {
    if (sep_use[i] == 1) {
      fprintf(f1,"c%d truecost = 1\n",i);
      fprintf(f1,"cv%d\n",i);
    }
  }   

/*
 *  facts
 */
  fprintf(f1,"FACTS\n");
  lit = 0;
  for (jsep=1;jsep<=sep_rec[formula_index][0][0];jsep++) {
/*
 *  encode occurrence of literals in sep_tmp[]: 
 *  0: no literal of variable i occurs in any separation
 *  1: no literal of variable i in jsep,
 *     but at least one literal occurs in other separations
 *  2: positive literal of variable i in jsep
 * -2: negative literal of variable i in jsep
 */
    for (i=1;i<=col_count;i++) {
      sep_tmp[i] = sep_use[i];
    }
    for (kentry=1;kentry<=sep_rec[formula_index][jsep][0];
         kentry++) {
      if (sep_rec[formula_index][jsep][kentry]>0) {
        sep_tmp[sep_rec[formula_index][jsep][kentry]] = 2;
      } else {
        sep_tmp[-sep_rec[formula_index][jsep][kentry]] = -2;
      }
    }
/*
 *  define clauses
 *
 *  if literal lit occurs positive in separation jsep:
 *  x lit => (s jsep & c jvar & cv jvar)
 *  (s jsep & c jvar) => x lit
 *
 *  if literal lit occurs negative in separation jsep:
 *  x lit => (s jsep & c jvar & -cv jvar)
 *  (s jsep & c jvar) => x lit
 *
 *  if no literal of variable jvar occurs in separation jsep,
 *  but such literals occur elsewhere:
 *  s jsep => -c jvar  
 */
    for (i=1;i<=col_count;i++) {
      if (sep_tmp[i] == 2) {
        lit++;
        fprintf(f1,"if x%d then s%d and c%d and cv%d.\n",
                 lit,jsep,i,i);
        fprintf(f1,"if s%d and c%d then x%d.\n", jsep,i,lit);
      } else if (sep_tmp[i] == -2) {
        lit++;
        fprintf(f1,"if x%d then s%d and c%d and -cv%d.\n",
                 lit,jsep,i,i);
        fprintf(f1,"if s%d and c%d then x%d.\n", jsep,i,lit);  
      } else if (sep_tmp[i] == 1) {
        fprintf(f1,"if s%d then -c%d.\n", jsep,i);
      }
    }
  }

/* 
 *  end of file statement
 */
  fprintf(f1,"ENDATA\n");
  fclose(f1);

/*
 *  compile .log file
 */
  cbd = 10;
  compile_prg(nam,cbd);

/*
 *  solve minsat problem
 */

  value[4] = 19;
  strcpy(type,"N"); 
  solve_problem();
  if (errcde[0]!=0) {
    lsqerror("make_one_pyr_formula","302");
  }
  if (strcmp(state,"U")==0) {
/*
 *  error, problem must be satisfiable
 */
    lsqerror("make_one_pyr_formula","304");   
  }

/*
 *  check if eliminated block is insignificant
 */
  pyr_obj_val[pyr_form_index] = value[2];
  if (pyr_obj_val[pyr_form_index] >= 0) {
/*
 *  eliminated block is too small to result in useful
 *  pyramid formula
 */
    pyr_rec[pyr_form_index][0][0] = 0;
    if (lsqscrflg == 1) {
      printf("No pyramid formula can be derived ");
      printf("from formula %d\n", formula_index);
      return;
    }
  }

/*
 *  useful pyramid formula has been obtained
 *
 *  extract pyramid formula
 */
  pcls = 0; /* number of clauses in pyramid formula */
  lit = 0;
  blk_cls = 0; /* number of clauses in block */
  blk_var = 0; /* number of variables in block */
  bkvarflg = -1;
  for (jsep=1;jsep<=sep_rec[formula_index][0][0];jsep++) {
    pcls++;
    plit = 0;
    bkclsflg = 0;
    for (kentry=1;kentry<=sep_rec[formula_index][jsep][0];
         kentry++) {
      lit++;
      value[0] = lit;
      get_value();
      if (errcde[0]!=0) {
         lsqerror("make_one_pyr_formula","308");
      }
      if (strcmp(state,"F")==0) {
/*
 *  literal lit is not in eliminated block; tentatively define
 *  it to be in pyramid clause pcls
 */
        plit++;
        pyr_rec[pyr_form_index][pcls][plit] = 
           sep_rec[formula_index][jsep][kentry]; 
      } else {
        if ((bkvarflg == -1) || (bkvarflg == 0)) {          
	  blk_var++;
          pyr_blk_var[blk_var] = 
	    sep_rec[formula_index][jsep][kentry];
          bkvarflg = 0;
        }
        if (bkclsflg == 0) {     
          blk_cls++;
          pyr_blk_cls[blk_cls] = jsep;
          bkclsflg = 1;
        }
      }
    }
    if (bkvarflg == 0) {
      bkvarflg = 1;
    }
/*
 *  error if all literals of jsep are part
 *  of the eliminated block, since then one separation is
 *  nested in another one, an impossible case
 */
    if (plit == 0) {
      lsqerror("make_one_pyr_formula","310");
    }
/*
 *  if no literal is part of the eliminated block,
 *  delete entire clause from pyramid formula
 *  otherwise retain clause and record number of literals
 */
    if (plit == sep_rec[formula_index][jsep][0]) {
      pcls--;
    } else {
      pyr_rec[pyr_form_index][pcls][0] = plit;
    } 
  }

  if (pcls < 2) {
/*
 *  error, optimal value < 0 guarantees at least two clauses
 *  and thus pcls >= 2
 */
    lsqerror("make_one_pyr_formula","402");
  }

/*
 * store total number of clauses of pyramid formula
 */
  pyr_rec[pyr_form_index][0][0] = pcls;
  if (lsqscrflg == 1) {
    printf(
           "Pyramid formula with %d clauses ",pcls);
    printf(
           "derived from formula %d\n",formula_index);
    printf(
           "eliminated block value = %d\n",
           -pyr_obj_val[pyr_form_index]);
  }
  return;

}

/*eject*/
/* ----------------------------------------------------------
 * void print_one_pyr_idx(): write literals of pyramid formula
 * by indices for one clause into file fout
 * caution: does not write final end_of_line '\n'
 * ---------------------------------------------------------- 
 */
void print_one_pyr_idx(FILE *fout,
     char *indentformat,int ktot,int sep[]) {

  int j,n,nskip;

  nskip = strlen(indentformat);
  n = nskip; /* writing position for current record */
  for (j=1;j<=ktot;j++) {
    fprintf(fout," %d",sep[j]);
    n += 5;
    if ((n > 50) &&
        (j < ktot)) {
      fprintf(fout,"\n%s",indentformat);
      n = nskip;
    }
  }

  return;

}

/*eject*/
/* ----------------------------------------------------------
 * void print_one_pyr_log(): write literals of pyramid formula
 * in logic notation for one clause into file fout
 * caution: does not write final end_of_line '\n'
 * ---------------------------------------------------------- 
 */
void print_one_pyr_log(FILE *fout,
     char *indentformat,int ktot,int sep[]) {

  int j,n,nskip;

  nskip = strlen(indentformat);
  fprintf(fout,"%s",indentformat);
  n = nskip; /* writing position for current record */
  fprintf(fout,"[ ");
  n += 2;
  for (j=1;j<=ktot;j++) {
    if (j >= 2) {
      fprintf(fout," & ");
      n += 3;
    }
    if (sep[j] < 0) {
      fprintf(fout,"-");
      n++;
    }
    fprintf(fout,"%s",&pyr_name_list[abs(sep[j])][0]);
    n += strlen(&pyr_name_list[abs(sep[j])][0]);
    if ((n > 50) &&
        (j < ktot)) {
      fprintf(fout,"\n%s",indentformat);
      n = nskip;
    }    
  }
  fprintf(fout," ]");
  return;

}

/*eject*/
/* -------------------------------------------------
 *  print_pyramid(): output formulas of pyr_rec[][][]
 *  to pyramid file
 * -------------------------------------------------
 */
void  print_pyramid() {

  int  jvar;

  void lsqerror();
  void print_pyr_formula();

  if ((fpyr = fopen(pyramid_file,"w")) == NULL){
  printf("Cannot open pyramid file:\n %s\n",pyramid_file);
  printf("Stop\n");
  fprintf(errfil,
     "Cannot open pyramid file:\n %s\n",pyramid_file);
  fprintf(errfil,"Stop\n");
  lsqerror("print_pyramid","102");
  }

/*
 *  number of pyramid formulas
 *  and number of variables 
 */
  fprintf(fpyr,
  "%d pyramid formula(s) with %d variables including pyramid\n",
  pyr_form_count,pyr_col_count);

/*
 *  variables
 */
  fprintf(fpyr,"Variables");
  for (jvar=1;jvar<=pyr_col_count;jvar++) {
    fprintf(fpyr,"\n    %s",&pyr_name_list[jvar][0]);
  }

/*
 *  pyramid formulas
 */
  for (pyr_form_index=1;
       pyr_form_index<=pyr_form_count;
       pyr_form_index++) {
/*
 *  pyramid formula pyr_form_index
 */
    fprintf(fpyr,"\n");
    print_pyr_formula();
  }
  
/*
 *   ENDATA
 */
  fprintf(fpyr,"\nENDATA\n");
  fclose(fpyr);

}

/*eject*/
/* ---------------------------------------------------------
 * void print_pyr_formula():
 * output pyramid formula pyr_form_index
 * ---------------------------------------------------------
 */
void print_pyr_formula() {

  int i;

  char fmt[100];

  void print_one_pyr_idx();
  void print_one_pyr_log(); 

  strcpy(fmt,"             "); /* 13 blanks */

/*
 *  formula header
 */

  fprintf(fpyr,"\nFormula %d %s %d ",
     pyr_form_index,
     &pyr_name_list[pyr_col_count -  pyr_form_count + 
                    pyr_form_index][0],
     pyr_rec[pyr_form_index][0][0]);

  fprintf(fpyr,"(variable %s, %d clauses)\n",
     &pyr_name_list[pyr_col_count -  pyr_form_count + 
                    pyr_form_index][0],
     pyr_rec[pyr_form_index][0][0]);

  fprintf(fpyr,"clause size literals\n");

  for (i=1; i<=pyr_rec[pyr_form_index][0][0]; i++) { 
    fprintf(fpyr,"%5d%5d   ",i,pyr_rec[pyr_form_index][i][0]);
    print_one_pyr_idx(fpyr,fmt,pyr_rec[pyr_form_index][i][0],
                      &pyr_rec[pyr_form_index][i][0]);
    fprintf(fpyr,"\n");
  }

  fprintf(fpyr,"%sLogic notation\n",fmt);
  for (i=1; i<=pyr_rec[pyr_form_index][0][0]; i++) {
 
    print_one_pyr_log(fpyr,fmt,pyr_rec[pyr_form_index][i][0],
                      &pyr_rec[pyr_form_index][i][0]);
    if (i < pyr_rec[pyr_form_index][0][0]) {
      fprintf(fpyr," |\n");
    } else {
      fprintf(fpyr,"\n");
    }
  }
  fprintf(fpyr,"Clauses and Variables in Block\n");
  fprintf(fpyr,"%d Clauses: ",blk_cls);
  for (i=1; i<=blk_cls; i++) {
    fprintf(fpyr,"%d ",pyr_blk_cls[i]);
  }
  fprintf(fpyr,"\n");
  fprintf(fpyr,"%d Variables: ",blk_var);
  for (i=1; i<=blk_var; i++) {
    fprintf(fpyr,"%d ",pyr_blk_var[i]);
  }
  for (i=1; i<=blk_var; i++) {
    fprintf(fpyr,
        "\n             %s",&pyr_name_list[pyr_blk_var[i]][0]);
  }

  fprintf(fpyr,"\n");

  return;

}

/*  last record of derive_pyramid.c***** */
