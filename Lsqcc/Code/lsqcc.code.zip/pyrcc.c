/*  first record of pyrcc.c***** */
/*
 *   Leibniz System: Lsqcc System
 *   Copyright 2004 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * =====================================================
 * Lsqcc Learning Logic - Callable Pyramid Building pyrcc
 * =====================================================
 *
 *  build pyramid of additional variables using
 *  expansion (= inverse of resolution)
 *  if pyramid file exists, it is stored in a backup file,
 *  and the enlarged pyramid is written into the pyramid file
 *  
 *  input:  separation file
 *          prior pyramid file (optional)
 *  output: pyramid file
 *          backup file of prior pyramid file, if applicable
 *          pyrsuccessflg = 1: a new pyramid formula has been
 *                             produced and is, together with
 *                             prior pyramid formulas, in the
 *                             pyramid file
 *                        = 0: no new pyramid formula has been
 *                             produced; the pyramid file is
 *                             equal to the prior pyramid file,
 *                             if such a file existed, or is
 *                             a pyramid file with 0 formulas
 *                             and no pyramid formulas
 *
 *  for details about the handling of col_count and pyr_col_count,
 *  see lsqcc.c
 * -----------------------------------------------------------
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h" 
/* corresponding lsqdefs.h is included in lsqutil.c */

void pyrcc() {
/*
 *  callable version of pyramid building program pyrcc
 *  caution: 
 *   - parameters must have been obtained (see lsqgetparm() for
 *   - required information)
 *   - allocation of leibniz arrays must have been done
 *   - errfil must have been opened
 *  caution: these conditions are not checked by the program
 */

  FILE *f1;
  int i;

  void  backup_pyr();
  void  consistency_pyrvar_sepvar();
  void  construct_work_area();
  void  derive_pyramid();
  void  get_pyrrc();
  void  get_seprc();
  void  lsqexit();
  void  remove_work_area();

  if (lsqscrflg == 1) {
    printf("\n\nBuild pyramid\n");
  }

/* 
 *  construct work area 
 */   
  construct_work_area();

/*
 *  read the variables and separations of the separation file 
 *  into log_name_list[][] and sep_rec[][][]
 */
  get_seprc();

/* check if number of formulas is equal to 4, which
 * corresponds to "4 total" learning option
 * if this is not the case, cannot process formulas
 */
  if (formula_count != 4){
    printf("Learning of formulas was not done using  option\n");
    printf("'4 partial'. But that option is required for the\n");
    printf("pyramid building process.\n");
    printf("Stop\n");
    fprintf(errfil,
         "Learning of formulas was not done using  option\n");
    fprintf(errfil,
         "'4 partial'. But that option is required for the\n");
    fprintf(errfil,
         "pyramid building process.\n");
    fprintf(errfil,"Stop\n");
    lsqexit(1);
  }

/*
 *  if pyramid file does not exist: 
 *        initialize pyr_col_count, pyr_form_count,
 *        and pyr_name_list[][] 
 *        for case of 0 pyramid formulas
 *  else: 
 *        make backup file, and read in pyramid formulas
 */
  if ((f1 = fopen(pyramid_file,"r")) == NULL){
    pyr_col_count = col_count;
    pyr_form_count = 0;
    for (i=1;i<=col_count;i++) {
      strcpy(&pyr_name_list[i][0],&log_name_list[i][0]);
    }
  } else {
    fclose(f1);
    backup_pyr();
    get_pyrrc();
  }

/*
 *  check consistency of separation variables and 
 *  pyramid variables
 */
  consistency_pyrvar_sepvar();

/*
 *  derive pyramid
 */
  derive_pyramid();

/*
 *  clean and remove work area
 */  
  remove_work_area();

  return;

}

/*eject*/
/* 
 * -----------------------------------
 * make backup file of pyramid file
 * -----------------------------------
 */
void backup_pyr() {

  FILE *f1, *fout;
  char fnam[256], record[256+1];

  void lsqerror();

  if ((f1 = fopen(pyramid_file,"r")) == NULL){
    printf("Cannot open pyramid file:\n %s\n",pyramid_file);
    printf("Stop\n");
    fprintf(errfil,
       "Cannot open pyramid file:\n %s\n",pyramid_file);
    fprintf(errfil,"Stop\n");
    lsqerror("backup_pyr","102");
  }

  strcpy(fnam,pyramid_file);
  strcat(fnam,".bak");

  if ((fout = fopen(fnam,"w")) == NULL){
    printf("Cannot open backup pyramid file:\n %s\n",fnam);
    printf("Stop\n");
    fprintf(errfil,
          "Cannot open backup pyramid file:\n %s\n",fnam);
    fprintf(errfil,"Stop\n");
    lsqerror("backup_pyr","104");
  }

  while (fgets(record,256,f1) != NULL) {
    fprintf(fout,"%s",record);
  }
 
  fclose(f1);
  fclose(fout);

  return;

}

/*  last record of pyrcc.c***** */
