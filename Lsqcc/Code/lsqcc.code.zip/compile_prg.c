/*  first record of compile_prg.c ****** */
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include "lsqparms.h"
#include "lsqdefs.h"
#include "features.h" /* system version selection */
 
/* ----------------------------------------------------
 *  compile_prg(): compile one log file and store
 *  program
 * ----------------------------------------------------
 */
void compile_prg(char *prbname,int cbd) {

  #include "leibnizmacro.h"

  char filnam[namesize];

  FILE *f1;

  void lsqerror();
  char * pathing();
  
  if ((f1 = fopen(pathing("leibnizparams.dat"),"w")) == NULL) {
    printf("\nCannot open leibnizparams.dat");
    fprintf(errfil,"\nCannot open leibnizparams.dat");
    lsqerror("compile_prg","102");
  }

/*
 *  assemble essential part of leibnizparams.dat
 *  CAUTION: do not change time bound for approximate
 *           minimization from 0 to a positive value 
 *           since that may make solution of sat problem
 *           less efficient
 */
  strcpy(filnam,prbname);
  strcat(filnam,".log");  
  fprintf(f1,"input file = %s\n",filnam);
  fprintf(f1,"input directory = %s\n",lsqworkarea);
  fprintf(f1,
    "compile process (normal, fast, very fast) = version 2\n");
  fprintf(f1,
    "use approximate minimization if time bound (sec) >= %d\n",cbd);
  fprintf(f1,
    "keep all variables even if not used in any fact\n");
  fprintf(f1,
    "machine speed (mips) =  500\n");
  fprintf(f1,"ENDATA\n");
  fclose(f1);

/*  
 *  execute lbcc compiler
 */
  strcpy(name,lsqworkarea);
  execute_lbcc();
  if (errcde[0] != 0) {
    lsqerror("compile_prg","202");
  }
  return;

}

/*  last record of compile_prg.c ****** */
