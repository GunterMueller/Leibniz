/*  first record of lsqccmain.c***** */
/*
 *  Leibniz System: Lsqcc System
 *  Copyright 1990-2015 by Leibniz Company
 *  Plano, Texas, U.S.A.
 *
 *  This program is free software: you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free Software
 *  Foundation, either version 3 of the License, or (at your option) any later
 *  version. The License statement is in file lgpl.txt, but can also be obtained
 *  from www.gnu.org/licenses/.
 *
 *  We do not make any representation or warranty, expressed or implied, 
 *  as to the condition, merchantability, title, design, operation, or fitness 
 *  of the program for a particular purpose.
 *
 *  We do not assume responsibility for any errors, including mechanics or logic, 
 *  in the operation or use of the program, and have no liability whatsoever 
 *  for any loss or damages suffered by any user as a result of the program.
 * 
 *  In particular, in no event shall we be liable for special, incidental, 
 *  consequential, or tort damages, even if we have been advised of the 
 *  possibility of such damages.
 *
 * ===================================================
 * Lsqcc System - Main Learning Program lsqccmain
 * ===================================================
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "lsqparms.h"
#include "lsqexts.h" /* lsqdefs.h is in lsqutil.c */

int main(int argc, char *argv[]) {  // argc and argv for lsqccparams
                                    // file definition
/*
 */
  void alloc_leib_lsq();
  void lsqcc();
  void lsqexit();
  void lsqgetparm();
  void tstcc();

/* lsqccparams file name option 
 *  if no name given, use default "lsqccparams.dat" 
 */
  if (argc == 2 && strcmp(argv[1],"") != 0) {
    strcpy(lsqccparamsname,argv[1]);
  } else {
    strcpy(lsqccparamsname,"lsqccparams.dat");
  }

/*
 *  open error file and allocate leibniz arrays
 */
  alloc_leib_lsq();

/*
 *  get parameters from file lsqccparams.dat
 */      
  lsqgetparm();

/*
 *  training process
 */
  if (trnprocessflg == 1) {
    lsqcc();
  }

/*
 *  testing process
 */
  if (tstprocessflg == 1) {
    tstcc();
  }

  lsqexit(0);
  exit(0); /* to suppress compiler error message */
}

/*eject*/
/* ----------------------------------------------------------
 * void alloc_leib_lsq(): allocate for leibniz system
 * and define error limits.
 * ---------------------------------------------------------- 
 */
void alloc_leib_lsq() {

  #include "leibnizmacro.h"

  void lsqerror();

  strcpy(name,"lsqcc.err");
  value[0] = 1;                        
  value[1] = max_total_col;
  value[2] = max_total_row;
  value[3] = max_total_anz;
  value[4] = 5;
  value[5] = 2;
  value[6] = 2;

  assign_device();
  if (errcde[0] != 0) {
    lsqerror("alloc_leib_lsq","102");
  }

/* assign leibniz error limits so that leibniz system does not
 * stop due to the limits. instead, after each leibniz
 * command, check errcde[0] for error code and stop process
 * if any warning, nonfatal error, or error is detected.
 * display code with error message so that error can be
 * analyzed.
 */
  value[0] = 10; /* limit for number of warnings        */      
  value[1] = 10; /* limit for number of nonfatal errors */
  value[2] = 10; /* limit for number of fatal errors    */
  limit_error();
  if (errcde[0] != 0) {
    lsqerror("alloc_leib_lsq","104");
  }

  return;

}


/*  last record of lsqccmain.c***** */

