/* first record of lsqgetparm.c***** */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lsqparms.h"
#include "lsqexts.h"

FILE *params;

/*
 * ------------------------------------------------------------
 *  lsqgetparm(): get parameters from file lsqccparams.dat
 * -------------------------------------------------------------
 */
void lsqgetparm() {

  char lhs[128+1], rhs[128+1], record[128+1], s1[128+1];
  char disext[nameextsize + 1];
  char optext[nameextsize + 1];
  char prdext[nameextsize + 1];
  char pyrext[nameextsize + 1];
  char sepext[nameextsize + 1];
  char trnext[nameextsize + 1];
  char tstext[nameextsize + 1];
  char votext[nameextsize + 1];

  int parse_param();
  void lsqexit();
  void lsqvrsion();
  int beginReadFlag;

  if ((params = fopen(lsqccparamsname, "r")) == NULL) {
    printf("\n Cannot open lsqccparams.dat. Stop");
    fprintf(errfil,"\n Cannot open lsqccparams.dat. Stop");
    lsqexit(1);
  }

  /* Set beginReadFlag */
  beginReadFlag = 1;

/*eject*/
  disprocessflg = 1; 
  trnprocessflg = 0;
  tstprocessflg = 0;
  lsqscrflg = 0;
  rmnestedflg = 1;
  globalfourtotalsepflg = 0;
  globalfortypartialsepflg = 1;
  strongsepflg = 0;
  weaksepflg = 1;
  shortsepflg = 1;
  optcstsepflg = 0;
  optreconlyflg = 0;

  pop_A_fraction = -1.0;
  cost_A_error = 1.0;
  cost_B_error = 1.0;
/*
 *  lsqlambda and lsqdelta effectively are no longer used.
 *  The value of lsqlambda is ignored by optcc due to
 *  optreconlyflg = 1 assigned in optcc(). The value
 *  lsqdelta = 1000000 assigned below effectively eliminates
 *  any influence in the computations of optcc(). 
 */   
  lsqlambda = 1.2;    /* not used by optcc           */ 
  lsqdelta = 1000000; /* eliminates delta constraint */

/*eject*/
/*
 ************************************************************** 
 *  Flags not set by parameter file lsqccparams.dat
 ************************************************************** 
 *  pyrminmaxuseflg flag for choice of separation formulas
 *  pyrminmaxuseflg = 1: use two min formulas
 *                  = 2: use two max formulas 
 *
 *  pyrnumberselectflg flag for number of pyramid formulas
 *  pyrnumberselectflg = 1: select 1 formula
 *                     = 2: select 2 formulas
 *
 *  evalformulaflg flag for evaluation method of formulas
 *  evalformulaflg  = 1: 1 vote if for min or max formula
 *                         all lit's = True
 *                  = 2: 1 vote for
 *                       min if all lit's = True
 *                       max if all lit's of min and 50% of add'l
 *                              lit's = True
 *                  = 3: 2 votes for min max pair of formulas
 *                       if all lit's of min and 50% of add'l
 *                       lit's = True
 *  caution: the flag applies only to the part where each literal
 *           evaluates to True/False and NOT to Undecided
 *
 *  litfrequencyflg = 0: do not output usage frequency
 *                       of literals making formulas True
 *                       for testing records
 *                  = 1: output usage frequency
 */
  pyrminmaxuseflg = 1;
  pyrnumberselectflg = 1;
  evalformulaflg = 1;
  litfrequencyflg = 1;
/*************************************************************/
  strcpy(disext,".dis");
  strcpy(optext,".opt");
  strcpy(prdext,".prd");
  strcpy(pyrext,".pyr");
  strcpy(sepext,".sep");
  strcpy(trnext,".trn");
  strcpy(tstext,".tst");
  strcpy(votext,".vot");

/*eject*/
  while (parse_param(lhs, rhs, record)) {
/*
 *  "show steps on screen"
 */
    if (strcmp(lhs,"showstepsonscreen") == 0) {
      lsqscrflg = 1;
      lsqvrsion();
      printf("\n");
      printf("show steps on screen\n");
      printf("                    Leibniz System\n");
      printf("         lsqcc/cutcc/optcc/pyrcc/tstcc Programs\n");
      printf("                     Version %s \n",lsqver);
      printf("        Copyright 2001-2005 by Leibniz Company\n");
      printf("                 Plano, Texas, U.S.A.\n\n");
      continue;
    }

/*
 *  "ENDATA"
 */
    if (strcmp(lhs,"ENDATA") == 0) {
      break;
    }

    /* check for "begin...cc" specification */
    if ((strncmp(lhs,"begin",5) == 0) &&
        (strncmp(&lhs[strlen(lhs)-2],"cc",2) == 0)) {
      beginReadFlag = 0;
      if ((strcmp(lhs,"beginlsqcc") == 0) ||
          (strcmp(lhs,"beginallcc") == 0)) {
        beginReadFlag = 1;
      }
      continue;
    }
    if (beginReadFlag == 0) {
      continue;
    }

/*
 *  "file name without extension = "
 */    
    if (strcmp(lhs,"filenamewithoutextension") == 0) {
      strcpy(filename_wo_ext,rhs);
      if (lsqscrflg == 1) {
        printf("file name without extension = %s\n",
               filename_wo_ext);
      }
      continue;
    }

/*
 *  "training/testing directory = "
 */    
    if (strcmp(lhs,"training/testingdirectory") == 0) {
      strcpy(lsqtraindir,rhs);
      if (lsqscrflg == 1) {
        printf("training/testing directory = %s\n",lsqtraindir);
      }
      continue;
    }
/*
 *  caution: lsqtraindir must contain terminating "/" for
 *           consistency with Leibniz System convention
 */

/* "Leibniz directory = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"Leibnizdirectory") == 0) {
      continue;
    }


/*
 *  "cutpoint file extension          (default: cut) = "
 *  note: only used by cutcc, hence no action here  
 */
    if (strcmp(lhs,"cutpointfileextension(default:cut)") == 0) {
      if (lsqscrflg == 1 ) {
        printf(
        "cutpoint file extension           (default: cut) = %s\n",
         rhs);
      }
      continue;
    }

/*
 *  "distribution file extension      (default: dis) = "
 */
    if (strcmp(lhs, 
      "distributionfileextension(default:dis)") == 0) {
      strcpy(disext,".");
      strcat(disext,rhs);
      if (lsqscrflg == 1 ) {
        printf(
        "distribution file extension       (default: dis) = %s\n",
         rhs);
      }
      continue;
    }

    /*  "executable file extension         (default: exe)  = " */
    /*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"executablefileextension(default:exe)") == 0) {
      continue;
    }

    /*  "minimization file extension       (default: min)  = " */
    /*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"minimizationfileextension(default:min)") == 0){
      continue;
    }

   /*  "master file extension            (default: mst)  = " */
   /*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs, "masterfileextension(default:mst)") == 0) {
      continue;
    }

    /*  "master AB file extension        (default: mstAB) = " */
    /*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs, "masterABfileextension(default:mstAB)") == 0) {
      continue;
    }

/*
 *  "optimal record file extension  (default: opt) = "
 */
    if (strcmp(lhs, 
      "optimalrecordfileextension(default:opt)") == 0) {
      strcpy(optext,".");
      strcat(optext,rhs);
      if (lsqscrflg == 1 ) {
        printf(
        "optimal record file extension     (default: opt) = %s\n",
         rhs);
      }
      continue;
    }

/*eject*/
/*
 *  "pyrpred file extension            (default: prd) ="
 */
    if (strcmp(lhs,"pyrpredfileextension(default:prd)") == 0) {
      strcpy(prdext,".");
      strcat(prdext,rhs);
      if (lsqscrflg == 1 ) {
        printf(
        "pyrpred file extension            (default: prd) = %s\n",
         rhs);
      }
      continue;
    }

/*
 *  "partial data file extension       (default: ptl) = "
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,
        "partialdatafileextension(default:ptl)") == 0) {
      if (lsqscrflg == 1 ) {
        printf(
        "partial data file extension       (default: ptl) = %s\n",
         rhs);
      }
      continue;
    }

/*
 *  "pyramid file extension            (default: pyr) ="
 */
    if (strcmp(lhs,"pyramidfileextension(default:pyr)") == 0) {
      strcpy(pyrext,".");
      strcat(pyrext,rhs);
      if (lsqscrflg == 1 ) {
        printf(
        "pyramid file extension            (default: pyr) = %s\n",
         rhs);
      }
      continue;
    }

/*eject*/
/*
 *  "rational training file extension  (default: rtr) = "
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,
       "rationaltrainingfileextension(default:rtr)") == 0) {
      if (lsqscrflg == 1 ) {
        printf(
        "rational training file extension  (default: rtr) = %s\n",
         rhs);
      }
      continue;
    }

/*
 *  "rational testing file extension   (default: rts) = "
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,
       "rationaltestingfileextension(default:rts)") == 0) {
      if (lsqscrflg == 1 ) {
        printf(
        "rational testing file extension   (default: rts) = %s\n",
         rhs);
      }
      continue;
    }

/*  "rational testing A file extension (default: rtsA)  = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
             "rationaltestingAfileextension(default:rtsA)") == 0) {
      continue;
    }

/*  "rational testing B file extension (default: rtsB)  = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
             "rationaltestingBfileextension(default:rtsB)") == 0) {
      continue;
    }   

/*  "rational testEq file ext.     (default: rtsEqrtr) = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
       "rationaltestEqtrainfileext.(default:rtsEqrtr)") == 0) {
      continue;
    }

/*  "alternate testing file            (default: ats)   = " */
/*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
             "alternatetestingfile(default:ats)") == 0) {
      continue;
    }

/*  "rule file extension               (default: rul)   =  " */
/*  note: not used by cutcc, hence no action here */
    if (strcmp(lhs,
        "rulefileextension(default:rul)") == 0) {
      continue;
    }

/*
 *  "separation file extension         (default: sep) = "
 */
    if (strcmp(lhs, 
          "separationfileextension(default:sep)") == 0) {
      strcpy(sepext,".");
      strcat(sepext,rhs);
      if (lsqscrflg == 1 ) {
        printf(
        "separation file extension         (default: sep) = %s\n",
        rhs);
      }
      continue;
    }

/*eject*/
/*  "subgroup file extension           (default: sub)   = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
        "subgroupfileextension(default:sub)") == 0) {
      continue;
    }

/*  "target file extension             (default: tgt)   = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
        "targetfileextension(default:tgt)") == 0) {
      continue;
    }

/*
 *  "logic training file extension       (default: trn) = "
 */
    if (strcmp(lhs,
       "logictrainingfileextension(default:trn)") == 0) {
      strcpy(trnext,".");
      strcat(trnext,rhs);
      strcpy(trnext_nodot,rhs);
      if (lsqscrflg == 1 ) {
        printf(
        "logic training file extension     (default: trn) = %s\n",
         rhs);
      }
      continue;
    }

/*
 *  "logic testing file extension        (default: tst) = "
 */
    if (strcmp(lhs,
               "logictestingfileextension(default:tst)") == 0) {
      strcpy(tstext,".");
      strcat(tstext,rhs);
      if (lsqscrflg == 1 ) {
        printf(
        "logic testing file extension      (default: tst) = %s\n",
         rhs);
      }
      continue;
    }

/*eject*/
/*
 *  "visualization file extension      (default: vis) = "
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,
       "visualizationfileextension(default:vis)") == 0) {
      if (lsqscrflg == 1 ) {
        printf(
        "visualization file extension      (default: vis) = %s\n",
         rhs);
      }
      continue;
    }

/*
 *  "vote file extension               (default: vot) = "
 */
    if (strcmp(lhs,"votefileextension(default:vot)") == 0) {
      strcpy(votext,".");
      strcat(votext,rhs);
      if (lsqscrflg == 1 ) {
        printf(
        "vote file extension               (default: vot) = %s\n",
         rhs);
      }
      continue;
    }

/*  "vote A file extension             (default: votA)  = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
        "voteAfileextension(default:votA)") == 0) {
      continue;
    }

/*  "vote B file extension             (default: votB)  = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
        "voteBfileextension(default:votB)") == 0) {
      continue;
    }

/*eject*/
/*
 *  "missing entries (absent, unavailable) = "
 *   absent      <--> strong separation
 *   unavailable <--> weak separation
 */
    if (strcmp(lhs,
    "missingentries(absent,unavailable)") == 0) {
      if (lsqscrflg == 1) {
        printf("missing entries (absent, unavailable) = ");
      }
      if (strcmp(rhs,"absent") == 0) {
        strongsepflg = 1;
        weaksepflg = 0;
        if (lsqscrflg == 1) {
          printf("absent\n");
        }
        continue;
      } else if (strcmp(rhs,"unavailable") == 0) {
        strongsepflg = 0;
        weaksepflg = 1;
        if (lsqscrflg == 1) {
          printf("unavailable\n");
        }
        continue;
      }
/*
 *  if none of the above rhs case applies, output is
 *  generated below that the record cannot be interpreted
 */        
    }

/*
 *  "do logic training"
 */
    if (strcmp(lhs,"dologictraining") == 0) {
      trnprocessflg = 1;
      if (lsqscrflg == 1) {
        printf("do logic training\n");
      }
      continue;
    }

/*eject*/
/*
 *  "number/type of separations (4 total, 40 partial) = "
 */
    if (strcmp(lhs,
    "number/typeofseparations(4total,40partial)") == 0) {
      if (lsqscrflg == 1) {
        printf(
        "number/type of separations (4 total, 40 partial) = ");
      }
      if (strcmp(rhs,"4total") == 0) {
        globalfourtotalsepflg = 1;
        globalfortypartialsepflg = 0;
        if (lsqscrflg == 1) {
          printf("4 total\n");
        }
        continue;
      } else if (strcmp(rhs,"40partial") == 0) {
        globalfourtotalsepflg = 0;
        globalfortypartialsepflg = 1;
        if (lsqscrflg == 1) {
          printf("40 partial\n");
        }
        continue;
      }
/*
 *  if none of the above rhs case applies, output is
 *  generated below that the record cannot be interpreted
 */        
    }

/*  
 *  "nestedness delete option (not allowed, least cost, all) = "
 */
    if (strcmp(lhs,
    "nestednessdeleteoption(notallowed,leastcost,all)") == 0) {
      if (lsqscrflg == 1) {
        printf(
        "nestedness delete option (not allowed, least cost, all) = ");
      }
      if (strcmp(rhs,"notallowed") == 0) {
        rmnestedflg = 0;
        if (lsqscrflg == 1) {
          printf("not allowed\n");
        }
        continue;
      } else if (strcmp(rhs,"leastcost") == 0) {
        rmnestedflg = 1;
        if (lsqscrflg == 1) {
          printf("least cost\n");
        }
        continue;
     } else if (strcmp(rhs,"all") == 0) {
        rmnestedflg = 2;
        if (lsqscrflg == 1) {
          printf("all\n");
        }
        continue;
      }
/*
 *  if none of the above rhs case applies, output is
 *  generated below that the record cannot be interpreted
 */        
    }

/*
 *  "fraction A population (0.xx) = "
 */    
    if (strcmp(lhs,"fractionApopulation(0.xx)") == 0) {
      if (strcmp(rhs,"") == 0) {
        pop_A_fraction = -1.0;
        if (lsqscrflg == 1) {
          printf("fraction A population not specified\n");
          printf("use training file to estimate value\n");
        }
        continue;
      } else {
        if (sscanf(rhs,"%f",&pop_A_fraction) > 0) {
          if (lsqscrflg == 1) {
            printf("fraction A population (0.xx) = %s\n",rhs);
          }
          if ((pop_A_fraction <= 0.0) ||
              (pop_A_fraction >= 1.0)) {
            printf(
             "fraction A population must be > 0.0 and < 1.0\n");
            printf("Stop\n");
            fprintf(errfil,
             "fraction A population must be > 0.0 and < 1.0\n");
            fprintf(errfil,"Stop\n");
            lsqexit(1);
          }
          continue;
        }
      }
/*
 *  rhs cannot be decoded; output is generated below 
 *  that the record cannot be interpreted
 */
    }

/*eject*/
/*
 *  "cost type A error = "
 */    
    if (strcmp(lhs,"costtypeAerror") == 0) {
      if (strcmp(rhs,"") == 0) {
        cost_A_error = 1.0;
        if (lsqscrflg == 1) {
          printf("cost of type A error not specified\n");
          printf("use cost of type A error = 1.0\n");
        }
        continue;
      } else {
        if (sscanf(rhs,"%f",&cost_A_error) > 0) {
          if (lsqscrflg == 1) {
            printf("cost of type A error = %s\n",rhs);
          }
          if ((cost_A_error < 0.0) ||
              (cost_A_error >= 10000000.)) {
            printf(
              "Cost of type A error must be >= 0.0 and");
            printf(" < 10000000.0\nStop\n");
            fprintf(errfil,
              "Cost of type A error must be >= 0.0 and");
            fprintf(errfil," < 10000000.0\nStop\n");
            lsqexit(1);
          }
          continue;
        }
      }
/*
 *  rhs cannot be decoded; output is generated below 
 *  that the record cannot be interpreted
 */
    }

/*
 *  "cost type B error = "
 */    
    if (strcmp(lhs,"costtypeBerror") == 0) {
      if (strcmp(rhs,"") == 0) {
        cost_B_error = 1.0;
        if (lsqscrflg == 1) {
          printf("cost of type B error not specified\n");
          printf("use cost of type B error = 1.0\n");
        }
        continue;
      } else {
        if (sscanf(rhs,"%f",&cost_B_error) > 0) {
          if (lsqscrflg == 1) {
            printf("cost of type B error = %s\n",rhs);
          }
          if ((cost_B_error < 0.0) ||
              (cost_B_error >= 10000000.)) {
            printf(
              "Cost of type B error must be >= 0.0 and");
            printf(" < 10000000.0\nStop\n");
            fprintf(errfil,
              "Cost of type B error must be >= 0.0 and");
            fprintf(errfil," < 10000000.0\nStop\n");
            lsqexit(1);
          }
          continue;
        }
      }
/*
 *  rhs cannot be decoded; output is generated below 
 *  that the record cannot be interpreted
 */
    }


/*
 *  "do logic testing"
 */
    if (strcmp(lhs,"dologictesting") == 0) {
      tstprocessflg = 1;
      if (lsqscrflg == 1) {
        printf("do logic testing\n");
      }
      continue;
    }

/*eject*/

/* "dotrainingtransformation(new,old,skip) = "  */
/*  note: not used by subcc, hence no action here */
    if (strcmp(lhs,
       "dotrainingtransformation(new,old,skip)") == 0) {
      continue;     
    }

/*  
 *  "do training transformation using (new, old) .cut file = "
 *  became obsolete December 2007
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,
         "dotrainingtransformationusing(new,old).cutfile") == 0) {
      continue;
    }

/*
 *  "do training transformation" became obsolete May 2007
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,"dotrainingtransformation") == 0) {
      continue;
    }
/*eject*/

/*
 *  "min cuts = "
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,"mincuts") == 0) {
      continue;
    }

/*
 *  "max cuts = "
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,"maxcuts") == 0) {
      continue;
    }

/*
 *  "degree of separation (effective, perfect) = "
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,
               "degreeofseparation(effective,perfect)") == 0) {
      continue;
    }

/*
 *  "do testing transformation"
 *  note: only used by cutcc, hence no action here
 */
    if (strcmp(lhs,"dotestingtransformation") == 0) {
      continue;
    }

/* "subcc detail directory = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"subccdetaildirectory") == 0) {
      continue;
    }

/* "show target processing steps"  */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
       "showtargetprocessingsteps") == 0) {
      continue;   
    }

/* "output variations of subgroups"  */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
       "outputvariationsofsubgroups") == 0) {
      continue;   
    }

/* "keep subcc detail directory" */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"keepsubccdetaildirectory") == 0) {
      continue;
    }

/* "attribute importance threshold = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"attributeimportancethreshold") == 0) {
      continue;
    }

/* "max number of attributes used = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"maxnumberofattributesused") == 0) {
      continue;
    }

/* "subgroup selection threshold = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"subgroupselectionthreshold") == 0) {
      continue;
    }

/* "max number of expansions = " */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"maxnumberofexpansions") == 0) {
      continue;
    }

/* "compute subgroups (new tgt, old tgt, tgt only = "  */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
       "computesubgroups(newtgt,oldtgt,tgtonly)") == 0) {
      continue;   
    }

  /* "master to masterAB program ="  */
  /*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
        "mastertomasterABprogram") == 0) {
      continue;   
    }

/* "use (master, alternate) testing file          = "  */
/*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,
        "use(master,alternate)testingfile") == 0) {
      continue;   
    }

    printf(
     "\nRecord in file lsqccparams.dat cannot be interpreted:\n\n");
    printf(" %s \n", record);
    printf("Please correct lsqccparams.dat file\n");
    printf("and execute lsqcc again\n");
    fprintf(errfil,
     "\nRecord in file lsqccparams.dat cannot be interpreted:\n\n");
    fprintf(errfil,
     " %s \n", record);
    fprintf(errfil,
     "Please correct lsqccparams.dat file\n");
    fprintf(errfil,
     "and execute lsqcc again\n");
    lsqexit(1);

  }/* end of while loop */

/*eject*/
/*
 *  construct file name with full path, but without extension
 */
  strcpy(s1,lsqtraindir);
  strcat(s1,filename_wo_ext);

/*
 *  create complete file names
 */
  strcpy(training_file_wo_dir,filename_wo_ext);
  strcpy(training_file,s1);
  strcpy(separation_file,s1);
  strcpy(distribution_file,s1);
  strcpy(optimization_file,s1);
  strcpy(testing_file,s1);
  strcpy(vote_file,s1);
  strcpy(pyramid_file,s1);
  strcpy(pyrpred_file,s1);

  strcat(training_file_wo_dir,trnext);
  strcat(training_file,trnext);
  strcat(separation_file,sepext);
  strcat(distribution_file,disext);
  strcat(optimization_file,optext);
  strcat(testing_file,tstext);
  strcat(vote_file,votext);
  strcat(pyramid_file,pyrext);
  strcat(pyrpred_file,prdext);

/*
 *  done
 */    
  fclose(params);
  return;
}

/*eject*/
/*
 * --------------------------------------------------------
 *  parse_param(): parse parameters
 * --------------------------------------------------------
 */
int parse_param(char *lhs, char *rhs, char *record) {
  char     str[128+1], ch;
  int      i, ix, l=0, r=0, nz;
  int      right = 0;
 
  if (feof(params)) {
    return(0);
  }
  fgets(str, 126, params);
  while (str[0] == '*') {
    if (feof(params)) {
      return(0);
    }
    fgets(str, 126, params);
  }  
/*
 *  change all string characters 
 *  with ascii code 1-31 or 127-254 by blanks
 */
  nz = strlen(str);
  for(i=0; i<=nz-1; i++)  {
    ix = (int)str[i];
    if (((ix>=1)&&
        (ix<=31))||
        ((ix>=127)&&
        (ix<=254))) {
      str[i] = ' ';
    }
  }
/*
 *  introduce carriage return character and,
 *  if necessary, new end of string character
 */
  if (str[nz-1] == ' ') {
    str[nz-1] = '\n';
  } else {
    str[nz] = '\n';
    str[nz+1] = '\0';
    nz++;
  }  
  
  strcpy(record, str);
  for (i = 0; i <= nz-1; i++) {
    ch = str[i];
    switch (ch) {
      case ' ':
                break;  
      case '=':
                right = 1;
                break;
      case '\n':
                break;
      default:
               if (right) {
                 rhs[r++] = ch;
               } else {
                 lhs[l++] = ch;
               }
    }
  }
  lhs[l] = '\0';
  rhs[r] = '\0';  
  return(1);
}

/*  last record of lsqgetparm.c***** */
