/* first record of lsqdefs.h *****/
extern FILE *errfil; /* file is defined by Leibniz System or */
                     /* in tstccmain.c                       */

#define abs(x)   ((x) >= 0 ? (x) : -(x))
#define max(x,y) (((x) > (y)) ? (x) : (y))
#define min(x,y) (((x) < (y)) ? (x) : (y))

/* Lsqcc System definitions */
/* flags */
int  disprocessflg;             /* compute distributions      */
int  trnprocessflg;             /* do training flag           */ 
int  tstprocessflg;             /* do testing flag            */
int  lsqscrflg;                 /* display progress on screen */
int  rmnestedflg;               /* remove nested records      */
     /* = 0: stop if nestedness is detected                   */
     /* = 1: remove nested records using 'least cost' rule    */
     /* = 2: remove nested records using 'all' rule           */
int  fourtotalsepflg;           /* 4 total case, local        */
int  fortypartialsepflg;        /* 40 partial case, local     */
int  globalfourtotalsepflg;     /* 4 total case, global       */
int  globalfortypartialsepflg;  /* 40 partial case, global    */
int  strongsepflg;              /* strong separation          */
                                /* unknown = absent           */
int  weaksepflg;                /* weak separation            */
                                /* unknown = unavailable      */
int  shortsepflg;               /* short separation           */
int  optcstsepflg;              /* optimal cost separation    */
int  optreconlyflg;       /* optimal records only             */
                          /* = 1: compute opt. rec's only     */
                          /*      and no sep's                */
                          /* = 0: opt. rec's and sep's        */
                          /* caution: optreconlyflg changes   */
                          /*          globalfourtotalsepflg   */
                          /*          and                     */
                          /*          globalfortypartialsepflg*/
                          /*          in lpsqcc() to suppress */
                          /*          computation of sep's    */
 

int  triviallogflg;             /* trivial partial log file   */
                                /* = 0: log file is nontrivial*/
                                /* = 1: log file is trivial   */

int  pyrsuccessflg;             /* pyrcc success flag         */
                                /* = 0 pyrcc has not produced */
                                /*     a pyramid formula      */
                                /* = 1 pyrcc has produced     */
                                /*     a pyramid formula      */

/*eject*/
/**************************************************************/
/* Option flags not set by parameter file lsqccparams.dat,    */
/* but fixed in lsqgetparm()                                  */
/**************************************************************/
int  pyrminmaxuseflg;           /* = 1: use two min formulas  */
                                /* = 2: use two max formulas  */
                                /*                            */
int  pyrnumberselectflg;        /* = 1: select 1 formula      */
                                /* = 2: select 2 formulas     */
                                /*                            */
int  evalformulaflg; /* = 1: 1 vote if for min or max formula */
                     /*      all lit's = True                 */
                     /* = 2: 1 vote for                       */
                     /*      min if all lit's = True          */
                     /*      max if all lit's of min and 50%  */ 
                     /*             of add'l lit's = True     */
                     /* = 3: 2 votes for min max pair of      */ 
                     /*      formulas if all lit's of min and */
                     /*      50% of add'l lit's = True        */
                     /*                                       */
int litfrequencyflg; /* = 0: do not output usage frequency    */
                     /*      of literals making formulas True */
                     /*      for testing records              */
                     /* = 1: output usage frequency           */
/**************************************************************/ 
/*eject*/
char lsqccparamsname[256];      /* lsqccparams file name      */
char lsqver[4+1];               /* lsqcc version              */
char lsqworkarea[256];          /* workarea dir path          */
char lsqtraindir[256];          /* training dir path          */

/* file names */
char filename_wo_ext[256];      /* filename without extension */
char distribution_file[256];    /* distribution file          */
char optimization_file[256];    /* optimization output file   */
char separation_file[256];      /* separation file            */
char testing_file[256];         /* testing file               */
char training_file[256];        /* training file              */
char training_file_wo_dir[256]; /* training file w/o directory*/
char vote_file[256];            /* vote file                  */
char pyramid_file[256];         /* pyramid file               */
char pyrpred_file[256];         /* pyramid predicates file    */

char trnext_nodot[nameextsize + 1]; /*training file ext  */

int  col_count; /* number of variables of each training record */
int  row_count; /* number of A/B records */
int  init_row_size_A; /* initial number of A records */
int  init_row_size_B; /* initial number of B records */
int  del_rows_A; /* deleted number of A records */
int  del_rows_B; /* deleted number of B records */
int  est_row_size_A; /* estimated number of A records         */
int  est_row_size_B; /* estimated number of B records         */
                     /* estimates obtained from training data */
                     /* for evaluation of testing data        */
int  log_rec_count; /* number of A/B and BEGIN A/B records */
int  filesize; /* number of records in file */

char log_name_list[max_column_size + 1][58 + 1];
/* list of variable names used in training/testing */
char pos_name_list[max_column_size + 1][58 + 1];
char neg_name_list[max_column_size + 1][58 + 1];
/* lists of predicate names with rightmost 'pos' resp. 'neg' */

int  pos_name_idx[max_column_size + 1];
int  neg_name_idx[max_column_size + 1];
/*  pos_name_idx[j] = index of logic program for 'pos'
 *                    case of variable j, j=1..col_count
 *  neg_name_idx[j] is 'neg' case
 */

int pos_var_cst[max_column_size + 1];
int neg_var_cst[max_column_size + 1];
/*
 * pos_var_cst[j] = cost of knowing value of data variable j when
 *                  that value is True
 * 
 * neg_var_cst[j] = cost of knowing value of data variable j when
 *                  that value is False
 */

float cost_A_error; /* cost of A error */
float cost_B_error; /* cost of B error */
float lsqlambda;/* factor by which minimum cost may be exceeded */

float pop_A_fraction; 
/* fraction of A population of total population */ 

int  lsqdelta;

int  log_rec[max_record_num + 2 + 1] [ max_column_size + 1];
/* i = 0:
 *   log_rec[0][j] undefined for all j >= 0
 * i = 1:
 *   log_rec[1][0] = BEGIN_A
 *   log_rec[1][j] = 0, j >= 1 (value is never used)
 * 2 <= i <= row_end_A:
 *   log_rec[i][0] = LSQBEG initially
 *                 = LSQTRUE  A record to be deleted
 *                 = LSQFALSE A record to be kept
 *   log_rec[i][j] = A record, 1 <= j <= col_count
 * i = row_end_A + 1:
 *   log_rec[row_end_A+1][0] = BEGIN_B
 *   log_rec[[row_end_A+1][j] = 0, j >= 1 (value is never used)
 * row_begin_B <= i <= log_rec_count:
 *   log_rec[i][0] = LSQBEG initially
 *                 = LSQTRUE  B record to be deleted
 *                 = LSQFALSE B record to be kept
 *   log_rec[i][j] = B record, 1 <= j <= col_count
 */

int  nzeros_inrow_log_rec[max_record_num + 2 + 1];
/* nzeros_inrow_log_rec[i] = number of zero entries */
/* in row log_rec[i][j], j >= 1                     */
 
int  rec_filidx[max_record_num + 2 + 1]; 
/* rec_filidx[i] = line in file where record i begins */

struct{
  float pos;
  float neg;
  float zero;
} typedef prob_cases;
prob_cases prob_of_entry[max_column_size + 1];
/*
 *  prob_of_entry[j].pos  = probability that entry is col j is +1
 *  prob_of_entry[j].neg  = probability that entry is col j is -1
 *  prob_of_entry[j].zero = probability that entry is col j is  0
 *                          probabilities are estimated from
 *                          testing data
 */

int  sep_l_a[separation_num + 1][sub_range_num + 1][4+1];
int  sep_l_b[separation_num + 1][sub_range_num + 1][4+1];
int  delete_var[max_column_size + 1];
/* delete_var[j] = 1 if variables is deleted; = 0 else */
/*eject*/

/* separation and testing arrays and variables */

int  sep_rec[4*sub_range_num + 1]
            [sep_set_size + 1]
            [max_column_size + 1];
/*
 *  sep_rec[formula][separation][entry of separation]
 *  sep_rec[i][0][0] = number of separations in formula i
 *  sep_rec[i][j][0] = number of nonzeros in formula i, 
 *                       separation j
 *  sep_rec[i][j][k] = +/-n entry k in  formula i, separation j
 *                       +/-n means nth entry of separation j 
 *                       is nonzero and equal to +/-1
 */

/* normal distribution values */
float normDistr[42];
/* normDistr[i] = prob[normal var. with mean=0 and sigma=1
 *                     is <= ((float)i)/10.0]; 
 *                for i = 0, 1, ..., 41 
 */

struct{
  int count;
  float prob;
  float zvalue;
  float imp;
} typedef sep_rec_facts;
sep_rec_facts sep_rec_stat[4*sub_range_num + 1][sep_set_size + 1];
/*  sep_rec_stat[i][j].count  = number of testing records for which
 *                              separation j of formula i is True
 *  sep_rec_stat[i][j].prob   = probability that separation j 
 *                              of formula i evaluates to True
 *  sep_rec_stat[i][j].zvalue = sigma factor for .count, using
 *                              .prob value and estimated
 *                              number of testing records
 *                              of applicable case A or B
 *                            = (sep_rec_stat[i][j].count - mu)/sigma
 *  sep_rec_stat[i][j].imp    = prob[actual count <=
 *                                  sep_rec_stat[i][i].count]
 *                            = normal distr. prob. corresponding
 *                              to zvalue
 *                            = prob. clause j of formula i is 
 *                              important
 */

struct{
  float freq;
  float signif;
} typedef lit_imp;
lit_imp lit_importance[4+1][max_column_size+1][2];
/*  importance data of literals
 *  lit_importance[i][j][0] refers to + literal of variable j
 *  lit_importance[i][j][1] refers to - literal of variable j
 *  .freq:   frequency of occurrence of case [i][j][0] or [i][j][1]
 *  .signif: significance of case [i][j][0] or [i][j][1]
 */

char formula_type[4*sub_range_num + 1][2];
char record[10*max_column_size + 1];

int  formula_count; /* number of separation formulas   */
int  formula_index; /* index of one separation formula */

int  sep_use[max_column_size + 1]; 
int  sep_tmp[max_column_size + 1]; 
/* flags of variables used in one separation formula  */

int  lit_freq[4*sub_range_num + 1][max_column_size + 1][2];
/* frequency of use of literals to achieve True by formulas 
 *   lit_freq[i][j][k]: i = formula index
 *                      j = variable index
 *                      k = 0: positive literal
 *                          1: negative literal
 */

/*eject*/
/* pyramid arrays and variables */

int  pyr_form_count; /* number of formulas of pyramid         */
int  pyr_form_index; /* index of one formula of pyramid       */
int  pyr_col_count;  /* number of variables including pyramid */

int  pyr_rec[max_pyr_count + 1]
            [sep_set_size + 1]
            [max_column_size + 1];
/*
 *  pyr_rec[formula][separation][entry of separation]
 *  pyr_rec[i][0][0] = number of separations in pyramid formula i
 *  pyr_rec[i][j][0] = number of nonzeros in pyramid formula i, 
 *                       separation j
 *  pyr_rec[i][j][k] = +/-n entry k in pyramid formula i,
 *                       separation j
 *                       +/-n means nth entry of separation j 
 *                       is nonzero and equal to +/-1
 */

char pyr_name_list[max_column_size + 1][58+1];
/* list of variable names used, including pyramid variables; is */
/* equal to log_name_list[][] when values of pyramid formulas   */
/* have been added to internal training/testing records         */

int pyr_obj_val[max_pyr_count + 1];
/* objective function value associated with pyramid formula    */
/* is computed by minsat instance determining eliminated block */

int pyr_blk_var[max_column_size + 1];
int blk_var; /* number of variables in block */
int pyr_blk_cls[sep_set_size + 1];
int blk_cls; /* number of clauses in block */
/* pyr_blk_var[n] has nth variables in block, with sign of literal */
/* pyr_blk_cls[m] has mth separation in block                      */

/* end of pyramid arrays and variables */

/* last record of lsqdefs.h *****/



