/*  Caution: The version number must have exactly 4 characters,
 *           including period "." in third position
 *  Example: 16.0
 */
  strcpy(globalversion,"16.1");
