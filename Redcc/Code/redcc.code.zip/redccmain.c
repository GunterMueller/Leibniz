/* first record of redccmain.c *****/
/*
 *   Leibniz System: Redcc System
 *   Copyright 2008 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * ===================================================
 * Redcc System - Main Subgroup Program redccmain
 * ===================================================
 *
 *  This program is free software: you can redistribute it and/or modify it under the
 *  terms of the GNU Lesser General Public License as published by the Free Software
 *  Foundation, either version 3 of the License, or (at your option) any later
 *  version. The License statement is in file lgpl.txt, but can also be obtained
 *  from www.gnu.org/licenses/.
 *
 *  We do not make any representation or warranty, expressed or implied, 
 *  as to the condition, merchantability, title, design, operation, or fitness 
 *  of the program for a particular purpose.
 *
 *  We do not assume responsibility for any errors, including mechanics or logic, 
 *  in the operation or use of the program, and have no liability whatsoever 
 *  for any loss or damages suffered by any user as a result of the program.
 * 
 *  In particular, in no event shall we be liable for special, incidental, 
 *  consequential, or tort damages, even if we have been advised of the 
 *  possibility of such damages.
 *
 */
#include "redcc.h"

int main(int argc, char *argv[]){ // argc and argv for lsqccparams
                                  // file definition
  /* lsqccparams file name option 
   *  if no name given, use default "lsqccparams.dat" 
   */
  if (argc == 2 && strcmp(argv[1],"") != 0) {
    strcpy(lsqccparamsname,argv[1]);
  } else {
    strcpy(lsqccparamsname,"lsqccparams.dat");
  }
	
 /* open error file errfil */
  if ((errfil = fopen("redcc.err", "w")) == NULL) {	
    printf("\n Cannot open error file redcc.err. Stop");
    exit(1);
  }
		
 /*
  * Read lsqccparams.dat file 
  */
  readParamsFile();
	
 /*
  * execute redcc 
  */
  redcc();

  fclose(errfil);
	
  return errorflag;
}
/* last record of redccmain.c *******/
