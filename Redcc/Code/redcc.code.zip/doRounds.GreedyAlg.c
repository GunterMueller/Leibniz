/* first record of doRounds.c *****/
#include "redcc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   void doRounds()
 *   int  reduceAttributes(int round) 
 */
/**************************************************************/
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  doRounds(): do reduction rounds, GREEDY ALG version
* --------------------------------------------------------
***************************************************************/
void doRounds() {

  int j, round;

  char name[MAXLEN];

  FILE* significancefil;

  showReductionSteps(
    "\nDefine master and alternate file for round 1\n");
  /* define alternate input file */
  if (XdefineAlternate() != 0) {
    rederror("Error: definition of alternate input file failed",
             "doRounds","101");
  }

  /* define master file for round 1 */
  if (XdefineMaster(1) != 0) {
    sprintf(name,
       "Definition of master input file for round 1 failed");
    rederror(name,"doRounds","201");
  }

  for (round=1; round<=numAttributes; round++) {

    sprintf(name,
    "\n****************** Round %d ******************\n\n",round);
    showReductionSteps(name);

    /* GREEDY ALG: begin */
    /*             replace Execute sub2cc and Evaluate Sub2cc output */
    /*             by direct definition of significance values */
    /* showReductionSteps("Execute sub2cc\n\n"); */
    /* execute sub2cc */
    /* if (Xsub2cc() != 0) {
      sprintf(name,
         "Execution of sub2cc failed in round %d",
         round);
      rederror(name,"doRounds","401");
    } */

    /* showReductionSteps("\nEvaluate Sub2cc output\n"); */
    /* evaluate sub2cc output */
    /* if (XevaluateSub2file(round) != 0) {
      sprintf(name,
         "Evaluation of sub2 output file failed in round %d",
         round);
      rederror(name,"doRounds","501");
    } */
    sprintf(name,"round.%d.significance",round);
    significancefil = openFileRedccdetail(name,"w");
    fprintf(significancefil,"ATTRIBUTES\n");
    for (j=1; j<=numAttributes; j++) {
      fprintf(significancefil,"%s	1.0\n",
              attribute[j]); /* value 1.0 is later replaced; see GREEDY ALG */
                             /* modifications in reduceAttributes() */
    } 
    fprintf(significancefil,"ENDATA\n");
    closeFile(significancefil); 
    /* GREEDY ALG: end */   

    showReductionSteps(
    "Reduce attributes and define master file for next round\n");
    /* reduce attributes */
    if (reduceAttributes(round) == FALSE) {
      if (round == 1) {
        /* no reduction possible */
        rederror("No reduction possible","doRounds","601");
      }
      round--;
      break;
    }

  } /* end for round */

  if (round >=numAttributes-1) {
    rederror("Too many reduction rounds","doRounds","701");
  }

  sprintf(name,
         "Save attribute file of round %d as optimal\n", round);
  showReductionSteps(name);
  /* save optimal attribute file */
  if (XsaveOptimalfile(round) != 0) {
    sprintf(name,
         "Transfer of optimal attribute file of round %d failed",
         round);
      rederror(name,"doRounds","801");
  }

  return;

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  reduceAttributes(round): reduce attributes
* --------------------------------------------------------
***************************************************************/
int reduceAttributes(int round) {

  struct { /* optimal flag, attribute index, error */
    int flag;
    char name[MAX_ID];
    double error;
  } typedef Optimal;
  Optimal opt;

  int iter, n, nactive, natt, ncand, nmin;
  int maxretryflag, retryflag, start;
  int status[MAX_ATTRIBUTE+1];

  double avgerror, minsig, minsig2;
  double significance[MAX_ATTRIBUTE+1];
  char deleteAttr[MAX_ATTRIBUTE+1][MAX_ID];
  int nDeleteAttr;  

  char control[MAX_ID];
  char fileRec[MAXLEN];
  char name[MAXLEN];
  char *buffer;

  FILE* prevattributefil;
  FILE* nextattributefil;
  FILE* significancefil;
  FILE* avgerrfil;

  /* initialize natt, nactive, ncand to suppress compiler warning */
  natt = 0;    
  nactive = 0;
  ncand = 0;

  /* open files */
  sprintf(name,"round.%d.attribute",round-1);
  prevattributefil = openFileRedccdetail(name,"r");
  sprintf(name,"round.%d.significance",round);
  significancefil = openFileRedccdetail(name,"r");

  strcpy(control,"");
  maxretryflag = 5; /* try up to 5 different significant levels */

  /* store significance values */
  while (fgets(fileRec,MAXLEN,significancefil) != 0) { /* while #1 */
    if (strncmp(fileRec,"ATTRIBUTES",10) == 0) {
      strcpy(control,"ATTRIBUTES");
      natt = 0;
      continue;
    }

    if (strcmp(control,"ATTRIBUTES") == 0) {
      if (strncmp(fileRec,"ENDATA",6) == 0) {
        strcpy(control,"ENDATA");
        if (natt != numAttributes) {
          sprintf(name,
             "round.%d.significance file out of order, case 1",
             round);
          rederror(name,"doRounds","101");               
        }
        break;
      }
      natt++;
      sscanf(fileRec,"%s %lf",name,&significance[natt]);
      continue;
    }
    sprintf(name,"round.%d.significance file out of order, case 2",
                 round);
    rederror(name,"doRounds","102");
  
  } /* end while #1 */ 
  if (strcmp(control,"ENDATA") != 0) {
    sprintf(name,"round.%d.significance file out of order, case 3",
                 round);
    rederror(name,"doRounds","103");
  }
  closeFile(significancefil);
/*eject*/
  /* identify DELETE, DISCARD, TARGET, ACTIVE cases */
  /* of previous attribute file */
  while(fgets(fileRec,MAXLEN,prevattributefil) != 0) { /* while #2 */
    if (strncmp(fileRec,"ATTRIBUTES",10) == 0) {
      strcpy(control,"ATTRIBUTES");
      natt = 0;
      nactive = 0;
      continue;
    }

    if (strcmp(control,"ATTRIBUTES") == 0) {
      if (strncmp(fileRec,"DATA",4) == 0) {
        strcpy(control,"DATA");
        if (natt != numAttributes) {
          sprintf(name,
             "round.%d.attribute file out of order, case 1",
             round-1);
          rederror(name,"doRounds","201");               
        }
        break;
      }
      natt++;
      buffer = strtok(fileRec," \t\n");
      if (buffer == NULL) {
        sprintf(name,
                "unexpected empty line in round.%d.significance",
                round);
        rederror(name,"doRounds","205");
      }
      buffer = strtok(NULL," \t\n");
      if (buffer == NULL) {
        status[natt] = ACTIVE;
        significance[natt] = 1.0; /*GREEDY ALG*/
        nactive++;
      } else {
        if (strcmp(buffer,"DELETE") == 0) {
          status[natt] = DELETE;
          significance[natt] = 0.0; /*GREEDY ALG*/         
        } else if (strncmp(buffer,"TARGET",6) == 0) {
          status[natt] = TARGET;
          significance[natt] = 0.0; /*GREEDY ALG*/
        } else {
          status[natt] = ACTIVE;
          significance[natt] = 1.0; /*GREEDY ALG*/
          nactive++;
        }
      } 
      continue;
    }
    sprintf(name,"round.%d.attribute file out of order, case 2",
                 round-1);
    rederror(name,"doRounds","202");
  
  } /* end while #2 */
  if (strcmp(control,"DATA") != 0) {
    sprintf(name,"round.%d.attribute file out of order, case 3",
                 round);
    rederror(name,"doRounds","203");
  } 
  closeFile(prevattributefil);

  /* check number of active attributes */
  if (nactive == 0) {
    /* this case should not occur */
    rederror("No active attributes","reduceAttributes","204");     
  } else if (nactive == 1) {
    /* attributes cannot be reduced */
    return FALSE;  
  }
/*eject*/
  /* get min significance value of active attributes */
  minsig = INFTY;
  for (n=1; n<=numAttributes; n++) {
    if (status[n] == ACTIVE) {
      minsig = min(minsig,significance[n]);
    }
  }

  if (minsig == INFTY) {
    sprintf(name,
            "No active attributes in round.%d.attribute",
            round-1);
    rederror(name,"reduceAttributes","251");
  }
  nmin = 0;
  for (n=1; n<=numAttributes; n++) {
    if ((status[n] == ACTIVE) && (significance[n] == minsig)) {
      nmin++;
    }
  }
/*eject*/
  /* define new attribute file */

  opt.flag = FALSE;
  opt.error = INFTY;

  for (retryflag = 1; retryflag <= maxretryflag; retryflag++) {

    /*   options for processing the nmin cases having
     *   mingsig significance:
     *     iter = 0: delete all minsig cases
     *     iter = 1, 2, ...,nmin: delete iter-th minsig case
     *   use iter = 0 case if minsig = 0.0 and nmin >= 2  
     */
    if ((minsig == 0.0) && (nmin >= 2)) {
      start = 0;
    } else {
      start = 1;
    }

    for (iter=start; iter<=nmin; iter++) {

      nDeleteAttr = 0;
      /* open previous and next attribute file */
      sprintf(name,"round.%d.attribute",round-1);
      prevattributefil = openFileRedccdetail(name,"r");
      sprintf(name,"round.%d.attribute",round);
      nextattributefil = openFileRedccdetail(name,"w");

      while(fgets(fileRec,MAXLEN,prevattributefil) != 0) {
         /* while #3 */
        if (strncmp(fileRec,"ATTRIBUTES",10) == 0) {
          strcpy(control,"ATTRIBUTES");
          fprintf(nextattributefil,"%s",fileRec);
          natt = 0;
          ncand = 0;        
          continue;
        }

        if (strcmp(control,"ATTRIBUTES") == 0) {
          if (strncmp(fileRec,"DATA",4) == 0) {
            strcpy(control,"DATA");
            if (natt != numAttributes) {
              sprintf(name,
                 "round.%d.attribute file out of order, case 4",
                 round-1);
              rederror(name,"reduceAttributes","304");               
            }
            fprintf(nextattributefil,"%s",fileRec);        
            break;
          }
          natt++;
          if ((status[natt] == ACTIVE) && 
              (significance[natt] == minsig)) {
            ncand++;
            if ((iter == 0) || (ncand == iter)) {
              sscanf(fileRec,"%s",name);
              fprintf(nextattributefil,"%s\tDELETE * in round %d\n",
                                       name,round);
              nDeleteAttr++;
              strcpy(deleteAttr[nDeleteAttr],name);     
            } else {
              fprintf(nextattributefil,"%s",fileRec); 
            }      
          } else {
            fprintf(nextattributefil,"%s",fileRec);
          }
          continue;
        }
        sprintf(name,"round.%d.attribute file out of order, case 5",
                     round-1);
        rederror(name,"reduceAttributes","305");
  
      } /* end while #3 */
      if (strcmp(control,"DATA") != 0) {
        sprintf(name,"round.%d.attribute file out of order, case 6",
                     round);
        rederror(name,"reduceAttributes","306");
      } 
      closeFile(prevattributefil); 
      closeFile(nextattributefil);
/*eject*/
      /* define next master */
      if (XdefineMaster(round+1) != 0) {
        sprintf(name,
           "Definition of master input file for round %d failed",
           round+1);
        rederror(name,"reduceAttributes","501");
      }

      /* compute error produced by master of next round */
      if (Xmatch(round) != 0) {
        sprintf(name, "Program match failed in round %d",round);
        rederror(name,"reduceAttributes","601");
      }

      /* get average error */
      sprintf(name,"round.%d.average.error",round);
      avgerrfil = openFileRedccdetail(name,"r");
      if (fgets(fileRec,MAXLEN,avgerrfil) == 0) {
        sprintf(name,"Empty round.%d.average.error file",round);
        rederror(name,"reduceAttributes","701");
      }
      closeFile(avgerrfil);
      if (sscanf(fileRec,"Average Error = %lf",&avgerror) != 1) {
        sprintf(name,
          "Incorrect record in round.%d.average.error file",
          round);
        rederror(name,"reduceAttributes","801");
      }
/*eject*/
      /* decide acceptance/rejection of this case */
      if (avgerror <= gParams.maxErrorFraction) {
        /* accept this case if minsig = 0.0 */
        if (minsig == 0.0) {
          sprintf(name,"\nAttributes Deleted in Round %d:\n",
                       round);
          showReductionSteps(name);
          for (n=1; n<=nDeleteAttr; n++) {
            sprintf(name,"  %s\n",deleteAttr[n]);
            showReductionSteps(name);
          }
          sprintf(name,"\nAverage error = %f\n\n",avgerror);
          return TRUE;
        }
        /* since minsig = 0.0 is only case with nDeleteAttr > 1, */
        /* must have nDeleteAttr = 1 */
        /* evaluate more cases */
        if (opt.flag == FALSE) {
          opt.flag = TRUE;
          opt.error = avgerror;
          strcpy(opt.name,deleteAttr[nDeleteAttr]);
        } else {
          if (avgerror < opt.error) {
            opt.error = avgerror;
            strcpy(opt.name,deleteAttr[nDeleteAttr]);
          }
        }    
      }

    } /* end for iter */
/*eject*/
    /* search for next larger minsig value */
    minsig2 = INFTY;
    for (n=1; n<=numAttributes; n++) {
      if ((status[n] == ACTIVE) &&
          (significance[n] > minsig)) {
        minsig2 = min(minsig2,significance[n]);        
      }
    }
    if (minsig2 == INFTY) {
      /* have tried all possible cases */
      break;
    }

    /* accept minsig2 as new minsig value */
    /* and do next retryflag iteration */
    minsig = minsig2;
    /* compute new nmin value */
    nmin= 0;
    for (n=1; n<=numAttributes; n++) {
      if ((status[n] == ACTIVE) && 
          (significance[n] == minsig)) {
        nmin++;
      }
    }
    
  } /* end for retryflag */
/*eject*/
  /* evaluate results */
  if (opt.flag == FALSE) {
    return FALSE;
  }

  /* output optimal case */
  sprintf(name,"\nAttribute Deleted in Round %d:\n",round);
  showReductionSteps(name);
  sprintf(name,"%s\n",opt.name);
  showReductionSteps(name);
  sprintf(name,"\nAverage error = %f\n\n",opt.error);
  showReductionSteps(name);

  sprintf(name,"round.%d.attribute",round-1);
  prevattributefil = openFileRedccdetail(name,"r");
  sprintf(name,"round.%d.attribute",round);
  nextattributefil = openFileRedccdetail(name,"w");

  while(fgets(fileRec,MAXLEN,prevattributefil) != 0) {
    if (fileRec[0] != '\0') {
      sscanf(fileRec,"%s",name);
      if (strcmp(name,opt.name) == 0) {
        fprintf(nextattributefil,"%s\tDELETE * in round %d\n",
                                  name,round);
      } else {
        fprintf(nextattributefil,"%s",fileRec);        
      }  
    }
  }
  closeFile(prevattributefil); 
  closeFile(nextattributefil);
/*eject*/
  /* define next master */
  if (XdefineMaster(round+1) != 0) {
    sprintf(name,
       "Definition of master input file for round %d failed",
       round+1);
    rederror(name,"reduceAttributes","1001");
  }

  /* compute error produced by master of next round */
  if (Xmatch(round) != 0) {
    sprintf(name, "Program match failed in round %d",round);
    rederror(name,"reduceAttributes","1101");
  }
 
  return TRUE;

}
/* last record of doRounds.c *****/
