#include "redparams.h"
/* NOTE: This is an independent program that */
/*       uses the parameter file redparams.h */
/***********************************************************
 * Program evaluatesub2file
 *
 * Evaluates sub2cc output file .sub2 for significance of variables,
 * as measured by occurences in factors
 *
 * Files
 *
 *   input.mst   = input master file
 *   input.sub2  = input sub2 file produced by sub2cc
 *                 note: sub2cc used the following files:
 *                       input.mst
 *                       input.ats
 *                       lsqccparams.input.dat
 *   output.significance = file with significance values for
 *                       variables
 *
 *   ./evaluatesub2file input.mst input.sub2 output.significance
 */
/*eject*/
/* Global structures */
/* polyhedron */
/* convention: all constraints are < */
struct {
  int numInequalities; /* number of currently active inequalities */
  int numOrigInequalities;/* number originally defined inequalities */
  double coeff[MAX_INEQUALITY+1][MAX_ATTRIBUTE+1];
  double rhs[MAX_INEQUALITY+1];
  int type; /* = POLYHEDRON: general polyhedron, not just a bound */
            /* = BOUND: polyhedron is one bound for one variable */
  int jBound; /* if BOUND case: = index of bounded variable */
              /*      polyhedron is defined by              */
              /*      coeff[1][jBound]*x[jBound] < rhs[1]   */
              /* else: = 0 */ 
} typedef PolyhedronArray;

/* polyhedron */
PolyhedronArray local;

/* Global Arrays and Variables */
char attribute[MAX_ATTRIBUTE+1][MAX_ENTRY];
int numAttributes;
double significance[MAX_ATTRIBUTE+1]; /* significance values */
double sig[MAX_ATTRIBUTE+1]; /* significance values, one polyhedron */ 
int targetflag[MAX_TARGET+1];/* = FALSE: target not yet encountered */
                             /* = TRUE: target already encountered */

/* Global Input and Output files */
FILE *inputmstfile;
FILE *inputsub2file;
FILE *significancefile;
char inputmstfilename[MAX_ID];
char inputsub2filename[MAX_ID];
char significancefilename[MAX_ID];

/* function prototypes */
void openFiles();
int  getIndex(char *attribute);
int  simplifyLine(char *lineread);
/*eject*/
/* main function */
int main(int argc, char *argv[])
{

  char lineread[MAXLEN] = {'\0'};
  int line;

  int j, jj, k, m, ncomp, stage, tgt;
  char *buffer;
  char comp[8][MAX_ID]; /* 8 = max number of components + 1 */
                        /* in lineread containing inequality part */ 
  char name[MAX_ID],range[MAX_ID];
  char control[MAX_ID];

  numAttributes = 0;

  strcpy(control,"");

  if (argc != 4) {
    printf("Calling Sequence:  evaluatesub2file input.mst input.sub2 output.significance\n"); 
    exit(1);
  }
  strcpy(inputmstfilename, argv[1]);
  strcpy(inputsub2filename, argv[2]);
  strcpy(significancefilename, argv[3]);

  /* DEBUG: comment out above and activate below */
  /* strcpy(inputmstfilename, "input.mst");
  strcpy(inputsub2filename, "input.sub2");
  strcpy(significancefilename, "output.significance"); */

  /* open all files */
  openFiles();
/*eject*/
  /* read attributes from input.mst file */

  while (fgets(lineread, MAXLEN, inputmstfile) != NULL) { 
    /* while #1 */
    line++;
    if  (simplifyLine(lineread) == 0) {
      continue;
    }

    /* Determine record type */
    if (strncmp(lineread, "DATA", 4) == 0) {
      strcpy(control,"DATA");
      break;
    }
    else if (strncmp(lineread, "ATTRIBUTES", 10) == 0) {
      strcpy(control,"ATTRIBUTES");
      continue;
    }

    /* have attribute */
    numAttributes++;
    if (numAttributes > MAX_ATTRIBUTE) {
      fprintf(stderr,
         "Error in evaluatessub2file: MAX_ATTRIBUTE too small\n");
      exit(1);
    }
    sscanf(lineread,"%s",attribute[numAttributes]);   
  } /* end while #1 */
/*eject*/
  if (strcmp(control,"DATA") != 0) {
    fprintf(stderr,
     "Error in evaluatessub2file: input.mst file %s out of order\n",
     inputmstfilename);
     exit(1); 
  }

  /* evaluate input.sub2 file */
  for (tgt=1; tgt<=MAX_TARGET; tgt++) {
    targetflag[tgt] = FALSE;
  }
  for (j=1; j<=numAttributes; j++) {
    significance[j] = 0;
  }
  strcpy(control,"TARGET");

  while (fgets(lineread, MAXLEN, inputsub2file) != NULL) {
    /* while #2 */
    line++;
    if  (simplifyLine(lineread) == 0) {
      continue;
    }

    /* read first string in lineread into name */
    sscanf(lineread,"%s",name);

    /* TARGET */
    if (strcmp(control,"TARGET") == 0) {
      if (strcmp(name,"TARGET") == 0) {
        sscanf(lineread,"TARGET %d STAGE %d %s",&tgt,&stage,range);
        if (tgt > MAX_TARGET) {
          fprintf(stderr,
              "Error in evaluatesub2file: MAX_TARGET too small\n");
          exit(1);
        }
        if (targetflag[tgt] == TRUE) {
          /* have processed this target case already with */
          /* higher significance, due to the high-to-low */
          /* sorting of cases; hence skip this case */
          continue;
        }
        targetflag[tgt] = TRUE;
        strcpy(control,"Factors");
      }
      continue;
    } /* end TARGET */
/*eject*/
    /* Factors */
    if (strcmp(control,"Factors") == 0) {
      if (strcmp(name,"Factors:") == 0) {
        /* initialize local number of inequalities */
        local.numInequalities = 0;
        strcpy(control,"Implication");
      }
      continue;      
    } /* end Factors */

    /* Implication */
    if (strcmp(control,"Implication") == 0) {
      /* lineread has line containing 'imply' or 'implies' */
      strcpy(control,"get inequalities");
      continue;      
    } /* end Factors */
/*eject*/
    /* get inequalities */
    if (strcmp(control,"get inequalities") == 0) {
      /* extract components from lineread */
      buffer = strtok(lineread," \t\n");
      ncomp = 1;
      strcpy(comp[ncomp],buffer);
      while (buffer != NULL) {
        buffer = strtok(NULL," \t\n");
        if (buffer != NULL) {
          ncomp++;
          strcpy(comp[ncomp],buffer);
        }      
      }
      /* replace additional comp[] entries by empty string */
      for (j=ncomp+1; j<=7; j++) {
        strcpy(comp[j],"");
      }
      /* ncomp = number of components in lineread */
      /* comp[j] = jth component */

      /* if comp[1] = "(": advance number of inequalities */
      /*                   set coefficients to 0.0 */
      if (strcmp(comp[1],"(") == 0) {
        local.numInequalities++;
        for (j=1; j<= numAttributes; j++) {
          local.coeff[local.numInequalities][j] = 0.0;
        }
      }
/*eject*/
      /* record cases */
      if (strcmp(comp[6],")") == 0) {
        /* examples: "( 2.0 x < 5.0 ) &" */
        /*           "( 2.0 x < 5.0 )"   */
        j = getIndex(comp[3]);
        local.coeff[local.numInequalities][j] =(double) atof(comp[2]);
        local.rhs[local.numInequalities] = (double) atof(comp[5]);
        if (strcmp(comp[4],">") == 0) {
          local.coeff[local.numInequalities][j] *= -1.0;
          local.rhs[local.numInequalities] *= -1.0;
        }

      } else if (strcmp(comp[5],")") == 0) {
        /* examples: "2.0 x < 5.0 ) &" */
        /*           "2.0 x < 5.0 )"   */        
        /*           "(   x < 5.0 ) &"   */ 
        /*           "(   x < 5.0 )"     */
        j = getIndex(comp[2]);
        if (strcmp(comp[1],"(") == 0) {
          local.coeff[local.numInequalities][j] = 1.0;
        } else {
          local.coeff[local.numInequalities][j] =
              (double) atof(comp[1]);
        }
        local.rhs[local.numInequalities] = (double) atof(comp[4]);
        if (strcmp(comp[3],">") == 0) {
          for (jj=1; jj<= numAttributes; jj++) {
            local.coeff[local.numInequalities][jj] *= -1.0;
          }
          local.rhs[local.numInequalities] *= -1.0;
        }

      } else if (ncomp == 3) {
        /* example: "( 2.0 x" */
        j = getIndex(comp[3]);
        local.coeff[local.numInequalities][j] = 
            (double) atof(comp[2]);

      } else if (ncomp == 2) {
        /* example: "2.0 x" */
        j = getIndex(comp[2]);
        local.coeff[local.numInequalities][j] = 
            (double) atof(comp[1]);
      } else {
        fprintf(stderr,
         "Error in evaluateSub2file: parsing problem\n");
         exit(1);
      }

      /* check if this is last inequality */
      if (strcmp(comp[ncomp],")") != 0) {
        /* this is not the last inequality */
        continue;
      }
    } /* end get inequalities */
/*eject*/
    /* compute significance values of attributes for polyhedron */
    for (j=1; j<=numAttributes; j++) {
      sig[j] = 0.0;
    }
    for (m=1; m<=local.numInequalities; m++) { /* begin for m */
      /* count number of nonzero coefficients in inequality m */
      k=0;
      for (j=1; j<=numAttributes; j++) {
        if (local.coeff[m][j] != 0) {
          k++;
        }
      }
      if (k == 0) {
        fprintf(stderr,
         "Error in evaluatesub2file: zero inequality\n");
      }
      /* update sig[j]; value is 1/k for attribute j with */
      /* nonzero coefficient */
      for (j=1; j<=numAttributes; j++) {
        if (local.coeff[m][j] != 0) {
          sig[j] = max(sig[j],1.0/((double)k));
        }
      }
    } /* end for m */

    /* update overall significance values */
    for (j=1; j<=numAttributes; j++) {
      significance[j] += sig[j];
    }

    /* proceed to next target case */
    strcpy(control,"TARGET");

  } /* end while #2 */

  /* write significance file */
  fprintf(significancefile,"ATTRIBUTES\n");
  for (j=1; j<=numAttributes; j++) {
    fprintf(significancefile,"%s	%.2f\n",
            attribute[j],significance[j]);
  } 
  fprintf(significancefile,"ENDATA\n");

  fclose(inputmstfile);
  fclose(inputsub2file);
  fclose(significancefile);

  exit(0);

}
/*eject*/
/*********************************************************
 *  getIndex
 * 
 *  purpose:  returns index for attribute name as 
 *            appears in mst file ATTRIBUTES section
 *********************************************************/
int getIndex(char *name)
{
  int i;
  for (i=1; i<=numAttributes; i++) {
    if (strcmp(attribute[i], name) == 0) {
      return i;
    }
  }
  
  printf("Error in getIndex():  Attribute not found: %s\n", name);
  exit(1);

  return 0;
}
/*eject*/
/*********************************************************
 *  openFiles
 * 
 *  purpose:  opens global input and output files
 *            
 *********************************************************/
void openFiles()
{
  if ((inputmstfile = fopen(inputmstfilename, "r")) == NULL) {
    fprintf(stderr, "Cannot open inputmstfile = %s\n", 
                    inputmstfilename);
    exit(1);
  }

  if ((inputsub2file = fopen(inputsub2filename, "r")) == NULL) {
    fprintf(stderr, "Cannot open inputsub2file = %s\n", 
                    inputsub2filename);
    exit(1);
  }

  if ((significancefile = fopen(significancefilename, "w")) == NULL) {
    fprintf(stderr, "Cannot open significancefile = %s\n", 
                    significancefilename);
    exit(1);
  }
}
/*eject*/
/*********************************************************
 *  simplifyLine
 * 
 *  purpose:  removes end-of-line white spaces and identifies
 *            blank or comment line
 *********************************************************/
int  simplifyLine(char *lineread) {

  int i, nz;

    nz = strlen(lineread);
    i = nz - 1;
    /* strip off carriage return and whitespace at the end */
    /* of the line */
    while (lineread[i]>=1 && lineread[i]<=32) {
      lineread[i] = '\0';
      i--;
    }

    /* skip blank and comment lines */
    if ((lineread[0] == '*') || 
        (lineread[0] == '\0')) {
      return 0;
    }
    return 1;
    
}
/**********last record of evaluatesub2file.c******************/

