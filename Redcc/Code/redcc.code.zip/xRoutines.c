/* first record of xRoutines.c *****/
#include "redcc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   int XdefineAlternate()
 *   int XdefineMaster(int round)
 *   int XevaluateSub2file(int round)
 *   int Xmatch(int round)
 *   int XsaveOptimalfile(int round)
 *   int Xsub2cc()
 */
/**************************************************************/
/*eject*/
/*************************************************************** 
----------------------------------------------------------
*  XdefineAlternate(int round): define alternate file .ats
***************************************************************/
int XdefineAlternate() {

  char cmnd[MAXLEN];

  sprintf(cmnd,
          "cp %s%s%s %sinput%s",
          gParams.directory, 
          gParams.prefix,
          gFileExt.ats,
          gParams.redccdetaildir, 
          gFileExt.ats);

  return(system(cmnd));

}
/*eject*/
/*************************************************************** 
----------------------------------------------------------
*  XdefineMaster(int round): define master file .mst for round
***************************************************************/
int XdefineMaster(int round) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

  sprintf(cmnd,
          "cat %sround.%d.attribute %sdatamaster > ",
          gParams.redccdetaildir,
          round-1,
          gParams.redccdetaildir);
  sprintf(addcmnd,
          "%sinput%s",
          gParams.redccdetaildir,
          gFileExt.mst);
  strcat(cmnd,addcmnd);               

  return(system(cmnd));

}

/*eject*/
/*************************************************************** 
----------------------------------------------------------
*  XevaluateSub2file(int round): evaluate .sub2 of round
***************************************************************/
int XevaluateSub2file(int round) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

  sprintf(cmnd,
          "%sRedcc/Code/evaluateSub2file ",
          gParams.leibnizpath);
  sprintf(addcmnd,
          "%sinput%s %sinput%s2 %sround.%d.significance",
          gParams.redccdetaildir,
          gFileExt.mst,
          gParams.redccdetaildir,
          gFileExt.sub,
          gParams.redccdetaildir,
          round);
  strcat(cmnd,addcmnd);

  return(system(cmnd));

}
/*eject*/
/*************************************************************** 
----------------------------------------------------------
*  Xmatch(int round): compute estimated values for .ats file
***************************************************************/
int Xmatch(int round) {

  char cmnd[MAXLEN];
  char addcmnd[MAXLEN];

  sprintf(cmnd,
          "%sMatchcc/Code/matchcc ",
          gParams.leibnizpath);
  sprintf(addcmnd,
          "%sinput%s %sinput%s %smatch.ats.mst %smatch.error ",
          gParams.redccdetaildir,
          gFileExt.mst,
          gParams.redccdetaildir,
          gFileExt.ats,
          gParams.redccdetaildir,
          gParams.redccdetaildir);
  strcat(cmnd,addcmnd);
  sprintf(addcmnd,
          "%smatch.test %smatch.solution %sround.%d.average.error",
          gParams.redccdetaildir,
          gParams.redccdetaildir,
          gParams.redccdetaildir,
          round);
  strcat(cmnd,addcmnd);

  return(system(cmnd));

}

/*eject*/
/*************************************************************** 
----------------------------------------------------------
*  XsaveOptimalfile(int round): save optimal file
***************************************************************/
int XsaveOptimalfile(int round) {

  char cmnd[MAXLEN];

  sprintf(cmnd,"cp %sround.%d.attribute %s%s%s",
          gParams.redccdetaildir,
          round,
          gParams.directory, 
          gParams.prefix,
          gFileExt.opt);         

  return(system(cmnd));

}

/*eject*/
/*************************************************************** 
----------------------------------------------------------
*  Xsub2cc(int round): execute sub2cc
***************************************************************/
int Xsub2cc(int round) {

  char cmnd[MAXLEN];

  sprintf(cmnd,
          "%sSub2cc/Code/sub2cc %slsqccparams.dat",
          gParams.leibnizpath,
          gParams.redccdetaildir);

  return(system(cmnd));

}

/* last record of xRoutines.c *******/















