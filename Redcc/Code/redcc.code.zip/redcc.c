/* first record of redcc.c *****/
/*
 *   Leibniz System: Redcc System
 *   Copyright 2008 by Leibniz Company
 *   Plano, Texas, U.S.A.
 *
 * ===================================================
 * Redcc System - Callable Subgroup Version redcc
 * ===================================================
 *
 *  caution: 
 *   - parameters must have been obtained 
 *     (see readParamsFile() for required information)
 *   - errfil must have been opened (see redccmain() program)
 *   - errfil must be closed after execution of redcc
 *  caution: these conditions are not checked by the program 
 * -----------------------------------------------------------
 *  Leibniz programs used:
 *  Subcc: sub2cc
 *
 *  subroutines in this file:
 *  int redcc()
 *  void doRounds()
 *  void initialize()
 *  void constructRedccdetail()    
 *  void removeRedccdetail()   
 * -----------------------------------------------------------
 */
#include "redcc.h"
/***********************************************************/	
int redcc() {

  char name[MAXLEN];
  char optimalfile[MAXLEN];


  /* initialize errorflag */
  errorflag = 0;

  /* initialize gNumOpenFiles */
  gNumOpenFiles = 0;

  /* construct Redccdetail directory */
  showReductionSteps("Construct Redccdetail directory\n\n");
  constructRedccdetail();

  /* initialize arrays, files, parameters */
  initialize();

  /* do reduction rounds */
  doRounds();
   
  /* print message for optimal attribute file */
  sprintf(optimalfile,"%s%s%s",
	  gParams.directory, gParams.prefix,
          gFileExt.opt);
  sprintf(name,"Output in file %s\n\n",optimalfile);
  showReductionSteps(name);

  /* if 'keep redcc details directory' is not 
   * specified in lsqccparams.dat, then remove
   * redcc detail directory
   */
  if (gKeepRedccdetail == FALSE) {
    showReductionSteps("Remove Redccdetail directory\n\n");
    removeRedccdetail();
  }

  if (gNumOpenFiles != 0) {
    rederror("mismatch of opened/closed files","redcc","901");
  }
  
  return errorflag;
	
}

/* last record of redcc.c *******/
    
