/* first record of util.c *****/
#include "redcc.h"
#include "features.h" /* system version selection */
/**************************************************************/
/*
 * subroutines in this file:
 *   void initialize()
 *   void createAttMasterFile()
 *   void createLsqccParamsFile()
 *   
 */
/***************************************************************/
/*eject*/
/************************************************************
 *   initialize(): initialize arrays, files, parameters
 ************************************************************/

void  initialize() {

  /* create lsqccparams.dat in Redccdetail directory for sub2cc */
  createLsqccParamsFile();

  /* define attribute file and data master file */
  createAttMasterFile();

  return;

}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  createAttMasterFile(): 
*    create attribute and data master file
* --------------------------------------------------------
***************************************************************/
void createAttMasterFile() {

  char fileRec[MAXLEN];
  char control[MAX_ID];

  FILE *attributefil;
  FILE *datamasterfil;
  FILE *masterfil;

  attributefil = openFileRedccdetail("round.0.attribute", "w");
  datamasterfil = openFileRedccdetail("datamaster", "w");
  masterfil = openFilePrefix(gFileExt.mst,"r");

  strcpy(control,"");

  while (fgets(fileRec,MAXLEN,masterfil) != 0) {  /* begin while */

    /* skip comment or blank line */
    if ((fileRec[0] == '*') || (fileRec[0] == '\n')) {
      continue;
    }

    if (strncmp(fileRec,"ATTRIBUTES",10) == 0) {
      strcpy(control,"ATTRIBUTES");
      fprintf(attributefil,"%s",fileRec);
      numAttributes = 0;
      continue;
    }

    if (strcmp(control,"ATTRIBUTES") == 0) {
      fprintf(attributefil,"%s",fileRec);
      if (strncmp(fileRec,"DATA",4) == 0) {
        strcpy(control,"DATA");
      } else {
        numAttributes++;
        if (sscanf(fileRec,"%s",attribute[numAttributes]) != 1) {
          rederror("Input master file out of order",
                   "createAttMasterFile","101");
        }
      }
      continue;
    }

    if (strcmp(control,"DATA") == 0) {
      fprintf(datamasterfil,"%s",fileRec);
      if (strncmp(fileRec,"ENDATA",6) == 0) {
        closeFile(attributefil);
        closeFile(datamasterfil);
        closeFile(masterfil);
        return;
      } else {
        continue;
      }
    }

    rederror("Input master file data out of order",
             "createAttMasterFile", "201");

  } /* end while */

}  
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  createLsqccParamsFile(): 
*    create lsqccparams.dat file for sub2cc
* --------------------------------------------------------
***************************************************************/
void createLsqccParamsFile() {

  char fileRec[MAXLEN]; 
  char name[MAXLEN];

  FILE *redccParams;
  FILE *sub2ccParams;

  redccParams = openFile(lsqccparamsname, "r");
  sub2ccParams = openFileRedccdetail("lsqccparams.dat","w");

  while (fgets(fileRec,MAXLEN,redccParams) != 0) {  /* begin while */

    if (strncmp(fileRec,"ENDATA",6) == 0) { 
      /* have copied all lines of lsqccparams file except
       * for ENDATA statement
       * complete file by adding statements
       */  

      /*************begin allcc section*************/
      sprintf(name,"begin allcc");
      fprintf(sub2ccParams,"%s\n",name);

      /* file name without extension */
      sprintf(name,
	      "file name without extension = input");
      fprintf(sub2ccParams,"%s\n",name);

      /* training/testing directory */
      sprintf(name,
	      "training/testing directory = %s",
              gParams.redccdetaildir);
      fprintf(sub2ccParams,"%s\n",name);

      /* ENDATA */
      sprintf(name,"ENDATA");
      fprintf(sub2ccParams,"%s\n",name);

      /* done with output file */
      closeFile(redccParams);
      closeFile(sub2ccParams);
      return;
    } /* end if strncmp(fileRec,"ENDATA" */

    /* write fileRec into output file */
    fprintf(sub2ccParams,"%s",fileRec);

  } /* end while */  

  rederror("Missing ENDATA record in lsqccparams.dat",
           "createLsqccParamsFile", "101");

}

/* last record of initialize.c *********/
