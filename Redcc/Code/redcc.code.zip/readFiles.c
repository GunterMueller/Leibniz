/* first record of readFiles.c *****/ 
#include "redcc.h"
#include "features.h" /* system version selection */
/***************************************************************/
/*
 * subroutines in this file:
 *   void lowerCase(char *ch)
 *   int  parse_param(char *lhs, char *rhs, char *record, 
 *                   FILE *params)
 *   void readParamsFile()
 *   void shiftLeft(char fileRec[])  
 */  
/*eject*/
/**************************************************************/
void lowerCase(char *ch)
{
	if (*ch >= 65 && *ch <= 90)
		*ch += 32;
}
/*eject*/
/**************************************************************
* --------------------------------------------------------
*  parse_param(): parse parameters
* --------------------------------------------------------
***************************************************************/
int parse_param(char *lhs, char *rhs, char *record, FILE *params) {
  char     str[128+1], ch;
  int      i, ix, l=0, r=0, nz;
  int      right = 0;
 
  if (feof(params)) {
    return(0);
  }
  fgets(str, 126, params);
  while (str[0] == '*') {
    if (feof(params)) {
      return(0);
    }
    fgets(str, 126, params);
  }  
/*
 *  change all string characters 
 *  with ascii code 1-31 or 127-254 by blanks
 */
  nz = strlen(str);
  for(i=0; i<=nz-1; i++)  {
    ix = (int)str[i];
    if (((ix>=1)&&
        (ix<=31))||
        ((ix>=127)&&
        (ix<=254))) {
      str[i] = ' ';
    }
  }
/*
 *  introduce carriage return character and,
 *  if necessary, new end of string character
 */
  if (str[nz-1] == ' ') {
    str[nz-1] = '\n';
  } else {
    str[nz] = '\n';
    str[nz+1] = '\0';
    nz++;
  }  
  
  strcpy(record, str);
  for (i = 0; i <= nz-1; i++) {
    ch = str[i];
    switch (ch) {
      case ' ':
                break;  
      case '=':
                right = 1;
                break;
      case '\n':
                break;
      default:
				if (right) {
				 rhs[r++] = ch;
               } else {
				 lowerCase(&ch);
                 lhs[l++] = ch;
               }
    }
  }
  lhs[l] = '\0';
  rhs[r] = '\0';  
  return(1);
}
/*eject*/
/**************************************************************/
void readParamsFile()
{
  FILE *redccParams;
  char record[MAXLEN] = {'\0'};
  char lhs[MAXLEN], rhs[MAXLEN];
  char message[MAXLEN];
  int cv[20] = {FALSE};
  int beginReadFlag;
	
  redccParams = openFile(lsqccparamsname, "r");

  /* Set default values */
  strcpy(gFileExt.cut, ".cut");
  strcpy(gFileExt.mst, ".mst");
  strcpy(gFileExt.mstAB, ".mstAB");
  strcpy(gFileExt.opt, ".opt");
  strcpy(gFileExt.rtr, ".rtr");
  strcpy(gFileExt.rts, ".rts");
  strcpy(gFileExt.rtsA, ".rtsA");
  strcpy(gFileExt.rtsB, ".rtsB");
  strcpy(gFileExt.rtsEqrtr, ".rtsEqrtr");
  strcpy(gFileExt.ats, ".ats");
  strcpy(gFileExt.sep, ".sep");
  strcpy(gFileExt.sub, ".sub");
  strcpy(gFileExt.tgt, ".tgt");
  strcpy(gFileExt.vot, ".vot");
  strcpy(gFileExt.votA, ".votA");
  strcpy(gFileExt.votB, ".votB");
  gShowSteps = FALSE;
  gShowReductionSteps = FALSE;
  gKeepRedccdetail = FALSE;
  gParams.maxErrorFraction = 0.01;
  /* Set beginReadFlag */
  beginReadFlag = TRUE;

/*eject*/	
  /* Loop at the file and look for tokens */
  while (parse_param(lhs, rhs, record, redccParams)) {
    /*
     * caution: parse_param() converts lhs to lower case
     *          this affects the tests below
     */
		
    /* Show steps on screen */
    if (strcmp(lhs,"showstepsonscreen") == 0) {
      gShowSteps = TRUE;
      gShowReductionSteps = TRUE;
      printf("\n");
      printf("show steps on screen\n\n");
      printf("                    Leibniz System\n");
      printf("                    redcc Program\n");
      printf("                     Version 10.0\n");
      printf("        Copyright 2001-2008 by Leibniz Company\n");
      printf("                 Plano, Texas, U.S.A.\n\n");
      continue;
    }

    /* "ENDATA" */
    if (strcmp(lhs, "endata") == 0 ||
      strcmp(lhs, "enddata") == 0) {
      cv[11] = TRUE;
      if (gShowSteps == TRUE ) {
        printf("\n**************************************\n\n");
      }
      break;
    }

    /* check for "begin...cc" specification */
    if ((strncmp(lhs,"begin",5) == 0) &&
        (strncmp(&lhs[strlen(lhs)-2],"cc",2) == 0)) {
      beginReadFlag = FALSE;
      if ((strcmp(lhs,"beginredcc") == 0) ||
          (strcmp(lhs,"beginallcc") == 0)) {
        beginReadFlag = TRUE;
      }
      continue;
    }
    if (beginReadFlag == FALSE) {
      continue;
    }

/*eject*/		

    /*  "file name without extension = " */
    if (strcmp(lhs,"filenamewithoutextension") == 0) {
      strcpy(gParams.prefix,rhs);
      cv[1] = TRUE;
      if (gShowSteps == TRUE) {
        printf("file name without extension = %s\n",
               gParams.prefix);
      }
     continue;
    }

    /* "training/testing directory = " */
    if (strcmp(lhs,"training/testingdirectory") == 0) {
      strcpy(gParams.directory,rhs);
      cv[2] = TRUE;
      if (gShowSteps == TRUE) {
        printf("training/testing directory = %s\n",
               gParams.directory);
      }
      continue;
    }

    /* "Leibniz directory = " */
    if (strcmp(lhs,"leibnizdirectory") == 0) {
      strcpy(gParams.leibnizpath,rhs);
      cv[3] = TRUE;
      if (gShowSteps == TRUE) {
        printf("Leibniz directory = %s\n",
               gParams.leibnizpath);
      }
      continue;
    }
/*eject*/

    /*  "cutpoint file extension           (default: cut)   = " */
    if (strcmp(lhs, "cutpointfileextension(default:cut)") == 0) {
      strcpy(gFileExt.cut,".");
      strcat(gFileExt.cut,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "cutpoint file extension           (default: cut)   = %s\n",
          rhs);
      }
      continue;
    }

    /*  "distribution file extension       (default: dis)   = " */
    /*  note: not used by redcc, hence no action here */
    if (strcmp(lhs,
        "distributionfileextension(default:dis)") == 0) {
      continue;
    }

    /*  "executable file extension         (default: exe)  = " */
    /*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"executablefileextension(default:exe)") == 0) {
      continue;
    }

    /*  "minimization file extension       (default: min)  = " */
    /*  note: not used by lsqcc, hence no action here */
    if (strcmp(lhs,"minimizationfileextension(default:min)") == 0){
      continue;
    }

    /*  "master file extension             (default: mst)   = " */
    if (strcmp(lhs, "masterfileextension(default:mst)") == 0) {
      strcpy(gFileExt.mst,".");
      strcat(gFileExt.mst,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "master file extension             (default: mst)   = %s\n",
          rhs);
      }
      continue;
    }
/*eject*/

    /*  "master AB file extension          (default: mstAB) = " */
    if (strcmp(lhs, "masterabfileextension(default:mstab)") == 0) {
      strcpy(gFileExt.mstAB,".");
      strcat(gFileExt.mstAB,rhs);
      if (gShowSteps == TRUE ) {
        printf(
        "master AB file extension          (default: mstAB) = %s\n",
          rhs);
      }
      continue;
    }

    /*  "optimal record file extension     (default: opt)   = " */
    /*  note: not used by redcc, hence no action here */
    if (strcmp(lhs,
        "optimalrecordfileextension(default:opt)") == 0) {
      continue;
    }

    /*  "pyrpred file extension            (default: prd)   = " */
    if (strcmp(lhs, "pyrpredfileextension(default:prd)") == 0) {
    /*  note: not used by redcc, hence no action here */
      continue;
    }

    /*  "partial data file extension       (default: ptl)   = " */
    if (strcmp(lhs,
        "partialdatafileextension(default:ptl)") == 0) {
    /*  note: not used by redcc, hence no action here */
      continue;
    }
/*eject*/

    /*  "pyramid file extension            (default: pyr)   = " */
    /*  note: not used by redcc, hence no action here */
    if (strcmp(lhs,
        "pyramidfileextension(default:pyr)") == 0) {
      continue;
    }

    /*  "rational training file extension  (default: rtr)   = " */
    if (strcmp(lhs,
             "rationaltrainingfileextension(default:rtr)") == 0) {
      strcpy(gFileExt.rtr,".");
      strcat(gFileExt.rtr,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational training file extension  (default: rtr)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "rational testing file extension  (default: rts)    = " */
    if (strcmp(lhs,
             "rationaltestingfileextension(default:rts)") == 0) {
      strcpy(gFileExt.rts,".");
      strcat(gFileExt.rts,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational testing file extension   (default: rts)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "rational testing A file extension (default: rtsA)  = " */
    if (strcmp(lhs,
             "rationaltestingafileextension(default:rtsa)") == 0) {
      strcpy(gFileExt.rtsA,".");
      strcat(gFileExt.rtsA,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational testing A file extension (default: rtsA)  = %s\n",
        rhs);
      }
      continue;
    }
/*eject*/

   /*  "rational testing B file extension (default: rtsB)  = " */
    if (strcmp(lhs,
             "rationaltestingbfileextension(default:rtsb)") == 0) {
      strcpy(gFileExt.rtsB,".");
      strcat(gFileExt.rtsB,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rational testing B file extension (default: rtsB)  = %s\n",
        rhs);
      }
      continue;
    }

   /* "rational testEqtrain file ext.    (default: rtsEqrtr) = " */
    if (strcmp(lhs,
       "rationaltesteqtrainfileext.(default:rtseqrtr)") == 0) {
      strcpy(gFileExt.rtsEqrtr,".");
      strcat(gFileExt.rtsEqrtr,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
      "rational testEqtrain file ext.    (default: rtsEqrtr) = %s\n",
        rhs);
      }
      continue;
    }

   /*  "alternate testing file            (default: ats)     = " */
    if (strcmp(lhs,
             "alternatetestingfile(default:ats)") == 0) {
      strcpy(gFileExt.ats,".");
      strcat(gFileExt.ats,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
       "alternate testing file            (default: ats)   = %s\n", 
        rhs);
      }
      continue;
    }
/*eject*/
    /*  "rule file extension               (default: rul)   = " */
    if (strcmp(lhs,
        "rulefileextension(default:rul)") == 0) {
      strcpy(gFileExt.rul,".");
      strcat(gFileExt.rul,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "rule file extension               (default: rul)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "separation file extension         (default: sep)   = " */
    if (strcmp(lhs,
        "separationfileextension(default:sep)") == 0) {
      strcpy(gFileExt.sep,".");
      strcat(gFileExt.sep,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "separation file extension         (default: sep)   = %s\n",
        rhs);
      }
      continue;
    }
/*eject*/
    /*  "subgroup file extension           (default: sub)   = " */
    if (strcmp(lhs,
        "subgroupfileextension(default:sub)") == 0) {
      strcpy(gFileExt.sub,".");
      strcat(gFileExt.sub,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "subgroup file extension           (default: sub)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "target file extension             (default: tgt)   = " */
    if (strcmp(lhs,
        "targetfileextension(default:tgt)") == 0) {
      strcpy(gFileExt.tgt,".");
      strcat(gFileExt.tgt,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "target file extension             (default: tgt)   = %s\n",
        rhs);
      }
      continue;
    }
				
    /*  "logic training file extension     (default: trn)   = " */
    /*  note: not used by redcc, hence no action here */
    if (strcmp(lhs,
      "logictrainingfileextension(default:trn)") == 0) {
      continue;
    }

    /*  "logic testing file extension      (default: tst)   = " */
    /*  note: not used by redcc, hence no action here */
    if (strcmp(lhs,
      "logictestingfileextension(default:tst)") == 0) {
      continue;
    }

    /*  "visualization file extension      (default: vis)   = " */
    /*  note: not used by redcc, hence no action here */
    if (strcmp(lhs,
       "visualizationfileextension(default:vis)") == 0) {
      continue;
    }
/*eject*/

    /*  "vote file extension               (default: vot)   = " */
    if (strcmp(lhs,
        "votefileextension(default:vot)") == 0) {
      strcpy(gFileExt.vot,".");
      strcat(gFileExt.vot,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "vot file extension                (default: vot)   = %s\n",
        rhs);
      }
      continue;
    }

    /*  "vote A file extension             (default: votA)  = " */
    if (strcmp(lhs,
        "voteafileextension(default:vota)") == 0) {
      strcpy(gFileExt.votA,".");
      strcat(gFileExt.votA,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "vote A file extension             (default: votA)  = %s\n",
        rhs);
      }
      continue;
    }

    /*  "vote B file extension             (default: votB)  = " */
    if (strcmp(lhs,
        "votebfileextension(default:votb)") == 0) {
      strcpy(gFileExt.votB,".");
      strcat(gFileExt.votB,rhs);
      if (gShowSteps == TRUE ) {
        printf( 
        "vot B file extension              (default: votB)  = %s\n",
        rhs);
      }
      continue;
    }
/*eject*/

    /* "missing entries (absent, unavailable) = " */
    /*  note: not used by redcc, hence no action here */
    if (strcmp(lhs, 
        "missingentries(absent,unavailable)") == 0) {
      continue; 
    }
/*eject*/

    /* "Redcc detail directory = " */
    if (strcmp(lhs,"redccdetaildirectory") == 0) {
      strcpy(gParams.redccdetaildir,rhs);
      cv[4] = TRUE;
      if (gShowSteps == TRUE) {
        printf("Redcc detail directory = %s\n",
               gParams.redccdetaildir);
      }
      continue;
    }

    /* "show reduction processing steps" */
    if (strcmp(lhs, "showreductionprocessingsteps") == 0) {
      gShowReductionSteps = TRUE;
      continue;
    }

    /* "keep redcc detail directory" */
    if (strcmp(lhs, "keepredccdetaildirectory") == 0) {
      gKeepRedccdetail = TRUE; 
      continue;
    }

   /* "max error fraction = " */
   if (strcmp(lhs, "maxerrorfraction") == 0) {
     if (gShowSteps == TRUE ) {
       printf("max error fraction = %s\n", rhs);\
     }
     if (rhs != NULL) {
       gParams.maxErrorFraction  = (float) atof(rhs);
     }
     continue;
   }
/*eject*/
    /* line cannot be interpreted */
    printf(
    "\nRecord in file lsqccparams.dat cannot be interpreted:\n\n");
    printf(" %s \n", record);
    printf("Please correct lsqccparams.dat file\n");
    printf("and execute redcc again\n");
    fprintf(errfil, 
    "\nRecord in file lsqccparams.dat cannot be interpreted:\n\n");
    fprintf(errfil, " %s \n", record);
    fprintf(errfil, "Please correct lsqccparams.dat file\n");
    fprintf(errfil,	"and execute redcc again\n");
    rederror("Error","readParamsFile", "501");

  } /* end of while */
/*eject*/
  /* confirm that all the information was entered */
  if(cv[1]==FALSE) {
    sprintf(message,
   "Filename without extension is not specified in lsqccparams.dat");
    rederror(message,"readParamsFile", "101");
  }

  if(cv[2]==FALSE) {
    rederror(
    "Training/testing directory is not specified in lsqccparams.dat",
    "readParamsFile", "102");
  }

  if(cv[3]==FALSE) {
    rederror("Leibniz directory is not specified in lsqccparams.dat",
             "readParamsFile", "103");
  }

  if(cv[4]==FALSE) {
    rederror(
        "Redcc detail directory is not specified in lsqccparams.dat",
        "readParamsFile", "104");
  }

  if(cv[11]==FALSE) {
    rederror(
        "ENDATA statement missing in lsqccparams.dat",
        "readParamsFile", "111");
  }

  closeFile(redccParams);
  return;
		
}
/*eject*/
/*************************************************************
*	Shift the line left
*   Ascii 32 = space, 9 = tab
**************************************************************/
void shiftLeft(char fileRec[]) {

  while(fileRec[0] == 32 || fileRec[0] == 9) {
    strcpy(fileRec, fileRec+1);
  }

  return;
}

/* last record of readFiles.c *******/
