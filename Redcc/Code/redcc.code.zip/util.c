/* first record of util.c *****/
#include "redcc.h"
#include "features.h" /* system version selection */
/**************************************************************/
/*
 * subroutines in this file:
 *   void  constructRedccdetail()
 *   void  closeFile(FILE* file);
 *   FILE* openFile(char* name, char* mode)
 *   FILE* openFilePrefix(char* extension, char* mode)
 *   FILE* openFileRedccdetail(char* name, char* mode)
 *   void  removeRedccdetail()
 *   void  showReductionSteps(char *message)
 *   void  rederror(char *m1,char *m2, char *m3)
 */
/***************************************************************/
/*eject*/
/************************************************************
 *   constructRedccdetail(): construct Redcc detail directory
 ************************************************************/

void  constructRedccdetail() {

  char cmnd[MAXLEN];
  char redccdetail[MAX_DIRECTORY+MAX_ID];

  FILE *out;

/*  
 *  gParams.redccdetaildir contains a terminating '/'
 *  to be consistent with Leibniz System convention
 */

  strcpy(redccdetail,gParams.redccdetaildir);

#ifdef UNIX

  sprintf(cmnd,"test -d %s",redccdetail);
    
    if( system(cmnd)  == 0 ) {    
/*
 * directory exists already, clean it
 * after introduction of fake file TMPlsq76xi2uy3
 * so that rm command does not cause error message
 * for empty directory
 */
      out = openFileRedccdetail("TMPlsq76xi2uy3TMPlsq76xi2uy3","w");
      closeFile(out); 
      sprintf(cmnd,"rm  %s*",redccdetail);
      system(cmnd);
    } else {
/*
 * directory does not exist, create it
 */
      sprintf(cmnd,"mkdir  %s",redccdetail);
      system(cmnd);
    }

#endif /*UNIX specification */

#ifdef WINDOWS

/* remove '\\' of directory specification */
  redccdetail[strlen[redccdetail]-1] = '\0';
  sprintf(cmnd, "IF EXIST %s. (del /f /q %s\\*) ELSE mkdir %s.",
		  redccdetail, redccdetail, redccdetail);
  system(cmnd);

  #endif /* WINDOWS specification */

  return;
}
/*eject*/
/***************************************************************/
void closeFile(FILE* file) 
{
  fclose(file);
  gNumOpenFiles--;
  return; 
}
/***************************************************************/
FILE* openFile(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,"Error opening %s \n for %s. Stop.\n",
                  name, mode);
          rederror(message,"openFile","101");
	}

        gNumOpenFiles++;	
	return out;
}
/****************************************************************/
FILE* openFilePrefix(char* extension, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,gParams.directory);
	strcat(file,gParams.prefix);
	strcat(file,extension);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,
            "Error opening %s \n for %s. Stop.\n", file, mode);
	  rederror(message,"openFilePrefix","101");
	}
	
        gNumOpenFiles++;	
	return out;
}
/****************************************************************/
FILE* openFileRedccdetail(char* name, char* mode)
{
	FILE* out;
	char file[MAX_DIRECTORY+MAX_ID];
        char message[MAXLEN];

	strcpy(file,gParams.redccdetaildir);
	strcat(file,name);
	
	out = fopen(file, mode);
	if (out == NULL)
	{
          sprintf(message,
              "Error opening %s \n for %s. Stop.\n", file, mode);
          rederror(message,"openFileRedccdetail","101");
	}
	
        gNumOpenFiles++;	
	return out;
}	
/*eject*/
/****************************************************
 * removeRedccdetail(): remove Redcc detail directory 
 ****************************************************/
void removeRedccdetail() {

  char cmnd[MAXLEN];
  char redccdetail[MAX_DIRECTORY+MAX_ID];

/*  
 *  gParams.redccdetaildir contains a terminating '/'
 *  to be consistent with Leibniz System convention
 */

  strcpy(redccdetail,gParams.redccdetaildir);

#ifdef UNIX  

  sprintf(cmnd,"rm %s*",redccdetail);
  system(cmnd);
  
  sprintf(cmnd,"rmdir %s",redccdetail);
  system(cmnd);

#endif /* UNIX specification */

#ifdef WINDOWS

/*
 * rd /s /q redccdetail
 */
  sprintf(cmnd, "rd /s /q %s", redccdetail);
  system(cmnd);

#endif /* WINDOWS specification */

  return;
}
/*eject*/
/****************************************************
 * showReductionSteps(): show reduction processing steps 
 ****************************************************/
void showReductionSteps(char *message) {

  if (gShowReductionSteps == TRUE) {
    printf("%s",message);
  }
  fprintf(errfil,"%s",message);

  return;
}
/*eject*/
/***************************************************************
*  rederror(): redcc system error termination 
****************************************************************/
void rederror(char *m1,char *m2, char *m3) {
/*
 */
  printf("%s\nStop\n",m1);
  fprintf(errfil,"%s\nStop\n",m1);

  printf("\n*******REDCC SYSTEM ERROR*******\n");
  printf("ERROR IN %s  code %s\n",m2,m3);
  printf("**********************************\n");
  printf("For details, see error file redcc.err\n");
/*
 */
  fprintf(errfil,"\n*******REDCC SYSTEM ERROR*******\n");
  fprintf(errfil,"ERROR IN %s  code %s\n",m2,m3);
  fprintf(errfil,"**********************************\n");
  exit(1);

}
/* last record of util.c *******/

















